var user_details =  {
  "expanded_url" : "http:\/\/www.swm.cc",
  "screen_name" : "swmcc",
  "location" : "iPhone: 54.584564,-5.950852",
  "url" : "http:\/\/t.co\/MtfzvtHd",
  "full_name" : "Stephen McCullough",
  "bio" : "Started breathing since 1979, haven't stopped since.",
  "id" : "804717",
  "created_at" : "2007-03-01 23:30:42 +0000",
  "display_url" : "swm.cc"
}