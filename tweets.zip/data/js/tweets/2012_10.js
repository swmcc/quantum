Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263756544460595202",
  "text" : "I'm a Presbie dammit - we don't do Halloween, line dancing or marrying outside our family circle!",
  "id" : 263756544460595202,
  "created_at" : "2012-10-31 21:37:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/sgGWbTQD",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=S8zIYY_zUx0",
      "display_url" : "youtube.com\/watch?v=S8zIYY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263629801707933696",
  "text" : "What the actual fuck.... http:\/\/t.co\/sgGWbTQD",
  "id" : 263629801707933696,
  "created_at" : "2012-10-31 13:13:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/263616496318681089\/photo\/1",
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/EkHJq4aB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6iNzoRCEAEdLZs.jpg",
      "id_str" : "263616496322875393",
      "id" : 263616496322875393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6iNzoRCEAEdLZs.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/EkHJq4aB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263616496318681089",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden is hungry http:\/\/t.co\/EkHJq4aB",
  "id" : 263616496318681089,
  "created_at" : "2012-10-31 12:20:45 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263565035165601792",
  "geo" : { },
  "id_str" : "263580140859174912",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams happy birthday.",
  "id" : 263580140859174912,
  "in_reply_to_status_id" : 263565035165601792,
  "created_at" : "2012-10-31 09:56:17 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263429109567324160",
  "geo" : { },
  "id_str" : "263432133811503104",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I am holding out hope.",
  "id" : 263432133811503104,
  "in_reply_to_status_id" : 263429109567324160,
  "created_at" : "2012-10-31 00:08:09 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263425582203797504",
  "text" : "Disney can't fuck up Star Wars anymore than Lucas did with 1-3... So lets just see. Have hope... Could be good.",
  "id" : 263425582203797504,
  "created_at" : "2012-10-30 23:42:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 0, 9 ],
      "id_str" : "9488072",
      "id" : 9488072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263373554098241536",
  "geo" : { },
  "id_str" : "263424878747721728",
  "in_reply_to_user_id" : 9488072,
  "text" : "@shylands it might be good. Clone Wars season 3 and on isn't half bad.",
  "id" : 263424878747721728,
  "in_reply_to_status_id" : 263373554098241536,
  "created_at" : "2012-10-30 23:39:19 +0000",
  "in_reply_to_screen_name" : "shylands",
  "in_reply_to_user_id_str" : "9488072",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ihope",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263407197550157824",
  "geo" : { },
  "id_str" : "263424436265447426",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight I dunno. The Clone Wars season 3 on is pretty good. I'm on the fence.. Just make it more adult and it should work. #ihope",
  "id" : 263424436265447426,
  "in_reply_to_status_id" : 263407197550157824,
  "created_at" : "2012-10-30 23:37:34 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263314310162415616",
  "geo" : { },
  "id_str" : "263314631043461120",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Like the mountains in springtime,  Like a walk in the rain, like a storm in the desert",
  "id" : 263314631043461120,
  "in_reply_to_status_id" : 263314310162415616,
  "created_at" : "2012-10-30 16:21:14 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Front",
      "screen_name" : "designbyfront",
      "indices" : [ 16, 30 ],
      "id_str" : "15629803",
      "id" : 15629803
    }, {
      "name" : "Typecast",
      "screen_name" : "TypecastApp",
      "indices" : [ 38, 50 ],
      "id_str" : "299681133",
      "id" : 299681133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263237582559780864",
  "text" : "Big congrats to @designbyfront on the @TypecastApp front.",
  "id" : 263237582559780864,
  "created_at" : "2012-10-30 11:15:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul McKeever",
      "screen_name" : "paulmckeever",
      "indices" : [ 0, 13 ],
      "id_str" : "15741536",
      "id" : 15741536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263237269593403392",
  "in_reply_to_user_id" : 15741536,
  "text" : "@paulmckeever congratulations to you and your team :D",
  "id" : 263237269593403392,
  "created_at" : "2012-10-30 11:13:50 +0000",
  "in_reply_to_screen_name" : "paulmckeever",
  "in_reply_to_user_id_str" : "15741536",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 8, 21 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 22, 30 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263187466540961792",
  "geo" : { },
  "id_str" : "263188640992202752",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco @Paul_Moffett @jbrevel a little @moffeloco running about.. Fucking hell... That'd be one ugly mofo. I hope no one has that handle!",
  "id" : 263188640992202752,
  "in_reply_to_status_id" : 263187466540961792,
  "created_at" : "2012-10-30 08:00:36 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 7, 20 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 25, 33 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dude",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263173673731633152",
  "text" : "I hope @Paul_Moffett and @jbrevel remember to pull out\/rollover later. Too new a couple to be having a baby! #dude-hormones",
  "id" : 263173673731633152,
  "created_at" : "2012-10-30 07:01:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263034310112731136",
  "geo" : { },
  "id_str" : "263035525177430016",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ Brilliant... Something to look forward to.",
  "id" : 263035525177430016,
  "in_reply_to_status_id" : 263034310112731136,
  "created_at" : "2012-10-29 21:52:10 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 123, 137 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263032607908954112",
  "geo" : { },
  "id_str" : "263033112706048000",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc Also if they spoil The Waking Dead.. Possibly Sons of Anarchy as well as I might not get a chance on Wed night! \/cc @ChrisKnowles_",
  "id" : 263033112706048000,
  "in_reply_to_status_id" : 263032607908954112,
  "created_at" : "2012-10-29 21:42:35 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263032332515168257",
  "geo" : { },
  "id_str" : "263032900780425217",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues We will see :) I don't have time to get to it tonight. Will be Wednesday before I get a chance. But I still procured the stuff :)",
  "id" : 263032900780425217,
  "in_reply_to_status_id" : 263032332515168257,
  "created_at" : "2012-10-29 21:41:45 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263032607908954112",
  "text" : "I'm only home. So I only have time for Broadwalk tonight.. Am out tomorrow night as well. If anyone spoils Homeland for me they fucking die!",
  "id" : 263032607908954112,
  "created_at" : "2012-10-29 21:40:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 13, 20 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stilltoosoon",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263025432960581636",
  "geo" : { },
  "id_str" : "263032256786997249",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @srushe You used to find me attractive Nail.. Then Ards happened and it was never the same. #stilltoosoon? ;)",
  "id" : 263032256786997249,
  "in_reply_to_status_id" : 263025432960581636,
  "created_at" : "2012-10-29 21:39:11 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263030066693419008",
  "geo" : { },
  "id_str" : "263032052780240898",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues drink this all the time so thought I'd give it a go. If nothing else I'll get good coffee and the house will smell nice :)",
  "id" : 263032052780240898,
  "in_reply_to_status_id" : 263030066693419008,
  "created_at" : "2012-10-29 21:38:22 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263030066693419008",
  "geo" : { },
  "id_str" : "263031934748332033",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues Aye. Its been said to me that I should introduce things back into the house that reminds me of happier times. The bro used to..",
  "id" : 263031934748332033,
  "in_reply_to_status_id" : 263030066693419008,
  "created_at" : "2012-10-29 21:37:54 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262944779212578816",
  "geo" : { },
  "id_str" : "263022956719005696",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe mailing lists yes. That's what I meant. Lucky I'm pretty eh ;)",
  "id" : 263022956719005696,
  "in_reply_to_status_id" : 262944779212578816,
  "created_at" : "2012-10-29 21:02:14 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/262993523790462976\/photo\/1",
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/Izu407h1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6ZXN2xCQAAPXOC.jpg",
      "id_str" : "262993523798851584",
      "id" : 262993523798851584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6ZXN2xCQAAPXOC.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/Izu407h1"
    } ],
    "hashtags" : [ {
      "text" : "imfullofshit",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262993523790462976",
  "text" : "Oh yeah :) The gourmet shit with a Tesco machine. #imfullofshit http:\/\/t.co\/Izu407h1",
  "id" : 262993523790462976,
  "created_at" : "2012-10-29 19:05:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262936616304267264",
  "geo" : { },
  "id_str" : "262939761608622080",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe i am still using mutt for newsgroups :)",
  "id" : 262939761608622080,
  "in_reply_to_status_id" : 262936616304267264,
  "created_at" : "2012-10-29 15:31:39 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262939278647111680",
  "geo" : { },
  "id_str" : "262939724048658433",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke s\/FUCK OFF\/YOU WANKER\/ :D",
  "id" : 262939724048658433,
  "in_reply_to_status_id" : 262939278647111680,
  "created_at" : "2012-10-29 15:31:30 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/262934083833823233\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/VvWzxch7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6YhJ_rCAAEajGv.png",
      "id_str" : "262934083842211841",
      "id" : 262934083842211841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6YhJ_rCAAEajGv.png",
      "sizes" : [ {
        "h" : 151,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 151,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 122,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 151,
        "resize" : "fit",
        "w" : 420
      } ],
      "display_url" : "pic.twitter.com\/VvWzxch7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262934083833823233",
  "text" : "Buying software for an open source nerd like me doesn't happen often. So it must be good if I buy it! http:\/\/t.co\/VvWzxch7",
  "id" : 262934083833823233,
  "created_at" : "2012-10-29 15:09:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262918196523323392",
  "text" : "I just had to do \"rvm get head\" on my mac... I feel quite dirty...",
  "id" : 262918196523323392,
  "created_at" : "2012-10-29 14:05:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wakingmeupisbad",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262498623722491905",
  "text" : "Some twat is having fun with a chainsaw... He's been at it since 8am. When I find him I am gonna cut his cock off with it! #wakingmeupisbad",
  "id" : 262498623722491905,
  "created_at" : "2012-10-28 10:18:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262196568751472640",
  "geo" : { },
  "id_str" : "262202482111963137",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit move to google apps. No hassle :) Coffee next week sir?",
  "id" : 262202482111963137,
  "in_reply_to_status_id" : 262196568751472640,
  "created_at" : "2012-10-27 14:41:57 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262194798084112384",
  "text" : "I just put on HIFNY on iplayer... Conrad Black is on the panel.. This is gonna be a massacre :)",
  "id" : 262194798084112384,
  "created_at" : "2012-10-27 14:11:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckingawesome",
      "indices" : [ 73, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261832488677175297",
  "text" : "Top Gun theme just came on.. Yeah - Best. Friday. Afternoon. Song. Ever. #fuckingawesome",
  "id" : 261832488677175297,
  "created_at" : "2012-10-26 14:11:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261820609636478977",
  "text" : "OH: \"Jim, I don't see your hole there..\" - \"Well its a big hole!!\" :D :D",
  "id" : 261820609636478977,
  "created_at" : "2012-10-26 13:24:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/261452994988617729\/photo\/1",
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/ky6bA2sD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6DeHRxCMAA6PiE.png",
      "id_str" : "261452994997006336",
      "id" : 261452994997006336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6DeHRxCMAA6PiE.png",
      "sizes" : [ {
        "h" : 417,
        "resize" : "fit",
        "w" : 603
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 603
      } ],
      "display_url" : "pic.twitter.com\/ky6bA2sD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261452994988617729",
  "text" : "I think my music taste is just getting worse and worse... I don't know how this happened!!! http:\/\/t.co\/ky6bA2sD",
  "id" : 261452994988617729,
  "created_at" : "2012-10-25 13:03:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 25, 38 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261451606741114880",
  "text" : "Am must saying it here.. @Paul_Moffett is full of wank\u2026 Only man that can destroy \"Killing in the name of\". I think I might kill him!!",
  "id" : 261451606741114880,
  "created_at" : "2012-10-25 12:58:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 14, 27 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261401357519581184",
  "geo" : { },
  "id_str" : "261449667441721345",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates @paul_moffett Oh he is\u2026 but I think that will be changing soon :) BBC Radio 6 - didn't even know there was a Radio 6!",
  "id" : 261449667441721345,
  "in_reply_to_status_id" : 261401357519581184,
  "created_at" : "2012-10-25 12:50:32 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 81 ],
      "url" : "https:\/\/t.co\/JzDqeOtG",
      "expanded_url" : "https:\/\/github.com\/play\/play",
      "display_url" : "github.com\/play\/play"
    } ]
  },
  "geo" : { },
  "id_str" : "261393479937171456",
  "text" : "We are now listening to Radio1 in the office.. Sooner I get https:\/\/t.co\/JzDqeOtG set up on our bot the better I think!",
  "id" : 261393479937171456,
  "created_at" : "2012-10-25 09:07:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldshcool",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261099054086373376",
  "text" : "Self Esteem from The Offspring just came on Spotify\u2026 FUCKING. AWESOME\u2026 #oldshcool",
  "id" : 261099054086373376,
  "created_at" : "2012-10-24 13:37:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261019596402880513",
  "geo" : { },
  "id_str" : "261026682268442624",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull I'm here! :D",
  "id" : 261026682268442624,
  "in_reply_to_status_id" : 261019596402880513,
  "created_at" : "2012-10-24 08:49:45 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 18, 33 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 69, 75 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261026616208158720",
  "text" : "She misses me :) \u201C@annette_mccull: still in the habit of checking if @swmcc is in when I get to work! He's not.\u201D",
  "id" : 261026616208158720,
  "created_at" : "2012-10-24 08:49:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/260501740418392068\/photo\/1",
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/EbbkW24A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5188-WCYAIJtv3.jpg",
      "id_str" : "260501740426780674",
      "id" : 260501740426780674,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5188-WCYAIJtv3.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/EbbkW24A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260501740418392068",
  "text" : "My card to my Dad on his 65th :) http:\/\/t.co\/EbbkW24A",
  "id" : 260501740418392068,
  "created_at" : "2012-10-22 22:03:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260070870293311488",
  "text" : "I spent most of this weekend sleeping.. Kinda needed it..",
  "id" : 260070870293311488,
  "created_at" : "2012-10-21 17:31:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259357247019286529",
  "geo" : { },
  "id_str" : "260070801800310784",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning I'll get you another time :)",
  "id" : 260070801800310784,
  "in_reply_to_status_id" : 259357247019286529,
  "created_at" : "2012-10-21 17:31:25 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dreamteam",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259368334846488577",
  "geo" : { },
  "id_str" : "260070759697899520",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe cheers Steve - hopefully we'll get to work again soon :) #dreamteam",
  "id" : 260070759697899520,
  "in_reply_to_status_id" : 259368334846488577,
  "created_at" : "2012-10-21 17:31:15 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259394744042536960",
  "geo" : { },
  "id_str" : "260070680777875456",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard your welcome buddy :) Hope you enjoyed it - miss ya already! :)",
  "id" : 260070680777875456,
  "in_reply_to_status_id" : 259394744042536960,
  "created_at" : "2012-10-21 17:30:56 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259259464048332801",
  "text" : "And now... Now I sleep....",
  "id" : 259259464048332801,
  "created_at" : "2012-10-19 11:47:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 1, 14 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259259424726716416",
  "text" : ".@RickyHassard gets the best prize for his message on my card... Think this means I lose - eternally.",
  "id" : 259259424726716416,
  "created_at" : "2012-10-19 11:47:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259259268711202817",
  "text" : "Thanks very much to the lovely people at Tascomi for my leaving gift and card - means a lot.. Will miss yas!",
  "id" : 259259268711202817,
  "created_at" : "2012-10-19 11:46:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "livejump",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257544465886093314",
  "text" : "I love seeing 'event stuff' unfold on twitter.. #livejump",
  "id" : 257544465886093314,
  "created_at" : "2012-10-14 18:12:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257133864349220865",
  "text" : "Attack of the clones is on... Ohhhhhh such a bad film. So so so bad.",
  "id" : 257133864349220865,
  "created_at" : "2012-10-13 15:01:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256778680389484544",
  "text" : "RT @HaVoCT5: @swmcc i though my music taste was bad, last week it was mulan and poccahontas! that lead to chats about our first hardons  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "256770415253413888",
    "geo" : { },
    "id_str" : "256773357532495872",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc i though my music taste was bad, last week it was mulan and poccahontas! that lead to chats about our first hardons tho! Every Cloud!",
    "id" : 256773357532495872,
    "in_reply_to_status_id" : 256770415253413888,
    "created_at" : "2012-10-12 15:08:33 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 256778680389484544,
  "created_at" : "2012-10-12 15:29:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256772547197153280",
  "text" : "Now \"sabotage\" has come on... Double fucking epic.",
  "id" : 256772547197153280,
  "created_at" : "2012-10-12 15:05:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fridaychoons",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256770415253413888",
  "text" : "\"I wanna hold your hand\" and \"Baby drive my car\" came on itunes for me there. FUCKING. EPIC. #fridaychoons",
  "id" : 256770415253413888,
  "created_at" : "2012-10-12 14:56:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256415696999813121",
  "text" : "I wish I stayed in bed this morning....",
  "id" : 256415696999813121,
  "created_at" : "2012-10-11 15:27:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 22, 29 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 34, 43 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256387795378122752",
  "text" : "Lovely lunch with the @srushe and @ManyHues at the plough in Hillsborough. Yummy :D",
  "id" : 256387795378122752,
  "created_at" : "2012-10-11 13:36:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 26, 34 ],
      "id_str" : "79820731",
      "id" : 79820731
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 73, 85 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 129, 136 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256322380467695616",
  "text" : "Am an honorary downstairs @tascomi geek for the next 10mins - sitting at @niall_adams old desk to debug something with help from @srushe :)",
  "id" : 256322380467695616,
  "created_at" : "2012-10-11 09:16:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255765484681695232",
  "text" : "\u201CI suggest a new strategy, R2. Let the wookiee win.\u201D",
  "id" : 255765484681695232,
  "created_at" : "2012-10-09 20:23:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 126, 139 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255669691236904960",
  "text" : "This sentence was taken out of context \"and I'm fingering myself\" as the boss walked out of the kitchen.. Last time I talk to @RickyHassard",
  "id" : 255669691236904960,
  "created_at" : "2012-10-09 14:02:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "russell",
      "screen_name" : "idoru",
      "indices" : [ 19, 25 ],
      "id_str" : "5582822",
      "id" : 5582822
    }, {
      "name" : "russell",
      "screen_name" : "idoru",
      "indices" : [ 92, 98 ],
      "id_str" : "5582822",
      "id" : 5582822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodtimes",
      "indices" : [ 99, 109 ]
    }, {
      "text" : "comebacktothecabalwemissya",
      "indices" : [ 110, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255589792614608896",
  "text" : "Ohhh look it is an @idoru - a fellow founder of the cabal and left wing hippie :D \/me kicks @idoru #goodtimes #comebacktothecabalwemissya",
  "id" : 255589792614608896,
  "created_at" : "2012-10-09 08:45:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255425288014548992",
  "text" : "\u201CBoring conversation anyway. Luke, we\u2019re gonna have company!\"",
  "id" : 255425288014548992,
  "created_at" : "2012-10-08 21:51:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255366294285725697",
  "geo" : { },
  "id_str" : "255374243389394944",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley thanks very much for your help... Foppin 'checkcode' :D",
  "id" : 255374243389394944,
  "in_reply_to_status_id" : 255366294285725697,
  "created_at" : "2012-10-08 18:28:58 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 7, 21 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mondayisbreakingme",
      "indices" : [ 105, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255362368408797184",
  "text" : "Me and @peter_omalley just spent 45mins going through code only to change about nine lines in one file.. #mondayisbreakingme",
  "id" : 255362368408797184,
  "created_at" : "2012-10-08 17:41:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254985302383407104",
  "text" : "\u201CIf this is a consular ship, where is the ambassador?\"",
  "id" : 254985302383407104,
  "created_at" : "2012-10-07 16:43:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254726087748243457",
  "geo" : { },
  "id_str" : "254899260955447297",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe GUI email clients :( Baah :) Mailplane seems nice so far though - but it is no mutt :)",
  "id" : 254899260955447297,
  "in_reply_to_status_id" : 254726087748243457,
  "created_at" : "2012-10-07 11:01:34 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254706135024668672",
  "geo" : { },
  "id_str" : "254709093938393089",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I am almost through season 2 of suits as well!!! Best. Saturday. Ever.",
  "id" : 254709093938393089,
  "in_reply_to_status_id" : 254706135024668672,
  "created_at" : "2012-10-06 22:25:54 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/gVT6gkwU",
      "expanded_url" : "http:\/\/swmcc.wordpress.com\/2012\/10\/06\/mutt-for-gmail\/",
      "display_url" : "swmcc.wordpress.com\/2012\/10\/06\/mut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "254679665216745472",
  "text" : "Posted a new blog entry: http:\/\/t.co\/gVT6gkwU",
  "id" : 254679665216745472,
  "created_at" : "2012-10-06 20:28:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 21, 34 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254617718827929600",
  "text" : "Nice Saturday... Met @stevebiscuit for coffee and then to me bros for food and a catchup.. How Saturdays should be. Now to make some stew!",
  "id" : 254617718827929600,
  "created_at" : "2012-10-06 16:22:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ground Espresso Bars",
      "screen_name" : "groundespresso",
      "indices" : [ 3, 18 ],
      "id_str" : "21042266",
      "id" : 21042266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254290812828012546",
  "text" : "RT @groundespresso: Ground in Lisburn!We looked at some sites,we picked a few.Then we saw the rates in Lisburn and now we know why so ma ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253955444714921986",
    "text" : "Ground in Lisburn!We looked at some sites,we picked a few.Then we saw the rates in Lisburn and now we know why so many units are lying empty",
    "id" : 253955444714921986,
    "created_at" : "2012-10-04 20:31:10 +0000",
    "user" : {
      "name" : "Ground Espresso Bars",
      "screen_name" : "groundespresso",
      "protected" : false,
      "id_str" : "21042266",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3372520019\/136933e6141179279106ae55980dbecd_normal.png",
      "id" : 21042266,
      "verified" : false
    }
  },
  "id" : 254290812828012546,
  "created_at" : "2012-10-05 18:43:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 74, 82 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254226827537686528",
  "text" : "OH: \"I can vividly remember my first hard on\" - I am really going to miss @HaVoCT5",
  "id" : 254226827537686528,
  "created_at" : "2012-10-05 14:29:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/254222463070765056\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/5V79f8tO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4ct-7WCAAAUojm.png",
      "id_str" : "254222463074959360",
      "id" : 254222463074959360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4ct-7WCAAAUojm.png",
      "sizes" : [ {
        "h" : 66,
        "resize" : "fit",
        "w" : 391
      }, {
        "h" : 66,
        "resize" : "fit",
        "w" : 391
      }, {
        "h" : 66,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 57,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 66,
        "resize" : "fit",
        "w" : 391
      } ],
      "display_url" : "pic.twitter.com\/5V79f8tO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254222463070765056",
  "text" : "I was really enjoying this song and wanted to know what it was... The evidence is starting to stack up.. http:\/\/t.co\/5V79f8tO",
  "id" : 254222463070765056,
  "created_at" : "2012-10-05 14:12:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254211801284231168",
  "text" : "Phil Collins has come into my playlist five times in the last two hours. I think the universe is trying to tell me something.",
  "id" : 254211801284231168,
  "created_at" : "2012-10-05 13:29:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 100, 113 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckoff",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254203659175473154",
  "text" : "\"Oh it has a surprise ending, you will love it\" #fuckoff&amp;dieubastardfuckinghatepeoplethatdothat @paul_moffett does it all the fucking time!",
  "id" : 254203659175473154,
  "created_at" : "2012-10-05 12:57:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 39, 55 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 16, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254135685844463616",
  "text" : "I don't do that #ff balls really.. But @michaelnsimpson - top bloke he is... Follow him - he might not accept you but give it a go anyway :)",
  "id" : 254135685844463616,
  "created_at" : "2012-10-05 08:27:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 115, 127 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253996096429375488",
  "text" : "I hate servers. Really hate the fuckers at 00:10 in the morning. Need someone to wake up to annoy over this. Err.. @niall_adams *tag u r it*",
  "id" : 253996096429375488,
  "created_at" : "2012-10-04 23:12:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 16, 23 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253834187029766144",
  "text" : "Chess game with @srushe coming up.. This is my time... I just quoted The Goonies (with a slight amendment)  so I will win. I will!",
  "id" : 253834187029766144,
  "created_at" : "2012-10-04 12:29:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Heckmann",
      "screen_name" : "aaronheckmann",
      "indices" : [ 3, 17 ],
      "id_str" : "13818902",
      "id" : 13818902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mongodb",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 105 ],
      "url" : "https:\/\/t.co\/RWvPzCco",
      "expanded_url" : "https:\/\/github.com\/LearnBoost\/express-mongoose\/pull\/18\/files",
      "display_url" : "github.com\/LearnBoost\/exp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253542473442418689",
  "text" : "RT @aaronheckmann: express-mongoose 0.1.0 released, adds express v3.x compatibility https:\/\/t.co\/RWvPzCco #mongodb #nodejs",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mongodb",
        "indices" : [ 87, 95 ]
      }, {
        "text" : "nodejs",
        "indices" : [ 96, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 86 ],
        "url" : "https:\/\/t.co\/RWvPzCco",
        "expanded_url" : "https:\/\/github.com\/LearnBoost\/express-mongoose\/pull\/18\/files",
        "display_url" : "github.com\/LearnBoost\/exp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "253541906112462848",
    "text" : "express-mongoose 0.1.0 released, adds express v3.x compatibility https:\/\/t.co\/RWvPzCco #mongodb #nodejs",
    "id" : 253541906112462848,
    "created_at" : "2012-10-03 17:07:55 +0000",
    "user" : {
      "name" : "Aaron Heckmann",
      "screen_name" : "aaronheckmann",
      "protected" : false,
      "id_str" : "13818902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3497059361\/5d522c25916de422d27a0bbbce76d05a_normal.jpeg",
      "id" : 13818902,
      "verified" : false
    }
  },
  "id" : 253542473442418689,
  "created_at" : "2012-10-03 17:10:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253514188733956096",
  "text" : "Git is lovely - then I have to go into subversion and it feels like I stepped about 20 years behind... Still does the job though.",
  "id" : 253514188733956096,
  "created_at" : "2012-10-03 15:17:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "indices" : [ 3, 14 ],
      "id_str" : "66949689",
      "id" : 66949689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/XhVuHhLb",
      "expanded_url" : "http:\/\/www.northernirelandscreen.co.uk\/news\/3082\/hollywood-blockbuster-looper-showcasing-local-vfx-talent.aspx",
      "display_url" : "northernirelandscreen.co.uk\/news\/3082\/holl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253447256324321280",
  "text" : "RT @blacknorth: http:\/\/t.co\/XhVuHhLb",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/XhVuHhLb",
        "expanded_url" : "http:\/\/www.northernirelandscreen.co.uk\/news\/3082\/hollywood-blockbuster-looper-showcasing-local-vfx-talent.aspx",
        "display_url" : "northernirelandscreen.co.uk\/news\/3082\/holl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "253444182335709185",
    "text" : "http:\/\/t.co\/XhVuHhLb",
    "id" : 253444182335709185,
    "created_at" : "2012-10-03 10:39:36 +0000",
    "user" : {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "protected" : false,
      "id_str" : "66949689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759091973\/blacklogo_normal.gif",
      "id" : 66949689,
      "verified" : false
    }
  },
  "id" : 253447256324321280,
  "created_at" : "2012-10-03 10:51:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253263022687137792",
  "geo" : { },
  "id_str" : "253263888064327680",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues all due respect... you are dead wrong. Awful. Film. :D",
  "id" : 253263888064327680,
  "in_reply_to_status_id" : 253263022687137792,
  "created_at" : "2012-10-02 22:43:10 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 78, 92 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252754392648916992",
  "text" : "Lovely lunch (bacon, lentil &amp; carrot soup) @ Humble Pie Hillsoborough c\/o @jenporterhall - thanks :D",
  "id" : 252754392648916992,
  "created_at" : "2012-10-01 12:58:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryan boyd",
      "screen_name" : "ryguyrg",
      "indices" : [ 3, 11 ],
      "id_str" : "954001",
      "id" : 954001
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "str",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252707107399417856",
  "text" : "RT @ryguyrg: George Dyson def of big data: \"when the cost of throwing away data become higher than the machine cost of storing it.\" #str ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "strataconf",
        "indices" : [ 119, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252698694007275520",
    "text" : "George Dyson def of big data: \"when the cost of throwing away data become higher than the machine cost of storing it.\" #strataconf",
    "id" : 252698694007275520,
    "created_at" : "2012-10-01 09:17:18 +0000",
    "user" : {
      "name" : "ryan boyd",
      "screen_name" : "ryguyrg",
      "protected" : false,
      "id_str" : "954001",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2267846303\/wfdv3rwiidmmrkxkiey9_normal.png",
      "id" : 954001,
      "verified" : false
    }
  },
  "id" : 252707107399417856,
  "created_at" : "2012-10-01 09:50:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]