Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerd",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/gsaimKjdiP",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aYec03PVQpQ",
      "display_url" : "youtube.com\/watch?v=aYec03\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318489160237346817",
  "text" : "http:\/\/t.co\/gsaimKjdiP - when games were games. I loved this. First C64 game I ever played. Then I took the manual and learned basic. #nerd",
  "id" : 318489160237346817,
  "created_at" : "2013-03-31 22:25:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 81, 89 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318446192906366976",
  "text" : "The retweet I did is an April fools but the lego scene is pretty much how me and @jbrevel develop :)",
  "id" : 318446192906366976,
  "created_at" : "2013-03-31 19:34:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "atlassian",
      "screen_name" : "atlassian",
      "indices" : [ 3, 13 ],
      "id_str" : "18060279",
      "id" : 18060279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/7YQDiIWh8k",
      "expanded_url" : "http:\/\/ow.ly\/jBOyz",
      "display_url" : "ow.ly\/jBOyz"
    } ]
  },
  "geo" : { },
  "id_str" : "318446030871990275",
  "text" : "RT @atlassian: We're very excited to announce JIRA Jr.- Where tracking is child's play! http:\/\/t.co\/7YQDiIWh8k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/7YQDiIWh8k",
        "expanded_url" : "http:\/\/ow.ly\/jBOyz",
        "display_url" : "ow.ly\/jBOyz"
      } ]
    },
    "geo" : { },
    "id_str" : "318438409456734209",
    "text" : "We're very excited to announce JIRA Jr.- Where tracking is child's play! http:\/\/t.co\/7YQDiIWh8k",
    "id" : 318438409456734209,
    "created_at" : "2013-03-31 19:03:27 +0000",
    "user" : {
      "name" : "atlassian",
      "screen_name" : "atlassian",
      "protected" : false,
      "id_str" : "18060279",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1825767682\/icon_normal.jpg",
      "id" : 18060279,
      "verified" : true
    }
  },
  "id" : 318446030871990275,
  "created_at" : "2013-03-31 19:33:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318441520908873728",
  "geo" : { },
  "id_str" : "318445213234384896",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel hell yeah...",
  "id" : 318445213234384896,
  "in_reply_to_status_id" : 318441520908873728,
  "created_at" : "2013-03-31 19:30:29 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318424958478991360",
  "geo" : { },
  "id_str" : "318439104729710592",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery No eggs at all... Ahh well my Mum and Sis weren't too angry :)",
  "id" : 318439104729710592,
  "in_reply_to_status_id" : 318424958478991360,
  "created_at" : "2013-03-31 19:06:13 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hopetheydontvote",
      "indices" : [ 73, 90 ]
    }, {
      "text" : "glenavy",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318419209921122304",
  "text" : "OH: \u201CLet\u2019s hope this extra hour of sunlight makes the snow melt faster\u201D. #hopetheydontvote #glenavy",
  "id" : 318419209921122304,
  "created_at" : "2013-03-31 17:47:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 3, 9 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318409381211414528",
  "text" : "RT @Jason: That moment when you think you've had the best idea of your life and then the designer sends you the mocks and you know it's  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318391382677004288",
    "text" : "That moment when you think you've had the best idea of your life and then the designer sends you the mocks and you know it's gonna work.",
    "id" : 318391382677004288,
    "created_at" : "2013-03-31 15:56:35 +0000",
    "user" : {
      "name" : "jason",
      "screen_name" : "Jason",
      "protected" : false,
      "id_str" : "3840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1582247652\/Screen_shot_2011-10-10_at_2.54.06_PM_normal.png",
      "id" : 3840,
      "verified" : true
    }
  },
  "id" : 318409381211414528,
  "created_at" : "2013-03-31 17:08:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318409286919270401",
  "text" : "The Spar in Glenavy better do Easter eggs or I am fucked.",
  "id" : 318409286919270401,
  "created_at" : "2013-03-31 17:07:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318334895107735554",
  "geo" : { },
  "id_str" : "318347151686135808",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning Adams took it.... he huffed when I stuck him chair to the ground... so it is hidden",
  "id" : 318347151686135808,
  "in_reply_to_status_id" : 318334895107735554,
  "created_at" : "2013-03-31 13:00:50 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318308937357217792",
  "geo" : { },
  "id_str" : "318309167079247872",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues Yo :) Loved that text you sent btw... never replied to it cos I am an asshole - but it made me laugh. New Star Trek is out soon :)",
  "id" : 318309167079247872,
  "in_reply_to_status_id" : 318308937357217792,
  "created_at" : "2013-03-31 10:29:53 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/317979901867216899\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/tsQy3AHGoy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGmxCTkCUAEYl-J.jpg",
      "id_str" : "317979901875605505",
      "id" : 317979901875605505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGmxCTkCUAEYl-J.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/tsQy3AHGoy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317979901867216899",
  "text" : "When working on personal projects sometimes it's good to get out of dodge - mmmm coffeeee http:\/\/t.co\/tsQy3AHGoy",
  "id" : 317979901867216899,
  "created_at" : "2013-03-30 12:41:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317833732532879360",
  "text" : "Can't get to sleep... So am gonna watch Heat.. \"Empathy was yesterday. Today, you're wasting my motherfucking time.\"",
  "id" : 317833732532879360,
  "created_at" : "2013-03-30 03:00:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317741176168005632",
  "text" : "The clocks go forward this weekend. There us snow outside. Fuck it all!",
  "id" : 317741176168005632,
  "created_at" : "2013-03-29 20:52:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317668732023500801",
  "geo" : { },
  "id_str" : "317741043913216000",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid cheers - I just stole food and milk from the parents. Will go tomorrow. The Tesco in Newtonbreds scares me - too big.",
  "id" : 317741043913216000,
  "in_reply_to_status_id" : 317668732023500801,
  "created_at" : "2013-03-29 20:52:22 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 0, 6 ],
      "id_str" : "3840",
      "id" : 3840
    }, {
      "name" : "TWiStartups",
      "screen_name" : "TWistartups",
      "indices" : [ 7, 19 ],
      "id_str" : "112880396",
      "id" : 112880396
    }, {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 40, 48 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "PJ Hyett",
      "screen_name" : "pjhyett",
      "indices" : [ 49, 57 ],
      "id_str" : "717233",
      "id" : 717233
    }, {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 61, 69 ],
      "id_str" : "713263",
      "id" : 713263
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 76, 83 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317682661160263681",
  "geo" : { },
  "id_str" : "317696618105274368",
  "in_reply_to_user_id" : 3840,
  "text" : "@Jason @TWistartups I would love to see @mojombo @pjhyett or @defunkt  from @github on your show... Great work btw.",
  "id" : 317696618105274368,
  "in_reply_to_status_id" : 317682661160263681,
  "created_at" : "2013-03-29 17:55:50 +0000",
  "in_reply_to_screen_name" : "Jason",
  "in_reply_to_user_id_str" : "3840",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317657487484547072",
  "text" : "What times does Tesco shut at tonight - hopefully nine...",
  "id" : 317657487484547072,
  "created_at" : "2013-03-29 15:20:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317643791815294976",
  "geo" : { },
  "id_str" : "317649582609801216",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda am sure getting it setup is a balls.. But I &lt;3 the whole \"reviewer\" \"integrator\" testing thing.. But these days \"pull request\" :)",
  "id" : 317649582609801216,
  "in_reply_to_status_id" : 317643791815294976,
  "created_at" : "2013-03-29 14:48:56 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317643010424848386",
  "geo" : { },
  "id_str" : "317643492023209984",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda Rose tinted glasses though - but it wasn't too bad. Of course you compare it to shit now and it is awful.",
  "id" : 317643492023209984,
  "in_reply_to_status_id" : 317643010424848386,
  "created_at" : "2013-03-29 14:24:44 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 3, 13 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317643337169502209",
  "text" : "RT @carisenda: My introduction to source control was Aegis. I was a \"graphic designer\" then. It's still probably too soon to talk about it.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "317643010424848386",
    "text" : "My introduction to source control was Aegis. I was a \"graphic designer\" then. It's still probably too soon to talk about it.",
    "id" : 317643010424848386,
    "created_at" : "2013-03-29 14:22:49 +0000",
    "user" : {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "protected" : false,
      "id_str" : "212603717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1513037620\/avatar_normal.png",
      "id" : 212603717,
      "verified" : false
    }
  },
  "id" : 317643337169502209,
  "created_at" : "2013-03-29 14:24:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 67, 80 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317632550615003136",
  "text" : "Great bank holiday weekend and that wanker and poor excuse for man @Paul_Moffett has smitten me with his disease... FUCK YOU MOFFETT!!!",
  "id" : 317632550615003136,
  "created_at" : "2013-03-29 13:41:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/317600774567890944\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/6lZDeVq6IQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGhYOMUCEAAfZ_V.png",
      "id_str" : "317600774576279552",
      "id" : 317600774576279552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGhYOMUCEAAfZ_V.png",
      "sizes" : [ {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6lZDeVq6IQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317600774567890944",
  "text" : "I can't reveal any names.... But.... Those that know will know :) http:\/\/t.co\/6lZDeVq6IQ",
  "id" : 317600774567890944,
  "created_at" : "2013-03-29 11:35:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317597290628014080",
  "text" : "Am installing RVM on a Redhat machine\u2026 Feels good man\u2026 dirty but good :)",
  "id" : 317597290628014080,
  "created_at" : "2013-03-29 11:21:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317576765365186562",
  "text" : "RT @MiriamKerbache: Diamond IT are giving away an IPAD MINI to 1 lucky follower on the 30th of April!To enter, all you have to do is RET ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "317563463457181697",
    "text" : "Diamond IT are giving away an IPAD MINI to 1 lucky follower on the 30th of April!To enter, all you have to do is RETWEET this and follow me!",
    "id" : 317563463457181697,
    "created_at" : "2013-03-29 09:06:44 +0000",
    "user" : {
      "name" : "Miriam Kerbache",
      "screen_name" : "MiriamDiamondrg",
      "protected" : false,
      "id_str" : "172736413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3502664762\/085747fe56b08dbf6b611845377f593b_normal.jpeg",
      "id" : 172736413,
      "verified" : false
    }
  },
  "id" : 317576765365186562,
  "created_at" : "2013-03-29 09:59:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 27, 43 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317561489479327744",
  "geo" : { },
  "id_str" : "317576575631626240",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams @michaelnsimpson My side was never messy... Just sayin...",
  "id" : 317576575631626240,
  "in_reply_to_status_id" : 317561489479327744,
  "created_at" : "2013-03-29 09:58:50 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317295430226567169",
  "geo" : { },
  "id_str" : "317297487197114369",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson this pleases me greatly..",
  "id" : 317297487197114369,
  "in_reply_to_status_id" : 317295430226567169,
  "created_at" : "2013-03-28 15:29:50 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317241171174907908",
  "text" : "Just gave vertical integrated testing a go there on a new app I am writing.. Pretty sweet if I do say so\u2026.",
  "id" : 317241171174907908,
  "created_at" : "2013-03-28 11:46:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 7, 19 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/317227775993995265\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/XLYZrWeCBO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGcE-0VCYAEq3ig.jpg",
      "id_str" : "317227775998189569",
      "id" : 317227775998189569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGcE-0VCYAEq3ig.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/XLYZrWeCBO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317227775993995265",
  "text" : "Thanks @DebbieCReid Easter egg :) http:\/\/t.co\/XLYZrWeCBO",
  "id" : 317227775993995265,
  "created_at" : "2013-03-28 10:52:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317216023461892096",
  "geo" : { },
  "id_str" : "317216425754361857",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel we should count the number of times he does \"hmmmm\" :)",
  "id" : 317216425754361857,
  "in_reply_to_status_id" : 317216023461892096,
  "created_at" : "2013-03-28 10:07:44 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 20, 33 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moffluvin",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317216279213793280",
  "text" : "RT @jbrevel: @swmcc @Paul_Moffett ah huh, yes, yes, yes, ok, hmmmmmm #moffluvin",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Paul Moffett",
        "screen_name" : "Paul_Moffett",
        "indices" : [ 7, 20 ],
        "id_str" : "36913698",
        "id" : 36913698
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moffluvin",
        "indices" : [ 56, 66 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "317215810722615296",
    "geo" : { },
    "id_str" : "317216023461892096",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @Paul_Moffett ah huh, yes, yes, yes, ok, hmmmmmm #moffluvin",
    "id" : 317216023461892096,
    "in_reply_to_status_id" : 317215810722615296,
    "created_at" : "2013-03-28 10:06:08 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 317216279213793280,
  "created_at" : "2013-03-28 10:07:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindatrue",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317215810722615296",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett sounds like he is having phone sex with a german right now.... #kindatrue",
  "id" : 317215810722615296,
  "created_at" : "2013-03-28 10:05:17 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316932684804939776",
  "text" : "I've left my fob\/keys to the office at home all week. If I do this tomorrow I think the office butler will kill me - he hates being a butler",
  "id" : 316932684804939776,
  "created_at" : "2013-03-27 15:20:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Plosker",
      "screen_name" : "DstroyAllModels",
      "indices" : [ 0, 16 ],
      "id_str" : "7274992",
      "id" : 7274992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316925700953231360",
  "geo" : { },
  "id_str" : "316926250797125632",
  "in_reply_to_user_id" : 7274992,
  "text" : "@DstroyAllModels don't do it :)",
  "id" : 316926250797125632,
  "in_reply_to_status_id" : 316925700953231360,
  "created_at" : "2013-03-27 14:54:41 +0000",
  "in_reply_to_screen_name" : "DstroyAllModels",
  "in_reply_to_user_id_str" : "7274992",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316902385303830530",
  "text" : "I am starting to think Colloquy is a big pile of balls.....",
  "id" : 316902385303830530,
  "created_at" : "2013-03-27 13:19:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Urban Anton",
      "screen_name" : "FUN",
      "indices" : [ 3, 7 ],
      "id_str" : "235555412",
      "id" : 235555412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316902156173197312",
  "text" : "RT @FUN: Price of 1 gigabyte of storage over time:\n1981 $300,000\n1987 $50,000\n1990 $10,000\n1994 $1,000\n1997 $100\n2000 $10\n2004 $1\n2012 $0.10",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316580220679376897",
    "text" : "Price of 1 gigabyte of storage over time:\n1981 $300,000\n1987 $50,000\n1990 $10,000\n1994 $1,000\n1997 $100\n2000 $10\n2004 $1\n2012 $0.10",
    "id" : 316580220679376897,
    "created_at" : "2013-03-26 15:59:41 +0000",
    "user" : {
      "name" : "Just so you Know",
      "screen_name" : "Know",
      "protected" : false,
      "id_str" : "221452291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411110038\/a8b7eced4dc43374e7ae21112ff749b6_normal.jpeg",
      "id" : 221452291,
      "verified" : false
    }
  },
  "id" : 316902156173197312,
  "created_at" : "2013-03-27 13:18:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316869544280989697",
  "geo" : { },
  "id_str" : "316871847989899264",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I\u2019m having a few problems with mutt too - just need to sit down and go through the oil .muttrc - gonna install growl tonight.",
  "id" : 316871847989899264,
  "in_reply_to_status_id" : 316869544280989697,
  "created_at" : "2013-03-27 11:18:30 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 3, 10 ],
      "id_str" : "17843859",
      "id" : 17843859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/3dLLjyHOna",
      "expanded_url" : "http:\/\/robtweed.wordpress.com\/2013\/03\/26\/mumps-the-proto-database-or-how-to-build-your-own-nosql-database\/",
      "display_url" : "robtweed.wordpress.com\/2013\/03\/26\/mum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316819583610793986",
  "text" : "RT @rtweed: Create your own NoSQL database: http:\/\/t.co\/3dLLjyHOna",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/3dLLjyHOna",
        "expanded_url" : "http:\/\/robtweed.wordpress.com\/2013\/03\/26\/mumps-the-proto-database-or-how-to-build-your-own-nosql-database\/",
        "display_url" : "robtweed.wordpress.com\/2013\/03\/26\/mum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316817654147055617",
    "text" : "Create your own NoSQL database: http:\/\/t.co\/3dLLjyHOna",
    "id" : 316817654147055617,
    "created_at" : "2013-03-27 07:43:09 +0000",
    "user" : {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "protected" : false,
      "id_str" : "17843859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1398354510\/me_normal.png",
      "id" : 17843859,
      "verified" : false
    }
  },
  "id" : 316819583610793986,
  "created_at" : "2013-03-27 07:50:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TWiStartups",
      "screen_name" : "TWistartups",
      "indices" : [ 3, 15 ],
      "id_str" : "112880396",
      "id" : 112880396
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 19, 23 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316647770742206465",
  "text" : "RT @TWistartups: . @dhh calls BS on startup myth of eating ramen, being so self-sacrificing in order to be part of the 'club' - http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DHH",
        "screen_name" : "dhh",
        "indices" : [ 2, 6 ],
        "id_str" : "14561327",
        "id" : 14561327
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/gKnegxfSWh",
        "expanded_url" : "http:\/\/thisweekin.com\/live",
        "display_url" : "thisweekin.com\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "316647673933463552",
    "text" : ". @dhh calls BS on startup myth of eating ramen, being so self-sacrificing in order to be part of the 'club' - http:\/\/t.co\/gKnegxfSWh",
    "id" : 316647673933463552,
    "created_at" : "2013-03-26 20:27:43 +0000",
    "user" : {
      "name" : "TWiStartups",
      "screen_name" : "TWistartups",
      "protected" : false,
      "id_str" : "112880396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1302543910\/TWITTER_TWIST_normal.png",
      "id" : 112880396,
      "verified" : false
    }
  },
  "id" : 316647770742206465,
  "created_at" : "2013-03-26 20:28:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316647418416492547",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh is a handsome man.... has to be said....",
  "id" : 316647418416492547,
  "created_at" : "2013-03-26 20:26:42 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 0, 8 ],
      "id_str" : "15966431",
      "id" : 15966431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/o1f5QrGbIg",
      "expanded_url" : "http:\/\/blog.swm.cc\/2012\/10\/06\/mutt-for-gmail\/",
      "display_url" : "blog.swm.cc\/2012\/10\/06\/mut\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "316642996147871744",
  "geo" : { },
  "id_str" : "316643599515283456",
  "in_reply_to_user_id" : 15966431,
  "text" : "@cobyism you ever look into getting mutt going for your mail? http:\/\/t.co\/o1f5QrGbIg",
  "id" : 316643599515283456,
  "in_reply_to_status_id" : 316642996147871744,
  "created_at" : "2013-03-26 20:11:31 +0000",
  "in_reply_to_screen_name" : "cobyism",
  "in_reply_to_user_id_str" : "15966431",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Q84AE2gcVT",
      "expanded_url" : "http:\/\/instagram.com\/p\/XU42t6hXx-\/",
      "display_url" : "instagram.com\/p\/XU42t6hXx-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "316578013414293504",
  "text" : "Wear your fucking glasses you blind bastard!!!!!! http:\/\/t.co\/Q84AE2gcVT",
  "id" : 316578013414293504,
  "created_at" : "2013-03-26 15:50:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/GxoZaOOWqQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/XU3VKTBXwW\/",
      "display_url" : "instagram.com\/p\/XU3VKTBXwW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "316574745900511232",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel working hard :) http:\/\/t.co\/GxoZaOOWqQ",
  "id" : 316574745900511232,
  "created_at" : "2013-03-26 15:37:55 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetyour16yearoldself",
      "indices" : [ 17, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316509251029852161",
  "text" : "Value your hair. #tweetyour16yearoldself",
  "id" : 316509251029852161,
  "created_at" : "2013-03-26 11:17:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doover",
      "indices" : [ 42, 49 ]
    }, {
      "text" : "itsbeenalongday",
      "indices" : [ 50, 66 ]
    }, {
      "text" : "cryptictweet",
      "indices" : [ 67, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316320363871096833",
  "text" : "\u201Crnil uses rnil and github to build rnil\u201D #doover #itsbeenalongday #cryptictweet",
  "id" : 316320363871096833,
  "created_at" : "2013-03-25 22:47:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316320050036502528",
  "text" : "\u201Crnli uses rnli and github to build rnli\u201D",
  "id" : 316320050036502528,
  "created_at" : "2013-03-25 22:45:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316318019796226049",
  "text" : "Developing your own pet project is really a joy to do sometimes :) 22:37 and I am shutting the laptop down. Will take tomorrow night off.",
  "id" : 316318019796226049,
  "created_at" : "2013-03-25 22:37:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Swanstrom",
      "screen_name" : "swgoof",
      "indices" : [ 3, 10 ],
      "id_str" : "46895955",
      "id" : 46895955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoSQL",
      "indices" : [ 104, 110 ]
    }, {
      "text" : "GraphDB",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/LdPYW1qepH",
      "expanded_url" : "http:\/\/bit.ly\/10ph3Mq",
      "display_url" : "bit.ly\/10ph3Mq"
    } ]
  },
  "geo" : { },
  "id_str" : "316315345218568193",
  "text" : "RT @swgoof: No, not every database was created equal. Here\u2019s how they stand out  http:\/\/t.co\/LdPYW1qepH #NoSQL #GraphDB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoSQL",
        "indices" : [ 92, 98 ]
      }, {
        "text" : "GraphDB",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/LdPYW1qepH",
        "expanded_url" : "http:\/\/bit.ly\/10ph3Mq",
        "display_url" : "bit.ly\/10ph3Mq"
      } ]
    },
    "geo" : { },
    "id_str" : "316312102233055233",
    "text" : "No, not every database was created equal. Here\u2019s how they stand out  http:\/\/t.co\/LdPYW1qepH #NoSQL #GraphDB",
    "id" : 316312102233055233,
    "created_at" : "2013-03-25 22:14:16 +0000",
    "user" : {
      "name" : "Ryan Swanstrom",
      "screen_name" : "swgoof",
      "protected" : false,
      "id_str" : "46895955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1118013482\/IMG_9500_normal.JPG",
      "id" : 46895955,
      "verified" : false
    }
  },
  "id" : 316315345218568193,
  "created_at" : "2013-03-25 22:27:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316300530836185090",
  "text" : "I just add everything into my Gemfile and then as the project matures I prune it to make it as light as poss? Is this a wrong thing to do?",
  "id" : 316300530836185090,
  "created_at" : "2013-03-25 21:28:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316267545466392578",
  "geo" : { },
  "id_str" : "316274695920037888",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger dunno what is worse... .NET or PHP.... Hmmmmm probably .NET - but still - not great choices either way.",
  "id" : 316274695920037888,
  "in_reply_to_status_id" : 316267545466392578,
  "created_at" : "2013-03-25 19:45:38 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316231655679488000",
  "text" : "Starting to use Sublime Text 2 more these past few months. Need to document my processes soon as I have lots of \u2018em now.",
  "id" : 316231655679488000,
  "created_at" : "2013-03-25 16:54:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316229537727934465",
  "text" : "I\u2019m listening to Adele and I like it!!!!!! :D",
  "id" : 316229537727934465,
  "created_at" : "2013-03-25 16:46:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 3, 19 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/2YUs3GauCJ",
      "expanded_url" : "http:\/\/j.mp\/hMejpH",
      "display_url" : "j.mp\/hMejpH"
    } ]
  },
  "geo" : { },
  "id_str" : "315901472527245312",
  "text" : "RT @newsycombinator: Why Use Nginx? http:\/\/t.co\/2YUs3GauCJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.steer.me\" rel=\"nofollow\"\u003Enewsycombinator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/2YUs3GauCJ",
        "expanded_url" : "http:\/\/j.mp\/hMejpH",
        "display_url" : "j.mp\/hMejpH"
      } ]
    },
    "geo" : { },
    "id_str" : "315887009086455808",
    "text" : "Why Use Nginx? http:\/\/t.co\/2YUs3GauCJ",
    "id" : 315887009086455808,
    "created_at" : "2013-03-24 18:05:06 +0000",
    "user" : {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "protected" : false,
      "id_str" : "14335498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000017952599\/cf443a6da9a74e5c9c1fcddf422ebb0e_normal.png",
      "id" : 14335498,
      "verified" : false
    }
  },
  "id" : 315901472527245312,
  "created_at" : "2013-03-24 19:02:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Urban Anton",
      "screen_name" : "FUN",
      "indices" : [ 3, 7 ],
      "id_str" : "235555412",
      "id" : 235555412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315901199582900225",
  "text" : "RT @FUN: Homosexual behavior has been found in over 1,500 species. Homophobia is found in only one.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315551663257694209",
    "text" : "Homosexual behavior has been found in over 1,500 species. Homophobia is found in only one.",
    "id" : 315551663257694209,
    "created_at" : "2013-03-23 19:52:33 +0000",
    "user" : {
      "name" : "Just so you Know",
      "screen_name" : "Know",
      "protected" : false,
      "id_str" : "221452291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411110038\/a8b7eced4dc43374e7ae21112ff749b6_normal.jpeg",
      "id" : 221452291,
      "verified" : false
    }
  },
  "id" : 315901199582900225,
  "created_at" : "2013-03-24 19:01:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315119464897204224",
  "text" : "The Lisburn to Glenavy Road is really bad. Thought I was going to have to ditch the car at one stage. Fire on\u2026\u2026.",
  "id" : 315119464897204224,
  "created_at" : "2013-03-22 15:15:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/315098020922400768\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/ZlmE0sBM42",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF9z-wcCIAATqL-.jpg",
      "id_str" : "315098020930789376",
      "id" : 315098020930789376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF9z-wcCIAATqL-.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZlmE0sBM42"
    } ],
    "hashtags" : [ {
      "text" : "fuckoffitsspring",
      "indices" : [ 18, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315098020922400768",
  "text" : "Stuck in traffic. #fuckoffitsspring http:\/\/t.co\/ZlmE0sBM42",
  "id" : 315098020922400768,
  "created_at" : "2013-03-22 13:49:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315017433029160960",
  "text" : "Fuck. Right. Off. Snow.",
  "id" : 315017433029160960,
  "created_at" : "2013-03-22 08:29:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyounature",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314860373364862977",
  "text" : "I will be super pissed if it snows tonight - it\u2019s almost April FFS! #fuckyounature",
  "id" : 314860373364862977,
  "created_at" : "2013-03-21 22:05:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/314856810781749249\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/pHZZKqIZQQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF6YmepCMAAYsvY.png",
      "id_str" : "314856810790137856",
      "id" : 314856810790137856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF6YmepCMAAYsvY.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/pHZZKqIZQQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314856810781749249",
  "text" : "Fail - haven\u2019t a fuckin clue what that was for. I do remember thinking I must add a proper entry though later. http:\/\/t.co\/pHZZKqIZQQ",
  "id" : 314856810781749249,
  "created_at" : "2013-03-21 21:51:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314807637990572032",
  "geo" : { },
  "id_str" : "314821559095291905",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne :) Getting to play with lots if cool things :)",
  "id" : 314821559095291905,
  "in_reply_to_status_id" : 314807637990572032,
  "created_at" : "2013-03-21 19:31:23 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314797755916754945",
  "text" : "And with that being said - I'm away to annoy the brother figure :)",
  "id" : 314797755916754945,
  "created_at" : "2013-03-21 17:56:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314797687553798144",
  "text" : "The metrics in this job compared to any of my prev jobs is astounding. I'd love to say more but I can't Needless to say I am a happy geek :)",
  "id" : 314797687553798144,
  "created_at" : "2013-03-21 17:56:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "atlassian",
      "screen_name" : "atlassian",
      "indices" : [ 3, 13 ],
      "id_str" : "18060279",
      "id" : 18060279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/YvjtpBKECd",
      "expanded_url" : "http:\/\/ow.ly\/jhYky",
      "display_url" : "ow.ly\/jhYky"
    } ]
  },
  "geo" : { },
  "id_str" : "314773828603637760",
  "text" : "RT @atlassian: HipChat is now FREE for teams of 5 users or fewer! Click the link to learn more: http:\/\/t.co\/YvjtpBKECd and please RT!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/YvjtpBKECd",
        "expanded_url" : "http:\/\/ow.ly\/jhYky",
        "display_url" : "ow.ly\/jhYky"
      } ]
    },
    "geo" : { },
    "id_str" : "314772348597321728",
    "text" : "HipChat is now FREE for teams of 5 users or fewer! Click the link to learn more: http:\/\/t.co\/YvjtpBKECd and please RT!",
    "id" : 314772348597321728,
    "created_at" : "2013-03-21 16:15:50 +0000",
    "user" : {
      "name" : "atlassian",
      "screen_name" : "atlassian",
      "protected" : false,
      "id_str" : "18060279",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1825767682\/icon_normal.jpg",
      "id" : 18060279,
      "verified" : true
    }
  },
  "id" : 314773828603637760,
  "created_at" : "2013-03-21 16:21:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314758704077627392",
  "geo" : { },
  "id_str" : "314762848209354753",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit nice one :D",
  "id" : 314762848209354753,
  "in_reply_to_status_id" : 314758704077627392,
  "created_at" : "2013-03-21 15:38:05 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 0, 9 ],
      "id_str" : "95932190",
      "id" : 95932190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314758623773470720",
  "geo" : { },
  "id_str" : "314762683691986945",
  "in_reply_to_user_id" : 95932190,
  "text" : "@brrygrdn I like my stupidity out there for all to see :)",
  "id" : 314762683691986945,
  "in_reply_to_status_id" : 314758623773470720,
  "created_at" : "2013-03-21 15:37:26 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314735052237979648",
  "geo" : { },
  "id_str" : "314745882044145664",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll :( :( Ahh well I still cyber stalk you on FB so it feels like I am back in your bushes regardless :D",
  "id" : 314745882044145664,
  "in_reply_to_status_id" : 314735052237979648,
  "created_at" : "2013-03-21 14:30:40 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/314744441627873280\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/gsmfwXwKUK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF4yZu7CEAECJsL.png",
      "id_str" : "314744441636261889",
      "id" : 314744441636261889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF4yZu7CEAECJsL.png",
      "sizes" : [ {
        "h" : 162,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 92,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gsmfwXwKUK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314744441627873280",
  "text" : "Not my greatest or smartest moments in those 15minutes - coffee needed :D http:\/\/t.co\/gsmfwXwKUK",
  "id" : 314744441627873280,
  "created_at" : "2013-03-21 14:24:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314728686286942209",
  "geo" : { },
  "id_str" : "314729032409288705",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll I miss your tweets :(",
  "id" : 314729032409288705,
  "in_reply_to_status_id" : 314728686286942209,
  "created_at" : "2013-03-21 13:23:43 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 0, 13 ],
      "id_str" : "162449244",
      "id" : 162449244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314680167404539906",
  "geo" : { },
  "id_str" : "314681338454233090",
  "in_reply_to_user_id" : 162449244,
  "text" : "@justinMleary I will follow you back when you reach 101 - I aint helping you attain 100 followers cos I am a bitch ;)",
  "id" : 314681338454233090,
  "in_reply_to_status_id" : 314680167404539906,
  "created_at" : "2013-03-21 10:14:12 +0000",
  "in_reply_to_screen_name" : "justinMleary",
  "in_reply_to_user_id_str" : "162449244",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alyswoodward",
      "screen_name" : "alyswoodward",
      "indices" : [ 3, 16 ],
      "id_str" : "16143817",
      "id" : 16143817
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bigdata",
      "indices" : [ 59, 67 ]
    }, {
      "text" : "bigdata2013",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314680142813335552",
  "text" : "RT @alyswoodward: Bryan Keating connects Rovers Return and #bigdata - genius at #bigdata2013",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bigdata",
        "indices" : [ 41, 49 ]
      }, {
        "text" : "bigdata2013",
        "indices" : [ 62, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314673788979650561",
    "text" : "Bryan Keating connects Rovers Return and #bigdata - genius at #bigdata2013",
    "id" : 314673788979650561,
    "created_at" : "2013-03-21 09:44:12 +0000",
    "user" : {
      "name" : "alyswoodward",
      "screen_name" : "alyswoodward",
      "protected" : false,
      "id_str" : "16143817",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1167625849\/30bd06c9-a6a8-4ae0-8d44-5b25308845d3_normal.jpg",
      "id" : 16143817,
      "verified" : false
    }
  },
  "id" : 314680142813335552,
  "created_at" : "2013-03-21 10:09:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fixmyfamily",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314516221326397442",
  "text" : "Ohhhh this \u201CFix my family\u201D looks like comedy gold! #fixmyfamily",
  "id" : 314516221326397442,
  "created_at" : "2013-03-20 23:18:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314442117130878976",
  "text" : "Nice wee day playing with Groovy :) Days like this make you glad to be a developer...",
  "id" : 314442117130878976,
  "created_at" : "2013-03-20 18:23:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314359015054381056",
  "geo" : { },
  "id_str" : "314369027378147329",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I also had to sell the x shares back in 2003\u2026 I think I got 200quid net\u2026",
  "id" : 314369027378147329,
  "in_reply_to_status_id" : 314359015054381056,
  "created_at" : "2013-03-20 13:33:11 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314359015054381056",
  "geo" : { },
  "id_str" : "314368787602341888",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl in Aug 2000 I was given \u2018some\u2019 shares worth x and share \u2018options\u2019 - if they\u2019d have worked out it\u2019d been a 6 fig sum. They didn\u2019t :)",
  "id" : 314368787602341888,
  "in_reply_to_status_id" : 314359015054381056,
  "created_at" : "2013-03-20 13:32:14 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/s4QqySQjL9",
      "expanded_url" : "http:\/\/dot.com",
      "display_url" : "dot.com"
    } ]
  },
  "in_reply_to_status_id_str" : "314346584311746560",
  "geo" : { },
  "id_str" : "314355941069946880",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl :) As a former employee of a failed http:\/\/t.co\/s4QqySQjL9 I concur.. not that I am bitter :)",
  "id" : 314355941069946880,
  "in_reply_to_status_id" : 314346584311746560,
  "created_at" : "2013-03-20 12:41:11 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/314355222317252608\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/S2Ix8eszIc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFzQaMACQAABlfC.jpg",
      "id_str" : "314355222325641216",
      "id" : 314355222325641216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFzQaMACQAABlfC.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/S2Ix8eszIc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314355222317252608",
  "text" : "Still believe that 50mins on with 10mins off is the best pomodoro technique to have when in the office. http:\/\/t.co\/S2Ix8eszIc",
  "id" : 314355222317252608,
  "created_at" : "2013-03-20 12:38:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314326909540499456",
  "geo" : { },
  "id_str" : "314330020472573955",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger shows class that :) Your mind is telling you to stay away from shite like VS :)",
  "id" : 314330020472573955,
  "in_reply_to_status_id" : 314326909540499456,
  "created_at" : "2013-03-20 10:58:11 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314296174205091840",
  "text" : "Technically today is the first day of spring. FUCK. RIGHT. OFF.",
  "id" : 314296174205091840,
  "created_at" : "2013-03-20 08:43:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314153120852766721",
  "text" : "So... that Bill Roache sure comes across like a cunt.....",
  "id" : 314153120852766721,
  "created_at" : "2013-03-19 23:15:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314114085769863168",
  "geo" : { },
  "id_str" : "314114599723089920",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger if you wrote it more than three months ago then that is a good sign\u2026 If it was less than that then - well enjoy :)",
  "id" : 314114599723089920,
  "in_reply_to_status_id" : 314114085769863168,
  "created_at" : "2013-03-19 20:42:11 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan North",
      "screen_name" : "tastapod",
      "indices" : [ 20, 29 ],
      "id_str" : "14526430",
      "id" : 14526430
    }, {
      "name" : "Bash!",
      "screen_name" : "devbash",
      "indices" : [ 35, 43 ],
      "id_str" : "454193975",
      "id" : 454193975
    }, {
      "name" : "Instil",
      "screen_name" : "instil",
      "indices" : [ 85, 92 ],
      "id_str" : "804212370",
      "id" : 804212370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/VNhqMmuuSn",
      "expanded_url" : "http:\/\/bash6.eventbrite.com",
      "display_url" : "bash6.eventbrite.com"
    } ]
  },
  "geo" : { },
  "id_str" : "314110668762664960",
  "text" : "Brilliant talk from @tastapod from @devbash - http:\/\/t.co\/VNhqMmuuSn - thanks to the @instil for putting it on..",
  "id" : 314110668762664960,
  "created_at" : "2013-03-19 20:26:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eventbrite",
      "screen_name" : "eventbrite",
      "indices" : [ 97, 108 ],
      "id_str" : "5625972",
      "id" : 5625972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/l6L24AoHmx",
      "expanded_url" : "http:\/\/bash6-estw.eventbrite.com",
      "display_url" : "bash6-estw.eventbrite.com"
    } ]
  },
  "geo" : { },
  "id_str" : "314026125917581313",
  "text" : "Check out \"Building Fast, Scalable Network Applications with Node.js\" http:\/\/t.co\/l6L24AoHmx via @eventbrite",
  "id" : 314026125917581313,
  "created_at" : "2013-03-19 14:50:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Mone OBE",
      "screen_name" : "MichelleMone",
      "indices" : [ 3, 16 ],
      "id_str" : "58432995",
      "id" : 58432995
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 30, 36 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Michelle Mone OBE",
      "screen_name" : "MichelleMone",
      "indices" : [ 38, 51 ],
      "id_str" : "58432995",
      "id" : 58432995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/zP9bKB5vbp",
      "expanded_url" : "http:\/\/yfrog.com\/gykbpyrgj",
      "display_url" : "yfrog.com\/gykbpyrgj"
    } ]
  },
  "geo" : { },
  "id_str" : "314004317147381761",
  "text" : "RT @MichelleMone: I use both \"@swmcc: @MichelleMone Dunno why but I am gutted you use a blackberry :( http:\/\/t.co\/zP9bKB5vbp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 12, 18 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Michelle Mone OBE",
        "screen_name" : "MichelleMone",
        "indices" : [ 20, 33 ],
        "id_str" : "58432995",
        "id" : 58432995
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/zP9bKB5vbp",
        "expanded_url" : "http:\/\/yfrog.com\/gykbpyrgj",
        "display_url" : "yfrog.com\/gykbpyrgj"
      } ]
    },
    "geo" : { },
    "id_str" : "314002428171284480",
    "text" : "I use both \"@swmcc: @MichelleMone Dunno why but I am gutted you use a blackberry :( http:\/\/t.co\/zP9bKB5vbp",
    "id" : 314002428171284480,
    "created_at" : "2013-03-19 13:16:27 +0000",
    "user" : {
      "name" : "Michelle Mone OBE",
      "screen_name" : "MichelleMone",
      "protected" : false,
      "id_str" : "58432995",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000461481062\/e9ceeff82d92c97817c22ebe186dd022_normal.jpeg",
      "id" : 58432995,
      "verified" : true
    }
  },
  "id" : 314004317147381761,
  "created_at" : "2013-03-19 13:23:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Mone OBE",
      "screen_name" : "MichelleMone",
      "indices" : [ 0, 13 ],
      "id_str" : "58432995",
      "id" : 58432995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314002428171284480",
  "geo" : { },
  "id_str" : "314004295345393664",
  "in_reply_to_user_id" : 58432995,
  "text" : "@MichelleMone faith restored :)",
  "id" : 314004295345393664,
  "in_reply_to_status_id" : 314002428171284480,
  "created_at" : "2013-03-19 13:23:52 +0000",
  "in_reply_to_screen_name" : "MichelleMone",
  "in_reply_to_user_id_str" : "58432995",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Mone OBE",
      "screen_name" : "MichelleMone",
      "indices" : [ 0, 13 ],
      "id_str" : "58432995",
      "id" : 58432995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314001372364275712",
  "geo" : { },
  "id_str" : "314001703198404608",
  "in_reply_to_user_id" : 58432995,
  "text" : "@MichelleMone Dunno why but I am gutted you use a blackberry :( Thought you'd be an iPhone sortta person...",
  "id" : 314001703198404608,
  "in_reply_to_status_id" : 314001372364275712,
  "created_at" : "2013-03-19 13:13:34 +0000",
  "in_reply_to_screen_name" : "MichelleMone",
  "in_reply_to_user_id_str" : "58432995",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cabalOH",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313978363981217792",
  "text" : "OH: \"I lack the enzyme that allows me to digest this particular type of shit.\" #cabalOH :)",
  "id" : 313978363981217792,
  "created_at" : "2013-03-19 11:40:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313977662009909248",
  "text" : "RT @szlwzl: Just got endorsed for Knitwear on Linked-In :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313975588719325184",
    "text" : "Just got endorsed for Knitwear on Linked-In :)",
    "id" : 313975588719325184,
    "created_at" : "2013-03-19 11:29:48 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 313977662009909248,
  "created_at" : "2013-03-19 11:38:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313966531988037632",
  "text" : "Something about listening to \"He's a Pirate\" that makes me code like a motherfucker!!! Dunno why! Klaus Badelt \u2013 He's a Pirate",
  "id" : 313966531988037632,
  "created_at" : "2013-03-19 10:53:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313961150901534720",
  "text" : "There is a certain blog I shouldn't go... But I do - everyday without fail.. And every time I want to bang my head against a wall. Rosie :D",
  "id" : 313961150901534720,
  "created_at" : "2013-03-19 10:32:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/313959192081866752\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/fIFJlUDQ06",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFtoOMZCIAA2NGI.png",
      "id_str" : "313959192086061056",
      "id" : 313959192086061056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFtoOMZCIAA2NGI.png",
      "sizes" : [ {
        "h" : 185,
        "resize" : "fit",
        "w" : 655
      }, {
        "h" : 96,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 655
      } ],
      "display_url" : "pic.twitter.com\/fIFJlUDQ06"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313959192081866752",
  "text" : "So Simon endorsed me on Linkedin again... Hmmmmm :) :) http:\/\/t.co\/fIFJlUDQ06",
  "id" : 313959192081866752,
  "created_at" : "2013-03-19 10:24:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313787963769253888",
  "geo" : { },
  "id_str" : "313788250525421568",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin original or re-imagined? Both are good - but the original is far far superior IMVHO.",
  "id" : 313788250525421568,
  "in_reply_to_status_id" : 313787963769253888,
  "created_at" : "2013-03-18 23:05:23 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "atlassian",
      "screen_name" : "atlassian",
      "indices" : [ 3, 13 ],
      "id_str" : "18060279",
      "id" : 18060279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/kP2hIRjPqS",
      "expanded_url" : "http:\/\/ow.ly\/jb0kH",
      "display_url" : "ow.ly\/jb0kH"
    } ]
  },
  "geo" : { },
  "id_str" : "313784897640738818",
  "text" : "RT @atlassian: New Blog! Learn what you need to know about the new Git 1.8.2 release: http:\/\/t.co\/kP2hIRjPqS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/kP2hIRjPqS",
        "expanded_url" : "http:\/\/ow.ly\/jb0kH",
        "display_url" : "ow.ly\/jb0kH"
      } ]
    },
    "geo" : { },
    "id_str" : "313729982214074369",
    "text" : "New Blog! Learn what you need to know about the new Git 1.8.2 release: http:\/\/t.co\/kP2hIRjPqS",
    "id" : 313729982214074369,
    "created_at" : "2013-03-18 19:13:51 +0000",
    "user" : {
      "name" : "atlassian",
      "screen_name" : "atlassian",
      "protected" : false,
      "id_str" : "18060279",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1825767682\/icon_normal.jpg",
      "id" : 18060279,
      "verified" : true
    }
  },
  "id" : 313784897640738818,
  "created_at" : "2013-03-18 22:52:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313747792017362944",
  "text" : "Right - a joke is a joke.. Time to get your ass off the pillow nature and WARM THE FUCK UP. It is after St Paddys so I want heat!! NOW!!",
  "id" : 313747792017362944,
  "created_at" : "2013-03-18 20:24:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313615278456053760",
  "geo" : { },
  "id_str" : "313618188661321728",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit ahhh well. Sure we all get fucker projects like that now and again :) You back home then? Heading to refresh tomorrow?",
  "id" : 313618188661321728,
  "in_reply_to_status_id" : 313615278456053760,
  "created_at" : "2013-03-18 11:49:37 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    }, {
      "name" : "Paul Ferguson Palmer",
      "screen_name" : "themoononastick",
      "indices" : [ 13, 29 ],
      "id_str" : "14390868",
      "id" : 14390868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313617783088873472",
  "geo" : { },
  "id_str" : "313617993550688258",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger @themoononastick I don\u2019t mind working more hours. But that was just a death march for no reason. Finished me as well.",
  "id" : 313617993550688258,
  "in_reply_to_status_id" : 313617783088873472,
  "created_at" : "2013-03-18 11:48:51 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313588123227529216",
  "text" : "I rememer going into work on the Friday and not coming out again until the Tuesday.",
  "id" : 313588123227529216,
  "created_at" : "2013-03-18 09:50:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 26, 32 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Paul Ferguson Palmer",
      "screen_name" : "themoononastick",
      "indices" : [ 37, 53 ],
      "id_str" : "14390868",
      "id" : 14390868
    }, {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 69, 81 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313587580786589697",
  "geo" : { },
  "id_str" : "313587843857526784",
  "in_reply_to_user_id" : 804717,
  "text" : "Have to point out that me @swmcc and @themoononastick were sober and @angryjogger took to drinking buckfast :) Stupid death march project.",
  "id" : 313587843857526784,
  "in_reply_to_status_id" : 313587580786589697,
  "created_at" : "2013-03-18 09:49:02 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ferguson Palmer",
      "screen_name" : "themoononastick",
      "indices" : [ 50, 66 ],
      "id_str" : "14390868",
      "id" : 14390868
    }, {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 94, 106 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313587580786589697",
  "text" : "Just celebrating the 4 year anniversary of me and @themoononastick doing a 120+hour week with @angryjogger getting drunk while coding. :)",
  "id" : 313587580786589697,
  "created_at" : "2013-03-18 09:48:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313257909314269185",
  "geo" : { },
  "id_str" : "313584936563134464",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger that's brilliant Matt!!! Very inspiring...",
  "id" : 313584936563134464,
  "in_reply_to_status_id" : 313257909314269185,
  "created_at" : "2013-03-18 09:37:29 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    }, {
      "name" : "The Ormeau Road",
      "screen_name" : "TheOrmeauRoad",
      "indices" : [ 13, 27 ],
      "id_str" : "542875998",
      "id" : 542875998
    }, {
      "name" : "Tom McShane",
      "screen_name" : "tommcshanemusic",
      "indices" : [ 28, 44 ],
      "id_str" : "53635324",
      "id" : 53635324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313403409615167488",
  "geo" : { },
  "id_str" : "313584602792996864",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger @TheOrmeauRoad @tommcshanemusic that will never happen. good shop but by fuck it is pricey.....",
  "id" : 313584602792996864,
  "in_reply_to_status_id" : 313403409615167488,
  "created_at" : "2013-03-18 09:36:10 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313402133322010624",
  "geo" : { },
  "id_str" : "313403202802429953",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl my sunday night winddown is father ted on e4... Can't beat it.",
  "id" : 313403202802429953,
  "in_reply_to_status_id" : 313402133322010624,
  "created_at" : "2013-03-17 21:35:20 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/UhqkHySyI0",
      "expanded_url" : "https:\/\/gist.github.com\/substack\/5075355",
      "display_url" : "gist.github.com\/substack\/50753\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313384075794722816",
  "text" : "I love this - https:\/\/t.co\/UhqkHySyI0",
  "id" : 313384075794722816,
  "created_at" : "2013-03-17 20:19:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 3, 10 ],
      "id_str" : "285766850",
      "id" : 285766850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodeup",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/chzpjlIvXe",
      "expanded_url" : "http:\/\/nodeup.com",
      "display_url" : "nodeup.com"
    } ]
  },
  "geo" : { },
  "id_str" : "313382820246597633",
  "text" : "RT @NodeUp: We will be going live soon. Join us in #nodeup on freenode and wait for the stream on http:\/\/t.co\/chzpjlIvXe.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodeup",
        "indices" : [ 39, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/chzpjlIvXe",
        "expanded_url" : "http:\/\/nodeup.com",
        "display_url" : "nodeup.com"
      } ]
    },
    "geo" : { },
    "id_str" : "313381899789815808",
    "text" : "We will be going live soon. Join us in #nodeup on freenode and wait for the stream on http:\/\/t.co\/chzpjlIvXe.",
    "id" : 313381899789815808,
    "created_at" : "2013-03-17 20:10:41 +0000",
    "user" : {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "protected" : false,
      "id_str" : "285766850",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1675860861\/logo2_normal.jpg",
      "id" : 285766850,
      "verified" : false
    }
  },
  "id" : 313382820246597633,
  "created_at" : "2013-03-17 20:14:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Brona Whittaker",
      "screen_name" : "Bzlwzl",
      "indices" : [ 8, 15 ],
      "id_str" : "30839162",
      "id" : 30839162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313282165133701121",
  "geo" : { },
  "id_str" : "313296299451637761",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @Bzlwzl Amazing.. Most famous person I got to reply to me was Andrew Neil.. :)",
  "id" : 313296299451637761,
  "in_reply_to_status_id" : 313282165133701121,
  "created_at" : "2013-03-17 14:30:33 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313050181077700608",
  "text" : "Usually on St Patricks day I hunt a hun and try and to start (wrestle) with my lawnmower... But it is snowing. So fuck it all. I hate snow!",
  "id" : 313050181077700608,
  "created_at" : "2013-03-16 22:12:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GQlp7ZsUey",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=AKC7Oz6ZrRU",
      "display_url" : "youtube.com\/watch?v=AKC7Oz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313032936104538113",
  "text" : "http:\/\/t.co\/GQlp7ZsUey 23 years ago!!!!! And I was even too old for it then!",
  "id" : 313032936104538113,
  "created_at" : "2013-03-16 21:04:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cat",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/OslYoHNqw9",
      "expanded_url" : "http:\/\/instagr.am\/p\/W69L2fBXxf\/",
      "display_url" : "instagr.am\/p\/W69L2fBXxf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "312928532475039745",
  "text" : "Poor poobie..... Almost 16 and is enjoying retirement. #cat http:\/\/t.co\/OslYoHNqw9",
  "id" : 312928532475039745,
  "created_at" : "2013-03-16 14:09:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/NXrfIcKazR",
      "expanded_url" : "http:\/\/instagr.am\/p\/W4_T3ehX0x\/",
      "display_url" : "instagr.am\/p\/W4_T3ehX0x\/"
    } ]
  },
  "geo" : { },
  "id_str" : "312651805425295361",
  "text" : "Coffee this is milk... Milk this is coffee. I think you'll two will get on great. You probably have a\u2026 http:\/\/t.co\/NXrfIcKazR",
  "id" : 312651805425295361,
  "created_at" : "2013-03-15 19:49:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "huntahunday",
      "indices" : [ 93, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312633512064843776",
  "text" : "\/me calls it a week... 3 day bank holiday weekend (if you are Irish)... Enjoy it fuckers!!!! #huntahunday",
  "id" : 312633512064843776,
  "created_at" : "2013-03-15 18:36:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.D. Peterson",
      "screen_name" : "jd_peterson",
      "indices" : [ 3, 15 ],
      "id_str" : "16676790",
      "id" : 16676790
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greatc",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/WFtrcQ3aNB",
      "expanded_url" : "http:\/\/newrelic.com\/mobile-monitoring",
      "display_url" : "newrelic.com\/mobile-monitor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312481862067052544",
  "text" : "RT @jd_peterson: New Relic continuing to crush it.  Awesome new platform for monitoring your mobile apps http:\/\/t.co\/WFtrcQ3aNB  #greatc ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "greatcompany",
        "indices" : [ 112, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/WFtrcQ3aNB",
        "expanded_url" : "http:\/\/newrelic.com\/mobile-monitoring",
        "display_url" : "newrelic.com\/mobile-monitor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312333356903849984",
    "text" : "New Relic continuing to crush it.  Awesome new platform for monitoring your mobile apps http:\/\/t.co\/WFtrcQ3aNB  #greatcompany",
    "id" : 312333356903849984,
    "created_at" : "2013-03-14 22:44:09 +0000",
    "user" : {
      "name" : "J.D. Peterson",
      "screen_name" : "jd_peterson",
      "protected" : false,
      "id_str" : "16676790",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3060485537\/0ed24f308b3e3ba2f94ba2509503d7e8_normal.jpeg",
      "id" : 16676790,
      "verified" : false
    }
  },
  "id" : 312481862067052544,
  "created_at" : "2013-03-15 08:34:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "indices" : [ 3, 11 ],
      "id_str" : "14173315",
      "id" : 14173315
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NBCPope",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/oEiR2QHAY9",
      "expanded_url" : "http:\/\/instagr.am\/p\/W2FCksR9-e\/",
      "display_url" : "instagr.am\/p\/W2FCksR9-e\/"
    } ]
  },
  "geo" : { },
  "id_str" : "312264641558499329",
  "text" : "RT @NBCNews: What a difference 8 years makes. St. Peter's Square in 2005 vs. 2013. #NBCPope http:\/\/t.co\/oEiR2QHAY9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NBCPope",
        "indices" : [ 70, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/oEiR2QHAY9",
        "expanded_url" : "http:\/\/instagr.am\/p\/W2FCksR9-e\/",
        "display_url" : "instagr.am\/p\/W2FCksR9-e\/"
      } ]
    },
    "geo" : { },
    "id_str" : "312242711338033153",
    "text" : "What a difference 8 years makes. St. Peter's Square in 2005 vs. 2013. #NBCPope http:\/\/t.co\/oEiR2QHAY9",
    "id" : 312242711338033153,
    "created_at" : "2013-03-14 16:43:58 +0000",
    "user" : {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "protected" : false,
      "id_str" : "14173315",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000521861809\/871433564230dfb44c737174d88eecfe_normal.png",
      "id" : 14173315,
      "verified" : true
    }
  },
  "id" : 312264641558499329,
  "created_at" : "2013-03-14 18:11:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312208436504952833",
  "text" : "WFH: Stupid interwebs being down...",
  "id" : 312208436504952833,
  "created_at" : "2013-03-14 14:27:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Halstead",
      "screen_name" : "nik",
      "indices" : [ 3, 7 ],
      "id_str" : "3364401",
      "id" : 3364401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312161233098911744",
  "text" : "RT @nik: I bet the whole company on the fact that Twitter would replace RSS 4 years ago (little known fact we started life as an RSS Reader)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312130152828112896",
    "text" : "I bet the whole company on the fact that Twitter would replace RSS 4 years ago (little known fact we started life as an RSS Reader)",
    "id" : 312130152828112896,
    "created_at" : "2013-03-14 09:16:42 +0000",
    "user" : {
      "name" : "Nick Halstead",
      "screen_name" : "nik",
      "protected" : false,
      "id_str" : "3364401",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1823229022\/nick2png_normal.png",
      "id" : 3364401,
      "verified" : false
    }
  },
  "id" : 312161233098911744,
  "created_at" : "2013-03-14 11:20:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 3, 10 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/WQeH0y85Cs",
      "expanded_url" : "http:\/\/www.newsbeuter.org\/",
      "display_url" : "newsbeuter.org"
    } ]
  },
  "geo" : { },
  "id_str" : "312158453353312257",
  "text" : "RT @srushe: Anyone looking for a text-based reader could try http:\/\/t.co\/WQeH0y85Cs. I've been using it happily for a while, with Dropbo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/WQeH0y85Cs",
        "expanded_url" : "http:\/\/www.newsbeuter.org\/",
        "display_url" : "newsbeuter.org"
      } ]
    },
    "geo" : { },
    "id_str" : "312157019098447872",
    "text" : "Anyone looking for a text-based reader could try http:\/\/t.co\/WQeH0y85Cs. I've been using it happily for a while, with Dropbox for syncing.",
    "id" : 312157019098447872,
    "created_at" : "2013-03-14 11:03:27 +0000",
    "user" : {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "protected" : false,
      "id_str" : "761761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414429155\/DangerMan_normal.jpg",
      "id" : 761761,
      "verified" : false
    }
  },
  "id" : 312158453353312257,
  "created_at" : "2013-03-14 11:09:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 33, 46 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311876322152550400",
  "text" : "Playing TopGun in the office and @Paul_Moffett is doing nothing but bitching about it... It is an awesome album!!!",
  "id" : 311876322152550400,
  "created_at" : "2013-03-13 16:28:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "indices" : [ 0, 7 ],
      "id_str" : "14060295",
      "id" : 14060295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311844743464247296",
  "geo" : { },
  "id_str" : "311847206615392256",
  "in_reply_to_user_id" : 14060295,
  "text" : "@cimota if you are in a giving mood I have an idea for a business.. indexes info from websites\u2026 could be a big money spinner.",
  "id" : 311847206615392256,
  "in_reply_to_status_id" : 311844743464247296,
  "created_at" : "2013-03-13 14:32:22 +0000",
  "in_reply_to_screen_name" : "cimota",
  "in_reply_to_user_id_str" : "14060295",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Artdigiland",
      "screen_name" : "artdigiland",
      "indices" : [ 3, 15 ],
      "id_str" : "438693642",
      "id" : 438693642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/7FBYQYDaMT",
      "expanded_url" : "http:\/\/fb.me\/Mcj6h51W",
      "display_url" : "fb.me\/Mcj6h51W"
    } ]
  },
  "geo" : { },
  "id_str" : "311788083509084160",
  "text" : "RT @artdigiland: Aurelien\nMan Ray \n1944 http:\/\/t.co\/7FBYQYDaMT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/7FBYQYDaMT",
        "expanded_url" : "http:\/\/fb.me\/Mcj6h51W",
        "display_url" : "fb.me\/Mcj6h51W"
      } ]
    },
    "geo" : { },
    "id_str" : "311783637219696640",
    "text" : "Aurelien\nMan Ray \n1944 http:\/\/t.co\/7FBYQYDaMT",
    "id" : 311783637219696640,
    "created_at" : "2013-03-13 10:19:46 +0000",
    "user" : {
      "name" : "Artdigiland",
      "screen_name" : "artdigiland",
      "protected" : false,
      "id_str" : "438693642",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2271183320\/0msqvueyz9r30k5sm8e4_normal.jpeg",
      "id" : 438693642,
      "verified" : false
    }
  },
  "id" : 311788083509084160,
  "created_at" : "2013-03-13 10:37:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 39, 47 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311787064028954624",
  "text" : "The Glenavy to Lisburn Road that is as @jbrevel got confused.",
  "id" : 311787064028954624,
  "created_at" : "2013-03-13 10:33:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311785652104593409",
  "text" : "Diversion on the Lisburn Road.... Got lost - took me to get to Ballynahinch to work out where the fuck I was..... Grrrrrrrrrrrrr",
  "id" : 311785652104593409,
  "created_at" : "2013-03-13 10:27:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311756882098397185",
  "geo" : { },
  "id_str" : "311761013596909568",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger where you working now?",
  "id" : 311761013596909568,
  "in_reply_to_status_id" : 311756882098397185,
  "created_at" : "2013-03-13 08:49:52 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 12, 24 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 82, 90 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311616287254130689",
  "geo" : { },
  "id_str" : "311752552683294720",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @ryancunning I told the fellas in here about the sex face cake. Think @jbrevel still has nightmares :)",
  "id" : 311752552683294720,
  "in_reply_to_status_id" : 311616287254130689,
  "created_at" : "2013-03-13 08:16:15 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 3, 14 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 16, 28 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 29, 35 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311748793676726272",
  "text" : "RT @Alana_Doll: @ryancunning @swmcc ah the sex face cake! My finest work yet!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan Cunning",
        "screen_name" : "ryancunning",
        "indices" : [ 0, 12 ],
        "id_str" : "226910307",
        "id" : 226910307
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 13, 19 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "311615870969466880",
    "geo" : { },
    "id_str" : "311616287254130689",
    "in_reply_to_user_id" : 226910307,
    "text" : "@ryancunning @swmcc ah the sex face cake! My finest work yet!",
    "id" : 311616287254130689,
    "in_reply_to_status_id" : 311615870969466880,
    "created_at" : "2013-03-12 23:14:47 +0000",
    "in_reply_to_screen_name" : "ryancunning",
    "in_reply_to_user_id_str" : "226910307",
    "user" : {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "protected" : false,
      "id_str" : "67130324",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3578323065\/bb177ebc2b37f1d2ee6f3eec1af258d0_normal.jpeg",
      "id" : 67130324,
      "verified" : false
    }
  },
  "id" : 311748793676726272,
  "created_at" : "2013-03-13 08:01:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Jensen",
      "screen_name" : "djensen47",
      "indices" : [ 3, 13 ],
      "id_str" : "16254468",
      "id" : 16254468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/MhoaJrzyoA",
      "expanded_url" : "http:\/\/j.mp\/Yj1pk0",
      "display_url" : "j.mp\/Yj1pk0"
    } ]
  },
  "geo" : { },
  "id_str" : "311596263323873280",
  "text" : "RT @djensen47: Attention CTOs: Culture matters http:\/\/t.co\/MhoaJrzyoA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/MhoaJrzyoA",
        "expanded_url" : "http:\/\/j.mp\/Yj1pk0",
        "display_url" : "j.mp\/Yj1pk0"
      } ]
    },
    "geo" : { },
    "id_str" : "311594231963725824",
    "text" : "Attention CTOs: Culture matters http:\/\/t.co\/MhoaJrzyoA",
    "id" : 311594231963725824,
    "created_at" : "2013-03-12 21:47:08 +0000",
    "user" : {
      "name" : "Dave Jensen",
      "screen_name" : "djensen47",
      "protected" : false,
      "id_str" : "16254468",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3122247357\/36fee7228d8a3d69b3574cd9e4650751_normal.jpeg",
      "id" : 16254468,
      "verified" : false
    }
  },
  "id" : 311596263323873280,
  "created_at" : "2013-03-12 21:55:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311591654240964609",
  "text" : "Wordpress is an awful *awful* *AWFUL* bit of kit. It does what it does well but by fuck is it a nasty nasty bit of software.",
  "id" : 311591654240964609,
  "created_at" : "2013-03-12 21:36:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311518396716044288",
  "geo" : { },
  "id_str" : "311525204859957248",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 why so?",
  "id" : 311525204859957248,
  "in_reply_to_status_id" : 311518396716044288,
  "created_at" : "2013-03-12 17:12:51 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Planet Clojure",
      "screen_name" : "planetclojure",
      "indices" : [ 3, 17 ],
      "id_str" : "146070339",
      "id" : 146070339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/ipIJQVXduZ",
      "expanded_url" : "http:\/\/dlvr.it\/341V9W",
      "display_url" : "dlvr.it\/341V9W"
    } ]
  },
  "geo" : { },
  "id_str" : "311426285178077184",
  "text" : "RT @planetclojure: Sinking Data to Neo4j from Hadoop with Cascading http:\/\/t.co\/ipIJQVXduZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/ipIJQVXduZ",
        "expanded_url" : "http:\/\/dlvr.it\/341V9W",
        "display_url" : "dlvr.it\/341V9W"
      } ]
    },
    "geo" : { },
    "id_str" : "311137194024792066",
    "text" : "Sinking Data to Neo4j from Hadoop with Cascading http:\/\/t.co\/ipIJQVXduZ",
    "id" : 311137194024792066,
    "created_at" : "2013-03-11 15:31:02 +0000",
    "user" : {
      "name" : "Planet Clojure",
      "screen_name" : "planetclojure",
      "protected" : false,
      "id_str" : "146070339",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/988729402\/Clojure_300x300_normal.png",
      "id" : 146070339,
      "verified" : false
    }
  },
  "id" : 311426285178077184,
  "created_at" : "2013-03-12 10:39:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311252722135478273",
  "geo" : { },
  "id_str" : "311395408276500480",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning what you on about? :)",
  "id" : 311395408276500480,
  "in_reply_to_status_id" : 311252722135478273,
  "created_at" : "2013-03-12 08:37:05 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 3, 10 ],
      "id_str" : "17843859",
      "id" : 17843859
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 85, 101 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/FoS1hyaUk2",
      "expanded_url" : "http:\/\/wp.me\/p2PtEp-2D",
      "display_url" : "wp.me\/p2PtEp-2D"
    } ]
  },
  "geo" : { },
  "id_str" : "311201406193393664",
  "text" : "RT @rtweed: Introducing EWD's new Real-time Web Framework http:\/\/t.co\/FoS1hyaUk2 via @wordpressdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 73, 89 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/FoS1hyaUk2",
        "expanded_url" : "http:\/\/wp.me\/p2PtEp-2D",
        "display_url" : "wp.me\/p2PtEp-2D"
      } ]
    },
    "geo" : { },
    "id_str" : "311201035391733760",
    "text" : "Introducing EWD's new Real-time Web Framework http:\/\/t.co\/FoS1hyaUk2 via @wordpressdotcom",
    "id" : 311201035391733760,
    "created_at" : "2013-03-11 19:44:43 +0000",
    "user" : {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "protected" : false,
      "id_str" : "17843859",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1398354510\/me_normal.png",
      "id" : 17843859,
      "verified" : false
    }
  },
  "id" : 311201406193393664,
  "created_at" : "2013-03-11 19:46:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311183838216855553",
  "text" : "That moment you remember you left your laptop bag at home.... and you spent the last 20 fucking minutes looking for it in the office!",
  "id" : 311183838216855553,
  "created_at" : "2013-03-11 18:36:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DataSift Developer",
      "screen_name" : "DataSiftDev",
      "indices" : [ 3, 15 ],
      "id_str" : "165781228",
      "id" : 165781228
    }, {
      "name" : "Jacek",
      "screen_name" : "jacek",
      "indices" : [ 76, 82 ],
      "id_str" : "2680071",
      "id" : 2680071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/2Pv6RoRNfw",
      "expanded_url" : "http:\/\/dsft.ly\/12IxXcs",
      "display_url" : "dsft.ly\/12IxXcs"
    } ]
  },
  "geo" : { },
  "id_str" : "311172474312204288",
  "text" : "RT @DataSiftDev: Writing CSDL in Vim: New DataSift Engineering blog post by @jacek http:\/\/t.co\/2Pv6RoRNfw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jacek",
        "screen_name" : "jacek",
        "indices" : [ 59, 65 ],
        "id_str" : "2680071",
        "id" : 2680071
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/2Pv6RoRNfw",
        "expanded_url" : "http:\/\/dsft.ly\/12IxXcs",
        "display_url" : "dsft.ly\/12IxXcs"
      } ]
    },
    "geo" : { },
    "id_str" : "311169730453045248",
    "text" : "Writing CSDL in Vim: New DataSift Engineering blog post by @jacek http:\/\/t.co\/2Pv6RoRNfw",
    "id" : 311169730453045248,
    "created_at" : "2013-03-11 17:40:19 +0000",
    "user" : {
      "name" : "DataSift Developer",
      "screen_name" : "DataSiftDev",
      "protected" : false,
      "id_str" : "165781228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1521862196\/datasift-twitter-logo_normal.jpg",
      "id" : 165781228,
      "verified" : false
    }
  },
  "id" : 311172474312204288,
  "created_at" : "2013-03-11 17:51:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Push Technology",
      "screen_name" : "push_technology",
      "indices" : [ 3, 19 ],
      "id_str" : "262711334",
      "id" : 262711334
    }, {
      "name" : "Business Innovation",
      "screen_name" : "Biz_Innovations",
      "indices" : [ 24, 40 ],
      "id_str" : "491462544",
      "id" : 491462544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigData",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311073370533928960",
  "text" : "RT @push_technology: RT @biz_innovations: #BigData is growing fast! Every 60 sec 600 blog posts are published and 34,000 tweets are sent ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Business Innovation",
        "screen_name" : "Biz_Innovations",
        "indices" : [ 3, 19 ],
        "id_str" : "491462544",
        "id" : 491462544
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Biz_Innovations\/status\/310842512766017537\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/LLaOO07t4o",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFBVnlNCIAE_fAm.png",
        "id_str" : "310842512778600449",
        "id" : 310842512778600449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFBVnlNCIAE_fAm.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 401
        } ],
        "display_url" : "pic.twitter.com\/LLaOO07t4o"
      } ],
      "hashtags" : [ {
        "text" : "BigData",
        "indices" : [ 21, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311072852893896705",
    "text" : "RT @biz_innovations: #BigData is growing fast! Every 60 sec 600 blog posts are published and 34,000 tweets are sent. http:\/\/t.co\/LLaOO07t4o",
    "id" : 311072852893896705,
    "created_at" : "2013-03-11 11:15:22 +0000",
    "user" : {
      "name" : "Push Technology",
      "screen_name" : "push_technology",
      "protected" : false,
      "id_str" : "262711334",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2165535851\/Push-Square_normal.jpg",
      "id" : 262711334,
      "verified" : false
    }
  },
  "id" : 311073370533928960,
  "created_at" : "2013-03-11 11:17:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311058152537870338",
  "text" : "OH: \u201CI wake up with a snake between my legs every morning. I sometimes strangle it but it just spits at me!\u201D",
  "id" : 311058152537870338,
  "created_at" : "2013-03-11 10:16:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Potter",
      "screen_name" : "tejcore",
      "indices" : [ 3, 11 ],
      "id_str" : "14474034",
      "id" : 14474034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310873935749201921",
  "text" : "RT @tejcore: Monday is the enemy of the weekend.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310873248126615552",
    "text" : "Monday is the enemy of the weekend.",
    "id" : 310873248126615552,
    "created_at" : "2013-03-10 22:02:12 +0000",
    "user" : {
      "name" : "Tim Potter",
      "screen_name" : "tejcore",
      "protected" : false,
      "id_str" : "14474034",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1359839077\/robotvatar_normal.png",
      "id" : 14474034,
      "verified" : false
    }
  },
  "id" : 310873935749201921,
  "created_at" : "2013-03-10 22:04:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "indices" : [ 3, 12 ],
      "id_str" : "14278978",
      "id" : 14278978
    }, {
      "name" : "intu",
      "screen_name" : "intu",
      "indices" : [ 131, 136 ],
      "id_str" : "1159812348",
      "id" : 1159812348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310833062340620290",
  "text" : "RT @ericries: \"If you can make experimentation super cheap and fast, then you can run them both and avoid arguments over opinions\" @Intu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intuit Inc. ",
        "screen_name" : "IntuitInc",
        "indices" : [ 117, 127 ],
        "id_str" : "76424904",
        "id" : 76424904
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310815836300525568",
    "text" : "\"If you can make experimentation super cheap and fast, then you can run them both and avoid arguments over opinions\" @IntuitInc",
    "id" : 310815836300525568,
    "created_at" : "2013-03-10 18:14:04 +0000",
    "user" : {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "protected" : false,
      "id_str" : "14278978",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1769304611\/image1327092761_normal.png",
      "id" : 14278978,
      "verified" : true
    }
  },
  "id" : 310833062340620290,
  "created_at" : "2013-03-10 19:22:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "indices" : [ 3, 12 ],
      "id_str" : "14278978",
      "id" : 14278978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310833011040059392",
  "text" : "RT @ericries: \"Imagine being a basketball player who only got one shot on basket each year. How could you improve? Experiments are shots ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intuit Inc. ",
        "screen_name" : "IntuitInc",
        "indices" : [ 124, 134 ],
        "id_str" : "76424904",
        "id" : 76424904
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sxsw",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310817138082467840",
    "text" : "\"Imagine being a basketball player who only got one shot on basket each year. How could you improve? Experiments are shots\" @IntuitInc #sxsw",
    "id" : 310817138082467840,
    "created_at" : "2013-03-10 18:19:15 +0000",
    "user" : {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "protected" : false,
      "id_str" : "14278978",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1769304611\/image1327092761_normal.png",
      "id" : 14278978,
      "verified" : true
    }
  },
  "id" : 310833011040059392,
  "created_at" : "2013-03-10 19:22:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lough Shore",
      "screen_name" : "loughshore",
      "indices" : [ 3, 14 ],
      "id_str" : "215992556",
      "id" : 215992556
    }, {
      "name" : "Lough Shore",
      "screen_name" : "loughshore",
      "indices" : [ 17, 28 ],
      "id_str" : "215992556",
      "id" : 215992556
    }, {
      "name" : "sendmybag.com",
      "screen_name" : "sendmybag",
      "indices" : [ 31, 41 ],
      "id_str" : "87487408",
      "id" : 87487408
    }, {
      "name" : "BBC Dragons' Den",
      "screen_name" : "BBCDragonsDen",
      "indices" : [ 48, 62 ],
      "id_str" : "133676100",
      "id" : 133676100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310832914424287232",
  "text" : "RT @loughshore: .@loughshore's @sendmybag is on @BBCDragonsDen at 7pm on BBC2. It's a repeat of the episode that originally aired in Sep ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lough Shore",
        "screen_name" : "loughshore",
        "indices" : [ 1, 12 ],
        "id_str" : "215992556",
        "id" : 215992556
      }, {
        "name" : "sendmybag.com",
        "screen_name" : "sendmybag",
        "indices" : [ 15, 25 ],
        "id_str" : "87487408",
        "id" : 87487408
      }, {
        "name" : "BBC Dragons' Den",
        "screen_name" : "BBCDragonsDen",
        "indices" : [ 32, 46 ],
        "id_str" : "133676100",
        "id" : 133676100
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310824920802263041",
    "text" : ".@loughshore's @sendmybag is on @BBCDragonsDen at 7pm on BBC2. It's a repeat of the episode that originally aired in September.",
    "id" : 310824920802263041,
    "created_at" : "2013-03-10 18:50:10 +0000",
    "user" : {
      "name" : "Lough Shore",
      "screen_name" : "loughshore",
      "protected" : false,
      "id_str" : "215992556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2289162078\/tfmy6pbzxb24ue7094hz_normal.jpeg",
      "id" : 215992556,
      "verified" : false
    }
  },
  "id" : 310832914424287232,
  "created_at" : "2013-03-10 19:21:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 3, 17 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 19, 25 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/peter_omalley\/status\/310465927609192448\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/QIj7X7gX5D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BE7_HcKCEAAfhTt.jpg",
      "id_str" : "310465927617581056",
      "id" : 310465927617581056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BE7_HcKCEAAfhTt.jpg",
      "sizes" : [ {
        "h" : 3264,
        "resize" : "fit",
        "w" : 1840
      }, {
        "h" : 1816,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QIj7X7gX5D"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310714537911402496",
  "text" : "RT @peter_omalley: @swmcc Found the ideal book for you today.... http:\/\/t.co\/QIj7X7gX5D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/peter_omalley\/status\/310465927609192448\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/QIj7X7gX5D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BE7_HcKCEAAfhTt.jpg",
        "id_str" : "310465927617581056",
        "id" : 310465927617581056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BE7_HcKCEAAfhTt.jpg",
        "sizes" : [ {
          "h" : 3264,
          "resize" : "fit",
          "w" : 1840
        }, {
          "h" : 1816,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1064,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QIj7X7gX5D"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.4901975, -6.1543529 ]
    },
    "id_str" : "310465927609192448",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Found the ideal book for you today.... http:\/\/t.co\/QIj7X7gX5D",
    "id" : 310465927609192448,
    "created_at" : "2013-03-09 19:03:40 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "protected" : false,
      "id_str" : "437697624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1706604039\/eC7Ba2I7_normal",
      "id" : 437697624,
      "verified" : false
    }
  },
  "id" : 310714537911402496,
  "created_at" : "2013-03-10 11:31:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310674756091383808",
  "geo" : { },
  "id_str" : "310714469615562753",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 @michaelnsimpson NO NO NO... YOU DID NOT DANCE WITH STORM TROOPERS!!!! Looks awesome btw :)",
  "id" : 310714469615562753,
  "in_reply_to_status_id" : 310674756091383808,
  "created_at" : "2013-03-10 11:31:17 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310457745797160960",
  "text" : "While I contemplate that question I'm off to Crawfordsburn....",
  "id" : 310457745797160960,
  "created_at" : "2013-03-09 18:31:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310457407132299267",
  "text" : "Age old question.... Who would you slap first - Gary Lightbody or Bono.........",
  "id" : 310457407132299267,
  "created_at" : "2013-03-09 18:29:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imafreak",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310137748298276864",
  "geo" : { },
  "id_str" : "310138239153471488",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne hope you feel better now and that it gave a massive crack noise :) #imafreak",
  "id" : 310138239153471488,
  "in_reply_to_status_id" : 310137748298276864,
  "created_at" : "2013-03-08 21:21:32 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310085950703296512",
  "geo" : { },
  "id_str" : "310087114631045121",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne really hot shower on it and then move your neck really quickly - *CRACK* - relief - happy Georgina",
  "id" : 310087114631045121,
  "in_reply_to_status_id" : 310085950703296512,
  "created_at" : "2013-03-08 17:58:23 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 1, 8 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/EqvnE2oLhU",
      "expanded_url" : "https:\/\/github.com\/blog\/1433-introducing-passion-projects",
      "display_url" : "github.com\/blog\/1433-intr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309796998851223553",
  "text" : "\u201C@github: Introducing Passion Projects https:\/\/t.co\/EqvnE2oLhU\u201D I have such a crush on this company &lt;3",
  "id" : 309796998851223553,
  "created_at" : "2013-03-07 22:45:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 3, 14 ],
      "id_str" : "7255652",
      "id" : 7255652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309721735031320576",
  "text" : "RT @engineyard: Don't miss our webcast on our new cloud architecture enhancements. It starts in 25 minutes! Register now: http:\/\/t.co\/y6 ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/y6wzOdx84z",
        "expanded_url" : "http:\/\/ey.io\/ZroSyB",
        "display_url" : "ey.io\/ZroSyB"
      } ]
    },
    "geo" : { },
    "id_str" : "309719314926292992",
    "text" : "Don't miss our webcast on our new cloud architecture enhancements. It starts in 25 minutes! Register now: http:\/\/t.co\/y6wzOdx84z",
    "id" : 309719314926292992,
    "created_at" : "2013-03-07 17:36:53 +0000",
    "user" : {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "protected" : false,
      "id_str" : "7255652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1410157959\/engine-yard-twitter_normal.jpg",
      "id" : 7255652,
      "verified" : true
    }
  },
  "id" : 309721735031320576,
  "created_at" : "2013-03-07 17:46:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309681418177490944",
  "text" : "OH: \u201CMcCalden is a cock\u201D - most accurate OH ever.",
  "id" : 309681418177490944,
  "created_at" : "2013-03-07 15:06:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309680938110029824",
  "text" : "OH: \u201CYou need to put your kids in one basket\u201D",
  "id" : 309680938110029824,
  "created_at" : "2013-03-07 15:04:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309677862431096832",
  "text" : "OH: \"Well you don't care about getting flacid cos you have just blown your load!!!\"",
  "id" : 309677862431096832,
  "created_at" : "2013-03-07 14:52:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/oTDqwpD4eZ",
      "expanded_url" : "http:\/\/www.wired.com\/opinion\/2013\/03\/github\/",
      "display_url" : "wired.com\/opinion\/2013\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309668092676562946",
  "text" : "Great article - http:\/\/t.co\/oTDqwpD4eZ",
  "id" : 309668092676562946,
  "created_at" : "2013-03-07 14:13:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309616866312220673",
  "geo" : { },
  "id_str" : "309620406925529088",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger welcome. Don\u2019t often get moved but that article was very well written\u2026",
  "id" : 309620406925529088,
  "in_reply_to_status_id" : 309616866312220673,
  "created_at" : "2013-03-07 11:03:52 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309605523085475841",
  "text" : "RT @MiriamKerbache: GAMES DEVELOPER REQUIRED- PHP, HTML5, MYSQL experience needed for contract role. Know someone who may be interested? ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "referafriend",
        "indices" : [ 117, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309602832733073408",
    "text" : "GAMES DEVELOPER REQUIRED- PHP, HTML5, MYSQL experience needed for contract role. Know someone who may be interested? #referafriend for \u00A3\u00A3\u00A3\u00A3",
    "id" : 309602832733073408,
    "created_at" : "2013-03-07 09:54:02 +0000",
    "user" : {
      "name" : "Miriam Kerbache",
      "screen_name" : "MiriamDiamondrg",
      "protected" : false,
      "id_str" : "172736413",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3502664762\/085747fe56b08dbf6b611845377f593b_normal.jpeg",
      "id" : 172736413,
      "verified" : false
    }
  },
  "id" : 309605523085475841,
  "created_at" : "2013-03-07 10:04:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geektweets",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309445992766398464",
  "geo" : { },
  "id_str" : "309446357679222784",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl it is still the workhorse of the interweb like so fair play to it. It isn't going anywhere. #geektweets",
  "id" : 309446357679222784,
  "in_reply_to_status_id" : 309445992766398464,
  "created_at" : "2013-03-06 23:32:15 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309445633532633088",
  "geo" : { },
  "id_str" : "309446114829025282",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I think its lost out to ruby\/rails though. Nice mature frameworks for it now all the same. Still prefer RoR all the same.",
  "id" : 309446114829025282,
  "in_reply_to_status_id" : 309445633532633088,
  "created_at" : "2013-03-06 23:31:17 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309399952612806657",
  "geo" : { },
  "id_str" : "309444983142903808",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I'm not knocking PHP like... It does what it says on the tin... Just there are better tins out there...",
  "id" : 309444983142903808,
  "in_reply_to_status_id" : 309399952612806657,
  "created_at" : "2013-03-06 23:26:47 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309444340147707904",
  "geo" : { },
  "id_str" : "309444619987480577",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl Yeah I agree and I hope so as well. People will be thinking I am more of a PHP developer than well... a proper programmer :)",
  "id" : 309444619987480577,
  "in_reply_to_status_id" : 309444340147707904,
  "created_at" : "2013-03-06 23:25:21 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309443739338817536",
  "geo" : { },
  "id_str" : "309443948319997952",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl lets call a truce before we get down to Pascal and Novell :)",
  "id" : 309443948319997952,
  "in_reply_to_status_id" : 309443739338817536,
  "created_at" : "2013-03-06 23:22:41 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309399952612806657",
  "geo" : { },
  "id_str" : "309443247288229888",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl son of a bitch - JSON and PHP :) Well played Simon... I endorsed you for Windows NT - but its not coming up on your profile :)",
  "id" : 309443247288229888,
  "in_reply_to_status_id" : 309399952612806657,
  "created_at" : "2013-03-06 23:19:53 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309399952612806657",
  "geo" : { },
  "id_str" : "309442384813506561",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl a few others have already done that for me - nice of them - bastards. \/me goes to endorse simon for windows nt admin knowledge :)",
  "id" : 309442384813506561,
  "in_reply_to_status_id" : 309399952612806657,
  "created_at" : "2013-03-06 23:16:28 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309304170412920833",
  "text" : "2 things make me die inside every time when these happen. Someone endorses me for PHP on Linkedin &amp; when I join the wrong network in work.",
  "id" : 309304170412920833,
  "created_at" : "2013-03-06 14:07:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309303513438113792",
  "geo" : { },
  "id_str" : "309303619138752513",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates inferring that i am a geek are ya? ;)",
  "id" : 309303619138752513,
  "in_reply_to_status_id" : 309303513438113792,
  "created_at" : "2013-03-06 14:05:04 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 14, 22 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "iColumbo",
      "screen_name" : "iColumbo",
      "indices" : [ 23, 32 ],
      "id_str" : "569395170",
      "id" : 569395170
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 33, 46 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 47, 54 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309298403706298369",
  "geo" : { },
  "id_str" : "309300827946901504",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates @jbrevel @iColumbo @Paul_Moffett @rejoco Great work - let us know the craic - if they want a geek to talk to etc...",
  "id" : 309300827946901504,
  "in_reply_to_status_id" : 309298403706298369,
  "created_at" : "2013-03-06 13:53:58 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 3, 13 ],
      "id_str" : "240194412",
      "id" : 240194412
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 32, 39 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 97, 110 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309256515779436544",
  "text" : "RT @RepKnight: It's a busy day! @Rejoco speaking at the USA-UKTI Cyber Mission in Pittsburgh and @nicholabates at The Hague for the UK-N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/app.repknight.com\" rel=\"nofollow\"\u003ERepKnight\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Reid",
        "screen_name" : "rejoco",
        "indices" : [ 17, 24 ],
        "id_str" : "53053999",
        "id" : 53053999
      }, {
        "name" : "Nichola Bates",
        "screen_name" : "nicholabates",
        "indices" : [ 82, 95 ],
        "id_str" : "19125494",
        "id" : 19125494
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309249506829033472",
    "text" : "It's a busy day! @Rejoco speaking at the USA-UKTI Cyber Mission in Pittsburgh and @nicholabates at The Hague for the UK-NL Security Dialogue",
    "id" : 309249506829033472,
    "created_at" : "2013-03-06 10:30:02 +0000",
    "user" : {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "protected" : false,
      "id_str" : "240194412",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1241221112\/repknight_avatar_twitter_normal.jpg",
      "id" : 240194412,
      "verified" : false
    }
  },
  "id" : 309256515779436544,
  "created_at" : "2013-03-06 10:57:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle UK",
      "screen_name" : "KindleUK",
      "indices" : [ 108, 117 ],
      "id_str" : "80447639",
      "id" : 80447639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/6Ao3V6DsAs",
      "expanded_url" : "http:\/\/www.amazon.co.uk\/dp\/B005PR422K\/ref=cm_sw_r_tw_ask_6hWBF.00J1TK1",
      "display_url" : "amazon.co.uk\/dp\/B005PR422K\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308992593625219073",
  "text" : "I just bought: 'The Lean Startup: How Constant Innovation Creates Radically Successful Businesses' by.. via @KindleUK http:\/\/t.co\/6Ao3V6DsAs",
  "id" : 308992593625219073,
  "created_at" : "2013-03-05 17:29:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Brodie",
      "screen_name" : "bob_brodie",
      "indices" : [ 3, 14 ],
      "id_str" : "101621268",
      "id" : 101621268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/cLlWcXse5R",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=UodTzseLh04",
      "display_url" : "youtube.com\/watch?v=UodTzs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308741279263637505",
  "text" : "RT @bob_brodie: A wonderful overview of NoSQL and neo4j: http:\/\/t.co\/cLlWcXse5R",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/cLlWcXse5R",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=UodTzseLh04",
        "display_url" : "youtube.com\/watch?v=UodTzs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308659405904310272",
    "text" : "A wonderful overview of NoSQL and neo4j: http:\/\/t.co\/cLlWcXse5R",
    "id" : 308659405904310272,
    "created_at" : "2013-03-04 19:25:11 +0000",
    "user" : {
      "name" : "Bob Brodie",
      "screen_name" : "bob_brodie",
      "protected" : false,
      "id_str" : "101621268",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1433159120\/Screen_shot_2011-07-08_at_7.15.15_PM_normal.png",
      "id" : 101621268,
      "verified" : false
    }
  },
  "id" : 308741279263637505,
  "created_at" : "2013-03-05 00:50:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taige Zhang",
      "screen_name" : "taigeair",
      "indices" : [ 3, 12 ],
      "id_str" : "16931266",
      "id" : 16931266
    }, {
      "name" : "DataSift",
      "screen_name" : "DataSift",
      "indices" : [ 14, 23 ],
      "id_str" : "155505157",
      "id" : 155505157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Onboarding",
      "indices" : [ 74, 85 ]
    }, {
      "text" : "Conversion",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308716752018219009",
  "text" : "RT @taigeair: @DataSift has one of the best SaaS product pages I've seen. #Onboarding #Conversion Best Practice. Full Analysis: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DataSift",
        "screen_name" : "DataSift",
        "indices" : [ 0, 9 ],
        "id_str" : "155505157",
        "id" : 155505157
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Onboarding",
        "indices" : [ 60, 71 ]
      }, {
        "text" : "Conversion",
        "indices" : [ 72, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/LmhIIqeTqY",
        "expanded_url" : "http:\/\/blog.kera.io\/post\/44293064778\/product-page-analysis-and-review-datasift-a",
        "display_url" : "blog.kera.io\/post\/442930647\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308697494483767296",
    "in_reply_to_user_id" : 155505157,
    "text" : "@DataSift has one of the best SaaS product pages I've seen. #Onboarding #Conversion Best Practice. Full Analysis: http:\/\/t.co\/LmhIIqeTqY",
    "id" : 308697494483767296,
    "created_at" : "2013-03-04 21:56:32 +0000",
    "in_reply_to_screen_name" : "DataSift",
    "in_reply_to_user_id_str" : "155505157",
    "user" : {
      "name" : "Taige Zhang",
      "screen_name" : "taigeair",
      "protected" : false,
      "id_str" : "16931266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3656905037\/3b3f34e9c75e04d81e4bb194e358feba_normal.jpeg",
      "id" : 16931266,
      "verified" : false
    }
  },
  "id" : 308716752018219009,
  "created_at" : "2013-03-04 23:13:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308656237191499777",
  "text" : "\/me puts the book down and goes home.. Kinda weird doing research at work - don't really have anything to show for today.. Odd...",
  "id" : 308656237191499777,
  "created_at" : "2013-03-04 19:12:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308633377588793344",
  "geo" : { },
  "id_str" : "308633629171531776",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke it isn\u2019t the space - it is having to use an IDE that has me depressed :(",
  "id" : 308633629171531776,
  "in_reply_to_status_id" : 308633377588793344,
  "created_at" : "2013-03-04 17:42:45 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308611641333907457",
  "text" : "OH: \u201CI am going to take a picture of my shit tonight!\u201D",
  "id" : 308611641333907457,
  "created_at" : "2013-03-04 16:15:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308604034649042944",
  "geo" : { },
  "id_str" : "308606728054906880",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda That's why I went for it - seemed to be the best out of a bad lot... Hopefully I can go into fullscreen mode and forget...",
  "id" : 308606728054906880,
  "in_reply_to_status_id" : 308604034649042944,
  "created_at" : "2013-03-04 15:55:52 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/308603069120270336\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/2SMnpifKDy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEhg2zgCUAA_xTp.png",
      "id_str" : "308603069128658944",
      "id" : 308603069128658944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEhg2zgCUAA_xTp.png",
      "sizes" : [ {
        "h" : 77,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 399
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 399
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 399
      }, {
        "h" : 90,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/2SMnpifKDy"
    } ],
    "hashtags" : [ {
      "text" : "IDESSUCKSOTHEYDO",
      "indices" : [ 11, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308603069120270336",
  "text" : "Disgusting #IDESSUCKSOTHEYDO http:\/\/t.co\/2SMnpifKDy",
  "id" : 308603069120270336,
  "created_at" : "2013-03-04 15:41:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "npm_tweets",
      "screen_name" : "npm_tweets",
      "indices" : [ 3, 14 ],
      "id_str" : "859195014",
      "id" : 859195014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/L1OgvZFVl2",
      "expanded_url" : "http:\/\/npmjs.org\/package\/neo4j-supervisor",
      "display_url" : "npmjs.org\/package\/neo4j-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308590641900814337",
  "text" : "RT @npm_tweets: neo4j-supervisor 0.1.1 http:\/\/t.co\/L1OgvZFVl2 manage a neo4j server installation",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/npmjs.org\/\" rel=\"nofollow\"\u003Enpm_tweets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/L1OgvZFVl2",
        "expanded_url" : "http:\/\/npmjs.org\/package\/neo4j-supervisor",
        "display_url" : "npmjs.org\/package\/neo4j-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308562954960392192",
    "text" : "neo4j-supervisor 0.1.1 http:\/\/t.co\/L1OgvZFVl2 manage a neo4j server installation",
    "id" : 308562954960392192,
    "created_at" : "2013-03-04 13:01:55 +0000",
    "user" : {
      "name" : "npm_tweets",
      "screen_name" : "npm_tweets",
      "protected" : false,
      "id_str" : "859195014",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3271965971\/d6a4510e888422699f1f5720552b68b5_normal.png",
      "id" : 859195014,
      "verified" : false
    }
  },
  "id" : 308590641900814337,
  "created_at" : "2013-03-04 14:51:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308589355247742976",
  "geo" : { },
  "id_str" : "308589601440792578",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 batman is an idea not just a man\u2026. So we are capable of being batman :) My job is done so I can now hang up the cape :)",
  "id" : 308589601440792578,
  "in_reply_to_status_id" : 308589355247742976,
  "created_at" : "2013-03-04 14:47:48 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308582728788475904",
  "geo" : { },
  "id_str" : "308589239149412352",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 Awesome!!!! :D",
  "id" : 308589239149412352,
  "in_reply_to_status_id" : 308582728788475904,
  "created_at" : "2013-03-04 14:46:22 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308572714715721728",
  "geo" : { },
  "id_str" : "308574357687517184",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin \/me takes the photo and says \"I know\" - \/me drives off",
  "id" : 308574357687517184,
  "in_reply_to_status_id" : 308572714715721728,
  "created_at" : "2013-03-04 13:47:14 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 23, 34 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308546855317405696",
  "text" : "Thanks for the donught @bigwetfish and @moesdonuts for the surprise earlier. There would have been a pic but a racoon stole it! :)",
  "id" : 308546855317405696,
  "created_at" : "2013-03-04 11:57:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308288175556685825",
  "geo" : { },
  "id_str" : "308340249736646656",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid ahhh crap. I should have said :( Fathers day is soon though - might get the oul fella that... Hmmmm.. Good idea :)",
  "id" : 308340249736646656,
  "in_reply_to_status_id" : 308288175556685825,
  "created_at" : "2013-03-03 22:16:58 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle UK",
      "screen_name" : "KindleUK",
      "indices" : [ 70, 79 ],
      "id_str" : "80447639",
      "id" : 80447639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/9Kl8DtvcnE",
      "expanded_url" : "http:\/\/www.amazon.co.uk\/dp\/B009BBGY0E\/ref=cm_sw_r_tw_ask_dgwAF.1GCXTT5",
      "display_url" : "amazon.co.uk\/dp\/B009BBGY0E\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308339560092405760",
  "text" : "I just bought: 'The Coop (Thickets Wood Trilogy)' by Rebecca Reid via @KindleUK http:\/\/t.co\/9Kl8DtvcnE",
  "id" : 308339560092405760,
  "created_at" : "2013-03-03 22:14:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rebecca reid",
      "screen_name" : "thicketswood",
      "indices" : [ 3, 16 ],
      "id_str" : "731412510",
      "id" : 731412510
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NI",
      "indices" : [ 110, 113 ]
    }, {
      "text" : "ebook",
      "indices" : [ 114, 120 ]
    }, {
      "text" : "amazon",
      "indices" : [ 121, 128 ]
    }, {
      "text" : "author",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/vTgsTS4fTj",
      "expanded_url" : "http:\/\/www.amazon.co.uk\/Coop-Thickets-Wood-Trilogy-ebook\/dp\/B009BBGY0E\/ref=sr_1_1?s=digital-text&ie=UTF8&qid=1362345709&sr=1-1",
      "display_url" : "amazon.co.uk\/Coop-Thickets-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308339417792262145",
  "text" : "RT @thicketswood: Only a few hours left to grab your copy of 'The Coop' for free.......http:\/\/t.co\/vTgsTS4fTj #NI #ebook #amazon #author",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NI",
        "indices" : [ 92, 95 ]
      }, {
        "text" : "ebook",
        "indices" : [ 96, 102 ]
      }, {
        "text" : "amazon",
        "indices" : [ 103, 110 ]
      }, {
        "text" : "author",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/vTgsTS4fTj",
        "expanded_url" : "http:\/\/www.amazon.co.uk\/Coop-Thickets-Wood-Trilogy-ebook\/dp\/B009BBGY0E\/ref=sr_1_1?s=digital-text&ie=UTF8&qid=1362345709&sr=1-1",
        "display_url" : "amazon.co.uk\/Coop-Thickets-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308326636791685121",
    "text" : "Only a few hours left to grab your copy of 'The Coop' for free.......http:\/\/t.co\/vTgsTS4fTj #NI #ebook #amazon #author",
    "id" : 308326636791685121,
    "created_at" : "2013-03-03 21:22:53 +0000",
    "user" : {
      "name" : "rebecca reid",
      "screen_name" : "thicketswood",
      "protected" : false,
      "id_str" : "731412510",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2536033361\/k7exx0jrh9vybzb8tky3_normal.png",
      "id" : 731412510,
      "verified" : false
    }
  },
  "id" : 308339417792262145,
  "created_at" : "2013-03-03 22:13:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308234344571478017",
  "geo" : { },
  "id_str" : "308238087966826497",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu that'd be her texting me the reaction of the oul fella when he found all the post-its I put in his room covered in drawn cocks.",
  "id" : 308238087966826497,
  "in_reply_to_status_id" : 308234344571478017,
  "created_at" : "2013-03-03 15:31:01 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/308177075397853184\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/vToTgAWPLW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEbdatNCAAAw5rx.png",
      "id_str" : "308177075402047488",
      "id" : 308177075402047488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEbdatNCAAAw5rx.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/vToTgAWPLW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308177075397853184",
  "text" : "Result http:\/\/t.co\/vToTgAWPLW",
  "id" : 308177075397853184,
  "created_at" : "2013-03-03 11:28:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307589981231280128",
  "text" : "Dad on me saying that I am gonna take the piss out of him when he turns 70: 'Do what you want as I'll be in the corner chewing my own dick'",
  "id" : 307589981231280128,
  "created_at" : "2013-03-01 20:35:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307492977406787585",
  "geo" : { },
  "id_str" : "307493062274347008",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery always ;)",
  "id" : 307493062274347008,
  "in_reply_to_status_id" : 307492977406787585,
  "created_at" : "2013-03-01 14:10:33 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307492858066243584",
  "text" : "That last tweet was brought to you by a post on upgrading framework versions\u2026 Stuff like that winds me up. Your \u2018site\u2019 should never be off!",
  "id" : 307492858066243584,
  "created_at" : "2013-03-01 14:09:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307492590058602496",
  "text" : "\u201CBefore performing an update you should take your site offline by replacing the index.php file with a static one.\u201D &lt;- THIS IS SO WRONG!!!",
  "id" : 307492590058602496,
  "created_at" : "2013-03-01 14:08:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/307472384833748993\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/ZyFvzNPij8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BERcgUSCAAEbRRc.jpg",
      "id_str" : "307472384837943297",
      "id" : 307472384837943297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BERcgUSCAAEbRRc.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/ZyFvzNPij8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307472384833748993",
  "text" : "Poor bastards are really giving it Dixie. First valet I've ever given her and I've had her 4years :) http:\/\/t.co\/ZyFvzNPij8",
  "id" : 307472384833748993,
  "created_at" : "2013-03-01 12:48:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307443353186885633",
  "geo" : { },
  "id_str" : "307444041719635969",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ that's a good idea. You should do that instead of wasting time on games :)",
  "id" : 307444041719635969,
  "in_reply_to_status_id" : 307443353186885633,
  "created_at" : "2013-03-01 10:55:46 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307442682060500992",
  "geo" : { },
  "id_str" : "307442818232762369",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ i haven\u2019t a fucking clue what you are on about son :)",
  "id" : 307442818232762369,
  "in_reply_to_status_id" : 307442682060500992,
  "created_at" : "2013-03-01 10:50:54 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307441574667755520",
  "geo" : { },
  "id_str" : "307442114957041664",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ what you doing?",
  "id" : 307442114957041664,
  "in_reply_to_status_id" : 307441574667755520,
  "created_at" : "2013-03-01 10:48:06 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/spotify.com\" rel=\"nofollow\"\u003ESpotify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Spotify",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/h6lphtqvqU",
      "expanded_url" : "http:\/\/spoti.fi\/YNiH9W",
      "display_url" : "spoti.fi\/YNiH9W"
    } ]
  },
  "geo" : { },
  "id_str" : "307440806854283264",
  "text" : "I love this playlist by Ant - listen to it most Fridays when I need to push stuff to the 'did' category :D http:\/\/t.co\/h6lphtqvqU #Spotify",
  "id" : 307440806854283264,
  "created_at" : "2013-03-01 10:42:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]