Grailbird.data.tweets_2010_08 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22597043080",
  "text" : "Virtual Monday.. After four day weekend.. Lovely BBQ in Carnfunfuck Park yesterday. Back to reality now.. Get out of bed SWMCC.. Get out!!!",
  "id" : 22597043080,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22612074289",
  "geo" : { },
  "id_str" : "22613804759",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Me and CC were in Larne yesterday and seen pretty much the same thing.. Why do ppl do it? Yuckie...",
  "id" : 22613804759,
  "in_reply_to_status_id" : 22612074289,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22613850833",
  "text" : "The Sonos Player just picked two Alanis Morissete (sp) songs in a row there... Surely that is a bad sign.",
  "id" : 22613850833,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22613961890",
  "text" : "Made a big pot of coffee there to help with this virtual Monday madness... Hope it helps, cos I need something.. Brain has shut down...",
  "id" : 22613961890,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22639614573",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe move! :)",
  "id" : 22639614573,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22642515263",
  "text" : "Seriously does my BBC licence fee actually pay for Holby City... It really is woeful.",
  "id" : 22642515263,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilson reid",
      "screen_name" : "wilsonreid",
      "indices" : [ 0, 11 ],
      "id_str" : "94781128",
      "id" : 94781128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22645259432",
  "text" : "@wilsonreid :)",
  "id" : 22645259432,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22645296442",
  "text" : "I just cleaned out all the cupboards there.. And no joke.. The oldest BBD on a tin of food was..... July........ 2005 :D :D :D :D",
  "id" : 22645296442,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22644847675",
  "geo" : { },
  "id_str" : "22645776163",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes good kick in the bajingo is what is needed there I think! Watching The Hills and stuff when they should be out playing!!!",
  "id" : 22645776163,
  "in_reply_to_status_id" : 22644847675,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 42, 49 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22649949233",
  "text" : "One day..... One day soon.. Mark my words @Srushe....",
  "id" : 22649949233,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22650179631",
  "geo" : { },
  "id_str" : "22650713554",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop geek :)",
  "id" : 22650713554,
  "in_reply_to_status_id" : 22650179631,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22650775303",
  "geo" : { },
  "id_str" : "22650914940",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop nope :)",
  "id" : 22650914940,
  "in_reply_to_status_id" : 22650775303,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22653989745",
  "geo" : { },
  "id_str" : "22654226385",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne but you did it. That's the main thing. Keep it up :)",
  "id" : 22654226385,
  "in_reply_to_status_id" : 22653989745,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22654327408",
  "text" : "Blair's autobiography out tomorrow. Will be a good read. When I am PM I will make ppl that end a severance with an upward inflection illegal",
  "id" : 22654327408,
  "created_at" : "2010-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22509803430",
  "text" : "\"I found a love bite on my boyfriend... and I'm pregnant with his child!\" Man I love this show sky+'d from now on...",
  "id" : 22509803430,
  "created_at" : "2010-08-30 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22513051970",
  "geo" : { },
  "id_str" : "22514855094",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bk_gordon is that 'someone' kazza? :)",
  "id" : 22514855094,
  "in_reply_to_status_id" : 22513051970,
  "created_at" : "2010-08-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22541848767",
  "text" : "A virtual Sunday there... Good good.. Now to download some entourage..",
  "id" : 22541848767,
  "created_at" : "2010-08-30 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scaryshizzle",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22425260252",
  "text" : "Fox news just ran a segment on a \"Palin\/Beck ticket for '12\". Thing was they were serious. #scaryshizzle",
  "id" : 22425260252,
  "created_at" : "2010-08-29 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22435998668",
  "text" : "Hello!!!!",
  "id" : 22435998668,
  "created_at" : "2010-08-29 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22455797723",
  "text" : "The last tweet I did was brought to you by the beautiful Christine!! Could have been worse, believe me :)",
  "id" : 22455797723,
  "created_at" : "2010-08-29 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22436161277",
  "geo" : { },
  "id_str" : "22455849974",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop That was a CC sponsored message - leave my iPhone down for more than 20mins and that happens :) Ahh well. Any craic? :)",
  "id" : 22455849974,
  "in_reply_to_status_id" : 22436161277,
  "created_at" : "2010-08-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22250598439",
  "text" : "Ahhhhh. In bed watching Jeremy Kyle.. Class :)",
  "id" : 22250598439,
  "created_at" : "2010-08-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22250645189",
  "geo" : { },
  "id_str" : "22250840025",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop nah I don't like that prog. But how can you not love this \"did you do drugs at your daughters christening?\"",
  "id" : 22250840025,
  "in_reply_to_status_id" : 22250645189,
  "created_at" : "2010-08-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22251318431",
  "text" : "\"How do I stop my teenage daughter from being a man?\"",
  "id" : 22251318431,
  "created_at" : "2010-08-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22251563134",
  "geo" : { },
  "id_str" : "22251865020",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe :) the whole point of JK is to make you feel so much better about your own life :) Gotta a chess app. Prepare for a kickin!! :)",
  "id" : 22251865020,
  "in_reply_to_status_id" : 22251563134,
  "created_at" : "2010-08-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22252458182",
  "text" : "\"Caught in bed with another man... If you didn't cheat, why were you naked?\"",
  "id" : 22252458182,
  "created_at" : "2010-08-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22254342132",
  "geo" : { },
  "id_str" : "22254998291",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Jeremy.. Is Trisha still going?",
  "id" : 22254998291,
  "in_reply_to_status_id" : 22254342132,
  "created_at" : "2010-08-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22257485964",
  "text" : "Now watching The Final Destanation. What a cheesy Friday",
  "id" : 22257485964,
  "created_at" : "2010-08-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22159026606",
  "text" : "Virtual Friday!!!!! :D",
  "id" : 22159026606,
  "created_at" : "2010-08-26 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetni",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22164766004",
  "text" : "Just joined Northern Ireland's Twitter directory http:\/\/tweetni.com #tweetni",
  "id" : 22164766004,
  "created_at" : "2010-08-26 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22180914564",
  "text" : "A virtual Friday afternoon is hard to see in.",
  "id" : 22180914564,
  "created_at" : "2010-08-26 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22200059939",
  "geo" : { },
  "id_str" : "22200680536",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne just after one there. Feel awful now though. Groggy.",
  "id" : 22200680536,
  "in_reply_to_status_id" : 22200059939,
  "created_at" : "2010-08-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22069682203",
  "text" : "Bank holiday weekend - and I am offski on the Friday!! Bring it bitches! :D",
  "id" : 22069682203,
  "created_at" : "2010-08-25 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 50, 57 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22094688366",
  "text" : "another week - yet another defeat by the hands of @srushe..",
  "id" : 22094688366,
  "created_at" : "2010-08-25 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21997763278",
  "geo" : { },
  "id_str" : "21999120729",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit :) You are right :) Good call.. Also the syntax for tar and useradd v adduser. Am never going to learn it.. Right.. tea! :)",
  "id" : 21999120729,
  "in_reply_to_status_id" : 21997763278,
  "created_at" : "2010-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22000472720",
  "geo" : { },
  "id_str" : "22001698142",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes aye.... he's up to something!",
  "id" : 22001698142,
  "in_reply_to_status_id" : 22000472720,
  "created_at" : "2010-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21983838573",
  "text" : "The tumble dryer stopped working last night. Probably just a fuse. Hopefully. Dammit.",
  "id" : 21983838573,
  "created_at" : "2010-08-24 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21990974571",
  "text" : "I &lt;3 you rsync.. I really do.",
  "id" : 21990974571,
  "created_at" : "2010-08-24 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21993319231",
  "geo" : { },
  "id_str" : "21994238140",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit find \/dir -type d -name '.svn' -exec rm -r '\u007B\u007D' ';'. But this is nicer - rscync -a --exclude '.svn' root@server:\/dir\/* .",
  "id" : 21994238140,
  "in_reply_to_status_id" : 21993319231,
  "created_at" : "2010-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21993319231",
  "geo" : { },
  "id_str" : "21994303640",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit just made stuff handier.. But there is nothing that confuses me more than find.. Well that and the order for ln -s :)",
  "id" : 21994303640,
  "in_reply_to_status_id" : 21993319231,
  "created_at" : "2010-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21995110331",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe is being sneaky! I don't like it :)",
  "id" : 21995110331,
  "created_at" : "2010-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21996206730",
  "text" : "He will be beaten.... Someday!!!  http:\/\/yfrog.com\/3r8bbj",
  "id" : 21996206730,
  "created_at" : "2010-08-24 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21898584061",
  "geo" : { },
  "id_str" : "21899061576",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin Glenavy =) Yeeeeooooooo :) What you doing in God's part of the world? ;) In saying that Glenavy is a good 8 mile away :)",
  "id" : 21899061576,
  "in_reply_to_status_id" : 21898584061,
  "created_at" : "2010-08-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21899971675",
  "geo" : { },
  "id_str" : "21900190147",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes I sky+'d that last night :) It is even worse than I remember. But in a really good way :)",
  "id" : 21900190147,
  "in_reply_to_status_id" : 21899971675,
  "created_at" : "2010-08-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21901161003",
  "geo" : { },
  "id_str" : "21904324995",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit was brilliant. Just like they used to make back in the day :)",
  "id" : 21904324995,
  "in_reply_to_status_id" : 21901161003,
  "created_at" : "2010-08-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21927012871",
  "geo" : { },
  "id_str" : "21927444242",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings cos they are making the classest game of all time Hastings! :) Why would they bother with an inferior franchise? ;)",
  "id" : 21927444242,
  "in_reply_to_status_id" : 21927012871,
  "created_at" : "2010-08-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21927769007",
  "geo" : { },
  "id_str" : "21927910087",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings idiot :)",
  "id" : 21927910087,
  "in_reply_to_status_id" : 21927769007,
  "created_at" : "2010-08-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Hutchinson",
      "screen_name" : "matthutchin",
      "indices" : [ 0, 12 ],
      "id_str" : "808420",
      "id" : 808420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21853881820",
  "geo" : { },
  "id_str" : "21856562965",
  "in_reply_to_user_id" : 808420,
  "text" : "@matthutchin you are an idiot! That is all :)",
  "id" : 21856562965,
  "in_reply_to_status_id" : 21853881820,
  "created_at" : "2010-08-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "matthutchin",
  "in_reply_to_user_id_str" : "808420",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21856642968",
  "text" : "The Expendables is an awesome film. Stallone is really churning out the classy cheesy films this weather. Bring it Sly.. More.. more :)",
  "id" : 21856642968,
  "created_at" : "2010-08-22 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21857629820",
  "geo" : { },
  "id_str" : "21857716819",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe you also didn't like the a-team either. What are your views on the latest Rambo and Rocky films? Also Star Wars? :)",
  "id" : 21857716819,
  "in_reply_to_status_id" : 21857629820,
  "created_at" : "2010-08-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duggie",
      "screen_name" : "duggie_boy",
      "indices" : [ 0, 11 ],
      "id_str" : "18317139",
      "id" : 18317139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21698738018",
  "geo" : { },
  "id_str" : "21744182323",
  "in_reply_to_user_id" : 18317139,
  "text" : "@duggie_boy :) I had a really weird dream last night where you and I were cops... WTF.. I saved your life, of course.. Gay or what! :(",
  "id" : 21744182323,
  "in_reply_to_status_id" : 21698738018,
  "created_at" : "2010-08-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "duggie_boy",
  "in_reply_to_user_id_str" : "18317139",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 11, 18 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turnthedialtoeleven",
      "indices" : [ 74, 94 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21774985268",
  "geo" : { },
  "id_str" : "21782155984",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes @Srushe has never seen the spinal tap??? And you married him?? #turnthedialtoeleven",
  "id" : 21782155984,
  "in_reply_to_status_id" : 21774985268,
  "created_at" : "2010-08-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21641945341",
  "text" : "Friiiiidddday. You toon your time getting here. Don't be doing that again!!!",
  "id" : 21641945341,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 0, 9 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21648356573",
  "geo" : { },
  "id_str" : "21650946851",
  "in_reply_to_user_id" : 14961440,
  "text" : "@akaihane reading when not in work is not a good thing ;)",
  "id" : 21650946851,
  "in_reply_to_status_id" : 21648356573,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "akaihane",
  "in_reply_to_user_id_str" : "14961440",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21653441043",
  "geo" : { },
  "id_str" : "21654063349",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit lower back giving bother again?",
  "id" : 21654063349,
  "in_reply_to_status_id" : 21653441043,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21661979923",
  "text" : "\"xxxx is putting in a 'new SVN' on cos the one Stevie put on is shit!\" - classic. Supposed technical expert said that last year. LOVE IT :D",
  "id" : 21661979923,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21662589853",
  "geo" : { },
  "id_str" : "21663070276",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit yes it was :) But how can one svn differ from another one is beyond me. I guess that's why I am not a 'technical expert'. :)",
  "id" : 21663070276,
  "in_reply_to_status_id" : 21662589853,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21664916934",
  "geo" : { },
  "id_str" : "21665861951",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin meeting at 3pm on a Friday! WTF.",
  "id" : 21665861951,
  "in_reply_to_status_id" : 21664916934,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21665919332",
  "geo" : { },
  "id_str" : "21666440395",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin on a Friday???",
  "id" : 21666440395,
  "in_reply_to_status_id" : 21665919332,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21671139569",
  "text" : "so people still use emacs... go figure.",
  "id" : 21671139569,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21558537117",
  "text" : "Its still not Friday :(",
  "id" : 21558537117,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21560735843",
  "geo" : { },
  "id_str" : "21561585102",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe good or bad? Don't understand mwah.... :)",
  "id" : 21561585102,
  "in_reply_to_status_id" : 21560735843,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21565836284",
  "text" : "Office is very empty today...",
  "id" : 21565836284,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21566102565",
  "geo" : { },
  "id_str" : "21566318147",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin didn't do them. GCSE's -&gt; TECH -&gt; JOB -&gt; GETTING IT IN ASS :)",
  "id" : 21566318147,
  "in_reply_to_status_id" : 21566102565,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stupidwoman",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21578554722",
  "text" : "http:\/\/twitter.com\/MSANNCOOPER - an excellent example of evolution not working properly. Then again she was in the TUV. #stupidwoman",
  "id" : 21578554722,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 29, 36 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21584035111",
  "text" : "today is going slow. I blame @srushe. Yes, yes I do!",
  "id" : 21584035111,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21605671378",
  "text" : "Watching The Departed... Class. \"No tickie.. No laundry\".",
  "id" : 21605671378,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 0, 9 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21606093791",
  "geo" : { },
  "id_str" : "21606959846",
  "in_reply_to_user_id" : 14961440,
  "text" : "@akaihane but that gas sub titles. Means reading... Reading!!!! :)",
  "id" : 21606959846,
  "in_reply_to_status_id" : 21606093791,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "akaihane",
  "in_reply_to_user_id_str" : "14961440",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21477247716",
  "text" : "Getting my wee nap sack and heading to Bytel... Servers a go go...",
  "id" : 21477247716,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "myfirstgig",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21478910915",
  "geo" : { },
  "id_str" : "21495681647",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit 1995 - Ulsterhall The Therapy? and Ash.. #myfirstgig",
  "id" : 21495681647,
  "in_reply_to_status_id" : 21478910915,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21480736663",
  "geo" : { },
  "id_str" : "21495825893",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop 50 :) Class... You must download some stuff :)",
  "id" : 21495825893,
  "in_reply_to_status_id" : 21480736663,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "myfirstgig",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21495951816",
  "text" : "1995 - Ulsterhall The Therapy? and Ash.. #myfirstgig",
  "id" : 21495951816,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21497214961",
  "text" : "http:\/\/twitgoo.com\/1imwjo  - awwww my wee babies are all growed up and have flown the nest :(",
  "id" : 21497214961,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21498984033",
  "geo" : { },
  "id_str" : "21499423536",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes Well the Therapy? were a great band in the day. Not so sure about now :) Ash - got they were awful! Awful. *TEEETHGRINDER*",
  "id" : 21499423536,
  "in_reply_to_status_id" : 21498984033,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21503491172",
  "text" : "Goes home.. Servers are hard work..",
  "id" : 21503491172,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derren Brown",
      "screen_name" : "DerrenBrown",
      "indices" : [ 39, 51 ],
      "id_str" : "25489250",
      "id" : 25489250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21514897193",
  "text" : "Why is twitter insisting that I follow @derrenbrown. I would rather cut of my own cock than do that! Away and FUCK twitter :D",
  "id" : 21514897193,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21519000285",
  "geo" : { },
  "id_str" : "21519188194",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit arms still in place? :) Well done :) That'll hurt the marra ;)",
  "id" : 21519188194,
  "in_reply_to_status_id" : 21519000285,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21386876142",
  "text" : "I joined @politicsjunkies last night.. They are currently asking if SarahPalin is sexy? What has that got to do with politics?",
  "id" : 21386876142,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21386994952",
  "geo" : { },
  "id_str" : "21387403829",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin She is funny though. A complete cartoon character :) But asking whether she is sexy or not is just stupid.",
  "id" : 21387403829,
  "in_reply_to_status_id" : 21386994952,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21389388578",
  "geo" : { },
  "id_str" : "21390526289",
  "in_reply_to_user_id" : 127470921,
  "text" : "@politicsjunkies Apologies. Probably just the usual tuesday morning grumps. Esp since i woke up and thought it was Saturday! Apologies.",
  "id" : 21390526289,
  "in_reply_to_status_id" : 21389388578,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "QwanzPolitics",
  "in_reply_to_user_id_str" : "127470921",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21400020369",
  "text" : "Ryvita and cream cheese for llunch.. i am a big girl :D",
  "id" : 21400020369,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twifficiency.com\/\" rel=\"nofollow\"\u003ETwifficiency\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21413105607",
  "text" : "My Twifficiency score is 56%. Whats yours? http:\/\/twifficiency.com\/",
  "id" : 21413105607,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21413151676",
  "text" : "Windows programmers... Are they really programmers? One fella I was talking to said once \"This SSH - what is it - never heard of it\"..",
  "id" : 21413151676,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21423519831",
  "text" : "Curry!",
  "id" : 21423519831,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21441819446",
  "text" : "Am too old for this shit. Its 12:30 in the am. Curry plus a shots..  In 10 hours I will be stuck in a server room putting my new babies in.",
  "id" : 21441819446,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21441831454",
  "text" : "But when I used to work for rehab I was only getting home at this time - so its still all good :D",
  "id" : 21441831454,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21302181501",
  "text" : "I am greatful for my job.. But by fuck I hate Mondays.. I loathe them. They should be made illegal...",
  "id" : 21302181501,
  "created_at" : "2010-08-16 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21309743169",
  "geo" : { },
  "id_str" : "21309836539",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe you could always try moving until @mnehughes comes out of the exam :)",
  "id" : 21309836539,
  "in_reply_to_status_id" : 21309743169,
  "created_at" : "2010-08-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 11, 18 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21315602963",
  "geo" : { },
  "id_str" : "21315800212",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes @srushe - I want strawberry milk for tomorrow :D",
  "id" : 21315800212,
  "in_reply_to_status_id" : 21315602963,
  "created_at" : "2010-08-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21321688251",
  "text" : "I can deal with lazy code.. But lazy systems.. \"Sure this will never happen\". Then a few years down the line it does. And its a whore to fix",
  "id" : 21321688251,
  "created_at" : "2010-08-16 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FML",
      "indices" : [ 68, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21329849733",
  "text" : "My Iphone us running reall slow.. What is it the kidz say nowadays. #FML",
  "id" : 21329849733,
  "created_at" : "2010-08-16 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 88, 95 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21345542691",
  "text" : "So... You can't castle while you are in check! Son of a bitch. I really hate Mondays :D @srushe - strawberry milk! :)",
  "id" : 21345542691,
  "created_at" : "2010-08-16 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 49, 56 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21229874611",
  "text" : "Using gameknots new training thing so I can beat @srushe this week.. \/me on top of a mountain \"Ruusssshe.. Ruuuussssshhhheeeeeee!!\"",
  "id" : 21229874611,
  "created_at" : "2010-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21253966008",
  "text" : "Watching that Amish thing on C4.. I think they have the right idea - no NFS to annoy you. Just grow shit and eat it!",
  "id" : 21253966008,
  "created_at" : "2010-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21254459725",
  "text" : "Ok.... I'll have to think about this Amish thing.. Cos the women don't shave their arm pits or legs.. And the dudes have to grow beards.",
  "id" : 21254459725,
  "created_at" : "2010-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21254533135",
  "text" : "And at 31 I can just about grow some fuzz around my mouth anywhere around the chin area is kinda dodgy, and a bit ginger if left for a while",
  "id" : 21254533135,
  "created_at" : "2010-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilson reid",
      "screen_name" : "wilsonreid",
      "indices" : [ 0, 11 ],
      "id_str" : "94781128",
      "id" : 94781128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21164027459",
  "text" : "@wilsonreid Gooooo Mac.. Once you go Mac you never go back... Fuck I am sad.. I think I'll kick myself in the nuts now :)",
  "id" : 21164027459,
  "created_at" : "2010-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilson reid",
      "screen_name" : "wilsonreid",
      "indices" : [ 0, 11 ],
      "id_str" : "94781128",
      "id" : 94781128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21167441098",
  "text" : "@wilsonreid that cut deep...",
  "id" : 21167441098,
  "created_at" : "2010-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilson reid",
      "screen_name" : "wilsonreid",
      "indices" : [ 0, 11 ],
      "id_str" : "94781128",
      "id" : 94781128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21169158945",
  "text" : "@wilsonreid just buy a mac you tight bastard :)",
  "id" : 21169158945,
  "created_at" : "2010-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilson reid",
      "screen_name" : "wilsonreid",
      "indices" : [ 0, 11 ],
      "id_str" : "94781128",
      "id" : 94781128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21170536024",
  "text" : "@wilsonreid no talkin to ya.",
  "id" : 21170536024,
  "created_at" : "2010-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21173402812",
  "text" : "Watching The Queen on C4. Admiral Piett is the Duke of York. Class...",
  "id" : 21173402812,
  "created_at" : "2010-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21185445779",
  "text" : "Watching Star Trek here... Insurrection.. The big tall dude doesn't have a beard.. It is shit. How can ppl like this?",
  "id" : 21185445779,
  "created_at" : "2010-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andie",
      "screen_name" : "andiepaige",
      "indices" : [ 1, 12 ],
      "id_str" : "1296524167",
      "id" : 1296524167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21042383089",
  "text" : "\u201C@AndiePaige: ...Just saw where someone spelled Mick Jagger as \"McJagger\".  I'm going to shoot myself.\u201D",
  "id" : 21042383089,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/timespent.info\/\" rel=\"nofollow\"\u003ESmall Useful Utilites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitter",
      "indices" : [ 3, 11 ]
    }, {
      "text" : "twittertime",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21045389439",
  "text" : "My #twitter age is 1260 days 8 hours 3 minutes 22 seconds. Find out yours at http:\/\/twitter.seocoder.org\/ #twittertime",
  "id" : 21045389439,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21051049381",
  "text" : "mounted my vmware dev server to my mac. So now I can start to use Textmate.. I have now moved into the land of GUI's!",
  "id" : 21051049381,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21051150137",
  "text" : "FFS... Just opened \/System\/ on my mac.. This is why I don't use stuff like this. Lets an idiot like me do really stupid shit!",
  "id" : 21051150137,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21051210083",
  "geo" : { },
  "id_str" : "21051523943",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop I have started to use it a bit more - just makes things handier I think.. But I've got the instance mounted. Just wont save :(",
  "id" : 21051523943,
  "in_reply_to_status_id" : 21051210083,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21051210083",
  "geo" : { },
  "id_str" : "21051729026",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop It does look very powerful.. Thought it was time I got my ass into the 21st century :)",
  "id" : 21051729026,
  "in_reply_to_status_id" : 21051210083,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21052126518",
  "text" : "fuck you nfs.. fuck you right into hell.",
  "id" : 21052126518,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21052941648",
  "text" : "right suprise suprise its permissions!! Son of a bitch!",
  "id" : 21052941648,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21054010324",
  "text" : "CHMOD 777 -R * am really tempted..",
  "id" : 21054010324,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21054253652",
  "geo" : { },
  "id_str" : "21054339199",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings Text::CSV_XS, File::Slurp, XML::Simple, and SpreadSheet::Excel.. But you are using PHP.. so you deserve what you get ;)",
  "id" : 21054339199,
  "in_reply_to_status_id" : 21054253652,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul McKeever",
      "screen_name" : "paulmckeever",
      "indices" : [ 0, 13 ],
      "id_str" : "15741536",
      "id" : 15741536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21054205743",
  "geo" : { },
  "id_str" : "21054375249",
  "in_reply_to_user_id" : 15741536,
  "text" : "@paulmckeever :) Its driving me crazy : Now I know why I never bother with NFS.. But textmate is nice! VMware to my desktop - so am tempted.",
  "id" : 21054375249,
  "in_reply_to_status_id" : 21054205743,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "paulmckeever",
  "in_reply_to_user_id_str" : "15741536",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21054387549",
  "geo" : { },
  "id_str" : "21054735037",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings I'll do it for ya. I used to do stuff like that all the time when i was with sendit.com - no bother like. If you want.",
  "id" : 21054735037,
  "in_reply_to_status_id" : 21054387549,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21055310280",
  "text" : "Has fixed his nfs problem.. Stupid permissions.. Now i know why ppl tend to stay away from it and use samba :)",
  "id" : 21055310280,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 41, 57 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21055590943",
  "text" : "I just got called a really nasty name by @AnthonyHastings.. Any guesses what he just called me? Uncalled for Sir, uncalled for :)",
  "id" : 21055590943,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21056039539",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings - I did deserve that on reflection. What an ass I was.. But it wasn't me that said it - I was a puppet.. :)",
  "id" : 21056039539,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21062214752",
  "text" : "sending in job applications from your current work address.. surely that's just dumb?",
  "id" : 21062214752,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21063196278",
  "geo" : { },
  "id_str" : "21063398740",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes I use bing.com now and again. Its not bad if you can look past the microsoft issues :)",
  "id" : 21063398740,
  "in_reply_to_status_id" : 21063196278,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21063950943",
  "geo" : { },
  "id_str" : "21064736523",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes I like the new google :) I don't mind it one bit. But sometimes searchin on bing is more successful\".",
  "id" : 21064736523,
  "in_reply_to_status_id" : 21063950943,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 97, 104 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21065701004",
  "text" : "I fancy a cup of tea.. But I don't fancy walking all the way over there &lt;---- to the kitchen. @srushe - any chance ;)",
  "id" : 21065701004,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21071938889",
  "geo" : { },
  "id_str" : "21072486344",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne They asked for my opinon, which I gave. Then didn't take my advice. Then complained when their idea failed and blamed moi!",
  "id" : 21072486344,
  "in_reply_to_status_id" : 21071938889,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21091926614",
  "geo" : { },
  "id_str" : "21092405065",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe shit one. Around ards on a Friday night... I feel for ya!",
  "id" : 21092405065,
  "in_reply_to_status_id" : 21091926614,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21089122903",
  "geo" : { },
  "id_str" : "21092425907",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes fanku :)",
  "id" : 21092425907,
  "in_reply_to_status_id" : 21089122903,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "21093179877",
  "geo" : { },
  "id_str" : "21097874543",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe kircubbin! Shit one! That's ards with inbreeding though. Just watch out for crowsbrows, banjos and banjo music :)",
  "id" : 21097874543,
  "in_reply_to_status_id" : 21093179877,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20958961739",
  "geo" : { },
  "id_str" : "20960127954",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop can I play? I know nothing about football, but it' dbe funny if I kicked your ass in it.. Can that happen?",
  "id" : 20960127954,
  "in_reply_to_status_id" : 20958961739,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20961795964",
  "text" : "I think I need to buy the dude\/dudette who ever wrote this tender document I am reading a lapdance.. Chill the fuck out!",
  "id" : 20961795964,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20965645772",
  "geo" : { },
  "id_str" : "20965846324",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin very wrong, but in the right circumstances very very right.",
  "id" : 20965846324,
  "in_reply_to_status_id" : 20965645772,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20964722353",
  "geo" : { },
  "id_str" : "20965889165",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes grrrrrrrr... Star Trek :( :( :( Get with it and watch Star Wars 4-6 (dont bother with the prequels). Seen the A-Team yet?",
  "id" : 20965889165,
  "in_reply_to_status_id" : 20964722353,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarge Rushes",
      "screen_name" : "SRushes",
      "indices" : [ 41, 49 ],
      "id_str" : "1586204550",
      "id" : 1586204550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20967292150",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes good luck with the exams, now @srushes rant about UU makes sense :)",
  "id" : 20967292150,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Saunders",
      "screen_name" : "dsaundersdesign",
      "indices" : [ 0, 16 ],
      "id_str" : "17232871",
      "id" : 17232871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20971457753",
  "geo" : { },
  "id_str" : "20973444749",
  "in_reply_to_user_id" : 17232871,
  "text" : "@dsaundersdesign I went from 4 beta developers version to 4.02 there and its all good. I seen your msg as soon as I hit update though :\/",
  "id" : 20973444749,
  "in_reply_to_status_id" : 20971457753,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "dsaundersdesign",
  "in_reply_to_user_id_str" : "17232871",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 58, 65 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20974602802",
  "text" : "Proper coffee... Ohhhhh how I have missed ya.. Now WTF is @srushe so we can continute are chess game!",
  "id" : 20974602802,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20974647782",
  "geo" : { },
  "id_str" : "20975034302",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop s\/are\/our\/ :) Too much coffee and too much time working in postgres shell this morning to know any different. :)",
  "id" : 20975034302,
  "in_reply_to_status_id" : 20974647782,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20975571681",
  "text" : "SOAP::WSDL - I hope you are as easy to use as you say.. And you aren't teasing me!",
  "id" : 20975571681,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 13, 20 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20984404001",
  "text" : "wondering if @srushe will take the draw offer.. don't hink he will... but might as well try.",
  "id" : 20984404001,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 17, 24 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20987615223",
  "text" : "A draw!! Yay for @srushe for not expoliting my last mistake.. Not my fault though.. damn twitter.. damn ;)",
  "id" : 20987615223,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "heartlessbastards",
      "indices" : [ 66, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20955715890",
  "text" : "Ppl saying about three day working weeks on a Thursday morning... #heartlessbastards",
  "id" : 20955715890,
  "created_at" : "2010-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20878543701",
  "geo" : { },
  "id_str" : "20879111512",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin Loved the \"No, not THAT accountant\" part.. Classic :)",
  "id" : 20879111512,
  "in_reply_to_status_id" : 20878543701,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20880924767",
  "geo" : { },
  "id_str" : "20881275903",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings it probably went up its own arse! Had to happen.. Like its such a simple thing to do - but they fucked it all up!",
  "id" : 20881275903,
  "in_reply_to_status_id" : 20880924767,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 36, 43 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20889629128",
  "text" : "currently playing a chess game with @srushe - not doing as bad as usual. New tatic seems to be working.. 6 years and I haven't beat him yet",
  "id" : 20889629128,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 14, 25 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmccbeingabitch",
      "indices" : [ 75, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20896072320",
  "geo" : { },
  "id_str" : "20896252550",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @davidjrice - biznet did it.. So it must be coldfusion then? #swmccbeingabitch",
  "id" : 20896252550,
  "in_reply_to_status_id" : 20896072320,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20897069160",
  "text" : "reading emails from 2002.. *cringe*",
  "id" : 20897069160,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20898120616",
  "geo" : { },
  "id_str" : "20898695877",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings you validation nazi :) Stupid HTML. Stupid CSS. Drives me nuts! Hate it all! Grrrrr :D",
  "id" : 20898695877,
  "in_reply_to_status_id" : 20898120616,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "translink",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20899059690",
  "text" : "Its now 17:30 and i can finally look at translink.. and it found the bus route i want okay. Works for me. #translink",
  "id" : 20899059690,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20910801202",
  "geo" : { },
  "id_str" : "20913128169",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit class:) code hall of fame :)",
  "id" : 20913128169,
  "in_reply_to_status_id" : 20910801202,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "translink",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20913261596",
  "text" : "A good bit of snobbery about #translink going on. I don't like it. The site is awful like but it was a bit mob mentality for me earlier.",
  "id" : 20913261596,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20778087839",
  "geo" : { },
  "id_str" : "20779937890",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit hire :)",
  "id" : 20779937890,
  "in_reply_to_status_id" : 20778087839,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20785664232",
  "geo" : { },
  "id_str" : "20785879491",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings :D Even I know not to flatten that. Not that I would ever use such GUI propaganda. That site you get these from is gr8 :)",
  "id" : 20785879491,
  "in_reply_to_status_id" : 20785664232,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20786115720",
  "text" : "Am I wrong for using bing instead of google lately?",
  "id" : 20786115720,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20792956326",
  "text" : "Just got two stands for my work monitor.. Class. No more standing on books :)",
  "id" : 20792956326,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20796605962",
  "text" : "its only 3pm.. what the hell is going on :(",
  "id" : 20796605962,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20798001584",
  "geo" : { },
  "id_str" : "20798766753",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes I think the benefit frauds are worse, cos they aren't contributing anything.. If you don't work and can work you don't then... :)",
  "id" : 20798766753,
  "in_reply_to_status_id" : 20798001584,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20798001584",
  "geo" : { },
  "id_str" : "20799102404",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes That is a funny story though.. I don't see the point in it myself. Am hoping they know what they are doing.. But then again...",
  "id" : 20799102404,
  "in_reply_to_status_id" : 20798001584,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20803093534",
  "text" : "LONGEST. DAY. IN. A. LONG. TIME.",
  "id" : 20803093534,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20809213298",
  "text" : "3 Systems live in two days. Am on fire :) Now - ham time.",
  "id" : 20809213298,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20813173878",
  "geo" : { },
  "id_str" : "20814791007",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne s\/ham\/home. I can't even blame pred text... How is the PRINCE2 training going?",
  "id" : 20814791007,
  "in_reply_to_status_id" : 20813173878,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20819468407",
  "geo" : { },
  "id_str" : "20825505011",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne well jus think of all the extra dolla' whilst doing it. $$$",
  "id" : 20825505011,
  "in_reply_to_status_id" : 20819468407,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20825989300",
  "text" : "Spent over an hour cutting my garden this evening.. Front and back.... What a bitch.. Stupid grass growing!!",
  "id" : 20825989300,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20828311034",
  "text" : "Oh nooooooo... Went onto Fox mews there and Glenn Beck is our with his blackboard. It's like rubber necking... Noooooo",
  "id" : 20828311034,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20827154803",
  "geo" : { },
  "id_str" : "20828632943",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit am watching smallville while you two learn mew shizzle :)",
  "id" : 20828632943,
  "in_reply_to_status_id" : 20827154803,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20829384838",
  "geo" : { },
  "id_str" : "20830729294",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings we ain't on a plane??? Class film. Just class...",
  "id" : 20830729294,
  "in_reply_to_status_id" : 20829384838,
  "created_at" : "2010-08-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20691875047",
  "geo" : { },
  "id_str" : "20700846192",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne office drama :) Nothing like it when someone has had enough and leaves to create drama. Get comfy and make some popcorn :)",
  "id" : 20700846192,
  "in_reply_to_status_id" : 20691875047,
  "created_at" : "2010-08-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20717766057",
  "text" : "Worked like a champ today.. Two systems put 'live'.. And plans in the works to merge 10 systems into one code base tomorrow.. Oh yeah :D",
  "id" : 20717766057,
  "created_at" : "2010-08-09 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20716122860",
  "geo" : { },
  "id_str" : "20724031438",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin that's one good reason not to use it. Stupid work ppl.",
  "id" : 20724031438,
  "in_reply_to_status_id" : 20716122860,
  "created_at" : "2010-08-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20722669234",
  "geo" : { },
  "id_str" : "20724159874",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne ahem... See my advice from last week G ;) Do it :)",
  "id" : 20724159874,
  "in_reply_to_status_id" : 20722669234,
  "created_at" : "2010-08-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20726098735",
  "geo" : { },
  "id_str" : "20733672326",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne yay. Good for you. That's half the battle! Good for you. Loved your last blog article :)",
  "id" : 20733672326,
  "in_reply_to_status_id" : 20726098735,
  "created_at" : "2010-08-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20739111465",
  "geo" : { },
  "id_str" : "20739172964",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings big pile if crap. Awful film. Awful.",
  "id" : 20739172964,
  "in_reply_to_status_id" : 20739111465,
  "created_at" : "2010-08-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20616111600",
  "text" : "David Simon... That man can write!",
  "id" : 20616111600,
  "created_at" : "2010-08-08 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "No2Homosexua",
      "screen_name" : "SayNo2homosexua",
      "indices" : [ 0, 16 ],
      "id_str" : "176551640",
      "id" : 176551640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20633882642",
  "in_reply_to_user_id" : 172689260,
  "text" : "@sayno2homosexua doesn't know the difference between a bro and sis marrying and being homosexual. I Wonder how they can remember to breathe.",
  "id" : 20633882642,
  "created_at" : "2010-08-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "non_account",
  "in_reply_to_user_id_str" : "172689260",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20652397160",
  "text" : "The Untouchables is a great film. Here endeth the lesson...",
  "id" : 20652397160,
  "created_at" : "2010-08-08 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20654514438",
  "text" : "Princess Leia was out buying space groceries when this happened...",
  "id" : 20654514438,
  "created_at" : "2010-08-08 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20541269381",
  "text" : "Watching the Sat mornin cooking programmes.. Am starving and can't be assed to get out of bed. Dammit...",
  "id" : 20541269381,
  "created_at" : "2010-08-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20542340631",
  "text" : "Wayne Rooney's street striker. What the fuck is this?? Seriously.",
  "id" : 20542340631,
  "created_at" : "2010-08-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20544332885",
  "text" : "Porridge and two episodes of Dexter.... Awesome Saturday.",
  "id" : 20544332885,
  "created_at" : "2010-08-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20544521772",
  "geo" : { },
  "id_str" : "20545411709",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes I am loving it so far...",
  "id" : 20545411709,
  "in_reply_to_status_id" : 20544521772,
  "created_at" : "2010-08-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilson reid",
      "screen_name" : "wilsonreid",
      "indices" : [ 0, 11 ],
      "id_str" : "94781128",
      "id" : 94781128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20566414780",
  "text" : "@wilsonreid ya think ;)",
  "id" : 20566414780,
  "created_at" : "2010-08-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20572843882",
  "text" : "Catwoman is possibly the worst film ever made..... Yup...",
  "id" : 20572843882,
  "created_at" : "2010-08-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itsy",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20454729887",
  "text" : "Now using the latest release of itsy.. Hope it isn't as buggy as its previous version. its small and light though.. So lets see. #itsy",
  "id" : 20454729887,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 52, 59 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20455871852",
  "text" : "Dexys Midnight Runners playing in the offic. Me and @srushe are going to go postal in a bit. Makes me want to watch GrangeHill though!",
  "id" : 20455871852,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    }, {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 17, 29 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20458293875",
  "geo" : { },
  "id_str" : "20460414941",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings @rickydunlop - don't you two be getting cocky! I remember when version control was vodoo magic to you ppl! :)",
  "id" : 20460414941,
  "in_reply_to_status_id" : 20458293875,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20460699682",
  "geo" : { },
  "id_str" : "20461376557",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings right back at cha! Only with svn. I should get to know git.. I just don't have the time.. Unless i do on my freetime..",
  "id" : 20461376557,
  "in_reply_to_status_id" : 20460699682,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20463032698",
  "text" : "Having to reboot your machine on a Friday. How annoying. Hopefully VMWare wont fuck up. Stupid bluetooth on the mac.. How i hate ye!",
  "id" : 20463032698,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rocknroll",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20493114973",
  "text" : "Watching the soaps with the parents on a Friday night. #rocknroll",
  "id" : 20493114973,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20409046742",
  "geo" : { },
  "id_str" : "20410220616",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne no buts G. If you aren't happy...",
  "id" : 20410220616,
  "in_reply_to_status_id" : 20409046742,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20417429114",
  "text" : "I find myself saying \"What a wanker\" when watching Glenn Beck. Watched him on the TV for about 5mins, and I must have said it 10,562 times!",
  "id" : 20417429114,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20418728618",
  "geo" : { },
  "id_str" : "20419343510",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Yup. That is just how big a knob that man is!",
  "id" : 20419343510,
  "in_reply_to_status_id" : 20418728618,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20382456639",
  "text" : "worked like a bastard today.. got lots done.. Hope it means a good tomorrow :D",
  "id" : 20382456639,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20382475178",
  "text" : "feckin thing i use for twitter now... grrrrrr...",
  "id" : 20382475178,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20382513466",
  "text" : "I want to try and fly a tank!",
  "id" : 20382513466,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilson reid",
      "screen_name" : "wilsonreid",
      "indices" : [ 0, 11 ],
      "id_str" : "94781128",
      "id" : 94781128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20382839009",
  "text" : "@wilsonreid you gotta a spare tank and the means to get it up in the air.. Lets give it a go - and try Lough Neagh as a landing pad :)",
  "id" : 20382839009,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilson reid",
      "screen_name" : "wilsonreid",
      "indices" : [ 0, 11 ],
      "id_str" : "94781128",
      "id" : 94781128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20384234637",
  "text" : "@wilsonreid with that sort of attitude I don't want you in the tank with me then!",
  "id" : 20384234637,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20399718599",
  "text" : "Ian jnr making sense.... What is going on??? http:\/\/www.bbc.co.uk\/news\/uk-northern-ireland-10879120",
  "id" : 20399718599,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20401535196",
  "geo" : { },
  "id_str" : "20408059518",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne apply for a new job! Appppppllllllyyyyyyy :)",
  "id" : 20408059518,
  "in_reply_to_status_id" : 20401535196,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20292623575",
  "geo" : { },
  "id_str" : "20293021323",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe want me to have a stab - i can be subtle :)",
  "id" : 20293021323,
  "in_reply_to_status_id" : 20292623575,
  "created_at" : "2010-08-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20335998812",
  "text" : "A-Team was brilliant!! Loved the first twenty minutes.. The rest was good, but the first twenty",
  "id" : 20335998812,
  "created_at" : "2010-08-04 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20211636267",
  "text" : "cleaned my desktop for the first time since November.. Spotlight just makes it so handy to keep everything all over du place.",
  "id" : 20211636267,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20215818557",
  "text" : "seeing the a-team tonight... Oh yeah bitches.. \"Doooo do do dooooooo. Do do dooo.. Do do do do do doooo. Doooo do do do dooooooo\"",
  "id" : 20215818557,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20217884242",
  "geo" : { },
  "id_str" : "20218278791",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes anyone that i know that has seen it says its great. Lets hope. Hollywood are bound to get at least one thing from the 80's right",
  "id" : 20218278791,
  "in_reply_to_status_id" : 20217884242,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20218932290",
  "text" : "@rforbes_simpson too late for a comeback. gay gay gay :)",
  "id" : 20218932290,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20217884242",
  "geo" : { },
  "id_str" : "20219935601",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes but if they screw up Tron I will be really annoyed. But so far it looks good. But you never know.",
  "id" : 20219935601,
  "in_reply_to_status_id" : 20217884242,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20224673925",
  "geo" : { },
  "id_str" : "20225312493",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit you must have long arms to get you both in ;)",
  "id" : 20225312493,
  "in_reply_to_status_id" : 20224673925,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20227482916",
  "text" : "no ateam tonight it looks like.. to be deferred.",
  "id" : 20227482916,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 7, 14 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20246338263",
  "text" : "I wish @srushe would stop castling.. Or at least tell me how to do it in gameknot.. :)",
  "id" : 20246338263,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 41, 48 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20246560483",
  "text" : "Then is the conditional move. I can hear @srushe sarcastic comment :) Law of averages I have to beat you once 6 years and counting though :)",
  "id" : 20246560483,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20120349478",
  "text" : "Woke up to Loose Women on the tee vee... Vile vile vile",
  "id" : 20120349478,
  "created_at" : "2010-08-02 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20125884033",
  "geo" : { },
  "id_str" : "20126223297",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop Pussy =) Shell.. Shell..... Shell....",
  "id" : 20126223297,
  "in_reply_to_status_id" : 20125884033,
  "created_at" : "2010-08-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20126249271",
  "geo" : { },
  "id_str" : "20130297420",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop Yeah you can! :) You just need to think a bit more than having diagrams all over the place...",
  "id" : 20130297420,
  "in_reply_to_status_id" : 20126249271,
  "created_at" : "2010-08-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20134297749",
  "geo" : { },
  "id_str" : "20147402801",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe shaddap!!!! :)",
  "id" : 20147402801,
  "in_reply_to_status_id" : 20134297749,
  "created_at" : "2010-08-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20170495690",
  "text" : "@rforbes_simpson bet you it aint great for the poor fucker having to look at you though ;)",
  "id" : 20170495690,
  "created_at" : "2010-08-02 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]