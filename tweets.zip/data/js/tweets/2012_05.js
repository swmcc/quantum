Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 15, 28 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 29, 43 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 44, 60 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208273601319800833",
  "geo" : { },
  "id_str" : "208329040757661696",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @RickyHassard @peter_omalley @michaelnsimpson you are obsessed with farting!",
  "id" : 208329040757661696,
  "in_reply_to_status_id" : 208273601319800833,
  "created_at" : "2012-05-31 22:48:08 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208116947974504448",
  "geo" : { },
  "id_str" : "208328924005011456",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight oh I haven't a clue yet - its getting mixed reviews at the cinema so am on the wall about it now :(",
  "id" : 208328924005011456,
  "in_reply_to_status_id" : 208116947974504448,
  "created_at" : "2012-05-31 22:47:40 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208324864837304320",
  "geo" : { },
  "id_str" : "208328788717740034",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard actually sorry about that - but fuck it was funny - cos me and Pete started to notice the smell just as you rang! :D",
  "id" : 208328788717740034,
  "in_reply_to_status_id" : 208324864837304320,
  "created_at" : "2012-05-31 22:47:08 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 14, 28 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 29, 45 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 46, 60 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208325331197771776",
  "geo" : { },
  "id_str" : "208328659780648960",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @jenporterhall @michaelnsimpson @peter_omalley I am so happy right now :D I will take a pic of my back seat tomorrow :D",
  "id" : 208328659780648960,
  "in_reply_to_status_id" : 208325331197771776,
  "created_at" : "2012-05-31 22:46:37 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 3, 16 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 21, 27 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RickyHassard\/status\/208324864837304320\/photo\/1",
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/4qFJeDZe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuQeXF7CQAAn18j.jpg",
      "id_str" : "208324864841498624",
      "id" : 208324864841498624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuQeXF7CQAAn18j.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/4qFJeDZe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208328586304827392",
  "text" : "RT @RickyHassard: If @swmcc offers u a lift home...get a taxi! http:\/\/t.co\/4qFJeDZe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 3, 9 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RickyHassard\/status\/208324864837304320\/photo\/1",
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/4qFJeDZe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AuQeXF7CQAAn18j.jpg",
        "id_str" : "208324864841498624",
        "id" : 208324864841498624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuQeXF7CQAAn18j.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/4qFJeDZe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208324864837304320",
    "text" : "If @swmcc offers u a lift home...get a taxi! http:\/\/t.co\/4qFJeDZe",
    "id" : 208324864837304320,
    "created_at" : "2012-05-31 22:31:33 +0000",
    "user" : {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "protected" : false,
      "id_str" : "5684272",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1317084795\/Screen_shot_2011-04-19_at_13.00.12_normal.png",
      "id" : 5684272,
      "verified" : false
    }
  },
  "id" : 208328586304827392,
  "created_at" : "2012-05-31 22:46:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 3, 17 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "The A21 Campaign",
      "screen_name" : "TheA21Campaign",
      "indices" : [ 123, 138 ],
      "id_str" : "23847000",
      "id" : 23847000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "endhumantrafficking",
      "indices" : [ 102, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/Drshfs7s",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=dleaF_D2tG4&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=dleaF_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207963516592857088",
  "text" : "RT @jenporterhall: Please take a second to watch this..because you are free to.. http:\/\/t.co\/Drshfs7s #endhumantrafficking @TheA21Campaign",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The A21 Campaign",
        "screen_name" : "TheA21Campaign",
        "indices" : [ 104, 119 ],
        "id_str" : "23847000",
        "id" : 23847000
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "endhumantrafficking",
        "indices" : [ 83, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/Drshfs7s",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=dleaF_D2tG4&feature=youtube_gdata_player",
        "display_url" : "youtube.com\/watch?v=dleaF_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "207960674939322368",
    "text" : "Please take a second to watch this..because you are free to.. http:\/\/t.co\/Drshfs7s #endhumantrafficking @TheA21Campaign",
    "id" : 207960674939322368,
    "created_at" : "2012-05-30 22:24:23 +0000",
    "user" : {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "protected" : false,
      "id_str" : "227493010",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2257082551\/DSCF9612_normal.jpg",
      "id" : 227493010,
      "verified" : false
    }
  },
  "id" : 207963516592857088,
  "created_at" : "2012-05-30 22:35:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cosyouisavampirebitcho",
      "indices" : [ 84, 107 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207962158288478209",
  "geo" : { },
  "id_str" : "207963132101001216",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Its past 10pm.... How can you still type when you are in the form of a bat? #cosyouisavampirebitcho!!!!",
  "id" : 207963132101001216,
  "in_reply_to_status_id" : 207962158288478209,
  "created_at" : "2012-05-30 22:34:09 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207957172569649152",
  "text" : "Was in my old bedroom there at my folks! Installing a tv.. Haven't been in that room in years. Nostalgia...",
  "id" : 207957172569649152,
  "created_at" : "2012-05-30 22:10:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207954463489662976",
  "geo" : { },
  "id_str" : "207956897754652673",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall straight out of 1987!",
  "id" : 207956897754652673,
  "in_reply_to_status_id" : 207954463489662976,
  "created_at" : "2012-05-30 22:09:22 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207927302623993857",
  "geo" : { },
  "id_str" : "207929385762828290",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR not a chance.... Even if I could.... I'll try if you go ginger!",
  "id" : 207929385762828290,
  "in_reply_to_status_id" : 207927302623993857,
  "created_at" : "2012-05-30 20:20:03 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207919263082754048",
  "text" : "Like a mullet just winds me up. People that have hair and abuse it...",
  "id" : 207919263082754048,
  "created_at" : "2012-05-30 19:39:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207919085823082496",
  "text" : "Crumlin Tescos.... Seen a dude with a mullet. I kid you not.. Crumlin - the 80's never left... Glenavy - the 80's never came :)",
  "id" : 207919085823082496,
  "created_at" : "2012-05-30 19:39:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207842521139789824",
  "geo" : { },
  "id_str" : "207854138065825792",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore but its a conference - you get to be a rockstar for the day :) :) :)",
  "id" : 207854138065825792,
  "in_reply_to_status_id" : 207842521139789824,
  "created_at" : "2012-05-30 15:21:02 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207815088768434177",
  "geo" : { },
  "id_str" : "207817827581829120",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore You just aint with the kool kids bitch! :D",
  "id" : 207817827581829120,
  "in_reply_to_status_id" : 207815088768434177,
  "created_at" : "2012-05-30 12:56:45 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 20, 36 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207811273960857600",
  "text" : "I would easily beat @michaelnsimpson  in a fight... FACT... ITS A FAT",
  "id" : 207811273960857600,
  "created_at" : "2012-05-30 12:30:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207772622409310210",
  "geo" : { },
  "id_str" : "207772813464059904",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues oh I asked my Dad. He said he doesn't know of any that would do that - best bet is kiwk fit :( His words :(",
  "id" : 207772813464059904,
  "in_reply_to_status_id" : 207772622409310210,
  "created_at" : "2012-05-30 09:57:53 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207753432214417408",
  "text" : "This time next week will be virtual Monday - this pleases me more than you know...",
  "id" : 207753432214417408,
  "created_at" : "2012-05-30 08:40:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207753281303355392",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings congratulations for today Ant!!! :D",
  "id" : 207753281303355392,
  "created_at" : "2012-05-30 08:40:16 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 76, 89 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207547342239432704",
  "geo" : { },
  "id_str" : "207548091627356160",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson technically it was a date. But don't forget @RickyHassard saying \"Can I come and make it a threesome?.",
  "id" : 207548091627356160,
  "in_reply_to_status_id" : 207547342239432704,
  "created_at" : "2012-05-29 19:04:55 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 79, 92 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207547342239432704",
  "geo" : { },
  "id_str" : "207547697287274497",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson technically it was a date. But not lets forget @RickyHassard saying \"Can I make it a threesome?\".",
  "id" : 207547697287274497,
  "in_reply_to_status_id" : 207547342239432704,
  "created_at" : "2012-05-29 19:03:21 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207547342239432704",
  "geo" : { },
  "id_str" : "207547469192634368",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson",
  "id" : 207547469192634368,
  "in_reply_to_status_id" : 207547342239432704,
  "created_at" : "2012-05-29 19:02:27 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/207458396918657024\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/KAs6bJMQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuEKUBZCMAAz7EX.png",
      "id_str" : "207458396922851328",
      "id" : 207458396922851328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuEKUBZCMAAz7EX.png",
      "sizes" : [ {
        "h" : 122,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 88,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 122,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 122,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 122,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/KAs6bJMQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207458396918657024",
  "text" : "What I wanted to do was \"register\" with them \/and then\/ spend some money transferring a few domains.. http:\/\/t.co\/KAs6bJMQ",
  "id" : 207458396918657024,
  "created_at" : "2012-05-29 13:08:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207457648428322817",
  "text" : "One way to get on my \"crap company\" section is to tell me that my user registration failed only to send me an email saying 'Welcome to'",
  "id" : 207457648428322817,
  "created_at" : "2012-05-29 13:05:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsIwoulddoforaboojum",
      "indices" : [ 21, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207453382963765249",
  "text" : "Cut off my own cock. #thingsIwoulddoforaboojum",
  "id" : 207453382963765249,
  "created_at" : "2012-05-29 12:48:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207427052834521089",
  "geo" : { },
  "id_str" : "207427668914876416",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Baking Goddess cup.. Simples...",
  "id" : 207427668914876416,
  "in_reply_to_status_id" : 207427052834521089,
  "created_at" : "2012-05-29 11:06:24 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsnottobeproudabout",
      "indices" : [ 75, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207426037762633728",
  "text" : "Getting caught by your own TODO: 357 days after writing it... Awesome.. :D #thingsnottobeproudabout",
  "id" : 207426037762633728,
  "created_at" : "2012-05-29 10:59:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207411499768090624",
  "geo" : { },
  "id_str" : "207412712207159298",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard Love that hashtag :D",
  "id" : 207412712207159298,
  "in_reply_to_status_id" : 207411499768090624,
  "created_at" : "2012-05-29 10:06:58 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207389574509494272",
  "text" : "Clouds are back :( This displeases me greatly.",
  "id" : 207389574509494272,
  "created_at" : "2012-05-29 08:35:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207373277168025601",
  "geo" : { },
  "id_str" : "207389469555441664",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne only thing uncool about you is this hating of the sun gods....",
  "id" : 207389469555441664,
  "in_reply_to_status_id" : 207373277168025601,
  "created_at" : "2012-05-29 08:34:37 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207240696699162624",
  "geo" : { },
  "id_str" : "207244844790325249",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq sweet - will watch that tomorrow evening when there is fuck all on. Not long till I get my DNS sorted for swm.cc as well :D",
  "id" : 207244844790325249,
  "in_reply_to_status_id" : 207240696699162624,
  "created_at" : "2012-05-28 22:59:56 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetni",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207235635038273536",
  "text" : "We should talk about more the things we do well as a country (aside from bombing) and less about the titanic.. Just saying like! #tweetni",
  "id" : 207235635038273536,
  "created_at" : "2012-05-28 22:23:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetni",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207235316547985409",
  "text" : "That was the best nights TV viewing I have had in a long time. So proud that GoT is filmed here.. Lets hope it continues! #tweetni",
  "id" : 207235316547985409,
  "created_at" : "2012-05-28 22:22:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207234949651243011",
  "text" : "RT @substack: You don't need an ideology to write tests.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "207229455901532160",
    "text" : "You don't need an ideology to write tests.",
    "id" : 207229455901532160,
    "created_at" : "2012-05-28 21:58:47 +0000",
    "user" : {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 207234949651243011,
  "created_at" : "2012-05-28 22:20:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "everybodylovesstevie",
      "indices" : [ 119, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207210573820211201",
  "text" : "Sister sent over to guilt me cos I haven't been over at my parents since Thursday night... It has only been four days. #everybodylovesstevie",
  "id" : 207210573820211201,
  "created_at" : "2012-05-28 20:43:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wow",
      "indices" : [ 30, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207206187358363649",
  "text" : "Mad Men.... Just amazing..... #wow",
  "id" : 207206187358363649,
  "created_at" : "2012-05-28 20:26:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207194560265338880",
  "geo" : { },
  "id_str" : "207200158935560194",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp good luck in your exam :)",
  "id" : 207200158935560194,
  "in_reply_to_status_id" : 207194560265338880,
  "created_at" : "2012-05-28 20:02:22 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207197854928875520",
  "geo" : { },
  "id_str" : "207198874455130112",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall ha ha :) \"My phone. My phone. My phone\".... :)",
  "id" : 207198874455130112,
  "in_reply_to_status_id" : 207197854928875520,
  "created_at" : "2012-05-28 19:57:15 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 17, 31 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207187860158291968",
  "geo" : { },
  "id_str" : "207190485842935810",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @jenporterhall I don't do proportional responses. She started it. She got me a second time on the stairs too.",
  "id" : 207190485842935810,
  "in_reply_to_status_id" : 207187860158291968,
  "created_at" : "2012-05-28 19:23:55 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 3, 17 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/207182086765944833\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/vW1rhhkM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuAPAp3CIAIBMir.jpg",
      "id_str" : "207182086770139138",
      "id" : 207182086770139138,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuAPAp3CIAIBMir.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/vW1rhhkM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207182086765944833",
  "text" : "So @jenporterhall has given me permission to post this after her soaking!!! Think she was a bit shocked!!! http:\/\/t.co\/vW1rhhkM",
  "id" : 207182086765944833,
  "created_at" : "2012-05-28 18:50:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207168772174389249",
  "geo" : { },
  "id_str" : "207168958124670976",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson none was taken - was too busy laughing :)",
  "id" : 207168958124670976,
  "in_reply_to_status_id" : 207168772174389249,
  "created_at" : "2012-05-28 17:58:23 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 7, 21 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207168135831359489",
  "text" : "Soaked @jenporterhall in the Mace car park this evening. Only had to wait beside a stinking skip for the guts of an hour. Worth it!",
  "id" : 207168135831359489,
  "created_at" : "2012-05-28 17:55:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 35, 48 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairplay",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207107237200670720",
  "text" : "Has to be said.. I just called out @RickyHassard there and he ended up bitch slapping me a million times over!!! #fairplay :)",
  "id" : 207107237200670720,
  "created_at" : "2012-05-28 13:53:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 13, 22 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207099665714380801",
  "geo" : { },
  "id_str" : "207101780000112640",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @manyhues wants the name of a garage that will do aircon servicing in the lisburn area that aint kwikfit.",
  "id" : 207101780000112640,
  "in_reply_to_status_id" : 207099665714380801,
  "created_at" : "2012-05-28 13:31:26 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 78, 90 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207090858623897600",
  "geo" : { },
  "id_str" : "207096999726690306",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues hmmm I use a fella called Artie.. But he's up in Dundrod... I think @niall_adams has used someone though - over to you Nail!",
  "id" : 207096999726690306,
  "in_reply_to_status_id" : 207090858623897600,
  "created_at" : "2012-05-28 13:12:27 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207074129063579648",
  "text" : "I'm scared if I go out for lunch I wont come back in here.. I like my job - but look at that afternoon.. Awesome :D",
  "id" : 207074129063579648,
  "created_at" : "2012-05-28 11:41:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207069337843007488",
  "geo" : { },
  "id_str" : "207073960884580352",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne are you off today G? :( Ohhhhh that's unfair lol.. Enjoy this glorious day :D",
  "id" : 207073960884580352,
  "in_reply_to_status_id" : 207069337843007488,
  "created_at" : "2012-05-28 11:40:54 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207044600492339200",
  "geo" : { },
  "id_str" : "207047486848761856",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne cottage cheese = wrong. WRONG WRONG WRONG",
  "id" : 207047486848761856,
  "in_reply_to_status_id" : 207044600492339200,
  "created_at" : "2012-05-28 09:55:42 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206859387451613184",
  "geo" : { },
  "id_str" : "206859717874692096",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq has been deleted... And also.. I can't look at that too much or I will melt!!!!! :)",
  "id" : 206859717874692096,
  "in_reply_to_status_id" : 206859387451613184,
  "created_at" : "2012-05-27 21:29:34 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/lvYc0sjc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=p-uWNZdK7Gs",
      "display_url" : "youtube.com\/watch?v=p-uWNZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206859213031489537",
  "text" : "Ending an awesome weekend by watching this... http:\/\/t.co\/lvYc0sjc",
  "id" : 206859213031489537,
  "created_at" : "2012-05-27 21:27:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206858652202708993",
  "geo" : { },
  "id_str" : "206858821124096000",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq Oh I am not - I am to blame :( Also I see I \"outed\" you on your rant you sent me lol :D Awesome :D",
  "id" : 206858821124096000,
  "in_reply_to_status_id" : 206858652202708993,
  "created_at" : "2012-05-27 21:26:00 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "luckyiampretty",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206858479158312961",
  "text" : "Shit... seems I set the reminder for 10pm... I am the weakest chain in my link :( #luckyiampretty",
  "id" : 206858479158312961,
  "created_at" : "2012-05-27 21:24:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 84, 97 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 98, 112 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 113, 129 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206848441110888448",
  "text" : "I fail at beards btw.... It was too hot this weekend to have a beard so I shaved... @RickyHassard @peter_omalley @michaelnsimpson",
  "id" : 206848441110888448,
  "created_at" : "2012-05-27 20:44:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/yLVEQ2yK",
      "expanded_url" : "http:\/\/www.lisburncity.gov.uk\/your-city-council\/council-departments\/environmental-services\/environmental-health\/dog-control-service\/out-of-hours-dog-warden-service\/",
      "display_url" : "lisburncity.gov.uk\/your-city-coun\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "206761575573487616",
  "geo" : { },
  "id_str" : "206763659966423040",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll local council http:\/\/t.co\/yLVEQ2yK",
  "id" : 206763659966423040,
  "in_reply_to_status_id" : 206761575573487616,
  "created_at" : "2012-05-27 15:07:52 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Tracy Adams",
      "screen_name" : "tracy2710",
      "indices" : [ 69, 79 ],
      "id_str" : "241879307",
      "id" : 241879307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206505302164647936",
  "geo" : { },
  "id_str" : "206509512302137344",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley yup - but he does it probably cos of @tracy2710 and he's probably drunk. You are sober and tweeting about it",
  "id" : 206509512302137344,
  "in_reply_to_status_id" : 206505302164647936,
  "created_at" : "2012-05-26 22:17:59 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikes Man Cards",
      "screen_name" : "mikesmancards",
      "indices" : [ 68, 82 ],
      "id_str" : "591285548",
      "id" : 591285548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206508183471136768",
  "text" : "Anyone that knows the awesome @michanelnsimpson feel free to follow @mikesmancards :) :)",
  "id" : 206508183471136768,
  "created_at" : "2012-05-26 22:12:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206506404662624257",
  "geo" : { },
  "id_str" : "206506953772507136",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley yes we do!! :D",
  "id" : 206506953772507136,
  "in_reply_to_status_id" : 206506404662624257,
  "created_at" : "2012-05-26 22:07:49 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206503977305636864",
  "geo" : { },
  "id_str" : "206504691654332416",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson a twitter feed of his unmanly doings... in tweet form... give me a second ;)",
  "id" : 206504691654332416,
  "in_reply_to_status_id" : 206503977305636864,
  "created_at" : "2012-05-26 21:58:49 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206498220107501568",
  "geo" : { },
  "id_str" : "206503354313093121",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley I am framing that last tweet..... Not unmanly though - its just FUCKING wrong!!!!",
  "id" : 206503354313093121,
  "in_reply_to_status_id" : 206498220107501568,
  "created_at" : "2012-05-26 21:53:30 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206491721662595072",
  "geo" : { },
  "id_str" : "206495649800257536",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson that's a new record. He lost all his cards before the weeks even starts.....",
  "id" : 206495649800257536,
  "in_reply_to_status_id" : 206491721662595072,
  "created_at" : "2012-05-26 21:22:54 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206484468381388800",
  "geo" : { },
  "id_str" : "206487095894736897",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson LOSS OF ALL MAN CARDS NEXT WEEK FOR MENTIONING THE EUROVISION SONG CONTEST ON TWITTER IN A POSITIVE POSTURE!!!!!!!!",
  "id" : 206487095894736897,
  "in_reply_to_status_id" : 206484468381388800,
  "created_at" : "2012-05-26 20:48:54 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206446313242497025",
  "geo" : { },
  "id_str" : "206485659354021888",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Do not tease with your baking!! Open a shop!!! :)",
  "id" : 206485659354021888,
  "in_reply_to_status_id" : 206446313242497025,
  "created_at" : "2012-05-26 20:43:12 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206446301813030913",
  "text" : "Am pretty sure I have just sunburnt my head........ Pain in the ass....",
  "id" : 206446301813030913,
  "created_at" : "2012-05-26 18:06:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 30, 41 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206364003885264898",
  "geo" : { },
  "id_str" : "206368991982256129",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams @alana_doll if it is an Alana type brownie you get a high five.... Nothing short of that greatness though!",
  "id" : 206368991982256129,
  "in_reply_to_status_id" : 206364003885264898,
  "created_at" : "2012-05-26 12:59:36 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206355649595052033",
  "text" : "Best. Saturday. Ever... Bank holiday weekend next weekend as well... Hope for this weather tweeppl!!!!",
  "id" : 206355649595052033,
  "created_at" : "2012-05-26 12:06:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206239727588876288",
  "geo" : { },
  "id_str" : "206312863806144513",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard that was four hours ago dude!!! That was just afer 6? I just had an epic lie in ;)",
  "id" : 206312863806144513,
  "in_reply_to_status_id" : 206239727588876288,
  "created_at" : "2012-05-26 09:16:34 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nohighfivesforthefridaygrumpus",
      "indices" : [ 33, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206142639718940672",
  "geo" : { },
  "id_str" : "206312471634526208",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams *VIRTUAL HIGH FIVE* #nohighfivesforthefridaygrumpus",
  "id" : 206312471634526208,
  "in_reply_to_status_id" : 206142639718940672,
  "created_at" : "2012-05-26 09:15:00 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206283621659709442",
  "geo" : { },
  "id_str" : "206312368257503232",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson FUCK UP! :) Everyone has bad days - just yours was on the best. work. day. ever. Make up for it next Friday :D",
  "id" : 206312368257503232,
  "in_reply_to_status_id" : 206283621659709442,
  "created_at" : "2012-05-26 09:14:36 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206141881841754114",
  "geo" : { },
  "id_str" : "206142387293130752",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams what for? ;)",
  "id" : 206142387293130752,
  "in_reply_to_status_id" : 206141881841754114,
  "created_at" : "2012-05-25 21:59:09 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wasteofafriday",
      "indices" : [ 106, 121 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206131023430422528",
  "geo" : { },
  "id_str" : "206140944343511040",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @michaelnsimpson it won't work. Best Friday in history and he spent most if it fucked off... #wasteofafriday",
  "id" : 206140944343511040,
  "in_reply_to_status_id" : 206131023430422528,
  "created_at" : "2012-05-25 21:53:25 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206073034161926144",
  "geo" : { },
  "id_str" : "206091979044552704",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe :D Aye - lets hope the hot weather continues :)",
  "id" : 206091979044552704,
  "in_reply_to_status_id" : 206073034161926144,
  "created_at" : "2012-05-25 18:38:51 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206083557683245058",
  "geo" : { },
  "id_str" : "206091862275133440",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq congrats :D",
  "id" : 206091862275133440,
  "in_reply_to_status_id" : 206083557683245058,
  "created_at" : "2012-05-25 18:38:23 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206010567843000320",
  "geo" : { },
  "id_str" : "206011899136057345",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight aye - well I hear it all the time from other sources. IT industry is full of ppl like that :)",
  "id" : 206011899136057345,
  "in_reply_to_status_id" : 206010567843000320,
  "created_at" : "2012-05-25 13:20:38 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/pqmUBuQ",
      "expanded_url" : "http:\/\/dilbert.com\/strips\/comic\/2012-05-25\/",
      "display_url" : "dilbert.com\/strips\/comic\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205994164675031041",
  "text" : "http:\/\/t.co\/pqmUBuQ",
  "id" : 205994164675031041,
  "created_at" : "2012-05-25 12:10:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MissionV",
      "screen_name" : "MissionVHQ",
      "indices" : [ 3, 14 ],
      "id_str" : "257965922",
      "id" : 257965922
    }, {
      "name" : "Digital Belfast",
      "screen_name" : "DigitalBelfast",
      "indices" : [ 19, 34 ],
      "id_str" : "316808549",
      "id" : 316808549
    }, {
      "name" : "Fraser Leonard",
      "screen_name" : "FraserLeonard",
      "indices" : [ 47, 61 ],
      "id_str" : "541959342",
      "id" : 541959342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205981690726854656",
  "text" : "RT @MissionVHQ: RT @DigitalBelfast 10 year old @FraserLeonard builds site for school entrepreneurial week - and sells advertising space  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twimbow.com\" rel=\"nofollow\"\u003ETwimbow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Digital Belfast",
        "screen_name" : "DigitalBelfast",
        "indices" : [ 3, 18 ],
        "id_str" : "316808549",
        "id" : 316808549
      }, {
        "name" : "Fraser Leonard",
        "screen_name" : "FraserLeonard",
        "indices" : [ 31, 45 ],
        "id_str" : "541959342",
        "id" : 541959342
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/XWItucvo",
        "expanded_url" : "http:\/\/fb.me\/1SsPxKhJ9",
        "display_url" : "fb.me\/1SsPxKhJ9"
      } ]
    },
    "geo" : { },
    "id_str" : "205961555785953280",
    "text" : "RT @DigitalBelfast 10 year old @FraserLeonard builds site for school entrepreneurial week - and sells advertising space http:\/\/t.co\/XWItucvo",
    "id" : 205961555785953280,
    "created_at" : "2012-05-25 10:00:36 +0000",
    "user" : {
      "name" : "MissionV",
      "screen_name" : "MissionVHQ",
      "protected" : false,
      "id_str" : "257965922",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1338385833\/mv_normal.jpg",
      "id" : 257965922,
      "verified" : false
    }
  },
  "id" : 205981690726854656,
  "created_at" : "2012-05-25 11:20:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 11, 17 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205929559298809856",
  "text" : "Day two of @swmcc tweets, let's ruin his Friday for him!",
  "id" : 205929559298809856,
  "created_at" : "2012-05-25 07:53:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/205919082619486208\/photo\/1",
      "indices" : [ 40, 59 ],
      "url" : "http:\/\/t.co\/krLTass",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtuSUIxCQAEtVyW.jpg",
      "id_str" : "205919082623680513",
      "id" : 205919082623680513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtuSUIxCQAEtVyW.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/krLTass"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205919082619486208",
  "text" : "The beautiful man makes a good point :) http:\/\/t.co\/krLTass",
  "id" : 205919082619486208,
  "created_at" : "2012-05-25 07:11:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205905944004149248",
  "geo" : { },
  "id_str" : "205909607216971776",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson that only stood when I thought you did support on Monday. :) Fair enough though. I forgot I did this.",
  "id" : 205909607216971776,
  "in_reply_to_status_id" : 205905944004149248,
  "created_at" : "2012-05-25 06:34:10 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205787859238649858",
  "geo" : { },
  "id_str" : "205791955328843776",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist nice :D",
  "id" : 205791955328843776,
  "in_reply_to_status_id" : 205787859238649858,
  "created_at" : "2012-05-24 22:46:40 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205785153296015360",
  "geo" : { },
  "id_str" : "205786981857370112",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist pic or shut the fuck up",
  "id" : 205786981857370112,
  "in_reply_to_status_id" : 205785153296015360,
  "created_at" : "2012-05-24 22:26:54 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "personalgrowththatiagreewiththis",
      "indices" : [ 32, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 31 ],
      "url" : "http:\/\/t.co\/ouZjSJh",
      "expanded_url" : "http:\/\/chrisyeh.blogspot.co.uk\/2012\/04\/speak-up-silicon-valley.html",
      "display_url" : "chrisyeh.blogspot.co.uk\/2012\/04\/speak-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205786934059089922",
  "text" : "*FIST PUMP* http:\/\/t.co\/ouZjSJh #personalgrowththatiagreewiththis",
  "id" : 205786934059089922,
  "created_at" : "2012-05-24 22:26:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 3, 11 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205782334316883968",
  "text" : "RT @dcurtis: It's even more obvious now that Facebook's Instagram acquisition was an insurance policy. \n\n(It's also clearer why Instagra ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205753463857098752",
    "text" : "It's even more obvious now that Facebook's Instagram acquisition was an insurance policy. \n\n(It's also clearer why Instagram chose to sell.)",
    "id" : 205753463857098752,
    "created_at" : "2012-05-24 20:13:43 +0000",
    "user" : {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "protected" : false,
      "id_str" : "9395832",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3586312198\/4f90d52a9416842731420c9e3cb1ec9f_normal.png",
      "id" : 9395832,
      "verified" : false
    }
  },
  "id" : 205782334316883968,
  "created_at" : "2012-05-24 22:08:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 17, 33 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205663219199651840",
  "text" : "No ice cream for @michaelnsimpson though, I don't really like him that much",
  "id" : 205663219199651840,
  "created_at" : "2012-05-24 14:15:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 33, 45 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205663006825250816",
  "text" : "Warm today sir - going to go buy @niall_adams an ice cream.",
  "id" : 205663006825250816,
  "created_at" : "2012-05-24 14:14:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Saunders",
      "screen_name" : "dsaundersdesign",
      "indices" : [ 0, 16 ],
      "id_str" : "17232871",
      "id" : 17232871
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 30, 42 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205658271997104131",
  "geo" : { },
  "id_str" : "205659470477524992",
  "in_reply_to_user_id" : 17232871,
  "text" : "@dsaundersdesign not me - its @niall_adams tweeting on my behalf - didn't sign out of the iPad.",
  "id" : 205659470477524992,
  "in_reply_to_status_id" : 205658271997104131,
  "created_at" : "2012-05-24 14:00:13 +0000",
  "in_reply_to_screen_name" : "dsaundersdesign",
  "in_reply_to_user_id_str" : "17232871",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205658017264447490",
  "geo" : { },
  "id_str" : "205659272456048640",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @niall_adams has my account logged in on the iPad. I am allowing him to be my proxy - for the craic :)",
  "id" : 205659272456048640,
  "in_reply_to_status_id" : 205658017264447490,
  "created_at" : "2012-05-24 13:59:26 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205658849762492418",
  "text" : "3 minutes - new record \\o\/",
  "id" : 205658849762492418,
  "created_at" : "2012-05-24 13:57:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205658161909202945",
  "text" : "Off for the 3pm poo",
  "id" : 205658161909202945,
  "created_at" : "2012-05-24 13:55:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205657701311717376",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson seriously, a dick.",
  "id" : 205657701311717376,
  "created_at" : "2012-05-24 13:53:11 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205642270035296256",
  "geo" : { },
  "id_str" : "205642519537655809",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson you're such a dick",
  "id" : 205642519537655809,
  "in_reply_to_status_id" : 205642270035296256,
  "created_at" : "2012-05-24 12:52:51 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205638189828947969",
  "text" : "For the next 4 hours @nial_adams is my proxy... As I left my account signed on in the iPad - so do your worst ;)",
  "id" : 205638189828947969,
  "created_at" : "2012-05-24 12:35:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 22, 34 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 64, 70 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205637436041207809",
  "text" : "\"For the next 6 hours @niall_adams can tweet whatever he wants\" @swmcc can't count :)",
  "id" : 205637436041207809,
  "created_at" : "2012-05-24 12:32:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205603878828376064",
  "geo" : { },
  "id_str" : "205603975154774016",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq awesome :D",
  "id" : 205603975154774016,
  "in_reply_to_status_id" : 205603878828376064,
  "created_at" : "2012-05-24 10:19:42 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205602876729458688",
  "geo" : { },
  "id_str" : "205603199917375488",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq any sign of the baby?",
  "id" : 205603199917375488,
  "in_reply_to_status_id" : 205602876729458688,
  "created_at" : "2012-05-24 10:16:37 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205587945007226880",
  "geo" : { },
  "id_str" : "205602027127058432",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight top cat :D Awesome.... Fucking awesome :)",
  "id" : 205602027127058432,
  "in_reply_to_status_id" : 205587945007226880,
  "created_at" : "2012-05-24 10:11:57 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 26, 37 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205601150223921152",
  "text" : "Happy 30th to the awesome @Alana_Doll :) :)",
  "id" : 205601150223921152,
  "created_at" : "2012-05-24 10:08:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 7, 19 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205593228576169984",
  "geo" : { },
  "id_str" : "205594674684108800",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @niall_adams I should sign out of the twitter.app :D",
  "id" : 205594674684108800,
  "in_reply_to_status_id" : 205593228576169984,
  "created_at" : "2012-05-24 09:42:44 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205593440292052992",
  "text" : "I have a real thing for men in shorts.",
  "id" : 205593440292052992,
  "created_at" : "2012-05-24 09:37:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 37, 49 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 63, 69 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205593228576169984",
  "text" : "Today's tweets are brought to you by @niall_adams on behalf of @swmcc",
  "id" : 205593228576169984,
  "created_at" : "2012-05-24 09:37:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205590172941824000",
  "text" : "\u201C@michaelnsimpson: OH \"swear I'm going to stick my dick in your ear\"\n\nA fine way to start off Thursday.\u201D It was me that said it :D",
  "id" : 205590172941824000,
  "created_at" : "2012-05-24 09:24:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 15, 28 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tascomikillerking",
      "indices" : [ 32, 50 ]
    }, {
      "text" : "vendettaisbackon",
      "indices" : [ 100, 117 ]
    }, {
      "text" : "nemesis",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205391156937363456",
  "text" : "I must destroy @RickyHassard at #tascomikillerking he bitch slapped me about something awful today. #vendettaisbackon #nemesis",
  "id" : 205391156937363456,
  "created_at" : "2012-05-23 20:14:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205307013503254528",
  "geo" : { },
  "id_str" : "205311692048052225",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll get yourself of FB. It is crap.",
  "id" : 205311692048052225,
  "in_reply_to_status_id" : 205307013503254528,
  "created_at" : "2012-05-23 14:58:16 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 1, 12 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Victoria",
      "screen_name" : "KeepYourEyesUp",
      "indices" : [ 14, 29 ],
      "id_str" : "1216689955",
      "id" : 1216689955
    }, {
      "name" : "Austin",
      "screen_name" : "austinslide",
      "indices" : [ 30, 42 ],
      "id_str" : "20501555",
      "id" : 20501555
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 43, 49 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bestjobeverrrrr",
      "indices" : [ 80, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205311532412841984",
  "text" : "\u201C@Alana_Doll: @keepyoureyesup @austinslide @swmcc tomorrow! Naked! Paid in cake #bestjobeverrrrr\u201D I love this woman - FACT! :)",
  "id" : 205311532412841984,
  "created_at" : "2012-05-23 14:57:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 47, 58 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205299074927300610",
  "text" : "I knew something good somwhere was happening. \u201C@Alana_Doll: Picked a good day to bake! It's 21 bloody degrees\u201D",
  "id" : 205299074927300610,
  "created_at" : "2012-05-23 14:08:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205241950750769154",
  "text" : "Bad mood has come... Too many ppl about my desk hanging about... Need to concentrate.. PPL FUCK OFF!!!!!",
  "id" : 205241950750769154,
  "created_at" : "2012-05-23 10:21:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205238658465415169",
  "geo" : { },
  "id_str" : "205238914775134208",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore yeah - the premise of the show didn't lend itself well to longevity. But still - amazing show in its prime.",
  "id" : 205238914775134208,
  "in_reply_to_status_id" : 205238658465415169,
  "created_at" : "2012-05-23 10:09:05 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205238108101419009",
  "geo" : { },
  "id_str" : "205238433466167296",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore They did that with The West Wing.. Sad to see a show nowhere near its prime - but still a good show...",
  "id" : 205238433466167296,
  "in_reply_to_status_id" : 205238108101419009,
  "created_at" : "2012-05-23 10:07:10 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205233123657650177",
  "geo" : { },
  "id_str" : "205237764189454337",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore was it good - I have to say I abandoned it a while back...",
  "id" : 205237764189454337,
  "in_reply_to_status_id" : 205233123657650177,
  "created_at" : "2012-05-23 10:04:30 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205224132370108416",
  "geo" : { },
  "id_str" : "205225074893131777",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams fuck right off :)",
  "id" : 205225074893131777,
  "in_reply_to_status_id" : 205224132370108416,
  "created_at" : "2012-05-23 09:14:05 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205218946759143424",
  "text" : "I am in a very good mood this morning... Odd.. Something will fuck it up though - bound to ;)",
  "id" : 205218946759143424,
  "created_at" : "2012-05-23 08:49:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/205208441290100737\/photo\/1",
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/6Lj4uih",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtkL_XhCEAAT4rc.jpg",
      "id_str" : "205208441294295040",
      "id" : 205208441294295040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtkL_XhCEAAT4rc.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/6Lj4uih"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205208441290100737",
  "text" : "Where is Snoop's head? http:\/\/t.co\/6Lj4uih",
  "id" : 205208441290100737,
  "created_at" : "2012-05-23 08:08:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205071758905180162",
  "text" : "Locked my account - am starting to worry about my digital footprint. Make of this what you will. I think it's personal growth!",
  "id" : 205071758905180162,
  "created_at" : "2012-05-22 23:04:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 82, 93 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205070571904577536",
  "geo" : { },
  "id_str" : "205071386677481474",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Yo G :) If you still want cake I can recommend anything the great @Alana_Doll  makes. Open a shop already!!",
  "id" : 205071386677481474,
  "in_reply_to_status_id" : 205070571904577536,
  "created_at" : "2012-05-22 23:03:23 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "andwiththisigohomecosshitlikethatwindsmeup",
      "indices" : [ 73, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204990016756264961",
  "text" : "\"Error: You must `brew link node' before coffee-script can be installed\" #andwiththisigohomecosshitlikethatwindsmeup",
  "id" : 204990016756264961,
  "created_at" : "2012-05-22 17:40:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204938995896029184",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson is two man cards down.... He isn't in tomorrow - but lets see what happens Thursday and Friday.",
  "id" : 204938995896029184,
  "created_at" : "2012-05-22 14:17:18 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204919361901834240",
  "geo" : { },
  "id_str" : "204923439629340672",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll :D Always... But that's got fuck all to do with it to be honest :) Well remember on Thursday to wish ya a happy 30 :D",
  "id" : 204923439629340672,
  "in_reply_to_status_id" : 204919361901834240,
  "created_at" : "2012-05-22 13:15:29 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204912691335282688",
  "geo" : { },
  "id_str" : "204912863926697985",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll noted - and you don't look a day over 21...",
  "id" : 204912863926697985,
  "in_reply_to_status_id" : 204912691335282688,
  "created_at" : "2012-05-22 12:33:28 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204906731925544960",
  "geo" : { },
  "id_str" : "204912538138316803",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll you 30 today? Happy Birthday....",
  "id" : 204912538138316803,
  "in_reply_to_status_id" : 204906731925544960,
  "created_at" : "2012-05-22 12:32:10 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204894088951111680",
  "geo" : { },
  "id_str" : "204894541873029120",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Stop it :) Sun = good :D",
  "id" : 204894541873029120,
  "in_reply_to_status_id" : 204894088951111680,
  "created_at" : "2012-05-22 11:20:40 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204891926623830018",
  "geo" : { },
  "id_str" : "204893868095840256",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Noooooooooo :(",
  "id" : 204893868095840256,
  "in_reply_to_status_id" : 204891926623830018,
  "created_at" : "2012-05-22 11:17:59 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204865773108330497",
  "geo" : { },
  "id_str" : "204868689332404224",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley way to go Pete :D",
  "id" : 204868689332404224,
  "in_reply_to_status_id" : 204865773108330497,
  "created_at" : "2012-05-22 09:37:56 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204835061852422147",
  "geo" : { },
  "id_str" : "204836085879156736",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq awesome :D",
  "id" : 204836085879156736,
  "in_reply_to_status_id" : 204835061852422147,
  "created_at" : "2012-05-22 07:28:23 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204647523405672449",
  "text" : "Garden cut and tended too.. Twitter cull down of assholes - not saying you aren't an asshole if you are still on my list though ;)",
  "id" : 204647523405672449,
  "created_at" : "2012-05-21 18:59:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204610813120626688",
  "geo" : { },
  "id_str" : "204611318735585280",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight and its a Fiat 500 - you don't need a photo of it ;)",
  "id" : 204611318735585280,
  "in_reply_to_status_id" : 204610813120626688,
  "created_at" : "2012-05-21 16:35:14 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204610813120626688",
  "geo" : { },
  "id_str" : "204611209524293633",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight no man card for me - am manly ;) Ack just shite. Am greatful for a job and like it - but sometimes ppl just fuck u off :)",
  "id" : 204611209524293633,
  "in_reply_to_status_id" : 204610813120626688,
  "created_at" : "2012-05-21 16:34:48 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204610196255940609",
  "text" : "Well that was the shittest Monday on record.. Gonna do some gardening to perk me up then Mad Men and Game of Thrones.",
  "id" : 204610196255940609,
  "created_at" : "2012-05-21 16:30:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204492496833757184",
  "geo" : { },
  "id_str" : "204592077848330240",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne road trip in a fiat 500 to Coleraine 8:30 Monday morning. Spotted by work peeps who had pancakes with them :(",
  "id" : 204592077848330240,
  "in_reply_to_status_id" : 204492496833757184,
  "created_at" : "2012-05-21 15:18:47 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204512317961023488",
  "geo" : { },
  "id_str" : "204591977549930497",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight Homer Simpson :) Also cool glasses ;) :D",
  "id" : 204591977549930497,
  "in_reply_to_status_id" : 204512317961023488,
  "created_at" : "2012-05-21 15:18:23 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204480529989500928",
  "geo" : { },
  "id_str" : "204481950247960576",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight company car. Fiat 500 to Coleraine",
  "id" : 204481950247960576,
  "in_reply_to_status_id" : 204480529989500928,
  "created_at" : "2012-05-21 08:01:10 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 3, 16 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 74, 80 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204481826549538816",
  "text" : "RT @RickyHassard: My monday morning just improved dramatically when I saw @swmcc enjoying the spacious comfort of the company Fiat 500 # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 56, 62 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "funroadtrip",
        "indices" : [ 117, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "204479349058056192",
    "text" : "My monday morning just improved dramatically when I saw @swmcc enjoying the spacious comfort of the company Fiat 500 #funroadtrip",
    "id" : 204479349058056192,
    "created_at" : "2012-05-21 07:50:50 +0000",
    "user" : {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "protected" : false,
      "id_str" : "5684272",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1317084795\/Screen_shot_2011-04-19_at_13.00.12_normal.png",
      "id" : 5684272,
      "verified" : false
    }
  },
  "id" : 204481826549538816,
  "created_at" : "2012-05-21 08:00:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204478195095965696",
  "text" : "Worst start to a Monday ever....",
  "id" : 204478195095965696,
  "created_at" : "2012-05-21 07:46:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204338899366055936",
  "geo" : { },
  "id_str" : "204340274019840000",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq nice :) Node I take it? I used meteor the other day - nice enough :)",
  "id" : 204340274019840000,
  "in_reply_to_status_id" : 204338899366055936,
  "created_at" : "2012-05-20 22:38:12 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 13, 26 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204315160003874818",
  "geo" : { },
  "id_str" : "204315790923665408",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @rickyhassard cunt sticks. I forgot clean all about that. :(",
  "id" : 204315790923665408,
  "in_reply_to_status_id" : 204315160003874818,
  "created_at" : "2012-05-20 21:00:55 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204220327939670018",
  "geo" : { },
  "id_str" : "204221648797302786",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne congrats :D",
  "id" : 204221648797302786,
  "in_reply_to_status_id" : 204220327939670018,
  "created_at" : "2012-05-20 14:46:49 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 3, 12 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "UNICEF",
      "screen_name" : "UNICEF",
      "indices" : [ 19, 26 ],
      "id_str" : "33933259",
      "id" : 33933259
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SahelNOW",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "KloutForGood",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204164379506245632",
  "text" : "RT @alvynmcq: Help @UNICEF spread the word about #SahelNOW! 1 Million+ children are suffering from severe malnutrition! #KloutForGood ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UNICEF",
        "screen_name" : "UNICEF",
        "indices" : [ 5, 12 ],
        "id_str" : "33933259",
        "id" : 33933259
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SahelNOW",
        "indices" : [ 35, 44 ]
      }, {
        "text" : "KloutForGood",
        "indices" : [ 106, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/cvVdOrPn",
        "expanded_url" : "http:\/\/klout.com\/s\/forgood\/unicef?n=tw&v=unicef",
        "display_url" : "klout.com\/s\/forgood\/unic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "204160122757447680",
    "text" : "Help @UNICEF spread the word about #SahelNOW! 1 Million+ children are suffering from severe malnutrition! #KloutForGood http:\/\/t.co\/cvVdOrPn",
    "id" : 204160122757447680,
    "created_at" : "2012-05-20 10:42:21 +0000",
    "user" : {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "protected" : false,
      "id_str" : "16155145",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2054100540\/535376_10150637481600213_561550212_9624784_1859481959_n_normal.jpg",
      "id" : 16155145,
      "verified" : false
    }
  },
  "id" : 204164379506245632,
  "created_at" : "2012-05-20 10:59:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203977978152108032",
  "geo" : { },
  "id_str" : "203978075707424770",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq cheers - I'll do the same in a bit :)",
  "id" : 203978075707424770,
  "in_reply_to_status_id" : 203977978152108032,
  "created_at" : "2012-05-19 22:38:57 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203976946206515203",
  "text" : "OH: \"Those that doubt me... Well they suck cock by choice!\" - awesome.",
  "id" : 203976946206515203,
  "created_at" : "2012-05-19 22:34:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/d5v0z1y7",
      "expanded_url" : "http:\/\/swmcc.wordpress.com",
      "display_url" : "swmcc.wordpress.com"
    } ]
  },
  "in_reply_to_status_id_str" : "203976042543718400",
  "geo" : { },
  "id_str" : "203976787863154688",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq still have my blog on http:\/\/t.co\/d5v0z1y7 - still need to sort out my nameservers for swm.cc - getting there though :)",
  "id" : 203976787863154688,
  "in_reply_to_status_id" : 203976042543718400,
  "created_at" : "2012-05-19 22:33:50 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203960597799387139",
  "geo" : { },
  "id_str" : "203961234968678401",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 enough playing.. Get back to it :)",
  "id" : 203961234968678401,
  "in_reply_to_status_id" : 203960597799387139,
  "created_at" : "2012-05-19 21:32:02 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "productivesaturday",
      "indices" : [ 37, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203960330630598657",
  "geo" : { },
  "id_str" : "203960456153530370",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 Done and Done then :) #productivesaturday",
  "id" : 203960456153530370,
  "in_reply_to_status_id" : 203960330630598657,
  "created_at" : "2012-05-19 21:28:56 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203959879503851521",
  "geo" : { },
  "id_str" : "203960027747332096",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 Big Al surely...",
  "id" : 203960027747332096,
  "in_reply_to_status_id" : 203959879503851521,
  "created_at" : "2012-05-19 21:27:14 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203957751955734528",
  "geo" : { },
  "id_str" : "203958000883482625",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 Done :)",
  "id" : 203958000883482625,
  "in_reply_to_status_id" : 203957751955734528,
  "created_at" : "2012-05-19 21:19:11 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203955834672267265",
  "geo" : { },
  "id_str" : "203956498693505025",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 I did. Didn't like it much. I don't want Trav and Jellybean to get together - would ruin it :( What you think?",
  "id" : 203956498693505025,
  "in_reply_to_status_id" : 203955834672267265,
  "created_at" : "2012-05-19 21:13:13 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203955834672267265",
  "geo" : { },
  "id_str" : "203956000171114496",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 pffffffttttttt :)",
  "id" : 203956000171114496,
  "in_reply_to_status_id" : 203955834672267265,
  "created_at" : "2012-05-19 21:11:14 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203955159506755584",
  "geo" : { },
  "id_str" : "203955319422992384",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson only watched one episode of justified so far. Gonna give it a go again in an hour. Am half way through DWS2.",
  "id" : 203955319422992384,
  "in_reply_to_status_id" : 203955159506755584,
  "created_at" : "2012-05-19 21:08:32 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leahchallenge",
      "indices" : [ 55, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203954691342745600",
  "geo" : { },
  "id_str" : "203954943936303104",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 This why it is a challenge!! 1h 55mins. #leahchallenge",
  "id" : 203954943936303104,
  "in_reply_to_status_id" : 203954691342745600,
  "created_at" : "2012-05-19 21:07:02 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203954398358020097",
  "geo" : { },
  "id_str" : "203954555820580864",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson that and deadwood season 2 :)",
  "id" : 203954555820580864,
  "in_reply_to_status_id" : 203954398358020097,
  "created_at" : "2012-05-19 21:05:30 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leahchallenge",
      "indices" : [ 44, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203954156157943810",
  "geo" : { },
  "id_str" : "203954360307302402",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 that's why its a challenge.. #leahchallenge You have 2 hours left ;)",
  "id" : 203954360307302402,
  "in_reply_to_status_id" : 203954156157943810,
  "created_at" : "2012-05-19 21:04:43 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203953649158860800",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I am buying a stetson.",
  "id" : 203953649158860800,
  "created_at" : "2012-05-19 21:01:53 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leahchallenge",
      "indices" : [ 52, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203945327370309632",
  "geo" : { },
  "id_str" : "203953548067737601",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 whole tub it or forever be a pussy!! #leahchallenge",
  "id" : 203953548067737601,
  "in_reply_to_status_id" : 203945327370309632,
  "created_at" : "2012-05-19 21:01:29 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203866491915993088",
  "geo" : { },
  "id_str" : "203869026005434368",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson looks ok so far.",
  "id" : 203869026005434368,
  "in_reply_to_status_id" : 203866491915993088,
  "created_at" : "2012-05-19 15:25:38 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203851420821241856",
  "geo" : { },
  "id_str" : "203853782344417281",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson Same as any tractors before to be fair :)",
  "id" : 203853782344417281,
  "in_reply_to_status_id" : 203851420821241856,
  "created_at" : "2012-05-19 14:25:03 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203773772313010177",
  "geo" : { },
  "id_str" : "203850861867311105",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson trying justified now.... Hopefully will be good.",
  "id" : 203850861867311105,
  "in_reply_to_status_id" : 203773772313010177,
  "created_at" : "2012-05-19 14:13:27 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203542179266834432",
  "geo" : { },
  "id_str" : "203774095127609345",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR I'll not gloat on the Tuesday.. I promise :D",
  "id" : 203774095127609345,
  "in_reply_to_status_id" : 203542179266834432,
  "created_at" : "2012-05-19 09:08:24 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "laztassbastards",
      "indices" : [ 77, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203773772313010177",
  "geo" : { },
  "id_str" : "203773979524206592",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson the start of June... Awesome :D I am watching Deadwood S2.. #laztassbastards",
  "id" : 203773979524206592,
  "in_reply_to_status_id" : 203773772313010177,
  "created_at" : "2012-05-19 09:07:57 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 28, 42 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203773200465797121",
  "text" : "Heading into Belfast to see @jenporterhall drive a tractor. No way this ends well for either Jenni or the tractor...",
  "id" : 203773200465797121,
  "created_at" : "2012-05-19 09:04:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203743748197330944",
  "geo" : { },
  "id_str" : "203772320874110976",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I do what I can!",
  "id" : 203772320874110976,
  "in_reply_to_status_id" : 203743748197330944,
  "created_at" : "2012-05-19 09:01:21 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 3, 12 ],
      "id_str" : "9488072",
      "id" : 9488072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203771143449088000",
  "text" : "RT @shylands: Upgraded my Macbook Pro with a wee 256GB SSD and 16GB of ram today. Not gonna lie\u2026. it's fast as fuck.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "203625381360701440",
    "text" : "Upgraded my Macbook Pro with a wee 256GB SSD and 16GB of ram today. Not gonna lie\u2026. it's fast as fuck.",
    "id" : 203625381360701440,
    "created_at" : "2012-05-18 23:17:28 +0000",
    "user" : {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "protected" : false,
      "id_str" : "9488072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3764440968\/5f8795a70c072aa9f29a92725bf8f567_normal.jpeg",
      "id" : 9488072,
      "verified" : false
    }
  },
  "id" : 203771143449088000,
  "created_at" : "2012-05-19 08:56:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 22, 35 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/203521023876923393\/photo\/1",
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/P6emruTl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtMNSv0CAAAPnFY.png",
      "id_str" : "203521023885312000",
      "id" : 203521023885312000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtMNSv0CAAAPnFY.png",
      "sizes" : [ {
        "h" : 361,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 637,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 757,
        "resize" : "fit",
        "w" : 713
      }, {
        "h" : 757,
        "resize" : "fit",
        "w" : 713
      } ],
      "display_url" : "pic.twitter.com\/P6emruTl"
    } ],
    "hashtags" : [ {
      "text" : "tascomikillerking",
      "indices" : [ 57, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203521023876923393",
  "text" : "And for the next week @rickyhassard is the killer king.. #tascomikillerking http:\/\/t.co\/P6emruTl",
  "id" : 203521023876923393,
  "created_at" : "2012-05-18 16:22:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 37, 43 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203520679763644416",
  "text" : "\u201C@michaelnsimpson: 90 seconds in and @swmcc finally twigs 'Killer Queen' is blaring from Sonos, his new company title &amp; darts walk on tune!\u201D",
  "id" : 203520679763644416,
  "created_at" : "2012-05-18 16:21:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203475450360627201",
  "geo" : { },
  "id_str" : "203478409286926337",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore :D Keep it up :)",
  "id" : 203478409286926337,
  "in_reply_to_status_id" : 203475450360627201,
  "created_at" : "2012-05-18 13:33:27 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 71, 85 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/1e79JbGL",
      "expanded_url" : "http:\/\/monobrowse.wordpress.com\/",
      "display_url" : "monobrowse.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "203470343216697345",
  "text" : "I hope this is as good as I know it can be :D http:\/\/t.co\/1e79JbGL \/cc @No_Underscore",
  "id" : 203470343216697345,
  "created_at" : "2012-05-18 13:01:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203463803499847682",
  "text" : "It feels like autumn out there and its seriously starting to get on my nuts!",
  "id" : 203463803499847682,
  "created_at" : "2012-05-18 12:35:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203452031262916608",
  "geo" : { },
  "id_str" : "203461953765642240",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR what!!!!!!!!!!!! Why the fuck not? This is not on :( :( :( :(",
  "id" : 203461953765642240,
  "in_reply_to_status_id" : 203452031262916608,
  "created_at" : "2012-05-18 12:28:04 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203434523394977792",
  "text" : "Something that @michaelnsimpson said to me in the kitchen there word for word \"But I don't want to see man cock!\"",
  "id" : 203434523394977792,
  "created_at" : "2012-05-18 10:39:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette McDonagh",
      "screen_name" : "AnnetteMcDonagh",
      "indices" : [ 30, 46 ],
      "id_str" : "1164404882",
      "id" : 1164404882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/jIbvwPeH",
      "expanded_url" : "http:\/\/www.raceforlifesponsorme.org\/Shazzas-Girls4?utm_source=twitter&utm_medium=socspon&utm_content=Shazzas-Girls4&utm_campaign=post-sponsor-tweet",
      "display_url" : "raceforlifesponsorme.org\/Shazzas-Girls4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203432710805528577",
  "text" : "I\u2019ve just sponsored the great @annettemcdonagh to take part in Race for Life. Its fundraising for Cancer Research UK @  http:\/\/t.co\/jIbvwPeH",
  "id" : 203432710805528577,
  "created_at" : "2012-05-18 10:31:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203422690848145408",
  "text" : "The Olympic Flag comes to these Isles today... Am I the only one hoping Superman will blow it?",
  "id" : 203422690848145408,
  "created_at" : "2012-05-18 09:52:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203405838889652224",
  "geo" : { },
  "id_str" : "203414225627004929",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 that looks brilliant :D Ha - have a good one :)",
  "id" : 203414225627004929,
  "in_reply_to_status_id" : 203405838889652224,
  "created_at" : "2012-05-18 09:18:25 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203225926291554305",
  "geo" : { },
  "id_str" : "203405050968678400",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight oh its a platform to write code in. I is learning new stuff ya see. \/me plays with duplo bricks.",
  "id" : 203405050968678400,
  "in_reply_to_status_id" : 203225926291554305,
  "created_at" : "2012-05-18 08:41:57 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203240485148569604",
  "geo" : { },
  "id_str" : "203404110022713345",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 that link is broken now but i take its some sort of star wars thingie? :) Awesome :)",
  "id" : 203404110022713345,
  "in_reply_to_status_id" : 203240485148569604,
  "created_at" : "2012-05-18 08:38:13 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203222917427896320",
  "geo" : { },
  "id_str" : "203224135780937729",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I wouldn't use it in production, yet. But for faffing about (for now) its dead on.",
  "id" : 203224135780937729,
  "in_reply_to_status_id" : 203222917427896320,
  "created_at" : "2012-05-17 20:43:04 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203217586110996480",
  "geo" : { },
  "id_str" : "203222319131406336",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq pretty much - but not sure about it though. Its installed on me server so go play :) Ports 4000+ for you I'd say",
  "id" : 203222319131406336,
  "in_reply_to_status_id" : 203217586110996480,
  "created_at" : "2012-05-17 20:35:51 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203212861495984128",
  "geo" : { },
  "id_str" : "203213099065540608",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley forgot to add chris cos he isn't in our about us page :D So I still fail :(",
  "id" : 203213099065540608,
  "in_reply_to_status_id" : 203212861495984128,
  "created_at" : "2012-05-17 19:59:12 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203211288866861057",
  "geo" : { },
  "id_str" : "203212762099363840",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson :d This 12 hours buddy!!!! Like days of yore!!!!! :D",
  "id" : 203212762099363840,
  "in_reply_to_status_id" : 203211288866861057,
  "created_at" : "2012-05-17 19:57:52 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 50 ],
      "url" : "https:\/\/t.co\/PRpUNofJ",
      "expanded_url" : "https:\/\/github.com\/swmcc\/Killer-King-Leaderboard",
      "display_url" : "github.com\/swmcc\/Killer-K\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "203211328343638016",
  "geo" : { },
  "id_str" : "203212655761166336",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq tis on github now. https:\/\/t.co\/PRpUNofJ - does fuck all though - just a proof of concept thingie for me!",
  "id" : 203212655761166336,
  "in_reply_to_status_id" : 203211328343638016,
  "created_at" : "2012-05-17 19:57:27 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/203209747330113537\/photo\/1",
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/lt1Q9RzW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtHyMETCIAEC-3F.png",
      "id_str" : "203209747334307841",
      "id" : 203209747334307841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtHyMETCIAEC-3F.png",
      "sizes" : [ {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1040,
        "resize" : "fit",
        "w" : 1840
      } ],
      "display_url" : "pic.twitter.com\/lt1Q9RzW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203209747330113537",
  "text" : "I've been hard at work... Using node for 'work' purposes... http:\/\/t.co\/lt1Q9RzW",
  "id" : 203209747330113537,
  "created_at" : "2012-05-17 19:45:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203141615823503360",
  "geo" : { },
  "id_str" : "203143692981252096",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard :D What can I say.. Worst. Picture. Ever. Think they did it on purpose - bastards :D",
  "id" : 203143692981252096,
  "in_reply_to_status_id" : 203141615823503360,
  "created_at" : "2012-05-17 15:23:25 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203140216591101952",
  "text" : "\"Hello. Tascomi speaking!!\". \"Tascomi?\" \"Ermmm... Yes!\" \"Can I speak to @michaelnsimpsn please\" She had enough of speaking to me already!",
  "id" : 203140216591101952,
  "created_at" : "2012-05-17 15:09:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 61, 74 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 75, 89 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 90, 106 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 107, 113 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 114, 128 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203138443390369792",
  "text" : "Man Cards are back on... I repeat man cards are back on. \/cc @RickyHassard @jenporterhall @michaelnsimpson @swmcc @peter_omalley",
  "id" : 203138443390369792,
  "created_at" : "2012-05-17 15:02:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203094540171747329",
  "geo" : { },
  "id_str" : "203094721642496000",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard enjoy it :D",
  "id" : 203094721642496000,
  "in_reply_to_status_id" : 203094540171747329,
  "created_at" : "2012-05-17 12:08:49 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203040562956341248",
  "text" : "Today will be a good day....",
  "id" : 203040562956341248,
  "created_at" : "2012-05-17 08:33:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 61, 67 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 68, 82 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203040340234600448",
  "text" : "\u201C@michaelnsimpson: Fruit Batman has saved the internets! cc\/ @swmcc @peter_omalley\u201D :D :D :D",
  "id" : 203040340234600448,
  "created_at" : "2012-05-17 08:32:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/nKeoYLDS",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/iplayer\/episode\/b01hr80j\/Spotlight_Sean_Quinns_Missing_Millions\/",
      "display_url" : "bbc.co.uk\/iplayer\/episod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202884337568464898",
  "text" : "Watching this again - http:\/\/t.co\/nKeoYLDS - I still think fair play to him.. Still though - happy medium in being a sneaky fuck :D",
  "id" : 202884337568464898,
  "created_at" : "2012-05-16 22:12:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "helen cupples",
      "screen_name" : "helencupples",
      "indices" : [ 15, 28 ],
      "id_str" : "43220559",
      "id" : 43220559
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "equalrightsdealwithitblondie",
      "indices" : [ 107, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202855923075657730",
  "geo" : { },
  "id_str" : "202856518264168448",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @helencupples I treat and talk to you the same as I do anyone else :) No special treatment! #equalrightsdealwithitblondie",
  "id" : 202856518264168448,
  "in_reply_to_status_id" : 202855923075657730,
  "created_at" : "2012-05-16 20:22:17 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202843751331270656",
  "geo" : { },
  "id_str" : "202852878178717697",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq cool will add it later. At folks right now.",
  "id" : 202852878178717697,
  "in_reply_to_status_id" : 202843751331270656,
  "created_at" : "2012-05-16 20:07:49 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202836844449234944",
  "geo" : { },
  "id_str" : "202843158114078720",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq want an account on me machine? Don't be fucking it up now - has node and all that guff... Email addy?",
  "id" : 202843158114078720,
  "in_reply_to_status_id" : 202836844449234944,
  "created_at" : "2012-05-16 19:29:12 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202831471717781504",
  "geo" : { },
  "id_str" : "202833001678258179",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq nice - you get a server then? What you using wordpress?",
  "id" : 202833001678258179,
  "in_reply_to_status_id" : 202831471717781504,
  "created_at" : "2012-05-16 18:48:50 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "helen cupples",
      "screen_name" : "helencupples",
      "indices" : [ 0, 13 ],
      "id_str" : "43220559",
      "id" : 43220559
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notbecomingofalady",
      "indices" : [ 117, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202828177058430977",
  "geo" : { },
  "id_str" : "202829792624652288",
  "in_reply_to_user_id" : 43220559,
  "text" : "@helencupples Well she'll not be doing it again - that's for sure ;) I think Jenni is awesome - but what a temper :) #notbecomingofalady",
  "id" : 202829792624652288,
  "in_reply_to_status_id" : 202828177058430977,
  "created_at" : "2012-05-16 18:36:05 +0000",
  "in_reply_to_screen_name" : "helencupples",
  "in_reply_to_user_id_str" : "43220559",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "helen cupples",
      "screen_name" : "helencupples",
      "indices" : [ 0, 13 ],
      "id_str" : "43220559",
      "id" : 43220559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202825969491386368",
  "in_reply_to_user_id" : 43220559,
  "text" : "@helencupples we weren't nasty to Jenni today - she was just being a moody cow :) Thanks for the cakes by the way :)",
  "id" : 202825969491386368,
  "created_at" : "2012-05-16 18:20:54 +0000",
  "in_reply_to_screen_name" : "helencupples",
  "in_reply_to_user_id_str" : "43220559",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "biscutnazi",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202703983435980800",
  "text" : "I've done it.. It finally happened. @michanelnsimpson has taken his toys and is huffing all the way home. #biscutnazi",
  "id" : 202703983435980800,
  "created_at" : "2012-05-16 10:16:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202681943777742850",
  "text" : "Worst. Tea. Break. Ever.",
  "id" : 202681943777742850,
  "created_at" : "2012-05-16 08:48:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202673469824040960",
  "geo" : { },
  "id_str" : "202673856345931776",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 fair enough - point taken :)",
  "id" : 202673856345931776,
  "in_reply_to_status_id" : 202673469824040960,
  "created_at" : "2012-05-16 08:16:27 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202670564769415168",
  "geo" : { },
  "id_str" : "202673132308406273",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 and you did 100k... excellent :) Well done.",
  "id" : 202673132308406273,
  "in_reply_to_status_id" : 202670564769415168,
  "created_at" : "2012-05-16 08:13:34 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202670564769415168",
  "geo" : { },
  "id_str" : "202673083134390272",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 shorts are never a must! Fact!",
  "id" : 202673083134390272,
  "in_reply_to_status_id" : 202670564769415168,
  "created_at" : "2012-05-16 08:13:23 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202659680793792512",
  "geo" : { },
  "id_str" : "202662097283330048",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 That looks official - were you in a race? Also short photos = illegal :)",
  "id" : 202662097283330048,
  "in_reply_to_status_id" : 202659680793792512,
  "created_at" : "2012-05-16 07:29:43 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Jim Fitzpatrick",
      "screen_name" : "jimfitzbiz",
      "indices" : [ 10, 21 ],
      "id_str" : "403466766",
      "id" : 403466766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202537729135886337",
  "geo" : { },
  "id_str" : "202646772768706561",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @jimfitzbiz Was an excellent documentary - well done Jim and team.",
  "id" : 202646772768706561,
  "in_reply_to_status_id" : 202537729135886337,
  "created_at" : "2012-05-16 06:28:50 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 3, 14 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Alana_Doll\/status\/202391988727853057\/photo\/1",
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/7vSHEX0j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/As8KcQHCMAES5-E.jpg",
      "id_str" : "202391988732047361",
      "id" : 202391988732047361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/As8KcQHCMAES5-E.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/7vSHEX0j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202392145175396354",
  "text" : "RT @Alana_Doll: *WARNING* may be too cute for human consumption http:\/\/t.co\/7vSHEX0j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Alana_Doll\/status\/202391988727853057\/photo\/1",
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/7vSHEX0j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/As8KcQHCMAES5-E.jpg",
        "id_str" : "202391988732047361",
        "id" : 202391988732047361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/As8KcQHCMAES5-E.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/7vSHEX0j"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202391988727853057",
    "text" : "*WARNING* may be too cute for human consumption http:\/\/t.co\/7vSHEX0j",
    "id" : 202391988727853057,
    "created_at" : "2012-05-15 13:36:25 +0000",
    "user" : {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "protected" : false,
      "id_str" : "67130324",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3578323065\/bb177ebc2b37f1d2ee6f3eec1af258d0_normal.jpeg",
      "id" : 67130324,
      "verified" : false
    }
  },
  "id" : 202392145175396354,
  "created_at" : "2012-05-15 13:37:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202389926388580352",
  "geo" : { },
  "id_str" : "202390536844353536",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq speak to the man that did it on the js thingie... He goes by beowulf - don't look directly at him though - you will turn to stone!",
  "id" : 202390536844353536,
  "in_reply_to_status_id" : 202389926388580352,
  "created_at" : "2012-05-15 13:30:38 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 3, 13 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pos",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/Zj4uZuxR",
      "expanded_url" : "http:\/\/carisenda.com\/sandbox\/choropleth\/",
      "display_url" : "carisenda.com\/sandbox\/chorop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202387437241106432",
  "text" : "RT @carisenda: Still a lot to do on it but here's a choropleth of NI births in 2011 using NISRA data and d3.js http:\/\/t.co\/Zj4uZuxR #pos ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "postgis",
        "indices" : [ 117, 125 ]
      }, {
        "text" : "d3js",
        "indices" : [ 126, 131 ]
      }, {
        "text" : "ni",
        "indices" : [ 132, 135 ]
      }, {
        "text" : "viz",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/Zj4uZuxR",
        "expanded_url" : "http:\/\/carisenda.com\/sandbox\/choropleth\/",
        "display_url" : "carisenda.com\/sandbox\/chorop\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "202133880273240064",
    "text" : "Still a lot to do on it but here's a choropleth of NI births in 2011 using NISRA data and d3.js http:\/\/t.co\/Zj4uZuxR #postgis #d3js #ni\u00A0#viz",
    "id" : 202133880273240064,
    "created_at" : "2012-05-14 20:30:47 +0000",
    "user" : {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "protected" : false,
      "id_str" : "212603717",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1513037620\/avatar_normal.png",
      "id" : 212603717,
      "verified" : false
    }
  },
  "id" : 202387437241106432,
  "created_at" : "2012-05-15 13:18:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202156764798529538",
  "text" : "Pan Am has been cancelled and Alcatraz... WTF :(",
  "id" : 202156764798529538,
  "created_at" : "2012-05-14 22:01:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 10, 26 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202154270831808512",
  "geo" : { },
  "id_str" : "202154469436305408",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq @michaelnsimpson only thing that gets harmed is the goat as its hard to defect with a dwarf in its stomach..",
  "id" : 202154469436305408,
  "in_reply_to_status_id" : 202154270831808512,
  "created_at" : "2012-05-14 21:52:36 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 17, 26 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202149951042617344",
  "geo" : { },
  "id_str" : "202150375485218816",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @alvynmcq depends on your point of view. Lets just say it involves a goat, a dwarf, 5 slices of cheese and a xylophone!",
  "id" : 202150375485218816,
  "in_reply_to_status_id" : 202149951042617344,
  "created_at" : "2012-05-14 21:36:19 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202147971209494528",
  "geo" : { },
  "id_str" : "202149031894450176",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson Will let Mike explain - I just give him the stuff.. I am an enabler :)",
  "id" : 202149031894450176,
  "in_reply_to_status_id" : 202147971209494528,
  "created_at" : "2012-05-14 21:30:59 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202146385024401408",
  "geo" : { },
  "id_str" : "202146879633498112",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight bull shit Ray... You are *much* older than me... Sure you are 34 in what.. \/me counts.. just under three months ;) 34!!!",
  "id" : 202146879633498112,
  "in_reply_to_status_id" : 202146385024401408,
  "created_at" : "2012-05-14 21:22:26 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 25, 41 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202146141893169153",
  "text" : "I am now a porn pimp for @michaelnsimpson - not that I am complaining like ;)",
  "id" : 202146141893169153,
  "created_at" : "2012-05-14 21:19:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202111533231247360",
  "text" : "That's it. Fuck making millions or being self sufficient... I just want to be Roger Sterling... Seriously... Life's ambition...",
  "id" : 202111533231247360,
  "created_at" : "2012-05-14 19:01:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202088648106180609",
  "text" : "Wedges in the hoven... Burger ready to be defrosted (made them a few weeks ago) - Mad Men &amp; GoT series 4 &amp; 5 respectively - ready :)",
  "id" : 202088648106180609,
  "created_at" : "2012-05-14 17:31:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202012524462354432",
  "text" : "I've got the blockbusters theme tune going through my head....",
  "id" : 202012524462354432,
  "created_at" : "2012-05-14 12:28:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202000563418841089",
  "geo" : { },
  "id_str" : "202001937040805888",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM happy birthday :D",
  "id" : 202001937040805888,
  "in_reply_to_status_id" : 202000563418841089,
  "created_at" : "2012-05-14 11:46:29 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201771350598238209",
  "text" : "Tomorrow will be fun. I think I might average out that profanity anyway but 12 hours worth of Deadwood today is bound to affect me some way!",
  "id" : 201771350598238209,
  "created_at" : "2012-05-13 20:30:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201770664640778241",
  "text" : "\"Fuck\" was said 43 times in the 1st hour of the pilot of Deadwood. Averages of 1.56 utterances of \"fuck\" p\/m. I just watched the 1st Season.",
  "id" : 201770664640778241,
  "created_at" : "2012-05-13 20:27:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201074259781627905",
  "geo" : { },
  "id_str" : "201079081834512384",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard :) You're the joker to my batman!",
  "id" : 201079081834512384,
  "in_reply_to_status_id" : 201074259781627905,
  "created_at" : "2012-05-11 22:39:23 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/201065487344484352\/photo\/1",
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/VPeb8Xdk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AspT_tYCQAApE-H.jpg",
      "id_str" : "201065487348678656",
      "id" : 201065487348678656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AspT_tYCQAApE-H.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/VPeb8Xdk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201065487344484352",
  "text" : "Hangover II http:\/\/t.co\/VPeb8Xdk",
  "id" : 201065487344484352,
  "created_at" : "2012-05-11 21:45:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201061730607050752",
  "geo" : { },
  "id_str" : "201061904687439872",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I'll get a new car when you get a new tv!",
  "id" : 201061904687439872,
  "in_reply_to_status_id" : 201061730607050752,
  "created_at" : "2012-05-11 21:31:08 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201061207069827072",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall you still took the lift though...",
  "id" : 201061207069827072,
  "created_at" : "2012-05-11 21:28:21 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201060705489788928",
  "geo" : { },
  "id_str" : "201061127034109952",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall to be fair that had nothing to do with the handbrake.. Was the fact that everytime I hit the foot brake the car shook..",
  "id" : 201061127034109952,
  "in_reply_to_status_id" : 201060705489788928,
  "created_at" : "2012-05-11 21:28:02 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201051186772721666",
  "geo" : { },
  "id_str" : "201058799342190592",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall yup - pulled the handbrake at the shop there and *CLUNK* :( But sure.... Makes driving more fun without one ;)",
  "id" : 201058799342190592,
  "in_reply_to_status_id" : 201051186772721666,
  "created_at" : "2012-05-11 21:18:47 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201046264496914433",
  "geo" : { },
  "id_str" : "201046922407067648",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley dunno - think maybe it just came off its hinges again... Fuck knows :( Just a pain in the ass!",
  "id" : 201046922407067648,
  "in_reply_to_status_id" : 201046264496914433,
  "created_at" : "2012-05-11 20:31:36 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201044821635379200",
  "text" : "Fucking handbrake failed on my car again.. That's 3 handbrakes I've went through in the last 16 months... Not on :(",
  "id" : 201044821635379200,
  "created_at" : "2012-05-11 20:23:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/3HU7dx4L",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Terhj8mjPwY",
      "display_url" : "youtube.com\/watch?v=Terhj8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201040304030232577",
  "text" : "This is feckin great... Never knew Hugh Jackman was so versatile... http:\/\/t.co\/3HU7dx4L",
  "id" : 201040304030232577,
  "created_at" : "2012-05-11 20:05:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 33, 45 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "growaset",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200992563723894784",
  "text" : "That last tweet was a lesson for @Kirstylvssp and how to let it out without restraint.. #growaset",
  "id" : 200992563723894784,
  "created_at" : "2012-05-11 16:55:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200991983269974018",
  "text" : "FUCK FUCK FUCK!!!! That is all..... Hang on... FUCK FUCK FUCK FUCK!!",
  "id" : 200991983269974018,
  "created_at" : "2012-05-11 16:53:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200985640043679744",
  "geo" : { },
  "id_str" : "200991892689784832",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp grow a set Kirsty and say it with conviction... Like this... Watch next tweet.",
  "id" : 200991892689784832,
  "in_reply_to_status_id" : 200985640043679744,
  "created_at" : "2012-05-11 16:52:56 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200924073231007746",
  "geo" : { },
  "id_str" : "200924255494488064",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe that'll be one freaky ass story... When the kid turns into a donkey will scare the shit out of me i bet!",
  "id" : 200924255494488064,
  "in_reply_to_status_id" : 200924073231007746,
  "created_at" : "2012-05-11 12:24:10 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200899535499825152",
  "geo" : { },
  "id_str" : "200908076759519233",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson That bad? :( :( :(",
  "id" : 200908076759519233,
  "in_reply_to_status_id" : 200899535499825152,
  "created_at" : "2012-05-11 11:19:52 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200875954552324098",
  "text" : "Yup - I still feel like shit - but sure... Onwards and upwards...",
  "id" : 200875954552324098,
  "created_at" : "2012-05-11 09:12:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200842541246070785",
  "geo" : { },
  "id_str" : "200842754442543104",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 I was going to say that but was too early for me to look up how to spell Freudian :)",
  "id" : 200842754442543104,
  "in_reply_to_status_id" : 200842541246070785,
  "created_at" : "2012-05-11 07:00:18 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200839945466814464",
  "geo" : { },
  "id_str" : "200842338526961664",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 ooops.. I meant \"your\" lol - too early in the morning :)",
  "id" : 200842338526961664,
  "in_reply_to_status_id" : 200839945466814464,
  "created_at" : "2012-05-11 06:58:39 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meteor",
      "screen_name" : "meteorjs",
      "indices" : [ 3, 12 ],
      "id_str" : "533884891",
      "id" : 533884891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200839716961140737",
  "text" : "RT @meteorjs: Happy 1 month anniversary, Meteor.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200761761828315136",
    "text" : "Happy 1 month anniversary, Meteor.",
    "id" : 200761761828315136,
    "created_at" : "2012-05-11 01:38:28 +0000",
    "user" : {
      "name" : "Meteor",
      "screen_name" : "meteorjs",
      "protected" : false,
      "id_str" : "533884891",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2080420398\/twitter-rock128_normal.png",
      "id" : 533884891,
      "verified" : false
    }
  },
  "id" : 200839716961140737,
  "created_at" : "2012-05-11 06:48:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200839086276231168",
  "geo" : { },
  "id_str" : "200839517027053568",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 you going to check out our new abode?",
  "id" : 200839517027053568,
  "in_reply_to_status_id" : 200839086276231168,
  "created_at" : "2012-05-11 06:47:26 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 3, 17 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "endhu",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200707946282360832",
  "text" : "RT @jenporterhall: 'Lust and greed at root at sexual exploitation of girls' ..affects all of society. This is rife in Ireland too #endhu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "endhumantrafficking",
        "indices" : [ 111, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200706634564116480",
    "text" : "'Lust and greed at root at sexual exploitation of girls' ..affects all of society. This is rife in Ireland too #endhumantrafficking",
    "id" : 200706634564116480,
    "created_at" : "2012-05-10 21:59:25 +0000",
    "user" : {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "protected" : false,
      "id_str" : "227493010",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2257082551\/DSCF9612_normal.jpg",
      "id" : 227493010,
      "verified" : false
    }
  },
  "id" : 200707946282360832,
  "created_at" : "2012-05-10 22:04:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200703061088407552",
  "geo" : { },
  "id_str" : "200705296258183168",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley illegal hashtag there!",
  "id" : 200705296258183168,
  "in_reply_to_status_id" : 200703061088407552,
  "created_at" : "2012-05-10 21:54:06 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 15, 29 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200698292542251008",
  "geo" : { },
  "id_str" : "200702535542128640",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @jenporterhall Don't I could stomach them tbh. Only having dinner now and even that is a struggle :( Jenni can have my quota",
  "id" : 200702535542128640,
  "in_reply_to_status_id" : 200698292542251008,
  "created_at" : "2012-05-10 21:43:08 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200700027226693632",
  "geo" : { },
  "id_str" : "200702179017895937",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist good fucking riddance.. I expect not to see you on the channel that doesn't exist tomorrow :D",
  "id" : 200702179017895937,
  "in_reply_to_status_id" : 200700027226693632,
  "created_at" : "2012-05-10 21:41:43 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 31, 47 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 52, 66 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 95, 109 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200695171925553153",
  "text" : "Friday tomorrow... We are down @michaelnsimpson but @jenporterhall is there so it evens out... @peter_omalley she wants a bacon bap too :)",
  "id" : 200695171925553153,
  "created_at" : "2012-05-10 21:13:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200659544169398272",
  "text" : "RT @substack: updated ubuntu and all the fonts are really ugly as usual",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200659479128317952",
    "text" : "updated ubuntu and all the fonts are really ugly as usual",
    "id" : 200659479128317952,
    "created_at" : "2012-05-10 18:52:02 +0000",
    "user" : {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 200659544169398272,
  "created_at" : "2012-05-10 18:52:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200575330552004608",
  "text" : "Am WFH and the folks are away for a weekend break this morning. Broke in to get some food - only got 5 sausages rolls and a kit kat :(",
  "id" : 200575330552004608,
  "created_at" : "2012-05-10 13:17:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 17, 31 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 39, 53 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200574618795384832",
  "geo" : { },
  "id_str" : "200575195231158272",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @No_Underscore Me and @peter_omalley showed him the Expendables 2 trailer - but nothing.. He felt nothing...",
  "id" : 200575195231158272,
  "in_reply_to_status_id" : 200574618795384832,
  "created_at" : "2012-05-10 13:17:07 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200563244719550464",
  "geo" : { },
  "id_str" : "200571933358698496",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson emotional stuff.... you shaving your bajingo this weekend????",
  "id" : 200571933358698496,
  "in_reply_to_status_id" : 200563244719550464,
  "created_at" : "2012-05-10 13:04:10 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 111, 127 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200567367212871680",
  "geo" : { },
  "id_str" : "200567699951206400",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore You think that's bad. There is a dude in my office that doesn't get it or Rocky or Rambo... \/cc @michaelnsimpson",
  "id" : 200567699951206400,
  "in_reply_to_status_id" : 200567367212871680,
  "created_at" : "2012-05-10 12:47:20 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200548972337696768",
  "geo" : { },
  "id_str" : "200556135298768896",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg could be fake - I don't pay much attention to them to be fair... I just ignore...",
  "id" : 200556135298768896,
  "in_reply_to_status_id" : 200548972337696768,
  "created_at" : "2012-05-10 12:01:23 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200537778776317952",
  "geo" : { },
  "id_str" : "200538672553132033",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq am more than happy where I am. But just want to update my skills without getting hounded by them seems impossible :(",
  "id" : 200538672553132033,
  "in_reply_to_status_id" : 200537778776317952,
  "created_at" : "2012-05-10 10:52:00 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200537778776317952",
  "geo" : { },
  "id_str" : "200538148638429184",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq get the odd one. I have mine set to 'no contact'. Kinda annoying like :\/ Thing is having a linkedin is kinda expected the days :(",
  "id" : 200538148638429184,
  "in_reply_to_status_id" : 200537778776317952,
  "created_at" : "2012-05-10 10:49:55 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200536019865567232",
  "text" : "I am getting too much spam from LinkedIN this weather :\/",
  "id" : 200536019865567232,
  "created_at" : "2012-05-10 10:41:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 68, 81 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200524738576130048",
  "geo" : { },
  "id_str" : "200529869266890752",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson yeah - the critics were wrong... Also according to @RickyHassard they paid 250k to use that Beatles song at the end!!",
  "id" : 200529869266890752,
  "in_reply_to_status_id" : 200524738576130048,
  "created_at" : "2012-05-10 10:17:01 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200524221523300353",
  "geo" : { },
  "id_str" : "200524420270403585",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson :D :D I am working from home today... Voice has completely gone.. VPN sorted so don't need to be in the office :)",
  "id" : 200524420270403585,
  "in_reply_to_status_id" : 200524221523300353,
  "created_at" : "2012-05-10 09:55:22 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200363917996855297",
  "geo" : { },
  "id_str" : "200364286768463872",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq fuck :( That sounds painful but at least you finished :) You fucking nutter... REST... REST... REST....",
  "id" : 200364286768463872,
  "in_reply_to_status_id" : 200363917996855297,
  "created_at" : "2012-05-09 23:19:03 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200362611773157377",
  "geo" : { },
  "id_str" : "200362821802921984",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I guess I have to get off my ass and give jade a go. But another fucking templating system - only so many I can deal with :\/",
  "id" : 200362821802921984,
  "in_reply_to_status_id" : 200362611773157377,
  "created_at" : "2012-05-09 23:13:13 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200362410559811584",
  "geo" : { },
  "id_str" : "200362674704498689",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I've found it invaluable taking this time all the same. How many miles in? You gonna take proper recovery time?",
  "id" : 200362674704498689,
  "in_reply_to_status_id" : 200362410559811584,
  "created_at" : "2012-05-09 23:12:38 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200360642639691776",
  "geo" : { },
  "id_str" : "200361178038403072",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I've spent the last four months listening to screen\/pod casts and new shizzle.. Just putting into effect now - takes time is all",
  "id" : 200361178038403072,
  "in_reply_to_status_id" : 200360642639691776,
  "created_at" : "2012-05-09 23:06:42 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200359322973245440",
  "text" : "Also got my new site (the static part) written in Jekyll - pretty nifty - but still no TT :) Got to get with it though :)",
  "id" : 200359322973245440,
  "created_at" : "2012-05-09 22:59:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 9, 25 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200358856608579584",
  "text" : "I bought @michaelnsimpson a USB stick today so he can watch good stuff for us to talk about during the working week in Tesco today :)",
  "id" : 200358856608579584,
  "created_at" : "2012-05-09 22:57:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200282495730716672",
  "geo" : { },
  "id_str" : "200358678916902914",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you alright G??? Just imagine - 4 months time - beetle counting :D :D :D :D :D",
  "id" : 200358678916902914,
  "in_reply_to_status_id" : 200282495730716672,
  "created_at" : "2012-05-09 22:56:46 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200358576059985921",
  "text" : "Mum's 60th birthday tea done :) She loved her TV and cake. Job done - am the favourite son for the next few hours anyway :)",
  "id" : 200358576059985921,
  "created_at" : "2012-05-09 22:56:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200334318214709249",
  "geo" : { },
  "id_str" : "200358229543354368",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 It is a natural process.. even with your mother on my face!",
  "id" : 200358229543354368,
  "in_reply_to_status_id" : 200334318214709249,
  "created_at" : "2012-05-09 22:54:59 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stilldiseased",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200324528101015552",
  "text" : "I'm starting to hate breathing solely through my mouth. #stilldiseased",
  "id" : 200324528101015552,
  "created_at" : "2012-05-09 20:41:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wecanstillbetwittermates",
      "indices" : [ 111, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200312708569120768",
  "geo" : { },
  "id_str" : "200313307398283265",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll oh hell no - you broke it off - am afraid you had your chance and blew it. I mean with your 'cut'. #wecanstillbetwittermates",
  "id" : 200313307398283265,
  "in_reply_to_status_id" : 200312708569120768,
  "created_at" : "2012-05-09 19:56:28 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youhaveasecondchance",
      "indices" : [ 40, 61 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200308177391198208",
  "geo" : { },
  "id_str" : "200310408979030016",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll cut me and it's deffo over. #youhaveasecondchance",
  "id" : 200310408979030016,
  "in_reply_to_status_id" : 200308177391198208,
  "created_at" : "2012-05-09 19:44:57 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200303063318278145",
  "geo" : { },
  "id_str" : "200310063456468992",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson get a USB stick.",
  "id" : 200310063456468992,
  "in_reply_to_status_id" : 200303063318278145,
  "created_at" : "2012-05-09 19:43:35 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200283658102374400",
  "geo" : { },
  "id_str" : "200309542800736256",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley we've all been there. Main thing was that it was found. :)",
  "id" : 200309542800736256,
  "in_reply_to_status_id" : 200283658102374400,
  "created_at" : "2012-05-09 19:41:31 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 38, 52 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200270337244540928",
  "text" : "Waiting in the girls toilets to scare @jenporterhall wont work when she is standing outside the fellas toilets to scare me.",
  "id" : 200270337244540928,
  "created_at" : "2012-05-09 17:05:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200240443357790209",
  "text" : "I've coughed so much my back hurts....",
  "id" : 200240443357790209,
  "created_at" : "2012-05-09 15:06:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200225178033209344",
  "text" : "When this cold departs me it will be a glorious day.....",
  "id" : 200225178033209344,
  "created_at" : "2012-05-09 14:06:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200186301595660289",
  "geo" : { },
  "id_str" : "200186885316943874",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard @bkgstatus saying what barry said is unacceptable... Means it will drag between now and 6. Not on. He should know better!",
  "id" : 200186885316943874,
  "in_reply_to_status_id" : 200186301595660289,
  "created_at" : "2012-05-09 11:34:07 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200182045010432001",
  "geo" : { },
  "id_str" : "200183748514422784",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus you cunt!!!!!! There is no need for that - rest of the day goes slow.... FUCK YOU BARRY... FUCK. YOU.",
  "id" : 200183748514422784,
  "in_reply_to_status_id" : 200182045010432001,
  "created_at" : "2012-05-09 11:21:39 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 17, 28 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200163837536768001",
  "geo" : { },
  "id_str" : "200165551199367169",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @alana_doll I screwed you over once Simpson.. Fuck me you are such a drama queen. :)",
  "id" : 200165551199367169,
  "in_reply_to_status_id" : 200163837536768001,
  "created_at" : "2012-05-09 10:09:20 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itwasgoodwhileitlsted",
      "indices" : [ 50, 72 ]
    }, {
      "text" : "harlot",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200158249285201920",
  "geo" : { },
  "id_str" : "200160443166244864",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll engagement off? Fine!!! Screw you!!!! #itwasgoodwhileitlsted #harlot",
  "id" : 200160443166244864,
  "in_reply_to_status_id" : 200158249285201920,
  "created_at" : "2012-05-09 09:49:03 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 24, 37 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200157051249369088",
  "text" : "I want to make out with @RickyHassard right now... Seriously...",
  "id" : 200157051249369088,
  "created_at" : "2012-05-09 09:35:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200087944797753344",
  "geo" : { },
  "id_str" : "200088267268431872",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson You had to throw that out - no way you could keep it for over 12 hours in your car - I could - you couldn't :)",
  "id" : 200088267268431872,
  "in_reply_to_status_id" : 200087944797753344,
  "created_at" : "2012-05-09 05:02:15 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200085870320173056",
  "text" : "Nothing turns me off a company than it whoring itself out for 'Likes' and 'Followers' - does it really matter? Buy for \u00A31 sell for \u00A32 ffs!",
  "id" : 200085870320173056,
  "created_at" : "2012-05-09 04:52:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 10, 19 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beashamed",
      "indices" : [ 76, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199987592521990144",
  "geo" : { },
  "id_str" : "199987857589407744",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq @slabbery classy and very offensive. And this I'd coming from me. #beashamed",
  "id" : 199987857589407744,
  "in_reply_to_status_id" : 199987592521990144,
  "created_at" : "2012-05-08 22:23:15 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199971934111404032",
  "geo" : { },
  "id_str" : "199985053000937472",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues erm.... You are lovely.... You are also middle aged already :)",
  "id" : 199985053000937472,
  "in_reply_to_status_id" : 199971934111404032,
  "created_at" : "2012-05-08 22:12:06 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199931103824461826",
  "geo" : { },
  "id_str" : "199983967942868992",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll make them buns and they will come. Fuck it make me buns and I'll do it. I'll still live at my house though. Deal?",
  "id" : 199983967942868992,
  "in_reply_to_status_id" : 199931103824461826,
  "created_at" : "2012-05-08 22:07:48 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 10, 19 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199982999704567808",
  "geo" : { },
  "id_str" : "199983630003613696",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq @slabbery it's all self inflicted - so man up :)",
  "id" : 199983630003613696,
  "in_reply_to_status_id" : 199982999704567808,
  "created_at" : "2012-05-08 22:06:27 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 32, 46 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 47, 60 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199956172260917251",
  "geo" : { },
  "id_str" : "199983469537931265",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @michaelnsimpson @peter_omalley @rickyhassard I think you'll find, if you look, that you Jennifer is full of shit :)",
  "id" : 199983469537931265,
  "in_reply_to_status_id" : 199956172260917251,
  "created_at" : "2012-05-08 22:05:49 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199955547615789056",
  "geo" : { },
  "id_str" : "199983291158380545",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams why so much hate? You whispered that you loved me this afternoon... Another lie then? Fine! It's over!",
  "id" : 199983291158380545,
  "in_reply_to_status_id" : 199955547615789056,
  "created_at" : "2012-05-08 22:05:06 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 31, 45 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199945061742546944",
  "geo" : { },
  "id_str" : "199947277148758016",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @rickyhassard @berryblonde84 I was growing it. It was gonna replace me soon enough!",
  "id" : 199947277148758016,
  "in_reply_to_status_id" : 199945061742546944,
  "created_at" : "2012-05-08 19:42:00 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 31, 45 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199944578919440385",
  "geo" : { },
  "id_str" : "199947178943324160",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @michaelnsimpson @berryblonde84 cheers :)",
  "id" : 199947178943324160,
  "in_reply_to_status_id" : 199944578919440385,
  "created_at" : "2012-05-08 19:41:36 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199940665512169473",
  "geo" : { },
  "id_str" : "199942906189053954",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson fuck away off twats. I is bowling... Getting my ass kicked by my sister but bowling never the less :)",
  "id" : 199942906189053954,
  "in_reply_to_status_id" : 199940665512169473,
  "created_at" : "2012-05-08 19:24:38 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/199902089500037121\/photo\/1",
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/rO3Di3SA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsYx5CrCEAESFlw.jpg",
      "id_str" : "199902089504231425",
      "id" : 199902089504231425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsYx5CrCEAESFlw.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/rO3Di3SA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199902089500037121",
  "text" : "Yum :) http:\/\/t.co\/rO3Di3SA",
  "id" : 199902089500037121,
  "created_at" : "2012-05-08 16:42:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Dugan",
      "screen_name" : "adriandugan",
      "indices" : [ 0, 12 ],
      "id_str" : "69403865",
      "id" : 69403865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199878938019893249",
  "geo" : { },
  "id_str" : "199879975120285696",
  "in_reply_to_user_id" : 69403865,
  "text" : "@adriandugan Nope - don't think it.... But now you say - wtf is it???",
  "id" : 199879975120285696,
  "in_reply_to_status_id" : 199878938019893249,
  "created_at" : "2012-05-08 15:14:34 +0000",
  "in_reply_to_screen_name" : "adriandugan",
  "in_reply_to_user_id_str" : "69403865",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199879900226793472",
  "text" : "I feel fucking rotten... Baby diseased me :( :( :(",
  "id" : 199879900226793472,
  "created_at" : "2012-05-08 15:14:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199815713286918146",
  "text" : "I am sick :( :( :(",
  "id" : 199815713286918146,
  "created_at" : "2012-05-08 10:59:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199611961191841792",
  "geo" : { },
  "id_str" : "199612144256434176",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp I just shoved it in the hoven... So will send one tomorrow morning... I dunno - my history of cakes is pretty poor....",
  "id" : 199612144256434176,
  "in_reply_to_status_id" : 199611961191841792,
  "created_at" : "2012-05-07 21:30:18 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199611674523746304",
  "text" : "I made a cherry cake :) Its for my Mum's 60th on Wednesday... Heading out tomorrow night to celebrate it though cos the other siblings suck.",
  "id" : 199611674523746304,
  "created_at" : "2012-05-07 21:28:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199566254183419906",
  "text" : "Mad Men is pure genius.",
  "id" : 199566254183419906,
  "created_at" : "2012-05-07 18:27:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 96, 108 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199550736013598721",
  "geo" : { },
  "id_str" : "199551496524800000",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I want to be Roger Lets start a business - you can be Don, I will be Roger and @niall_adams can be Peggy :)",
  "id" : 199551496524800000,
  "in_reply_to_status_id" : 199550736013598721,
  "created_at" : "2012-05-07 17:29:18 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199550163524648960",
  "geo" : { },
  "id_str" : "199550266989748225",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson watch it from the last one to the first - it'd probably just make as much fucking sense! :(",
  "id" : 199550266989748225,
  "in_reply_to_status_id" : 199550163524648960,
  "created_at" : "2012-05-07 17:24:25 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199550097523085313",
  "text" : "Ohhh look a DVD of Mad Men &amp; Game of Thrones :D",
  "id" : 199550097523085313,
  "created_at" : "2012-05-07 17:23:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199549784653176833",
  "geo" : { },
  "id_str" : "199549933676797954",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson JJ fucked me over with Lost... So sooooo much. No way that he's getting to do it again. So I watch his shows in reverse :)",
  "id" : 199549933676797954,
  "in_reply_to_status_id" : 199549784653176833,
  "created_at" : "2012-05-07 17:23:06 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199547523742969857",
  "geo" : { },
  "id_str" : "199548444107476993",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I am but I watched the finale of season 3 at xmas :)",
  "id" : 199548444107476993,
  "in_reply_to_status_id" : 199547523742969857,
  "created_at" : "2012-05-07 17:17:11 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199536301341540352",
  "geo" : { },
  "id_str" : "199540194284814337",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson this is why what I'm doing is interesting. I know how it ends up - just don't know how it got there :)",
  "id" : 199540194284814337,
  "in_reply_to_status_id" : 199536301341540352,
  "created_at" : "2012-05-07 16:44:24 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199536301341540352",
  "geo" : { },
  "id_str" : "199540042279026688",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson want me to tell you? :D",
  "id" : 199540042279026688,
  "in_reply_to_status_id" : 199536301341540352,
  "created_at" : "2012-05-07 16:43:48 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199532264667889664",
  "geo" : { },
  "id_str" : "199533749141118977",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll fail! Your answer should have been \"tell you later\".....",
  "id" : 199533749141118977,
  "in_reply_to_status_id" : 199532264667889664,
  "created_at" : "2012-05-07 16:18:47 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199529387257896960",
  "geo" : { },
  "id_str" : "199530439558434816",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll prove it.",
  "id" : 199530439558434816,
  "in_reply_to_status_id" : 199529387257896960,
  "created_at" : "2012-05-07 16:05:38 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199529001830727681",
  "geo" : { },
  "id_str" : "199529169405743104",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley I've got a helper Jen!!! Any clue as to who it can be????? :D :D :D :D Missing someone???? :D",
  "id" : 199529169405743104,
  "in_reply_to_status_id" : 199529001830727681,
  "created_at" : "2012-05-07 16:00:35 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neverpiggyback",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199525603794358272",
  "text" : "Spent the day in moo-tools and finally got a portfolio site together.. Need to sort out the nameservers for me domain now. #neverpiggyback",
  "id" : 199525603794358272,
  "created_at" : "2012-05-07 15:46:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199525285492817920",
  "text" : "Right - that's it... A 'static app' is just a website you clueless hipster prats :) Fuck sake - kids..... Get a clue!",
  "id" : 199525285492817920,
  "created_at" : "2012-05-07 15:45:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 14, 23 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199396053118763008",
  "geo" : { },
  "id_str" : "199396463728525312",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @alvynmcq good luck today :)",
  "id" : 199396463728525312,
  "in_reply_to_status_id" : 199396053118763008,
  "created_at" : "2012-05-07 07:13:16 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pippasarousrex",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199257968380870657",
  "text" : "But since she's only turning one next month I think I'll let her away with it.. She is the classest wee woman ever. #pippasarousrex",
  "id" : 199257968380870657,
  "created_at" : "2012-05-06 22:02:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199257738759507968",
  "text" : "I think the lovely Pippasarous-rex gave me the cold... She did sneeze right in my face when I was playing with her on Sat morning - twice...",
  "id" : 199257738759507968,
  "created_at" : "2012-05-06 22:02:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openashopalready",
      "indices" : [ 60, 77 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199243434391908352",
  "geo" : { },
  "id_str" : "199254248188416000",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll :) Ppl can survive on yours... Well known fact. #openashopalready",
  "id" : 199254248188416000,
  "in_reply_to_status_id" : 199243434391908352,
  "created_at" : "2012-05-06 21:48:09 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199252018060201984",
  "geo" : { },
  "id_str" : "199252449347911680",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson and I am not buying a new one - I bought it new 6 years ago!! No fucking way!! I HATE IT!! GONNA GO KICK IT!",
  "id" : 199252449347911680,
  "in_reply_to_status_id" : 199252018060201984,
  "created_at" : "2012-05-06 21:41:00 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199252298453630976",
  "in_reply_to_user_id" : 77241609,
  "text" : "@berryblonde84 @michaelnsimpson then it starts to fuck with me.. Cutting out half way through a cut or not sucking the grass up right.",
  "id" : 199252298453630976,
  "created_at" : "2012-05-06 21:40:24 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199252018060201984",
  "geo" : { },
  "id_str" : "199252200315293697",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson I do get it fixed - it hates me.. Every start of spring - it gets a service. Its okay for 2\/3 cuts...",
  "id" : 199252200315293697,
  "in_reply_to_status_id" : 199252018060201984,
  "created_at" : "2012-05-06 21:40:01 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199251412318814208",
  "geo" : { },
  "id_str" : "199251712043778048",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson I hate that lawnmower with all my heart... It goads me... It is my nemesis. Hateful thing :(",
  "id" : 199251712043778048,
  "in_reply_to_status_id" : 199251412318814208,
  "created_at" : "2012-05-06 21:38:04 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199251037859753985",
  "geo" : { },
  "id_str" : "199251404588724224",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson awesome :D He does not. I have a massive beer bottle - I called it Janine.. You don't want to know ;)",
  "id" : 199251404588724224,
  "in_reply_to_status_id" : 199251037859753985,
  "created_at" : "2012-05-06 21:36:51 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199250521620627456",
  "geo" : { },
  "id_str" : "199250846272331776",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson the other three houses don't talk to me much cos i tend to curse when starting the lawnmower. Honestly :)",
  "id" : 199250846272331776,
  "in_reply_to_status_id" : 199250521620627456,
  "created_at" : "2012-05-06 21:34:38 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199250521620627456",
  "geo" : { },
  "id_str" : "199250672456183808",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson I'd settle for a game of \"Pennnnny Caaaaaaaan\" with John Morgan my 85 year old neighbour :D",
  "id" : 199250672456183808,
  "in_reply_to_status_id" : 199250521620627456,
  "created_at" : "2012-05-06 21:33:56 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199249909948497922",
  "geo" : { },
  "id_str" : "199250087740841985",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson but tis not about cougars anymore.. I love the writing... I live in a cul-de-sac - but no crew :(",
  "id" : 199250087740841985,
  "in_reply_to_status_id" : 199249909948497922,
  "created_at" : "2012-05-06 21:31:37 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199248328872042496",
  "geo" : { },
  "id_str" : "199249545975169024",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson Did you see the last one? I wish they would change the name soon though.. Next season apparently :)",
  "id" : 199249545975169024,
  "in_reply_to_status_id" : 199248328872042496,
  "created_at" : "2012-05-06 21:29:28 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199247618566651904",
  "geo" : { },
  "id_str" : "199247791434895361",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson I straddle both worlds. I am not a blokey bloke - nor a girly person. I respect all genres :D",
  "id" : 199247791434895361,
  "in_reply_to_status_id" : 199247618566651904,
  "created_at" : "2012-05-06 21:22:29 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199247091619475456",
  "geo" : { },
  "id_str" : "199247298201530369",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 ack of course I stil do :) We will see re: the dated thing :) Mike will learn to love them :)",
  "id" : 199247298201530369,
  "in_reply_to_status_id" : 199247091619475456,
  "created_at" : "2012-05-06 21:20:32 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199246238565138432",
  "geo" : { },
  "id_str" : "199246391527223296",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 :( It is 80's classic though... It is awesome :)",
  "id" : 199246391527223296,
  "in_reply_to_status_id" : 199246238565138432,
  "created_at" : "2012-05-06 21:16:56 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 32, 46 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itsdeadnow",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199246057853558785",
  "geo" : { },
  "id_str" : "199246225164341248",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson @peter_omalley Ohhh nooo.. you said rocky is dated... and I liked you too.... I really did... #itsdeadnow",
  "id" : 199246225164341248,
  "in_reply_to_status_id" : 199246057853558785,
  "created_at" : "2012-05-06 21:16:16 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199245590910091265",
  "geo" : { },
  "id_str" : "199245964417048576",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 rambo might be one of those things - but you can appreciate rocky (apart from 5) at any time.",
  "id" : 199245964417048576,
  "in_reply_to_status_id" : 199245590910091265,
  "created_at" : "2012-05-06 21:15:14 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 32, 46 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199243913859575810",
  "geo" : { },
  "id_str" : "199244233851404288",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson @peter_omalley Oh yes - that would be after the 2 R's though.. He needs shock treatment :)",
  "id" : 199244233851404288,
  "in_reply_to_status_id" : 199243913859575810,
  "created_at" : "2012-05-06 21:08:21 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 32, 46 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199242716259958784",
  "geo" : { },
  "id_str" : "199242963480621057",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson @peter_omalley Rocky &amp; Rambo films for a start. Poor Mike just doesn't get it. And we aren't bullying him :)",
  "id" : 199242963480621057,
  "in_reply_to_status_id" : 199242716259958784,
  "created_at" : "2012-05-06 21:03:18 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199233471565135872",
  "geo" : { },
  "id_str" : "199242134652592128",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley Yeah - I suppose.. Still you need the staple bloke films..",
  "id" : 199242134652592128,
  "in_reply_to_status_id" : 199233471565135872,
  "created_at" : "2012-05-06 21:00:01 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/199181349939187714\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/aHbG1u6f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsOiYemCEAAmR-w.jpg",
      "id_str" : "199181349947576320",
      "id" : 199181349947576320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsOiYemCEAAmR-w.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/aHbG1u6f"
    } ],
    "hashtags" : [ {
      "text" : "toomuch",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199181349939187714",
  "text" : "Fuck this I am out... Gonna annoy the folks - they are singing Michael Bolton!! Michael fuckibg Bolton #toomuch http:\/\/t.co\/aHbG1u6f",
  "id" : 199181349939187714,
  "created_at" : "2012-05-06 16:58:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199180870626717697",
  "text" : "This time an hour ago I was watching The Expendables... Now I am watching Glee... Compromise... It sucketh..",
  "id" : 199180870626717697,
  "created_at" : "2012-05-06 16:56:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199178961467621376",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp I just arched The Expendables again. It is awesome. You are wrong. Completely wrong....",
  "id" : 199178961467621376,
  "created_at" : "2012-05-06 16:48:59 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the black telescope",
      "screen_name" : "blacktelescope",
      "indices" : [ 0, 15 ],
      "id_str" : "14932763",
      "id" : 14932763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199158652802830336",
  "geo" : { },
  "id_str" : "199162555430731776",
  "in_reply_to_user_id" : 14932763,
  "text" : "@blacktelescope wow it's 2001 all over again :)",
  "id" : 199162555430731776,
  "in_reply_to_status_id" : 199158652802830336,
  "created_at" : "2012-05-06 15:43:48 +0000",
  "in_reply_to_screen_name" : "blacktelescope",
  "in_reply_to_user_id_str" : "14932763",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the black telescope",
      "screen_name" : "blacktelescope",
      "indices" : [ 0, 15 ],
      "id_str" : "14932763",
      "id" : 14932763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199157507669762049",
  "geo" : { },
  "id_str" : "199157639198945280",
  "in_reply_to_user_id" : 14932763,
  "text" : "@blacktelescope meant Lovefilm instant.",
  "id" : 199157639198945280,
  "in_reply_to_status_id" : 199157507669762049,
  "created_at" : "2012-05-06 15:24:16 +0000",
  "in_reply_to_screen_name" : "blacktelescope",
  "in_reply_to_user_id_str" : "14932763",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199151467272216579",
  "geo" : { },
  "id_str" : "199152800490471424",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard Just seems to be on Sundays that they cap me... Dunno about during the day since I am at work. Am happy otherwise :)",
  "id" : 199152800490471424,
  "in_reply_to_status_id" : 199151467272216579,
  "created_at" : "2012-05-06 15:05:02 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199152692982063104",
  "text" : "Back from the DVD place.. Sweeeeeet - I drove really *really* quick...",
  "id" : 199152692982063104,
  "created_at" : "2012-05-06 15:04:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199151011435257857",
  "text" : "Unrelated - seems that BT cap your usage to 2Mb\/s on a Sunday afternoon... Just sayin",
  "id" : 199151011435257857,
  "created_at" : "2012-05-06 14:57:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199150800474345474",
  "text" : "So The Expendables isn't available on LoveFilm... Guess I am gonna pop into my car and head to the DVD rental place.....",
  "id" : 199150800474345474,
  "created_at" : "2012-05-06 14:57:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199084195744727040",
  "geo" : { },
  "id_str" : "199094911621017602",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley Pete.... control... control!!!!!",
  "id" : 199094911621017602,
  "in_reply_to_status_id" : 199084195744727040,
  "created_at" : "2012-05-06 11:15:00 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199063008503279616",
  "geo" : { },
  "id_str" : "199066810673405952",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley \"6 pounds of pure plutonium is powerful enough to change the balance of the world. Imagine what 5 tonnes will do\". EPIC!!!",
  "id" : 199066810673405952,
  "in_reply_to_status_id" : 199063008503279616,
  "created_at" : "2012-05-06 09:23:20 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199063008503279616",
  "geo" : { },
  "id_str" : "199066152801013760",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson Yup - he needs to learn the ways of man... This is the ultimate bloke film... He needs to learn!",
  "id" : 199066152801013760,
  "in_reply_to_status_id" : 199063008503279616,
  "created_at" : "2012-05-06 09:20:43 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199060965361328131",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley I just watched The Expendables 2 trailer... Epic!!! I cannot wait....",
  "id" : 199060965361328131,
  "created_at" : "2012-05-06 09:00:07 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/199046992687677440\/photo\/1",
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/i72eDbEa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsMoL20CQAAa_QV.jpg",
      "id_str" : "199046992691871744",
      "id" : 199046992691871744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsMoL20CQAAa_QV.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/i72eDbEa"
    } ],
    "hashtags" : [ {
      "text" : "stringerbell",
      "indices" : [ 43, 56 ]
    }, {
      "text" : "notamused",
      "indices" : [ 57, 67 ]
    }, {
      "text" : "revenge",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199046992687677440",
  "text" : "Someone violated the Sunday morning truce? #stringerbell #notamused #revenge http:\/\/t.co\/i72eDbEa",
  "id" : 199046992687677440,
  "created_at" : "2012-05-06 08:04:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198887922433396736",
  "text" : "This film is taking itself seriously.....",
  "id" : 198887922433396736,
  "created_at" : "2012-05-05 21:32:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198879816991260672",
  "text" : "Watching Little Red Riding Hood.... Kinda fucked up if I am honest... Trying to be like Twlight I think...",
  "id" : 198879816991260672,
  "created_at" : "2012-05-05 21:00:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198862254882570240",
  "geo" : { },
  "id_str" : "198864699109031936",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley fat. cunt.",
  "id" : 198864699109031936,
  "in_reply_to_status_id" : 198862254882570240,
  "created_at" : "2012-05-05 20:00:13 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198860269601034240",
  "text" : "Chicken legs, sweet and sour sauce - hoven for 30mins and rice.. Epic meal.. Just saying..",
  "id" : 198860269601034240,
  "created_at" : "2012-05-05 19:42:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 73, 89 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198814438927765504",
  "geo" : { },
  "id_str" : "198815896402276353",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley Pete - we need to educate these fools... \/cc @michaelnsimpson",
  "id" : 198815896402276353,
  "in_reply_to_status_id" : 198814438927765504,
  "created_at" : "2012-05-05 16:46:18 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 1, 12 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 14, 20 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterwedding",
      "indices" : [ 43, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198813369074073600",
  "text" : "\u201C@Alana_Doll: @swmcc ok ill marry you : )\u201D #twitterwedding :)",
  "id" : 198813369074073600,
  "created_at" : "2012-05-05 16:36:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 15, 27 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198812193968496642",
  "geo" : { },
  "id_str" : "198812446226522115",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @kirstylvssp *FISTPUMP*",
  "id" : 198812446226522115,
  "in_reply_to_status_id" : 198812193968496642,
  "created_at" : "2012-05-05 16:32:35 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 1, 12 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 14, 20 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Alana_Doll\/status\/198811391078055937\/photo\/1",
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/5qqxWye7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsJR6CcCQAAiahb.jpg",
      "id_str" : "198811391086444544",
      "id" : 198811391086444544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsJR6CcCQAAiahb.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/5qqxWye7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198811716774150146",
  "text" : "\u201C@Alana_Doll: @swmcc they smell amazing!! http:\/\/t.co\/5qqxWye7\u201D When this woman opens a shop every bakery in NI is in trouble!!!",
  "id" : 198811716774150146,
  "created_at" : "2012-05-05 16:29:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bakinggoddess",
      "indices" : [ 37, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198811391078055937",
  "geo" : { },
  "id_str" : "198811626319777792",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll seriously... marry me... #bakinggoddess",
  "id" : 198811626319777792,
  "in_reply_to_status_id" : 198811391078055937,
  "created_at" : "2012-05-05 16:29:20 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "takeitback",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198810904534585344",
  "geo" : { },
  "id_str" : "198811140741005312",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley Peter... CONTROL YOUR WOMAN!!!!!! #takeitback",
  "id" : 198811140741005312,
  "in_reply_to_status_id" : 198810904534585344,
  "created_at" : "2012-05-05 16:27:24 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198702268139315200",
  "geo" : { },
  "id_str" : "198810263825293312",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley man up Henderson!!!!",
  "id" : 198810263825293312,
  "in_reply_to_status_id" : 198702268139315200,
  "created_at" : "2012-05-05 16:23:55 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 3, 14 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Alana_Doll\/status\/198747170105602048\/photo\/1",
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/PrFA1UrG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsIXf4qCMAACaWO.jpg",
      "id_str" : "198747170109796352",
      "id" : 198747170109796352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsIXf4qCMAACaWO.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/PrFA1UrG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198809854289260544",
  "text" : "RT @Alana_Doll: This is happening.. http:\/\/t.co\/PrFA1UrG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Alana_Doll\/status\/198747170105602048\/photo\/1",
        "indices" : [ 20, 40 ],
        "url" : "http:\/\/t.co\/PrFA1UrG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AsIXf4qCMAACaWO.jpg",
        "id_str" : "198747170109796352",
        "id" : 198747170109796352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsIXf4qCMAACaWO.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/PrFA1UrG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198747170105602048",
    "text" : "This is happening.. http:\/\/t.co\/PrFA1UrG",
    "id" : 198747170105602048,
    "created_at" : "2012-05-05 12:13:13 +0000",
    "user" : {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "protected" : false,
      "id_str" : "67130324",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3578323065\/bb177ebc2b37f1d2ee6f3eec1af258d0_normal.jpeg",
      "id" : 67130324,
      "verified" : false
    }
  },
  "id" : 198809854289260544,
  "created_at" : "2012-05-05 16:22:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198747170105602048",
  "geo" : { },
  "id_str" : "198809836429914113",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Baking porn...... I am gonna retweet this....",
  "id" : 198809836429914113,
  "in_reply_to_status_id" : 198747170105602048,
  "created_at" : "2012-05-05 16:22:13 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198706379408670720",
  "geo" : { },
  "id_str" : "198808648561065984",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson it is an awesome bloke film... You need to be educated in these ways Mike..",
  "id" : 198808648561065984,
  "in_reply_to_status_id" : 198706379408670720,
  "created_at" : "2012-05-05 16:17:30 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198808490737807360",
  "text" : "Lovely morning\/afternoon spent in Belfast.. The MAC is a nice place and the bistro place beside it is really nice.",
  "id" : 198808490737807360,
  "created_at" : "2012-05-05 16:16:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198683263454289920",
  "text" : "I really hate the word 'app'.",
  "id" : 198683263454289920,
  "created_at" : "2012-05-05 07:59:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 15, 27 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fatbastard",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198536259990339584",
  "geo" : { },
  "id_str" : "198553017396629505",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @kirstylvssp Well to be fair you did have two bacon baps and a big chippy for lunch too. #fatbastard",
  "id" : 198553017396629505,
  "in_reply_to_status_id" : 198536259990339584,
  "created_at" : "2012-05-04 23:21:42 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "indices" : [ 17, 27 ],
      "id_str" : "199486205",
      "id" : 199486205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198433633684566016",
  "geo" : { },
  "id_str" : "198493219389059073",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @aoifeb155 shut up simpson.. Next Friday I am gonna get in before you!!!",
  "id" : 198493219389059073,
  "in_reply_to_status_id" : 198433633684566016,
  "created_at" : "2012-05-04 19:24:05 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 3, 16 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198470172221259776",
  "text" : "RT @stevebiscuit: RIP Adam Yauch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198460774627295232",
    "text" : "RIP Adam Yauch",
    "id" : 198460774627295232,
    "created_at" : "2012-05-04 17:15:10 +0000",
    "user" : {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "protected" : false,
      "id_str" : "14068466",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1929736578\/steve_normal.png",
      "id" : 14068466,
      "verified" : false
    }
  },
  "id" : 198470172221259776,
  "created_at" : "2012-05-04 17:52:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 85, 98 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 99, 113 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 114, 130 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "killerkingoftascomi",
      "indices" : [ 63, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198443532275556352",
  "text" : "3 in a row again. What a way to end a shitty fucking week. \/cc #killerkingoftascomi  @RickyHassard @peter_omalley @michaelnsimpson",
  "id" : 198443532275556352,
  "created_at" : "2012-05-04 16:06:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "indices" : [ 91, 100 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "pyrotechnick",
      "screen_name" : "pyrotechnick",
      "indices" : [ 107, 120 ],
      "id_str" : "11366522",
      "id" : 11366522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198418148599410689",
  "text" : "I just found a testing framework in node.js that is based on Test::More &lt;3 &lt;3 Thanks @substack &amp; @pyrotechnick",
  "id" : 198418148599410689,
  "created_at" : "2012-05-04 14:25:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 3, 17 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/198413560907444224\/photo\/1",
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/g8IZWpdq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsDoFRjCMAA0CY8.jpg",
      "id_str" : "198413560911638528",
      "id" : 198413560911638528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsDoFRjCMAA0CY8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 427
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 427
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 427
      }, {
        "h" : 342,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g8IZWpdq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198413560907444224",
  "text" : "Yo @jenporterhall look at this cheeky expression.... Wonder what she'll be up to this bank holiday? http:\/\/t.co\/g8IZWpdq",
  "id" : 198413560907444224,
  "created_at" : "2012-05-04 14:07:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 0, 10 ],
      "id_str" : "7311162",
      "id" : 7311162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198395532736086017",
  "geo" : { },
  "id_str" : "198395955773587457",
  "in_reply_to_user_id" : 7311162,
  "text" : "@mharrigan you do reliase I am joking you fuckwit, don't you?",
  "id" : 198395955773587457,
  "in_reply_to_status_id" : 198395532736086017,
  "created_at" : "2012-05-04 12:57:36 +0000",
  "in_reply_to_screen_name" : "mharrigan",
  "in_reply_to_user_id_str" : "7311162",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198385239255547904",
  "text" : "I thought lesbians made everything better in the world... Today I was proved wrong. My universal theory ruined. What a shit cup of coffee :(",
  "id" : 198385239255547904,
  "created_at" : "2012-05-04 12:15:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 1, 15 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baconfriday",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198339469194178560",
  "text" : "\u201C@peter_omalley: #baconfriday was a great success today!\u201D It really was :)",
  "id" : 198339469194178560,
  "created_at" : "2012-05-04 09:13:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/198309598875234304\/photo\/1",
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/VM2nZ7om",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsCJh4zCMAEz9Hz.jpg",
      "id_str" : "198309598879428609",
      "id" : 198309598879428609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsCJh4zCMAEz9Hz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/VM2nZ7om"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198309598875234304",
  "text" : "Screw it :( http:\/\/t.co\/VM2nZ7om",
  "id" : 198309598875234304,
  "created_at" : "2012-05-04 07:14:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 32, 44 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wanker",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198307335532331009",
  "geo" : { },
  "id_str" : "198308202155229185",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley @niall_adams FUCK YOU!!! I am burning you stuff now as well.... #wanker And get the fuck off my chair!",
  "id" : 198308202155229185,
  "in_reply_to_status_id" : 198307335532331009,
  "created_at" : "2012-05-04 07:08:54 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198290195391582209",
  "geo" : { },
  "id_str" : "198295816555872256",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight awesome :D Right back at cha! :)",
  "id" : 198295816555872256,
  "in_reply_to_status_id" : 198290195391582209,
  "created_at" : "2012-05-04 06:19:41 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198163048798748675",
  "geo" : { },
  "id_str" : "198165066179280896",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley true true true :D :D And tomorrow is bacon friday.. Hitting the sack now so I can get up early :D",
  "id" : 198165066179280896,
  "in_reply_to_status_id" : 198163048798748675,
  "created_at" : "2012-05-03 21:40:08 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 30, 44 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "details",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198154178026156032",
  "geo" : { },
  "id_str" : "198163667001425920",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @michaelnsimpson @peter_omalley I never said I would kiss you on the lips!!!! #details",
  "id" : 198163667001425920,
  "in_reply_to_status_id" : 198154178026156032,
  "created_at" : "2012-05-03 21:34:34 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 29, 45 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 46, 60 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/198161326156152833\/photo\/1",
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/t2rTQqzu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsACrR4CAAE2Gdu.jpg",
      "id_str" : "198161326160347137",
      "id" : 198161326160347137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsACrR4CAAE2Gdu.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/t2rTQqzu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198161326156152833",
  "text" : "Now that was a burger... \/cc @michaelnsimpson @peter_omalley http:\/\/t.co\/t2rTQqzu",
  "id" : 198161326156152833,
  "created_at" : "2012-05-03 21:25:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198071462635126785",
  "geo" : { },
  "id_str" : "198073384666542081",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin I once got a server load to 64 :D Not something to proud off though... Was shitting it at the time - so didn't get a screeenshot",
  "id" : 198073384666542081,
  "in_reply_to_status_id" : 198071462635126785,
  "created_at" : "2012-05-03 15:35:49 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "indices" : [ 0, 7 ],
      "id_str" : "14060295",
      "id" : 14060295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198018306068856832",
  "geo" : { },
  "id_str" : "198019344716931072",
  "in_reply_to_user_id" : 14060295,
  "text" : "@cimota its just so the politicians can say \"50 high tech jobs\" - never mind they are in support roles and 30% subsidised for a few years.",
  "id" : 198019344716931072,
  "in_reply_to_status_id" : 198018306068856832,
  "created_at" : "2012-05-03 12:01:05 +0000",
  "in_reply_to_screen_name" : "cimota",
  "in_reply_to_user_id_str" : "14060295",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Taylor",
      "screen_name" : "marktaylor4294",
      "indices" : [ 3, 18 ],
      "id_str" : "222094103",
      "id" : 222094103
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 20, 34 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198018288779927552",
  "text" : "RT @marktaylor4294: @jenporterhall well that worked an absolute treat, can still hear the panic in the poor mans voice lol ;-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jenni Porter",
        "screen_name" : "jenporterhall",
        "indices" : [ 0, 14 ],
        "id_str" : "227493010",
        "id" : 227493010
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198016893355950080",
    "in_reply_to_user_id" : 227493010,
    "text" : "@jenporterhall well that worked an absolute treat, can still hear the panic in the poor mans voice lol ;-)",
    "id" : 198016893355950080,
    "created_at" : "2012-05-03 11:51:21 +0000",
    "in_reply_to_screen_name" : "jenporterhall",
    "in_reply_to_user_id_str" : "227493010",
    "user" : {
      "name" : "Mark Taylor",
      "screen_name" : "marktaylor4294",
      "protected" : true,
      "id_str" : "222094103",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2606383212\/image_normal.jpg",
      "id" : 222094103,
      "verified" : false
    }
  },
  "id" : 198018288779927552,
  "created_at" : "2012-05-03 11:56:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 38, 52 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Mark Taylor",
      "screen_name" : "marktaylor4294",
      "indices" : [ 57, 72 ],
      "id_str" : "222094103",
      "id" : 222094103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shittingmyselfstill",
      "indices" : [ 108, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198013953987706880",
  "text" : "Just got the shit scared out of me by @jenporterhall and @marktaylor4294.. Don't miss with Jenni... ever....#shittingmyselfstill",
  "id" : 198013953987706880,
  "created_at" : "2012-05-03 11:39:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotesstarwarsandisabakinggoddess",
      "indices" : [ 24, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197982867282857984",
  "geo" : { },
  "id_str" : "197983084002549760",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Marry me :D #quotesstarwarsandisabakinggoddess",
  "id" : 197983084002549760,
  "in_reply_to_status_id" : 197982867282857984,
  "created_at" : "2012-05-03 09:37:00 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197792979644203009",
  "geo" : { },
  "id_str" : "197794744208850944",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll pic or stfu :)",
  "id" : 197794744208850944,
  "in_reply_to_status_id" : 197792979644203009,
  "created_at" : "2012-05-02 21:08:36 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197777663530770433",
  "text" : "@MarkAMcGregor that's hardcore stuff with no helmet :)",
  "id" : 197777663530770433,
  "created_at" : "2012-05-02 20:00:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197777395091116032",
  "text" : "I just dug a rather big hole in my garden... Anyone fancy coming round and burying me in it? :) Awwwwww go on....",
  "id" : 197777395091116032,
  "created_at" : "2012-05-02 19:59:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197771509245284353",
  "text" : "@MarkAMcGregor bunch of nutters though. That game moves too fast for me to follow but its good craic. Don't know anyone sane that plays it.",
  "id" : 197771509245284353,
  "created_at" : "2012-05-02 19:36:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197770532345749505",
  "text" : "@MarkAMcGregor I haven't a clue how anyone can watch a sport that isn't golf or boxing. The rest are just boring :)",
  "id" : 197770532345749505,
  "created_at" : "2012-05-02 19:32:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Adams",
      "screen_name" : "badams",
      "indices" : [ 3, 10 ],
      "id_str" : "10704902",
      "id" : 10704902
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 23, 29 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197759835712925697",
  "text" : "RT @badams: @bkgStatus @swmcc I am indeed a SEO expert, but also one of the first to admit I can be a rather colossal wanker.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 11, 17 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "197735039105118208",
    "geo" : { },
    "id_str" : "197749934257213440",
    "in_reply_to_user_id" : 95932190,
    "text" : "@bkgStatus @swmcc I am indeed a SEO expert, but also one of the first to admit I can be a rather colossal wanker.",
    "id" : 197749934257213440,
    "in_reply_to_status_id" : 197735039105118208,
    "created_at" : "2012-05-02 18:10:33 +0000",
    "in_reply_to_screen_name" : "brrygrdn",
    "in_reply_to_user_id_str" : "95932190",
    "user" : {
      "name" : "Barry Adams",
      "screen_name" : "badams",
      "protected" : false,
      "id_str" : "10704902",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3661696352\/063b88717dd226e6c1ab02a83ce01c2a_normal.png",
      "id" : 10704902,
      "verified" : false
    }
  },
  "id" : 197759835712925697,
  "created_at" : "2012-05-02 18:49:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197745520796631040",
  "geo" : { },
  "id_str" : "197759309994655745",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq fuck em all :) Geddy seems like rails to me. I much prefer express - feels like dancer\/Sinatra.",
  "id" : 197759309994655745,
  "in_reply_to_status_id" : 197745520796631040,
  "created_at" : "2012-05-02 18:47:48 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/197758989520474113\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/ScVN50dN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar6UwNHCEAEdoFD.jpg",
      "id_str" : "197758989524668417",
      "id" : 197758989524668417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar6UwNHCEAEdoFD.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/ScVN50dN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197758989520474113",
  "text" : "My sister is a nurse. Found this at the kitchen table. Opened it up without reading the title. Not good :( http:\/\/t.co\/ScVN50dN",
  "id" : 197758989520474113,
  "created_at" : "2012-05-02 18:46:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197730080254996482",
  "geo" : { },
  "id_str" : "197730990762889216",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson aye - well I am pulling all that back a bit as I said :) Going round to my folks - if I insult them I am just giving up :)",
  "id" : 197730990762889216,
  "in_reply_to_status_id" : 197730080254996482,
  "created_at" : "2012-05-02 16:55:16 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197728341669838848",
  "geo" : { },
  "id_str" : "197728558989324288",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit \"SEO Experts\" this time... But they're like nuns (not real people) - so I probably get a pass on that :)",
  "id" : 197728558989324288,
  "in_reply_to_status_id" : 197728341669838848,
  "created_at" : "2012-05-02 16:45:36 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197728124765609984",
  "text" : "Not meaning to be insulting - just we have more twats per sq foot than is comfortable so I mix everyone in the same pot.  :(",
  "id" : 197728124765609984,
  "created_at" : "2012-05-02 16:43:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197727568676401154",
  "text" : "If I ever want to leave my current job (I don't) - I may move country. I've fucked off every recruiter and wannabe boss here :(",
  "id" : 197727568676401154,
  "created_at" : "2012-05-02 16:41:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Adams",
      "screen_name" : "badams",
      "indices" : [ 11, 18 ],
      "id_str" : "10704902",
      "id" : 10704902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197725628215209986",
  "geo" : { },
  "id_str" : "197727223103492096",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus @badams its black magic.. I have yet to meet an \"SEO expert\" and not think \"FUCKING KNOB TWAT WANKER CARWASH CUNT\".",
  "id" : 197727223103492096,
  "in_reply_to_status_id" : 197725628215209986,
  "created_at" : "2012-05-02 16:40:18 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197725557478277120",
  "geo" : { },
  "id_str" : "197725866925637632",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson not sure.... wasn't as bad as the last two days anyway :D",
  "id" : 197725866925637632,
  "in_reply_to_status_id" : 197725557478277120,
  "created_at" : "2012-05-02 16:34:54 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckwednesday",
      "indices" : [ 46, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197718907073740800",
  "text" : "16:54:55 Stevies-Mac-2: ~ $ brew install nmap #fuckwednesday",
  "id" : 197718907073740800,
  "created_at" : "2012-05-02 16:07:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 19, 29 ],
      "id_str" : "9713742",
      "id" : 9713742
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 30, 36 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197701741809119232",
  "text" : "\u201C@michaelnsimpson: @Burkazoid @swmcc @bkgStatus the man fucked with the biscuit stash, he needs to learn :)\u201D The Wire - I am Omar :D :D :D",
  "id" : 197701741809119232,
  "created_at" : "2012-05-02 14:59:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "upstairsbiscutemporer",
      "indices" : [ 61, 83 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197701051061772290",
  "geo" : { },
  "id_str" : "197701398400475136",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson too right.. His new title is #upstairsbiscutemporer",
  "id" : 197701398400475136,
  "in_reply_to_status_id" : 197701051061772290,
  "created_at" : "2012-05-02 14:57:41 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 11, 27 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "enjoy",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197700179229544449",
  "geo" : { },
  "id_str" : "197700443214852096",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid @michaelnsimpson @bkgstatus just put a biscut on his desk, open a new packet of biscuts and leave an empty packet out. #enjoy",
  "id" : 197700443214852096,
  "in_reply_to_status_id" : 197700179229544449,
  "created_at" : "2012-05-02 14:53:53 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 10, 26 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckwednesday",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197699130867449856",
  "text" : "Just made @michaelnsimpson lose it. He threw a tea cake at me... #fuckwednesday",
  "id" : 197699130867449856,
  "created_at" : "2012-05-02 14:48:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197630959410098176",
  "text" : "That moment when looking at old code and you think to yourself \"be better if I just rewrote this\"... \/me gets the toolbox out :)",
  "id" : 197630959410098176,
  "created_at" : "2012-05-02 10:17:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197616049666002944",
  "geo" : { },
  "id_str" : "197616778233393152",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit s\/following\/in\/ :D",
  "id" : 197616778233393152,
  "in_reply_to_status_id" : 197616049666002944,
  "created_at" : "2012-05-02 09:21:26 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/197614138896302081\/photo\/1",
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/K9iZ04wT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar4RAyfCQAETpU5.png",
      "id_str" : "197614138900496385",
      "id" : 197614138900496385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar4RAyfCQAETpU5.png",
      "sizes" : [ {
        "h" : 349,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/K9iZ04wT"
    } ],
    "hashtags" : [ {
      "text" : "fuckwednesday",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197614138896302081",
  "text" : "#fuckwednesday http:\/\/t.co\/K9iZ04wT",
  "id" : 197614138896302081,
  "created_at" : "2012-05-02 09:10:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 6, 20 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 25, 41 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckwednesday",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197609512390230016",
  "text" : "Right @peter_omalley and @michaelnsimpson - lets destroy this bitch!!!!!!! #fuckwednesday",
  "id" : 197609512390230016,
  "created_at" : "2012-05-02 08:52:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197430654869319681",
  "geo" : { },
  "id_str" : "197431473949786112",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit I've played with it lately. I have to say I quite like it.",
  "id" : 197431473949786112,
  "in_reply_to_status_id" : 197430654869319681,
  "created_at" : "2012-05-01 21:05:06 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197428574104469507",
  "geo" : { },
  "id_str" : "197429744512405506",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit python. You thinking of going to work for a local company that uses that these days? ;)",
  "id" : 197429744512405506,
  "in_reply_to_status_id" : 197428574104469507,
  "created_at" : "2012-05-01 20:58:13 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197426789763645440",
  "geo" : { },
  "id_str" : "197428488188346369",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne just imagine though this time next year - beetle counting :)",
  "id" : 197428488188346369,
  "in_reply_to_status_id" : 197426789763645440,
  "created_at" : "2012-05-01 20:53:14 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Georginaisawesome",
      "indices" : [ 73, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197423136596180992",
  "geo" : { },
  "id_str" : "197424766884384768",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne remember general rule number one when doing it though :) #Georginaisawesome :)",
  "id" : 197424766884384768,
  "in_reply_to_status_id" : 197423136596180992,
  "created_at" : "2012-05-01 20:38:27 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197417183985401856",
  "geo" : { },
  "id_str" : "197417562152251392",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne why?",
  "id" : 197417562152251392,
  "in_reply_to_status_id" : 197417183985401856,
  "created_at" : "2012-05-01 20:09:49 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ohfuckoff",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197416852559900673",
  "text" : "RT @dhh: Speaking of likes, followers, and check-ins, I can't stand businesses growling for them. Pleeeeease like us, follow us. #ohfuckoff",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ohfuckoff",
        "indices" : [ 120, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197416307518476289",
    "text" : "Speaking of likes, followers, and check-ins, I can't stand businesses growling for them. Pleeeeease like us, follow us. #ohfuckoff",
    "id" : 197416307518476289,
    "created_at" : "2012-05-01 20:04:50 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 197416852559900673,
  "created_at" : "2012-05-01 20:07:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197416679297396737",
  "text" : "Awwwwwwwe I do &lt;3 my mac book pro that work had given me. Kinds want my own though.. Thinking an air...",
  "id" : 197416679297396737,
  "created_at" : "2012-05-01 20:06:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197401687437230080",
  "geo" : { },
  "id_str" : "197405355305746434",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne sorry you meant what is wrong with me? Ack nothing just usual drama crap that gets me down... But sure :)",
  "id" : 197405355305746434,
  "in_reply_to_status_id" : 197401687437230080,
  "created_at" : "2012-05-01 19:21:18 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "exitstageleft",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197402924115181569",
  "geo" : { },
  "id_str" : "197404611127156737",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall :( \/me bows out of this convo #exitstageleft",
  "id" : 197404611127156737,
  "in_reply_to_status_id" : 197402924115181569,
  "created_at" : "2012-05-01 19:18:21 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besttweetever",
      "indices" : [ 32, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197404265373896704",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne how's your ass? #besttweetever",
  "id" : 197404265373896704,
  "created_at" : "2012-05-01 19:16:59 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197401687437230080",
  "geo" : { },
  "id_str" : "197404100776837120",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne just decided to update my skill base a bit. Need somewhere to put this new stuff and my old server was cheap and crap..",
  "id" : 197404100776837120,
  "in_reply_to_status_id" : 197401687437230080,
  "created_at" : "2012-05-01 19:16:19 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197393483470868480",
  "geo" : { },
  "id_str" : "197399884658262018",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley hmmmmm who knows. Tomorrow has to be better.. It is hump day after all :)",
  "id" : 197399884658262018,
  "in_reply_to_status_id" : 197393483470868480,
  "created_at" : "2012-05-01 18:59:34 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fucktuesdays",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197393103139766273",
  "text" : "Right tomorrow is another day... Just worked on my own stuff there for a wee bit - made me :D Tomorrow is a new day :) #fucktuesdays",
  "id" : 197393103139766273,
  "created_at" : "2012-05-01 18:32:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197391933834919936",
  "geo" : { },
  "id_str" : "197392859844976641",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley we fucking better cos if I don't have a win soon or at least get to do something that resembles dev work...",
  "id" : 197392859844976641,
  "in_reply_to_status_id" : 197391933834919936,
  "created_at" : "2012-05-01 18:31:39 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197380200206581760",
  "text" : "Right... homeward bound - new server ticking along nicely :)",
  "id" : 197380200206581760,
  "created_at" : "2012-05-01 17:41:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197370764163420160",
  "geo" : { },
  "id_str" : "197371122071769088",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq Ubuntu 11.04 - its going well so far - just installing the stuff I need now and then heading home :D Want an account?",
  "id" : 197371122071769088,
  "in_reply_to_status_id" : 197370764163420160,
  "created_at" : "2012-05-01 17:05:17 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197370316899618817",
  "geo" : { },
  "id_str" : "197370538455334912",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson Megan Fox couldn't even turn this fuck of a day round. I am going home. :)",
  "id" : 197370538455334912,
  "in_reply_to_status_id" : 197370316899618817,
  "created_at" : "2012-05-01 17:02:57 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 37, 53 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197337951183704064",
  "text" : "I think someone in here just mistook @michaelnsimpson for a developer... Awesome... \"So that's 1 to 100.... - Brilliant.. I get it\"...",
  "id" : 197337951183704064,
  "created_at" : "2012-05-01 14:53:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197277837584117760",
  "text" : "I'd say the 6MPs are now gonna find it hard to get re-elected in 2015 now :)",
  "id" : 197277837584117760,
  "created_at" : "2012-05-01 10:54:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linguist",
      "screen_name" : "cunninG",
      "indices" : [ 25, 33 ],
      "id_str" : "7017842",
      "id" : 7017842
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/197272374117273600\/photo\/1",
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/e6h4Kz2r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArzaLdeCEAALVTc.png",
      "id_str" : "197272374121467904",
      "id" : 197272374121467904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArzaLdeCEAALVTc.png",
      "sizes" : [ {
        "h" : 30,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 53,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 1289
      }, {
        "h" : 114,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/e6h4Kz2r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197272374117273600",
  "text" : "Stupid extra \"t\"...  \/cc @cunning http:\/\/t.co\/e6h4Kz2r",
  "id" : 197272374117273600,
  "created_at" : "2012-05-01 10:32:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyoutuesday",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197261982917861376",
  "geo" : { },
  "id_str" : "197263683200622592",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson you have no idea.... yeah I like this.. #fuckyoutuesday",
  "id" : 197263683200622592,
  "in_reply_to_status_id" : 197261982917861376,
  "created_at" : "2012-05-01 09:58:21 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197253078305607680",
  "text" : "Fucking Tuesday morning.....",
  "id" : 197253078305607680,
  "created_at" : "2012-05-01 09:16:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197225229045608448",
  "geo" : { },
  "id_str" : "197230117406261248",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq me too. Moved my own site to express but took away the rendering engine so uses static. Will add to it as I go :) work in progress",
  "id" : 197230117406261248,
  "in_reply_to_status_id" : 197225229045608448,
  "created_at" : "2012-05-01 07:44:59 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197220107053834242",
  "geo" : { },
  "id_str" : "197224592396402688",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq new server today! w00t :)",
  "id" : 197224592396402688,
  "in_reply_to_status_id" : 197220107053834242,
  "created_at" : "2012-05-01 07:23:01 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 9, 23 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197218102507880448",
  "text" : "Me &amp; @peter_omalley are blitzing a list of work today... A threesome of work. He starts at the top, me at the bottom &amp; meet in the middle :)",
  "id" : 197218102507880448,
  "created_at" : "2012-05-01 06:57:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]