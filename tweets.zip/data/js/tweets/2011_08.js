Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Hamill",
      "screen_name" : "gdh_gdh",
      "indices" : [ 64, 72 ],
      "id_str" : "139846667",
      "id" : 139846667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933266, -6.212655994 ]
  },
  "id_str" : "109001315975303168",
  "text" : "Wow! Ten years since 9\/11. Mad! I watched in work at Bytel with @gdh_gdh and a few others! Ten years!!",
  "id" : 109001315975303168,
  "created_at" : "2011-08-31 20:35:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 1, 14 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 16, 22 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badtaste",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933351467, -6.2125889233 ]
  },
  "id_str" : "108999573854363648",
  "text" : "\u201C@RickyHassard: @swmcc lieutenant dan? #badtaste\u201D he's been working with me too long. Love it :) awesome burn :)",
  "id" : 108999573854363648,
  "created_at" : "2011-08-31 20:28:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933387825, -6.212585535 ]
  },
  "id_str" : "108996966448504832",
  "text" : "Who wants to sell me a new pair of legs?",
  "id" : 108996966448504832,
  "created_at" : "2011-08-31 20:17:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108861272887529473",
  "text" : "Most annoying wee kids in the shop there - two of them shouting at the top of their lungs \"We want chocolate ice cream\" over and over again!",
  "id" : 108861272887529473,
  "created_at" : "2011-08-31 11:18:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108843620169297920",
  "geo" : { },
  "id_str" : "108843766512754688",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop a wiki and source control... next thing you'll be testing :) Proud of ya :)",
  "id" : 108843766512754688,
  "in_reply_to_status_id" : 108843620169297920,
  "created_at" : "2011-08-31 10:09:10 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108843012452401152",
  "geo" : { },
  "id_str" : "108843211514064896",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop nope that and the order of creating a symbolic link.. Also adduser v useradd... I am dumb",
  "id" : 108843211514064896,
  "in_reply_to_status_id" : 108843012452401152,
  "created_at" : "2011-08-31 10:06:58 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108842614131924992",
  "text" : "11.5 years working and I still have to look up the syntax for tar.",
  "id" : 108842614131924992,
  "created_at" : "2011-08-31 10:04:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "nichola mccrea",
      "screen_name" : "oldknickers",
      "indices" : [ 15, 27 ],
      "id_str" : "25062406",
      "id" : 25062406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108837520749498369",
  "geo" : { },
  "id_str" : "108838398902538240",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @oldknickers Plus he really is the most ginger person in the world. Dead on though which is rare in a ginger!",
  "id" : 108838398902538240,
  "in_reply_to_status_id" : 108837520749498369,
  "created_at" : "2011-08-31 09:47:51 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108814734761013248",
  "text" : "Forgot about the cleaners this morning. This wont be good with only 2 hours sleep last night.",
  "id" : 108814734761013248,
  "created_at" : "2011-08-31 08:13:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108809688166051840",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard is wearing a suit today. Tweeeeet tooooooooo :D",
  "id" : 108809688166051840,
  "created_at" : "2011-08-31 07:53:45 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 10, 23 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108649928582103040",
  "geo" : { },
  "id_str" : "108650121843056640",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq @rickyhassard Don't listen to Alvyn he's from Larne and possibly a bigger cock than you.. if possible :) But he's from Larne!",
  "id" : 108650121843056640,
  "in_reply_to_status_id" : 108649928582103040,
  "created_at" : "2011-08-30 21:19:42 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108615936432537600",
  "geo" : { },
  "id_str" : "108642822177034240",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard Beatrice Kennedys is really nice. But its nowhere near the Lyric.",
  "id" : 108642822177034240,
  "in_reply_to_status_id" : 108615936432537600,
  "created_at" : "2011-08-30 20:50:41 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108538210900115457",
  "text" : "Wondering why a function isn't working for the past 20mins. Finally worked out - I spelt the table name wrong. What a fucking idiot!!!!",
  "id" : 108538210900115457,
  "created_at" : "2011-08-30 13:55:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 19, 31 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108520760640929792",
  "text" : "Think I just broke @ryancunning... Oh dear....",
  "id" : 108520760640929792,
  "created_at" : "2011-08-30 12:45:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108515724296847360",
  "geo" : { },
  "id_str" : "108517374877118464",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin me ;)",
  "id" : 108517374877118464,
  "in_reply_to_status_id" : 108515724296847360,
  "created_at" : "2011-08-30 12:32:12 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 56, 68 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Awesome",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108501049039536128",
  "text" : "Just got to quote Father Fintan Jack from Father Ted to @stimpled0rf - been waiting since 1996 to do that :D #Awesome",
  "id" : 108501049039536128,
  "created_at" : "2011-08-30 11:27:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108496083042312192",
  "geo" : { },
  "id_str" : "108500870001463296",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf You're sitting there, imagining that, with a huge smile on your face.",
  "id" : 108500870001463296,
  "in_reply_to_status_id" : 108496083042312192,
  "created_at" : "2011-08-30 11:26:37 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108496083042312192",
  "geo" : { },
  "id_str" : "108500792239079424",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf And you, only you're thinking of what they'd look like without the shorts.",
  "id" : 108500792239079424,
  "in_reply_to_status_id" : 108496083042312192,
  "created_at" : "2011-08-30 11:26:19 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108496083042312192",
  "geo" : { },
  "id_str" : "108500681580744704",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf Youg boys running round in shorts. I bet you like that, don't you.",
  "id" : 108500681580744704,
  "in_reply_to_status_id" : 108496083042312192,
  "created_at" : "2011-08-30 11:25:52 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108496827300589568",
  "text" : "Going through a bug list and the Rocky theme came on.. Rather apt.. Just need Hearts on Fire to come on after :D \/me chops down some trees",
  "id" : 108496827300589568,
  "created_at" : "2011-08-30 11:10:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108493357361278976",
  "geo" : { },
  "id_str" : "108496509867278336",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore well fair point. I just think there is too much emphasis on chasing rainbows re: apps\/social media in the industry.",
  "id" : 108496509867278336,
  "in_reply_to_status_id" : 108493357361278976,
  "created_at" : "2011-08-30 11:09:18 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 14, 26 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108491412072435712",
  "geo" : { },
  "id_str" : "108493982044139520",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @stimpled0rf It is now marked in the board :) 30th August 2058 - \"Finally kick Rick in the nuts\" :D Please accept invite :)",
  "id" : 108493982044139520,
  "in_reply_to_status_id" : 108491412072435712,
  "created_at" : "2011-08-30 10:59:15 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 13, 24 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 51, 63 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108491954827960320",
  "geo" : { },
  "id_str" : "108492884759687169",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @alana_doll still a giant twat though @stimpled0rf. We are laybay buddies today :D",
  "id" : 108492884759687169,
  "in_reply_to_status_id" : 108491954827960320,
  "created_at" : "2011-08-30 10:54:54 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108492303861153792",
  "geo" : { },
  "id_str" : "108492624326967297",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore Hit the nail on the head. INI need to fuck up IMVHO and a few others.. An app isn't a business idea - just following the herd",
  "id" : 108492624326967297,
  "in_reply_to_status_id" : 108492303861153792,
  "created_at" : "2011-08-30 10:53:51 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 12, 25 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 66, 78 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108482926068498433",
  "text" : "Didn't kick @RickyHassard in the nuts. Had a meeting with him and @stimpled0rf and he helped me out with a few things. It'll happen though.",
  "id" : 108482926068498433,
  "created_at" : "2011-08-30 10:15:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http:\/\/t.co\/0OQTC29",
      "expanded_url" : "http:\/\/yfrog.com\/mfvhupuj",
      "display_url" : "yfrog.com\/mfvhupuj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593334195, -6.21270978 ]
  },
  "id_str" : "108294667057106944",
  "text" : "Oh yeah.. Oh yeah. Watching Entourage...  http:\/\/t.co\/0OQTC29",
  "id" : 108294667057106944,
  "created_at" : "2011-08-29 21:47:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 15, 28 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108285711505031168",
  "geo" : { },
  "id_str" : "108290620916903936",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @rickyhassard FOOTBALL NERDS",
  "id" : 108290620916903936,
  "in_reply_to_status_id" : 108285711505031168,
  "created_at" : "2011-08-29 21:31:10 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 62, 75 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 77, 83 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesometuesday",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933386625, -6.21258862 ]
  },
  "id_str" : "108240282117607424",
  "text" : "Legally binding... I get to kick him in the nuts tomorrow :) \u201C@RickyHassard: @swmcc lucky me :-) looking forward to it!\u201D #awesometuesday",
  "id" : 108240282117607424,
  "created_at" : "2011-08-29 18:11:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108148671580880898",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5932993525, -6.21236756 ]
  },
  "id_str" : "108160002350522368",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin tight bastard :)",
  "id" : 108160002350522368,
  "in_reply_to_status_id" : 108148671580880898,
  "created_at" : "2011-08-29 12:52:08 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108141303652564992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593302518, -6.212260982 ]
  },
  "id_str" : "108147848071217152",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin it's the film. Ffs. I dunno. Lucky I is pretty :)",
  "id" : 108147848071217152,
  "in_reply_to_status_id" : 108141303652564992,
  "created_at" : "2011-08-29 12:03:50 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108141303652564992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933386625, -6.21258862 ]
  },
  "id_str" : "108144982124281856",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin honeymoon period already over?",
  "id" : 108144982124281856,
  "in_reply_to_status_id" : 108141303652564992,
  "created_at" : "2011-08-29 11:52:27 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 47, 60 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933020075, -6.2126281825 ]
  },
  "id_str" : "108143302792060928",
  "text" : "Got new floor and new curtains there. Was near @RickyHassard abode. Was gonna call in and give him a kickin. Will save it for tomorrow.",
  "id" : 108143302792060928,
  "created_at" : "2011-08-29 11:45:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107946370094219264",
  "text" : "OH: \"It's not so much a bollocks wank it's more of a fuck in the mouth\"",
  "id" : 107946370094219264,
  "created_at" : "2011-08-28 22:43:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107873764074725376",
  "text" : "Seems my TV has problems playing files over 2Gig. Not sure if its that or the DLNA server. Probably the TV.. Grrrr - rather annoying.",
  "id" : 107873764074725376,
  "created_at" : "2011-08-28 17:54:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 25 ],
      "url" : "http:\/\/t.co\/zeyHwqT",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=LHBpQQ6ZeP4&feature=related",
      "display_url" : "youtube.com\/watch?v=LHBpQQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "107748292368142336",
  "text" : "WTF.. http:\/\/t.co\/zeyHwqT",
  "id" : 107748292368142336,
  "created_at" : "2011-08-28 09:36:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107555266253430786",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933334, -6.2125109 ]
  },
  "id_str" : "107561281048944640",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf am sure you could hazard a guess :) Am feeling much better.. Am gonna be stuck to you like shit on rice next week :)",
  "id" : 107561281048944640,
  "in_reply_to_status_id" : 107555266253430786,
  "created_at" : "2011-08-27 21:13:02 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107559642632159232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933334, -6.2125109 ]
  },
  "id_str" : "107560867176001536",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit good call... Wonder if it's on Lovefilm... *click* yup there it is ;)",
  "id" : 107560867176001536,
  "in_reply_to_status_id" : 107559642632159232,
  "created_at" : "2011-08-27 21:11:23 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http:\/\/t.co\/QFvJ22A",
      "expanded_url" : "http:\/\/yfrog.com\/h81fwzwkj",
      "display_url" : "yfrog.com\/h81fwzwkj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933334, -6.2125109 ]
  },
  "id_str" : "107560553312043008",
  "text" : "Seems The Matrix Reloaded is just as shit on my new tv as it was in the old tv and the cinema.  http:\/\/t.co\/QFvJ22A",
  "id" : 107560553312043008,
  "created_at" : "2011-08-27 21:10:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107481639935946754",
  "text" : "Bro's chilli-con-carnie was awesome though.",
  "id" : 107481639935946754,
  "created_at" : "2011-08-27 15:56:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107481510482939904",
  "text" : "Didn't get a chance to buy the floor. Was gonna go into work on Monday but now I think I will procure the floor then! Need it!",
  "id" : 107481510482939904,
  "created_at" : "2011-08-27 15:56:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107464026774175744",
  "geo" : { },
  "id_str" : "107480204406034433",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf Dusseldorf BSc Msc WKR - nice ring to it :)",
  "id" : 107480204406034433,
  "in_reply_to_status_id" : 107464026774175744,
  "created_at" : "2011-08-27 15:50:52 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.591849735, -5.88320028 ]
  },
  "id_str" : "107452329619505152",
  "text" : "In the brothers house.... He is making me chilli..... News to go buy a floor.. Euuggggghhhhhhh.....",
  "id" : 107452329619505152,
  "created_at" : "2011-08-27 14:00:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.61997926, -6.20613712 ]
  },
  "id_str" : "106942851006472193",
  "text" : "Hmmm temp has creeped up to 39 again.... Driving is gonna be fun...",
  "id" : 106942851006472193,
  "created_at" : "2011-08-26 04:15:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.61997926, -6.20613712 ]
  },
  "id_str" : "106941634138226688",
  "text" : "Back in Antrim.... Awesome... Work tweeps see you Tuesday... Leg has flared up again......",
  "id" : 106941634138226688,
  "created_at" : "2011-08-26 04:10:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106789452793397248",
  "text" : "Hmmm... Leg is getting sore. First day without meds.. Hopefully the heat wont come back and I am just being a pussy!!!! Time will tell....",
  "id" : 106789452793397248,
  "created_at" : "2011-08-25 18:06:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330649, -6.2125086725 ]
  },
  "id_str" : "106768301140611073",
  "text" : "I was twaped earlier today.",
  "id" : 106768301140611073,
  "created_at" : "2011-08-25 16:42:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106757338609885184",
  "geo" : { },
  "id_str" : "106758382182080514",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf fuck you dusseldorf!!!!",
  "id" : 106758382182080514,
  "in_reply_to_status_id" : 106757338609885184,
  "created_at" : "2011-08-25 16:02:36 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 32, 44 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106751748483448832",
  "geo" : { },
  "id_str" : "106751967778447362",
  "in_reply_to_user_id" : 28624459,
  "text" : "I apologise for my rant against @niall_adams. I got caught up in my own mob mentality there! Dangerous. Love ya Nail x",
  "id" : 106751967778447362,
  "in_reply_to_status_id" : 106751748483448832,
  "created_at" : "2011-08-25 15:37:07 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 15, 27 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106742231360217088",
  "text" : "I FUCKING HATE @niall_adams. He is an utter utter cock of the highest order!",
  "id" : 106742231360217088,
  "created_at" : "2011-08-25 14:58:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.48841589, -6.07933437 ]
  },
  "id_str" : "106731704085000192",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf I want you. Now.",
  "id" : 106731704085000192,
  "created_at" : "2011-08-25 14:16:35 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106665239600308224",
  "text" : "So this is Thursday then.. Finding it hard to fit into the groove....",
  "id" : 106665239600308224,
  "created_at" : "2011-08-25 09:52:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "heartsonfire",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106368154539802624",
  "geo" : { },
  "id_str" : "106368453404934144",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore not a vacation.. Need to toughen up. Think Rocky IV training montage in Siberia!! #heartsonfire",
  "id" : 106368453404934144,
  "in_reply_to_status_id" : 106368154539802624,
  "created_at" : "2011-08-24 14:13:10 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106366462674997250",
  "geo" : { },
  "id_str" : "106366834571350017",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore it is war you hippie!!!! You've gone soft in Belfast.. You need a fortnight back in Derry to toughen you up :)",
  "id" : 106366834571350017,
  "in_reply_to_status_id" : 106366462674997250,
  "created_at" : "2011-08-24 14:06:44 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 14, 23 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106366163533053952",
  "geo" : { },
  "id_str" : "106366316335734786",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @alvynmcq you two are knobs.. so it proves my case... knobs!",
  "id" : 106366316335734786,
  "in_reply_to_status_id" : 106366163533053952,
  "created_at" : "2011-08-24 14:04:40 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 7, 21 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106365747667800066",
  "geo" : { },
  "id_str" : "106366052409163776",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @no_underscore afore mentioned studio will remain nameless - but I can get you a load of devs that would relish a chance for payback!",
  "id" : 106366052409163776,
  "in_reply_to_status_id" : 106365747667800066,
  "created_at" : "2011-08-24 14:03:37 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Front",
      "screen_name" : "designbyfront",
      "indices" : [ 49, 63 ],
      "id_str" : "15629803",
      "id" : 15629803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106364198778441728",
  "geo" : { },
  "id_str" : "106365747667800066",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore destroy your rivals - well I like @designbyfront they are nice. But if you want a hand taking on another studio just ask :)",
  "id" : 106365747667800066,
  "in_reply_to_status_id" : 106364198778441728,
  "created_at" : "2011-08-24 14:02:25 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106346777631924224",
  "geo" : { },
  "id_str" : "106346938345078784",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin FFS.... Correcting a geek joke... Hang your head in shame also!",
  "id" : 106346938345078784,
  "in_reply_to_status_id" : 106346777631924224,
  "created_at" : "2011-08-24 12:47:40 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 35, 48 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106345748496527360",
  "text" : "\"There is no place like 127.0.0.1\" @RickyHassard should hang his head in shame at that joke!",
  "id" : 106345748496527360,
  "created_at" : "2011-08-24 12:42:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106311101381214208",
  "text" : "My new aim in life is to be Roger Sterling from Mad Men. Obv without the sexism or racism... He has a sweet life!",
  "id" : 106311101381214208,
  "created_at" : "2011-08-24 10:25:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106129800879550464",
  "geo" : { },
  "id_str" : "106282283182465024",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit thanks but need another week for this leg to heal properly, at least. But its almost back to normal :)",
  "id" : 106282283182465024,
  "in_reply_to_status_id" : 106129800879550464,
  "created_at" : "2011-08-24 08:30:45 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330649, -6.2125086725 ]
  },
  "id_str" : "106117089458270208",
  "text" : "Watching my first ropy of big bro.. Sally Bercow... She's an intellectual giant compared to the rest of them. That's not a compliment.",
  "id" : 106117089458270208,
  "created_at" : "2011-08-23 21:34:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106111707994263552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330649, -6.2125086725 ]
  },
  "id_str" : "106116263549485056",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you are great at getting ppl to do new things :) can't wait till leg heals and I get up those mountains again :)",
  "id" : 106116263549485056,
  "in_reply_to_status_id" : 106111707994263552,
  "created_at" : "2011-08-23 21:31:03 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106074301597364224",
  "geo" : { },
  "id_str" : "106077273291104256",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard I think we have known each other long enough to know the answer to that....",
  "id" : 106077273291104256,
  "in_reply_to_status_id" : 106074301597364224,
  "created_at" : "2011-08-23 18:56:07 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106066215683887105",
  "text" : "Anyone see my phone? I lost it this morning... Can't find it anywhere... Fuck sake...",
  "id" : 106066215683887105,
  "created_at" : "2011-08-23 18:12:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106019006888165376",
  "geo" : { },
  "id_str" : "106019868901515264",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll brilliant! Congrats..",
  "id" : 106019868901515264,
  "in_reply_to_status_id" : 106019006888165376,
  "created_at" : "2011-08-23 15:08:01 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105997966787100672",
  "geo" : { },
  "id_str" : "106017809787650049",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll am feeling much better now thanks. :) SW going well?",
  "id" : 106017809787650049,
  "in_reply_to_status_id" : 105997966787100672,
  "created_at" : "2011-08-23 14:59:50 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105975038511038465",
  "geo" : { },
  "id_str" : "105987787555213313",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll I love your work too! :D",
  "id" : 105987787555213313,
  "in_reply_to_status_id" : 105975038511038465,
  "created_at" : "2011-08-23 13:00:32 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105929710508326912",
  "geo" : { },
  "id_str" : "105943434329722880",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin this is my first big one in about 5 years - deffo harder to get over this time. But sure - will get there :)",
  "id" : 105943434329722880,
  "in_reply_to_status_id" : 105929710508326912,
  "created_at" : "2011-08-23 10:04:17 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105927055761358848",
  "geo" : { },
  "id_str" : "105928174738735104",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore got a nasty leg infection last week that's knocked the lining out of me. I'll be back to norm in a few weeks though :)",
  "id" : 105928174738735104,
  "in_reply_to_status_id" : 105927055761358848,
  "created_at" : "2011-08-23 09:03:39 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105926276660985856",
  "text" : "Wrecked.com - walked from the laybay to the office. Sweat lashing of me now... Only way the leg will get stronger though.. *ouch*",
  "id" : 105926276660985856,
  "created_at" : "2011-08-23 08:56:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/5pjv8ms",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=NUQ-dpb0CaY",
      "display_url" : "youtube.com\/watch?v=NUQ-dp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105741703784312832",
  "text" : "Who needs Don Draper - http:\/\/t.co\/5pjv8ms",
  "id" : 105741703784312832,
  "created_at" : "2011-08-22 20:42:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330649, -6.2125086725 ]
  },
  "id_str" : "105735892467073024",
  "text" : "I can't be alone in wanting to kick Jamie Oliver surely? Just something utterly slappable about yon bloke!",
  "id" : 105735892467073024,
  "created_at" : "2011-08-22 20:19:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105720454869815296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59333042, -6.2127000867 ]
  },
  "id_str" : "105720759351123968",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg guess the stock will have to do instead ;)",
  "id" : 105720759351123968,
  "in_reply_to_status_id" : 105720454869815296,
  "created_at" : "2011-08-22 19:19:27 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105709746862047232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59333412, -6.2125097475 ]
  },
  "id_str" : "105719878933164032",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg you not get employee discount on those things? Am on the wall with hp v iPad.",
  "id" : 105719878933164032,
  "in_reply_to_status_id" : 105709746862047232,
  "created_at" : "2011-08-22 19:15:57 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 22, 29 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105656107078393856",
  "text" : "Just gotta cuppa from @srushe - cheers :D",
  "id" : 105656107078393856,
  "created_at" : "2011-08-22 15:02:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105648103230681089",
  "text" : "Someone in work just reminded me that we have a bank holiday coming up... Sweet! :D",
  "id" : 105648103230681089,
  "created_at" : "2011-08-22 14:30:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105627146977939456",
  "text" : "I miss PERL... This isn't too bad though - print_r(array_keys($array));",
  "id" : 105627146977939456,
  "created_at" : "2011-08-22 13:07:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105611069271183360",
  "text" : "New Official Enemy. Cheeky Indian bitch that rings up and has my extension (for some reason). She just hung up on me. 2moro should be fun!",
  "id" : 105611069271183360,
  "created_at" : "2011-08-22 12:03:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    }, {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 13, 27 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105580841907920897",
  "geo" : { },
  "id_str" : "105581965301923840",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop @madebyrichard fuck up :) I just hate that self wanking INI culture that is apparent in \"startups\" in NI. A few ppl annoy me!",
  "id" : 105581965301923840,
  "in_reply_to_status_id" : 105580841907920897,
  "created_at" : "2011-08-22 10:07:56 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105579863058030592",
  "geo" : { },
  "id_str" : "105580284967272448",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop hmm.. Good call - that'd mean going near their twitter feed though and it would wind me up...",
  "id" : 105580284967272448,
  "in_reply_to_status_id" : 105579863058030592,
  "created_at" : "2011-08-22 10:01:16 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105579614478401536",
  "text" : "Even when you un-follow twats - you till tend to see their RT's. Seriously - get a fucking room. Self wanking sector.... Disgusts me.",
  "id" : 105579614478401536,
  "created_at" : "2011-08-22 09:58:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105567378426970112",
  "geo" : { },
  "id_str" : "105570528621887488",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop when someone pays you enough money you'll do it - believe me :)",
  "id" : 105570528621887488,
  "in_reply_to_status_id" : 105567378426970112,
  "created_at" : "2011-08-22 09:22:30 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105565905370615808",
  "geo" : { },
  "id_str" : "105567115511205888",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop hence my pain! He deduced that email wasn't working because he hadn't received any. Thought me sending an email would have...",
  "id" : 105567115511205888,
  "in_reply_to_status_id" : 105565905370615808,
  "created_at" : "2011-08-22 09:08:56 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105565669713645568",
  "text" : "First email I get from a customer from coming back \"Stevie - email isn't working\" - I ask how they know \"Haven't received any!\".",
  "id" : 105565669713645568,
  "created_at" : "2011-08-22 09:03:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105549430576525312",
  "text" : "Is back in work - my leg is not happy - it should shut up soon :)",
  "id" : 105549430576525312,
  "created_at" : "2011-08-22 07:58:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59733372, -6.20922815 ]
  },
  "id_str" : "105340143375880192",
  "text" : "My right foot is easily five times as big as it should be! Kinda curious lookin!",
  "id" : 105340143375880192,
  "created_at" : "2011-08-21 18:07:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105263673563553793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59333412, -6.2125097475 ]
  },
  "id_str" : "105266813822173184",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams much better thanks :) Really sore today but that's to be expected. Back tomorrow.",
  "id" : 105266813822173184,
  "in_reply_to_status_id" : 105263673563553793,
  "created_at" : "2011-08-21 13:15:38 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105253228471517184",
  "text" : "Leg is killing me today :( Stupid thing........",
  "id" : 105253228471517184,
  "created_at" : "2011-08-21 12:21:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104976749531631616",
  "text" : "Tesco run down... Leg is killing me now.. Guess it will be a while before long walks are back in order!",
  "id" : 104976749531631616,
  "created_at" : "2011-08-20 18:03:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104956259182190592",
  "text" : "Gotta go get supplies @ Tesco now... Eugggggghhhhhh",
  "id" : 104956259182190592,
  "created_at" : "2011-08-20 16:41:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933573525, -6.21267202 ]
  },
  "id_str" : "104677261055246336",
  "text" : "\"Hmmm look see in the middle here it was so hot it made your outer skin bubble and blister\"...",
  "id" : 104677261055246336,
  "created_at" : "2011-08-19 22:12:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933573525, -6.21267202 ]
  },
  "id_str" : "104676852173520896",
  "text" : "Leg has it's own pulse at the mo... Pretty cool ! Doc today took great interest in it - I tend not to look at it.. He said.....",
  "id" : 104676852173520896,
  "created_at" : "2011-08-19 22:11:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104273458959101955",
  "text" : "Hmmmm seems that meal at 11:30 is all I need for today :( Hopefully wake up hungry tomorrow. But since I've been up all day I am whacked",
  "id" : 104273458959101955,
  "created_at" : "2011-08-18 19:28:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330192, -6.212606935 ]
  },
  "id_str" : "104213086583529474",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning enjoy your last hour. Dick weasel!",
  "id" : 104213086583529474,
  "created_at" : "2011-08-18 15:28:30 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 3, 16 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104207577474269184",
  "text" : "RT @RickyHassard: @swmcc woot: (especially in electronic communication) used to express elation, enthusiasm, or triumph.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104198572454592512",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc woot: (especially in electronic communication) used to express elation, enthusiasm, or triumph.",
    "id" : 104198572454592512,
    "created_at" : "2011-08-18 14:30:50 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "protected" : false,
      "id_str" : "5684272",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1317084795\/Screen_shot_2011-04-19_at_13.00.12_normal.png",
      "id" : 5684272,
      "verified" : false
    }
  },
  "id" : 104207577474269184,
  "created_at" : "2011-08-18 15:06:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104207196233007104",
  "in_reply_to_user_id" : 5684272,
  "text" : "@rickyhassard: (a knob)",
  "id" : 104207196233007104,
  "created_at" : "2011-08-18 15:05:06 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104186583430856704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330192, -6.212606935 ]
  },
  "id_str" : "104186977724792832",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus on the mend. Way better than yesterday and ten times better than the day before. Can now walk again (albeit like a 80yr old) :)",
  "id" : 104186977724792832,
  "in_reply_to_status_id" : 104186583430856704,
  "created_at" : "2011-08-18 13:44:45 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104184968284078080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.6001842, -6.21155679 ]
  },
  "id_str" : "104185998929440768",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus i did a few years ago :) Sorry for rants. Just haven't spoke to anyone since Sunday morning. Getting cabin fever!",
  "id" : 104185998929440768,
  "in_reply_to_status_id" : 104184968284078080,
  "created_at" : "2011-08-18 13:40:52 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330192, -6.212606935 ]
  },
  "id_str" : "104185743299190784",
  "text" : "To take up a spot that someone else might need? Insane. And all I need is flucloxacillin - won't get you high but will give you anal leakage",
  "id" : 104185743299190784,
  "created_at" : "2011-08-18 13:39:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330192, -6.212606935 ]
  },
  "id_str" : "104185267203739648",
  "text" : "Surely there is a rec of me being admitted to hosp with what drugs I got home with me. Can the GP just not renew it without me having..",
  "id" : 104185267203739648,
  "created_at" : "2011-08-18 13:37:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330192, -6.212606935 ]
  },
  "id_str" : "104183988394012673",
  "text" : ".. an appointment tomorrow. Why couldn't they just give me the appointment in the first place!",
  "id" : 104183988394012673,
  "created_at" : "2011-08-18 13:32:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330192, -6.212606935 ]
  },
  "id_str" : "104183256949338112",
  "text" : "Fucking NHS. Drugs run out tomorrow. GP refused to see me to renew prescription. I say I am going to casualty then they magically find..",
  "id" : 104183256949338112,
  "created_at" : "2011-08-18 13:29:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104148327888715776",
  "text" : "Just over an hour to eat one bit of lasagne - but its all gone :)",
  "id" : 104148327888715776,
  "created_at" : "2011-08-18 11:11:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 0, 9 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104132794678120448",
  "in_reply_to_user_id" : 14961440,
  "text" : "@akaihane I was just watching it - never said I was a fan :)",
  "id" : 104132794678120448,
  "created_at" : "2011-08-18 10:09:27 +0000",
  "in_reply_to_screen_name" : "akaihane",
  "in_reply_to_user_id_str" : "14961440",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104132490523975680",
  "text" : "am just about to sit down to my first meal since Sunday morning... With strawberry Crusha!!!! :) Leg is still complety FUBARD though :)",
  "id" : 104132490523975680,
  "created_at" : "2011-08-18 10:08:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103958326332760065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593321178, -6.212601408 ]
  },
  "id_str" : "103958615102197760",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe I can live with guilt. I have perfected it! I'll be back to annoy you Monday so be nice!! :)",
  "id" : 103958615102197760,
  "in_reply_to_status_id" : 103958326332760065,
  "created_at" : "2011-08-17 22:37:19 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 8, 17 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103957170239971329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59332448, -6.2126984 ]
  },
  "id_str" : "103957606586007552",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe @manyhues Team Edward.",
  "id" : 103957606586007552,
  "in_reply_to_status_id" : 103957170239971329,
  "created_at" : "2011-08-17 22:33:19 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 0, 10 ],
      "id_str" : "7311162",
      "id" : 7311162
    }, {
      "name" : "Gavin Hamill",
      "screen_name" : "gdh_gdh",
      "indices" : [ 11, 19 ],
      "id_str" : "139846667",
      "id" : 139846667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103942146058493953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933130933, -6.2126221833 ]
  },
  "id_str" : "103949092203401216",
  "in_reply_to_user_id" : 7311162,
  "text" : "@mharrigan @gdh_gdh GDH still uses Windows NT 4.1",
  "id" : 103949092203401216,
  "in_reply_to_status_id" : 103942146058493953,
  "created_at" : "2011-08-17 21:59:29 +0000",
  "in_reply_to_screen_name" : "mharrigan",
  "in_reply_to_user_id_str" : "7311162",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103935059035295745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933130933, -6.2126221833 ]
  },
  "id_str" : "103947807274176512",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning that means switching on computer in other room. It was enough to get out of bed today lol.",
  "id" : 103947807274176512,
  "in_reply_to_status_id" : 103935059035295745,
  "created_at" : "2011-08-17 21:54:23 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933130933, -6.2126221833 ]
  },
  "id_str" : "103907597769388033",
  "text" : "I am watching Twilight... Yes. I am a 15 year old girl! Leave me alone Donkeys!",
  "id" : 103907597769388033,
  "created_at" : "2011-08-17 19:14:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 54, 66 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103887866991616000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329986, -6.212610005 ]
  },
  "id_str" : "103888093484023809",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc I am starting to feel better. Still as weak as @niall_adams but that will improve in time :)",
  "id" : 103888093484023809,
  "in_reply_to_status_id" : 103887866991616000,
  "created_at" : "2011-08-17 17:57:06 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329986, -6.212610005 ]
  },
  "id_str" : "103887866991616000",
  "text" : "Its official tweeps. I know I might've tempting fate... But whoo hoooo",
  "id" : 103887866991616000,
  "created_at" : "2011-08-17 17:56:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103878778274594816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933130933, -6.2126221833 ]
  },
  "id_str" : "103884777244983296",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke and backwards compatible to Netscape Navigator.",
  "id" : 103884777244983296,
  "in_reply_to_status_id" : 103878778274594816,
  "created_at" : "2011-08-17 17:43:55 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 97, 110 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103831683933011968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329986, -6.212610005 ]
  },
  "id_str" : "103834500026470401",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning RVH Hopefully won't happen. I'd it does you are not welcome :) I hate you more than @RickyHassard right now, you bastard!",
  "id" : 103834500026470401,
  "in_reply_to_status_id" : 103831683933011968,
  "created_at" : "2011-08-17 14:24:08 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the black telescope",
      "screen_name" : "blacktelescope",
      "indices" : [ 0, 15 ],
      "id_str" : "14932763",
      "id" : 14932763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103831505285038081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933477375, -6.2126936875 ]
  },
  "id_str" : "103832433736167424",
  "in_reply_to_user_id" : 14932763,
  "text" : "@blacktelescope no they were very cool! loved that film.",
  "id" : 103832433736167424,
  "in_reply_to_status_id" : 103831505285038081,
  "created_at" : "2011-08-17 14:15:55 +0000",
  "in_reply_to_screen_name" : "blacktelescope",
  "in_reply_to_user_id_str" : "14932763",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the black telescope",
      "screen_name" : "blacktelescope",
      "indices" : [ 0, 15 ],
      "id_str" : "14932763",
      "id" : 14932763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103829815785832448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933477375, -6.2126936875 ]
  },
  "id_str" : "103830836092215297",
  "in_reply_to_user_id" : 14932763,
  "text" : "@blacktelescope just worked out that your wee girl in it played the prostitute in Sin City. Was doing my head in.",
  "id" : 103830836092215297,
  "in_reply_to_status_id" : 103829815785832448,
  "created_at" : "2011-08-17 14:09:35 +0000",
  "in_reply_to_screen_name" : "blacktelescope",
  "in_reply_to_user_id_str" : "14932763",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329779, -6.21266311 ]
  },
  "id_str" : "103829534608080896",
  "text" : "Dunno what's worse that I can't walk or I am now addicted to The Gilmore Girls",
  "id" : 103829534608080896,
  "created_at" : "2011-08-17 14:04:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5934891667, -6.2128758333 ]
  },
  "id_str" : "103827392744792065",
  "text" : "Apparently if this leg doesn't get better I will be admitted into hospital tomorrow. That's nice, that's fucking nice!",
  "id" : 103827392744792065,
  "created_at" : "2011-08-17 13:55:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103818700125241344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329986, -6.212610005 ]
  },
  "id_str" : "103827122954571776",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning if it does I will get it home with me... And shove it up your extremely hairy, very ginger hole!!!",
  "id" : 103827122954571776,
  "in_reply_to_status_id" : 103818700125241344,
  "created_at" : "2011-08-17 13:54:49 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Cole Henley",
      "screen_name" : "cole007",
      "indices" : [ 14, 22 ],
      "id_str" : "7400342",
      "id" : 7400342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103818335631851520",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @cole007 but not at those wages",
  "id" : 103818335631851520,
  "created_at" : "2011-08-17 13:19:54 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cole Henley",
      "screen_name" : "cole007",
      "indices" : [ 1, 9 ],
      "id_str" : "7400342",
      "id" : 7400342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933477375, -6.2126936875 ]
  },
  "id_str" : "103808126846894081",
  "text" : "\u201C@cole007: Web job advertised up to \u00A355k requires experience in DHTML. Does anyone still call it to DHTML?\u201D typical recruiters - know f all",
  "id" : 103808126846894081,
  "created_at" : "2011-08-17 12:39:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 13, 25 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103796425854418944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933477375, -6.2126936875 ]
  },
  "id_str" : "103798846404042752",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @ryancunning I haven't ate anything but 2 slicesof bread since Sunday night so that doesn't Annoy it me too much, but it will..",
  "id" : 103798846404042752,
  "in_reply_to_status_id" : 103796425854418944,
  "created_at" : "2011-08-17 12:02:28 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 48, 60 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CW",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59865444, -6.21127194 ]
  },
  "id_str" : "103789486349094912",
  "text" : "Starting - cockwednesdays (CW). This weeks it's @ryancunning he looks like ron weasley and has taken the piss out of me who is vry sick. #CW",
  "id" : 103789486349094912,
  "created_at" : "2011-08-17 11:25:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103780107499487232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933477375, -6.2126936875 ]
  },
  "id_str" : "103788308664041472",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning ginger twat! I hope you get herpes! Screw that I hope your unborn kids all get it too!!!!! :)",
  "id" : 103788308664041472,
  "in_reply_to_status_id" : 103780107499487232,
  "created_at" : "2011-08-17 11:20:35 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933477375, -6.2126936875 ]
  },
  "id_str" : "103779442207371264",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning wanker!",
  "id" : 103779442207371264,
  "created_at" : "2011-08-17 10:45:21 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933477375, -6.2126936875 ]
  },
  "id_str" : "103764828757295104",
  "text" : "I've been stuck downstairs for the last three hours! Leg won't work! I am gonna build an en-suite. This isn't funny anymore - I'm 32 not 82!",
  "id" : 103764828757295104,
  "created_at" : "2011-08-17 09:47:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103743088664645633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933477375, -6.2126936875 ]
  },
  "id_str" : "103764400166535168",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning cunt!! I've been stuck downstairs for the last three hours! Only got to bed now.. Leg won't work! Fuck you Cunning, fuck you!",
  "id" : 103764400166535168,
  "in_reply_to_status_id" : 103743088664645633,
  "created_at" : "2011-08-17 09:45:35 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329986, -6.212610005 ]
  },
  "id_str" : "103681386946379776",
  "text" : "..... Another side effect is anal leakage, apparently! Enjoy your breakfast tweeps ;)",
  "id" : 103681386946379776,
  "created_at" : "2011-08-17 04:15:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329986, -6.212610005 ]
  },
  "id_str" : "103676698922463233",
  "text" : "A side effect of the drug I am is an interrupted sleep pattern. So Ian now watching (listening) to the utter most American shite on E4!",
  "id" : 103676698922463233,
  "created_at" : "2011-08-17 03:57:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Nolan",
      "screen_name" : "StephenNolan",
      "indices" : [ 0, 13 ],
      "id_str" : "36673147",
      "id" : 36673147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103595422832005120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933477375, -6.2126936875 ]
  },
  "id_str" : "103598841839882240",
  "in_reply_to_user_id" : 36673147,
  "text" : "@StephenNolan can I have an RT please? Am sick too with a nasty case of cellulitis. Us Stephens have to stick together :)",
  "id" : 103598841839882240,
  "in_reply_to_status_id" : 103595422832005120,
  "created_at" : "2011-08-16 22:47:43 +0000",
  "in_reply_to_screen_name" : "StephenNolan",
  "in_reply_to_user_id_str" : "36673147",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103585621674692609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329714, -6.2125729867 ]
  },
  "id_str" : "103586230545031168",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll nooooooo!!!!!!!!!",
  "id" : 103586230545031168,
  "in_reply_to_status_id" : 103585621674692609,
  "created_at" : "2011-08-16 21:57:36 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329714, -6.2125729867 ]
  },
  "id_str" : "103573496126377984",
  "text" : "Screw recreational drugs. Get a 39' temp and watch Robert Petson on tv... Man is a great writer but really doesn't translate well to tee vee",
  "id" : 103573496126377984,
  "created_at" : "2011-08-16 21:07:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103489802351030272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329714, -6.2125729867 ]
  },
  "id_str" : "103530978487709696",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Christine did slimming world and she saved them up for the weekend. Go to minimins.com - she used that for advice.",
  "id" : 103530978487709696,
  "in_reply_to_status_id" : 103489802351030272,
  "created_at" : "2011-08-16 18:18:03 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 12, 24 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103472647932874752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329714, -6.2125729867 ]
  },
  "id_str" : "103529744791904256",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @stimpled0rf I must be sick cos I ain't cross that I wont get any. Last thing I ate was on Sunday.. :)",
  "id" : 103529744791904256,
  "in_reply_to_status_id" : 103472647932874752,
  "created_at" : "2011-08-16 18:13:09 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329714, -6.2125729867 ]
  },
  "id_str" : "103427122772705280",
  "text" : "A 39' temp for the last 36hours... Trying to make appointment with doc.. Drugs run out on Friday. Feel better than yesterday though :)",
  "id" : 103427122772705280,
  "created_at" : "2011-08-16 11:25:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5934033333, -6.2126827167 ]
  },
  "id_str" : "102943986032967681",
  "text" : "Lagan valley is closed????",
  "id" : 102943986032967681,
  "created_at" : "2011-08-15 03:25:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5934033333, -6.2126827167 ]
  },
  "id_str" : "102916153478889472",
  "text" : "last time.. Will shove a pic up later - but beware it's fucking gross. This will alert both work ppl and mates and I won't wake anyone :)",
  "id" : 102916153478889472,
  "created_at" : "2011-08-15 01:34:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5934033333, -6.2126827167 ]
  },
  "id_str" : "102915622530334720",
  "text" : "Guess twitter verse. Guess who got a second round of cellulitis :) Thats right. Just gotta wait for the shivers to go then LVH. Worse than..",
  "id" : 102915622530334720,
  "created_at" : "2011-08-15 01:32:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 3, 15 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "problemsolved",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102848151542710273",
  "text" : "RT @niall_adams: From now on I'm not going to acknowledge Mondays. #problemsolved",
  "id" : 102848151542710273,
  "created_at" : "2011-08-14 21:04:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102848121524076544",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams fucking genius",
  "id" : 102848121524076544,
  "created_at" : "2011-08-14 21:04:37 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102802388175433729",
  "text" : "I am so bored.. Could do some work\/house work..... I hate this. Parents have went away on holiday so my routine is out of whack!",
  "id" : 102802388175433729,
  "created_at" : "2011-08-14 18:02:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 27, 40 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 45, 60 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102646384301309952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329714, -6.2125729867 ]
  },
  "id_str" : "102652343757180928",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin I went up with @stevebiscuit and @Georgina_Milne. My crew was so much more awesome than yours :) Enjoy it :)",
  "id" : 102652343757180928,
  "in_reply_to_status_id" : 102646384301309952,
  "created_at" : "2011-08-14 08:06:40 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102296724994924545",
  "text" : "So according to Starkey I am now black.... Good to know! What a fucking idiot.",
  "id" : 102296724994924545,
  "created_at" : "2011-08-13 08:33:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102134840459132930",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59331095, -6.2124147167 ]
  },
  "id_str" : "102136300563480576",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf errrrrrrrrrmmmmmmmm",
  "id" : 102136300563480576,
  "in_reply_to_status_id" : 102134840459132930,
  "created_at" : "2011-08-12 21:56:06 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102013424145412096",
  "geo" : { },
  "id_str" : "102016522729426944",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @niall_adams am pretty sure you are born gay... As much as i would wish every woman would turn gay in the world it wont happen",
  "id" : 102016522729426944,
  "in_reply_to_status_id" : 102013424145412096,
  "created_at" : "2011-08-12 14:00:09 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102013046607720448",
  "text" : "Nothing like fixing a bug on a Friday... then getting that cba feeling :) Must get back to it :)",
  "id" : 102013046607720448,
  "created_at" : "2011-08-12 13:46:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 1, 13 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 54, 66 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102012701148053504",
  "text" : "\u201C@niall_adams: Hanging in there.... just.  I hate you @ryancunning\u201D Everyone hates him today.. The And Monday he is persono non grata",
  "id" : 102012701148053504,
  "created_at" : "2011-08-12 13:44:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102001972667879424",
  "geo" : { },
  "id_str" : "102002498692325376",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard at least you made it back. I'll shove on the Top Gun Theme tune in a bit and it'll make you feel better!",
  "id" : 102002498692325376,
  "in_reply_to_status_id" : 102001972667879424,
  "created_at" : "2011-08-12 13:04:25 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 96, 109 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102000914612752385",
  "text" : "Scissor Sisters just came on the Sonos player.... Hmmmmmm - not sure how I feel about this. \/cc @RickyHassard shove some Top Gun on!",
  "id" : 102000914612752385,
  "created_at" : "2011-08-12 12:58:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101982149699309568",
  "geo" : { },
  "id_str" : "101982874386956288",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop Am not surprised... Congrats - told you. Believe in yourself.. Congrats again x",
  "id" : 101982874386956288,
  "in_reply_to_status_id" : 101982149699309568,
  "created_at" : "2011-08-12 11:46:26 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101979636757577730",
  "text" : "Just fixed a bug with multi selects... I can now eat my lunch guilt free :)",
  "id" : 101979636757577730,
  "created_at" : "2011-08-12 11:33:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ifonly",
      "indices" : [ 125, 132 ]
    }, {
      "text" : "ifonly",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101955617157165057",
  "geo" : { },
  "id_str" : "101956069181493248",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe Its called the Jack McCoy doctrine.. You said it.. You said \"People are free to play lesbians if they so desire :)\". #ifonly #ifonly",
  "id" : 101956069181493248,
  "in_reply_to_status_id" : 101955617157165057,
  "created_at" : "2011-08-12 09:59:55 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101955009234743296",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe said to be today \"you can play a lesbian if you show wish\".... If only.... If only....",
  "id" : 101955009234743296,
  "created_at" : "2011-08-12 09:55:43 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Craic",
      "screen_name" : "belfastcraic",
      "indices" : [ 3, 16 ],
      "id_str" : "33617792",
      "id" : 33617792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101945124199743488",
  "text" : "RT @belfastcraic: Rory McIlroy wrist injury fears:  Well that's what happens when ye get rid of yer girlfriend! :P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101794335661625344",
    "text" : "Rory McIlroy wrist injury fears:  Well that's what happens when ye get rid of yer girlfriend! :P",
    "id" : 101794335661625344,
    "created_at" : "2011-08-11 23:17:15 +0000",
    "user" : {
      "name" : "Belfast Craic",
      "screen_name" : "belfastcraic",
      "protected" : false,
      "id_str" : "33617792",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1594961023\/bc2_normal.jpg",
      "id" : 33617792,
      "verified" : false
    }
  },
  "id" : 101945124199743488,
  "created_at" : "2011-08-12 09:16:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101939198487035904",
  "text" : "Listening to epic movie soundtracks in work makes this reporting segment I am working on more exciting than it should be.",
  "id" : 101939198487035904,
  "created_at" : "2011-08-12 08:52:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 3, 12 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 14, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101934349540270081",
  "text" : "RT @alvynmcq: #ff @swmcc the Chaucer of his generation",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 4, 10 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ff",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101919614556057601",
    "text" : "#ff @swmcc the Chaucer of his generation",
    "id" : 101919614556057601,
    "created_at" : "2011-08-12 07:35:04 +0000",
    "user" : {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "protected" : false,
      "id_str" : "16155145",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2054100540\/535376_10150637481600213_561550212_9624784_1859481959_n_normal.jpg",
      "id" : 16155145,
      "verified" : false
    }
  },
  "id" : 101934349540270081,
  "created_at" : "2011-08-12 08:33:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 4, 15 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933540633, -6.21269152 ]
  },
  "id_str" : "101913807617662977",
  "text" : "#ff @Alana_Doll Baking Goddess.",
  "id" : 101913807617662977,
  "created_at" : "2011-08-12 07:11:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 19, 32 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 7, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933540633, -6.21269152 ]
  },
  "id_str" : "101913610195968000",
  "text" : "Weekly #ff. Hmmmmm @RickyHassard cos he'll be an extra grumpy mofo this mornin.",
  "id" : 101913610195968000,
  "created_at" : "2011-08-12 07:11:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101784747658846208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59330235, -6.2129626833 ]
  },
  "id_str" : "101786265699098624",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf sausage bap pilgramige soon :)",
  "id" : 101786265699098624,
  "in_reply_to_status_id" : 101784747658846208,
  "created_at" : "2011-08-11 22:45:11 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101743767861727232",
  "text" : "I love reading Robert Peston... But anytime he comes on the TV I find it so hard to keep focus on him.",
  "id" : 101743767861727232,
  "created_at" : "2011-08-11 19:56:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101732888034279424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329581, -6.2125726 ]
  },
  "id_str" : "101735008242372609",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit is it any good? Anything new?",
  "id" : 101735008242372609,
  "in_reply_to_status_id" : 101732888034279424,
  "created_at" : "2011-08-11 19:21:30 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 49, 56 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101728816027803648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329581, -6.2125726 ]
  },
  "id_str" : "101734934980464640",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues hollyoaks. You wouldn't half know that @srushe isn't in the house!",
  "id" : 101734934980464640,
  "in_reply_to_status_id" : 101728816027803648,
  "created_at" : "2011-08-11 19:21:13 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "knob",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101678982067535872",
  "geo" : { },
  "id_str" : "101679326067572736",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq am pretty sure that a curry has nothing to do with my sexual orientation - but who knows ;) #knob",
  "id" : 101679326067572736,
  "in_reply_to_status_id" : 101678982067535872,
  "created_at" : "2011-08-11 15:40:15 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101670104638570498",
  "text" : "slow cooking a curry tonight.. this makes me insanely happy... dunno why :)",
  "id" : 101670104638570498,
  "created_at" : "2011-08-11 15:03:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101640597558923264",
  "geo" : { },
  "id_str" : "101641344635772930",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop show me some nipple!!!!!",
  "id" : 101641344635772930,
  "in_reply_to_status_id" : 101640597558923264,
  "created_at" : "2011-08-11 13:09:19 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101609883291488256",
  "text" : "Disney- The Bare necessities",
  "id" : 101609883291488256,
  "created_at" : "2011-08-11 11:04:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101608394196140032",
  "text" : "Journey - Don't Stop Believing. Which reminds me of the last scene of the Sopranos and not Glee - unlike most of you homos!",
  "id" : 101608394196140032,
  "created_at" : "2011-08-11 10:58:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101607643025649664",
  "text" : "Jackson 5 - ABC :)",
  "id" : 101607643025649664,
  "created_at" : "2011-08-11 10:55:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101606450152996864",
  "text" : "Starting a rather crappy part of this project so need some kewl tunes to keep me sane... \"Hewy Lewis & The News\" The Power of Love - CHEESE",
  "id" : 101606450152996864,
  "created_at" : "2011-08-11 10:50:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/imR28JQ",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-14458424",
      "display_url" : "bbc.co.uk\/news\/uk-144584\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "101591530921402368",
  "text" : "http:\/\/t.co\/imR28JQ - STUPID STUPID STUPID STUPID STUPID STUPID STUPID",
  "id" : 101591530921402368,
  "created_at" : "2011-08-11 09:51:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101325203933634560",
  "text" : "What I have to do after a debug race... vim `fgrep -ri 'var_dump' *` :D Think i'd learn by now :)",
  "id" : 101325203933634560,
  "created_at" : "2011-08-10 16:13:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101315811511238657",
  "text" : "This bit of code wont work... WHY WONT IT WORK?!?!?!?!?!?!?!?!?",
  "id" : 101315811511238657,
  "created_at" : "2011-08-10 15:35:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101304188985819137",
  "text" : "Top top bottom bottom middle middle middle.\n\nTop top bottom bottom middle middle middle.\n\nTop top bottom bottom middle middle middle.",
  "id" : 101304188985819137,
  "created_at" : "2011-08-10 14:49:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101302995689549825",
  "geo" : { },
  "id_str" : "101303541460770819",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard don't huff.. You have screwed me over plenty of times :) But that fucking song is in my head now so I guess you win!",
  "id" : 101303541460770819,
  "in_reply_to_status_id" : 101302995689549825,
  "created_at" : "2011-08-10 14:47:01 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 18, 31 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 39, 47 ],
      "id_str" : "79820731",
      "id" : 79820731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101301925525463041",
  "text" : "Just screwed over @RickyHassard in the @tascomi office... Totally worth it.. Top Top Top Top Down Down Middle Middle",
  "id" : 101301925525463041,
  "created_at" : "2011-08-10 14:40:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mar\u00EDa Basia ",
      "screen_name" : "maria_basia",
      "indices" : [ 0, 12 ],
      "id_str" : "235508724",
      "id" : 235508724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101290739899707392",
  "geo" : { },
  "id_str" : "101292392472252416",
  "in_reply_to_user_id" : 235508724,
  "text" : "@maria_basia am with you until that last statement :)",
  "id" : 101292392472252416,
  "in_reply_to_status_id" : 101290739899707392,
  "created_at" : "2011-08-10 14:02:42 +0000",
  "in_reply_to_screen_name" : "maria_basia",
  "in_reply_to_user_id_str" : "235508724",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101281032631894016",
  "geo" : { },
  "id_str" : "101284581730299904",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery Samsung 46\" LCD.. Not sure of the actual model - will look when I get home.",
  "id" : 101284581730299904,
  "in_reply_to_status_id" : 101281032631894016,
  "created_at" : "2011-08-10 13:31:40 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101280946262786048",
  "geo" : { },
  "id_str" : "101284498007789569",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe last time the problem was a no character change :) So that will be fun :)",
  "id" : 101284498007789569,
  "in_reply_to_status_id" : 101280946262786048,
  "created_at" : "2011-08-10 13:31:20 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101278651189956609",
  "text" : "Yeah - also on Friday night I let it be known to an old manager that the week I took off on the sick was to finish KOTOR! He wasn't happy :)",
  "id" : 101278651189956609,
  "created_at" : "2011-08-10 13:08:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101274775153950720",
  "geo" : { },
  "id_str" : "101276401377878017",
  "in_reply_to_user_id" : 761761,
  "text" : "@manyhues @srushe just told me that it was your idea for the HDMI cable.. I think you should punish him!",
  "id" : 101276401377878017,
  "in_reply_to_status_id" : 101274775153950720,
  "created_at" : "2011-08-10 12:59:10 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101273333752016897",
  "geo" : { },
  "id_str" : "101273457177792512",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin then I have fuck all sympathy for ya!",
  "id" : 101273457177792512,
  "in_reply_to_status_id" : 101273333752016897,
  "created_at" : "2011-08-10 12:47:28 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101273195574853633",
  "geo" : { },
  "id_str" : "101273275564433408",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin don't use windows :D",
  "id" : 101273275564433408,
  "in_reply_to_status_id" : 101273195574853633,
  "created_at" : "2011-08-10 12:46:45 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101272468509032448",
  "text" : "Heading to a friends tonight instead of being able to tinker with the awesome TV... Grrrrrrrrrrrr.",
  "id" : 101272468509032448,
  "created_at" : "2011-08-10 12:43:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101271463222444032",
  "geo" : { },
  "id_str" : "101272137045782529",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe technically he is right though. His solution works just as well as mine. But it isn't cool! He is such a programmer!",
  "id" : 101272137045782529,
  "in_reply_to_status_id" : 101271463222444032,
  "created_at" : "2011-08-10 12:42:13 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 78, 85 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101237904348688384",
  "text" : "\"I just hook my laptop up to the tv with a hdmi cable and work away that way\" @srushe does not understand the awesomeness of my TV setup!",
  "id" : 101237904348688384,
  "created_at" : "2011-08-10 10:26:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101225371344707584",
  "text" : "Coming in late due to an epic sleep in :( Two alarms didn't wake me - thought it was Thursday. Fail of a day  :( Must get into work stride!",
  "id" : 101225371344707584,
  "created_at" : "2011-08-10 09:36:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101073186992558080",
  "geo" : { },
  "id_str" : "101225146483879936",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg thats it - dlna. Haven't read much about it - just seen the option last night and started to tinker. Wont play mkv files though.",
  "id" : 101225146483879936,
  "in_reply_to_status_id" : 101073186992558080,
  "created_at" : "2011-08-10 09:35:30 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101187567420047360",
  "geo" : { },
  "id_str" : "101223824472817664",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @lisami75 Yo G :D Would love to but i have a christening to go that Sunday. Next time though - loved it :)",
  "id" : 101223824472817664,
  "in_reply_to_status_id" : 101187567420047360,
  "created_at" : "2011-08-10 09:30:15 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329581, -6.2125726 ]
  },
  "id_str" : "101044779311312896",
  "text" : "Looks like I will have to convert stuff to avi.. Will read more tomorrow. Night tweeps :)",
  "id" : 101044779311312896,
  "created_at" : "2011-08-09 21:38:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100965280385220608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933165133, -6.2126152867 ]
  },
  "id_str" : "101039789486247936",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings far from it. But am now confident enough on front end type stuff. Still not comparable to my back end shiz though :)",
  "id" : 101039789486247936,
  "in_reply_to_status_id" : 100965280385220608,
  "created_at" : "2011-08-09 21:18:57 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101039025061773312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933093375, -6.21253083 ]
  },
  "id_str" : "101039401181777920",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf not at all. But this way works for now. Plex and a nas. However this way gets me up quicker and cheaper :)",
  "id" : 101039401181777920,
  "in_reply_to_status_id" : 101039025061773312,
  "created_at" : "2011-08-09 21:17:25 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933093375, -6.21253083 ]
  },
  "id_str" : "101038039706517504",
  "text" : "Got media player to play mkv files... Now to get them added to the video library. Windows sure us an abortion of an OS!",
  "id" : 101038039706517504,
  "created_at" : "2011-08-09 21:12:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933093375, -6.21253083 ]
  },
  "id_str" : "101023880713486336",
  "text" : "Seems my tv can see network shares :) Awesome... Now to get this working :)",
  "id" : 101023880713486336,
  "created_at" : "2011-08-09 20:15:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 52, 64 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 66, 72 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100953345396719617",
  "text" : "Think that's Derry for we are leaving in 20mins :) \u201C@stimpled0rf: @swmcc don't forget you're now my bitch.. lay by buddy..\u201D",
  "id" : 100953345396719617,
  "created_at" : "2011-08-09 15:35:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100951839457017856",
  "text" : "jQuery is now my bitch (I think) :)",
  "id" : 100951839457017856,
  "created_at" : "2011-08-09 15:29:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100896817314660352",
  "text" : "Watching Seinfeld on my lunch break :)",
  "id" : 100896817314660352,
  "created_at" : "2011-08-09 11:50:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100879589961760768",
  "geo" : { },
  "id_str" : "100881754923089920",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus take a satchel everywhere you go.. *punch*",
  "id" : 100881754923089920,
  "in_reply_to_status_id" : 100879589961760768,
  "created_at" : "2011-08-09 10:50:59 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100877912944816129",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgstatus wearing 1980's clothing and speak with an American accent even though you are from the UK.. *punch*",
  "id" : 100877912944816129,
  "created_at" : "2011-08-09 10:35:43 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100841597087907840",
  "text" : "And coming in early when the cleaners are here is a bit of a false economy as well.",
  "id" : 100841597087907840,
  "created_at" : "2011-08-09 08:11:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 59, 71 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100837408626585600",
  "text" : "Came in early to get some work done and had a meeting with @stimpled0rf all before 9am.. Good meeting though :)",
  "id" : 100837408626585600,
  "created_at" : "2011-08-09 07:54:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933093375, -6.21253083 ]
  },
  "id_str" : "100687629175095296",
  "text" : "Sky+ failed to record Entourage for me. This is all kinds of ass..... None if which are good! Fuck you Sky+ - *click* - *download*. l",
  "id" : 100687629175095296,
  "created_at" : "2011-08-08 21:59:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100669400696369152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933079867, -6.2126034833 ]
  },
  "id_str" : "100670078701416449",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf don't read!!! Watch. Entourage. Watch. It. Do. Not. Read. Knob :)",
  "id" : 100670078701416449,
  "in_reply_to_status_id" : 100669400696369152,
  "created_at" : "2011-08-08 20:49:51 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100668267781304321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933093375, -6.21253083 ]
  },
  "id_str" : "100668505355075584",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf entourage! Watch Entourage :) Not long now to Friday bap of sausages pilgrimage!",
  "id" : 100668505355075584,
  "in_reply_to_status_id" : 100668267781304321,
  "created_at" : "2011-08-08 20:43:36 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100667788737257472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329847, -6.2124888433 ]
  },
  "id_str" : "100668046997323776",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf oh I get that. But ppl think that him coming back will make a difference. Poor ppl losing their homes and livelihoods.",
  "id" : 100668046997323776,
  "in_reply_to_status_id" : 100667788737257472,
  "created_at" : "2011-08-08 20:41:47 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593308935, -6.2125269575 ]
  },
  "id_str" : "100659259389382656",
  "text" : "Forgot that Entourage is on tonight. Hope I can stay awake long enough to see it!",
  "id" : 100659259389382656,
  "created_at" : "2011-08-08 20:06:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100603003320549376",
  "geo" : { },
  "id_str" : "100603622685024257",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf you shoving the indicators on soon?",
  "id" : 100603622685024257,
  "in_reply_to_status_id" : 100603003320549376,
  "created_at" : "2011-08-08 16:25:47 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100602860722601984",
  "text" : "Its like not over taking a police car on the motorway... Yup - this is exactly what its like :)",
  "id" : 100602860722601984,
  "created_at" : "2011-08-08 16:22:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100582220208685056",
  "text" : "Am so tired my eyes are starting to sting a little!",
  "id" : 100582220208685056,
  "created_at" : "2011-08-08 15:00:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 19, 31 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100582039513858048",
  "text" : "I need to cheer up @stimpled0rf he hasn't been himself today!!!!",
  "id" : 100582039513858048,
  "created_at" : "2011-08-08 15:00:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmccespressocount",
      "indices" : [ 46, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100560692964368384",
  "text" : "Well only on the second come of espresso :) 2 #swmccespressocount",
  "id" : 100560692964368384,
  "created_at" : "2011-08-08 13:35:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100514418642788352",
  "text" : "Just got emailed the best bit of work advice I've gotten in ages - it involved the words \"flibble flobble flibble flooooo\". Awesome :)",
  "id" : 100514418642788352,
  "created_at" : "2011-08-08 10:31:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 19, 31 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100500004866756608",
  "text" : "Think I just broke @stimpled0rf :(",
  "id" : 100500004866756608,
  "created_at" : "2011-08-08 09:34:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmccespressocount",
      "indices" : [ 92, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100494081691615233",
  "text" : "Got no sleep last night so gonna go for my first espresso of the day.. Lets keep count :) 1 #swmccespressocount",
  "id" : 100494081691615233,
  "created_at" : "2011-08-08 09:10:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100303951903195136",
  "geo" : { },
  "id_str" : "100305773355216898",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne You are a machine :) Very impressive",
  "id" : 100305773355216898,
  "in_reply_to_status_id" : 100303951903195136,
  "created_at" : "2011-08-07 20:42:14 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 1, 12 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacakeporn",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 41 ],
      "url" : "http:\/\/t.co\/48lui3G",
      "expanded_url" : "http:\/\/yfrog.com\/kelqirkj",
      "display_url" : "yfrog.com\/kelqirkj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593304344, -6.212496002 ]
  },
  "id_str" : "100140058270633984",
  "text" : "\u201C@Alana_Doll: Eeeeep! http:\/\/t.co\/48lui3G\u201D #teacakeporn",
  "id" : 100140058270633984,
  "created_at" : "2011-08-07 09:43:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59645551, -6.20866125 ]
  },
  "id_str" : "99954129354502145",
  "text" : "Harry Potter film on a Saturday night.. Tomorrow curtain shopping :)",
  "id" : 99954129354502145,
  "created_at" : "2011-08-06 21:24:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/t2eH7Xg",
      "expanded_url" : "http:\/\/yfrog.com\/h4kluacj",
      "display_url" : "yfrog.com\/h4kluacj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5935535333, -6.2127041667 ]
  },
  "id_str" : "99916145766842368",
  "text" : "Spent a good portion of this evening with this cool cat!!! Pippa she's awesome.. Could look at her all day :)  http:\/\/t.co\/t2eH7Xg",
  "id" : 99916145766842368,
  "created_at" : "2011-08-06 18:54:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593329455, -6.21263104 ]
  },
  "id_str" : "99788397161357313",
  "text" : "Smurfs: The Movie in 3D!!! Seriously Hollywood leave my child hood alone and cone up with *original* ideas!!! Fuck sake!!!!",
  "id" : 99788397161357313,
  "created_at" : "2011-08-06 10:26:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 25, 38 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 3, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99431408124178432",
  "text" : "My #ff this week goes to @RickyHassard for he sent me a text that wrote \"Ah the state of acceptance. The closest thing to pure happiness :D\"",
  "id" : 99431408124178432,
  "created_at" : "2011-08-05 10:47:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99384258531041280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5932976733, -6.2124789533 ]
  },
  "id_str" : "99386448284893185",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf not too bad. I thought sheldon was good in it. Could do without the penny and lanky drama though.",
  "id" : 99386448284893185,
  "in_reply_to_status_id" : 99384258531041280,
  "created_at" : "2011-08-05 07:49:10 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 62, 77 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 78, 91 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99382803862536192",
  "text" : "update on happiness Stuck at the side of a road cos car broke @Georgina_Milne @stevebiscuit guess the shaking car on Sunday was a clue.",
  "id" : 99382803862536192,
  "created_at" : "2011-08-05 07:34:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 23, 35 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99374758449262593",
  "text" : "Woke up by a text from @stimpled0rf at stupid o'clock.. Bit of work done before I head in. Funnily enough cos of yesterday i am happy!",
  "id" : 99374758449262593,
  "created_at" : "2011-08-05 07:02:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.578812475, -5.96227121 ]
  },
  "id_str" : "99166953880567809",
  "text" : "Good day in work, finally. Another day like that an a few hours at the weekend and I'll be laughing on Monday :)",
  "id" : 99166953880567809,
  "created_at" : "2011-08-04 17:16:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99139604850032640",
  "geo" : { },
  "id_str" : "99151292416524288",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf not that... you just scud Fridays....",
  "id" : 99151292416524288,
  "in_reply_to_status_id" : 99139604850032640,
  "created_at" : "2011-08-04 16:14:44 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99128153137627136",
  "geo" : { },
  "id_str" : "99128304702980096",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf yes. yes you can.",
  "id" : 99128304702980096,
  "in_reply_to_status_id" : 99128153137627136,
  "created_at" : "2011-08-04 14:43:24 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99125652661354496",
  "geo" : { },
  "id_str" : "99125876964335616",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf then no more talk of Friday until Friday.. And even then tread very very carefully :)",
  "id" : 99125876964335616,
  "in_reply_to_status_id" : 99125652661354496,
  "created_at" : "2011-08-04 14:33:45 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 7, 21 ],
      "id_str" : "49953918",
      "id" : 49953918
    }, {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 33, 45 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99121721709305856",
  "geo" : { },
  "id_str" : "99121905528864768",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @rickthejackal @bkgstatus @rickydunlop Maybe that's cos i am not licking InvestNI's balls though.. Just saying :D",
  "id" : 99121905528864768,
  "in_reply_to_status_id" : 99121721709305856,
  "created_at" : "2011-08-04 14:17:58 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 0, 14 ],
      "id_str" : "49953918",
      "id" : 49953918
    }, {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 26, 38 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99121432860164097",
  "geo" : { },
  "id_str" : "99121721709305856",
  "in_reply_to_user_id" : 49953918,
  "text" : "@RickTheJackal @bkgstatus @rickydunlop ack he doesn't even know who I am... I don't register on his radar..",
  "id" : 99121721709305856,
  "in_reply_to_status_id" : 99121432860164097,
  "created_at" : "2011-08-04 14:17:14 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 0, 14 ],
      "id_str" : "49953918",
      "id" : 49953918
    }, {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 26, 38 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99119021508673536",
  "geo" : { },
  "id_str" : "99120973122502656",
  "in_reply_to_user_id" : 49953918,
  "text" : "@RickTheJackal @bkgstatus @rickydunlop ffs... Vim isn't old skool. Its just a different wa. You gonna change your name to Lee Munroe next!",
  "id" : 99120973122502656,
  "in_reply_to_status_id" : 99119021508673536,
  "created_at" : "2011-08-04 14:14:16 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99116565001277440",
  "geo" : { },
  "id_str" : "99116788515749888",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop I have a 28\" display now - kinda daft cos I use vim so much - but using Texmate more and more.",
  "id" : 99116788515749888,
  "in_reply_to_status_id" : 99116565001277440,
  "created_at" : "2011-08-04 13:57:38 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99115801910591488",
  "geo" : { },
  "id_str" : "99116125538893824",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop i have started to use vim as well - I have to say its really nice.",
  "id" : 99116125538893824,
  "in_reply_to_status_id" : 99115801910591488,
  "created_at" : "2011-08-04 13:55:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    }, {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 13, 27 ],
      "id_str" : "49953918",
      "id" : 49953918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99115394060656641",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop @rickthejackal or textmate if you are a hippie.. coda if you are a complete fucking twt and eclipse if you are a cunt.",
  "id" : 99115394060656641,
  "created_at" : "2011-08-04 13:52:06 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    }, {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 13, 27 ],
      "id_str" : "49953918",
      "id" : 49953918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99115095765954560",
  "geo" : { },
  "id_str" : "99115259004076032",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop @rickthejackal that would be vim if you are a real man ;)",
  "id" : 99115259004076032,
  "in_reply_to_status_id" : 99115095765954560,
  "created_at" : "2011-08-04 13:51:33 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99111290013880321",
  "geo" : { },
  "id_str" : "99114404179742720",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe @bkgstatus if you are happy to spend close to a quid on a sausage roll you must be fucking it. Simple! :)",
  "id" : 99114404179742720,
  "in_reply_to_status_id" : 99111290013880321,
  "created_at" : "2011-08-04 13:48:10 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99103184198438913",
  "geo" : { },
  "id_str" : "99109710749368320",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe you know I just eat the sausage rolls I buy - I don't fuck them? The guts of a quid is too dear!!!!!",
  "id" : 99109710749368320,
  "in_reply_to_status_id" : 99103184198438913,
  "created_at" : "2011-08-04 13:29:31 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 24, 37 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99094799847657472",
  "text" : "He sucks and I rock \/cc @RickyHassard",
  "id" : 99094799847657472,
  "created_at" : "2011-08-04 12:30:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99085094492454912",
  "text" : "76p for a sausage roll in Hillsborough... WTF",
  "id" : 99085094492454912,
  "created_at" : "2011-08-04 11:51:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99016784996335616",
  "geo" : { },
  "id_str" : "99049829300310016",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb more than welcome. But I'd wait until house is finished need to get the floor down and curtains. And we will need the curtains ;)",
  "id" : 99049829300310016,
  "in_reply_to_status_id" : 99016784996335616,
  "created_at" : "2011-08-04 09:31:34 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99016784996335616",
  "geo" : { },
  "id_str" : "99034605176369152",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Don't have sky sports :) Not really interested in the 3d aspect. Was more the size, clarity and pure awesomeness of the tv :)",
  "id" : 99034605176369152,
  "in_reply_to_status_id" : 99016784996335616,
  "created_at" : "2011-08-04 08:31:04 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99015705772568576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.60007101, -6.20976805 ]
  },
  "id_str" : "99016294547984384",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb yeah just fit those two it's worth it. Yup 3d ready samsung LCD 48 inch or 46. Can't mind. Good buy I think.",
  "id" : 99016294547984384,
  "in_reply_to_status_id" : 99015705772568576,
  "created_at" : "2011-08-04 07:18:18 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99014575030157312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59326954, -6.2125026167 ]
  },
  "id_str" : "99015203840208896",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb good enough. Lovefilm and iplayer are worth it. Rest of the apps are a bit gimmicky. need to get plex on it for my ripped stuff",
  "id" : 99015203840208896,
  "in_reply_to_status_id" : 99014575030157312,
  "created_at" : "2011-08-04 07:13:58 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99014575030157312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59326954, -6.2125026167 ]
  },
  "id_str" : "99015179022499840",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb but I am more than happy. Annoying thing is the cost of a wireless adapter. 40quid which is annoying considering the initial cost.",
  "id" : 99015179022499840,
  "in_reply_to_status_id" : 99014575030157312,
  "created_at" : "2011-08-04 07:13:52 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98865596518768640",
  "text" : "Done a bit of work tonight.. Mostly spent it getting my tv up to speed though :) Dunno about plex on the tv..",
  "id" : 98865596518768640,
  "created_at" : "2011-08-03 21:19:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Herron",
      "screen_name" : "paul_herron",
      "indices" : [ 0, 12 ],
      "id_str" : "41416719",
      "id" : 41416719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98856912111677440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5932593467, -6.21231802 ]
  },
  "id_str" : "98858928523325440",
  "in_reply_to_user_id" : 41416719,
  "text" : "@paul_herron that dick was you btw.. Good times.. Good times.",
  "id" : 98858928523325440,
  "in_reply_to_status_id" : 98856912111677440,
  "created_at" : "2011-08-03 20:52:59 +0000",
  "in_reply_to_screen_name" : "paul_herron",
  "in_reply_to_user_id_str" : "41416719",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Herron",
      "screen_name" : "paul_herron",
      "indices" : [ 0, 12 ],
      "id_str" : "41416719",
      "id" : 41416719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98856912111677440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5932593467, -6.21231802 ]
  },
  "id_str" : "98857678406828032",
  "in_reply_to_user_id" : 41416719,
  "text" : "@paul_herron I am comfortable with it. I remember a certain dick I used to work with.. Did nothing but skin gorillas at night...",
  "id" : 98857678406828032,
  "in_reply_to_status_id" : 98856912111677440,
  "created_at" : "2011-08-03 20:48:01 +0000",
  "in_reply_to_screen_name" : "paul_herron",
  "in_reply_to_user_id_str" : "41416719",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Herron",
      "screen_name" : "paul_herron",
      "indices" : [ 0, 12 ],
      "id_str" : "41416719",
      "id" : 41416719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98854531881910272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59326071, -6.212235078 ]
  },
  "id_str" : "98856623241572352",
  "in_reply_to_user_id" : 41416719,
  "text" : "@paul_herron decided to make this house a supreme boys toys place. Not being in a relationship anymore has it's advantages :)",
  "id" : 98856623241572352,
  "in_reply_to_status_id" : 98854531881910272,
  "created_at" : "2011-08-03 20:43:50 +0000",
  "in_reply_to_screen_name" : "paul_herron",
  "in_reply_to_user_id_str" : "41416719",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59326071, -6.212235078 ]
  },
  "id_str" : "98856339459162112",
  "text" : "Am also doing my front living room up. Getting curtains and floor soon.. Just in case you lot think I am a gypsy..",
  "id" : 98856339459162112,
  "created_at" : "2011-08-03 20:42:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/ITHPgZ8",
      "expanded_url" : "http:\/\/yfrog.com\/h3y3niij",
      "display_url" : "yfrog.com\/h3y3niij"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5932976733, -6.2124789533 ]
  },
  "id_str" : "98855821944954880",
  "text" : "Watching Star Wars: The Old Republic trailer via YouTube on a 48 inch. Geek porn...  http:\/\/t.co\/ITHPgZ8",
  "id" : 98855821944954880,
  "created_at" : "2011-08-03 20:40:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/samsung.com\/apps\" rel=\"nofollow\"\u003ESamsung Smart TV\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98854327891918848",
  "text" : "my first tweet from my tv",
  "id" : 98854327891918848,
  "created_at" : "2011-08-03 20:34:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98845141309206529",
  "geo" : { },
  "id_str" : "98850984956145664",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I got a new net connection in your abscence.. I now average about 34Mbit :) Ha! - Will download that shiz for you in a bit :)",
  "id" : 98850984956145664,
  "in_reply_to_status_id" : 98845141309206529,
  "created_at" : "2011-08-03 20:21:26 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98845666847109120",
  "geo" : { },
  "id_str" : "98849818071404545",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf just need to figure out plex - then its all good :)",
  "id" : 98849818071404545,
  "in_reply_to_status_id" : 98845666847109120,
  "created_at" : "2011-08-03 20:16:47 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593280785, -6.212353435 ]
  },
  "id_str" : "98832254750572545",
  "text" : "My tv can stream lovefilm, YouTube, iplayer, twitter. Gonna get plex going if I can...",
  "id" : 98832254750572545,
  "created_at" : "2011-08-03 19:07:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98779883165057025",
  "text" : "OH: \"Fuck you Stevie.. Fuck you!\" - I love my work colleagues :)",
  "id" : 98779883165057025,
  "created_at" : "2011-08-03 15:38:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 74, 84 ],
      "id_str" : "212603717",
      "id" : 212603717
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 86, 93 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quake",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98745501997989888",
  "text" : "FUCKER CHEATED! Plus it was almost 10 years ago - get over it! :) #quake \u201C@carisenda: @srushe beowulf 20 - 0 swm\u201D",
  "id" : 98745501997989888,
  "created_at" : "2011-08-03 13:22:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98744015360499713",
  "geo" : { },
  "id_str" : "98745323568103425",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll but you will get there :) You is ha-maze-ing at baking type stuffs :D",
  "id" : 98745323568103425,
  "in_reply_to_status_id" : 98744015360499713,
  "created_at" : "2011-08-03 13:21:34 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98736699173117952",
  "text" : "No One thing you never wanting to pop up in your Adium feed: \"Gonna have to call it off at this stage and get back in my coding underpants\"",
  "id" : 98736699173117952,
  "created_at" : "2011-08-03 12:47:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98732351495995392",
  "text" : "Hmmmm according to the interweb - I can get plex running on my TV... Not sure about that - but will give it a go tonight :)",
  "id" : 98732351495995392,
  "created_at" : "2011-08-03 12:30:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Tinpot :-)",
      "screen_name" : "Tinpot",
      "indices" : [ 10, 17 ],
      "id_str" : "17894449",
      "id" : 17894449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98722354359844864",
  "geo" : { },
  "id_str" : "98725235607613440",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @Tinpot here here! Really annoys me that!",
  "id" : 98725235607613440,
  "in_reply_to_status_id" : 98722354359844864,
  "created_at" : "2011-08-03 12:01:45 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98491662501806080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593296075, -6.21263033 ]
  },
  "id_str" : "98501686456365056",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne that'd have been a cool way to go all the same :)",
  "id" : 98501686456365056,
  "in_reply_to_status_id" : 98491662501806080,
  "created_at" : "2011-08-02 21:13:26 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http:\/\/t.co\/oVbPdIc",
      "expanded_url" : "http:\/\/yfrog.com\/klaydtxj",
      "display_url" : "yfrog.com\/klaydtxj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593296075, -6.21263033 ]
  },
  "id_str" : "98501591149195264",
  "text" : "Fucking awesome :)  http:\/\/t.co\/oVbPdIc",
  "id" : 98501591149195264,
  "created_at" : "2011-08-02 21:13:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98492976732446720",
  "geo" : { },
  "id_str" : "98498778440540160",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf  sorted :) And you'll have it tomorrow mainly cos your lovely gf made me the bestest bun ever! Your not bad yourself like :)",
  "id" : 98498778440540160,
  "in_reply_to_status_id" : 98492976732446720,
  "created_at" : "2011-08-02 21:01:53 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98491362856534016",
  "geo" : { },
  "id_str" : "98491920791257089",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke amateur. I got a free one tonight :)",
  "id" : 98491920791257089,
  "in_reply_to_status_id" : 98491362856534016,
  "created_at" : "2011-08-02 20:34:38 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98481714736807936",
  "geo" : { },
  "id_str" : "98491727802937344",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf all sorted - really fqn fast. Just getting my plex media windows server set up to stream to the tv.",
  "id" : 98491727802937344,
  "in_reply_to_status_id" : 98481714736807936,
  "created_at" : "2011-08-02 20:33:52 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98481002237792256",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf ok reg'd with ngroups.net - but it wont do anyting with the stuff I get from newzbin :(",
  "id" : 98481002237792256,
  "created_at" : "2011-08-02 19:51:15 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98475985099440128",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf if so - what is a good one to get?",
  "id" : 98475985099440128,
  "created_at" : "2011-08-02 19:31:19 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98475158272090112",
  "text" : "I count myself as fairly up to speed on technical gizmos - specially those assoicated with the interweb  but this newsnet stuff has be beat!",
  "id" : 98475158272090112,
  "created_at" : "2011-08-02 19:28:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98474198879580160",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf so I have to enter in server info??? Man this is hurting my bald head!",
  "id" : 98474198879580160,
  "created_at" : "2011-08-02 19:24:13 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98473002722791424",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf I've downloaded  it - this is hurting my head :) I just want to click and go and then watch :)",
  "id" : 98473002722791424,
  "created_at" : "2011-08-02 19:19:28 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98472630675451904",
  "text" : "I am using Unzbin - but I might be doing somethign wrong?",
  "id" : 98472630675451904,
  "created_at" : "2011-08-02 19:17:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98470760238153728",
  "geo" : { },
  "id_str" : "98471176774488065",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne I thought we were just misplaced. That you and David knew roughly where we were :) Awesome :)",
  "id" : 98471176774488065,
  "in_reply_to_status_id" : 98470760238153728,
  "created_at" : "2011-08-02 19:12:12 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98469047343136768",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne  Thanks you three were very patient with me which I appreciated . Looking forward to the next time :) And we weren't lost :)",
  "id" : 98469047343136768,
  "created_at" : "2011-08-02 19:03:45 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98468838072532992",
  "text" : "And FYI - this isn't for downloading stuff - that would be illegal, immoral and wrong :)",
  "id" : 98468838072532992,
  "created_at" : "2011-08-02 19:02:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98468717058461697",
  "text" : "I need a good nfo client for newsbin - that's over https - any ideas?",
  "id" : 98468717058461697,
  "created_at" : "2011-08-02 19:02:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98426020847304704",
  "text" : "Should I lift the stair carpet or cut the grass tonight??????? Fuck my life is rock n roll I tells ya!",
  "id" : 98426020847304704,
  "created_at" : "2011-08-02 16:12:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97760413734809600",
  "geo" : { },
  "id_str" : "98389893683748865",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit @lisami75 Oh I think I will leave it another 3\/4 weeks before bombing up again :) Gonna get fitter & fitter :)",
  "id" : 98389893683748865,
  "in_reply_to_status_id" : 97760413734809600,
  "created_at" : "2011-08-02 13:49:13 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bestbakerever",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98388390193541120",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll that tea was so good... Thank you so much :) Open a shop and I'll be your bestest customer :) #bestbakerever",
  "id" : 98388390193541120,
  "created_at" : "2011-08-02 13:43:14 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 72, 79 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/PxJ0CyB",
      "expanded_url" : "https:\/\/github.com\/caius\/php-faker",
      "display_url" : "github.com\/caius\/php-faker"
    } ]
  },
  "in_reply_to_status_id_str" : "98341097830481922",
  "geo" : { },
  "id_str" : "98342499193593856",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop found this- might do what i want.. http:\/\/t.co\/PxJ0CyB \/cc @srushe",
  "id" : 98342499193593856,
  "in_reply_to_status_id" : 98341097830481922,
  "created_at" : "2011-08-02 10:40:53 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98341097830481922",
  "geo" : { },
  "id_str" : "98342001237438464",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop Well that is good for testing the actual app on the site. But more for random stuff to be guffed in during Unit Testing.",
  "id" : 98342001237438464,
  "in_reply_to_status_id" : 98341097830481922,
  "created_at" : "2011-08-02 10:38:54 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "painful",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98340701045133313",
  "text" : "In my sleep I am typing Stephen McCullough xx Xxx Xxxxxx Glenavy, Crumlin, BTXX XXX 02894xxxxxx 07749xxxxxx... #painful",
  "id" : 98340701045133313,
  "created_at" : "2011-08-02 10:33:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98340359855280129",
  "text" : "Is there a nice Faker object class for PHP that I can use? For if I enter my own details 1 more fucking time I will actually go nuts!",
  "id" : 98340359855280129,
  "created_at" : "2011-08-02 10:32:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 59, 71 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 101, 112 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98318009034223616",
  "geo" : { },
  "id_str" : "98318529736093696",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll you are awesome :D Thank you very very much =] @stimpled0rf you are pretty cool too! But @Alana_Doll is awesome :)",
  "id" : 98318529736093696,
  "in_reply_to_status_id" : 98318009034223616,
  "created_at" : "2011-08-02 09:05:38 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 6, 18 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 30, 39 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wankers",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98314209544245248",
  "text" : "Seems @niall_adams has done a @kirkcoyb on me and got engaged when he was away on holidays! Always the bridesmaid never the bride! #wankers",
  "id" : 98314209544245248,
  "created_at" : "2011-08-02 08:48:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the black telescope",
      "screen_name" : "blacktelescope",
      "indices" : [ 0, 15 ],
      "id_str" : "14932763",
      "id" : 14932763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98311379936743424",
  "geo" : { },
  "id_str" : "98312354072248320",
  "in_reply_to_user_id" : 14932763,
  "text" : "@blacktelescope did you just get hacked? :)",
  "id" : 98312354072248320,
  "in_reply_to_status_id" : 98311379936743424,
  "created_at" : "2011-08-02 08:41:06 +0000",
  "in_reply_to_screen_name" : "blacktelescope",
  "in_reply_to_user_id_str" : "14932763",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 22, 33 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 54 ],
      "url" : "http:\/\/t.co\/Q5cJS5I",
      "expanded_url" : "http:\/\/yfrog.com\/gz435scj",
      "display_url" : "yfrog.com\/gz435scj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.4628270717, -6.0829304017 ]
  },
  "id_str" : "98295196739055616",
  "text" : "My precious :) Cheers @Alana_Doll  http:\/\/t.co\/Q5cJS5I",
  "id" : 98295196739055616,
  "created_at" : "2011-08-02 07:32:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593280785, -6.212353435 ]
  },
  "id_str" : "98123709289742337",
  "text" : "Just woke up after being in a coma for most if the day!! some fucker has let of an explosion in my head!!!",
  "id" : 98123709289742337,
  "created_at" : "2011-08-01 20:11:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]