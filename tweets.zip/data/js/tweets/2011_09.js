Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933524517, -6.2125541033 ]
  },
  "id_str" : "119902767597895680",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I meant \"knew\".",
  "id" : 119902767597895680,
  "created_at" : "2011-09-30 22:33:42 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119898327373455360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593367882, -6.212691862 ]
  },
  "id_str" : "119898547477954560",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall new there would be some perving involved :)",
  "id" : 119898547477954560,
  "in_reply_to_status_id" : 119898327373455360,
  "created_at" : "2011-09-30 22:16:55 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119883339044880384",
  "geo" : { },
  "id_str" : "119886939829714944",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall its the tv series from the 70's. Only one eppy in - looks good :) Gonna watch the film after.",
  "id" : 119886939829714944,
  "in_reply_to_status_id" : 119883339044880384,
  "created_at" : "2011-09-30 21:30:48 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 63, 71 ],
      "id_str" : "7885972",
      "id" : 7885972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TinkerTailorSoldierSpy",
      "indices" : [ 72, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/SQ4cTeBp",
      "expanded_url" : "http:\/\/bit.ly\/oNnCvq",
      "display_url" : "bit.ly\/oNnCvq"
    } ]
  },
  "geo" : { },
  "id_str" : "119869082437820416",
  "text" : "I'm watching Tinker, Tailor, Soldier, Spy http:\/\/t.co\/SQ4cTeBp @GetGlue #TinkerTailorSoldierSpy",
  "id" : 119869082437820416,
  "created_at" : "2011-09-30 20:19:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 12, 24 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119848332813275136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5880335167, -6.2127615167 ]
  },
  "id_str" : "119851971288109056",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin @rickydunlop think I might go with a qnap or something like that. Dunno... Need to think.",
  "id" : 119851971288109056,
  "in_reply_to_status_id" : 119848332813275136,
  "created_at" : "2011-09-30 19:11:51 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 53, 61 ],
      "id_str" : "7885972",
      "id" : 7885972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/yvrxtZTx",
      "expanded_url" : "http:\/\/bit.ly\/oiutF0",
      "display_url" : "bit.ly\/oiutF0"
    } ]
  },
  "geo" : { },
  "id_str" : "119851361742495744",
  "text" : "I unlocked the The Big Bang Theory: Penny sticker on @GetGlue! http:\/\/t.co\/yvrxtZTx",
  "id" : 119851361742495744,
  "created_at" : "2011-09-30 19:09:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 79, 87 ],
      "id_str" : "7885972",
      "id" : 7885972
    }, {
      "name" : "The Big Bang Theory",
      "screen_name" : "BigBang_CBS",
      "indices" : [ 88, 100 ],
      "id_str" : "72644483",
      "id" : 72644483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/zXeulqqp",
      "expanded_url" : "http:\/\/bit.ly\/oImP2y",
      "display_url" : "bit.ly\/oImP2y"
    } ]
  },
  "geo" : { },
  "id_str" : "119851345804144640",
  "text" : "I'm watching The Big Bang Theory (1264 others checked-in) http:\/\/t.co\/zXeulqqp @GetGlue @BigBang_CBS",
  "id" : 119851345804144640,
  "created_at" : "2011-09-30 19:09:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119844755281678337",
  "text" : "The DLNA player on my TV wont play .mkv or .wmv - which is annoying.. Time to get a media player I'd say. AppleTV wont do the job.",
  "id" : 119844755281678337,
  "created_at" : "2011-09-30 18:43:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Deeley",
      "screen_name" : "catdeeley",
      "indices" : [ 0, 10 ],
      "id_str" : "46284762",
      "id" : 46284762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119786611612454912",
  "geo" : { },
  "id_str" : "119788357512470528",
  "in_reply_to_user_id" : 46284762,
  "text" : "@catdeeley its 4pm in the UK.. Get up!!!!!",
  "id" : 119788357512470528,
  "in_reply_to_status_id" : 119786611612454912,
  "created_at" : "2011-09-30 14:59:04 +0000",
  "in_reply_to_screen_name" : "catdeeley",
  "in_reply_to_user_id_str" : "46284762",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119769728016334848",
  "geo" : { },
  "id_str" : "119770689283694592",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard it just started raining up here.... Fucking hole of a country of this!",
  "id" : 119770689283694592,
  "in_reply_to_status_id" : 119769728016334848,
  "created_at" : "2011-09-30 13:48:52 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/0WSrRQrq",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-15122444",
      "display_url" : "bbc.co.uk\/news\/uk-151224\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119768383926439936",
  "text" : "Bull. Fucking. Shit. http:\/\/t.co\/0WSrRQrq",
  "id" : 119768383926439936,
  "created_at" : "2011-09-30 13:39:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC This Week",
      "screen_name" : "bbcthisweek",
      "indices" : [ 31, 43 ],
      "id_str" : "78602972",
      "id" : 78602972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/Tu3bG4Wc",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-politics-15124481",
      "display_url" : "bbc.co.uk\/news\/uk-politi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119758147400368128",
  "text" : "Feck sake... First time I miss @bbcthisweek and they finally get a decent guest. Sir David Frost. http:\/\/t.co\/Tu3bG4Wc",
  "id" : 119758147400368128,
  "created_at" : "2011-09-30 12:59:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119757577847455744",
  "text" : "So much for getting the last of that grass cut in the garden this weekend. Fucking rain.",
  "id" : 119757577847455744,
  "created_at" : "2011-09-30 12:56:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119740170571489280",
  "text" : "\"I'm not making McDonalds I'm makin you a momma's burger!\"",
  "id" : 119740170571489280,
  "created_at" : "2011-09-30 11:47:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119730214937964544",
  "geo" : { },
  "id_str" : "119732891600175104",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore what floor you in? I was in your building last night - next time I'll drop in and say \"hi\".",
  "id" : 119732891600175104,
  "in_reply_to_status_id" : 119730214937964544,
  "created_at" : "2011-09-30 11:18:40 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119723665704235008",
  "geo" : { },
  "id_str" : "119725166627536896",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard flip flops.... Eugggghhhhhhhhhh",
  "id" : 119725166627536896,
  "in_reply_to_status_id" : 119723665704235008,
  "created_at" : "2011-09-30 10:47:58 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sweltered",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119722944434929664",
  "text" : "Can't believe I wore a jumper today. #sweltered",
  "id" : 119722944434929664,
  "created_at" : "2011-09-30 10:39:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119708739338121216",
  "in_reply_to_user_id" : 95167567,
  "text" : "@Paulkennedy974 apologies... wasn't you on the radio... I need more sleep :)",
  "id" : 119708739338121216,
  "created_at" : "2011-09-30 09:42:42 +0000",
  "in_reply_to_screen_name" : "PKCOOLFM",
  "in_reply_to_user_id_str" : "95167567",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119702397751795712",
  "text" : "Just saying @Paulkennedy974.. Talk over a song again and its a road trip to Ards to kick your ass :D",
  "id" : 119702397751795712,
  "created_at" : "2011-09-30 09:17:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119681016960008193",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf come on!!!!!!",
  "id" : 119681016960008193,
  "created_at" : "2011-09-30 07:52:32 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119674512613715968",
  "text" : "Holy good fuck it is Friday!!!!",
  "id" : 119674512613715968,
  "created_at" : "2011-09-30 07:26:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 73, 81 ],
      "id_str" : "7885972",
      "id" : 7885972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOAFX",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/CtUhajpX",
      "expanded_url" : "http:\/\/bit.ly\/nUUM48",
      "display_url" : "bit.ly\/nUUM48"
    } ]
  },
  "geo" : { },
  "id_str" : "119498656989716480",
  "text" : "I'm watching Sons of Anarchy (96 others checked-in) http:\/\/t.co\/CtUhajpX @GetGlue #SOAFX",
  "id" : 119498656989716480,
  "created_at" : "2011-09-29 19:47:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 8, 21 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119438024105934848",
  "geo" : { },
  "id_str" : "119438221456326657",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe @joannedunlop Yeah - I got it right... Get 'em out love :D",
  "id" : 119438221456326657,
  "in_reply_to_status_id" : 119438024105934848,
  "created_at" : "2011-09-29 15:47:45 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119436663813443585",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop 62... I hope you keep your word!",
  "id" : 119436663813443585,
  "created_at" : "2011-09-29 15:41:34 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119435878266449920",
  "geo" : { },
  "id_str" : "119436217879248897",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop as long as it is your side boob :) Want this in writing first.....",
  "id" : 119436217879248897,
  "in_reply_to_status_id" : 119435878266449920,
  "created_at" : "2011-09-29 15:39:48 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119434649347952641",
  "geo" : { },
  "id_str" : "119435560606629888",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop Do I get a sideboob for this? - 15th Oct - Beat the Rec\u00A3ssion roadshow comes to St Georges",
  "id" : 119435560606629888,
  "in_reply_to_status_id" : 119434649347952641,
  "created_at" : "2011-09-29 15:37:11 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119414512024690688",
  "text" : "I am King Midas in reverse today.. Everything I touch is turning to shit.",
  "id" : 119414512024690688,
  "created_at" : "2011-09-29 14:13:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 17, 29 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119369072478662656",
  "text" : "Me and the great @stimpled0rf are due such an epic sausage of baps tomorrow!!!",
  "id" : 119369072478662656,
  "created_at" : "2011-09-29 11:12:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119328779326853120",
  "text" : "bunzip2 - why oh why can you not just be bunzip instead of that stupid 2. And no - setting an alias wont help!",
  "id" : 119328779326853120,
  "created_at" : "2011-09-29 08:32:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.509631405, -6.0470394575 ]
  },
  "id_str" : "119095424857550848",
  "text" : "Picking up my car in an hour.... Can't. Fucking. Wait.",
  "id" : 119095424857550848,
  "created_at" : "2011-09-28 17:05:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119024318729568256",
  "geo" : { },
  "id_str" : "119024533331128320",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams you say that as if you were suprised.",
  "id" : 119024533331128320,
  "in_reply_to_status_id" : 119024318729568256,
  "created_at" : "2011-09-28 12:23:54 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118999020172615680",
  "geo" : { },
  "id_str" : "119024482756206593",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues geting the car back tonight os that's me sorted :) I am just not made for public transport.",
  "id" : 119024482756206593,
  "in_reply_to_status_id" : 118999020172615680,
  "created_at" : "2011-09-28 12:23:42 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mar\u00EDa Basia ",
      "screen_name" : "maria_basia",
      "indices" : [ 3, 15 ],
      "id_str" : "235508724",
      "id" : 235508724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118960786017226753",
  "text" : "RT @maria_basia: Good morning world, I love you",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118960358374391808",
    "text" : "Good morning world, I love you",
    "id" : 118960358374391808,
    "created_at" : "2011-09-28 08:08:54 +0000",
    "user" : {
      "name" : "Mar\u00EDa Basia ",
      "screen_name" : "maria_basia",
      "protected" : true,
      "id_str" : "235508724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000197478535\/e4b77e3f5ef70c1b775c4a864af6b994_normal.jpeg",
      "id" : 235508724,
      "verified" : false
    }
  },
  "id" : 118960786017226753,
  "created_at" : "2011-09-28 08:10:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118958584976506880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.50961026, -6.047101105 ]
  },
  "id_str" : "118959092151758848",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb and it's way too expensive. 5.50 return from Glenavy to Belfast. Then 3.50 from Lisburn to Hillsborough. 45 a week!",
  "id" : 118959092151758848,
  "in_reply_to_status_id" : 118958584976506880,
  "created_at" : "2011-09-28 08:03:52 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118957938147721216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5093849111, -6.0471096778 ]
  },
  "id_str" : "118958197066317824",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb am hoping today... I hope so. The bus hasn't been that bad this time. Thus morning has been annoying though.",
  "id" : 118958197066317824,
  "in_reply_to_status_id" : 118957938147721216,
  "created_at" : "2011-09-28 08:00:18 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5091939086, -6.04684229 ]
  },
  "id_str" : "118955764323856385",
  "text" : "Just asked the bus info fella about my bus. He said it came but went to stand 4 instead... *RAGE*",
  "id" : 118955764323856385,
  "created_at" : "2011-09-28 07:50:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 102, 115 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118954913492500481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5091939086, -6.04684229 ]
  },
  "id_str" : "118955366204702722",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb I dunno. No bills, no responsibility, hair, two quid a week was a fortune to me, no work or @RickyHassard in my life. Loved it!",
  "id" : 118955366204702722,
  "in_reply_to_status_id" : 118954913492500481,
  "created_at" : "2011-09-28 07:49:04 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118953870247469056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5093106267, -6.0469537733 ]
  },
  "id_str" : "118954136556421120",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb I tried for the curtains but (get this) my hair was too thick for it to work :)",
  "id" : 118954136556421120,
  "in_reply_to_status_id" : 118953870247469056,
  "created_at" : "2011-09-28 07:44:10 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118952664179539968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5093918933, -6.0472303256 ]
  },
  "id_str" : "118953232830709760",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb that is true. When I think of the things I did when I was that age. Catipillar boots with the tounge out, skinny ties...",
  "id" : 118953232830709760,
  "in_reply_to_status_id" : 118952664179539968,
  "created_at" : "2011-09-28 07:40:35 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5093918933, -6.0472303256 ]
  },
  "id_str" : "118952887379431424",
  "text" : "Ok... My bus in this morning was 5mins later than usual... But I stood at stand 6 for the connection to Banbridge and it never came.",
  "id" : 118952887379431424,
  "created_at" : "2011-09-28 07:39:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/261YCew9",
      "expanded_url" : "http:\/\/yfrog.com\/hwcorkj",
      "display_url" : "yfrog.com\/hwcorkj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.509481515, -6.04695564 ]
  },
  "id_str" : "118950076067483648",
  "text" : "Proof of that stupid trend with the different coloured laces..  http:\/\/t.co\/261YCew9",
  "id" : 118950076067483648,
  "created_at" : "2011-09-28 07:28:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.509536667, -6.047153968 ]
  },
  "id_str" : "118949396162428928",
  "text" : "This bus is late... The screen says \"Departed\". But it's lying. I need to bring a book with me instead of spamming your feeds :)",
  "id" : 118949396162428928,
  "created_at" : "2011-09-28 07:25:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5094828125, -6.0469580975 ]
  },
  "id_str" : "118947361501360128",
  "text" : "Hopefully get my car back today. Then I shall be ignorant of kids social groups and trends.",
  "id" : 118947361501360128,
  "created_at" : "2011-09-28 07:17:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5094828125, -6.0469580975 ]
  },
  "id_str" : "118947132618194945",
  "text" : "Seems there is a trend for the kids to wear trainers that aren't tied \/and\/ are an opposing colour.",
  "id" : 118947132618194945,
  "created_at" : "2011-09-28 07:16:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118946046486380544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5096544314, -6.0471742514 ]
  },
  "id_str" : "118946826584985601",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne how long do you swim for?",
  "id" : 118946826584985601,
  "in_reply_to_status_id" : 118946046486380544,
  "created_at" : "2011-09-28 07:15:08 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5093104283, -6.0469268817 ]
  },
  "id_str" : "118945983152402432",
  "text" : "School kids and their social groupings... Funny to watch. If you are in the right mood, fucking irritating if not.",
  "id" : 118945983152402432,
  "created_at" : "2011-09-28 07:11:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118793725194420224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593357142, -6.212610692 ]
  },
  "id_str" : "118794876727992321",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop don't ask twitter about grooming products is a good start ;)",
  "id" : 118794876727992321,
  "in_reply_to_status_id" : 118793725194420224,
  "created_at" : "2011-09-27 21:11:20 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118791516004167680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933525917, -6.2125371433 ]
  },
  "id_str" : "118793033532706817",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop brute... Asking twitter for aftershave info. Man up!!! :)",
  "id" : 118793033532706817,
  "in_reply_to_status_id" : 118791516004167680,
  "created_at" : "2011-09-27 21:04:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 30, 41 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118780511006109696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593313822, -6.212610788 ]
  },
  "id_str" : "118781027295567874",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit @johngirvin :) I like the explanation. I think you're cool.. But your deffo a geek.. No doubt about it.",
  "id" : 118781027295567874,
  "in_reply_to_status_id" : 118780511006109696,
  "created_at" : "2011-09-27 20:16:18 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 30, 41 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118778914062606336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933221933, -6.2123058283 ]
  },
  "id_str" : "118779457275314176",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit @johngirvin \"Did you know fix gloves were poisonous?\". A factoid about plants \/then\/ an explanation. Is geeky!",
  "id" : 118779457275314176,
  "in_reply_to_status_id" : 118778914062606336,
  "created_at" : "2011-09-27 20:10:04 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118762813408813056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59334993, -6.21251113 ]
  },
  "id_str" : "118762968346394624",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit oh no no no. You is a geek as well :)",
  "id" : 118762968346394624,
  "in_reply_to_status_id" : 118762813408813056,
  "created_at" : "2011-09-27 19:04:32 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/d3D1OU8l",
      "expanded_url" : "http:\/\/yfrog.com\/ke3juhpj",
      "display_url" : "yfrog.com\/ke3juhpj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.509631405, -6.0470394575 ]
  },
  "id_str" : "118731919637741568",
  "text" : "Me and my Sis have a gr8 way with each other. I rang her earlier to do a favour for me and she was moody on the phone.  http:\/\/t.co\/d3D1OU8l",
  "id" : 118731919637741568,
  "created_at" : "2011-09-27 17:01:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 82, 97 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118708352141361152",
  "geo" : { },
  "id_str" : "118708594140127233",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit thought it might have been interesting. It wasn't. Goes 2 show that @Georgina_Milne is the more interesting one in your duo :)",
  "id" : 118708594140127233,
  "in_reply_to_status_id" : 118708352141361152,
  "created_at" : "2011-09-27 15:28:28 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118707610319986689",
  "geo" : { },
  "id_str" : "118707840255918081",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit boring!",
  "id" : 118707840255918081,
  "in_reply_to_status_id" : 118707610319986689,
  "created_at" : "2011-09-27 15:25:29 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118702360007688193",
  "geo" : { },
  "id_str" : "118704506988019712",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit share your grocery list... awwwww go on :)",
  "id" : 118704506988019712,
  "in_reply_to_status_id" : 118702360007688193,
  "created_at" : "2011-09-27 15:12:14 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 0, 12 ],
      "id_str" : "216299334",
      "id" : 216299334
    }, {
      "name" : "Ivan Lewis",
      "screen_name" : "IvanLewis_MP",
      "indices" : [ 13, 26 ],
      "id_str" : "249709671",
      "id" : 249709671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118666408778416128",
  "geo" : { },
  "id_str" : "118667458142932992",
  "in_reply_to_user_id" : 216299334,
  "text" : "@piersmorgan @ivanlewis_mp but you used to be the editor of the Mirror. Pot.. Kettle... :D",
  "id" : 118667458142932992,
  "in_reply_to_status_id" : 118666408778416128,
  "created_at" : "2011-09-27 12:45:01 +0000",
  "in_reply_to_screen_name" : "piersmorgan",
  "in_reply_to_user_id_str" : "216299334",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bapgate",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118667011835441152",
  "text" : "Am pretty sure 'A Greater God' or 'God' for that matter could care less as to how you are dressed. #bapgate",
  "id" : 118667011835441152,
  "created_at" : "2011-09-27 12:43:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118648093565652992",
  "text" : "After I finish my lunch I am working on fixing a bug.... Great - I love bugs... Really I do!",
  "id" : 118648093565652992,
  "created_at" : "2011-09-27 11:28:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mar\u00EDa Basia ",
      "screen_name" : "maria_basia",
      "indices" : [ 0, 12 ],
      "id_str" : "235508724",
      "id" : 235508724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118597356764663810",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5097594411, -6.0469186778 ]
  },
  "id_str" : "118597726710677505",
  "in_reply_to_user_id" : 235508724,
  "text" : "@maria_basia car refuses to work. Should get her back soon though. But the kids on that bus... So irritating.",
  "id" : 118597726710677505,
  "in_reply_to_status_id" : 118597356764663810,
  "created_at" : "2011-09-27 08:07:56 +0000",
  "in_reply_to_screen_name" : "maria_basia",
  "in_reply_to_user_id_str" : "235508724",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5097594411, -6.0469186778 ]
  },
  "id_str" : "118597056179863552",
  "text" : "Getting that 8:15 bus was actual torture. Think the 7:35 one is the only option.",
  "id" : 118597056179863552,
  "created_at" : "2011-09-27 08:05:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 45, 53 ],
      "id_str" : "7885972",
      "id" : 7885972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/OW8aWM3o",
      "expanded_url" : "http:\/\/bit.ly\/oJ9jov",
      "display_url" : "bit.ly\/oJ9jov"
    } ]
  },
  "geo" : { },
  "id_str" : "118408778709344256",
  "text" : "I unlocked the Ready for Fall TV! sticker on @GetGlue! http:\/\/t.co\/OW8aWM3o",
  "id" : 118408778709344256,
  "created_at" : "2011-09-26 19:37:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 75, 83 ],
      "id_str" : "7885972",
      "id" : 7885972
    }, {
      "name" : "HBO",
      "screen_name" : "HBO",
      "indices" : [ 84, 88 ],
      "id_str" : "15635604",
      "id" : 15635604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/6NxmjoCi",
      "expanded_url" : "http:\/\/bit.ly\/oKoGJC",
      "display_url" : "bit.ly\/oKoGJC"
    } ]
  },
  "geo" : { },
  "id_str" : "118408764008308737",
  "text" : "I'm watching Boardwalk Empire (158 others checked-in) http:\/\/t.co\/6NxmjoCi @GetGlue @HBO",
  "id" : 118408764008308737,
  "created_at" : "2011-09-26 19:37:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118392436002258946",
  "text" : "Seems that Sky Atlantic is gonna wait a few days before broadcasting Broadwalk Empire.. Idiots. So annoying.. If only there was a way I cou.",
  "id" : 118392436002258946,
  "created_at" : "2011-09-26 18:32:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118358177917042688",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe has left me to get the bus all on my own!!! Heartless bastard - what if someone kidnaps me???",
  "id" : 118358177917042688,
  "created_at" : "2011-09-26 16:16:03 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118329873830920192",
  "text" : "A espresso might help me",
  "id" : 118329873830920192,
  "created_at" : "2011-09-26 14:23:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 15, 28 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 29, 44 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 45, 56 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118326804678320128",
  "geo" : { },
  "id_str" : "118327969658843137",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @stevebiscuit @georgina_milne @magic8lisa tall black haired hairy pussy then :) If you make a joke outta that then you r sick",
  "id" : 118327969658843137,
  "in_reply_to_status_id" : 118326804678320128,
  "created_at" : "2011-09-26 14:16:01 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 15, 28 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 29, 44 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 45, 56 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118326551476576256",
  "geo" : { },
  "id_str" : "118326689951514624",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @stevebiscuit @georgina_milne @magic8lisa DERRY PUSSY :D",
  "id" : 118326689951514624,
  "in_reply_to_status_id" : 118326551476576256,
  "created_at" : "2011-09-26 14:10:55 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 16, 30 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 31, 42 ],
      "id_str" : "210949996",
      "id" : 210949996
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 85, 98 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118281568719613952",
  "geo" : { },
  "id_str" : "118324282014179328",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @no_underscore @magic8lisa pack of pussies! :D G - I is up for it if @stevebiscuit is :D",
  "id" : 118324282014179328,
  "in_reply_to_status_id" : 118281568719613952,
  "created_at" : "2011-09-26 14:01:21 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Braziel",
      "screen_name" : "Braziel",
      "indices" : [ 0, 8 ],
      "id_str" : "776654",
      "id" : 776654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118055613610721280",
  "geo" : { },
  "id_str" : "118057766156898305",
  "in_reply_to_user_id" : 776654,
  "text" : "@Braziel Mine started on Thursday... It is still hanging around. No sign of it going soon :(",
  "id" : 118057766156898305,
  "in_reply_to_status_id" : 118055613610721280,
  "created_at" : "2011-09-25 20:22:19 +0000",
  "in_reply_to_screen_name" : "Braziel",
  "in_reply_to_user_id_str" : "776654",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117585961243774976",
  "geo" : { },
  "id_str" : "117591993626017792",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop that they require adobe air updates every few weeks - which gets annoying. Other than that though its solid.",
  "id" : 117591993626017792,
  "in_reply_to_status_id" : 117585961243774976,
  "created_at" : "2011-09-24 13:31:30 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117585961243774976",
  "geo" : { },
  "id_str" : "117591839460171776",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop On windows or mac. The native twitter client is hard to beat for the mac - dunno about windows. Problem with tweetdeck is..",
  "id" : 117591839460171776,
  "in_reply_to_status_id" : 117585961243774976,
  "created_at" : "2011-09-24 13:30:53 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/1H5C6DYZ",
      "expanded_url" : "http:\/\/www.swtor.com\/news\/news-article\/20110924",
      "display_url" : "swtor.com\/news\/news-arti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117573888321392640",
  "text" : "Now the question is - can my 4 year old computer take it? - http:\/\/t.co\/1H5C6DYZ",
  "id" : 117573888321392640,
  "created_at" : "2011-09-24 12:19:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Old Republic",
      "screen_name" : "SWTOR",
      "indices" : [ 3, 9 ],
      "id_str" : "16890969",
      "id" : 16890969
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SWTOR",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117573706531868672",
  "text" : "RT @SWTOR: The wait is over! #SWTOR will officially release on 12\/20 (US) and 12\/22 (EU). Read the full details here: http:\/\/t.co\/Hxyaz9 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SWTOR",
        "indices" : [ 18, 24 ]
      }, {
        "text" : "TOR2011",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/Hxyaz9Pl",
        "expanded_url" : "http:\/\/bit.ly\/n3tWgw",
        "display_url" : "bit.ly\/n3tWgw"
      } ]
    },
    "geo" : { },
    "id_str" : "117562109767852032",
    "text" : "The wait is over! #SWTOR will officially release on 12\/20 (US) and 12\/22 (EU). Read the full details here: http:\/\/t.co\/Hxyaz9Pl #TOR2011",
    "id" : 117562109767852032,
    "created_at" : "2011-09-24 11:32:45 +0000",
    "user" : {
      "name" : "The Old Republic",
      "screen_name" : "SWTOR",
      "protected" : false,
      "id_str" : "16890969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3154185743\/28f7b6b96bd72d06e89d00e81d0e77cb_normal.jpeg",
      "id" : 16890969,
      "verified" : true
    }
  },
  "id" : 117573706531868672,
  "created_at" : "2011-09-24 12:18:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.6361376, -6.21358698 ]
  },
  "id_str" : "117360533879013377",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe How are ya?",
  "id" : 117360533879013377,
  "created_at" : "2011-09-23 22:11:46 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.6361376, -6.21358698 ]
  },
  "id_str" : "117360481039163393",
  "text" : "Thor is a shit film!",
  "id" : 117360481039163393,
  "created_at" : "2011-09-23 22:11:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117358163463905280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.6361376, -6.21358698 ]
  },
  "id_str" : "117360430673969153",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus Tuesday??? Get a move on son!",
  "id" : 117360430673969153,
  "in_reply_to_status_id" : 117358163463905280,
  "created_at" : "2011-09-23 22:11:21 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117315308087283712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933545625, -6.212622565 ]
  },
  "id_str" : "117328353408712704",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne so that's a yes then... Sweeeeet :)",
  "id" : 117328353408712704,
  "in_reply_to_status_id" : 117315308087283712,
  "created_at" : "2011-09-23 20:03:53 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117312719404802048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59332523, -6.212685712 ]
  },
  "id_str" : "117313032606064640",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne I was going to... But got sick. So am watching Glee at home. Have a good night. Mountain next weekend? :)",
  "id" : 117313032606064640,
  "in_reply_to_status_id" : 117312719404802048,
  "created_at" : "2011-09-23 19:03:01 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117311721416294401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59332523, -6.212685712 ]
  },
  "id_str" : "117311910130626561",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne 21 Social?",
  "id" : 117311910130626561,
  "in_reply_to_status_id" : 117311721416294401,
  "created_at" : "2011-09-23 18:58:33 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59332523, -6.212685712 ]
  },
  "id_str" : "117311824604565504",
  "text" : "I am watching Glee.... Not my choice....",
  "id" : 117311824604565504,
  "created_at" : "2011-09-23 18:58:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117226529230036993",
  "geo" : { },
  "id_str" : "117226946332590080",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin its easy. Just take away all your cynicism and replace it with enthusiasm.. You remember what it feels like - cos i don't!",
  "id" : 117226946332590080,
  "in_reply_to_status_id" : 117226529230036993,
  "created_at" : "2011-09-23 13:20:56 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117226356353404928",
  "geo" : { },
  "id_str" : "117226665221947392",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor sweet :) will look that up - thanks ginger boy :D",
  "id" : 117226665221947392,
  "in_reply_to_status_id" : 117226356353404928,
  "created_at" : "2011-09-23 13:19:49 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117224625724862464",
  "text" : "I think it might be handy if I learnt French.. (Don't ask).. I haven't looked at that language since I was 13.. Any ideas?",
  "id" : 117224625724862464,
  "created_at" : "2011-09-23 13:11:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/uVCjrF84",
      "expanded_url" : "http:\/\/a4.sphotos.ak.fbcdn.net\/hphotos-ak-ash2\/165366_10150107695863653_667353652_7341596_1618079_n.jpg",
      "display_url" : "a4.sphotos.ak.fbcdn.net\/hphotos-ak-ash\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117211308314734592",
  "text" : "I am sick cos of my fello Petorian... This wanker made me sick. What a knob. http:\/\/t.co\/uVCjrF84",
  "id" : 117211308314734592,
  "created_at" : "2011-09-23 12:18:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117181839709454337",
  "text" : "Gotta admit - I quite like the changes to FB... I haven't bothered with it in months though.",
  "id" : 117181839709454337,
  "created_at" : "2011-09-23 10:21:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117175995211063298",
  "geo" : { },
  "id_str" : "117181732284928000",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore where you heading off to? how long for? when?",
  "id" : 117181732284928000,
  "in_reply_to_status_id" : 117175995211063298,
  "created_at" : "2011-09-23 10:21:16 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 18, 27 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117157314892533760",
  "text" : "Seems I dont have @kirkcoyb  on Bakebook anymore... And he's huffing :)",
  "id" : 117157314892533760,
  "created_at" : "2011-09-23 08:44:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117155891857469440",
  "geo" : { },
  "id_str" : "117156025425076224",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb touchy :D I haven't a clue why you are off.. I am lookin now and a few are off.. Odd...",
  "id" : 117156025425076224,
  "in_reply_to_status_id" : 117155891857469440,
  "created_at" : "2011-09-23 08:39:07 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117155539347185664",
  "geo" : { },
  "id_str" : "117155729437233153",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb I didn't... I have two accounts for some odd reason - very odd indeed.. Never knew you were off this one.. I shall add! :)",
  "id" : 117155729437233153,
  "in_reply_to_status_id" : 117155539347185664,
  "created_at" : "2011-09-23 08:37:57 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117149179024908289",
  "text" : "Cos I was sick a while back my immune system is screwed... I got a really bad dose of the cold - I can just about talk. Fuck sake.",
  "id" : 117149179024908289,
  "created_at" : "2011-09-23 08:11:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/6wsr2dYr",
      "expanded_url" : "http:\/\/yfrog.com\/klx3cfyj",
      "display_url" : "yfrog.com\/klx3cfyj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5093305929, -6.0469609343 ]
  },
  "id_str" : "116924180309618689",
  "text" : "Lisburn.... Where fuckwits buy pink toilet seats!  http:\/\/t.co\/6wsr2dYr",
  "id" : 116924180309618689,
  "created_at" : "2011-09-22 17:17:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 3, 10 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.4628223233, -6.0829773942 ]
  },
  "id_str" : "116914965054627841",
  "text" : "No @srushe to get the bus home with. He got a lift instead. Heartless bastard.",
  "id" : 116914965054627841,
  "created_at" : "2011-09-22 16:41:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 11, 20 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116859990064631808",
  "geo" : { },
  "id_str" : "116873118856921089",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus @akaihane class :D BOKE BOKE BOKE Kaza BOKE BOKE BOKE",
  "id" : 116873118856921089,
  "in_reply_to_status_id" : 116859990064631808,
  "created_at" : "2011-09-22 13:54:57 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116857357367123968",
  "text" : "TMI Time: Just boked in the toilets - then when I sprayed the air freshner - it went into my face instead of in the air (stupid nozzle).",
  "id" : 116857357367123968,
  "created_at" : "2011-09-22 12:52:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116838982351994881",
  "text" : "I have the cold and feel like shite :(",
  "id" : 116838982351994881,
  "created_at" : "2011-09-22 11:39:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.510606105, -6.0520720633 ]
  },
  "id_str" : "116769662599049216",
  "text" : "Now to wait 15mins with the school kidz... When did they all start acting like they were in an episode of 'The Hills'?",
  "id" : 116769662599049216,
  "created_at" : "2011-09-22 07:03:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 11, 24 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.510606105, -6.0520720633 ]
  },
  "id_str" : "116768740321931264",
  "text" : "Just spied @RickyHassard in his car... Small world.",
  "id" : 116768740321931264,
  "created_at" : "2011-09-22 07:00:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116457456418299905",
  "text" : "WFH today - its cold in here... well this room anyway... Must resist turning the heating on.",
  "id" : 116457456418299905,
  "created_at" : "2011-09-21 10:23:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116444810474295296",
  "geo" : { },
  "id_str" : "116445193431027713",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Cheers. Might hire a car - depends how long I will be without.",
  "id" : 116445193431027713,
  "in_reply_to_status_id" : 116444810474295296,
  "created_at" : "2011-09-21 09:34:32 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116444730765742081",
  "geo" : { },
  "id_str" : "116445048589127680",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I use CentOS in work. It does the job. But I find debian just so much easier to use.",
  "id" : 116445048589127680,
  "in_reply_to_status_id" : 116444730765742081,
  "created_at" : "2011-09-21 09:33:57 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116437174995529730",
  "geo" : { },
  "id_str" : "116441035328073728",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore Dude.. Don't use CentOS.. Debian makes life so much easier.. Seriously. It does.",
  "id" : 116441035328073728,
  "in_reply_to_status_id" : 116437174995529730,
  "created_at" : "2011-09-21 09:18:00 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116410388832190465",
  "geo" : { },
  "id_str" : "116428280227307520",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Looks like the waterpump. Wont me mobile for a few days - so will pick it up next week if that is okay :)",
  "id" : 116428280227307520,
  "in_reply_to_status_id" : 116410388832190465,
  "created_at" : "2011-09-21 08:27:19 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116421470405656576",
  "text" : "Waterpump gone in the car... Wont have her back till Tuesday or there abouts - so its public transport till then - sweet! WFH today.",
  "id" : 116421470405656576,
  "created_at" : "2011-09-21 08:00:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5932973167, -6.2120090267 ]
  },
  "id_str" : "116410236763512832",
  "text" : "Car just made funny noises when I started her there.....",
  "id" : 116410236763512832,
  "created_at" : "2011-09-21 07:15:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116074444929236993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5932973167, -6.2120090267 ]
  },
  "id_str" : "116410040063234048",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb actually just hit in my car and it made a funny noise... So can I pick it up tomorrow. Gonna go to garage and see....",
  "id" : 116410040063234048,
  "in_reply_to_status_id" : 116074444929236993,
  "created_at" : "2011-09-21 07:14:51 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116074444929236993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593338364, -6.21251833 ]
  },
  "id_str" : "116407634353074176",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb on my way in now :)",
  "id" : 116407634353074176,
  "in_reply_to_status_id" : 116074444929236993,
  "created_at" : "2011-09-21 07:05:17 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 14, 26 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116285959099785216",
  "text" : "Happy 30th to @willemkokke :D You are in the cool gang again you beautiful dutch bastard :D",
  "id" : 116285959099785216,
  "created_at" : "2011-09-20 23:01:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933424367, -6.2125223433 ]
  },
  "id_str" : "116256116224172034",
  "text" : "Heating on for two hours tonight again. I feel ashamed....",
  "id" : 116256116224172034,
  "created_at" : "2011-09-20 21:03:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116242953634197507",
  "geo" : { },
  "id_str" : "116255115773620224",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne yeah. I like U2.. I just find him sooooo annoying... He isn't a statesman... Annoys me.",
  "id" : 116255115773620224,
  "in_reply_to_status_id" : 116242953634197507,
  "created_at" : "2011-09-20 20:59:14 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116229186401746944",
  "text" : "Maybe do a bit of work now..... That was a good documentary till those two twats turned up... Lord Trimble came on - boy is he bland.",
  "id" : 116229186401746944,
  "created_at" : "2011-09-20 19:16:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116228097887576064",
  "text" : "Oh fuck Eammon McCan just came on... Time to switch this off.. Can't be having McCann and Bono on at the same time.....",
  "id" : 116228097887576064,
  "created_at" : "2011-09-20 19:11:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116227955574841344",
  "text" : "Also seeing Seamous Mallon and John Hume back on the tv even for 20mins is great. Only politician really wort anything now is Naomi Long.",
  "id" : 116227955574841344,
  "created_at" : "2011-09-20 19:11:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59329356, -6.2123604114 ]
  },
  "id_str" : "116226908399738882",
  "text" : "Watching a documentary on John Hume... And who pops up but Bono. What the fuck has he got to offer to this? Fucking knob!",
  "id" : 116226908399738882,
  "created_at" : "2011-09-20 19:07:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Nolan",
      "screen_name" : "StephenNolan",
      "indices" : [ 0, 13 ],
      "id_str" : "36673147",
      "id" : 36673147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116197411860385792",
  "geo" : { },
  "id_str" : "116197882159312898",
  "in_reply_to_user_id" : 36673147,
  "text" : "@StephenNolan Yes it is :( But probably worth it in your car - it isn't that old. But it can only be the gasket if your car is losing water.",
  "id" : 116197882159312898,
  "in_reply_to_status_id" : 116197411860385792,
  "created_at" : "2011-09-20 17:11:48 +0000",
  "in_reply_to_screen_name" : "StephenNolan",
  "in_reply_to_user_id_str" : "36673147",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 38, 45 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116185861346963457",
  "text" : "I am getting my ass kicked so much by @srushe its not even funny. I haven't had an ass kicking this much since 2003!",
  "id" : 116185861346963457,
  "created_at" : "2011-09-20 16:24:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116102832700141568",
  "text" : "I love it when a good U2 song comes on the radio.. Pity Bono is such a fucking knob though - kinda spoils the song for me!",
  "id" : 116102832700141568,
  "created_at" : "2011-09-20 10:54:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116068738872250368",
  "geo" : { },
  "id_str" : "116072847658590208",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Coolio... Remember to wear something slutty :D",
  "id" : 116072847658590208,
  "in_reply_to_status_id" : 116068738872250368,
  "created_at" : "2011-09-20 08:54:58 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116070833654468608",
  "geo" : { },
  "id_str" : "116071101922156544",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Class.. You about at 8 tomorrow then? :)",
  "id" : 116071101922156544,
  "in_reply_to_status_id" : 116070833654468608,
  "created_at" : "2011-09-20 08:48:01 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116068738872250368",
  "geo" : { },
  "id_str" : "116070501163601920",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb ahhhh. I didn't know if I was to come for it this morning or tomorrow... Can i pick it up tomorrow morning now instead please? :)",
  "id" : 116070501163601920,
  "in_reply_to_status_id" : 116068738872250368,
  "created_at" : "2011-09-20 08:45:38 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116067094134669312",
  "text" : "First cup of tea today.... All this drinking I do now to help drain the lymphatic system is doing my head in. But sure....",
  "id" : 116067094134669312,
  "created_at" : "2011-09-20 08:32:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116036685757808640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5775967367, -5.9619284833 ]
  },
  "id_str" : "116044057028984832",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you are only human :) Take a rest week :)",
  "id" : 116044057028984832,
  "in_reply_to_status_id" : 116036685757808640,
  "created_at" : "2011-09-20 07:00:33 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5775967367, -5.9619284833 ]
  },
  "id_str" : "116039337577168896",
  "text" : "I didnt feel sick once this morning... Nope. I felt sick eighteen separate times. Endorphins... Where are ya!?",
  "id" : 116039337577168896,
  "created_at" : "2011-09-20 06:41:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59332151, -6.21268329 ]
  },
  "id_str" : "115866407794778112",
  "text" : "I just shoved on the heating. My Presbie ancestors would not be pleased. :(",
  "id" : 115866407794778112,
  "created_at" : "2011-09-19 19:14:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115815117802844161",
  "geo" : { },
  "id_str" : "115815276754378752",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus I'll do it when I get home... Am busy :D - Not often I work like 'a boss' but am today!",
  "id" : 115815276754378752,
  "in_reply_to_status_id" : 115815117802844161,
  "created_at" : "2011-09-19 15:51:28 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115814898440732672",
  "geo" : { },
  "id_str" : "115815048680701952",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus hence why I said 'officially'.",
  "id" : 115815048680701952,
  "in_reply_to_status_id" : 115814898440732672,
  "created_at" : "2011-09-19 15:50:34 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115811854521073664",
  "geo" : { },
  "id_str" : "115814645146730496",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus did you just the 'i' word??? Think that means you are now officially a twat\/asshole\/cunt... Pretty sure it does anyway!",
  "id" : 115814645146730496,
  "in_reply_to_status_id" : 115811854521073664,
  "created_at" : "2011-09-19 15:48:57 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115802618416205824",
  "text" : "Martin 'v' Dana... You couldn't make this shit up!",
  "id" : 115802618416205824,
  "created_at" : "2011-09-19 15:01:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/jOTa0jbJ",
      "expanded_url" : "http:\/\/yfrog.com\/h7wqtfnj",
      "display_url" : "yfrog.com\/h7wqtfnj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.4629498383, -6.08286723 ]
  },
  "id_str" : "115717237251375104",
  "text" : "Random - I normally hate Halloween...  http:\/\/t.co\/jOTa0jbJ",
  "id" : 115717237251375104,
  "created_at" : "2011-09-19 09:21:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593311472, -6.212656552 ]
  },
  "id_str" : "115693947082379264",
  "text" : "Amazing how different the tone of a Monday is compared to that of a Sunday.",
  "id" : 115693947082379264,
  "created_at" : "2011-09-19 07:49:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115538658811064320",
  "geo" : { },
  "id_str" : "115540490329391104",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard why?",
  "id" : 115540490329391104,
  "in_reply_to_status_id" : 115538658811064320,
  "created_at" : "2011-09-18 21:39:34 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115535911093141504",
  "geo" : { },
  "id_str" : "115536530948370432",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard I have that on record..... Fuck it - I am watching Downtown Abbey.. I'll shave my vagina tomorrow!",
  "id" : 115536530948370432,
  "in_reply_to_status_id" : 115535911093141504,
  "created_at" : "2011-09-18 21:23:50 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115523508968235008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933607025, -6.21266038 ]
  },
  "id_str" : "115532148626309121",
  "in_reply_to_user_id" : 210949996,
  "text" : "@Lisami75 you might have to tell your laptop to use the external speakers. What you got mac or windows?",
  "id" : 115532148626309121,
  "in_reply_to_status_id" : 115523508968235008,
  "created_at" : "2011-09-18 21:06:25 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115521273114787840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933607025, -6.21266038 ]
  },
  "id_str" : "115531958108430336",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne how long can you hold the handspring for? Is that only one hand holding on as well?",
  "id" : 115531958108430336,
  "in_reply_to_status_id" : 115521273114787840,
  "created_at" : "2011-09-18 21:05:39 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933607025, -6.21266038 ]
  },
  "id_str" : "115517383300485120",
  "text" : "Ahh well. Downtown Abbey it is then :)",
  "id" : 115517383300485120,
  "created_at" : "2011-09-18 20:07:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115461920601030656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933607025, -6.21266038 ]
  },
  "id_str" : "115463319065853952",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore the pic of dinner :)",
  "id" : 115463319065853952,
  "in_reply_to_status_id" : 115461920601030656,
  "created_at" : "2011-09-18 16:32:55 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115434955005362177",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933629375, -6.2126698125 ]
  },
  "id_str" : "115461683270524930",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore didn't want to say ;) Ahh well could be worse ;)",
  "id" : 115461683270524930,
  "in_reply_to_status_id" : 115434955005362177,
  "created_at" : "2011-09-18 16:26:25 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cabal",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115418738400034816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933629375, -6.2126698125 ]
  },
  "id_str" : "115461255082414080",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit been too busy lately to be on bitchtalk or #cabal. You got a contract for this comin week or chillin?",
  "id" : 115461255082414080,
  "in_reply_to_status_id" : 115418738400034816,
  "created_at" : "2011-09-18 16:24:43 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115392951651282944",
  "geo" : { },
  "id_str" : "115398829192388608",
  "in_reply_to_user_id" : 210949996,
  "text" : "@Lisami75 Divis?",
  "id" : 115398829192388608,
  "in_reply_to_status_id" : 115392951651282944,
  "created_at" : "2011-09-18 12:16:39 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 25, 38 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/b9WdGzIp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=tgbNymZ7vqY&feature=related",
      "display_url" : "youtube.com\/watch?v=tgbNym\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115389357594120192",
  "text" : "Class Video. Pretty sure @RickyHassard is in there somewhere. http:\/\/t.co\/b9WdGzIp",
  "id" : 115389357594120192,
  "created_at" : "2011-09-18 11:39:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59332207, -6.212141604 ]
  },
  "id_str" : "115108811592835074",
  "text" : "Sister just got a HTC Desire S. Apple better up their game. Contract is up next month.",
  "id" : 115108811592835074,
  "created_at" : "2011-09-17 17:04:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115106509939163136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59332207, -6.212141604 ]
  },
  "id_str" : "115108003862163456",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore dating is shite. Wanna share scare stories. My most recent one was a cracker :) It's good craic though :)",
  "id" : 115108003862163456,
  "in_reply_to_status_id" : 115106509939163136,
  "created_at" : "2011-09-17 17:01:01 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/WCnjc5rm",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7gZkqHH08A0&feature=related",
      "display_url" : "youtube.com\/watch?v=7gZkqH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115032479072665601",
  "text" : "http:\/\/t.co\/WCnjc5rm - This will probably be in the 3D edition.",
  "id" : 115032479072665601,
  "created_at" : "2011-09-17 12:00:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114830709788651520",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe - move bitcho :)",
  "id" : 114830709788651520,
  "created_at" : "2011-09-16 22:39:09 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 25, 37 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114800805764284416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59335346, -6.2126369125 ]
  },
  "id_str" : "114809109836087296",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll hope you and @stimpled0rf have a great holiday! Am gonna miss Mike when he's away..",
  "id" : 114809109836087296,
  "in_reply_to_status_id" : 114800805764284416,
  "created_at" : "2011-09-16 21:13:19 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114774254280642560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593327352, -6.212689894 ]
  },
  "id_str" : "114774644548046848",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit That's the spirit :)",
  "id" : 114774644548046848,
  "in_reply_to_status_id" : 114774254280642560,
  "created_at" : "2011-09-16 18:56:22 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114752722800091136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933058, -6.21199919 ]
  },
  "id_str" : "114770539872141312",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne do I sense weakness?",
  "id" : 114770539872141312,
  "in_reply_to_status_id" : 114752722800091136,
  "created_at" : "2011-09-16 18:40:03 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114716956518662144",
  "geo" : { },
  "id_str" : "114717393258950656",
  "in_reply_to_user_id" : 210949996,
  "text" : "@Lisami75 sell it. Why do ppl go on about souls re: work. Go with whatever pays the most :) Selling your soul feels good :)",
  "id" : 114717393258950656,
  "in_reply_to_status_id" : 114716956518662144,
  "created_at" : "2011-09-16 15:08:52 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Crawford",
      "screen_name" : "Kitty_Crawford",
      "indices" : [ 0, 15 ],
      "id_str" : "21756710",
      "id" : 21756710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114699799298719745",
  "geo" : { },
  "id_str" : "114708981716488192",
  "in_reply_to_user_id" : 21756710,
  "text" : "@Kitty_Crawford I do - but I am in Hillsborough!",
  "id" : 114708981716488192,
  "in_reply_to_status_id" : 114699799298719745,
  "created_at" : "2011-09-16 14:35:27 +0000",
  "in_reply_to_screen_name" : "Kitty_Crawford",
  "in_reply_to_user_id_str" : "21756710",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114673926017269760",
  "text" : "Any ppl out there now how to use squid and htpasswd authentican - its beyond me :)",
  "id" : 114673926017269760,
  "created_at" : "2011-09-16 12:16:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114365824680214529",
  "geo" : { },
  "id_str" : "114367407665065984",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin its a great tune! Good to code for! Wish I was flying in an F-15 doing a 4g inverted dive with a MiG28! Sure beats programming!",
  "id" : 114367407665065984,
  "in_reply_to_status_id" : 114365824680214529,
  "created_at" : "2011-09-15 15:58:09 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114363040778027008",
  "geo" : { },
  "id_str" : "114364380287741952",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall you said it was gonna be 1k... You have softened from your stance Jenni!!! :D",
  "id" : 114364380287741952,
  "in_reply_to_status_id" : 114363040778027008,
  "created_at" : "2011-09-15 15:46:07 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoolFM",
      "screen_name" : "CoolFM",
      "indices" : [ 28, 35 ],
      "id_str" : "20199652",
      "id" : 20199652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114364205280411648",
  "text" : "The dangerzone just came on @COOLFM there - fan fucking tastic!",
  "id" : 114364205280411648,
  "created_at" : "2011-09-15 15:45:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114335142398541825",
  "geo" : { },
  "id_str" : "114336279705026560",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe You could say the same for 7 and 8. Ended badly. I view the end as S6. First 3 seasons were epic though.",
  "id" : 114336279705026560,
  "in_reply_to_status_id" : 114335142398541825,
  "created_at" : "2011-09-15 13:54:28 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114333542569361408",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Dear Baking Goddess... Just had a tea cake of yours. You are awesome!!!! :D Regards, Stephen",
  "id" : 114333542569361408,
  "created_at" : "2011-09-15 13:43:35 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114309042142326784",
  "text" : "Unread Gmail count: 370... I will get to them this weekend - bound to be some email in there that requires a reply...",
  "id" : 114309042142326784,
  "created_at" : "2011-09-15 12:06:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 1, 11 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114308888676925440",
  "text" : "\u201C@carisenda: What ruined Flickr? The Yahoo! login they added.\u201D He speaks the truth here.",
  "id" : 114308888676925440,
  "created_at" : "2011-09-15 12:05:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114305129624252416",
  "geo" : { },
  "id_str" : "114308831152046080",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop leg is better now - was a bit nasty and manky there for a few weeks :) Just need to be careful. Tell C he is a c*nt please :D",
  "id" : 114308831152046080,
  "in_reply_to_status_id" : 114305129624252416,
  "created_at" : "2011-09-15 12:05:23 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114303060435673088",
  "geo" : { },
  "id_str" : "114303465227952128",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop nerd :) How's tricks anyway?",
  "id" : 114303465227952128,
  "in_reply_to_status_id" : 114303060435673088,
  "created_at" : "2011-09-15 11:44:04 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114302855501979648",
  "geo" : { },
  "id_str" : "114302957851389952",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop knob ;)",
  "id" : 114302957851389952,
  "in_reply_to_status_id" : 114302855501979648,
  "created_at" : "2011-09-15 11:42:03 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114302677038542848",
  "text" : "My desk is starting to turn me.",
  "id" : 114302677038542848,
  "created_at" : "2011-09-15 11:40:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Crawford",
      "screen_name" : "Kitty_Crawford",
      "indices" : [ 0, 15 ],
      "id_str" : "21756710",
      "id" : 21756710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114297158831833088",
  "geo" : { },
  "id_str" : "114299297952047104",
  "in_reply_to_user_id" : 21756710,
  "text" : "@Kitty_Crawford ahhhh!!! pain! I get them to go through my hand! That sounds painful.. Hope you are okay.",
  "id" : 114299297952047104,
  "in_reply_to_status_id" : 114297158831833088,
  "created_at" : "2011-09-15 11:27:30 +0000",
  "in_reply_to_screen_name" : "Kitty_Crawford",
  "in_reply_to_user_id_str" : "21756710",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114236067472871424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59335086, -6.2127271433 ]
  },
  "id_str" : "114238548068155392",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you know the things to say to get a Presbie interested. :)",
  "id" : 114238548068155392,
  "in_reply_to_status_id" : 114236067472871424,
  "created_at" : "2011-09-15 07:26:06 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114118719696941057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.61040496, -6.20637792 ]
  },
  "id_str" : "114123139453165569",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne hippie :)",
  "id" : 114123139453165569,
  "in_reply_to_status_id" : 114118719696941057,
  "created_at" : "2011-09-14 23:47:31 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114021442089259008",
  "text" : "Hello, steviemccullough!\n\nYou have been challenged to a chess game by srushe\n\nIts so on!!!! After 11.5 years of beatings it is now my time!",
  "id" : 114021442089259008,
  "created_at" : "2011-09-14 17:03:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 111 ],
      "url" : "http:\/\/t.co\/ArguYkh",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=27RVJJfny4I",
      "display_url" : "youtube.com\/watch?v=27RVJJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "113980254883815425",
  "text" : "George - leave well enough alone. STOP FUCKING WITH MY CHILDHOOD - THE ORIGINALS WERE FINE! http:\/\/t.co\/ArguYkh",
  "id" : 113980254883815425,
  "created_at" : "2011-09-14 14:19:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113950826057302016",
  "in_reply_to_user_id" : 19477583,
  "text" : "@susannar100 very unfair that you were on tv this morning. I thought it was Friday until about 10mins ago!",
  "id" : 113950826057302016,
  "created_at" : "2011-09-14 12:22:48 +0000",
  "in_reply_to_screen_name" : "susannareid100",
  "in_reply_to_user_id_str" : "19477583",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 75, 89 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http:\/\/t.co\/oW4XqRd",
      "expanded_url" : "http:\/\/yfrog.com\/18igalj",
      "display_url" : "yfrog.com\/18igalj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.4628609543, -6.0829598171 ]
  },
  "id_str" : "113916018438569984",
  "text" : "You get her back again when you stop talking about the foopin butler!! \/cc @jenporterhall  http:\/\/t.co\/oW4XqRd",
  "id" : 113916018438569984,
  "created_at" : "2011-09-14 10:04:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http:\/\/t.co\/lrOOzbU",
      "expanded_url" : "http:\/\/yfrog.com\/klxl0qyj",
      "display_url" : "yfrog.com\/klxl0qyj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.4629298875, -6.082873905 ]
  },
  "id_str" : "113914573500841984",
  "text" : "Niall - gotta love his honesty.. This goes with his new briefcase and coffee mug.  http:\/\/t.co\/lrOOzbU",
  "id" : 113914573500841984,
  "created_at" : "2011-09-14 09:58:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 10, 20 ],
      "id_str" : "7311162",
      "id" : 7311162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113713901115424768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59331792, -6.21240429 ]
  },
  "id_str" : "113714798558064640",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq @mharrigan possibly :) I don't do proportional responses though....",
  "id" : 113714798558064640,
  "in_reply_to_status_id" : 113713901115424768,
  "created_at" : "2011-09-13 20:44:55 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 10, 20 ],
      "id_str" : "7311162",
      "id" : 7311162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113713033594945536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933275929, -6.2123732414 ]
  },
  "id_str" : "113713448206090240",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq @mharrigan just thought it was a random text to get. Idiot. I loathe your existence",
  "id" : 113713448206090240,
  "in_reply_to_status_id" : 113713033594945536,
  "created_at" : "2011-09-13 20:39:33 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 0, 10 ],
      "id_str" : "7311162",
      "id" : 7311162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113710927832039424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933275929, -6.2123732414 ]
  },
  "id_str" : "113712251915083776",
  "in_reply_to_user_id" : 7311162,
  "text" : "@mharrigan looks like it.",
  "id" : 113712251915083776,
  "in_reply_to_status_id" : 113710927832039424,
  "created_at" : "2011-09-13 20:34:48 +0000",
  "in_reply_to_screen_name" : "mharrigan",
  "in_reply_to_user_id_str" : "7311162",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http:\/\/t.co\/qiMfAOe",
      "expanded_url" : "http:\/\/yfrog.com\/nx3ummcj",
      "display_url" : "yfrog.com\/nx3ummcj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933522933, -6.21274592 ]
  },
  "id_str" : "113706412839931904",
  "text" : "Why I want to live like my brother..  http:\/\/t.co\/qiMfAOe",
  "id" : 113706412839931904,
  "created_at" : "2011-09-13 20:11:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.57932871, -5.96965014 ]
  },
  "id_str" : "113506687926808576",
  "text" : "Yeah.... Dont think I will be missing another session again by sleeping in. I was sick almost three times. Endorphins where are ya????",
  "id" : 113506687926808576,
  "created_at" : "2011-09-13 06:57:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 18, 30 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113363963651174400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.61286157, -6.20957821 ]
  },
  "id_str" : "113370164145299457",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe @stimpled0rf donkey and the custard were separate incidents. But yes.. Same folder :)",
  "id" : 113370164145299457,
  "in_reply_to_status_id" : 113363963651174400,
  "created_at" : "2011-09-12 21:55:28 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113348383938326528",
  "text" : "So when you change the network group on a windows machine (even in windows7) you still need to reboot the fucking thing. FAIL!",
  "id" : 113348383938326528,
  "created_at" : "2011-09-12 20:28:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 10, 22 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113339749988700160",
  "geo" : { },
  "id_str" : "113340067547844608",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq @ryancunning seriously do you just sit around on twitter waiting to insult me? Go fuck yourself, cuntmuscle!",
  "id" : 113340067547844608,
  "in_reply_to_status_id" : 113339749988700160,
  "created_at" : "2011-09-12 19:55:52 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 114, 121 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 126, 138 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113339119236694016",
  "text" : "Now to freak him the fuck out and make him cry!!! \/me opens up Photo Library and goes to the one marked \"S&M with @srushe and @stimpled0rf\"",
  "id" : 113339119236694016,
  "created_at" : "2011-09-12 19:52:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 19, 31 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113338925858299906",
  "text" : "Trying to help out @ryancunning on his home machine.. He ends up being able to see my desktop.. For all I know he is watching me type this.",
  "id" : 113338925858299906,
  "created_at" : "2011-09-12 19:51:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113314259965976577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933472325, -6.212646315 ]
  },
  "id_str" : "113315399843590144",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf you can have it back tomorrow!",
  "id" : 113315399843590144,
  "in_reply_to_status_id" : 113314259965976577,
  "created_at" : "2011-09-12 18:17:51 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113298969504915456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59336193, -6.21274604 ]
  },
  "id_str" : "113315277671907329",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll doing great :)",
  "id" : 113315277671907329,
  "in_reply_to_status_id" : 113298969504915456,
  "created_at" : "2011-09-12 18:17:22 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113220271154016258",
  "geo" : { },
  "id_str" : "113221832034893824",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues your husband freaked me out earlier!!! Tell him not to do that again.. Thanks :D",
  "id" : 113221832034893824,
  "in_reply_to_status_id" : 113220271154016258,
  "created_at" : "2011-09-12 12:06:02 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 11, 23 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113161512012615680",
  "text" : "Don't tell @stimpled0rf something in confidence. He'll just blap it out without meaning. Fuckin idiot :)",
  "id" : 113161512012615680,
  "created_at" : "2011-09-12 08:06:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ari Gold",
      "screen_name" : "AriGold",
      "indices" : [ 98, 106 ],
      "id_str" : "17596607",
      "id" : 17596607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113158261905166336",
  "text" : "Last ever episode of Entourage tonight. Have to say am glad it is finishing. 7 seasons is enough. @Arigold is am awesome character.",
  "id" : 113158261905166336,
  "created_at" : "2011-09-12 07:53:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113134229424050178",
  "geo" : { },
  "id_str" : "113155080391376896",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne wrong!",
  "id" : 113155080391376896,
  "in_reply_to_status_id" : 113134229424050178,
  "created_at" : "2011-09-12 07:40:48 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112612916649406464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933523875, -6.2125916275 ]
  },
  "id_str" : "112617565511098369",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll congrats :) :) :)",
  "id" : 112617565511098369,
  "in_reply_to_status_id" : 112612916649406464,
  "created_at" : "2011-09-10 20:04:54 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112597374483963905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593349536, -6.21253962 ]
  },
  "id_str" : "112601245939793921",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit it's a date!",
  "id" : 112601245939793921,
  "in_reply_to_status_id" : 112597374483963905,
  "created_at" : "2011-09-10 19:00:03 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/9Jwm3EY",
      "expanded_url" : "http:\/\/yfrog.com\/h34ozqhj",
      "display_url" : "yfrog.com\/h34ozqhj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59336799, -6.21278539 ]
  },
  "id_str" : "112577461493051393",
  "text" : "Bought a new sofa. Will be eleven weeks before it's ready to be delivered! Reclining goodness!!  http:\/\/t.co\/9Jwm3EY",
  "id" : 112577461493051393,
  "created_at" : "2011-09-10 17:25:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112544292333043712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59336799, -6.21278539 ]
  },
  "id_str" : "112577111608401920",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne looking great G!!",
  "id" : 112577111608401920,
  "in_reply_to_status_id" : 112544292333043712,
  "created_at" : "2011-09-10 17:24:09 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112552989922820097",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59336799, -6.21278539 ]
  },
  "id_str" : "112576594811432960",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne can't tomorrow now... But will be there next time with bells on :)",
  "id" : 112576594811432960,
  "in_reply_to_status_id" : 112552989922820097,
  "created_at" : "2011-09-10 17:22:06 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112523045494718464",
  "text" : "Going into town to buy a sofa...... Gotta a feeling I am gonna end up in The Spaniard later though. Dunno who these two things add up.",
  "id" : 112523045494718464,
  "created_at" : "2011-09-10 13:49:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112464563533914112",
  "geo" : { },
  "id_str" : "112468354404585472",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @niall_adams Lets do a haka!!!!",
  "id" : 112468354404585472,
  "in_reply_to_status_id" : 112464563533914112,
  "created_at" : "2011-09-10 10:11:59 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112450253038428160",
  "geo" : { },
  "id_str" : "112468225832386560",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit He is not - he didn't know if it was on or not so is helping his brother do stuffs now. But I shall be there next time :)",
  "id" : 112468225832386560,
  "in_reply_to_status_id" : 112450253038428160,
  "created_at" : "2011-09-10 10:11:29 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112289357179789312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.6162275, -6.21124118 ]
  },
  "id_str" : "112289905014611968",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall quote from the film :)",
  "id" : 112289905014611968,
  "in_reply_to_status_id" : 112289357179789312,
  "created_at" : "2011-09-09 22:22:54 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 1, 10 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 45, 58 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933497717, -6.2125471583 ]
  },
  "id_str" : "112287395491233792",
  "text" : "\u201C@kirkcoyb: Social network.  Good show.\u201D See @RickyHassard You are wrong!",
  "id" : 112287395491233792,
  "created_at" : "2011-09-09 22:12:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112285191908753408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933497717, -6.2125471583 ]
  },
  "id_str" : "112287218059579392",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall it's great! \"It's running out of me like hot lava!\"",
  "id" : 112287218059579392,
  "in_reply_to_status_id" : 112285191908753408,
  "created_at" : "2011-09-09 22:12:13 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 10, 23 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112277537903747073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933497717, -6.2125471583 ]
  },
  "id_str" : "112287050153201664",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq @rickyhassard nope. Ricky is.. Chris is just tight :)",
  "id" : 112287050153201664,
  "in_reply_to_status_id" : 112277537903747073,
  "created_at" : "2011-09-09 22:11:33 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112275244944855040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593323346, -6.21240209 ]
  },
  "id_str" : "112277456404234241",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall it's good.I like the girl that talks about fight club.",
  "id" : 112277456404234241,
  "in_reply_to_status_id" : 112275244944855040,
  "created_at" : "2011-09-09 21:33:26 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112275506979807232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593323346, -6.21240209 ]
  },
  "id_str" : "112277048252317697",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard you are the wrongest person ever!!!",
  "id" : 112277048252317697,
  "in_reply_to_status_id" : 112275506979807232,
  "created_at" : "2011-09-09 21:31:48 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112269748166868992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933542225, -6.212712745 ]
  },
  "id_str" : "112273132324265984",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe am actually really enjoying Bridesmaids!",
  "id" : 112273132324265984,
  "in_reply_to_status_id" : 112269748166868992,
  "created_at" : "2011-09-09 21:16:15 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112264461850640384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593280334, -6.212391862 ]
  },
  "id_str" : "112267952845357056",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe which one?",
  "id" : 112267952845357056,
  "in_reply_to_status_id" : 112264461850640384,
  "created_at" : "2011-09-09 20:55:40 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112266277707460608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593280334, -6.212391862 ]
  },
  "id_str" : "112267827473428480",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq not centos! You never learn!",
  "id" : 112267827473428480,
  "in_reply_to_status_id" : 112266277707460608,
  "created_at" : "2011-09-09 20:55:10 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593280334, -6.212391862 ]
  },
  "id_str" : "112258156125618178",
  "text" : "Oh on unrelated news newzbin is back up again.",
  "id" : 112258156125618178,
  "created_at" : "2011-09-09 20:16:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.6162275, -6.21124118 ]
  },
  "id_str" : "112258003637501952",
  "text" : "I am watching Bridesmaids.... This is not my choice!!!!",
  "id" : 112258003637501952,
  "created_at" : "2011-09-09 20:16:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newzbin",
      "screen_name" : "Newzbin",
      "indices" : [ 0, 8 ],
      "id_str" : "196506793",
      "id" : 196506793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112246100739637248",
  "in_reply_to_user_id" : 196506793,
  "text" : "@Newzbin Have BT finally blocked you - I can't get onto the site. If I try a server I have in California it works fine though....",
  "id" : 112246100739637248,
  "created_at" : "2011-09-09 19:28:50 +0000",
  "in_reply_to_screen_name" : "Newzbin",
  "in_reply_to_user_id_str" : "196506793",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 50, 58 ],
      "id_str" : "79820731",
      "id" : 79820731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933251717, -6.21261006 ]
  },
  "id_str" : "112216581391646720",
  "text" : "Thinking that I should write an ethics manual for @tascomi pub time on a Friday.",
  "id" : 112216581391646720,
  "created_at" : "2011-09-09 17:31:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 3, 12 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckityfuck",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112216339657129984",
  "text" : "RT @alvynmcq: fuck sake, cough fuck off, cold fuck off, fuck off fuck off fuck off. #fuckityfuck",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fuckityfuck",
        "indices" : [ 70, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112202264411766785",
    "text" : "fuck sake, cough fuck off, cold fuck off, fuck off fuck off fuck off. #fuckityfuck",
    "id" : 112202264411766785,
    "created_at" : "2011-09-09 16:34:39 +0000",
    "user" : {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "protected" : false,
      "id_str" : "16155145",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2054100540\/535376_10150637481600213_561550212_9624784_1859481959_n_normal.jpg",
      "id" : 16155145,
      "verified" : false
    }
  },
  "id" : 112216339657129984,
  "created_at" : "2011-09-09 17:30:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Dugan",
      "screen_name" : "adriandugan",
      "indices" : [ 12, 24 ],
      "id_str" : "69403865",
      "id" : 69403865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112158475211112448",
  "text" : "Congrats to @adriandugan on his new baby boy Jacob!",
  "id" : 112158475211112448,
  "created_at" : "2011-09-09 13:40:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112122705838485504",
  "text" : "Also a random fact.. My left arm wont stop shaking.... Kinda weird...",
  "id" : 112122705838485504,
  "created_at" : "2011-09-09 11:18:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Crawford",
      "screen_name" : "Kitty_Crawford",
      "indices" : [ 13, 28 ],
      "id_str" : "21756710",
      "id" : 21756710
    }, {
      "name" : "Annette McDonagh",
      "screen_name" : "AnnetteMcDonagh",
      "indices" : [ 62, 78 ],
      "id_str" : "1164404882",
      "id" : 1164404882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 7, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112118902976299008",
  "text" : "Oh yes #ff - @Kitty_Crawford for the office space comment and @annettemcdonagh for the awesome choco cake she made!",
  "id" : 112118902976299008,
  "created_at" : "2011-09-09 11:03:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112114429159669760",
  "geo" : { },
  "id_str" : "112115108263628800",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin Maybe its lack of sleep... but that made me laugh... I am awanker! Here that works.",
  "id" : 112115108263628800,
  "in_reply_to_status_id" : 112114429159669760,
  "created_at" : "2011-09-09 10:48:19 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112107433459060736",
  "geo" : { },
  "id_str" : "112107792428564480",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf well its past 11 - so you better be happy or you know what happens :)",
  "id" : 112107792428564480,
  "in_reply_to_status_id" : 112107433459060736,
  "created_at" : "2011-09-09 10:19:15 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112099071916912641",
  "text" : "Pasty McGlone and Alasdair McDonnell running for the SDLP leadership it seems. Atwood get your ass in gear and run!",
  "id" : 112099071916912641,
  "created_at" : "2011-09-09 09:44:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 18, 30 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112090848094724096",
  "text" : "Tried to cheer up @stimpled0rf there - he is having none of it.",
  "id" : 112090848094724096,
  "created_at" : "2011-09-09 09:11:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112043555329024001",
  "text" : "Shit, arse and fuck! I slept in... Got a text saying something like \"You are dead. You will pay for this later\". Tuesday will be fun!",
  "id" : 112043555329024001,
  "created_at" : "2011-09-09 06:03:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 24, 36 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111827941721260032",
  "text" : "I am dead on my feet... @stimpled0rf you heading soon?",
  "id" : 111827941721260032,
  "created_at" : "2011-09-08 15:47:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111826740170600448",
  "geo" : { },
  "id_str" : "111827764868419584",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne class... Now paint yourself green :)",
  "id" : 111827764868419584,
  "in_reply_to_status_id" : 111826740170600448,
  "created_at" : "2011-09-08 15:46:31 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bttf",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111819677122052100",
  "geo" : { },
  "id_str" : "111821224996376576",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard Roads? Where we're going, we don't need roads. #bttf",
  "id" : 111821224996376576,
  "in_reply_to_status_id" : 111819677122052100,
  "created_at" : "2011-09-08 15:20:32 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 0, 14 ],
      "id_str" : "49953918",
      "id" : 49953918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111764365916635136",
  "geo" : { },
  "id_str" : "111764562059083776",
  "in_reply_to_user_id" : 49953918,
  "text" : "@RickTheJackal its fucking awful... Turns me. Need something to power me through the next 4 hours or whatever it is - scared to look!",
  "id" : 111764562059083776,
  "in_reply_to_status_id" : 111764365916635136,
  "created_at" : "2011-09-08 11:35:22 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 79, 88 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111764231778607104",
  "geo" : { },
  "id_str" : "111764419050090496",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb I love your ASS! I said it tastes of ASS - I never said it tasted of @kirkcoyb ASS :)",
  "id" : 111764419050090496,
  "in_reply_to_status_id" : 111764231778607104,
  "created_at" : "2011-09-08 11:34:48 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111764087796547584",
  "text" : "First time of RedBull in years to keep me awake.. It tastes like ass... I dunno how I used to drink this with vodka! It really tastes of ass",
  "id" : 111764087796547584,
  "created_at" : "2011-09-08 11:33:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111734376303296512",
  "geo" : { },
  "id_str" : "111734913849503744",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne mightly impressive. If you are decent you should take a pic to proof to the twitter verse.",
  "id" : 111734913849503744,
  "in_reply_to_status_id" : 111734376303296512,
  "created_at" : "2011-09-08 09:37:34 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111721474607427584",
  "text" : "Worked like a mad thing yesterday and pretty late last night - am now finding it hard to get into the groove!",
  "id" : 111721474607427584,
  "created_at" : "2011-09-08 08:44:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111718107780874241",
  "geo" : { },
  "id_str" : "111719147125215232",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe You so far missed on two cups of tea...... Just letting you know what you are missing.. That and watching me walk away ;)",
  "id" : 111719147125215232,
  "in_reply_to_status_id" : 111718107780874241,
  "created_at" : "2011-09-08 08:34:54 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111708044739624960",
  "text" : "For all the ppl that have sent me an email in the last week - I will get back to you.. Just hectic at the mo.. :)",
  "id" : 111708044739624960,
  "created_at" : "2011-09-08 07:50:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette McDonagh",
      "screen_name" : "AnnetteMcDonagh",
      "indices" : [ 8, 24 ],
      "id_str" : "1164404882",
      "id" : 1164404882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111705555567001600",
  "text" : "I think @annettemcdonagh has lost it this morning... Yup - she's away with it!!!",
  "id" : 111705555567001600,
  "created_at" : "2011-09-08 07:40:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http:\/\/t.co\/gCy4idq",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/health-14824310",
      "display_url" : "bbc.co.uk\/news\/health-14\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "111700889160527873",
  "text" : "Never knew that blood could be gay... http:\/\/t.co\/gCy4idq",
  "id" : 111700889160527873,
  "created_at" : "2011-09-08 07:22:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111554061836361728",
  "geo" : { },
  "id_str" : "111556958426902528",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I is cool as feck! Plain and simple! I aint a Trekkie either Barbie!!!",
  "id" : 111556958426902528,
  "in_reply_to_status_id" : 111554061836361728,
  "created_at" : "2011-09-07 21:50:26 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Vicky Beeching",
      "screen_name" : "vickybeeching",
      "indices" : [ 15, 29 ],
      "id_str" : "13115502",
      "id" : 13115502
    }, {
      "name" : "jena jones",
      "screen_name" : "JJones0",
      "indices" : [ 30, 38 ],
      "id_str" : "920471461",
      "id" : 920471461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111541561296289792",
  "geo" : { },
  "id_str" : "111547976253587456",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @vickybeeching @jjones0 I am not a geek Jenni!!!!!",
  "id" : 111547976253587456,
  "in_reply_to_status_id" : 111541561296289792,
  "created_at" : "2011-09-07 21:14:44 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 3, 16 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111529309658824705",
  "text" : "RT @RickyHassard: My daughters popup tent just popped up by itself while i was watching tv.  I think I've crapped myself",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111527833196707840",
    "text" : "My daughters popup tent just popped up by itself while i was watching tv.  I think I've crapped myself",
    "id" : 111527833196707840,
    "created_at" : "2011-09-07 19:54:42 +0000",
    "user" : {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "protected" : false,
      "id_str" : "5684272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1317084795\/Screen_shot_2011-04-19_at_13.00.12_normal.png",
      "id" : 5684272,
      "verified" : false
    }
  },
  "id" : 111529309658824705,
  "created_at" : "2011-09-07 20:00:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111486131656335360",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall shame on you!!!!!!!!! If your kids weren't here I would kick your ass!!!",
  "id" : 111486131656335360,
  "created_at" : "2011-09-07 17:08:59 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CakePHP",
      "screen_name" : "cakephp",
      "indices" : [ 18, 26 ],
      "id_str" : "8620662",
      "id" : 8620662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111177296018288640",
  "text" : "The fact that the @cakephp website takes ages to load is a bit worrying.",
  "id" : 111177296018288640,
  "created_at" : "2011-09-06 20:41:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111174650242924545",
  "geo" : { },
  "id_str" : "111174793776209920",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne I'll be up at around that time too - but being in the pool for 5:30.. You gotta slow down!! Picked a mountain yet? ;)",
  "id" : 111174793776209920,
  "in_reply_to_status_id" : 111174650242924545,
  "created_at" : "2011-09-06 20:31:51 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111170604610240512",
  "geo" : { },
  "id_str" : "111172686289436672",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne as in 5:30 you will be in the pool! Nutter!!!!!",
  "id" : 111172686289436672,
  "in_reply_to_status_id" : 111170604610240512,
  "created_at" : "2011-09-06 20:23:28 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111153537437806592",
  "geo" : { },
  "id_str" : "111156879908020224",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard end of what?",
  "id" : 111156879908020224,
  "in_reply_to_status_id" : 111153537437806592,
  "created_at" : "2011-09-06 19:20:40 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 15, 24 ],
      "id_str" : "20543444",
      "id" : 20543444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111133135261007872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59333157, -6.212114736 ]
  },
  "id_str" : "111133976378351616",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @herrwulf probably for the best....",
  "id" : 111133976378351616,
  "in_reply_to_status_id" : 111133135261007872,
  "created_at" : "2011-09-06 17:49:39 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111129931282513921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59333157, -6.212114736 ]
  },
  "id_str" : "111133755661492224",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I am at home. Now over at the parents.. Getting my tea made by my Mum :)",
  "id" : 111133755661492224,
  "in_reply_to_status_id" : 111129931282513921,
  "created_at" : "2011-09-06 17:48:46 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111123481101475840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59334367, -6.2124964167 ]
  },
  "id_str" : "111126916626522112",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore was thinking more MS Frontpage. Wonder how they can afford those prices though.",
  "id" : 111126916626522112,
  "in_reply_to_status_id" : 111123481101475840,
  "created_at" : "2011-09-06 17:21:36 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Crawford",
      "screen_name" : "Kitty_Crawford",
      "indices" : [ 0, 15 ],
      "id_str" : "21756710",
      "id" : 21756710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111111923399004161",
  "geo" : { },
  "id_str" : "111112297589645312",
  "in_reply_to_user_id" : 21756710,
  "text" : "@Kitty_Crawford \"I could set the building on fire\"... I'll watch it on Sunday night - just to clear the blues :)",
  "id" : 111112297589645312,
  "in_reply_to_status_id" : 111111923399004161,
  "created_at" : "2011-09-06 16:23:30 +0000",
  "in_reply_to_screen_name" : "Kitty_Crawford",
  "in_reply_to_user_id_str" : "21756710",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Crawford",
      "screen_name" : "Kitty_Crawford",
      "indices" : [ 0, 15 ],
      "id_str" : "21756710",
      "id" : 21756710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111111571958267904",
  "geo" : { },
  "id_str" : "111111801948737538",
  "in_reply_to_user_id" : 21756710,
  "text" : "@Kitty_Crawford you have to do the voice. Its the law!",
  "id" : 111111801948737538,
  "in_reply_to_status_id" : 111111571958267904,
  "created_at" : "2011-09-06 16:21:32 +0000",
  "in_reply_to_screen_name" : "Kitty_Crawford",
  "in_reply_to_user_id_str" : "21756710",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111090271143473153",
  "geo" : { },
  "id_str" : "111111649171218432",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore fuck sake C.. Sell up now.. Those boys are gonna fucking destroy you :) 599 for an e-site.. i would like to see their work!",
  "id" : 111111649171218432,
  "in_reply_to_status_id" : 111090271143473153,
  "created_at" : "2011-09-06 16:20:56 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Crawford",
      "screen_name" : "Kitty_Crawford",
      "indices" : [ 0, 15 ],
      "id_str" : "21756710",
      "id" : 21756710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111076107545092096",
  "geo" : { },
  "id_str" : "111111302876905472",
  "in_reply_to_user_id" : 21756710,
  "text" : "@Kitty_Crawford I *heart* that you get the office space joke.. I stole one once and only a few got the joke. Not appreciated in our time!",
  "id" : 111111302876905472,
  "in_reply_to_status_id" : 111076107545092096,
  "created_at" : "2011-09-06 16:19:33 +0000",
  "in_reply_to_screen_name" : "Kitty_Crawford",
  "in_reply_to_user_id_str" : "21756710",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 54, 66 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111028662933000192",
  "text" : "I am being tortured by hourly updates on my doings by @niall_adams. It is starting to get to me to be fair :)",
  "id" : 111028662933000192,
  "created_at" : "2011-09-06 10:51:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette McDonagh",
      "screen_name" : "AnnetteMcDonagh",
      "indices" : [ 96, 112 ],
      "id_str" : "1164404882",
      "id" : 1164404882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111003243651416064",
  "text" : "The McDonagh has joined the twitterverse... She makes awesome cakes.. Which makes her awesome - @annettemcdonagh",
  "id" : 111003243651416064,
  "created_at" : "2011-09-06 09:10:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110995183113478144",
  "geo" : { },
  "id_str" : "111002128356622336",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne if you are up for it then aye - as long as it aint raining :)",
  "id" : 111002128356622336,
  "in_reply_to_status_id" : 110995183113478144,
  "created_at" : "2011-09-06 09:05:44 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110977963104800768",
  "text" : "\"I wanna be like you\" coming onto the iPhone from the car to the office - puts you in good form.. You know - until you get into the office!",
  "id" : 110977963104800768,
  "created_at" : "2011-09-06 07:29:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110961008935317504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.57759475, -5.96194243 ]
  },
  "id_str" : "110963545612623872",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Nooooo rain is crap!! Just finished gym session. Get weighed on Friday.... Wonder how much I've lost... Hmmm :)",
  "id" : 110963545612623872,
  "in_reply_to_status_id" : 110961008935317504,
  "created_at" : "2011-09-06 06:32:25 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110819156273795072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593358178, -6.21262017 ]
  },
  "id_str" : "110819264470073345",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop name your terms.....",
  "id" : 110819264470073345,
  "in_reply_to_status_id" : 110819156273795072,
  "created_at" : "2011-09-05 20:59:06 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110818478004518912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593358178, -6.21262017 ]
  },
  "id_str" : "110818696573882369",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop I ain't a green!!! Well I am if you are a lesbian... Here is hoping =)",
  "id" : 110818696573882369,
  "in_reply_to_status_id" : 110818478004518912,
  "created_at" : "2011-09-05 20:56:50 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110817670332547073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933578567, -6.2125322667 ]
  },
  "id_str" : "110817833839099904",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop conserving money sexy lady ;)",
  "id" : 110817833839099904,
  "in_reply_to_status_id" : 110817670332547073,
  "created_at" : "2011-09-05 20:53:25 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110812237005991936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933578567, -6.2125322667 ]
  },
  "id_str" : "110816577498251264",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop how so?",
  "id" : 110816577498251264,
  "in_reply_to_status_id" : 110812237005991936,
  "created_at" : "2011-09-05 20:48:25 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933578567, -6.2125322667 ]
  },
  "id_str" : "110810936910168064",
  "text" : "The Presbie in me won't allow me to put the heating on. Not in Sept. Especially not this close to Sept!",
  "id" : 110810936910168064,
  "created_at" : "2011-09-05 20:26:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110785433692143616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933109775, -6.21274462 ]
  },
  "id_str" : "110798615332667392",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @twitinsin what is on????",
  "id" : 110798615332667392,
  "in_reply_to_status_id" : 110785433692143616,
  "created_at" : "2011-09-05 19:37:03 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933109775, -6.21274462 ]
  },
  "id_str" : "110798272267943936",
  "text" : "@twitinsin that jquery hack ealier today makes me both happy and sad...",
  "id" : 110798272267943936,
  "created_at" : "2011-09-05 19:35:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 49, 61 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110744187615453186",
  "text" : "FFS.. I hate it when ppl get into my twittter... @niall_adams go fuck yourself! :D",
  "id" : 110744187615453186,
  "created_at" : "2011-09-05 16:00:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 8, 14 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.4629033333, -6.08281131 ]
  },
  "id_str" : "110742018468233216",
  "text" : "16:51 - @swmcc off to have a shit.",
  "id" : 110742018468233216,
  "created_at" : "2011-09-05 15:52:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 6, 12 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 39, 51 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110729262348242946",
  "text" : "16:01 @swmcc is thinking about kicking @niall_adams in the nuts.",
  "id" : 110729262348242946,
  "created_at" : "2011-09-05 15:01:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110721026656186368",
  "geo" : { },
  "id_str" : "110723723971149824",
  "in_reply_to_user_id" : 210949996,
  "text" : "@Lisami75 I would have guffed her out of the car and made her walk home!",
  "id" : 110723723971149824,
  "in_reply_to_status_id" : 110721026656186368,
  "created_at" : "2011-09-05 14:39:27 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tabs",
      "indices" : [ 4, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110703450135855104",
  "text" : "$( \"#tabs\" ).tabs( \u007B selected: \u007B$tab\u007D \u007D);",
  "id" : 110703450135855104,
  "created_at" : "2011-09-05 13:18:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110662712941494272",
  "geo" : { },
  "id_str" : "110665000162566144",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin no, not at all :) I just know a few ppl that work from home and it drives them nuts. When I have to WFH it drives me nuts too.",
  "id" : 110665000162566144,
  "in_reply_to_status_id" : 110662712941494272,
  "created_at" : "2011-09-05 10:46:06 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110654922323795969",
  "geo" : { },
  "id_str" : "110660491810062336",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin what is it like working from home? Do you not get cabin fever?",
  "id" : 110660491810062336,
  "in_reply_to_status_id" : 110654922323795969,
  "created_at" : "2011-09-05 10:28:11 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110627800393846784",
  "geo" : { },
  "id_str" : "110627911563882496",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard am only joking ya ffs :) Much love xx",
  "id" : 110627911563882496,
  "in_reply_to_status_id" : 110627800393846784,
  "created_at" : "2011-09-05 08:18:44 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110626991794962432",
  "geo" : { },
  "id_str" : "110627288940417024",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard better not or I will knock the cunt out of ye!",
  "id" : 110627288940417024,
  "in_reply_to_status_id" : 110626991794962432,
  "created_at" : "2011-09-05 08:16:15 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110625353583693824",
  "text" : "Hate it when my VM server reboots without the hosting company telling me before hand. All screen sessions gone. Pain in the ass esp on a Mon",
  "id" : 110625353583693824,
  "created_at" : "2011-09-05 08:08:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110611898990473217",
  "geo" : { },
  "id_str" : "110624940776112128",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit interesting so far - no doubt that will end :)",
  "id" : 110624940776112128,
  "in_reply_to_status_id" : 110611898990473217,
  "created_at" : "2011-09-05 08:06:55 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 15, 24 ],
      "id_str" : "20543444",
      "id" : 20543444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110433574599131136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.61445057, -6.20433795 ]
  },
  "id_str" : "110446393260380160",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @herrwulf Awesome show! I can sing the 50 states song :)",
  "id" : 110446393260380160,
  "in_reply_to_status_id" : 110433574599131136,
  "created_at" : "2011-09-04 20:17:26 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110441502932598784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933347883, -6.212231075 ]
  },
  "id_str" : "110442864550481920",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I like my job. I just hate working. Once I get into it come 9:30 I am fine. Just like to moan :)",
  "id" : 110442864550481920,
  "in_reply_to_status_id" : 110441502932598784,
  "created_at" : "2011-09-04 20:03:25 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59331646, -6.212129885 ]
  },
  "id_str" : "110434449283497984",
  "text" : "I need a new job. Cowboy, Gardner or Boxing coach... Not a programmer... Fuck I loathe Sundays!",
  "id" : 110434449283497984,
  "created_at" : "2011-09-04 19:29:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110420315179462656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933304714, -6.2125578814 ]
  },
  "id_str" : "110422870919876609",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard awwwwww you mean there was were no pics of you and me!!!! Hmmmphhhh!!!!!",
  "id" : 110422870919876609,
  "in_reply_to_status_id" : 110420315179462656,
  "created_at" : "2011-09-04 18:43:58 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933304714, -6.2125578814 ]
  },
  "id_str" : "110422397047418880",
  "text" : "I hate Sunday nights.... I really really do....",
  "id" : 110422397047418880,
  "created_at" : "2011-09-04 18:42:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 3, 14 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110069863208333312",
  "text" : "RT @johngirvin: To wrap up a perfect day, while I was outside (still) talking about FUCKING bricks, a bird shit on me. Perfect. \n\n*explodes*",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "110060171648188416",
    "text" : "To wrap up a perfect day, while I was outside (still) talking about FUCKING bricks, a bird shit on me. Perfect. \n\n*explodes*",
    "id" : 110060171648188416,
    "created_at" : "2011-09-03 18:42:44 +0000",
    "user" : {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "protected" : false,
      "id_str" : "14604982",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2314099862\/alwns3aah07mbpojkbms_normal.jpeg",
      "id" : 14604982,
      "verified" : false
    }
  },
  "id" : 110069863208333312,
  "created_at" : "2011-09-03 19:21:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109760753212456960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933400933, -6.2125765433 ]
  },
  "id_str" : "109761298614595584",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues score out of ten?",
  "id" : 109761298614595584,
  "in_reply_to_status_id" : 109760753212456960,
  "created_at" : "2011-09-02 22:55:07 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109742362695188481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593344814, -6.21260553 ]
  },
  "id_str" : "109755976533549056",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues come on.. Even I wouldn't go to see that..",
  "id" : 109755976533549056,
  "in_reply_to_status_id" : 109742362695188481,
  "created_at" : "2011-09-02 22:33:58 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/5YaQh37",
      "expanded_url" : "http:\/\/yfrog.com\/meb52vj",
      "display_url" : "yfrog.com\/meb52vj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933414067, -6.21268248 ]
  },
  "id_str" : "109718939059228672",
  "text" : "Random monkey film...  http:\/\/t.co\/5YaQh37",
  "id" : 109718939059228672,
  "created_at" : "2011-09-02 20:06:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109717003790594048",
  "text" : "1.4Gb down in 2:35 - awesome.... Of course its not a ripped copy of Rise of the Planet of the Apes. That would be illegal moral and wrong.",
  "id" : 109717003790594048,
  "created_at" : "2011-09-02 19:59:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.62090313, -6.21389096 ]
  },
  "id_str" : "109707486898036736",
  "text" : "All the stuff moved into the living room.. In a few weeks I'll be moving it out again for new sofa and chair.",
  "id" : 109707486898036736,
  "created_at" : "2011-09-02 19:21:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109687390112714752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59333171, -6.2123428133 ]
  },
  "id_str" : "109693093334360064",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit nah... You explained plants to me on out trek. Interesting like.. I am a nerd too :)",
  "id" : 109693093334360064,
  "in_reply_to_status_id" : 109687390112714752,
  "created_at" : "2011-09-02 18:24:06 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 26, 37 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109669291858731009",
  "geo" : { },
  "id_str" : "109683824002220033",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @niall_adams @alana_doll not really a twitter hack... Either that or buns - either way I am happy :)",
  "id" : 109683824002220033,
  "in_reply_to_status_id" : 109669291858731009,
  "created_at" : "2011-09-02 17:47:16 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 13, 24 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.50306648, -6.07580894 ]
  },
  "id_str" : "109664439216783360",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @Alana_Doll fancy a threesome?",
  "id" : 109664439216783360,
  "created_at" : "2011-09-02 16:30:14 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109626605126680576",
  "text" : "A friday afternoon meeting.. Also known as \"FUCK SAKE.. I HATE MEETINGS - EVEN MORE SO ON A FRIDAY AFTERNOON\"",
  "id" : 109626605126680576,
  "created_at" : "2011-09-02 13:59:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109612887017922561",
  "text" : "OH on \"Sometime, just sometimes, I wish I could settle my difference of opinion with clients via a duel\"",
  "id" : 109612887017922561,
  "created_at" : "2011-09-02 13:05:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109605453293563904",
  "geo" : { },
  "id_str" : "109605548491669505",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit I thought you two were cool.. Nerds...",
  "id" : 109605548491669505,
  "in_reply_to_status_id" : 109605453293563904,
  "created_at" : "2011-09-02 12:36:13 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109594209215975424",
  "geo" : { },
  "id_str" : "109598134379884544",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne They are coming next month to do the hall. If you haven't it sorted by then I'll let them know :)",
  "id" : 109598134379884544,
  "in_reply_to_status_id" : 109594209215975424,
  "created_at" : "2011-09-02 12:06:46 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 90, 103 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 69 ],
      "url" : "http:\/\/t.co\/hjttThY",
      "expanded_url" : "http:\/\/www.tascomi.com\/aboutus\/jobs",
      "display_url" : "tascomi.com\/aboutus\/jobs"
    } ]
  },
  "geo" : { },
  "id_str" : "109575403546480640",
  "text" : "If anyone wants the pleasure of working with me - http:\/\/t.co\/hjttThY - give it a go. And @RickyHassard doesn't smell that much.....",
  "id" : 109575403546480640,
  "created_at" : "2011-09-02 10:36:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109564409042571264",
  "text" : "Floor dudes done - all signed and measured up for next month.. Now back into work :)",
  "id" : 109564409042571264,
  "created_at" : "2011-09-02 09:52:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FML",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109545519201779712",
  "text" : "...but one of the floor dudes just shouted \"Oh Yeah\" at the top of his lungs and then the other two started saying it in unison... #FML",
  "id" : 109545519201779712,
  "created_at" : "2011-09-02 08:37:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109545361428844544",
  "text" : "I can't really go through my bug list at the mo due to workign via teamviewer - so updating documentation - which is just as important....",
  "id" : 109545361428844544,
  "created_at" : "2011-09-02 08:37:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109541495039733760",
  "text" : "Mysterious Girl - I kid you not!!!!!!!",
  "id" : 109541495039733760,
  "created_at" : "2011-09-02 08:21:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109540409868419072",
  "text" : "Iggy Pop - I am the passenger.... This stop being cute about 30mins ago!",
  "id" : 109540409868419072,
  "created_at" : "2011-09-02 08:17:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109538984820080640",
  "text" : "These floor dudes literally song along to every single song that comes on.. In the last 10mins I've gotten a Kylie song and Beat It by MJ!",
  "id" : 109538984820080640,
  "created_at" : "2011-09-02 08:11:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109530793541505024",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne  Back from first gym session this morning... Leg is stronger than I thought.. Hopefully be back up the mournes soon :)",
  "id" : 109530793541505024,
  "created_at" : "2011-09-02 07:39:10 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109529700954685440",
  "geo" : { },
  "id_str" : "109530540180381696",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne They r happy enough already. Telling them that there is a blonde lookin them to fix a dancing pole I dunno what it'll happen",
  "id" : 109530540180381696,
  "in_reply_to_status_id" : 109529700954685440,
  "created_at" : "2011-09-02 07:38:10 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109528780200091648",
  "geo" : { },
  "id_str" : "109529249731457024",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne They are the happiest bunch of workers I have ever seen....",
  "id" : 109529249731457024,
  "in_reply_to_status_id" : 109528780200091648,
  "created_at" : "2011-09-02 07:33:02 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109525843100962816",
  "text" : "Floor dudes are in now - singing along to Ride Along Sally at 8:05am on a Friday. Think my neighbours are gonna lynch me later!",
  "id" : 109525843100962816,
  "created_at" : "2011-09-02 07:19:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109414034859769856",
  "text" : "They were in the fuckin washing basket. That's 90mins I wont get back again At some point you just have to give up on urself. Its now time!",
  "id" : 109414034859769856,
  "created_at" : "2011-09-01 23:55:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109411846250962946",
  "text" : "I have also lost my car keys in the big move...... FUCK A DUCK....",
  "id" : 109411846250962946,
  "created_at" : "2011-09-01 23:46:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 1, 14 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 16, 22 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933351467, -6.2127178667 ]
  },
  "id_str" : "109385507259166721",
  "text" : "\u201C@RickyHassard: @swmcc FAIL\u201D Took him an hour! Quite frankly I am disappointed in you sir! Then again you have a life :)",
  "id" : 109385507259166721,
  "created_at" : "2011-09-01 22:01:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109369352373014529",
  "text" : "Ahh well suppose you can't be this good lookin and smart!!!",
  "id" : 109369352373014529,
  "created_at" : "2011-09-01 20:57:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109369155446251520",
  "text" : "If the VM was bridged it wouldn't be a problem at all... I could do some firewall jiggery poker and port forwarding. Cos its NAT though!!",
  "id" : 109369155446251520,
  "created_at" : "2011-09-01 20:56:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109368977100255232",
  "text" : "Teamviewer will come to the rescue I suppose... What a fucking dick.. A 2k MBP and I forget it! I am a fucking moron...",
  "id" : 109368977100255232,
  "created_at" : "2011-09-01 20:56:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109368713471471616",
  "text" : "And I just remembered I am working from home tomorrow morning and I left my fucking laptop in work.. FUCK. And my VM I develop on is NAT.",
  "id" : 109368713471471616,
  "created_at" : "2011-09-01 20:55:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109368529068883969",
  "text" : "Skirting boards lifted, tracks lifted.. Dusted& brushed, everything out... Floor to be laid tomorrow first thing, apparently :) Can't wait..",
  "id" : 109368529068883969,
  "created_at" : "2011-09-01 20:54:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 27, 40 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109281091130621952",
  "text" : "I wanted to rant there but @RickyHassard wouldn't play ball.. The man serves no purpose now. He's like the appendix - no use anymore!",
  "id" : 109281091130621952,
  "created_at" : "2011-09-01 15:06:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109207222290100225",
  "geo" : { },
  "id_str" : "109271210180886530",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne next two or three weeks and my leg should be up to it.. Its just healing now.. But start back at the gym tomorrow morning :)",
  "id" : 109271210180886530,
  "in_reply_to_status_id" : 109207222290100225,
  "created_at" : "2011-09-01 14:27:41 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109229927169142784",
  "text" : "Fan on the MPB started to go nuts there... Had a wee look with Activity Mon to see what was happening. M$ RD was taking 99% of CPU :(",
  "id" : 109229927169142784,
  "created_at" : "2011-09-01 11:43:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109224908294336512",
  "geo" : { },
  "id_str" : "109226594308075520",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin natural selection in work there.",
  "id" : 109226594308075520,
  "in_reply_to_status_id" : 109224908294336512,
  "created_at" : "2011-09-01 11:30:24 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109206172367728640",
  "text" : "Am starving marving... Got another hour to wait... *munch* *munch*",
  "id" : 109206172367728640,
  "created_at" : "2011-09-01 10:09:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109204327398260736",
  "geo" : { },
  "id_str" : "109205008863596544",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop not in the hevenings and weekhends. :)",
  "id" : 109205008863596544,
  "in_reply_to_status_id" : 109204327398260736,
  "created_at" : "2011-09-01 10:04:37 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109200657889771520",
  "geo" : { },
  "id_str" : "109203131971284992",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop I do! :)",
  "id" : 109203131971284992,
  "in_reply_to_status_id" : 109200657889771520,
  "created_at" : "2011-09-01 09:57:10 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109158099314679808",
  "geo" : { },
  "id_str" : "109189781531013121",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne need more updates from ya G!!! Gotta keep me motivated.. Makes me feel lazy when you do and then I do stuffs :D",
  "id" : 109189781531013121,
  "in_reply_to_status_id" : 109158099314679808,
  "created_at" : "2011-09-01 09:04:07 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]