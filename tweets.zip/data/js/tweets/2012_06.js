Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219198488758595584",
  "text" : "Round at me folks :)",
  "id" : 219198488758595584,
  "created_at" : "2012-06-30 22:39:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219173572172713987",
  "geo" : { },
  "id_str" : "219193845827633153",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard does what it says on the tin :)",
  "id" : 219193845827633153,
  "in_reply_to_status_id" : 219173572172713987,
  "created_at" : "2012-06-30 22:20:59 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219076153342824448",
  "geo" : { },
  "id_str" : "219081892346077184",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams yes. why yes I did :)",
  "id" : 219081892346077184,
  "in_reply_to_status_id" : 219076153342824448,
  "created_at" : "2012-06-30 14:56:08 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219070961415241728",
  "text" : "I just got soaked at Crumlin dump. There is so much wrongness in that sentence.",
  "id" : 219070961415241728,
  "created_at" : "2012-06-30 14:12:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 0, 6 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218170724161036288",
  "geo" : { },
  "id_str" : "218767372587245568",
  "in_reply_to_user_id" : 3840,
  "text" : "@Jason actually ignore me - that script is crap!!!! :( Sorry.. Am sure there is something out there though. Good luck.",
  "id" : 218767372587245568,
  "in_reply_to_status_id" : 218170724161036288,
  "created_at" : "2012-06-29 18:06:20 +0000",
  "in_reply_to_screen_name" : "Jason",
  "in_reply_to_user_id_str" : "3840",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 0, 6 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/LhNCnAOD",
      "expanded_url" : "http:\/\/www.justnaira.com\/2012\/01\/mass-unfollow-script-for-twitter.html",
      "display_url" : "justnaira.com\/2012\/01\/mass-u\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "218170724161036288",
  "geo" : { },
  "id_str" : "218767232547823616",
  "in_reply_to_user_id" : 3840,
  "text" : "@Jason Get someone you trust to look over this re: unfollow everyone - http:\/\/t.co\/LhNCnAOD",
  "id" : 218767232547823616,
  "in_reply_to_status_id" : 218170724161036288,
  "created_at" : "2012-06-29 18:05:47 +0000",
  "in_reply_to_screen_name" : "Jason",
  "in_reply_to_user_id_str" : "3840",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mikegettingamotivationtalkfromtheboss",
      "indices" : [ 26, 64 ]
    }, {
      "text" : "awesome",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218685110638223360",
  "text" : "OH: \"Grow a set of balls\" #mikegettingamotivationtalkfromtheboss #awesome",
  "id" : 218685110638223360,
  "created_at" : "2012-06-29 12:39:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/tWyw3xUl",
      "expanded_url" : "http:\/\/sethgodin.typepad.com\/seths_blog\/2012\/06\/do-we-have-to-pander.html?utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "sethgodin.typepad.com\/seths_blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218642698482094081",
  "text" : "*FISTPUMP* http:\/\/t.co\/tWyw3xUl",
  "id" : 218642698482094081,
  "created_at" : "2012-06-29 09:50:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218642050114011136",
  "text" : "Twitter help: installing redmine_backlogs and get this error: \"uninitialized constant BacklogsPrintableCards::Gravatar::GravatarHelper\"",
  "id" : 218642050114011136,
  "created_at" : "2012-06-29 09:48:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/218618947866599424\/photo\/1",
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/i8uGArqR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwiwxllCIAAiURG.jpg",
      "id_str" : "218618947874988032",
      "id" : 218618947874988032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwiwxllCIAAiURG.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/i8uGArqR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218618947866599424",
  "text" : "My \"don't even look at me\" headphones in work that I just procured. Should do the trick! http:\/\/t.co\/i8uGArqR",
  "id" : 218618947866599424,
  "created_at" : "2012-06-29 08:16:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/218615782886744064\/photo\/1",
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/uBV5Yy6M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Awit5XGCIAAuH5k.jpg",
      "id_str" : "218615782890938368",
      "id" : 218615782890938368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Awit5XGCIAAuH5k.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/uBV5Yy6M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218615782886744064",
  "text" : "Just a normal Friday morning http:\/\/t.co\/uBV5Yy6M",
  "id" : 218615782886744064,
  "created_at" : "2012-06-29 08:04:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218465910313336832",
  "geo" : { },
  "id_str" : "218466099455459329",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop it has got me thinking... now shhhhhhh!!!!! :D",
  "id" : 218466099455459329,
  "in_reply_to_status_id" : 218465910313336832,
  "created_at" : "2012-06-28 22:09:11 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/pQ3R0JUh",
      "expanded_url" : "http:\/\/lab.hakim.se\/reveal-js\/#\/",
      "display_url" : "lab.hakim.se\/reveal-js\/#\/"
    } ]
  },
  "geo" : { },
  "id_str" : "218464097589657600",
  "text" : "Need to find a practical application for this - http:\/\/t.co\/pQ3R0JUh",
  "id" : 218464097589657600,
  "created_at" : "2012-06-28 22:01:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218463612887511041",
  "text" : "I was also told I was a \"self contained person\" tonight... Guess I am a bit :) Right... fuck this... Tomorrow be Friday :D :D :D",
  "id" : 218463612887511041,
  "created_at" : "2012-06-28 21:59:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/XSViYRCb",
      "expanded_url" : "http:\/\/www.syncni.com\/news\/6689",
      "display_url" : "syncni.com\/news\/6689"
    } ]
  },
  "geo" : { },
  "id_str" : "218460114905079808",
  "text" : "Anyone that needs to be told about this at this late stage deserves to be out of fucking business.. http:\/\/t.co\/XSViYRCb ASSHOLES",
  "id" : 218460114905079808,
  "created_at" : "2012-06-28 21:45:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 67, 79 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218456507191275520",
  "text" : "OH: \"You do have hot friends\".... No, no I do not... Well there is @willemkokke... the rest - meh - ugly feckers the lot of you!",
  "id" : 218456507191275520,
  "created_at" : "2012-06-28 21:31:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 15, 28 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wasafix",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218445618429952000",
  "geo" : { },
  "id_str" : "218451431450091520",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @marcus_r1975 awww nuts did I lose? :( fuck sake... I am gonna see who wins.. if it is Spain all money goes back! #wasafix",
  "id" : 218451431450091520,
  "in_reply_to_status_id" : 218445618429952000,
  "created_at" : "2012-06-28 21:10:54 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218405814048796673",
  "geo" : { },
  "id_str" : "218413877568880643",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson watershed moments like that are good in life. I've had more than a few recently. Just taking no more shit anymore :)",
  "id" : 218413877568880643,
  "in_reply_to_status_id" : 218405814048796673,
  "created_at" : "2012-06-28 18:41:41 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218405814048796673",
  "geo" : { },
  "id_str" : "218413514711240704",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson did something fuck you off?",
  "id" : 218413514711240704,
  "in_reply_to_status_id" : 218405814048796673,
  "created_at" : "2012-06-28 18:40:14 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pcworld",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/IQTDc5QL",
      "expanded_url" : "http:\/\/yfrog.com\/nxcdhzp",
      "display_url" : "yfrog.com\/nxcdhzp"
    } ]
  },
  "geo" : { },
  "id_str" : "218359117998329856",
  "text" : "Now that is cheap! #pcworld http:\/\/t.co\/IQTDc5QL",
  "id" : 218359117998329856,
  "created_at" : "2012-06-28 15:04:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 40 ],
      "url" : "https:\/\/t.co\/jHJTKco5",
      "expanded_url" : "https:\/\/www.chiliproject.org\/",
      "display_url" : "chiliproject.org"
    } ]
  },
  "geo" : { },
  "id_str" : "218341640220315650",
  "text" : "Just installed the https:\/\/t.co\/jHJTKco5 in work... Wasn't that nasty to do either.",
  "id" : 218341640220315650,
  "created_at" : "2012-06-28 13:54:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218333060905713664",
  "text" : "I find it a failure when I have to install software using the source... Debian and Ubuntu has made me lazy",
  "id" : 218333060905713664,
  "created_at" : "2012-06-28 13:20:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218302882376716289",
  "geo" : { },
  "id_str" : "218303242751315970",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson but I will qualify the statement. I was in the middle of a pissing contest, a horse pissing contest.",
  "id" : 218303242751315970,
  "in_reply_to_status_id" : 218302882376716289,
  "created_at" : "2012-06-28 11:22:03 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218302882376716289",
  "geo" : { },
  "id_str" : "218303086618349569",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson am covered in horse piss..... Will explain tomorrow!!!",
  "id" : 218303086618349569,
  "in_reply_to_status_id" : 218302882376716289,
  "created_at" : "2012-06-28 11:21:26 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218300460971474945",
  "text" : "I am covered in horse piss and I am not happy!!!!!",
  "id" : 218300460971474945,
  "created_at" : "2012-06-28 11:11:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 16, 32 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218121285723631616",
  "geo" : { },
  "id_str" : "218122403144929280",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @AnthonyHastings yes I do!",
  "id" : 218122403144929280,
  "in_reply_to_status_id" : 218121285723631616,
  "created_at" : "2012-06-27 23:23:28 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218115465246019585",
  "text" : "Really don't like using amazon's website to order stuffs... But I still did. Am a hypocrite :)",
  "id" : 218115465246019585,
  "created_at" : "2012-06-27 22:55:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218104244237107200",
  "geo" : { },
  "id_str" : "218104396804927493",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall was explained last night :)",
  "id" : 218104396804927493,
  "in_reply_to_status_id" : 218104244237107200,
  "created_at" : "2012-06-27 22:11:55 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218101853093773312",
  "geo" : { },
  "id_str" : "218103957275410433",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall yup.",
  "id" : 218103957275410433,
  "in_reply_to_status_id" : 218101853093773312,
  "created_at" : "2012-06-27 22:10:10 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218103007613681665",
  "geo" : { },
  "id_str" : "218103876207919106",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard :) Ahhhh righto. Ah well :) I wasn't expecting it to be that bad all the same. Sure Saturday will cheer me up from it.",
  "id" : 218103876207919106,
  "in_reply_to_status_id" : 218103007613681665,
  "created_at" : "2012-06-27 22:09:50 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218101271989714944",
  "geo" : { },
  "id_str" : "218101671002247168",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard heavy rain until Next Tuesday. I was not expecting that. No sir. Booking a holiday right now, seriously. Stupid weather!",
  "id" : 218101671002247168,
  "in_reply_to_status_id" : 218101271989714944,
  "created_at" : "2012-06-27 22:01:05 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218097048543703041",
  "geo" : { },
  "id_str" : "218098992804937729",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist you can go fuck yourself! I hope lightning strikes you, I really do!",
  "id" : 218098992804937729,
  "in_reply_to_status_id" : 218097048543703041,
  "created_at" : "2012-06-27 21:50:26 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218098741058600961",
  "text" : "Just watched The Iron Lady. What a depressing ass film. Not that it was gonna be a barrelful of laughs. But fuck me!",
  "id" : 218098741058600961,
  "created_at" : "2012-06-27 21:49:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 17, 32 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218097759293685761",
  "geo" : { },
  "id_str" : "218098365957799937",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings @georgina_milne knobs!",
  "id" : 218098365957799937,
  "in_reply_to_status_id" : 218097759293685761,
  "created_at" : "2012-06-27 21:47:57 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "indices" : [ 0, 7 ],
      "id_str" : "14060295",
      "id" : 14060295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218094678099230722",
  "geo" : { },
  "id_str" : "218098024709226496",
  "in_reply_to_user_id" : 14060295,
  "text" : "@cimota it's natural selection.",
  "id" : 218098024709226496,
  "in_reply_to_status_id" : 218094678099230722,
  "created_at" : "2012-06-27 21:46:35 +0000",
  "in_reply_to_screen_name" : "cimota",
  "in_reply_to_user_id_str" : "14060295",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218097017224839170",
  "geo" : { },
  "id_str" : "218097942681231361",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight fuck sake. Listening to you lovely wife's propaganda.",
  "id" : 218097942681231361,
  "in_reply_to_status_id" : 218097017224839170,
  "created_at" : "2012-06-27 21:46:16 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/218096398577573889\/photo\/1",
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/zsLEoUJb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwbVhNxCIAAgiDq.jpg",
      "id_str" : "218096398581768192",
      "id" : 218096398581768192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwbVhNxCIAAgiDq.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/zsLEoUJb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218096398577573889",
  "text" : "Fuck. Right. Off. http:\/\/t.co\/zsLEoUJb",
  "id" : 218096398577573889,
  "created_at" : "2012-06-27 21:40:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218069588787736576",
  "geo" : { },
  "id_str" : "218090141967843330",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne noooooo",
  "id" : 218090141967843330,
  "in_reply_to_status_id" : 218069588787736576,
  "created_at" : "2012-06-27 21:15:16 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 3, 16 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 25, 37 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "niweather",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218040859801817088",
  "text" : "RT @RickyHassard: @swmcc @niall_adams ha! Glenavy rocks! #niweather",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Niall Adams",
        "screen_name" : "niall_adams",
        "indices" : [ 7, 19 ],
        "id_str" : "28624459",
        "id" : 28624459
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "niweather",
        "indices" : [ 39, 49 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "218037612131254273",
    "geo" : { },
    "id_str" : "218040729061163008",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @niall_adams ha! Glenavy rocks! #niweather",
    "id" : 218040729061163008,
    "in_reply_to_status_id" : 218037612131254273,
    "created_at" : "2012-06-27 17:58:55 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "protected" : false,
      "id_str" : "5684272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1317084795\/Screen_shot_2011-04-19_at_13.00.12_normal.png",
      "id" : 5684272,
      "verified" : false
    }
  },
  "id" : 218040859801817088,
  "created_at" : "2012-06-27 17:59:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218037002027810816",
  "geo" : { },
  "id_str" : "218037612131254273",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams I just about made it home. No joke! Glenavy is sunny and dry though. Odd. Even rain thinks \"fuck it, Glenavy\".",
  "id" : 218037612131254273,
  "in_reply_to_status_id" : 218037002027810816,
  "created_at" : "2012-06-27 17:46:32 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218034865906515968",
  "geo" : { },
  "id_str" : "218037337257558017",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams and now I know :)",
  "id" : 218037337257558017,
  "in_reply_to_status_id" : 218034865906515968,
  "created_at" : "2012-06-27 17:45:26 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218037210161741825",
  "text" : "Didn't think I was gonna make it hone from Hillsborough. Rain was mad, couldn't see in front of me and roads flooding.",
  "id" : 218037210161741825,
  "created_at" : "2012-06-27 17:44:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Moran",
      "screen_name" : "ianmoran",
      "indices" : [ 0, 9 ],
      "id_str" : "16236773",
      "id" : 16236773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218019065959170049",
  "geo" : { },
  "id_str" : "218036764793774080",
  "in_reply_to_user_id" : 16236773,
  "text" : "@ianmoran nope. It'll be grand just keep the ttl low.",
  "id" : 218036764793774080,
  "in_reply_to_status_id" : 218019065959170049,
  "created_at" : "2012-06-27 17:43:10 +0000",
  "in_reply_to_screen_name" : "ianmoran",
  "in_reply_to_user_id_str" : "16236773",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218010785195102208",
  "text" : "That moment... when you meet a wanker face to face.....",
  "id" : 218010785195102208,
  "created_at" : "2012-06-27 15:59:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217998461965049858",
  "text" : "OH: I have a ginger fetish... I've tried it on with many ginger women...",
  "id" : 217998461965049858,
  "created_at" : "2012-06-27 15:10:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217974656286732288",
  "geo" : { },
  "id_str" : "217977288657076226",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit rockst@r :D :D :D :D",
  "id" : 217977288657076226,
  "in_reply_to_status_id" : 217974656286732288,
  "created_at" : "2012-06-27 13:46:50 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/RP2FleZR",
      "expanded_url" : "http:\/\/www.clipartguide.com\/_named_clipart_images\/0511-0811-0415-3733_Cartoon_of_an_Office_Worker_Drinking_Too_Much_Coffee_clipart_image.jpg",
      "display_url" : "clipartguide.com\/_named_clipart\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217971221415985153",
  "text" : "Current Status: http:\/\/t.co\/RP2FleZR",
  "id" : 217971221415985153,
  "created_at" : "2012-06-27 13:22:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 17, 30 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 31, 45 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notinaromanticwaythough",
      "indices" : [ 115, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217938069532319744",
  "geo" : { },
  "id_str" : "217951286325288961",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @marcus_r1975 @peter_omalley you will be sitting yourself up for a fall... I MISS YOU :D :D :D :D #notinaromanticwaythough",
  "id" : 217951286325288961,
  "in_reply_to_status_id" : 217938069532319744,
  "created_at" : "2012-06-27 12:03:30 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217920347532562434",
  "geo" : { },
  "id_str" : "217921473166311424",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit Yo you used firehose.io in your travels?",
  "id" : 217921473166311424,
  "in_reply_to_status_id" : 217920347532562434,
  "created_at" : "2012-06-27 10:05:02 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217917737924702208",
  "text" : "Stood outside to see HM Queen - she didn't show. I went inside to have some porridge instead. I think I made the correct choice :D",
  "id" : 217917737924702208,
  "created_at" : "2012-06-27 09:50:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217884437013200896",
  "text" : "I've royally fucked this repo :\/ But I know i can get it fixed but just... just.... meh :) Was on support yesterday so dev head on again!",
  "id" : 217884437013200896,
  "created_at" : "2012-06-27 07:37:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217879228023189504",
  "text" : "And happy birthday to @micahelnsimpson :D",
  "id" : 217879228023189504,
  "created_at" : "2012-06-27 07:17:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 3, 17 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 21, 37 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217877035706621952",
  "text" : "No @peter_omalley or @michaelnsimpson in the office today :( Ahh well - will get some work done for a change instead of playing....",
  "id" : 217877035706621952,
  "created_at" : "2012-06-27 07:08:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/ZqZ1wrmj",
      "expanded_url" : "http:\/\/yfrog.com\/kkrrhyp",
      "display_url" : "yfrog.com\/kkrrhyp"
    } ]
  },
  "geo" : { },
  "id_str" : "217873745329664001",
  "text" : "I'm onto a winner here I think..... :) http:\/\/t.co\/ZqZ1wrmj",
  "id" : 217873745329664001,
  "created_at" : "2012-06-27 06:55:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MOO.COM",
      "screen_name" : "overheardatmoo",
      "indices" : [ 68, 83 ],
      "id_str" : "14711282",
      "id" : 14711282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOO",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/JPn7N9Qd",
      "expanded_url" : "http:\/\/klout.com\/perk\/Moo\/MooCards?passalong=Mzc0LzI1ODk1NzAyNjI0MDU2NDIxLzI&passalongSig=375f1e62e54d16dad24a5f231b1760b05b7335c1a08349ed4851ccd7dd86cb81&n=tw&v=perks_completed_passalong&i=25895702624056421",
      "display_url" : "klout.com\/perk\/Moo\/MooCa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217750907595661314",
  "text" : "I'm getting a pack of #MOO cards because I've got Klout - thanks to @overheardatmoo! You can too, just click here: http:\/\/t.co\/JPn7N9Qd",
  "id" : 217750907595661314,
  "created_at" : "2012-06-26 22:47:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 1, 14 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217744187502759939",
  "text" : ".@joannedunlop One requires a status update on Operation: Thingie-ma-jig. Much Love - Stephen :)",
  "id" : 217744187502759939,
  "created_at" : "2012-06-26 22:20:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217742976217124864",
  "text" : "OH: Is that YOU as a gorilla? Don't you find that offensive? No! Why? Gorillas aren't class I'm asking too many questions I'm going to sleep",
  "id" : 217742976217124864,
  "created_at" : "2012-06-26 22:15:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217740253824434176",
  "geo" : { },
  "id_str" : "217741353742897152",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson on the pilgrimage :) Looks interesting..",
  "id" : 217741353742897152,
  "in_reply_to_status_id" : 217740253824434176,
  "created_at" : "2012-06-26 22:09:18 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217740348053651459",
  "text" : "Apparently it is called \"Gorilla hugs kitten\".... Awesome.",
  "id" : 217740348053651459,
  "created_at" : "2012-06-26 22:05:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/217739749211914240\/photo\/1",
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/6qu00L5p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwWRJfWCQAAENW5.png",
      "id_str" : "217739749216108544",
      "id" : 217739749216108544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwWRJfWCQAAENW5.png",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 448
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 448
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6qu00L5p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217739749211914240",
  "text" : "I &lt;3 THIS.... http:\/\/t.co\/6qu00L5p",
  "id" : 217739749211914240,
  "created_at" : "2012-06-26 22:02:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217716213109891072",
  "text" : "Quite liked Newsroom. Apart from the blatant romantic overtures that make no sense and the quirky ending. We shall see.",
  "id" : 217716213109891072,
  "created_at" : "2012-06-26 20:29:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 14, 28 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 29, 45 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217712720626204673",
  "geo" : { },
  "id_str" : "217714130944143360",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 @peter_omalley @michaelnsimpson I am taking myself out of this. You lot don't get it :)",
  "id" : 217714130944143360,
  "in_reply_to_status_id" : 217712720626204673,
  "created_at" : "2012-06-26 20:21:08 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 14, 28 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 29, 45 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217706048390307840",
  "geo" : { },
  "id_str" : "217708121815126017",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 @peter_omalley @michaelnsimpson you idiots don't get it.",
  "id" : 217708121815126017,
  "in_reply_to_status_id" : 217706048390307840,
  "created_at" : "2012-06-26 19:57:15 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217646194988556290",
  "text" : "Damn - I hate crabs.",
  "id" : 217646194988556290,
  "created_at" : "2012-06-26 15:51:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217625496563879938",
  "text" : "OH: i can't comment, i write html for a living",
  "id" : 217625496563879938,
  "created_at" : "2012-06-26 14:28:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "indices" : [ 0, 7 ],
      "id_str" : "14060295",
      "id" : 14060295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217617047914422272",
  "geo" : { },
  "id_str" : "217617790780194816",
  "in_reply_to_user_id" : 14060295,
  "text" : "@cimota he's not a sysadmin... he's a cock. :)",
  "id" : 217617790780194816,
  "in_reply_to_status_id" : 217617047914422272,
  "created_at" : "2012-06-26 13:58:19 +0000",
  "in_reply_to_screen_name" : "cimota",
  "in_reply_to_user_id_str" : "14060295",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217578466864922625",
  "text" : "Think that's set me up for the rest of the day... :D",
  "id" : 217578466864922625,
  "created_at" : "2012-06-26 11:22:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feelsawesome",
      "indices" : [ 113, 126 ]
    }, {
      "text" : "fuckem",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217578297830293505",
  "text" : "Getting an apology over the phone by proxy is a nice thing! \"Sorry about that we would like to apologise for...\" #feelsawesome #fuckem",
  "id" : 217578297830293505,
  "created_at" : "2012-06-26 11:21:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Windsor",
      "screen_name" : "Queen_UK",
      "indices" : [ 3, 12 ],
      "id_str" : "140118545",
      "id" : 140118545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217570246331084800",
  "text" : "RT @Queen_UK: Northern Ireland, one is in you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217568054354251776",
    "text" : "Northern Ireland, one is in you.",
    "id" : 217568054354251776,
    "created_at" : "2012-06-26 10:40:41 +0000",
    "user" : {
      "name" : "Elizabeth Windsor",
      "screen_name" : "Queen_UK",
      "protected" : false,
      "id_str" : "140118545",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1519465232\/HMsmall_normal.jpg",
      "id" : 140118545,
      "verified" : false
    }
  },
  "id" : 217570246331084800,
  "created_at" : "2012-06-26 10:49:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217398621149212674",
  "text" : "For my programming buddies that are waking up this morning and thinking \"Fucking work\" - be thankful that you aren't a RBS programmer :)",
  "id" : 217398621149212674,
  "created_at" : "2012-06-25 23:27:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 30, 46 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 47, 60 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217389096245542912",
  "geo" : { },
  "id_str" : "217389449884090368",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley @michaelnsimpson @rickyhassard pfffffttt... and you'll be in full evening dress too I bet. Idiot :)",
  "id" : 217389449884090368,
  "in_reply_to_status_id" : 217389096245542912,
  "created_at" : "2012-06-25 22:50:58 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 30, 46 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 47, 60 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217375596953608193",
  "geo" : { },
  "id_str" : "217379731149029377",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley @michaelnsimpson @RickyHassard I will wash myself - that's all I can promise :)",
  "id" : 217379731149029377,
  "in_reply_to_status_id" : 217375596953608193,
  "created_at" : "2012-06-25 22:12:21 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217368932301021184",
  "geo" : { },
  "id_str" : "217369189739020288",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley I wasn't at work FFS :)",
  "id" : 217369189739020288,
  "in_reply_to_status_id" : 217368932301021184,
  "created_at" : "2012-06-25 21:30:28 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217367988725219328",
  "geo" : { },
  "id_str" : "217368221576216577",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams why :( I am still super pumped on other crap :) I wasnt at work :)",
  "id" : 217368221576216577,
  "in_reply_to_status_id" : 217367988725219328,
  "created_at" : "2012-06-25 21:26:37 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217361910029484033",
  "text" : "And now..... Now I head home... :)",
  "id" : 217361910029484033,
  "created_at" : "2012-06-25 21:01:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217292245060173826",
  "text" : "\/me looks around the office and can see a load of dead bodies... Think Monday has killed a few peeps today. I am happy though :D",
  "id" : 217292245060173826,
  "created_at" : "2012-06-25 16:24:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyoutuesday",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217284899298742274",
  "geo" : { },
  "id_str" : "217285021768237057",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams too right :D Hasn't been that bad a Monday, relatively speaking... Tomorrow might break me. #fuckyoutuesday",
  "id" : 217285021768237057,
  "in_reply_to_status_id" : 217284899298742274,
  "created_at" : "2012-06-25 15:56:00 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 25, 37 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217284491037782016",
  "text" : "I want it on record that @niall_adams just done the 'blowjob' face to me there as he was walking down the stairs! :D :D :D",
  "id" : 217284491037782016,
  "created_at" : "2012-06-25 15:53:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "node js",
      "screen_name" : "nodejs",
      "indices" : [ 3, 10 ],
      "id_str" : "91985735",
      "id" : 91985735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/Sq0a0nbU",
      "expanded_url" : "http:\/\/blog.nodejs.org\/2012\/06\/25\/node-v0-8-0\/",
      "display_url" : "blog.nodejs.org\/2012\/06\/25\/nod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217273028076257282",
  "text" : "RT @nodejs: Version 0.8.0 Released\nhttp:\/\/t.co\/Sq0a0nbU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/Sq0a0nbU",
        "expanded_url" : "http:\/\/blog.nodejs.org\/2012\/06\/25\/node-v0-8-0\/",
        "display_url" : "blog.nodejs.org\/2012\/06\/25\/nod\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217271405996290049",
    "text" : "Version 0.8.0 Released\nhttp:\/\/t.co\/Sq0a0nbU",
    "id" : 217271405996290049,
    "created_at" : "2012-06-25 15:01:54 +0000",
    "user" : {
      "name" : "node js",
      "screen_name" : "nodejs",
      "protected" : false,
      "id_str" : "91985735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1437021459\/nodejs-dark_normal.png",
      "id" : 91985735,
      "verified" : false
    }
  },
  "id" : 217273028076257282,
  "created_at" : "2012-06-25 15:08:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217267601364090880",
  "geo" : { },
  "id_str" : "217267901961482240",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus answer support tickets cos they are working for the likes of Citi and NYSE... Can't design fuck all from the ground up.",
  "id" : 217267901961482240,
  "in_reply_to_status_id" : 217267601364090880,
  "created_at" : "2012-06-25 14:47:59 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217267601364090880",
  "geo" : { },
  "id_str" : "217267806834659328",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus oh hell yeah - you need to understand the shit regardless.. A bit like a generation of 'developers' out there that can only",
  "id" : 217267806834659328,
  "in_reply_to_status_id" : 217267601364090880,
  "created_at" : "2012-06-25 14:47:36 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217267349865234434",
  "geo" : { },
  "id_str" : "217267490101788673",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus for personal use I can't justify it. Work - well me doing this is taken away actual development time so it might work out...",
  "id" : 217267490101788673,
  "in_reply_to_status_id" : 217267349865234434,
  "created_at" : "2012-06-25 14:46:20 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "backofthenet",
      "indices" : [ 48, 61 ]
    }, {
      "text" : "nowtorebootthefucker",
      "indices" : [ 62, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217267165215207425",
  "text" : "elmo:~# cat \/etc\/debian_version \n6.0.5\nelmo:~#\n\n#backofthenet #nowtorebootthefucker",
  "id" : 217267165215207425,
  "created_at" : "2012-06-25 14:45:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217265888506814465",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgstatus the more I see it and use it out of work the more PaaS model is making more and more sense to me",
  "id" : 217265888506814465,
  "created_at" : "2012-06-25 14:39:59 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217264912030896129",
  "geo" : { },
  "id_str" : "217265431445127169",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus well if it doesn't work it hardly matters. Local VM in the internal server cluster... AKA Don't give a fuck :)",
  "id" : 217265431445127169,
  "in_reply_to_status_id" : 217264912030896129,
  "created_at" : "2012-06-25 14:38:10 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217264116279160834",
  "text" : "Doing a dist upgrade from lenny to squeeze on a VM... Wonder if this will work. 50\/50 with these things usually.",
  "id" : 217264116279160834,
  "created_at" : "2012-06-25 14:32:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217263528334213120",
  "geo" : { },
  "id_str" : "217263802608132097",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams aye the phones wont fucking quit.. i have work to do and there is too much happening!!!",
  "id" : 217263802608132097,
  "in_reply_to_status_id" : 217263528334213120,
  "created_at" : "2012-06-25 14:31:41 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217244392262602753",
  "text" : "I just royally fucked up my repo.... Impressive.... \/me goes to rollback",
  "id" : 217244392262602753,
  "created_at" : "2012-06-25 13:14:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/217217259477811200\/photo\/1",
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/X2YRZSAh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwO18laCQAAwKyd.jpg",
      "id_str" : "217217259482005504",
      "id" : 217217259482005504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwO18laCQAAwKyd.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/X2YRZSAh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217217259477811200",
  "text" : "Taking pleasure in a friends sleep deprived misery is funny. Short and tithe point response :) http:\/\/t.co\/X2YRZSAh",
  "id" : 217217259477811200,
  "created_at" : "2012-06-25 11:26:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217213843812777984",
  "text" : "Hence why I am now tweeting instead of getting on with what I am supposed. Yes, i know this is a failure of mine. But its fucking annoying!",
  "id" : 217213843812777984,
  "created_at" : "2012-06-25 11:13:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217213749176705025",
  "text" : "I find it next to impossible to get any work done with people walking around me back and forth. So I just stop working when it happens.",
  "id" : 217213749176705025,
  "created_at" : "2012-06-25 11:12:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217203185062912000",
  "text" : "Raining Men - Geri Halwhatshername verison came on my itunes dj... Weirdly I am alright with it :D",
  "id" : 217203185062912000,
  "created_at" : "2012-06-25 10:30:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217014252433702913",
  "geo" : { },
  "id_str" : "217029840652603394",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley You should forefit if you win cos you cheated. Also remember to wear something slutty tomorrow - start of the week good!",
  "id" : 217029840652603394,
  "in_reply_to_status_id" : 217014252433702913,
  "created_at" : "2012-06-24 23:02:00 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217005856322101249",
  "text" : "Hmmmmm.... Who is the better team then - Germany or Italy? I want that 65quid dammit!!!",
  "id" : 217005856322101249,
  "created_at" : "2012-06-24 21:26:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217004261073092609",
  "geo" : { },
  "id_str" : "217004456674471936",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I'm 65quid closer if England win though (have Germany in the work sweeps). Only reason I am watching now :)",
  "id" : 217004456674471936,
  "in_reply_to_status_id" : 217004261073092609,
  "created_at" : "2012-06-24 21:21:08 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 54, 62 ],
      "id_str" : "79820731",
      "id" : 79820731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217004083880538113",
  "text" : "I want Englad to win - only cos I have Germany in the @tascomi sweep stakes.",
  "id" : 217004083880538113,
  "created_at" : "2012-06-24 21:19:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Shaw",
      "screen_name" : "dshaw",
      "indices" : [ 0, 6 ],
      "id_str" : "806757",
      "id" : 806757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cool",
      "indices" : [ 53, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217003312485105667",
  "geo" : { },
  "id_str" : "217003928229904384",
  "in_reply_to_user_id" : 806757,
  "text" : "@dshaw an american watching a Euro quarter final? ;) #cool",
  "id" : 217003928229904384,
  "in_reply_to_status_id" : 217003312485105667,
  "created_at" : "2012-06-24 21:19:02 +0000",
  "in_reply_to_screen_name" : "dshaw",
  "in_reply_to_user_id_str" : "806757",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216997680826679296",
  "geo" : { },
  "id_str" : "217000287171391488",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley do they get paid for playing for England? Football is boring!",
  "id" : 217000287171391488,
  "in_reply_to_status_id" : 216997680826679296,
  "created_at" : "2012-06-24 21:04:34 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216995809563119616",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley maybe I am missing something - but if they can't get a winner in 90 - why have an extra 30? Stupid. Game.",
  "id" : 216995809563119616,
  "created_at" : "2012-06-24 20:46:47 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216992981478150144",
  "geo" : { },
  "id_str" : "216994724765122561",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley pfffffttttt. stupid game.... I. DO. NOT. GET. IT.",
  "id" : 216994724765122561,
  "in_reply_to_status_id" : 216992981478150144,
  "created_at" : "2012-06-24 20:42:28 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216989164233699329",
  "text" : "Am just back from a mates house this evening and I find that I've missed 80mins of football on the tee-vee... Result :D",
  "id" : 216989164233699329,
  "created_at" : "2012-06-24 20:20:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216857505161166848",
  "text" : "Anyone else on twitter getting DM's that you have read coming back as 'unread' - drives me insane :(",
  "id" : 216857505161166848,
  "created_at" : "2012-06-24 11:37:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216853541011193856",
  "geo" : { },
  "id_str" : "216857302169419778",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp I like you but your boyfriend is a fuckwit of epic proportions.",
  "id" : 216857302169419778,
  "in_reply_to_status_id" : 216853541011193856,
  "created_at" : "2012-06-24 11:36:24 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216852275249946626",
  "geo" : { },
  "id_str" : "216852389460852736",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley asshole",
  "id" : 216852389460852736,
  "in_reply_to_status_id" : 216852275249946626,
  "created_at" : "2012-06-24 11:16:53 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 65, 77 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216851230369128448",
  "geo" : { },
  "id_str" : "216851677360295936",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley sales shopping in London??? Was this your idea or @Kirstylvssp - think carefully re: your answer!",
  "id" : 216851677360295936,
  "in_reply_to_status_id" : 216851230369128448,
  "created_at" : "2012-06-24 11:14:03 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216848505703120896",
  "text" : "\u00A310,000 to someone who can invent an app that will make be beans and toast from either the command line, app or www.",
  "id" : 216848505703120896,
  "created_at" : "2012-06-24 11:01:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216821233663229952",
  "geo" : { },
  "id_str" : "216832372648321024",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson it should be... it should be :D Donkey Ninjas are class!!!",
  "id" : 216832372648321024,
  "in_reply_to_status_id" : 216821233663229952,
  "created_at" : "2012-06-24 09:57:20 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216675462934560769",
  "geo" : { },
  "id_str" : "216675943136247808",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne I'll make a list :) Coffee table is still in the car so no photo - will take it out tomorrow.",
  "id" : 216675943136247808,
  "in_reply_to_status_id" : 216675462934560769,
  "created_at" : "2012-06-23 23:35:45 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronan Keating",
      "screen_name" : "ronanofficial",
      "indices" : [ 0, 14 ],
      "id_str" : "26032912",
      "id" : 26032912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216654797573603329",
  "geo" : { },
  "id_str" : "216671979250515969",
  "in_reply_to_user_id" : 26032912,
  "text" : "@ronanofficial you given the wire a go? mad men as well... Good call on Sons of Anarchy but they do the irish accent wrong :(",
  "id" : 216671979250515969,
  "in_reply_to_status_id" : 216654797573603329,
  "created_at" : "2012-06-23 23:20:00 +0000",
  "in_reply_to_screen_name" : "ronanofficial",
  "in_reply_to_user_id_str" : "26032912",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216641859274031104",
  "text" : "Very productive day! Am in love with hubot - but still discordia was still the bestest bot ever.",
  "id" : 216641859274031104,
  "created_at" : "2012-06-23 21:20:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216577391936540673",
  "geo" : { },
  "id_str" : "216577603459489794",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne hoover does not work. stereo does not work. table is fugly. Will take a pic and send you it then see :)",
  "id" : 216577603459489794,
  "in_reply_to_status_id" : 216577391936540673,
  "created_at" : "2012-06-23 17:04:59 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 17, 32 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216572993021808640",
  "geo" : { },
  "id_str" : "216573224597729280",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @Georgina_Milne you wanna see what I am doing with my \"work area\" now... Just found a bank statement from 2005 in a drawer!",
  "id" : 216573224597729280,
  "in_reply_to_status_id" : 216572993021808640,
  "created_at" : "2012-06-23 16:47:35 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 16, 32 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216571377241702401",
  "geo" : { },
  "id_str" : "216572578133835777",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @michaelnsimpson An old coffee table, an old chair, a hoover, an old stereo from 1993 and general rubbish.",
  "id" : 216572578133835777,
  "in_reply_to_status_id" : 216571377241702401,
  "created_at" : "2012-06-23 16:45:01 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 16, 32 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216554591356059648",
  "geo" : { },
  "id_str" : "216565960470048769",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @michaelnsimpson You are as bad as my sister :D I missed the skip so its in my car for the time being. Will do it on Monday.",
  "id" : 216565960470048769,
  "in_reply_to_status_id" : 216554591356059648,
  "created_at" : "2012-06-23 16:18:43 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 60, 76 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216547724902932480",
  "text" : "And now - the dump in Crumlin.. Spending too much time with @michaelnsimpson and am throwing shit I don't need the fuck out!",
  "id" : 216547724902932480,
  "created_at" : "2012-06-23 15:06:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216546770942033920",
  "text" : "Just moved my \"living room\" to another room.... Last month I moved to another bedroom... Gonna take a while to adjust :)",
  "id" : 216546770942033920,
  "created_at" : "2012-06-23 15:02:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216281992436793344",
  "geo" : { },
  "id_str" : "216283631365267458",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard you are a beautiful man :)",
  "id" : 216283631365267458,
  "in_reply_to_status_id" : 216281992436793344,
  "created_at" : "2012-06-22 21:36:50 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216279381105049601",
  "geo" : { },
  "id_str" : "216281631676305409",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard awesome :) I should do that too... do you think I will have it done by Monday night? ;)",
  "id" : 216281631676305409,
  "in_reply_to_status_id" : 216279381105049601,
  "created_at" : "2012-06-22 21:28:53 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216271305224364032",
  "text" : "* puts an end to the shittest week in a long time not helped by this ubber shit Friday. Tomrrow is a new dawn. Still - assholes keep clear!",
  "id" : 216271305224364032,
  "created_at" : "2012-06-22 20:47:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216264869249421313",
  "text" : "That's it. I meet one more self centred person today again I am hibernating for the rest of the year! :)",
  "id" : 216264869249421313,
  "created_at" : "2012-06-22 20:22:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216247682602242048",
  "geo" : { },
  "id_str" : "216247867206156288",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid see that - but good Monday viewing - need something for that shitty day now that Mad Men is over.. So gonna watch Silk.",
  "id" : 216247867206156288,
  "in_reply_to_status_id" : 216247682602242048,
  "created_at" : "2012-06-22 19:14:43 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216244892916137984",
  "text" : "Designing with a sip of bourbon.... What has happened to my life ;)",
  "id" : 216244892916137984,
  "created_at" : "2012-06-22 19:02:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216243101268852736",
  "geo" : { },
  "id_str" : "216244348902309889",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid is it out now? Must go look... I liked 60 as well. TV also doesn't get much better than TWW S1 I think.",
  "id" : 216244348902309889,
  "in_reply_to_status_id" : 216243101268852736,
  "created_at" : "2012-06-22 19:00:45 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216237737848745984",
  "geo" : { },
  "id_str" : "216239558071828481",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley ignore it!!!!! Be a man! This week sucked major donkey dick... I am tellin ya...",
  "id" : 216239558071828481,
  "in_reply_to_status_id" : 216237737848745984,
  "created_at" : "2012-06-22 18:41:42 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yeahthisshitbeme",
      "indices" : [ 21, 38 ]
    }, {
      "text" : "shitdayjustgotshitterandtheweatherisnthelping",
      "indices" : [ 39, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/S1cSD1o5",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Transition_dipole_moment",
      "display_url" : "en.wikipedia.org\/wiki\/Transitio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216174381259440128",
  "text" : "http:\/\/t.co\/S1cSD1o5 #yeahthisshitbeme #shitdayjustgotshitterandtheweatherisnthelping",
  "id" : 216174381259440128,
  "created_at" : "2012-06-22 14:22:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216168080932474880",
  "geo" : { },
  "id_str" : "216173181248081921",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 feeling better now thanks.",
  "id" : 216173181248081921,
  "in_reply_to_status_id" : 216168080932474880,
  "created_at" : "2012-06-22 14:17:57 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "indices" : [ 123, 134 ],
      "id_str" : "66949689",
      "id" : 66949689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 118 ],
      "url" : "https:\/\/t.co\/i0piGbIw",
      "expanded_url" : "https:\/\/vimeo.com\/44037268",
      "display_url" : "vimeo.com\/44037268"
    } ]
  },
  "geo" : { },
  "id_str" : "216140273850384386",
  "text" : "No INI 'big financial institution' or 'cloud story' - all home grown talent - FUCKING AWESOME. - https:\/\/t.co\/i0piGbIw \/cc @blacknorth",
  "id" : 216140273850384386,
  "created_at" : "2012-06-22 12:07:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 31, 45 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 46, 59 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215831096233959424",
  "geo" : { },
  "id_str" : "215831400539103232",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 @michaelnsimpson @peter_omalley @rickyhassard but a 9 year old kid inheriting billions - yes. yes he could.",
  "id" : 215831400539103232,
  "in_reply_to_status_id" : 215831096233959424,
  "created_at" : "2012-06-21 15:39:50 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 31, 45 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 46, 59 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215831096233959424",
  "geo" : { },
  "id_str" : "215831319807131648",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 @michaelnsimpson @peter_omalley @rickyhassard with enough time and training.. possibly. But I am 33 now so I'd be 50...",
  "id" : 215831319807131648,
  "in_reply_to_status_id" : 215831096233959424,
  "created_at" : "2012-06-21 15:39:31 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 31, 45 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 46, 59 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215828740545064961",
  "geo" : { },
  "id_str" : "215830668175884288",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 @michaelnsimpson @peter_omalley @rickyhassard see... told you.. with enough training and funding it could be possible!",
  "id" : 215830668175884288,
  "in_reply_to_status_id" : 215828740545064961,
  "created_at" : "2012-06-21 15:36:55 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215780905741062145",
  "geo" : { },
  "id_str" : "215782165261193217",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard \"to be continued\"....",
  "id" : 215782165261193217,
  "in_reply_to_status_id" : 215780905741062145,
  "created_at" : "2012-06-21 12:24:11 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215777772533059586",
  "geo" : { },
  "id_str" : "215780363786661888",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard again... WTF... You should be \"networking\"",
  "id" : 215780363786661888,
  "in_reply_to_status_id" : 215777772533059586,
  "created_at" : "2012-06-21 12:17:02 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215680943304867841",
  "geo" : { },
  "id_str" : "215706320286916608",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit Congratulations :D",
  "id" : 215706320286916608,
  "in_reply_to_status_id" : 215680943304867841,
  "created_at" : "2012-06-21 07:22:49 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 1, 9 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 11, 17 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215587691591503873",
  "text" : "\u201C@HaVoCT5: @swmcc only when am using the right hand :)\u201D Finally someone that will go as low as me. Tascomi upstairs just got interesting :)",
  "id" : 215587691591503873,
  "created_at" : "2012-06-20 23:31:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215586926613381120",
  "geo" : { },
  "id_str" : "215587178783309825",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 I'll be watching you sleep. That thought will linger.",
  "id" : 215587178783309825,
  "in_reply_to_status_id" : 215586926613381120,
  "created_at" : "2012-06-20 23:29:23 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215585930021572611",
  "geo" : { },
  "id_str" : "215586458130587648",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 nah only kidding :) forget that shit :) Am only playing. You will learn to respect them given time :)",
  "id" : 215586458130587648,
  "in_reply_to_status_id" : 215585930021572611,
  "created_at" : "2012-06-20 23:26:31 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215585066531815424",
  "geo" : { },
  "id_str" : "215585393331023872",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 \/after\/ centos :)",
  "id" : 215585393331023872,
  "in_reply_to_status_id" : 215585066531815424,
  "created_at" : "2012-06-20 23:22:17 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215584491647926273",
  "geo" : { },
  "id_str" : "215584704026509313",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 no problem. Will be done ASAP when you are in :)",
  "id" : 215584704026509313,
  "in_reply_to_status_id" : 215584491647926273,
  "created_at" : "2012-06-20 23:19:33 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215584268162842624",
  "geo" : { },
  "id_str" : "215584399050293249",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 I like to take my time.",
  "id" : 215584399050293249,
  "in_reply_to_status_id" : 215584268162842624,
  "created_at" : "2012-06-20 23:18:20 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215584288542957568",
  "in_reply_to_user_id" : 152381157,
  "text" : "@havoct5 Then when that's done - phpUnit :)",
  "id" : 215584288542957568,
  "created_at" : "2012-06-20 23:17:54 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tagyouareit",
      "indices" : [ 34, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215583000967122944",
  "geo" : { },
  "id_str" : "215583903862374401",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 am serious by the way :) #tagyouareit",
  "id" : 215583903862374401,
  "in_reply_to_status_id" : 215583000967122944,
  "created_at" : "2012-06-20 23:16:22 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215583000967122944",
  "geo" : { },
  "id_str" : "215583700736413697",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 so set up a centos 5.6 install with Postgres 8.1, PHP 5.3 and apache 2.0 use vagrantz I'll check up I. Friday. See how you get on.",
  "id" : 215583700736413697,
  "in_reply_to_status_id" : 215583000967122944,
  "created_at" : "2012-06-20 23:15:34 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215583000967122944",
  "geo" : { },
  "id_str" : "215583382833336321",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 I love you already. But you've just been promoted to server guy in waiting. Congratulations - www.centis.ord - enjoy :)",
  "id" : 215583382833336321,
  "in_reply_to_status_id" : 215583000967122944,
  "created_at" : "2012-06-20 23:14:18 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215581789744410624",
  "geo" : { },
  "id_str" : "215582422895575040",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 and you've just fucked me off and the Friday gods off. You think you can hide? There is a flaw in your formula :)",
  "id" : 215582422895575040,
  "in_reply_to_status_id" : 215581789744410624,
  "created_at" : "2012-06-20 23:10:29 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215581250973478912",
  "geo" : { },
  "id_str" : "215581454388830210",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 you are a fucking idiot",
  "id" : 215581454388830210,
  "in_reply_to_status_id" : 215581250973478912,
  "created_at" : "2012-06-20 23:06:38 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215580077944078336",
  "geo" : { },
  "id_str" : "215580444652089345",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 you :) and no need. No need at all. You are playing with powers you do not understand :)",
  "id" : 215580444652089345,
  "in_reply_to_status_id" : 215580077944078336,
  "created_at" : "2012-06-20 23:02:37 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215579366397198336",
  "geo" : { },
  "id_str" : "215579642810220544",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 hmmmm seems I've found a worthy opponent :)",
  "id" : 215579642810220544,
  "in_reply_to_status_id" : 215579366397198336,
  "created_at" : "2012-06-20 22:59:26 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215578509370851329",
  "geo" : { },
  "id_str" : "215578863672102912",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 what are you wearing?",
  "id" : 215578863672102912,
  "in_reply_to_status_id" : 215578509370851329,
  "created_at" : "2012-06-20 22:56:21 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215566146248769536",
  "geo" : { },
  "id_str" : "215566602526138368",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke either road. I'd go it in a second :)",
  "id" : 215566602526138368,
  "in_reply_to_status_id" : 215566146248769536,
  "created_at" : "2012-06-20 22:07:37 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hecticlifeifswmcc",
      "indices" : [ 32, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215566459068366849",
  "text" : "Finally sitting down to my tea. #hecticlifeifswmcc",
  "id" : 215566459068366849,
  "created_at" : "2012-06-20 22:07:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215565559998324738",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke unless they horde the money or something in an off shore back account. I wish I could do it!",
  "id" : 215565559998324738,
  "created_at" : "2012-06-20 22:03:29 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215565165133963266",
  "geo" : { },
  "id_str" : "215565468008857602",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke I don't understand the big deal though - am sure that the money is ploughed back into the economy through other means though",
  "id" : 215565468008857602,
  "in_reply_to_status_id" : 215565165133963266,
  "created_at" : "2012-06-20 22:03:07 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215565165133963266",
  "geo" : { },
  "id_str" : "215565332218257408",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke reducing a bill from 135 to 3.5k is a bit on the immoral side since we all use the same services.. But still - fair play :)",
  "id" : 215565332218257408,
  "in_reply_to_status_id" : 215565165133963266,
  "created_at" : "2012-06-20 22:02:34 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215562578905137154",
  "text" : "And... yup *CLANG*...",
  "id" : 215562578905137154,
  "created_at" : "2012-06-20 21:51:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215552071313784833",
  "geo" : { },
  "id_str" : "215562337145466882",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke its immoral like - but I am the same. If I could do with it - I would do it.. Too fucking right. Immoral and rich wins!",
  "id" : 215562337145466882,
  "in_reply_to_status_id" : 215552071313784833,
  "created_at" : "2012-06-20 21:50:40 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thisdoesnotpleasememovingforward",
      "indices" : [ 81, 114 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215418284332433409",
  "geo" : { },
  "id_str" : "215520404343762944",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard Hang on... I just saw your tweet at lunchtime. How did you escape? #thisdoesnotpleasememovingforward",
  "id" : 215520404343762944,
  "in_reply_to_status_id" : 215418284332433409,
  "created_at" : "2012-06-20 19:04:03 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heroku",
      "screen_name" : "heroku",
      "indices" : [ 15, 22 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215519190948388864",
  "text" : "You gotta love @heroku. Nuff Said.....",
  "id" : 215519190948388864,
  "created_at" : "2012-06-20 18:59:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 29, 42 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "retiredandboredawinnerforswmcc",
      "indices" : [ 104, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215511252141735937",
  "text" : "Came home early from leaving @marcus_r1975 at the airport and my Dad was strimming my garden... Result. #retiredandboredawinnerforswmcc",
  "id" : 215511252141735937,
  "created_at" : "2012-06-20 18:27:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckinghellgetherefaster",
      "indices" : [ 48, 73 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215510854467203072",
  "geo" : { },
  "id_str" : "215511008297492480",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams what is an acorn? #fuckinghellgetherefaster",
  "id" : 215511008297492480,
  "in_reply_to_status_id" : 215510854467203072,
  "created_at" : "2012-06-20 18:26:43 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215510400995819520",
  "geo" : { },
  "id_str" : "215510486974869504",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @michaelnsimpson stop being a grumpy fuck!",
  "id" : 215510486974869504,
  "in_reply_to_status_id" : 215510400995819520,
  "created_at" : "2012-06-20 18:24:38 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 7, 23 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 24, 36 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215510078361571328",
  "geo" : { },
  "id_str" : "215510316979716096",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @michaelnsimpson @niall_adams Acorns you ass........",
  "id" : 215510316979716096,
  "in_reply_to_status_id" : 215510078361571328,
  "created_at" : "2012-06-20 18:23:58 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215510225455812608",
  "text" : "It is really geeky that I am listening to ruby podcasts when cleaning the house...",
  "id" : 215510225455812608,
  "created_at" : "2012-06-20 18:23:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 34, 46 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215510078361571328",
  "text" : "\/me looks at @michaelnsimpson and @niall_adams - hmmmmmmmmmm - HMMMMMMMMMMMMMM - HHHHMMMMMMMM!",
  "id" : 215510078361571328,
  "created_at" : "2012-06-20 18:23:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215467583221141504",
  "geo" : { },
  "id_str" : "215485565997555712",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley MAN CARD DOWN. MAN CARD DOWN. Leaving ONE this week!!!!!",
  "id" : 215485565997555712,
  "in_reply_to_status_id" : 215467583221141504,
  "created_at" : "2012-06-20 16:45:37 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/215467580712955904\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/0HASJA1b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Av1-n4FCMAAhq_v.jpg",
      "id_str" : "215467580717150208",
      "id" : 215467580717150208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av1-n4FCMAAhq_v.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/0HASJA1b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215467580712955904",
  "text" : "This is the stupidest cunt ive ever met. WHSmith Belfast airport. http:\/\/t.co\/0HASJA1b",
  "id" : 215467580712955904,
  "created_at" : "2012-06-20 15:34:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sparrowmail",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215382180111712256",
  "text" : "Anyone use sparrowmail for the iPhone? I use it for personal mail on me MPB. Just wondering the iphone app is any good? #sparrowmail",
  "id" : 215382180111712256,
  "created_at" : "2012-06-20 09:54:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215373454420082688",
  "text" : "OH: I never really got on with my brother when we were growing up but I never ever wanted to shite on him!",
  "id" : 215373454420082688,
  "created_at" : "2012-06-20 09:20:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 27, 42 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215200708797014024",
  "geo" : { },
  "id_str" : "215209598632738816",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit you bought a @Georgina_Milne ??",
  "id" : 215209598632738816,
  "in_reply_to_status_id" : 215200708797014024,
  "created_at" : "2012-06-19 22:29:01 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215114436887855104",
  "geo" : { },
  "id_str" : "215122558087991296",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I am knocking the crap out of the OH's this week aren't I?",
  "id" : 215122558087991296,
  "in_reply_to_status_id" : 215114436887855104,
  "created_at" : "2012-06-19 16:43:09 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215107585098002433",
  "geo" : { },
  "id_str" : "215108300876939264",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Alana Bakes Ltd... I'll be an investor :D",
  "id" : 215108300876939264,
  "in_reply_to_status_id" : 215107585098002433,
  "created_at" : "2012-06-19 15:46:30 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215106515005210624",
  "geo" : { },
  "id_str" : "215107138694029312",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll did you open a home salon and just ignore the bakery idea?",
  "id" : 215107138694029312,
  "in_reply_to_status_id" : 215106515005210624,
  "created_at" : "2012-06-19 15:41:53 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fucktuesday",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215106999183097857",
  "text" : "\u201C@michaelnsimpson: Just entered my 5th meeting for the day, someone fucking kill me.\u201D #fucktuesday",
  "id" : 215106999183097857,
  "created_at" : "2012-06-19 15:41:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 39, 52 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Sonos",
      "screen_name" : "Sonos",
      "indices" : [ 89, 95 ],
      "id_str" : "16727022",
      "id" : 16727022
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyoutuesday",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215021560543719426",
  "text" : "\u201C@michaelnsimpson: When all else fails @RickyHassard puts the new Tallest Man release on @sonos - bravo sir, bravo #fuckyoutuesday\u201D",
  "id" : 215021560543719426,
  "created_at" : "2012-06-19 10:01:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fucktuesday",
      "indices" : [ 49, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215004325120970754",
  "text" : "\/me tries to clean himself... cannot be done.... #fucktuesday",
  "id" : 215004325120970754,
  "created_at" : "2012-06-19 08:53:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fucktuesday",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215002746233954304",
  "text" : "And there it is........ *BOOOM* #fucktuesday",
  "id" : 215002746233954304,
  "created_at" : "2012-06-19 08:47:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fucktuesday",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "fucktuesday",
      "indices" : [ 13, 25 ]
    }, {
      "text" : "fucktuesday",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214996214268182528",
  "text" : "#fucktuesday #fucktuesday #fucktuesday",
  "id" : 214996214268182528,
  "created_at" : "2012-06-19 08:21:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214975327930290176",
  "text" : "Mr. Poots - take a bow sir.... Just when you think our 'politicians' can't sink any lower... Idiot.",
  "id" : 214975327930290176,
  "created_at" : "2012-06-19 06:58:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214847723004895233",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley Much love.. Stephen :D",
  "id" : 214847723004895233,
  "created_at" : "2012-06-18 22:31:03 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fucktuesday",
      "indices" : [ 40, 52 ]
    }, {
      "text" : "fuckthebusinessteam",
      "indices" : [ 57, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214846776010735616",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley yeah... #fucktuesday and #fuckthebusinessteam",
  "id" : 214846776010735616,
  "created_at" : "2012-06-18 22:27:17 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214846428047081472",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley but never mind the meetings so much - but the kerfuffle it will cause upstairs. i need peace to work...",
  "id" : 214846428047081472,
  "created_at" : "2012-06-18 22:25:54 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214846016233553922",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley like when do you assholes do any work - how can you when you are in FUCKING meetings all the FUCKING time!",
  "id" : 214846016233553922,
  "created_at" : "2012-06-18 22:24:16 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214844675159367681",
  "geo" : { },
  "id_str" : "214845865788051456",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley I will take those positive energy bars and shoving it up your ass! Your kind likes too many meetings...",
  "id" : 214845865788051456,
  "in_reply_to_status_id" : 214844675159367681,
  "created_at" : "2012-06-18 22:23:40 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214834548809269249",
  "geo" : { },
  "id_str" : "214835152034070531",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq where my desk is positioned means that people will be walking in behind me and around me all day. Fucks me off is all :)",
  "id" : 214835152034070531,
  "in_reply_to_status_id" : 214834548809269249,
  "created_at" : "2012-06-18 21:41:06 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fucktuesday",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214832921977163776",
  "geo" : { },
  "id_str" : "214833631485632512",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley It is even winding me up now thinking about it... I'm just gonna grump tomorrow until I go home I think.. #fucktuesday",
  "id" : 214833631485632512,
  "in_reply_to_status_id" : 214832921977163776,
  "created_at" : "2012-06-18 21:35:03 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214830661134057474",
  "geo" : { },
  "id_str" : "214830808744202240",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley just the sheer amount of meetings.. Its gonna wind me up.. Must bring earphones.",
  "id" : 214830808744202240,
  "in_reply_to_status_id" : 214830661134057474,
  "created_at" : "2012-06-18 21:23:50 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214827818410967040",
  "text" : "Maybe I am being too negative. But tomorrow is gonna suck big donkey dicks.",
  "id" : 214827818410967040,
  "created_at" : "2012-06-18 21:11:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 0, 11 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "datenight",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214695450882744321",
  "geo" : { },
  "id_str" : "214700395061190657",
  "in_reply_to_user_id" : 5932682,
  "text" : "@davidjrice I'm a sure thing... Just letting you know. #datenight",
  "id" : 214700395061190657,
  "in_reply_to_status_id" : 214695450882744321,
  "created_at" : "2012-06-18 12:45:37 +0000",
  "in_reply_to_screen_name" : "davidjrice",
  "in_reply_to_user_id_str" : "5932682",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214465682484641792",
  "geo" : { },
  "id_str" : "214471022118846464",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit it's a bruise. Man up :)",
  "id" : 214471022118846464,
  "in_reply_to_status_id" : 214465682484641792,
  "created_at" : "2012-06-17 21:34:11 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214466137637916672",
  "text" : "I now I like goats cheese.",
  "id" : 214466137637916672,
  "created_at" : "2012-06-17 21:14:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cahir O'Doherty",
      "screen_name" : "cahir_odoherty",
      "indices" : [ 3, 18 ],
      "id_str" : "14993868",
      "id" : 14993868
    }, {
      "name" : "Responsify",
      "screen_name" : "responsifyit",
      "indices" : [ 104, 117 ],
      "id_str" : "462983240",
      "id" : 462983240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/AF70vQI7",
      "expanded_url" : "http:\/\/responsify.it\/",
      "display_url" : "responsify.it"
    } ]
  },
  "geo" : { },
  "id_str" : "214457121452986368",
  "text" : "RT @cahir_odoherty: Responsify - A new tool to build Responsive grid templates http:\/\/t.co\/AF70vQI7 via @responsifyit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Responsify",
        "screen_name" : "responsifyit",
        "indices" : [ 84, 97 ],
        "id_str" : "462983240",
        "id" : 462983240
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/AF70vQI7",
        "expanded_url" : "http:\/\/responsify.it\/",
        "display_url" : "responsify.it"
      } ]
    },
    "geo" : { },
    "id_str" : "214453163242160128",
    "text" : "Responsify - A new tool to build Responsive grid templates http:\/\/t.co\/AF70vQI7 via @responsifyit",
    "id" : 214453163242160128,
    "created_at" : "2012-06-17 20:23:13 +0000",
    "user" : {
      "name" : "Cahir O'Doherty",
      "screen_name" : "cahir_odoherty",
      "protected" : false,
      "id_str" : "14993868",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3308543948\/ad17c61ef396feee0d641617be0c77ea_normal.jpeg",
      "id" : 14993868,
      "verified" : false
    }
  },
  "id" : 214457121452986368,
  "created_at" : "2012-06-17 20:38:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214450382179540992",
  "geo" : { },
  "id_str" : "214450854093258753",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR I'm not as classy as you. But you are quite clearly crazy for that show as pure pish... Not a good thing about it.",
  "id" : 214450854093258753,
  "in_reply_to_status_id" : 214450382179540992,
  "created_at" : "2012-06-17 20:14:02 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 23, 30 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womanisplainasscrazy",
      "indices" : [ 89, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214450585070604290",
  "text" : "A Sunday evening where @BekaBR is trying convince me that Desperate Housewives was good. #womanisplainasscrazy",
  "id" : 214450585070604290,
  "created_at" : "2012-06-17 20:12:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stopbaitingmeyouarebetterthanthis",
      "indices" : [ 37, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214449481259823104",
  "geo" : { },
  "id_str" : "214449834390851586",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR you're about the same age!!! #stopbaitingmeyouarebetterthanthis",
  "id" : 214449834390851586,
  "in_reply_to_status_id" : 214449481259823104,
  "created_at" : "2012-06-17 20:09:59 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214446816157110272",
  "geo" : { },
  "id_str" : "214447084701630465",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR laaaaaaameeeeeeeee :)",
  "id" : 214447084701630465,
  "in_reply_to_status_id" : 214446816157110272,
  "created_at" : "2012-06-17 19:59:03 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214417520797560832",
  "text" : "Guess I better go over and give my Fathers Day present to my Dad....",
  "id" : 214417520797560832,
  "created_at" : "2012-06-17 18:01:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214414945582981121",
  "geo" : { },
  "id_str" : "214417292333821952",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @michaelnsimpson Details we need details - if possible pictures too ;)",
  "id" : 214417292333821952,
  "in_reply_to_status_id" : 214414945582981121,
  "created_at" : "2012-06-17 18:00:40 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214152471642255360",
  "geo" : { },
  "id_str" : "214152588571058176",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard awesome just awesome :D",
  "id" : 214152588571058176,
  "in_reply_to_status_id" : 214152471642255360,
  "created_at" : "2012-06-17 00:28:50 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hewillkillmecomemondaybuttotallyworthit",
      "indices" : [ 20, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214150249625825280",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard yo :D #hewillkillmecomemondaybuttotallyworthit",
  "id" : 214150249625825280,
  "created_at" : "2012-06-17 00:19:32 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214110671388934145",
  "geo" : { },
  "id_str" : "214110877228609536",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson he won't. The endings don't matter :)",
  "id" : 214110877228609536,
  "in_reply_to_status_id" : 214110671388934145,
  "created_at" : "2012-06-16 21:43:05 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214108819003944961",
  "geo" : { },
  "id_str" : "214109664877625344",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson in the following order the ending. Loss. Win. Win. Win (cold war win). Win (street fight). Loss.",
  "id" : 214109664877625344,
  "in_reply_to_status_id" : 214108819003944961,
  "created_at" : "2012-06-16 21:38:16 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214105892029870080",
  "geo" : { },
  "id_str" : "214106059571347456",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson i've certainly a new appreciation for them - that's for fucking sure....",
  "id" : 214106059571347456,
  "in_reply_to_status_id" : 214105892029870080,
  "created_at" : "2012-06-16 21:23:57 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214103477587156993",
  "geo" : { },
  "id_str" : "214105016330502144",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @JulieAnnBrace 'sport' was good. I learned a new metric on how to measure performance... All I am saying. Leave it at that.",
  "id" : 214105016330502144,
  "in_reply_to_status_id" : 214103477587156993,
  "created_at" : "2012-06-16 21:19:48 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatshitcouldhappen",
      "indices" : [ 119, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214103477587156993",
  "geo" : { },
  "id_str" : "214104797396213760",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @JulieAnnBrace that is okay! Losing example: \"my cushions are lovely - it is a woven fabric you know\" #thatshitcouldhappen",
  "id" : 214104797396213760,
  "in_reply_to_status_id" : 214103477587156993,
  "created_at" : "2012-06-16 21:18:56 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214102863926923264",
  "geo" : { },
  "id_str" : "214103047545167872",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @JulieAnnBrace I've given you enough pointers. Fuck sake - just learn how to play! :)",
  "id" : 214103047545167872,
  "in_reply_to_status_id" : 214102863926923264,
  "created_at" : "2012-06-16 21:11:59 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214102205106622464",
  "geo" : { },
  "id_str" : "214102632799801344",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @JulieAnnBrace cushions are alright - everyone needs nice cushions. If you talk to me about the fabric of the cushion...",
  "id" : 214102632799801344,
  "in_reply_to_status_id" : 214102205106622464,
  "created_at" : "2012-06-16 21:10:20 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "remembertowearsomethingslutty",
      "indices" : [ 108, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214100528345530368",
  "geo" : { },
  "id_str" : "214101810858819584",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I shall call down on Monday\/Tuesday then to see the place after work - which ever suits :) #remembertowearsomethingslutty",
  "id" : 214101810858819584,
  "in_reply_to_status_id" : 214100528345530368,
  "created_at" : "2012-06-16 21:07:04 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mancarddown",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214100825507770368",
  "geo" : { },
  "id_str" : "214101516984922112",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley Fuck sake. #mancarddown - Not liking it \/before\/ you even tried it.... It. Is. Rocky.",
  "id" : 214101516984922112,
  "in_reply_to_status_id" : 214100825507770368,
  "created_at" : "2012-06-16 21:05:54 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "steptooitson",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214095193144705025",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @julieannbrace What you all get at Ikea? Mike when shall I see this new abode? :D Watched startup yet? :) #steptooitson",
  "id" : 214095193144705025,
  "created_at" : "2012-06-16 20:40:46 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Dibb",
      "screen_name" : "beandog76",
      "indices" : [ 3, 13 ],
      "id_str" : "27091874",
      "id" : 27091874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214028880456069120",
  "text" : "RT @beandog76: I'm going to invent new HTTP status codes: 508 NOT MY FAULT and 208 WORKS FOR ME",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213782600928608256",
    "text" : "I'm going to invent new HTTP status codes: 508 NOT MY FAULT and 208 WORKS FOR ME",
    "id" : 213782600928608256,
    "created_at" : "2012-06-15 23:58:38 +0000",
    "user" : {
      "name" : "Steve Dibb",
      "screen_name" : "beandog76",
      "protected" : false,
      "id_str" : "27091874",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000577277843\/a3933f3bad713a45ef50049693b9f69e_normal.png",
      "id" : 27091874,
      "verified" : false
    }
  },
  "id" : 214028880456069120,
  "created_at" : "2012-06-16 16:17:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213978758745567232",
  "geo" : { },
  "id_str" : "213983513526018048",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit afraid not. \"software consultant\" from London. Ignoring one for the other is daft. I dunno. Am grumpy today :)",
  "id" : 213983513526018048,
  "in_reply_to_status_id" : 213978758745567232,
  "created_at" : "2012-06-16 13:16:59 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213968136842653696",
  "text" : "I wont name and shame him. But just for the record - both as important as each other. As I said - idiot.",
  "id" : 213968136842653696,
  "created_at" : "2012-06-16 12:15:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213967910048247809",
  "text" : "Had to unfollow someone there due to them saying this \"Programming should be a secondary issue to design re: app development\". Idiot.",
  "id" : 213967910048247809,
  "created_at" : "2012-06-16 12:14:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213929297944125440",
  "text" : "Sir Kenneth Branagh... Thor didn't really damage his credibility then.... Anyway - regardless - nice to see a Belfast fella doing well :)",
  "id" : 213929297944125440,
  "created_at" : "2012-06-16 09:41:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213759674695163904",
  "geo" : { },
  "id_str" : "213760008482074625",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu right - I'll be nicer to you on this thing that I was on FB... Promise..",
  "id" : 213760008482074625,
  "in_reply_to_status_id" : 213759674695163904,
  "created_at" : "2012-06-15 22:28:52 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 130, 140 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213759289066659840",
  "text" : "In the left corner - with the hairy back and speech impediment - weighing in at 300lb Christina \"I was born a boy\" McCullough \/cc @Xtinamccu",
  "id" : 213759289066659840,
  "created_at" : "2012-06-15 22:26:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tascomikillerking",
      "indices" : [ 15, 33 ]
    }, {
      "text" : "tascomititansassemble",
      "indices" : [ 78, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213656527389720576",
  "text" : "Fuck this - no #tascomikillerking this Friday. We are heading to the bar!!!!! #tascomititansassemble",
  "id" : 213656527389720576,
  "created_at" : "2012-06-15 15:37:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213655702454013952",
  "geo" : { },
  "id_str" : "213656051977945088",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams yes - but not from *us* :D",
  "id" : 213656051977945088,
  "in_reply_to_status_id" : 213655702454013952,
  "created_at" : "2012-06-15 15:35:46 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213655476112596993",
  "text" : "OH: The resolution of the pre meeting is that there will be another meeting about the meeting before the final meeting.",
  "id" : 213655476112596993,
  "created_at" : "2012-06-15 15:33:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itwasme",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213652659566166016",
  "text" : "\u201C@michaelnsimpson: OH in the office \"go on, just talk dirty to me... switch your webcam on\"\u201D #itwasme :D",
  "id" : 213652659566166016,
  "created_at" : "2012-06-15 15:22:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noshit",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213652508512489473",
  "text" : "OH: We are having a pre-meeting to discuss the meeting that is setting the agenda for the proper meeting on Tuesday. #noshit",
  "id" : 213652508512489473,
  "created_at" : "2012-06-15 15:21:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 12, 24 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213650916266606592",
  "geo" : { },
  "id_str" : "213651946047938561",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe ask @niall_adams about the trac number.... You will see how dumb it was!",
  "id" : 213651946047938561,
  "in_reply_to_status_id" : 213650916266606592,
  "created_at" : "2012-06-15 15:19:28 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213646275772551168",
  "geo" : { },
  "id_str" : "213650603212144640",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams it was inferred by your edit! I still say it was justified and would stand up in a court of law as the dumbest question ever!",
  "id" : 213650603212144640,
  "in_reply_to_status_id" : 213646275772551168,
  "created_at" : "2012-06-15 15:14:07 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213639203731415041",
  "geo" : { },
  "id_str" : "213639567297884160",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke apparently it might be at some point. In which case there are bigger issues than me saying \"fuck\" - it was warranted!",
  "id" : 213639567297884160,
  "in_reply_to_status_id" : 213639203731415041,
  "created_at" : "2012-06-15 14:30:16 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213638820216840193",
  "geo" : { },
  "id_str" : "213638951506939904",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke of course not :)",
  "id" : 213638951506939904,
  "in_reply_to_status_id" : 213638820216840193,
  "created_at" : "2012-06-15 14:27:49 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 1, 15 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 17, 23 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "epicrant",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213638531468369922",
  "text" : "\u201C@peter_omalley: @swmcc There were actually 5 in it. #epicrant\u201D",
  "id" : 213638531468369922,
  "created_at" : "2012-06-15 14:26:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213633771004633089",
  "text" : "..cursing in a trac is just stupid and reflects badly on me. Making me so angry by asking such a stupid fucking question is unprofessional!",
  "id" : 213633771004633089,
  "created_at" : "2012-06-15 14:07:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213633444847157248",
  "text" : "Someone edited out a comment I made to a trac yesterday. As it was \"unprofessional\"... My reply had 4 fucks in it....",
  "id" : 213633444847157248,
  "created_at" : "2012-06-15 14:05:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 16, 28 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213572905609605120",
  "geo" : { },
  "id_str" : "213573469089173505",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @willemkokke awesome :D How did you get that past security? :)",
  "id" : 213573469089173505,
  "in_reply_to_status_id" : 213572905609605120,
  "created_at" : "2012-06-15 10:07:37 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213569989549101058",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne LOVE IT :D",
  "id" : 213569989549101058,
  "created_at" : "2012-06-15 09:53:48 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 16, 28 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213567965671604224",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @willemkokke Is that your name tag there? :D And that calendar is a bit subtle G... Needs more glitter!!! :D",
  "id" : 213567965671604224,
  "created_at" : "2012-06-15 09:45:45 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 16, 28 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213438148192112642",
  "geo" : { },
  "id_str" : "213438492783546368",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @willemkokke we need money for the quarterly newsletter and the statue we want to erect in Lasy Dixon Park.",
  "id" : 213438492783546368,
  "in_reply_to_status_id" : 213438148192112642,
  "created_at" : "2012-06-15 01:11:16 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 16, 28 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213437285339906048",
  "geo" : { },
  "id_str" : "213437979539148801",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @willemkokke your beautiful too G. Add that with your pure raw awesomeness and your one lab experiment from superhero :)",
  "id" : 213437979539148801,
  "in_reply_to_status_id" : 213437285339906048,
  "created_at" : "2012-06-15 01:09:14 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 16, 28 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213437009442783232",
  "geo" : { },
  "id_str" : "213437447479099392",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @willemkokke there is. I'm the treasurer and co founder. :)",
  "id" : 213437447479099392,
  "in_reply_to_status_id" : 213437009442783232,
  "created_at" : "2012-06-15 01:07:07 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 16, 28 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213436314891202561",
  "geo" : { },
  "id_str" : "213436535595483137",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @willemkokke its Willem - and yes, why yes he is :)",
  "id" : 213436535595483137,
  "in_reply_to_status_id" : 213436314891202561,
  "created_at" : "2012-06-15 01:03:30 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 78, 90 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213436389306535936",
  "text" : "My sleep pattern is all fucked up now.. Think its time to give a shout out to @niall_adams - WAKEY WAKEY ASSHOLE!!!! :D Much Love - Stevie!",
  "id" : 213436389306535936,
  "created_at" : "2012-06-15 01:02:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213435450042499072",
  "geo" : { },
  "id_str" : "213435778875932672",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Feck - must be bad :( Well just imagine how happy you will be getting back to science :)",
  "id" : 213435778875932672,
  "in_reply_to_status_id" : 213435450042499072,
  "created_at" : "2012-06-15 01:00:29 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 13, 28 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213434749023297536",
  "geo" : { },
  "id_str" : "213435668779646976",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @georgina_milne What you doing up at this time you beautiful dutch bastard?",
  "id" : 213435668779646976,
  "in_reply_to_status_id" : 213434749023297536,
  "created_at" : "2012-06-15 01:00:03 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213431922825756672",
  "geo" : { },
  "id_str" : "213432103789019136",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne not long till its all over now though :D",
  "id" : 213432103789019136,
  "in_reply_to_status_id" : 213431922825756672,
  "created_at" : "2012-06-15 00:45:53 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213431177577635840",
  "geo" : { },
  "id_str" : "213431397061369856",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne at 0142hrs? :D Love it :) You not got school tomorrow morning - I do - just can't sleep! :(",
  "id" : 213431397061369856,
  "in_reply_to_status_id" : 213431177577635840,
  "created_at" : "2012-06-15 00:43:05 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213426595879333890",
  "geo" : { },
  "id_str" : "213426713890271233",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne explain pls :)",
  "id" : 213426713890271233,
  "in_reply_to_status_id" : 213426595879333890,
  "created_at" : "2012-06-15 00:24:28 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manchallange",
      "indices" : [ 62, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213372257605652480",
  "geo" : { },
  "id_str" : "213386403021721600",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson a rocky quiz all next week... #manchallange",
  "id" : 213386403021721600,
  "in_reply_to_status_id" : 213372257605652480,
  "created_at" : "2012-06-14 21:44:17 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213372257605652480",
  "geo" : { },
  "id_str" : "213386280204124160",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson",
  "id" : 213386280204124160,
  "in_reply_to_status_id" : 213372257605652480,
  "created_at" : "2012-06-14 21:43:48 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anjali Guptara Khera",
      "screen_name" : "anjaliguptara",
      "indices" : [ 3, 17 ],
      "id_str" : "208513962",
      "id" : 208513962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trafficking",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213383497916760064",
  "text" : "RT @anjaliguptara: Human #trafficking an escalating crime across the world, considered as lucrative as drug smuggling &amp; arms dealing ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "trafficking",
        "indices" : [ 6, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/5D59zkdf",
        "expanded_url" : "http:\/\/news.yahoo.com\/lexisnexis-introduces-human-trafficking-awareness-index-080247871.html",
        "display_url" : "news.yahoo.com\/lexisnexis-int\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "213373599690661892",
    "text" : "Human #trafficking an escalating crime across the world, considered as lucrative as drug smuggling &amp; arms dealing - http:\/\/t.co\/5D59zkdf",
    "id" : 213373599690661892,
    "created_at" : "2012-06-14 20:53:25 +0000",
    "user" : {
      "name" : "Anjali Guptara Khera",
      "screen_name" : "anjaliguptara",
      "protected" : false,
      "id_str" : "208513962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268709188\/anja-peacock_normal.jpg",
      "id" : 208513962,
      "verified" : false
    }
  },
  "id" : 213383497916760064,
  "created_at" : "2012-06-14 21:32:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 12, 26 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shakeitsista",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213373838908600320",
  "geo" : { },
  "id_str" : "213381063886635009",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @No_Underscore Yup. #shakeitsista!",
  "id" : 213381063886635009,
  "in_reply_to_status_id" : 213373838908600320,
  "created_at" : "2012-06-14 21:23:04 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213370483461197827",
  "geo" : { },
  "id_str" : "213370615514673152",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson me either but I am happy enough in here. Will go home now I think. Just fucked about mostly :)",
  "id" : 213370615514673152,
  "in_reply_to_status_id" : 213370483461197827,
  "created_at" : "2012-06-14 20:41:33 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 12, 26 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213369103681990657",
  "geo" : { },
  "id_str" : "213370362140954624",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @no_underscore 22nd September.... According my records.. But on a serious note - congrats on doing so well :D",
  "id" : 213370362140954624,
  "in_reply_to_status_id" : 213369103681990657,
  "created_at" : "2012-06-14 20:40:33 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213360930644430848",
  "geo" : { },
  "id_str" : "213363043466346496",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson i'm outta here.... as soon as I get this last column did and done :D",
  "id" : 213363043466346496,
  "in_reply_to_status_id" : 213360930644430848,
  "created_at" : "2012-06-14 20:11:28 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 22, 36 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213352003504578560",
  "text" : "Just of note.. Me and @jenporterhall just got out witted by an 11 year old :D Not really surprising when you think about it though...",
  "id" : 213352003504578560,
  "created_at" : "2012-06-14 19:27:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213269969956380672",
  "geo" : { },
  "id_str" : "213306290389270529",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll pic or stfu :D",
  "id" : 213306290389270529,
  "in_reply_to_status_id" : 213269969956380672,
  "created_at" : "2012-06-14 16:25:57 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213027322092195840",
  "geo" : { },
  "id_str" : "213213851225829376",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne oh I would but am busy :( But let me know how you get on! And as always good luck :D",
  "id" : 213213851225829376,
  "in_reply_to_status_id" : 213027322092195840,
  "created_at" : "2012-06-14 10:18:38 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 129, 137 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213212557882826753",
  "text" : "That moment when the year placement student notices that not only he is the most mature in the office but also the coolest! \/cc @@HaVoCT5",
  "id" : 213212557882826753,
  "created_at" : "2012-06-14 10:13:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/IrJELf29",
      "expanded_url" : "http:\/\/www.any.do\/",
      "display_url" : "any.do"
    } ]
  },
  "geo" : { },
  "id_str" : "213209240691679234",
  "text" : "Any.DO - lovely app - http:\/\/t.co\/IrJELf29",
  "id" : 213209240691679234,
  "created_at" : "2012-06-14 10:00:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213166811263410176",
  "text" : "Epic sleep. Epic.",
  "id" : 213166811263410176,
  "created_at" : "2012-06-14 07:11:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Shaw",
      "screen_name" : "dshaw",
      "indices" : [ 3, 9 ],
      "id_str" : "806757",
      "id" : 806757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213166601283973120",
  "text" : "RT @dshaw: Google's fucked.\n\nSearched for \"Matt Cain\" and got a Wikipedia article.\n\nSearched Twitter and found a link to live coverage a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213133024924147712",
    "text" : "Google's fucked.\n\nSearched for \"Matt Cain\" and got a Wikipedia article.\n\nSearched Twitter and found a link to live coverage and saw it.",
    "id" : 213133024924147712,
    "created_at" : "2012-06-14 04:57:27 +0000",
    "user" : {
      "name" : "Daniel Shaw",
      "screen_name" : "dshaw",
      "protected" : false,
      "id_str" : "806757",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1552591406\/angry_unicorn_normal.png",
      "id" : 806757,
      "verified" : false
    }
  },
  "id" : 213166601283973120,
  "created_at" : "2012-06-14 07:10:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "indices" : [ 0, 10 ],
      "id_str" : "199486205",
      "id" : 199486205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212933263109529600",
  "geo" : { },
  "id_str" : "212934472079904768",
  "in_reply_to_user_id" : 199486205,
  "text" : "@AoifeB155 :D",
  "id" : 212934472079904768,
  "in_reply_to_status_id" : 212933263109529600,
  "created_at" : "2012-06-13 15:48:28 +0000",
  "in_reply_to_screen_name" : "AoifeB155",
  "in_reply_to_user_id_str" : "199486205",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212932779795677184",
  "text" : "Come 1700hrs I am heading home. By 1730 I want to be in bed catching 40 winks.. and yeah - I spelt that right ;)",
  "id" : 212932779795677184,
  "created_at" : "2012-06-13 15:41:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212898673556856832",
  "text" : "I can't be sure - but I'd say I am about 97% caffeine today.",
  "id" : 212898673556856832,
  "created_at" : "2012-06-13 13:26:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 0, 11 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212897834272423936",
  "geo" : { },
  "id_str" : "212898202716864512",
  "in_reply_to_user_id" : 5932682,
  "text" : "@davidjrice this is almost as mad as the time you said about getting pull requests on github was equal (or better) to a weekend in vegas!",
  "id" : 212898202716864512,
  "in_reply_to_status_id" : 212897834272423936,
  "created_at" : "2012-06-13 13:24:21 +0000",
  "in_reply_to_screen_name" : "davidjrice",
  "in_reply_to_user_id_str" : "5932682",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 0, 11 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212897834272423936",
  "geo" : { },
  "id_str" : "212898037926854656",
  "in_reply_to_user_id" : 5932682,
  "text" : "@davidjrice I really hope that someone has hacked into your account or someone in work is playing a trick on you.",
  "id" : 212898037926854656,
  "in_reply_to_status_id" : 212897834272423936,
  "created_at" : "2012-06-13 13:23:42 +0000",
  "in_reply_to_screen_name" : "davidjrice",
  "in_reply_to_user_id_str" : "5932682",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212830280057229312",
  "geo" : { },
  "id_str" : "212830667430572032",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor said that homosexuality is the same as fucking an animal.",
  "id" : 212830667430572032,
  "in_reply_to_status_id" : 212830280057229312,
  "created_at" : "2012-06-13 08:55:59 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212828292716314624",
  "geo" : { },
  "id_str" : "212829260828774400",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams nah - i bet you i could write it word for word what was said. Just thought more of him to be honest - am pretty shocked.",
  "id" : 212829260828774400,
  "in_reply_to_status_id" : 212828292716314624,
  "created_at" : "2012-06-13 08:50:24 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "indices" : [ 3, 10 ],
      "id_str" : "14060295",
      "id" : 14060295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212829112623050753",
  "text" : "RT @cimota: Don't like the bigoted rhetoric spouted by our politicians? You voted them in, you can vote them out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.7546904379, -6.0032434748 ]
    },
    "id_str" : "212828896624775168",
    "text" : "Don't like the bigoted rhetoric spouted by our politicians? You voted them in, you can vote them out.",
    "id" : 212828896624775168,
    "created_at" : "2012-06-13 08:48:57 +0000",
    "user" : {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "protected" : false,
      "id_str" : "14060295",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2844403973\/36986f401fc4df14d5abe8b38c1301cc_normal.jpeg",
      "id" : 14060295,
      "verified" : false
    }
  },
  "id" : 212829112623050753,
  "created_at" : "2012-06-13 08:49:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212829041521197056",
  "text" : "Way to Ken Maginnis you fucking idiot. I respected him up until now...",
  "id" : 212829041521197056,
  "created_at" : "2012-06-13 08:49:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212827024534945792",
  "geo" : { },
  "id_str" : "212827950423351296",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams you serious?",
  "id" : 212827950423351296,
  "in_reply_to_status_id" : 212827024534945792,
  "created_at" : "2012-06-13 08:45:12 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212816005267865600",
  "geo" : { },
  "id_str" : "212825152159887360",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you'll do grand. Good luck :D",
  "id" : 212825152159887360,
  "in_reply_to_status_id" : 212816005267865600,
  "created_at" : "2012-06-13 08:34:05 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212825092768538626",
  "text" : "Right people. Whoever put the \"it is Thursay\" deal in my head - take it out please.",
  "id" : 212825092768538626,
  "created_at" : "2012-06-13 08:33:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212662983686504449",
  "geo" : { },
  "id_str" : "212664073807069185",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard I approve of your last tweet.....",
  "id" : 212664073807069185,
  "in_reply_to_status_id" : 212662983686504449,
  "created_at" : "2012-06-12 21:54:00 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212658464600756225",
  "text" : "Just saw the season trailer for Star Wars The Clone Wars... Hope no one asks me to stand up for a few minutes. Yes, that good!",
  "id" : 212658464600756225,
  "created_at" : "2012-06-12 21:31:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212643659659739136",
  "geo" : { },
  "id_str" : "212645895731294210",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid it's just I have thing for remembering faces.",
  "id" : 212645895731294210,
  "in_reply_to_status_id" : 212643659659739136,
  "created_at" : "2012-06-12 20:41:46 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212641214133047297",
  "geo" : { },
  "id_str" : "212642656516456449",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid you don't need a phd for tgat. Just two eyes. Fucj, even one would do - two is for depth perception ;)",
  "id" : 212642656516456449,
  "in_reply_to_status_id" : 212641214133047297,
  "created_at" : "2012-06-12 20:28:54 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212638264283250688",
  "geo" : { },
  "id_str" : "212641067630198785",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid you have a doctorate don't you? ;)",
  "id" : 212641067630198785,
  "in_reply_to_status_id" : 212638264283250688,
  "created_at" : "2012-06-12 20:22:35 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212636277433040897",
  "text" : "OH: Tab your way to victory....",
  "id" : 212636277433040897,
  "created_at" : "2012-06-12 20:03:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212612540755222528",
  "geo" : { },
  "id_str" : "212635928018169856",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid you fucking serious? In other news - Charlie Sheen has a famous Dad!!",
  "id" : 212635928018169856,
  "in_reply_to_status_id" : 212612540755222528,
  "created_at" : "2012-06-12 20:02:10 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 14, 23 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "guestweek",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212589156411510785",
  "text" : "Dangerous!!! \u201C@climagic: sudo rm -Rf how\/ # remove directory and subdirectories plus any existing files all at once #guestweek\u201D",
  "id" : 212589156411510785,
  "created_at" : "2012-06-12 16:56:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212572668040462337",
  "text" : "OH: \"This conversation is hard work and so has terminated\"",
  "id" : 212572668040462337,
  "created_at" : "2012-06-12 15:50:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212271902528503808",
  "geo" : { },
  "id_str" : "212273655500111873",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson is that a yes then sir?",
  "id" : 212273655500111873,
  "in_reply_to_status_id" : 212271902528503808,
  "created_at" : "2012-06-11 20:02:37 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212265602998476802",
  "geo" : { },
  "id_str" : "212266466366603267",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson of course it has.",
  "id" : 212266466366603267,
  "in_reply_to_status_id" : 212265602998476802,
  "created_at" : "2012-06-11 19:34:03 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "propermanchallengefridaylikeoldtimes",
      "indices" : [ 85, 122 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212258841411325952",
  "geo" : { },
  "id_str" : "212259318102376448",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson Think we should do the challenge this Friday re: the mushroom soup? #propermanchallengefridaylikeoldtimes",
  "id" : 212259318102376448,
  "in_reply_to_status_id" : 212258841411325952,
  "created_at" : "2012-06-11 19:05:39 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212256819635167233",
  "text" : "I wonder how @michaelnsimpson is getting on in his new abode. Probably stomping about in his pants and eating ham... Oh.. that's me!",
  "id" : 212256819635167233,
  "created_at" : "2012-06-11 18:55:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212227588863705090",
  "geo" : { },
  "id_str" : "212234649185959937",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @RickyHassard that was pretty awesome. The only thing that helped us through such an utterly shit Monday!",
  "id" : 212234649185959937,
  "in_reply_to_status_id" : 212227588863705090,
  "created_at" : "2012-06-11 17:27:38 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212136524643434496",
  "text" : "You'd think it'd be easy to get a cup of tea in here.... Grrrrrrrrrrrr",
  "id" : 212136524643434496,
  "created_at" : "2012-06-11 10:57:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212099700684357632",
  "geo" : { },
  "id_str" : "212099854325907456",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley i'm gonna start killing people if they don't get the fuck off this floor!!!! It is a Monday FFS!",
  "id" : 212099854325907456,
  "in_reply_to_status_id" : 212099700684357632,
  "created_at" : "2012-06-11 08:32:00 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 54, 67 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/212095538068328448\/photo\/1",
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/oyiqUmHZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AvGDxKVCEAAfcKs.jpg",
      "id_str" : "212095538072522752",
      "id" : 212095538072522752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AvGDxKVCEAAfcKs.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oyiqUmHZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212095538068328448",
  "text" : "Snoopy got a friend :) Introducing Mexican Snoopy c\/o @Paul_Moffett http:\/\/t.co\/oyiqUmHZ",
  "id" : 212095538068328448,
  "created_at" : "2012-06-11 08:14:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211940938677891073",
  "geo" : { },
  "id_str" : "211954312782422017",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit Why yes, yes it is :)",
  "id" : 211954312782422017,
  "in_reply_to_status_id" : 211940938677891073,
  "created_at" : "2012-06-10 22:53:40 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211934196476817409",
  "geo" : { },
  "id_str" : "211936514194685955",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit &lt;&lt;&lt; 2 awesome peeps :D Also Steve - where is your blog post. I've given up on mine...",
  "id" : 211936514194685955,
  "in_reply_to_status_id" : 211934196476817409,
  "created_at" : "2012-06-10 21:42:57 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211910563557679105",
  "geo" : { },
  "id_str" : "211921207686201344",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq awesome.. Just awesome.",
  "id" : 211921207686201344,
  "in_reply_to_status_id" : 211910563557679105,
  "created_at" : "2012-06-10 20:42:07 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 6, 19 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ihateit",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211882268317331456",
  "text" : "Seems @RickyHassard has been replaced as my nemesis by that mother fucking lawnmower!!! #ihateit",
  "id" : 211882268317331456,
  "created_at" : "2012-06-10 18:07:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211873123228852226",
  "text" : "I really wish I liked football. Just don't get it I guess. Should probably now the lawn...",
  "id" : 211873123228852226,
  "created_at" : "2012-06-10 17:31:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "indices" : [ 0, 7 ],
      "id_str" : "14060295",
      "id" : 14060295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211764125133582337",
  "geo" : { },
  "id_str" : "211771691712520192",
  "in_reply_to_user_id" : 14060295,
  "text" : "@cimota and why shouldn't it. It has to be one of the most EPIC films ever made!",
  "id" : 211771691712520192,
  "in_reply_to_status_id" : 211764125133582337,
  "created_at" : "2012-06-10 10:48:00 +0000",
  "in_reply_to_screen_name" : "cimota",
  "in_reply_to_user_id_str" : "14060295",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211738320852627458",
  "geo" : { },
  "id_str" : "211738582166159360",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley Hmmmmm I think you've beaten me.... Well done :)",
  "id" : 211738582166159360,
  "in_reply_to_status_id" : 211738320852627458,
  "created_at" : "2012-06-10 08:36:26 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melanie Sykes",
      "screen_name" : "MsMelanieSykes",
      "indices" : [ 3, 18 ],
      "id_str" : "321929473",
      "id" : 321929473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211553814250143744",
  "text" : "RT @MsMelanieSykes: Fuck fuck fuck!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211552344243044355",
    "text" : "Fuck fuck fuck!!!",
    "id" : 211552344243044355,
    "created_at" : "2012-06-09 20:16:23 +0000",
    "user" : {
      "name" : "Melanie Sykes",
      "screen_name" : "MsMelanieSykes",
      "protected" : false,
      "id_str" : "321929473",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000316696911\/364762cf039a5014f7dbce4163fd1814_normal.jpeg",
      "id" : 321929473,
      "verified" : true
    }
  },
  "id" : 211553814250143744,
  "created_at" : "2012-06-09 20:22:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211543837187907585",
  "geo" : { },
  "id_str" : "211544966881742849",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams that's the tagline for the next new server :D",
  "id" : 211544966881742849,
  "in_reply_to_status_id" : 211543837187907585,
  "created_at" : "2012-06-09 19:47:05 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211540512728035328",
  "geo" : { },
  "id_str" : "211540646954147840",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I am open to offers..",
  "id" : 211540646954147840,
  "in_reply_to_status_id" : 211540512728035328,
  "created_at" : "2012-06-09 19:29:55 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211539335034572801",
  "geo" : { },
  "id_str" : "211539706888982528",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I can do that on me push bike but my loose change goes all over the place :(",
  "id" : 211539706888982528,
  "in_reply_to_status_id" : 211539335034572801,
  "created_at" : "2012-06-09 19:26:10 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "British People",
      "screen_name" : "itsohsobritish",
      "indices" : [ 3, 18 ],
      "id_str" : "282122629",
      "id" : 282122629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211464262504292353",
  "text" : "RT @itsohsobritish: INSTALLING SUMMER..... \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591 45% DONE. Installation failed. 404 error: Season not valid in UK",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211159973764399105",
    "text" : "INSTALLING SUMMER..... \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591 45% DONE. Installation failed. 404 error: Season not valid in UK",
    "id" : 211159973764399105,
    "created_at" : "2012-06-08 18:17:15 +0000",
    "user" : {
      "name" : "British People",
      "screen_name" : "itsohsobritish",
      "protected" : false,
      "id_str" : "282122629",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1328654836\/BritishFlag_normal.jpg",
      "id" : 282122629,
      "verified" : false
    }
  },
  "id" : 211464262504292353,
  "created_at" : "2012-06-09 14:26:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 59, 74 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rainisawful",
      "indices" : [ 75, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211442710001881088",
  "text" : "This weather is crap. Only person mad enough to like it is @Georgina_Milne #rainisawful",
  "id" : 211442710001881088,
  "created_at" : "2012-06-09 13:00:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211434335436406785",
  "geo" : { },
  "id_str" : "211441893668683776",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid I didn't that one through, did I :)",
  "id" : 211441893668683776,
  "in_reply_to_status_id" : 211434335436406785,
  "created_at" : "2012-06-09 12:57:30 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/211433607212961792\/photo\/1",
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/hWbXEoy3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Au8pvtvCEAE0C20.jpg",
      "id_str" : "211433607217156097",
      "id" : 211433607217156097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Au8pvtvCEAE0C20.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/hWbXEoy3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211433607212961792",
  "text" : "Fucking Raaaaaaaa!!!!! http:\/\/t.co\/hWbXEoy3",
  "id" : 211433607212961792,
  "created_at" : "2012-06-09 12:24:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211380210187239424",
  "text" : "What sort of fool forgot to get bacon yesterday in Tesco?? :(",
  "id" : 211380210187239424,
  "created_at" : "2012-06-09 08:52:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211148177116626944",
  "text" : "First time in a long long time (not since my @maildistiller days) I am excited about going back to work on Monday on a Friday evening :)",
  "id" : 211148177116626944,
  "created_at" : "2012-06-08 17:30:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsthatmakemelaugh",
      "indices" : [ 28, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211113354134175744",
  "text" : "Being called a \"fuck head\". #thingsthatmakemelaugh",
  "id" : 211113354134175744,
  "created_at" : "2012-06-08 15:12:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lough Shore",
      "screen_name" : "loughshore",
      "indices" : [ 3, 14 ],
      "id_str" : "215992556",
      "id" : 215992556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/zZFHQgz3",
      "expanded_url" : "http:\/\/bit.ly\/MRq90i",
      "display_url" : "bit.ly\/MRq90i"
    } ]
  },
  "geo" : { },
  "id_str" : "211109773905633280",
  "text" : "RT @loughshore: Belfast's JamPot wins Microsoft European tech start-up award http:\/\/t.co\/zZFHQgz3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/zZFHQgz3",
        "expanded_url" : "http:\/\/bit.ly\/MRq90i",
        "display_url" : "bit.ly\/MRq90i"
      } ]
    },
    "geo" : { },
    "id_str" : "211109087503581184",
    "text" : "Belfast's JamPot wins Microsoft European tech start-up award http:\/\/t.co\/zZFHQgz3",
    "id" : 211109087503581184,
    "created_at" : "2012-06-08 14:55:03 +0000",
    "user" : {
      "name" : "Lough Shore",
      "screen_name" : "loughshore",
      "protected" : false,
      "id_str" : "215992556",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2289162078\/tfmy6pbzxb24ue7094hz_normal.jpeg",
      "id" : 215992556,
      "verified" : false
    }
  },
  "id" : 211109773905633280,
  "created_at" : "2012-06-08 14:57:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211062927493578753",
  "text" : "Getting older is odd.... I now like smoked salmon...",
  "id" : 211062927493578753,
  "created_at" : "2012-06-08 11:51:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211046113388670976",
  "text" : "OH: You'd come back with a burnt dick",
  "id" : 211046113388670976,
  "created_at" : "2012-06-08 10:44:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211044934558547969",
  "geo" : { },
  "id_str" : "211045256479768576",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I try my best not to disappoint. Same old Kerr. Wanker.",
  "id" : 211045256479768576,
  "in_reply_to_status_id" : 211044934558547969,
  "created_at" : "2012-06-08 10:41:24 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/dW6t4EoM",
      "expanded_url" : "http:\/\/tom.preston-werner.com\/2010\/08\/23\/readme-driven-development.html",
      "display_url" : "tom.preston-werner.com\/2010\/08\/23\/rea\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "211040813675851776",
  "geo" : { },
  "id_str" : "211044598666113024",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I use this shit now for my personal stuff - http:\/\/t.co\/dW6t4EoM",
  "id" : 211044598666113024,
  "in_reply_to_status_id" : 211040813675851776,
  "created_at" : "2012-06-08 10:38:47 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211043678255460352",
  "geo" : { },
  "id_str" : "211044383980662785",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I moved onto pastures new by that stage due to web 1.0 bubble bursting :)",
  "id" : 211044383980662785,
  "in_reply_to_status_id" : 211043678255460352,
  "created_at" : "2012-06-08 10:37:56 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211040813675851776",
  "geo" : { },
  "id_str" : "211043173500334080",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist you mean there was a time when we 'developed' pre 2005\/6??? GET THE FUCK OUT :) Next you'll be saying you did it in frameworks!",
  "id" : 211043173500334080,
  "in_reply_to_status_id" : 211040813675851776,
  "created_at" : "2012-06-08 10:33:08 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tascomifridaysarentthesamewithouthim",
      "indices" : [ 33, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211028176351150081",
  "geo" : { },
  "id_str" : "211029146380410880",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson PS I miss Mike! #tascomifridaysarentthesamewithouthim",
  "id" : 211029146380410880,
  "in_reply_to_status_id" : 211028176351150081,
  "created_at" : "2012-06-08 09:37:23 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211028176351150081",
  "geo" : { },
  "id_str" : "211029067393273856",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams huh? Screw you two then. You were gonna be my Lane and Don to my Roger. Assholes!",
  "id" : 211029067393273856,
  "in_reply_to_status_id" : 211028176351150081,
  "created_at" : "2012-06-08 09:37:05 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211026201454710784",
  "text" : "Why are local companies telling me about the twitter logo change? I sign up to local companies to hear their news not twitters!",
  "id" : 211026201454710784,
  "created_at" : "2012-06-08 09:25:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ivedoneitbutiamprettysoitdoesntcount",
      "indices" : [ 60, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211012104512225281",
  "geo" : { },
  "id_str" : "211013977919062016",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp easier to forget your laptop than you think... #ivedoneitbutiamprettysoitdoesntcount",
  "id" : 211013977919062016,
  "in_reply_to_status_id" : 211012104512225281,
  "created_at" : "2012-06-08 08:37:07 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/210849068468015104\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/17oqQdHz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Au0WHFOCEAEJwxT.png",
      "id_str" : "210849068472209409",
      "id" : 210849068472209409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Au0WHFOCEAEJwxT.png",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 792
      } ],
      "display_url" : "pic.twitter.com\/17oqQdHz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210849068468015104",
  "text" : "And they wonder why there is 'piracy' about. FWIW 1.50 per episode to watch - on top of my Sky subscription. Hmmm.. http:\/\/t.co\/17oqQdHz",
  "id" : 210849068468015104,
  "created_at" : "2012-06-07 21:41:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tascomikillerking",
      "indices" : [ 51, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210830893005283328",
  "text" : "Just remembered that we have two new plebs to play #tascomikillerking with tomorrow... First league match in two weeks. Snoopybot can't play",
  "id" : 210830893005283328,
  "created_at" : "2012-06-07 20:29:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 32, 45 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210823513362268161",
  "geo" : { },
  "id_str" : "210826899251920897",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson @RickyHassard which makes you all (bar Nail) traitors. You seen the IRC topic \"Don't high five the mike\"",
  "id" : 210826899251920897,
  "in_reply_to_status_id" : 210823513362268161,
  "created_at" : "2012-06-07 20:13:44 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210822259743526914",
  "text" : "Am watching Chasing Madoff. They turned a rather interesting subject and turned it into a bore fest.",
  "id" : 210822259743526914,
  "created_at" : "2012-06-07 19:55:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    }, {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 10, 21 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210795395482259457",
  "geo" : { },
  "id_str" : "210795777092632577",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr @davidjrice I agree with Dave. If you don't like it build it yourself - or pay more somewhere else. Simples.",
  "id" : 210795777092632577,
  "in_reply_to_status_id" : 210795395482259457,
  "created_at" : "2012-06-07 18:10:04 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "indices" : [ 0, 10 ],
      "id_str" : "199486205",
      "id" : 199486205
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 11, 23 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210791858706726912",
  "geo" : { },
  "id_str" : "210792394843631616",
  "in_reply_to_user_id" : 199486205,
  "text" : "@AoifeB155 @niall_adams Not dissing the brit.. Dissing The Nail - The Nail Adams :)",
  "id" : 210792394843631616,
  "in_reply_to_status_id" : 210791858706726912,
  "created_at" : "2012-06-07 17:56:37 +0000",
  "in_reply_to_screen_name" : "AoifeB155",
  "in_reply_to_user_id_str" : "199486205",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "indices" : [ 3, 13 ],
      "id_str" : "199486205",
      "id" : 199486205
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 15, 21 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 22, 34 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210792292691357696",
  "text" : "RT @AoifeB155: @swmcc @niall_adams Dont diss the Brit!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Niall Adams",
        "screen_name" : "niall_adams",
        "indices" : [ 7, 19 ],
        "id_str" : "28624459",
        "id" : 28624459
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "210791264059260929",
    "geo" : { },
    "id_str" : "210791858706726912",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @niall_adams Dont diss the Brit!",
    "id" : 210791858706726912,
    "in_reply_to_status_id" : 210791264059260929,
    "created_at" : "2012-06-07 17:54:30 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "protected" : false,
      "id_str" : "199486205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000615046755\/0bf35b5f6b4c769c187ef27a502beb25_normal.jpeg",
      "id" : 199486205,
      "verified" : false
    }
  },
  "id" : 210792292691357696,
  "created_at" : "2012-06-07 17:56:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 36, 48 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/210791264059260929\/photo\/1",
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/ogWEIsla",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuzhibBCAAAjQ0G.jpg",
      "id_str" : "210791264063455232",
      "id" : 210791264063455232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuzhibBCAAAjQ0G.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/ogWEIsla"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210791264059260929",
  "text" : "He's deffo not helping himself. \/cc @niall_adams http:\/\/t.co\/ogWEIsla",
  "id" : 210791264059260929,
  "created_at" : "2012-06-07 17:52:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 24, 36 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/210770129930305537\/photo\/1",
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/N2PM3Z6a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuzOUQQCQAAUIn3.jpg",
      "id_str" : "210770129934499840",
      "id" : 210770129934499840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuzOUQQCQAAUIn3.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/N2PM3Z6a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210770129930305537",
  "text" : "There are no words. \/cc @niall_adams http:\/\/t.co\/N2PM3Z6a",
  "id" : 210770129930305537,
  "created_at" : "2012-06-07 16:28:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 24, 37 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210759520119570433",
  "geo" : { },
  "id_str" : "210761271484755968",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson was to @stevebiscuit :)",
  "id" : 210761271484755968,
  "in_reply_to_status_id" : 210759520119570433,
  "created_at" : "2012-06-07 15:52:57 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210758280413327361",
  "text" : ".. deadline is sunday 3pm :D",
  "id" : 210758280413327361,
  "created_at" : "2012-06-07 15:41:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210757795836985344",
  "geo" : { },
  "id_str" : "210758236066947073",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit do it - interested to see others doing stuff :) If you blog about it I guess I should too.. Probably at the same time - so...",
  "id" : 210758236066947073,
  "in_reply_to_status_id" : 210757795836985344,
  "created_at" : "2012-06-07 15:40:53 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210757214980419584",
  "geo" : { },
  "id_str" : "210757503150071812",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit i've been using vagrant &amp; chef for my own stuff - I love it :D Get the blog post up boyo - me wants to read it :)",
  "id" : 210757503150071812,
  "in_reply_to_status_id" : 210757214980419584,
  "created_at" : "2012-06-07 15:37:59 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210756431199223808",
  "geo" : { },
  "id_str" : "210756778693115905",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit ssshhhhhh!!!!!! Drives me nuts everytime.",
  "id" : 210756778693115905,
  "in_reply_to_status_id" : 210756431199223808,
  "created_at" : "2012-06-07 15:35:06 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210754510518366208",
  "text" : "Little part of me died there getting a mac set up as a dev enviro.",
  "id" : 210754510518366208,
  "created_at" : "2012-06-07 15:26:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 38, 51 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/210729994513678336\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/nI5nNOzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Auyp0EMCAAAHLvL.png",
      "id_str" : "210729994522066944",
      "id" : 210729994522066944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Auyp0EMCAAAHLvL.png",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 737,
        "resize" : "fit",
        "w" : 748
      }, {
        "h" : 737,
        "resize" : "fit",
        "w" : 748
      } ],
      "display_url" : "pic.twitter.com\/nI5nNOzR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210729994513678336",
  "text" : "Even Stalin had to start somewhere... @marcus_r1975 will fear SnoopyBot at some stage... It is still young. http:\/\/t.co\/nI5nNOzR",
  "id" : 210729994513678336,
  "created_at" : "2012-06-07 13:48:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210717967024001024",
  "text" : "OH: \"There is no legal definition for what a furnished flat should be\"",
  "id" : 210717967024001024,
  "created_at" : "2012-06-07 13:00:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reboot",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210629163382603777",
  "text" : "Reboot day... Wonder if my nemisis and I can keep it together today... He broke the truce yesterday... #reboot",
  "id" : 210629163382603777,
  "created_at" : "2012-06-07 07:08:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mar\u00EDa Basia ",
      "screen_name" : "maria_basia",
      "indices" : [ 0, 12 ],
      "id_str" : "235508724",
      "id" : 235508724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210612567666724866",
  "geo" : { },
  "id_str" : "210613006269296640",
  "in_reply_to_user_id" : 235508724,
  "text" : "@maria_basia grrrrrrrrrr tooo hot.. you do not appreciate it :)",
  "id" : 210613006269296640,
  "in_reply_to_status_id" : 210612567666724866,
  "created_at" : "2012-06-07 06:03:48 +0000",
  "in_reply_to_screen_name" : "maria_basia",
  "in_reply_to_user_id_str" : "235508724",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 12, 20 ],
      "id_str" : "79820731",
      "id" : 79820731
    }, {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 53, 66 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210489800296374272",
  "text" : "Hacking the @tascomi bot.. Its gonna have revenge on @marcus_r1975.. It will grow strong! :)",
  "id" : 210489800296374272,
  "created_at" : "2012-06-06 21:54:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210486019479445504",
  "text" : "I reopen my facebook every now and again. Only to remember why I close it every so often. Most of the ppl on it are fuckwits! *closed*",
  "id" : 210486019479445504,
  "created_at" : "2012-06-06 21:39:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210426705226121217",
  "geo" : { },
  "id_str" : "210432917690777602",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson awesome. Yay - Mike and his 8 minute commute :)",
  "id" : 210432917690777602,
  "in_reply_to_status_id" : 210426705226121217,
  "created_at" : "2012-06-06 18:08:11 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210401119057358849",
  "geo" : { },
  "id_str" : "210402376274821120",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR you are a sick sick sick person!",
  "id" : 210402376274821120,
  "in_reply_to_status_id" : 210401119057358849,
  "created_at" : "2012-06-06 16:06:50 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 17, 33 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210357621880918016",
  "text" : "Just learnt that @michaelnsimpson is off on Friday - this does not please me at all!",
  "id" : 210357621880918016,
  "created_at" : "2012-06-06 13:08:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Wales",
      "screen_name" : "jimmy_wales",
      "indices" : [ 3, 15 ],
      "id_str" : "49793",
      "id" : 49793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210325711536394241",
  "text" : "RT @jimmy_wales: I want to legally purchase Game of Thrones season 2 to watch on planes as I travel.  What kind of stupid industry refus ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210270085414268928",
    "text" : "I want to legally purchase Game of Thrones season 2 to watch on planes as I travel.  What kind of stupid industry refuses money?",
    "id" : 210270085414268928,
    "created_at" : "2012-06-06 07:21:09 +0000",
    "user" : {
      "name" : "Jimmy Wales",
      "screen_name" : "jimmy_wales",
      "protected" : false,
      "id_str" : "49793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/15944612\/small_sepia_jimbo_normal.jpg",
      "id" : 49793,
      "verified" : true
    }
  },
  "id" : 210325711536394241,
  "created_at" : "2012-06-06 11:02:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 50, 64 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210307319366561792",
  "geo" : { },
  "id_str" : "210315057219907584",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe as you should be!!! as you should be! \/cc @ChrisKnowles_",
  "id" : 210315057219907584,
  "in_reply_to_status_id" : 210307319366561792,
  "created_at" : "2012-06-06 10:19:51 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210139037644759040",
  "geo" : { },
  "id_str" : "210139196650827777",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues this pleases me greatly :) I need to discuss about it and he is good to talk to about these things :)",
  "id" : 210139196650827777,
  "in_reply_to_status_id" : 210139037644759040,
  "created_at" : "2012-06-05 22:41:03 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210138580406898688",
  "geo" : { },
  "id_str" : "210138782614290434",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe then he'll be grumpy tomorrow and unwilling to talk about it... Make sure its Thursday though please :D",
  "id" : 210138782614290434,
  "in_reply_to_status_id" : 210138580406898688,
  "created_at" : "2012-06-05 22:39:24 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210137929396391939",
  "geo" : { },
  "id_str" : "210138205821997058",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe this displeases me greatly............. I'll get over it though... In time... I guess...",
  "id" : 210138205821997058,
  "in_reply_to_status_id" : 210137929396391939,
  "created_at" : "2012-06-05 22:37:07 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 14, 21 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210135679089393664",
  "geo" : { },
  "id_str" : "210137353501687809",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues did @srushe watch mad men and game of thrones more importantly???",
  "id" : 210137353501687809,
  "in_reply_to_status_id" : 210135679089393664,
  "created_at" : "2012-06-05 22:33:43 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 10, 19 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210130730574024704",
  "geo" : { },
  "id_str" : "210130922224357377",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq @slabbery @nial_adams silent mode :)",
  "id" : 210130922224357377,
  "in_reply_to_status_id" : 210130730574024704,
  "created_at" : "2012-06-05 22:08:10 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    }, {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 10, 19 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210125739272577025",
  "geo" : { },
  "id_str" : "210125874387890177",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery @alvynmcq knob",
  "id" : 210125874387890177,
  "in_reply_to_status_id" : 210125739272577025,
  "created_at" : "2012-06-05 21:48:07 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    }, {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 10, 19 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210125322308435968",
  "geo" : { },
  "id_str" : "210125468530249730",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery @alvynmcq not grumpy :) Am bald and a tad grey ;)",
  "id" : 210125468530249730,
  "in_reply_to_status_id" : 210125322308435968,
  "created_at" : "2012-06-05 21:46:30 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    }, {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 22, 31 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210124719125569536",
  "geo" : { },
  "id_str" : "210124931231526912",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery @nial_adams @alvynmcq I ain't in following. You aren't funny however you are a grade 'a' wanker!",
  "id" : 210124931231526912,
  "in_reply_to_status_id" : 210124719125569536,
  "created_at" : "2012-06-05 21:44:22 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    }, {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 10, 19 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210122589866168321",
  "geo" : { },
  "id_str" : "210124372965462017",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery @alvynmcq @nial_adams i bet you these tweets are waking him up or at least stopping him from going over to sleep! :)",
  "id" : 210124372965462017,
  "in_reply_to_status_id" : 210122589866168321,
  "created_at" : "2012-06-05 21:42:09 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 95, 107 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210104052141404161",
  "geo" : { },
  "id_str" : "210104240352411649",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery he lives in mount eagles if he is proud to be british he's pretty much fucked... \/cc @niall_adams",
  "id" : 210104240352411649,
  "in_reply_to_status_id" : 210104052141404161,
  "created_at" : "2012-06-05 20:22:09 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210102875777544192",
  "geo" : { },
  "id_str" : "210103481279844352",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I'll do a trac for you for every type you tell me about? Deal? :D",
  "id" : 210103481279844352,
  "in_reply_to_status_id" : 210102875777544192,
  "created_at" : "2012-06-05 20:19:08 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/zR4rNwgh",
      "expanded_url" : "http:\/\/swm.cc",
      "display_url" : "swm.cc"
    } ]
  },
  "geo" : { },
  "id_str" : "210102862519341056",
  "text" : "So @nial_adams has compared him finding typos on my new site (http:\/\/t.co\/zR4rNwgh) to being in saw... Weirdo :D",
  "id" : 210102862519341056,
  "created_at" : "2012-06-05 20:16:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210102465557831680",
  "geo" : { },
  "id_str" : "210102654544781312",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams how the fuck is this anything like saw? What have you been smoking and bring it in tomorrow ;)",
  "id" : 210102654544781312,
  "in_reply_to_status_id" : 210102465557831680,
  "created_at" : "2012-06-05 20:15:51 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210102078595543040",
  "geo" : { },
  "id_str" : "210102273827815424",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams will do it tomorrow - there is probably more than one so instead of you telling me one by one I want them all bitch :D",
  "id" : 210102273827815424,
  "in_reply_to_status_id" : 210102078595543040,
  "created_at" : "2012-06-05 20:14:20 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210089031713820672",
  "text" : "@MarrkyMc I just did a google define on 'pejazzle'. Dude. No need... Still if it gets me another day off work... Still.. Not on... Not on.",
  "id" : 210089031713820672,
  "created_at" : "2012-06-05 19:21:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210082450838274049",
  "text" : "I was in the tv room Rocky 4 'Hearts on Fire' just came on in the ipod that's docked in the kitchen. Now to wash the FUCK out of that floor!",
  "id" : 210082450838274049,
  "created_at" : "2012-06-05 18:55:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210076108555685889",
  "text" : "Forgot to take the lawnmower to the fixy person.. Balls! Time to bribe my Dad into doing it. This could be expensive!",
  "id" : 210076108555685889,
  "created_at" : "2012-06-05 18:30:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210051689061957632",
  "geo" : { },
  "id_str" : "210051848617463808",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll you disappoint me Alana....",
  "id" : 210051848617463808,
  "in_reply_to_status_id" : 210051689061957632,
  "created_at" : "2012-06-05 16:53:57 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210050603211177985",
  "geo" : { },
  "id_str" : "210051437089136640",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll if you would end that with strawberry yazoo then that'd be the most perfect sentence in the world ever.. Well one of them anyway",
  "id" : 210051437089136640,
  "in_reply_to_status_id" : 210050603211177985,
  "created_at" : "2012-06-05 16:52:19 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210049475929063424",
  "text" : "So MongoDB (on ubuntu anyway) can't easily restart from a crash as it creates a lock file... Hate stuff like that. At least I know now!",
  "id" : 210049475929063424,
  "created_at" : "2012-06-05 16:44:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/209952882806636545\/photo\/1",
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/kFEf46vX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AunnCNeCQAApcu7.jpg",
      "id_str" : "209952882810830848",
      "id" : 209952882810830848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AunnCNeCQAApcu7.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/kFEf46vX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209952882806636545",
  "text" : "Sweeeeet \/cc @peter_omalley http:\/\/t.co\/kFEf46vX",
  "id" : 209952882806636545,
  "created_at" : "2012-06-05 10:20:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 66, 73 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyoucupcake",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209945056591884288",
  "text" : "Sitting relaxing this morning - my phone goes off.. An email from @bekabr that reminds you that you are a sucker! #fuckyoucupcake",
  "id" : 209945056591884288,
  "created_at" : "2012-06-05 09:49:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209771729780875267",
  "text" : "OK.. Screw the 'cloud' thing.. Next person to say \"proudtobebritish\" gets unfollowed. Why be proud of your country - makes no sense!",
  "id" : 209771729780875267,
  "created_at" : "2012-06-04 22:20:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209771008079568896",
  "geo" : { },
  "id_str" : "209771269460201473",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson tired = grumpy. grumpy = can't poke you as much :) You'll be more up for the craic after a 10min commute :D",
  "id" : 209771269460201473,
  "in_reply_to_status_id" : 209771008079568896,
  "created_at" : "2012-06-04 22:19:02 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209769227123564545",
  "geo" : { },
  "id_str" : "209769417687580672",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams where is it!?!??!?!",
  "id" : 209769417687580672,
  "in_reply_to_status_id" : 209769227123564545,
  "created_at" : "2012-06-04 22:11:41 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209767888519827458",
  "geo" : { },
  "id_str" : "209768140593303553",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr just warning you - there is no hey jude!!! Like wtf :(",
  "id" : 209768140593303553,
  "in_reply_to_status_id" : 209767888519827458,
  "created_at" : "2012-06-04 22:06:36 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209767102343675905",
  "geo" : { },
  "id_str" : "209767452400295938",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall Nothing wrong with Steps or Kylie!!! I stand by my musical taste :)",
  "id" : 209767452400295938,
  "in_reply_to_status_id" : 209767102343675905,
  "created_at" : "2012-06-04 22:03:52 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209765853175099393",
  "geo" : { },
  "id_str" : "209766381166673922",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall you got something to say porter? Just come out and say it like - don't beat around your hairy man arms!!!",
  "id" : 209766381166673922,
  "in_reply_to_status_id" : 209765853175099393,
  "created_at" : "2012-06-04 21:59:37 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209765989464809472",
  "text" : "@MarrkyMc Bits of it weren't bad. But Sir Paul never ended on Hey Jude so now I just feel dirty. Ahh well day off tomorrow so fuck it :)",
  "id" : 209765989464809472,
  "created_at" : "2012-06-04 21:58:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209764461920264192",
  "geo" : { },
  "id_str" : "209764878896988162",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall there was no hey jude :( When you see Sir Paul at these things it always ends in Hey Jude :(",
  "id" : 209764878896988162,
  "in_reply_to_status_id" : 209764461920264192,
  "created_at" : "2012-06-04 21:53:39 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209761893156532224",
  "text" : "The Queen looks really uncomfy and oul Charlie is milking this - he is basically saying \"I is next mofos\" :D",
  "id" : 209761893156532224,
  "created_at" : "2012-06-04 21:41:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209761211296911360",
  "geo" : { },
  "id_str" : "209761757089103872",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams where? :)",
  "id" : 209761757089103872,
  "in_reply_to_status_id" : 209761211296911360,
  "created_at" : "2012-06-04 21:41:14 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Braziel",
      "screen_name" : "Braziel",
      "indices" : [ 0, 8 ],
      "id_str" : "776654",
      "id" : 776654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209757498343821312",
  "geo" : { },
  "id_str" : "209758639047712768",
  "in_reply_to_user_id" : 776654,
  "text" : "@Braziel he's pretty old now though - and he still is head and tails better than anyone else out there.",
  "id" : 209758639047712768,
  "in_reply_to_status_id" : 209757498343821312,
  "created_at" : "2012-06-04 21:28:51 +0000",
  "in_reply_to_screen_name" : "Braziel",
  "in_reply_to_user_id_str" : "776654",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209750440194228224",
  "text" : "Lenny Henry and Rolf Harris - aye - this Jubilee thing is real classy!!! And now Rolf Harris singing?!?!",
  "id" : 209750440194228224,
  "created_at" : "2012-06-04 20:56:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 16, 32 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Mikes Man Cards",
      "screen_name" : "mikesmancards",
      "indices" : [ 105, 119 ],
      "id_str" : "591285548",
      "id" : 591285548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209741868290949122",
  "text" : "Can't wait till @michaelnsimpson moves back up to Lisburn again.. Back to old Mike and then we can start @mikesmancards again without fear!",
  "id" : 209741868290949122,
  "created_at" : "2012-06-04 20:22:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Adams",
      "screen_name" : "PRAEst76",
      "indices" : [ 0, 9 ],
      "id_str" : "12081742",
      "id" : 12081742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209715837702123520",
  "geo" : { },
  "id_str" : "209727187593596929",
  "in_reply_to_user_id" : 12081742,
  "text" : "@PRAEst76 it drives me nuts. \"Lets push it to the cloud\" \"Are you in the cloud?\" Fashion driven buzz words drive me nuts!",
  "id" : 209727187593596929,
  "in_reply_to_status_id" : 209715837702123520,
  "created_at" : "2012-06-04 19:23:52 +0000",
  "in_reply_to_screen_name" : "PRAEst76",
  "in_reply_to_user_id_str" : "12081742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cloud Experience",
      "screen_name" : "cloudexp",
      "indices" : [ 8, 17 ],
      "id_str" : "216394561",
      "id" : 216394561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209713025429671937",
  "text" : "Shit... @cloudexp just tweeted about the 'cloud' did it there.. So a final caveat to past tweets... You gotta be from NI!",
  "id" : 209713025429671937,
  "created_at" : "2012-06-04 18:27:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "idiots",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209711817025519617",
  "text" : "haven't organically moved that way by now you do not deserve to be in business... Why is the IT world so fashion driven?? #idiots",
  "id" : 209711817025519617,
  "created_at" : "2012-06-04 18:22:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209711667330826242",
  "text" : "That's it - the next person that tweets something with the words \"cloud\" is getting unfollowed. It is nothing new - and if you....",
  "id" : 209711667330826242,
  "created_at" : "2012-06-04 18:22:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/209697900018667520\/photo\/1",
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/u6qtjOmE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Auj_IQmCEAAfdhF.jpg",
      "id_str" : "209697900031250432",
      "id" : 209697900031250432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Auj_IQmCEAAfdhF.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/u6qtjOmE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209697900018667520",
  "text" : "Pips in her car! Happy 1st :) *beep* *beep* http:\/\/t.co\/u6qtjOmE",
  "id" : 209697900018667520,
  "created_at" : "2012-06-04 17:27:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209677572714409984",
  "geo" : { },
  "id_str" : "209679002108047361",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I knew that would get a reaction from you. You are \/sooooo\/ predictable! Now go make me a cuppa woman! ;)",
  "id" : 209679002108047361,
  "in_reply_to_status_id" : 209677572714409984,
  "created_at" : "2012-06-04 16:12:24 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209673631444377600",
  "text" : "Got the grass cut. She cut off after every 3mins - then had to wait 5 b4 starting again. But I got there!!! She's in for a service now :)",
  "id" : 209673631444377600,
  "created_at" : "2012-06-04 15:51:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209663106232750081",
  "geo" : { },
  "id_str" : "209664938795483136",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues Awesome.. Well I'd rather rather be known for lots of drinking than slavery  ;)  Litttle House on the Prairie :D This is awesome!",
  "id" : 209664938795483136,
  "in_reply_to_status_id" : 209663106232750081,
  "created_at" : "2012-06-04 15:16:31 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209648435719188480",
  "geo" : { },
  "id_str" : "209648704297250816",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq looks like it will have to go for a service tomorrow though - so the next cut (cos this one isn't happening) will be  hell :(",
  "id" : 209648704297250816,
  "in_reply_to_status_id" : 209648435719188480,
  "created_at" : "2012-06-04 14:12:00 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209648435719188480",
  "geo" : { },
  "id_str" : "209648580955357185",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq nah - but with all the past heat and with the rain coming if I don't take it down to its lowest now it will be hell later.",
  "id" : 209648580955357185,
  "in_reply_to_status_id" : 209648435719188480,
  "created_at" : "2012-06-04 14:11:31 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209647483238879236",
  "text" : "Lawnmower 3 - swmcc 3... Frigging thing keeps cutting out on me.. Am now inside huffing.. Gonna give it another 10....",
  "id" : 209647483238879236,
  "created_at" : "2012-06-04 14:07:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209638226141523969",
  "text" : "Took it over to my Dad who since he's retired has taken up fixing stuff.. He got her fixed - sortta. \"It only leaks when she's turned off!\"",
  "id" : 209638226141523969,
  "created_at" : "2012-06-04 13:30:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209603678984876032",
  "text" : "Lawnmower 2 - swmcc 3. Took the lawnmower out to discover it is leaking petrol all over the place. Everywhere is closed :(",
  "id" : 209603678984876032,
  "created_at" : "2012-06-04 11:13:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209336593956343808",
  "geo" : { },
  "id_str" : "209368236481982465",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams cheers. Will check it in the iPad on Wednesday - but it should be alright :)",
  "id" : 209368236481982465,
  "in_reply_to_status_id" : 209336593956343808,
  "created_at" : "2012-06-03 19:37:32 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209311750137450496",
  "text" : "I've lost my wallet - \/again\/... Need to go to Tesco as the cupboard is bare here... Darnnnit",
  "id" : 209311750137450496,
  "created_at" : "2012-06-03 15:53:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209285013005545474",
  "geo" : { },
  "id_str" : "209295072724918274",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke feel free to fork it dude and get it going ;)",
  "id" : 209295072724918274,
  "in_reply_to_status_id" : 209285013005545474,
  "created_at" : "2012-06-03 14:46:48 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209278077501587456",
  "geo" : { },
  "id_str" : "209294990239739904",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist nah I am happy with them. Not a photo snob like you :)",
  "id" : 209294990239739904,
  "in_reply_to_status_id" : 209278077501587456,
  "created_at" : "2012-06-03 14:46:28 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209270476848107521",
  "geo" : { },
  "id_str" : "209270917690429441",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop :D",
  "id" : 209270917690429441,
  "in_reply_to_status_id" : 209270476848107521,
  "created_at" : "2012-06-03 13:10:49 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209270383084453888",
  "geo" : { },
  "id_str" : "209270751654711296",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery ahhh cheers - will nick the one in work and will see if it looks okay. I don't have one to test. Cheers :)",
  "id" : 209270751654711296,
  "in_reply_to_status_id" : 209270383084453888,
  "created_at" : "2012-06-03 13:10:09 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209269553128153088",
  "geo" : { },
  "id_str" : "209270645962444800",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight just stuff that I am working on. Nothing major - just playing about.",
  "id" : 209270645962444800,
  "in_reply_to_status_id" : 209269553128153088,
  "created_at" : "2012-06-03 13:09:44 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/MtfzvtHd",
      "expanded_url" : "http:\/\/www.swm.cc",
      "display_url" : "swm.cc"
    } ]
  },
  "geo" : { },
  "id_str" : "209268314189475842",
  "text" : "Just put up my new site - http:\/\/t.co\/MtfzvtHd live. Uses jekyll and grunt and has a terminal :) Am pretty happy with it.",
  "id" : 209268314189475842,
  "created_at" : "2012-06-03 13:00:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209251830847385600",
  "text" : "Testing something out",
  "id" : 209251830847385600,
  "created_at" : "2012-06-03 11:54:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 31, 43 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208535655683330050",
  "geo" : { },
  "id_str" : "208535874160439296",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @rickyhassard @niall_adams THAT'S NOT A MAN CARD LOSS!!!!! Wanting to see another mans wang isn't unmanly!",
  "id" : 208535874160439296,
  "in_reply_to_status_id" : 208535655683330050,
  "created_at" : "2012-06-01 12:30:01 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 31, 43 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208534152432197634",
  "geo" : { },
  "id_str" : "208535350971338752",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @rickyhassard @niall_adams you want to see Niall's wizard on photoshop??????",
  "id" : 208535350971338752,
  "in_reply_to_status_id" : 208534152432197634,
  "created_at" : "2012-06-01 12:27:56 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 31, 43 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208531779571814401",
  "geo" : { },
  "id_str" : "208531943904641025",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @rickyhassard @niall_adams No.. you and Rick are just fucktards. Simples.",
  "id" : 208531943904641025,
  "in_reply_to_status_id" : 208531779571814401,
  "created_at" : "2012-06-01 12:14:24 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208530916979654657",
  "geo" : { },
  "id_str" : "208531042506768384",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams DO NOT OPEN... ITS THE STUPID INTERNET HIGH FIVE THING....",
  "id" : 208531042506768384,
  "in_reply_to_status_id" : 208530916979654657,
  "created_at" : "2012-06-01 12:10:49 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208529515163553794",
  "geo" : { },
  "id_str" : "208529626253889537",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams NO!!! REMEMBER THE PACT.. GRUMPUS!!!!!",
  "id" : 208529626253889537,
  "in_reply_to_status_id" : 208529515163553794,
  "created_at" : "2012-06-01 12:05:11 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208528849233903618",
  "geo" : { },
  "id_str" : "208529051697152000",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams seems he has his iPone with him Niall while he's reading about \"how to create your own vagina from yarn\"...",
  "id" : 208529051697152000,
  "in_reply_to_status_id" : 208528849233903618,
  "created_at" : "2012-06-01 12:02:54 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208528104476520450",
  "geo" : { },
  "id_str" : "208528421414912000",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams *highfive*",
  "id" : 208528421414912000,
  "in_reply_to_status_id" : 208528104476520450,
  "created_at" : "2012-06-01 12:00:24 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "indices" : [ 0, 10 ],
      "id_str" : "199486205",
      "id" : 199486205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208495419947352065",
  "geo" : { },
  "id_str" : "208496372134055936",
  "in_reply_to_user_id" : 199486205,
  "text" : "@AoifeB155 awwwww that's a lovely photo - how young is it?",
  "id" : 208496372134055936,
  "in_reply_to_status_id" : 208495419947352065,
  "created_at" : "2012-06-01 09:53:03 +0000",
  "in_reply_to_screen_name" : "AoifeB155",
  "in_reply_to_user_id_str" : "199486205",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 4, 11 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208487413960548352",
  "text" : "FFS @srushe today re: friday \"What's the worst that could happen?\" - then I get an email re: a dead disk.. Do not bait the friday gods!",
  "id" : 208487413960548352,
  "created_at" : "2012-06-01 09:17:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]