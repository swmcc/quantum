Grailbird.data.tweets_2008_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.netvibes.com\/subscribe.php?module=Twitter\" rel=\"nofollow\"\u003ENetvibes\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932157482",
  "text" : "is using twitter via netvibes",
  "id" : 932157482,
  "created_at" : "2008-09-23 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.netvibes.com\/subscribe.php?module=Twitter\" rel=\"nofollow\"\u003ENetvibes\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932164639",
  "text" : "is thinking davidjrice updates his twitter a good bit",
  "id" : 932164639,
  "created_at" : "2008-09-23 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]