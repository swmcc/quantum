Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197085587180748800",
  "text" : "I sooooooo want to be Roger Sterling when I grows up!!!!",
  "id" : 197085587180748800,
  "created_at" : "2012-04-30 22:10:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197079271267762176",
  "text" : "Mad Men &amp; Game of Thrones - almost makes Mondays worth it :) Tuesday tomorrow - stupid non day!",
  "id" : 197079271267762176,
  "created_at" : "2012-04-30 21:45:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saysitall",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197044008562851841",
  "text" : "20:25:01 Stevies-Mac-2: ~ $ mkdir fuck\nmkdir: fuck: File exists \n\n#saysitall",
  "id" : 197044008562851841,
  "created_at" : "2012-04-30 19:25:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196936668039757824",
  "geo" : { },
  "id_str" : "196947875836592129",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore did I hear you right.. are you going to some sort of hipster meetup this week?",
  "id" : 196947875836592129,
  "in_reply_to_status_id" : 196936668039757824,
  "created_at" : "2012-04-30 13:03:27 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196926176785219586",
  "geo" : { },
  "id_str" : "196926305860714496",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll pussy.... you should have listened to me.. Epic FAIL :(",
  "id" : 196926305860714496,
  "in_reply_to_status_id" : 196926176785219586,
  "created_at" : "2012-04-30 11:37:44 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 10, 21 ],
      "id_str" : "21522311",
      "id" : 21522311
    }, {
      "name" : "Tibus",
      "screen_name" : "tibus",
      "indices" : [ 133, 139 ],
      "id_str" : "15602284",
      "id" : 15602284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196924828622667776",
  "text" : "Talked to @bigwetfish should have new server tomrrow :) A local hosting company that cares &amp; knows wtf they are doing! Take note @tibus :)",
  "id" : 196924828622667776,
  "created_at" : "2012-04-30 11:31:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196913777403371520",
  "geo" : { },
  "id_str" : "196918228797231105",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll tuna (mayo, sweetcorn, onion), big bap and tayto cheese &amp; onion...",
  "id" : 196918228797231105,
  "in_reply_to_status_id" : 196913777403371520,
  "created_at" : "2012-04-30 11:05:38 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196878954110533632",
  "text" : "Forgot my mobile....",
  "id" : 196878954110533632,
  "created_at" : "2012-04-30 08:29:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196717558282465280",
  "geo" : { },
  "id_str" : "196719467873583105",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight shut it... Here. you watching Fringe? I am just getting into it - not too bad really... not shabby.",
  "id" : 196719467873583105,
  "in_reply_to_status_id" : 196717558282465280,
  "created_at" : "2012-04-29 21:55:50 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196707336889450496",
  "geo" : { },
  "id_str" : "196709585443237888",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson can't see a new trailer but seen a feature there - didn't give that much away.",
  "id" : 196709585443237888,
  "in_reply_to_status_id" : 196707336889450496,
  "created_at" : "2012-04-29 21:16:34 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196708260592631809",
  "geo" : { },
  "id_str" : "196709474688438273",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq nice :) Good to see it :)",
  "id" : 196709474688438273,
  "in_reply_to_status_id" : 196708260592631809,
  "created_at" : "2012-04-29 21:16:08 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fanboy",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196708662369202177",
  "geo" : { },
  "id_str" : "196709422544850944",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight its #fanboy actually :)",
  "id" : 196709422544850944,
  "in_reply_to_status_id" : 196708662369202177,
  "created_at" : "2012-04-29 21:15:55 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196706893253718017",
  "geo" : { },
  "id_str" : "196707112024408065",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq this is why I like node at the mo. Nothing makes you learn better than when shit breaks :)",
  "id" : 196707112024408065,
  "in_reply_to_status_id" : 196706893253718017,
  "created_at" : "2012-04-29 21:06:44 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196706887708848128",
  "geo" : { },
  "id_str" : "196707024824836097",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson really? Is it good - I have to go see it now.... Hang on....",
  "id" : 196707024824836097,
  "in_reply_to_status_id" : 196706887708848128,
  "created_at" : "2012-04-29 21:06:24 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196706443406229506",
  "geo" : { },
  "id_str" : "196706873775370240",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight oh no just some smart ass that's watched too much big bang theory :) Of course I bitch on twitter and not to their face :)",
  "id" : 196706873775370240,
  "in_reply_to_status_id" : 196706443406229506,
  "created_at" : "2012-04-29 21:05:48 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196706345381138432",
  "geo" : { },
  "id_str" : "196706546141511681",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight its your wife that hasn't aged :) You continue to age - that's the deal :)",
  "id" : 196706546141511681,
  "in_reply_to_status_id" : 196706345381138432,
  "created_at" : "2012-04-29 21:04:29 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196704855149121536",
  "geo" : { },
  "id_str" : "196705269533769729",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq awesome :D Well done. Thats the thing with node.js - things change quickly - doubt it will slow down till 1.0",
  "id" : 196705269533769729,
  "in_reply_to_status_id" : 196704855149121536,
  "created_at" : "2012-04-29 20:59:25 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196705098016100352",
  "text" : "@MarkAMcGregor oh don't worry - I'll dump the body outside Tesco and you can continue :)",
  "id" : 196705098016100352,
  "created_at" : "2012-04-29 20:58:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196704279954862084",
  "geo" : { },
  "id_str" : "196704736324489216",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight i was a tad delicate this morning... Am feeling that I am close to your age this weather :D",
  "id" : 196704736324489216,
  "in_reply_to_status_id" : 196704279954862084,
  "created_at" : "2012-04-29 20:57:18 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196704508032729090",
  "text" : "Gonna get into a fight here... Someone is trying to convince me that Darth Vader built the Death Star... I want to kill....",
  "id" : 196704508032729090,
  "created_at" : "2012-04-29 20:56:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196691634904252416",
  "geo" : { },
  "id_str" : "196703353219186688",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq github it so I can see it :) Getting my big wet fish server on Tuesday :D Whooo-hoooo :D",
  "id" : 196703353219186688,
  "in_reply_to_status_id" : 196691634904252416,
  "created_at" : "2012-04-29 20:51:48 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 3, 10 ],
      "id_str" : "285766850",
      "id" : 285766850
    }, {
      "name" : "Z\u0322\u0337\u0334\u0360\u0336",
      "screen_name" : "izs",
      "indices" : [ 59, 63 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "Mikeal",
      "screen_name" : "mikeal",
      "indices" : [ 64, 71 ],
      "id_str" : "668423",
      "id" : 668423
    }, {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "indices" : [ 72, 81 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Paolo Fragomeni",
      "screen_name" : "hij1nx",
      "indices" : [ 82, 89 ],
      "id_str" : "95938827",
      "id" : 95938827
    }, {
      "name" : "Nuno Job",
      "screen_name" : "dscape",
      "indices" : [ 94, 101 ],
      "id_str" : "9279552",
      "id" : 9279552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodeup",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196654239102144514",
  "text" : "RT @NodeUp: NodeUp will be live today at noon (pacific) w\/ @izs @mikeal @substack @hij1nx and @dscape. Come hang out with us in #nodeup  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Z\u0322\u0337\u0334\u0360\u0336",
        "screen_name" : "izs",
        "indices" : [ 47, 51 ],
        "id_str" : "8038312",
        "id" : 8038312
      }, {
        "name" : "Mikeal",
        "screen_name" : "mikeal",
        "indices" : [ 52, 59 ],
        "id_str" : "668423",
        "id" : 668423
      }, {
        "name" : "James Halliday",
        "screen_name" : "substack",
        "indices" : [ 60, 69 ],
        "id_str" : "125027291",
        "id" : 125027291
      }, {
        "name" : "Paolo Fragomeni",
        "screen_name" : "hij1nx",
        "indices" : [ 70, 77 ],
        "id_str" : "95938827",
        "id" : 95938827
      }, {
        "name" : "Nuno Job",
        "screen_name" : "dscape",
        "indices" : [ 82, 89 ],
        "id_str" : "9279552",
        "id" : 9279552
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodeup",
        "indices" : [ 116, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "196645572927696898",
    "text" : "NodeUp will be live today at noon (pacific) w\/ @izs @mikeal @substack @hij1nx and @dscape. Come hang out with us in #nodeup on freenode.",
    "id" : 196645572927696898,
    "created_at" : "2012-04-29 17:02:12 +0000",
    "user" : {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "protected" : false,
      "id_str" : "285766850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1675860861\/logo2_normal.jpg",
      "id" : 285766850,
      "verified" : false
    }
  },
  "id" : 196654239102144514,
  "created_at" : "2012-04-29 17:36:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196607339967684609",
  "geo" : { },
  "id_str" : "196618228582191106",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley just feel like shit and have done since Friday.. Oh sweet :D We can get some work done now :))",
  "id" : 196618228582191106,
  "in_reply_to_status_id" : 196607339967684609,
  "created_at" : "2012-04-29 15:13:33 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196603972679766016",
  "geo" : { },
  "id_str" : "196605817221419009",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley I am damaged - but should be in tomorrow - unless I am on support - in which case - fuck ya ;)",
  "id" : 196605817221419009,
  "in_reply_to_status_id" : 196603972679766016,
  "created_at" : "2012-04-29 14:24:14 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196600856450318337",
  "geo" : { },
  "id_str" : "196604363295309827",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Oh I just woke up in pain and was sounding out :) Congrats on 2nd degree btw :D",
  "id" : 196604363295309827,
  "in_reply_to_status_id" : 196600856450318337,
  "created_at" : "2012-04-29 14:18:27 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rob martin",
      "screen_name" : "version2beta",
      "indices" : [ 3, 16 ],
      "id_str" : "9431062",
      "id" : 9431062
    }, {
      "name" : "node js",
      "screen_name" : "nodejs",
      "indices" : [ 29, 36 ],
      "id_str" : "91985735",
      "id" : 91985735
    }, {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 130, 137 ],
      "id_str" : "285766850",
      "id" : 285766850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196560428103499776",
  "text" : "RT @version2beta: Why I like @Nodejs Q: Are you trying to be faster than Rails or Django? A: We want to be faster than nginx. Via @NodeUp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "node js",
        "screen_name" : "nodejs",
        "indices" : [ 11, 18 ],
        "id_str" : "91985735",
        "id" : 91985735
      }, {
        "name" : "NodeUp",
        "screen_name" : "NodeUp",
        "indices" : [ 112, 119 ],
        "id_str" : "285766850",
        "id" : 285766850
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195660790123077633",
    "text" : "Why I like @Nodejs Q: Are you trying to be faster than Rails or Django? A: We want to be faster than nginx. Via @NodeUp",
    "id" : 195660790123077633,
    "created_at" : "2012-04-26 23:49:02 +0000",
    "user" : {
      "name" : "rob martin",
      "screen_name" : "version2beta",
      "protected" : false,
      "id_str" : "9431062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000325305783\/97b008f53ea164a903531c714e6fcca6_normal.jpeg",
      "id" : 9431062,
      "verified" : false
    }
  },
  "id" : 196560428103499776,
  "created_at" : "2012-04-29 11:23:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196559759598563328",
  "text" : "Fuckity fuck fuck fuck.",
  "id" : 196559759598563328,
  "created_at" : "2012-04-29 11:21:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196359669177008128",
  "geo" : { },
  "id_str" : "196363114814504960",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight watching Fringe... Then going to bed. Then coma :)",
  "id" : 196363114814504960,
  "in_reply_to_status_id" : 196359669177008128,
  "created_at" : "2012-04-28 22:19:49 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sexistbuttrue",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196356836398600192",
  "text" : "Took two women into town there - they didn't shut up the whole fucking way there.. Not one word did I get in... #sexistbuttrue",
  "id" : 196356836398600192,
  "created_at" : "2012-04-28 21:54:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196339096799551488",
  "geo" : { },
  "id_str" : "196356209857667072",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight :) I wasn't expecting much.. Was impressed :)",
  "id" : 196356209857667072,
  "in_reply_to_status_id" : 196339096799551488,
  "created_at" : "2012-04-28 21:52:23 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Nolan",
      "screen_name" : "StephenNolan",
      "indices" : [ 0, 13 ],
      "id_str" : "36673147",
      "id" : 36673147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196310810082033664",
  "geo" : { },
  "id_str" : "196338015994527744",
  "in_reply_to_user_id" : 36673147,
  "text" : "@StephenNolan Avengers is a brilliant watch. I wasn't expecting much but it was good escapism for 2 hours.",
  "id" : 196338015994527744,
  "in_reply_to_status_id" : 196310810082033664,
  "created_at" : "2012-04-28 20:40:05 +0000",
  "in_reply_to_screen_name" : "StephenNolan",
  "in_reply_to_user_id_str" : "36673147",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196284872510291970",
  "geo" : { },
  "id_str" : "196289287174619136",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll how loud you talking?",
  "id" : 196289287174619136,
  "in_reply_to_status_id" : 196284872510291970,
  "created_at" : "2012-04-28 17:26:27 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 21, 27 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/dBJVx34P",
      "expanded_url" : "http:\/\/klouchebag.com\/#swmcc",
      "display_url" : "klouchebag.com\/#swmcc"
    } ]
  },
  "geo" : { },
  "id_str" : "196171919379283969",
  "text" : "Klouchebag score for @swmcc: 41, or 'quite noisy'. http:\/\/t.co\/dBJVx34P",
  "id" : 196171919379283969,
  "created_at" : "2012-04-28 09:40:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195990465680646144",
  "geo" : { },
  "id_str" : "195990854308081664",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq oh yes I would say. I regret not learning it back in 06 when I came across it. Thought PERL was good enough.. Now look - php :(",
  "id" : 195990854308081664,
  "in_reply_to_status_id" : 195990465680646144,
  "created_at" : "2012-04-27 21:40:35 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195990430943420416",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq but it wont happen which is fair enough.. But it'd be nice :)",
  "id" : 195990430943420416,
  "created_at" : "2012-04-27 21:38:54 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 17, 27 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195988982184677376",
  "geo" : { },
  "id_str" : "195989691676377090",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @burkazoid Shit it was the wee dude that played Robin - not Matt Damon. Fucking waste of a day.. Feel like shit :(",
  "id" : 195989691676377090,
  "in_reply_to_status_id" : 195988982184677376,
  "created_at" : "2012-04-27 21:35:58 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195988473646292992",
  "geo" : { },
  "id_str" : "195989040577789955",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq Ruby probably - its the way things are going. Don't know about rails - Sinatra if i had my way maybe.",
  "id" : 195989040577789955,
  "in_reply_to_status_id" : 195988473646292992,
  "created_at" : "2012-04-27 21:33:23 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195987371920068608",
  "geo" : { },
  "id_str" : "195988059521679360",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq for better really. I'd love to move the core away from PHP though - finding it hard to get ppl now.. history repeating itself",
  "id" : 195988059521679360,
  "in_reply_to_status_id" : 195987371920068608,
  "created_at" : "2012-04-27 21:29:29 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195987371920068608",
  "geo" : { },
  "id_str" : "195987720047304707",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq its not my bosses job to keep my skills current. But to be fair to him - he looks after us great - nice toys - I couldn't ask",
  "id" : 195987720047304707,
  "in_reply_to_status_id" : 195987371920068608,
  "created_at" : "2012-04-27 21:28:08 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195987371920068608",
  "geo" : { },
  "id_str" : "195987598815145984",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq Oh I disagree with CPD thing. Training to benefit the company is fine - but CPD should be done elsewhere...",
  "id" : 195987598815145984,
  "in_reply_to_status_id" : 195987371920068608,
  "created_at" : "2012-04-27 21:27:39 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nodeconf",
      "screen_name" : "nodeconf",
      "indices" : [ 27, 36 ],
      "id_str" : "186697923",
      "id" : 186697923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195986880188268545",
  "text" : "Really wish I was going to @nodeconf - there is a sentence I thought I would never say.",
  "id" : 195986880188268545,
  "created_at" : "2012-04-27 21:24:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195984769375416320",
  "geo" : { },
  "id_str" : "195985727580942336",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq it's a good watch.",
  "id" : 195985727580942336,
  "in_reply_to_status_id" : 195984769375416320,
  "created_at" : "2012-04-27 21:20:13 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195984111465267200",
  "geo" : { },
  "id_str" : "195985700338933760",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore Was awesome :) Hulk stole the show.. The bit in Grand Central Terminal craiced me up too..",
  "id" : 195985700338933760,
  "in_reply_to_status_id" : 195984111465267200,
  "created_at" : "2012-04-27 21:20:06 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195984374766903296",
  "text" : "The Avengers was a very good film (for what it was).",
  "id" : 195984374766903296,
  "created_at" : "2012-04-27 21:14:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195920355297198080",
  "geo" : { },
  "id_str" : "195984074010136576",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley this wasn't a Friday.... Was all wrong. Next week shall be good :)",
  "id" : 195984074010136576,
  "in_reply_to_status_id" : 195920355297198080,
  "created_at" : "2012-04-27 21:13:39 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 17, 27 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195982152263925761",
  "geo" : { },
  "id_str" : "195983810813378561",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @burkazoid worst film ever. Matt Damon and Robin Willams. Poetry. Standing on tables. Pure pish.",
  "id" : 195983810813378561,
  "in_reply_to_status_id" : 195982152263925761,
  "created_at" : "2012-04-27 21:12:36 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "punygod",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195957648343044096",
  "geo" : { },
  "id_str" : "195980714854989825",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I went to see it and loved it. #punygod",
  "id" : 195980714854989825,
  "in_reply_to_status_id" : 195957648343044096,
  "created_at" : "2012-04-27 21:00:18 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195958560792915969",
  "geo" : { },
  "id_str" : "195980560051605504",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid dead poets????? Really??",
  "id" : 195980560051605504,
  "in_reply_to_status_id" : 195958560792915969,
  "created_at" : "2012-04-27 20:59:41 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "killerkingoftascomi",
      "indices" : [ 116, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195917716845101056",
  "geo" : { },
  "id_str" : "195919196289384449",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson I've better things to be getting in with on a Friday afternoon :) Next week bitches #killerkingoftascomi",
  "id" : 195919196289384449,
  "in_reply_to_status_id" : 195917716845101056,
  "created_at" : "2012-04-27 16:55:51 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/XXkXvC87",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-england-london-17869815",
      "display_url" : "bbc.co.uk\/news\/uk-englan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195891983259144192",
  "text" : "Its very telling that I found out about this story on twitter and followed it on twitter. http:\/\/t.co\/XXkXvC87 - news is changing.",
  "id" : 195891983259144192,
  "created_at" : "2012-04-27 15:07:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 8, 24 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195802798770757632",
  "geo" : { },
  "id_str" : "195803010927038464",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor @michaelnsimpson what - I got a ginger cake - not a twat cake... So its got fuck all to do with you - twat!",
  "id" : 195803010927038464,
  "in_reply_to_status_id" : 195802798770757632,
  "created_at" : "2012-04-27 09:14:10 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195802141141639169",
  "text" : ".@michaelnsimpson said to me \"I am never trust you with my money ever again... Who likes jamican ginger cake.. I asked for biscuts!!\"",
  "id" : 195802141141639169,
  "created_at" : "2012-04-27 09:10:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 56, 70 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 75, 91 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195787477729021952",
  "geo" : { },
  "id_str" : "195787820487540736",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard but you are at home though. I am here and @peter_omalley and @michaelnsimpson have to Larne later :) How is Jonah?",
  "id" : 195787820487540736,
  "in_reply_to_status_id" : 195787477729021952,
  "created_at" : "2012-04-27 08:13:48 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/195785138280476673\/photo\/1",
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/9C4k8gNk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AreRi8PCMAALvEW.jpg",
      "id_str" : "195785138284670976",
      "id" : 195785138284670976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AreRi8PCMAALvEW.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/9C4k8gNk"
    } ],
    "hashtags" : [ {
      "text" : "baconfridays",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195785138280476673",
  "text" : "Bacon Fridays :) #baconfridays http:\/\/t.co\/9C4k8gNk",
  "id" : 195785138280476673,
  "created_at" : "2012-04-27 08:03:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC SPACE",
      "screen_name" : "BBC_Space",
      "indices" : [ 3, 13 ],
      "id_str" : "560452336",
      "id" : 560452336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195765912496914432",
  "text" : "RT @BBC_Space: This is a new account which will be used as a central hub for all things space & astro related from the BBC. Please sprea ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194387067428548608",
    "text" : "This is a new account which will be used as a central hub for all things space & astro related from the BBC. Please spread the word!  Thanks",
    "id" : 194387067428548608,
    "created_at" : "2012-04-23 11:27:43 +0000",
    "user" : {
      "name" : "BBC SPACE",
      "screen_name" : "BBC_Space",
      "protected" : false,
      "id_str" : "560452336",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2158607678\/-14_normal.jpg",
      "id" : 560452336,
      "verified" : false
    }
  },
  "id" : 195765912496914432,
  "created_at" : "2012-04-27 06:46:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195626132379410432",
  "text" : "Nothing like popping in for an improtu cup of tea at a friends and then getting served a lovely lamb tea... Yum :)",
  "id" : 195626132379410432,
  "created_at" : "2012-04-26 21:31:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baconfriday",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195602180533788675",
  "geo" : { },
  "id_str" : "195625585987428352",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley I will be there. Before you lot probably. #baconfriday",
  "id" : 195625585987428352,
  "in_reply_to_status_id" : 195602180533788675,
  "created_at" : "2012-04-26 21:29:08 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195564385433956353",
  "text" : "battling with 'brew' again - it shouldn't be this hard....",
  "id" : 195564385433956353,
  "created_at" : "2012-04-26 17:25:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195509130532880385",
  "geo" : { },
  "id_str" : "195510467727339521",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit dude!",
  "id" : 195510467727339521,
  "in_reply_to_status_id" : 195509130532880385,
  "created_at" : "2012-04-26 13:51:42 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Charlotte Hughes",
      "screen_name" : "thatsortagirl",
      "indices" : [ 16, 30 ],
      "id_str" : "46484752",
      "id" : 46484752
    }, {
      "name" : "Stephen McMaster",
      "screen_name" : "s_mc_master",
      "indices" : [ 31, 43 ],
      "id_str" : "501270359",
      "id" : 501270359
    }, {
      "name" : "Andrew Jones",
      "screen_name" : "ajones13113",
      "indices" : [ 44, 56 ],
      "id_str" : "88930077",
      "id" : 88930077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195447853953458177",
  "geo" : { },
  "id_str" : "195451194662072320",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @thatsortagirl @s_mc_master @ajones13113 You have my sympathy of course, lots of it. Just you are G - you don't break :)",
  "id" : 195451194662072320,
  "in_reply_to_status_id" : 195447853953458177,
  "created_at" : "2012-04-26 09:56:10 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Charlotte Hughes",
      "screen_name" : "thatsortagirl",
      "indices" : [ 16, 30 ],
      "id_str" : "46484752",
      "id" : 46484752
    }, {
      "name" : "Stephen McMaster",
      "screen_name" : "s_mc_master",
      "indices" : [ 31, 43 ],
      "id_str" : "501270359",
      "id" : 501270359
    }, {
      "name" : "Andrew Jones",
      "screen_name" : "ajones13113",
      "indices" : [ 44, 56 ],
      "id_str" : "88930077",
      "id" : 88930077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195281754247020544",
  "geo" : { },
  "id_str" : "195432162537897984",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @thatsortagirl @s_mc_master @ajones13113 I am sure its not fun - am just shocked you broke..  You are made of iron!",
  "id" : 195432162537897984,
  "in_reply_to_status_id" : 195281754247020544,
  "created_at" : "2012-04-26 08:40:33 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 3, 18 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 20, 26 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195281791303680000",
  "text" : "RT @Georgina_Milne: @swmcc okok, I BROKE MY ASS",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "195251175833083905",
    "geo" : { },
    "id_str" : "195281508112678915",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc okok, I BROKE MY ASS",
    "id" : 195281508112678915,
    "in_reply_to_status_id" : 195251175833083905,
    "created_at" : "2012-04-25 22:41:54 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "protected" : false,
      "id_str" : "15344533",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1562857707\/meee_normal.jpg",
      "id" : 15344533,
      "verified" : false
    }
  },
  "id" : 195281791303680000,
  "created_at" : "2012-04-25 22:43:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195274730897539072",
  "geo" : { },
  "id_str" : "195275103418843136",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq oh congrats - I didn't know you were expecting :)",
  "id" : 195275103418843136,
  "in_reply_to_status_id" : 195274730897539072,
  "created_at" : "2012-04-25 22:16:27 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195274114573934593",
  "geo" : { },
  "id_str" : "195274343243202562",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq be confident - you'll be grand. Remeber to GitHub it so I can be nosey :)",
  "id" : 195274343243202562,
  "in_reply_to_status_id" : 195274114573934593,
  "created_at" : "2012-04-25 22:13:26 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195271015364960257",
  "geo" : { },
  "id_str" : "195273663350714368",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I meant distro - stupid autocorrect.",
  "id" : 195273663350714368,
  "in_reply_to_status_id" : 195271015364960257,
  "created_at" : "2012-04-25 22:10:44 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195271946571759617",
  "geo" : { },
  "id_str" : "195273514712965121",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq nice one :) What you building and what framework you using?",
  "id" : 195273514712965121,
  "in_reply_to_status_id" : 195271946571759617,
  "created_at" : "2012-04-25 22:10:08 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195269340206071808",
  "geo" : { },
  "id_str" : "195270114403287040",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I am going for 15 - just that's what the end point is. What district you going?",
  "id" : 195270114403287040,
  "in_reply_to_status_id" : 195269340206071808,
  "created_at" : "2012-04-25 21:56:37 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195267045120671744",
  "text" : "Only getting to watch GoT now... .Hectic :)",
  "id" : 195267045120671744,
  "created_at" : "2012-04-25 21:44:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baconfriday",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195259939361521667",
  "geo" : { },
  "id_str" : "195265562434215937",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I did - but had to go back onto to it for some family shiz.. Will tell you on Friday. #baconfriday",
  "id" : 195265562434215937,
  "in_reply_to_status_id" : 195259939361521667,
  "created_at" : "2012-04-25 21:38:32 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195252193987792898",
  "text" : "I am losing more and more interest in facebook and falling more in &lt;3 with twitter. I am never on FB now, not really.",
  "id" : 195252193987792898,
  "created_at" : "2012-04-25 20:45:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195235505015754752",
  "geo" : { },
  "id_str" : "195251175833083905",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne did you break your ass? Is that what your saying? :)",
  "id" : 195251175833083905,
  "in_reply_to_status_id" : 195235505015754752,
  "created_at" : "2012-04-25 20:41:22 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 3, 12 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195250908869828608",
  "text" : "RT @alvynmcq: \"but what is the cloud and why don't we need printers?\" - \"the cloud is the internet and printers are shit.\" - I am a mast ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195220499423436802",
    "text" : "\"but what is the cloud and why don't we need printers?\" - \"the cloud is the internet and printers are shit.\" - I am a master communicator.",
    "id" : 195220499423436802,
    "created_at" : "2012-04-25 18:39:28 +0000",
    "user" : {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "protected" : false,
      "id_str" : "16155145",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2054100540\/535376_10150637481600213_561550212_9624784_1859481959_n_normal.jpg",
      "id" : 16155145,
      "verified" : false
    }
  },
  "id" : 195250908869828608,
  "created_at" : "2012-04-25 20:40:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195218186071838720",
  "geo" : { },
  "id_str" : "195250413140852736",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq nope. Waiting till the first of May. Hate having direct debuts at the end if the month. Can't wait :) You?",
  "id" : 195250413140852736,
  "in_reply_to_status_id" : 195218186071838720,
  "created_at" : "2012-04-25 20:38:20 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "minnielovesit",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195223157366464514",
  "geo" : { },
  "id_str" : "195250237831516160",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp did @peter_omalley not explain it? #minnielovesit",
  "id" : 195250237831516160,
  "in_reply_to_status_id" : 195223157366464514,
  "created_at" : "2012-04-25 20:37:38 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toocuttingedgeforswmcc",
      "indices" : [ 74, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195213360042737666",
  "text" : "Stevies-Mac-2: ~ $ node -v\nv0.7.9-pre\nStevies-Mac-2: ~ $ node -v\nv0.6.15\n\n#toocuttingedgeforswmcc",
  "id" : 195213360042737666,
  "created_at" : "2012-04-25 18:11:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/AlOFYgvV",
      "expanded_url" : "http:\/\/newrelic.com\/dirtydozen?utm_source=TWIT&utm_medium=text_ad&utm_content=social_media&utm_campaign=RPM&utm_term=tweet&mpc=TA-TWIT-RPM-en-100-dirtydozen-tweet",
      "display_url" : "newrelic.com\/dirtydozen?utm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195196225430110209",
  "text" : "http:\/\/t.co\/AlOFYgvV :D I like this.",
  "id" : 195196225430110209,
  "created_at" : "2012-04-25 17:03:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/195136600949276672\/photo\/1",
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/PJ99fHw2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArVDtGaCQAAgwqV.jpg",
      "id_str" : "195136600953470976",
      "id" : 195136600953470976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArVDtGaCQAAgwqV.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PJ99fHw2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195136600949276672",
  "text" : "Spit roast.... http:\/\/t.co\/PJ99fHw2",
  "id" : 195136600949276672,
  "created_at" : "2012-04-25 13:06:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/195120911727341568\/photo\/1",
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/ZGTEdCH2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArU1b3gCMAAnQPT.jpg",
      "id_str" : "195120911731535872",
      "id" : 195120911731535872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArU1b3gCMAAnQPT.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZGTEdCH2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195120911727341568",
  "text" : "Look at what Minnie and Snoopy are doing Liz :) http:\/\/t.co\/ZGTEdCH2",
  "id" : 195120911727341568,
  "created_at" : "2012-04-25 12:03:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195079796856860673",
  "text" : "This Leveson thing is brilliant....",
  "id" : 195079796856860673,
  "created_at" : "2012-04-25 09:20:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 46, 59 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hedeservesit",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194907918221578240",
  "text" : "Feel kinda guilty after taking the piss outta @Paul_Moffett for most of this evening. Can't help it though.. #hedeservesit",
  "id" : 194907918221578240,
  "created_at" : "2012-04-24 21:57:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194896213961736192",
  "geo" : { },
  "id_str" : "194907601564217344",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr Should only be a week or two. Any longer and I would go chasing.",
  "id" : 194907601564217344,
  "in_reply_to_status_id" : 194896213961736192,
  "created_at" : "2012-04-24 21:56:08 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 17, 28 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckwit",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194819872771936256",
  "text" : "Just had to kick @davidjrice from the cabal cos he says that hacking the twillio API is more fun than a week in Vegas. #fuckwit",
  "id" : 194819872771936256,
  "created_at" : "2012-04-24 16:07:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194794215497142273",
  "geo" : { },
  "id_str" : "194794375203651584",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 kiss my ass",
  "id" : 194794375203651584,
  "in_reply_to_status_id" : 194794215497142273,
  "created_at" : "2012-04-24 14:26:12 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    }, {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 30, 37 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194790488103067649",
  "geo" : { },
  "id_str" : "194792198187909120",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight I didn't see @bekabr there..... Was she? :)",
  "id" : 194792198187909120,
  "in_reply_to_status_id" : 194790488103067649,
  "created_at" : "2012-04-24 14:17:33 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 36, 42 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194785964428763136",
  "text" : "Pfsense firewalls and IPSEC VPN's = @swmcc has a sore head.",
  "id" : 194785964428763136,
  "created_at" : "2012-04-24 13:52:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194779373482672128",
  "geo" : { },
  "id_str" : "194779902250196993",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams \"You shall not passssssss!!!!!!!!\" or \"One system to rule them all and in the darkness bind them\"? :D",
  "id" : 194779902250196993,
  "in_reply_to_status_id" : 194779373482672128,
  "created_at" : "2012-04-24 13:28:42 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194768857628540928",
  "geo" : { },
  "id_str" : "194769613605715970",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson *BOOOOM*",
  "id" : 194769613605715970,
  "in_reply_to_status_id" : 194768857628540928,
  "created_at" : "2012-04-24 12:47:49 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grindsmygears",
      "indices" : [ 81, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194766203565248512",
  "text" : "Nothing quite winds me up when there is chaos in the queuing system at a shop... #grindsmygears",
  "id" : 194766203565248512,
  "created_at" : "2012-04-24 12:34:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194706650475671552",
  "geo" : { },
  "id_str" : "194714141880107008",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you broke G??? That was bound to hurt!",
  "id" : 194714141880107008,
  "in_reply_to_status_id" : 194706650475671552,
  "created_at" : "2012-04-24 09:07:23 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Ryan",
      "screen_name" : "richardiaryan",
      "indices" : [ 3, 17 ],
      "id_str" : "89961918",
      "id" : 89961918
    }, {
      "name" : "Andrew Neill",
      "screen_name" : "neill_andrew",
      "indices" : [ 47, 60 ],
      "id_str" : "31930813",
      "id" : 31930813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194685471383764992",
  "text" : "RT @richardiaryan: 1 things I've made up about @neill_andrew in the last 5 mins- favourite song- 'In Glenavy' by the Village People",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Neill",
        "screen_name" : "neill_andrew",
        "indices" : [ 28, 41 ],
        "id_str" : "31930813",
        "id" : 31930813
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194535433982578688",
    "text" : "1 things I've made up about @neill_andrew in the last 5 mins- favourite song- 'In Glenavy' by the Village People",
    "id" : 194535433982578688,
    "created_at" : "2012-04-23 21:17:16 +0000",
    "user" : {
      "name" : "Richard Ryan",
      "screen_name" : "richardiaryan",
      "protected" : false,
      "id_str" : "89961918",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000491148723\/75cf7043e3c6dc2ce4b48469197cd477_normal.jpeg",
      "id" : 89961918,
      "verified" : false
    }
  },
  "id" : 194685471383764992,
  "created_at" : "2012-04-24 07:13:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hardcoreblondelady",
      "indices" : [ 76, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194571038493913088",
  "geo" : { },
  "id_str" : "194571342044069888",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne ouch!!!! :( The one on the right looks really feckin sore.. #hardcoreblondelady",
  "id" : 194571342044069888,
  "in_reply_to_status_id" : 194571038493913088,
  "created_at" : "2012-04-23 23:39:57 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194568392424947712",
  "geo" : { },
  "id_str" : "194568671639769090",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne explain....",
  "id" : 194568671639769090,
  "in_reply_to_status_id" : 194568392424947712,
  "created_at" : "2012-04-23 23:29:20 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194543359342280705",
  "text" : "I am gonna whitie - this tv show is gonna do it!",
  "id" : 194543359342280705,
  "created_at" : "2012-04-23 21:48:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194528535912787968",
  "text" : "I want to kill puppies every time someone refers the command line as CLI.",
  "id" : 194528535912787968,
  "created_at" : "2012-04-23 20:49:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194463115839156226",
  "geo" : { },
  "id_str" : "194527737090801664",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq Getting the 15quid a month one. Just for a few sites I have. Mostly for node.js - with some Ruby\/PHP & Perl. Just showcases for me",
  "id" : 194527737090801664,
  "in_reply_to_status_id" : 194463115839156226,
  "created_at" : "2012-04-23 20:46:41 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 25, 36 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194369892705779712",
  "text" : "Am vastly impressed with @bigwetfish - finally a local hosting company that isn't that expensive and offers good support :D",
  "id" : 194369892705779712,
  "created_at" : "2012-04-23 10:19:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194365615388110848",
  "geo" : { },
  "id_str" : "194369704104706048",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish cheers - will do :) As long as I can get ubuntu I am happy.. Will give you a shout on Thursday\/Friday :)",
  "id" : 194369704104706048,
  "in_reply_to_status_id" : 194365615388110848,
  "created_at" : "2012-04-23 10:18:43 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/0E4Hwx82",
      "expanded_url" : "http:\/\/easydns.org",
      "display_url" : "easydns.org"
    } ]
  },
  "geo" : { },
  "id_str" : "194360324214890496",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish will either use my current VPS in to host bind or move to http:\/\/t.co\/0E4Hwx82 or something :)",
  "id" : 194360324214890496,
  "created_at" : "2012-04-23 09:41:26 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194359027243810817",
  "geo" : { },
  "id_str" : "194360024783532032",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish the DNS lot I was piggybacking on got turned off - so just need somewhere to host the actual zone files. No worries if you can't",
  "id" : 194360024783532032,
  "in_reply_to_status_id" : 194359027243810817,
  "created_at" : "2012-04-23 09:40:15 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194355355264876545",
  "geo" : { },
  "id_str" : "194356143840178176",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish I take it that you can do DNS for the domains I have as well?",
  "id" : 194356143840178176,
  "in_reply_to_status_id" : 194355355264876545,
  "created_at" : "2012-04-23 09:24:50 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    }, {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 90, 99 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194354871133159424",
  "geo" : { },
  "id_str" : "194355062183698432",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish Oh no trial needed - am gonna go for it come Thursday. Heard good things from @alvynmcq so just gonna sign up :)",
  "id" : 194355062183698432,
  "in_reply_to_status_id" : 194354871133159424,
  "created_at" : "2012-04-23 09:20:32 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 37, 48 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194354475719340032",
  "text" : "Have to say am really impressed with @bigwetfish getting back to me so soon after my initial query.. Impressive :)",
  "id" : 194354475719340032,
  "created_at" : "2012-04-23 09:18:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194354002094333952",
  "geo" : { },
  "id_str" : "194354251907080194",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish Thinking of your 15 a month version - where are your systems held out of interest. Should give the go ahead come Thursday. :)",
  "id" : 194354251907080194,
  "in_reply_to_status_id" : 194354002094333952,
  "created_at" : "2012-04-23 09:17:19 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194352913416601603",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish - yo :D Do you offer an Unbuntu flavour in the VPS? And if so - what version? :)",
  "id" : 194352913416601603,
  "created_at" : "2012-04-23 09:12:00 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194344852350177280",
  "text" : "I fucking hate Mondays.",
  "id" : 194344852350177280,
  "created_at" : "2012-04-23 08:39:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Hamill",
      "screen_name" : "gdh_gdh",
      "indices" : [ 0, 8 ],
      "id_str" : "139846667",
      "id" : 139846667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194171792422735873",
  "geo" : { },
  "id_str" : "194172400940744704",
  "in_reply_to_user_id" : 139846667,
  "text" : "@gdh_gdh sorry I meant nameservers for the domains I have - the nameservers in BlackStar were finally turned off. Am tight, just like you :)",
  "id" : 194172400940744704,
  "in_reply_to_status_id" : 194171792422735873,
  "created_at" : "2012-04-22 21:14:42 +0000",
  "in_reply_to_screen_name" : "gdh_gdh",
  "in_reply_to_user_id_str" : "139846667",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Moran",
      "screen_name" : "ianmoran",
      "indices" : [ 0, 9 ],
      "id_str" : "16236773",
      "id" : 16236773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194169433458094080",
  "geo" : { },
  "id_str" : "194169711620128768",
  "in_reply_to_user_id" : 16236773,
  "text" : "@ianmoran I was thinking of doing that myself but something doesn't feel right about it. I currently have a small VPS doing nothing hmm....",
  "id" : 194169711620128768,
  "in_reply_to_status_id" : 194169433458094080,
  "created_at" : "2012-04-22 21:04:01 +0000",
  "in_reply_to_screen_name" : "ianmoran",
  "in_reply_to_user_id_str" : "16236773",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194169315384229888",
  "text" : "@MarkAMcGregor you are fucking kidding me? So that's why? That's the daftest thing ever - surely that's an accident waiting to happen?",
  "id" : 194169315384229888,
  "created_at" : "2012-04-22 21:02:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Moran",
      "screen_name" : "ianmoran",
      "indices" : [ 0, 9 ],
      "id_str" : "16236773",
      "id" : 16236773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194168468705259522",
  "geo" : { },
  "id_str" : "194168882527879170",
  "in_reply_to_user_id" : 16236773,
  "text" : "@ianmoran Oh I mean what hosting providers do people use. I have several domains and the nameservers I was piggybacking off went offline",
  "id" : 194168882527879170,
  "in_reply_to_status_id" : 194168468705259522,
  "created_at" : "2012-04-22 21:00:43 +0000",
  "in_reply_to_screen_name" : "ianmoran",
  "in_reply_to_user_id_str" : "16236773",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194167513469296641",
  "text" : "Also anyone know what the fuck the temp traffic lights are for on the Hannastown Road? Drives me fucking crazy!!!",
  "id" : 194167513469296641,
  "created_at" : "2012-04-22 20:55:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194167372951732225",
  "text" : "Who does everyone use for their DNS? I was piggy backing on the oul BlackStar nameservers but they have been turned off now (I know!) :)",
  "id" : 194167372951732225,
  "created_at" : "2012-04-22 20:54:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193799849815183361",
  "geo" : { },
  "id_str" : "194166579703980032",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall what is the dude behind him trying to do? Cool photo :)",
  "id" : 194166579703980032,
  "in_reply_to_status_id" : 193799849815183361,
  "created_at" : "2012-04-22 20:51:34 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 108, 116 ],
      "id_str" : "79820731",
      "id" : 79820731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194166385188929536",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq some point in the future it will be useful. Am gonna use it for a utility\/house keeping system in @tascomi soon too.",
  "id" : 194166385188929536,
  "created_at" : "2012-04-22 20:50:48 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194166206247337984",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I still think that its not something I would use in production yet - just cos its so new and everything changes - but deffo at",
  "id" : 194166206247337984,
  "created_at" : "2012-04-22 20:50:05 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194164483520864256",
  "geo" : { },
  "id_str" : "194166086399303680",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq When I get my new DNS lot sorted (I am lazy) I am gonna move swm.cc to a node.js platform - just to have something running on it.",
  "id" : 194166086399303680,
  "in_reply_to_status_id" : 194164483520864256,
  "created_at" : "2012-04-22 20:49:37 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194164394228334593",
  "geo" : { },
  "id_str" : "194165933395288066",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq yeah - that's my main reason for not playing about it with meteor that much. Express seems to have been round a while (relatively)",
  "id" : 194165933395288066,
  "in_reply_to_status_id" : 194164394228334593,
  "created_at" : "2012-04-22 20:49:00 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    }, {
      "name" : "Meteor",
      "screen_name" : "meteorjs",
      "indices" : [ 95, 104 ],
      "id_str" : "533884891",
      "id" : 533884891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194163321275039744",
  "geo" : { },
  "id_str" : "194163585306476545",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I would go express - but that just cos I am currently using it. Did you ever look at @meteorjs ?",
  "id" : 194163585306476545,
  "in_reply_to_status_id" : 194163321275039744,
  "created_at" : "2012-04-22 20:39:40 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/Hkaudsgp",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3163-making-shit-work-is-everyones-job",
      "display_url" : "37signals.com\/svn\/posts\/3163\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194162008545964034",
  "text" : "http:\/\/t.co\/Hkaudsgp This is by far my favourite article so far though. Number of times I have heard that in relation to server stuff...",
  "id" : 194162008545964034,
  "created_at" : "2012-04-22 20:33:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/hJq3HtYe",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/1941-press-release-37signals-valuation-tops-100-billion-after-bold-vc-investment",
      "display_url" : "37signals.com\/svn\/posts\/1941\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194161591355322369",
  "text" : "http:\/\/t.co\/hJq3HtYe - I &lt;3 this company.... They say what I want to without cursing and actually make sense! Yes I am late to the party!",
  "id" : 194161591355322369,
  "created_at" : "2012-04-22 20:31:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194120010040483841",
  "text" : ".. The Sunday papers. I can't remember when I last bought a paper or watched news on the tee-vee.",
  "id" : 194120010040483841,
  "created_at" : "2012-04-22 17:46:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194119530711224320",
  "text" : "Have spent this afternoon at my folks. Amazed at how different me and my Dad are in getting news. He watches every bulletin and reads...",
  "id" : 194119530711224320,
  "created_at" : "2012-04-22 17:44:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194100440311414784",
  "geo" : { },
  "id_str" : "194101610102784000",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit You were in Lisburn and you didn't call in for a cuppa.. Bastard - I'd have welcomed you with open arms too :)",
  "id" : 194101610102784000,
  "in_reply_to_status_id" : 194100440311414784,
  "created_at" : "2012-04-22 16:33:24 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 99, 115 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194012122877919233",
  "text" : "I've got a huge guy crush on David Heinemeier Hansson - everything the man says makes sense. Sorry @michaelnsimpson you're out ;)",
  "id" : 194012122877919233,
  "created_at" : "2012-04-22 10:37:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 15, 26 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193819606207574017",
  "geo" : { },
  "id_str" : "193821817700491264",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @alana_doll I avoid all forums and even discussion on the subjects. Apologies.",
  "id" : 193821817700491264,
  "in_reply_to_status_id" : 193819606207574017,
  "created_at" : "2012-04-21 22:01:37 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193804560266043393",
  "text" : "Funeral to go to tomorrow. Next door neighbour. Hate these things, granted not much craic for the person that died to be fair.",
  "id" : 193804560266043393,
  "created_at" : "2012-04-21 20:53:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Abinante",
      "screen_name" : "feministy",
      "indices" : [ 0, 10 ],
      "id_str" : "7039892",
      "id" : 7039892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193788525672542208",
  "geo" : { },
  "id_str" : "193798244281749506",
  "in_reply_to_user_id" : 7039892,
  "text" : "@feministy I can do it if you haven't got someone to help already.",
  "id" : 193798244281749506,
  "in_reply_to_status_id" : 193788525672542208,
  "created_at" : "2012-04-21 20:27:56 +0000",
  "in_reply_to_screen_name" : "feministy",
  "in_reply_to_user_id_str" : "7039892",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 14, 26 ],
      "id_str" : "760043",
      "id" : 760043
    }, {
      "name" : "Geoff Taylor",
      "screen_name" : "OpinionatedGeek",
      "indices" : [ 27, 43 ],
      "id_str" : "16894344",
      "id" : 16894344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193749991909634049",
  "geo" : { },
  "id_str" : "193797586677792768",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @straytaoist @opinionatedgeek I can't wait till development goes back to proper geeks & this rock star generation fucks up :)",
  "id" : 193797586677792768,
  "in_reply_to_status_id" : 193749991909634049,
  "created_at" : "2012-04-21 20:25:19 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193746230050951168",
  "geo" : { },
  "id_str" : "193797295576334336",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore are they gonna continue with this timeline thing?",
  "id" : 193797295576334336,
  "in_reply_to_status_id" : 193746230050951168,
  "created_at" : "2012-04-21 20:24:10 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 40, 56 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193766162180476928",
  "text" : "Want this noted for future. I just gave @michaelnsimpson the best motivation to start a company. One part was \"desks on wheels\" the other...",
  "id" : 193766162180476928,
  "created_at" : "2012-04-21 18:20:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/193760562868523008\/photo\/1",
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/Nrut52A8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArBgNJFCEAIUsEZ.jpg",
      "id_str" : "193760562868523010",
      "id" : 193760562868523010,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArBgNJFCEAIUsEZ.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/Nrut52A8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193760562868523008",
  "text" : "WTF :) http:\/\/t.co\/Nrut52A8",
  "id" : 193760562868523008,
  "created_at" : "2012-04-21 17:58:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193738953310994432",
  "text" : "\"Some of us had to spend their freshmen year making those recordings... and leading a disastrous monkey escape.\" I &lt;3 30Rock.",
  "id" : 193738953310994432,
  "created_at" : "2012-04-21 16:32:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 17, 27 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193706590287826945",
  "geo" : { },
  "id_str" : "193720671837237250",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @burkazoid what is this voodoo? \/me reads a bit more",
  "id" : 193720671837237250,
  "in_reply_to_status_id" : 193706590287826945,
  "created_at" : "2012-04-21 15:19:41 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/qcdo1bLG",
      "expanded_url" : "http:\/\/www.businessinsider.com\/hey-linkedin-youd-better-go-buy-branchout-before-facebook-does-2012-4",
      "display_url" : "businessinsider.com\/hey-linkedin-y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193720128683253761",
  "text" : "Sooner or later this bubble is gonna pop... http:\/\/t.co\/qcdo1bLG",
  "id" : 193720128683253761,
  "created_at" : "2012-04-21 15:17:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193435937798238210",
  "geo" : { },
  "id_str" : "193470856868016128",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq awesome :D",
  "id" : 193470856868016128,
  "in_reply_to_status_id" : 193435937798238210,
  "created_at" : "2012-04-20 22:47:01 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193385755635220480",
  "text" : "Killerking Killerking Killerking Killerking - 3 in a fucking row!!!! Killerking Killerking Killerking.",
  "id" : 193385755635220480,
  "created_at" : "2012-04-20 17:08:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 52, 68 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 69, 76 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 81, 94 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tascomikingofkiller",
      "indices" : [ 112, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193372743503331329",
  "text" : "I am the killer master - won 3 in a row and it took @michaelnsimpson @srushe and @RickyHassard to defeat me! :D #tascomikingofkiller",
  "id" : 193372743503331329,
  "created_at" : "2012-04-20 16:17:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193350799005466624",
  "geo" : { },
  "id_str" : "193351751846473728",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist :D Shoreditch.... Never....",
  "id" : 193351751846473728,
  "in_reply_to_status_id" : 193350799005466624,
  "created_at" : "2012-04-20 14:53:44 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193350235068702720",
  "geo" : { },
  "id_str" : "193350542838345728",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I've had enough of things of tattooed pink-haired hipster chicks for the time being thanks ;)",
  "id" : 193350542838345728,
  "in_reply_to_status_id" : 193350235068702720,
  "created_at" : "2012-04-20 14:48:56 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193349505125584896",
  "geo" : { },
  "id_str" : "193349872311730176",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I wouldn't survive two seconds in silicon round about :D I hate that feckin Hello World demo :(",
  "id" : 193349872311730176,
  "in_reply_to_status_id" : 193349505125584896,
  "created_at" : "2012-04-20 14:46:16 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193348911908388865",
  "geo" : { },
  "id_str" : "193349106305990656",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I read somewhere that it wouldn't. Also my interest in node.js is cos I missed the boat on Ruby - and am now in PHP land :(",
  "id" : 193349106305990656,
  "in_reply_to_status_id" : 193348911908388865,
  "created_at" : "2012-04-20 14:43:13 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193345982228992000",
  "text" : "Am glad to see some articles about getting node.js working on a raspberrypi - didn't think ARM would play ball :)",
  "id" : 193345982228992000,
  "created_at" : "2012-04-20 14:30:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Gallacher",
      "screen_name" : "tomgco",
      "indices" : [ 3, 10 ],
      "id_str" : "23053834",
      "id" : 23053834
    }, {
      "name" : "node js",
      "screen_name" : "nodejs",
      "indices" : [ 27, 34 ],
      "id_str" : "91985735",
      "id" : 91985735
    }, {
      "name" : "Raspberry Pi",
      "screen_name" : "Raspberry_Pi",
      "indices" : [ 43, 56 ],
      "id_str" : "302666251",
      "id" : 302666251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/2CrpuYMI",
      "expanded_url" : "http:\/\/blog.tomg.co\/post\/21322413373\/how-to-install-node-js-on-your-raspberry-pi",
      "display_url" : "blog.tomg.co\/post\/213224133\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193345812623933440",
  "text" : "RT @tomgco: How to install @nodejs on your @Raspberry_Pi Tutorial; http:\/\/t.co\/2CrpuYMI",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "node js",
        "screen_name" : "nodejs",
        "indices" : [ 15, 22 ],
        "id_str" : "91985735",
        "id" : 91985735
      }, {
        "name" : "Raspberry Pi",
        "screen_name" : "Raspberry_Pi",
        "indices" : [ 31, 44 ],
        "id_str" : "302666251",
        "id" : 302666251
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/2CrpuYMI",
        "expanded_url" : "http:\/\/blog.tomg.co\/post\/21322413373\/how-to-install-node-js-on-your-raspberry-pi",
        "display_url" : "blog.tomg.co\/post\/213224133\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "192599718671552513",
    "text" : "How to install @nodejs on your @Raspberry_Pi Tutorial; http:\/\/t.co\/2CrpuYMI",
    "id" : 192599718671552513,
    "created_at" : "2012-04-18 13:05:25 +0000",
    "user" : {
      "name" : "Tom Gallacher",
      "screen_name" : "tomgco",
      "protected" : false,
      "id_str" : "23053834",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3654199166\/2fd3cf5c087b5d1eb50c8d1a1c91bab1_normal.jpeg",
      "id" : 23053834,
      "verified" : false
    }
  },
  "id" : 193345812623933440,
  "created_at" : "2012-04-20 14:30:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 93, 109 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mikehastoquote",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193324482465767424",
  "text" : "The only dude in the world that can actually quote Rocky and sound camp - I introduce to you @michaelnsimpson #mikehastoquote",
  "id" : 193324482465767424,
  "created_at" : "2012-04-20 13:05:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 15, 29 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193317016147464193",
  "geo" : { },
  "id_str" : "193324298470031361",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @jenporterhall :D :D :D Rain Rain Rain Rain Rain Rain",
  "id" : 193324298470031361,
  "in_reply_to_status_id" : 193317016147464193,
  "created_at" : "2012-04-20 13:04:39 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193289482651451393",
  "geo" : { },
  "id_str" : "193291232917725184",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin tity sprinkles.....",
  "id" : 193291232917725184,
  "in_reply_to_status_id" : 193289482651451393,
  "created_at" : "2012-04-20 10:53:15 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193288903476789248",
  "geo" : { },
  "id_str" : "193289322168991745",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid surely that's a hugely untapped market though - big pizzas for lunchtime hipster\/startup type places... Yeah I said it ;) :D",
  "id" : 193289322168991745,
  "in_reply_to_status_id" : 193288903476789248,
  "created_at" : "2012-04-20 10:45:40 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193287246651199488",
  "geo" : { },
  "id_str" : "193288749759737856",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid how come? That sounds a bt weird.. Surely its just a bigger pizza than normal? Unless the ovens aren't ready for lunchtime? :(",
  "id" : 193288749759737856,
  "in_reply_to_status_id" : 193287246651199488,
  "created_at" : "2012-04-20 10:43:23 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193277478813437954",
  "geo" : { },
  "id_str" : "193277963893080064",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall Grrrrrr!!!!!!!!! Minnie is gonna be in some positions this weekend with Snoopy!!! :D",
  "id" : 193277963893080064,
  "in_reply_to_status_id" : 193277478813437954,
  "created_at" : "2012-04-20 10:00:32 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 59, 73 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193272909823877120",
  "text" : "Number 6591 of things that wind the living crap out of me: @jenporterhall saying \"Ehhhhhhhhhh\".",
  "id" : 193272909823877120,
  "created_at" : "2012-04-20 09:40:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193272189192114176",
  "geo" : { },
  "id_str" : "193272679057469441",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley Firstly \"Ehhhhh\" and secondly Star Wars is much better than SATC.",
  "id" : 193272679057469441,
  "in_reply_to_status_id" : 193272189192114176,
  "created_at" : "2012-04-20 09:39:32 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "starwarsquote",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193259883435528192",
  "geo" : { },
  "id_str" : "193269908765818880",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley Don't get cocky... Han Solo said that to Luke Skywalker... #starwarsquote",
  "id" : 193269908765818880,
  "in_reply_to_status_id" : 193259883435528192,
  "created_at" : "2012-04-20 09:28:31 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193073088949272576",
  "geo" : { },
  "id_str" : "193073560993017856",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams I am making you jack! You got your dinner made for you tonight :( Of course there will enuff tuna and soda for ya",
  "id" : 193073560993017856,
  "in_reply_to_status_id" : 193073088949272576,
  "created_at" : "2012-04-19 20:28:18 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193072536790122497",
  "geo" : { },
  "id_str" : "193072887039655937",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams I am gonna procure some soda bread tomorrow so you can witness the greatness that is a soda tuna sandwich.",
  "id" : 193072887039655937,
  "in_reply_to_status_id" : 193072536790122497,
  "created_at" : "2012-04-19 20:25:38 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 3, 17 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 44, 50 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/ZKwfHllf",
      "expanded_url" : "http:\/\/yfrog.com\/mmhjmllj",
      "display_url" : "yfrog.com\/mmhjmllj"
    } ]
  },
  "geo" : { },
  "id_str" : "193072306380210177",
  "text" : "RT @jenporterhall: Rumbled!! After 4 months @swmcc has fallen off the wagon!  http:\/\/t.co\/ZKwfHllf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 25, 31 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/ZKwfHllf",
        "expanded_url" : "http:\/\/yfrog.com\/mmhjmllj",
        "display_url" : "yfrog.com\/mmhjmllj"
      } ]
    },
    "geo" : { },
    "id_str" : "193026556342452224",
    "text" : "Rumbled!! After 4 months @swmcc has fallen off the wagon!  http:\/\/t.co\/ZKwfHllf",
    "id" : 193026556342452224,
    "created_at" : "2012-04-19 17:21:31 +0000",
    "user" : {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "protected" : false,
      "id_str" : "227493010",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2257082551\/DSCF9612_normal.jpg",
      "id" : 227493010,
      "verified" : false
    }
  },
  "id" : 193072306380210177,
  "created_at" : "2012-04-19 20:23:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 64, 76 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193070201397444608",
  "geo" : { },
  "id_str" : "193071898190548992",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard BAD: You didn't know me seven years ago. GOOD: No @niall_adams.",
  "id" : 193071898190548992,
  "in_reply_to_status_id" : 193070201397444608,
  "created_at" : "2012-04-19 20:21:42 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 7, 19 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FAIL",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192993530656985088",
  "geo" : { },
  "id_str" : "192993807237779456",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @niall_adams I fucked up the quote..... Now it sounds like there was a donkey thinking of me on a beach and getting a hard on. #FAIL",
  "id" : 192993807237779456,
  "in_reply_to_status_id" : 192993530656985088,
  "created_at" : "2012-04-19 15:11:23 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 60, 66 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 71, 83 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192993530656985088",
  "text" : "\"I saw a pic of a donkey with a hard on that thought of you @swmcc\" by @niall_adams",
  "id" : 192993530656985088,
  "created_at" : "2012-04-19 15:10:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192773332339400705",
  "geo" : { },
  "id_str" : "192776113334919168",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne not long till Sept though :D Then its beetle dreaming :)",
  "id" : 192776113334919168,
  "in_reply_to_status_id" : 192773332339400705,
  "created_at" : "2012-04-19 00:46:21 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192669249024696321",
  "geo" : { },
  "id_str" : "192675114498785280",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson shit I meant to mention you in that. Was in a rush on my way to Belfast. It sucks here but needs must :(",
  "id" : 192675114498785280,
  "in_reply_to_status_id" : 192669249024696321,
  "created_at" : "2012-04-18 18:05:01 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/192667847418318848\/photo\/1",
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/oBeLCr7o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aqx-Yu1CEAAgshb.jpg",
      "id_str" : "192667847422513152",
      "id" : 192667847422513152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aqx-Yu1CEAAgshb.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/oBeLCr7o"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192667847418318848",
  "text" : ":) Don't head fuck me again :) That'll fester there alllllll night ;) http:\/\/t.co\/oBeLCr7o",
  "id" : 192667847418318848,
  "created_at" : "2012-04-18 17:36:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192639959319068672",
  "geo" : { },
  "id_str" : "192643651694891009",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson \/me claps :D Most confusing phone call ever \"Mike said he was in the office though?\" - *head explodes*",
  "id" : 192643651694891009,
  "in_reply_to_status_id" : 192639959319068672,
  "created_at" : "2012-04-18 16:00:00 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192578919843635201",
  "geo" : { },
  "id_str" : "192581170737852417",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore didn't like Thor... So am dubious about this one.. Will still go see it like.",
  "id" : 192581170737852417,
  "in_reply_to_status_id" : 192578919843635201,
  "created_at" : "2012-04-18 11:51:43 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 13, 27 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192580465008455680",
  "geo" : { },
  "id_str" : "192581059072897026",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @no_underscore my bio says that actually - has done since the start :D",
  "id" : 192581059072897026,
  "in_reply_to_status_id" : 192580465008455680,
  "created_at" : "2012-04-18 11:51:17 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192578177808351232",
  "geo" : { },
  "id_str" : "192578501440847872",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore you mean you are gonna sit through Thor again? That's hardcore... I think this film maybe a step too far but still :)",
  "id" : 192578501440847872,
  "in_reply_to_status_id" : 192578177808351232,
  "created_at" : "2012-04-18 11:41:07 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jemma Simpson",
      "screen_name" : "JemmaSimpsonIT",
      "indices" : [ 0, 15 ],
      "id_str" : "491327765",
      "id" : 491327765
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 16, 27 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 28, 41 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192574347020476416",
  "geo" : { },
  "id_str" : "192576445107814400",
  "in_reply_to_user_id" : 491327765,
  "text" : "@JemmaSimpsonIT @johngirvin @stevebiscuit took us over 5 months to find a new dev. Distinct lack of talent out there at the mo :(",
  "id" : 192576445107814400,
  "in_reply_to_status_id" : 192574347020476416,
  "created_at" : "2012-04-18 11:32:57 +0000",
  "in_reply_to_screen_name" : "JemmaSimpsonIT",
  "in_reply_to_user_id_str" : "491327765",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 6, 20 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192573539851845632",
  "text" : "Hmmmm @jenporterhall just said \"Its Jenni from Tascomi\"... out loud on the phone there.. Now I have \"Jenni from the block\" in my head...",
  "id" : 192573539851845632,
  "created_at" : "2012-04-18 11:21:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 85, 101 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192354667668307968",
  "text" : "My 6000th tweet was confessing my love of SATC. Could have been the one saying about @michaelnsimpson sexy ass. What a digital footprint!",
  "id" : 192354667668307968,
  "created_at" : "2012-04-17 20:51:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192353174147956736",
  "geo" : { },
  "id_str" : "192353910713880579",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley for fuck sake!!! I suck I really really do!!!!",
  "id" : 192353910713880579,
  "in_reply_to_status_id" : 192353174147956736,
  "created_at" : "2012-04-17 20:48:40 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192351971766845440",
  "geo" : { },
  "id_str" : "192352479466369024",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 Come Aaaan!!!",
  "id" : 192352479466369024,
  "in_reply_to_status_id" : 192351971766845440,
  "created_at" : "2012-04-17 20:42:59 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192351367040466945",
  "geo" : { },
  "id_str" : "192351676324257793",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson I wish they would change the title as it puts man my off. It's pretty good! Peeeeenniiiieeeee Caaaaaan!!",
  "id" : 192351676324257793,
  "in_reply_to_status_id" : 192351367040466945,
  "created_at" : "2012-04-17 20:39:48 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192350993390903296",
  "geo" : { },
  "id_str" : "192351287113818112",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson no worries, your sexy ass isn't in tomorrow anyway ;) TBD on Thursday though :)",
  "id" : 192351287113818112,
  "in_reply_to_status_id" : 192350993390903296,
  "created_at" : "2012-04-17 20:38:15 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/9gpVFuk2",
      "expanded_url" : "http:\/\/search.npmjs.org\/",
      "display_url" : "search.npmjs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "192349703931830272",
  "text" : "RT @substack: over 9000 http:\/\/t.co\/9gpVFuk2",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 30 ],
        "url" : "http:\/\/t.co\/9gpVFuk2",
        "expanded_url" : "http:\/\/search.npmjs.org\/",
        "display_url" : "search.npmjs.org"
      } ]
    },
    "geo" : { },
    "id_str" : "192341716643217408",
    "text" : "over 9000 http:\/\/t.co\/9gpVFuk2",
    "id" : 192341716643217408,
    "created_at" : "2012-04-17 20:00:13 +0000",
    "user" : {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 192349703931830272,
  "created_at" : "2012-04-17 20:31:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192348458034790401",
  "geo" : { },
  "id_str" : "192349053323968514",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson aye. It shows NY so am hoping it's good. I want a replacement for SATC. I am happy to admit that.",
  "id" : 192349053323968514,
  "in_reply_to_status_id" : 192348458034790401,
  "created_at" : "2012-04-17 20:29:22 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 17, 31 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192348021491630080",
  "geo" : { },
  "id_str" : "192348405815709696",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @berryblonde84 you watching the latest episode of MM?",
  "id" : 192348405815709696,
  "in_reply_to_status_id" : 192348021491630080,
  "created_at" : "2012-04-17 20:26:48 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 19, 35 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192347463640809472",
  "text" : "This new show that @michaelnsimpson recommended is pretty fuckin good!!",
  "id" : 192347463640809472,
  "created_at" : "2012-04-17 20:23:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192281096187154432",
  "text" : "The Ulsterbank across the street for me makes me laugh... Promptly at 5 they are all out the door!",
  "id" : 192281096187154432,
  "created_at" : "2012-04-17 15:59:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192271490274697216",
  "text" : "I know i am working hard today.. So far 3 cups of tea and 3 cups of coffee... Now to have one more cuppa for the day...",
  "id" : 192271490274697216,
  "created_at" : "2012-04-17 15:21:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brian d foy",
      "screen_name" : "briandfoy_perl",
      "indices" : [ 3, 18 ],
      "id_str" : "89105157",
      "id" : 89105157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192266861533081602",
  "text" : "RT @briandfoy_perl: I love Perl's XML::Twig. If you grok DOM processing, it makes handling XML even easier than the regex games people t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/xRVK9NAn",
        "expanded_url" : "http:\/\/bit.ly\/IuaSvI",
        "display_url" : "bit.ly\/IuaSvI"
      } ]
    },
    "geo" : { },
    "id_str" : "192263165030051840",
    "text" : "I love Perl's XML::Twig. If you grok DOM processing, it makes handling XML even easier than the regex games people try. http:\/\/t.co\/xRVK9NAn",
    "id" : 192263165030051840,
    "created_at" : "2012-04-17 14:48:05 +0000",
    "user" : {
      "name" : "brian d foy",
      "screen_name" : "briandfoy_perl",
      "protected" : false,
      "id_str" : "89105157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1563922007\/headshot_normal.jpg",
      "id" : 89105157,
      "verified" : false
    }
  },
  "id" : 192266861533081602,
  "created_at" : "2012-04-17 15:02:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192044840073166848",
  "geo" : { },
  "id_str" : "192048647779790848",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Noooo so wrong :( Its keeping me up.....",
  "id" : 192048647779790848,
  "in_reply_to_status_id" : 192044840073166848,
  "created_at" : "2012-04-17 00:35:40 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mikehastoquote",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191991152843571200",
  "text" : "challenge this week... Due to the epic failure this time.. I am opening it up to twitter. Has to be Rocky quotes. Hash it as #mikehastoquote",
  "id" : 191991152843571200,
  "created_at" : "2012-04-16 20:47:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 7, 23 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191990968118018049",
  "text" : "Due to @michaelnsimpson losing all his man cards in the space of 6 hours AND lambasting Rocky - he has to quote Rocky quotes for his man.",
  "id" : 191990968118018049,
  "created_at" : "2012-04-16 20:46:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mikehastoquote",
      "indices" : [ 72, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191990750249103360",
  "text" : "\"Hey fool! You ready for another beating? You shoulda never came back!\" #mikehastoquote",
  "id" : 191990750249103360,
  "created_at" : "2012-04-16 20:45:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mikehastoquote",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191990310560219136",
  "text" : "\"To all my love slaves out there: Thunderlips is here. In the flesh, baby. The ultimate male versus. the ultimate meatball.\" #mikehastoquote",
  "id" : 191990310560219136,
  "created_at" : "2012-04-16 20:43:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mikehastoquote",
      "indices" : [ 79, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191990100652072962",
  "text" : "\"What did you say, Paper Champion? I'll beat you like a dog, a dog, you fool!\" #mikehastoquote",
  "id" : 191990100652072962,
  "created_at" : "2012-04-16 20:43:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mikehastoquote",
      "indices" : [ 58, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191989788625215488",
  "text" : "\"What's your prediction for the fight?.... ***PAIN!!!***\" #mikehastoquote",
  "id" : 191989788625215488,
  "created_at" : "2012-04-16 20:41:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mikehastoquote",
      "indices" : [ 51, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191989427449503744",
  "text" : "\"Go for the ribs, don't let that bastard breathe!\" #mikehastoquote",
  "id" : 191989427449503744,
  "created_at" : "2012-04-16 20:40:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mikehastoquote",
      "indices" : [ 50, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191989028223066113",
  "text" : "\"Get up you son of a bitch! Cuz Mickey loves ya.\" #mikehastoquote",
  "id" : 191989028223066113,
  "created_at" : "2012-04-16 20:38:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mikehastoquote",
      "indices" : [ 67, 82 ]
    }, {
      "text" : "rocky",
      "indices" : [ 83, 89 ]
    }, {
      "text" : "endtgecoldwarsongkehandily",
      "indices" : [ 90, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191985655662903299",
  "text" : "\"If I can change.... And you can change.... EVERYONE can change!!\" #mikehastoquote #rocky #endtgecoldwarsongkehandily",
  "id" : 191985655662903299,
  "created_at" : "2012-04-16 20:25:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191981878339846144",
  "geo" : { },
  "id_str" : "191982784590520320",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard personal projects or work?",
  "id" : 191982784590520320,
  "in_reply_to_status_id" : 191981878339846144,
  "created_at" : "2012-04-16 20:13:57 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191982035546537984",
  "geo" : { },
  "id_str" : "191982391995277312",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley FFS!!! I am thinking of taking one off for next week. Quoting Rocky is the coolest thing you can do!!!!",
  "id" : 191982391995277312,
  "in_reply_to_status_id" : 191982035546537984,
  "created_at" : "2012-04-16 20:12:23 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Sterling Jr.",
      "screen_name" : "RogerSterlingJr",
      "indices" : [ 3, 19 ],
      "id_str" : "554085327",
      "id" : 554085327
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 21, 27 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterThanDraper",
      "indices" : [ 70, 87 ]
    }, {
      "text" : "SterlingsGold",
      "indices" : [ 88, 102 ]
    }, {
      "text" : "Madmen",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191978047073824768",
  "text" : "RT @RogerSterlingJr: @swmcc Start by having a Gibson for breakfast... #BetterThanDraper #SterlingsGold #Madmen",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BetterThanDraper",
        "indices" : [ 49, 66 ]
      }, {
        "text" : "SterlingsGold",
        "indices" : [ 67, 81 ]
      }, {
        "text" : "Madmen",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "191973258592141312",
    "geo" : { },
    "id_str" : "191977757138366465",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Start by having a Gibson for breakfast... #BetterThanDraper #SterlingsGold #Madmen",
    "id" : 191977757138366465,
    "in_reply_to_status_id" : 191973258592141312,
    "created_at" : "2012-04-16 19:53:58 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Roger Sterling Jr.",
      "screen_name" : "RogerSterlingJr",
      "protected" : false,
      "id_str" : "554085327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2123197131\/mm-s5-john-slattery-590_normal.jpg",
      "id" : 554085327,
      "verified" : false
    }
  },
  "id" : 191978047073824768,
  "created_at" : "2012-04-16 19:55:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191976253631381504",
  "geo" : { },
  "id_str" : "191977997522313216",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson get him to quote the best quotes of Rocky... Out loud and with gusto! \"Hurt\/ing\/ Bombs???\"...",
  "id" : 191977997522313216,
  "in_reply_to_status_id" : 191976253631381504,
  "created_at" : "2012-04-16 19:54:56 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191973258592141312",
  "text" : "I really really really want to be Roger Sterling....",
  "id" : 191973258592141312,
  "created_at" : "2012-04-16 19:36:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191890432878317568",
  "text" : "\u201C@michaelnsimpson: if you don't give me a card back i'm going to have to dish out some hurt-ing bombs.",
  "id" : 191890432878317568,
  "created_at" : "2012-04-16 14:06:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191890142947057664",
  "text" : "OH: \"Lets build some hurtin bombs!!!\" \"Hurt\/ing\/ bombs????\"... Guess who said that and is now a man card down :(",
  "id" : 191890142947057664,
  "created_at" : "2012-04-16 14:05:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 21, 37 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/RQ67jZEZ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=nRFiTwQwcNk",
      "display_url" : "youtube.com\/watch?v=nRFiTw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191889749810757632",
  "text" : "Man Card Down.. Took @michaelnsimpson less than six hours to lose them all... New record... He didn't get this http:\/\/t.co\/RQ67jZEZ",
  "id" : 191889749810757632,
  "created_at" : "2012-04-16 14:04:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "John Walker",
      "screen_name" : "botherer",
      "indices" : [ 10, 19 ],
      "id_str" : "19785044",
      "id" : 19785044
    }, {
      "name" : "Mary Hamilton",
      "screen_name" : "newsmary",
      "indices" : [ 20, 29 ],
      "id_str" : "80262276",
      "id" : 80262276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191876308840615938",
  "geo" : { },
  "id_str" : "191884169197002752",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @botherer @newsmary Game companies just like the TV stations just don't get it.. Guess they'll get it at some stage though :(",
  "id" : 191884169197002752,
  "in_reply_to_status_id" : 191876308840615938,
  "created_at" : "2012-04-16 13:42:05 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rebecca brownlie",
      "screen_name" : "RB__Photography",
      "indices" : [ 0, 16 ],
      "id_str" : "21508246",
      "id" : 21508246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191866418789224448",
  "geo" : { },
  "id_str" : "191871976896335873",
  "in_reply_to_user_id" : 21508246,
  "text" : "@RB__Photography i am. I don't hate it - but don't use it much. Guess you have to be an avid photo taker. I am not.",
  "id" : 191871976896335873,
  "in_reply_to_status_id" : 191866418789224448,
  "created_at" : "2012-04-16 12:53:38 +0000",
  "in_reply_to_screen_name" : "RB__Photography",
  "in_reply_to_user_id_str" : "21508246",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191792402405654528",
  "text" : "I wont cry on the way into work.. I wont cry.. I wont.... Nope... WAAAAAAHHHHHHHHHHHHHHHH :( And its fucking sunny too!",
  "id" : 191792402405654528,
  "created_at" : "2012-04-16 07:37:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191662616517681153",
  "geo" : { },
  "id_str" : "191662852027842565",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq i was impressed to be honest. But not sure about tying my projects to it.",
  "id" : 191662852027842565,
  "in_reply_to_status_id" : 191662616517681153,
  "created_at" : "2012-04-15 23:02:39 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 18, 25 ],
      "id_str" : "285766850",
      "id" : 285766850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191644366014644227",
  "text" : "Big thanks to the @NodeUp peeps for a good show.. Had to run so didn't get the last part so will download it later :)",
  "id" : 191644366014644227,
  "created_at" : "2012-04-15 21:49:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191639208484544513",
  "geo" : { },
  "id_str" : "191640321396973569",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne :D :D That last tweet has made me smile :D",
  "id" : 191640321396973569,
  "in_reply_to_status_id" : 191639208484544513,
  "created_at" : "2012-04-15 21:33:07 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191638304700112897",
  "geo" : { },
  "id_str" : "191640205231521792",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq :D I am getting into node just cos its making the same noise ruby did 7 years ago. Not getting caught out this time :)",
  "id" : 191640205231521792,
  "in_reply_to_status_id" : 191638304700112897,
  "created_at" : "2012-04-15 21:32:40 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191635213472894976",
  "text" : "I like my job and all - don't get me wrong... But fuck me I do hate Sunday nights..",
  "id" : 191635213472894976,
  "created_at" : "2012-04-15 21:12:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191635042349494272",
  "text" : "Yeah... Am back to hating Sunday nights - only difference this time I just want to get it over with - like ripping off a plaster :(",
  "id" : 191635042349494272,
  "created_at" : "2012-04-15 21:12:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191631168477728768",
  "geo" : { },
  "id_str" : "191634867971297281",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq am actually writing stuff in Mongo at the mo... Its quite nice. Odd to be going away from RDMS though - but sure...",
  "id" : 191634867971297281,
  "in_reply_to_status_id" : 191631168477728768,
  "created_at" : "2012-04-15 21:11:27 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191624808302247936",
  "geo" : { },
  "id_str" : "191628542918926336",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq you might want to look at meteor - it seems quite good... but not really sure about anything in node just yet. Still fact finding.",
  "id" : 191628542918926336,
  "in_reply_to_status_id" : 191624808302247936,
  "created_at" : "2012-04-15 20:46:19 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191623689014489088",
  "geo" : { },
  "id_str" : "191624275130720256",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq me too :) Ubuntu should be able to have npm and node installed no bother. Am sure it runs on windows just as well...",
  "id" : 191624275130720256,
  "in_reply_to_status_id" : 191623689014489088,
  "created_at" : "2012-04-15 20:29:22 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 15, 27 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191621023676903426",
  "geo" : { },
  "id_str" : "191622983238942722",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @kirstylvssp apologies...",
  "id" : 191622983238942722,
  "in_reply_to_status_id" : 191621023676903426,
  "created_at" : "2012-04-15 20:24:14 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191580433044094977",
  "geo" : { },
  "id_str" : "191622817387786240",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne impressive :)",
  "id" : 191622817387786240,
  "in_reply_to_status_id" : 191580433044094977,
  "created_at" : "2012-04-15 20:23:34 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191622106923012098",
  "geo" : { },
  "id_str" : "191622312020283392",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq :D I found the SocketStream interesting. Gutted no one from express was there :( You not feeling it?",
  "id" : 191622312020283392,
  "in_reply_to_status_id" : 191622106923012098,
  "created_at" : "2012-04-15 20:21:34 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191621237087272960",
  "in_reply_to_user_id" : 453312717,
  "text" : "@kirstylvssp knew that something was up.. Was very sweet. Our cat never got over Tessa dying - and has little respect for the new dog :)",
  "id" : 191621237087272960,
  "created_at" : "2012-04-15 20:17:17 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191621005486198784",
  "in_reply_to_user_id" : 453312717,
  "text" : "@kirstylvssp walked away and lay down on the patio.. And our cat took some of her food in her mouth and carried it over to Tessa cos she..",
  "id" : 191621005486198784,
  "created_at" : "2012-04-15 20:16:22 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191620853627240449",
  "in_reply_to_user_id" : 453312717,
  "text" : "@kirstylvssp anyway that morning we thought we would still offer her some food in the morning so fed both of them. Tessa just ....",
  "id" : 191620853627240449,
  "created_at" : "2012-04-15 20:15:46 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191620698203111424",
  "in_reply_to_user_id" : 453312717,
  "text" : "@kirstylvssp each morning for years and were good mates.. Tessa stopped eating a few days and we knew it was time. She just wanted to die.",
  "id" : 191620698203111424,
  "created_at" : "2012-04-15 20:15:09 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191619976820563968",
  "geo" : { },
  "id_str" : "191620511833399297",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp even worse she just stopped eating and wanted to die - and our cat knew something was up.. they always got fed at the same time",
  "id" : 191620511833399297,
  "in_reply_to_status_id" : 191619976820563968,
  "created_at" : "2012-04-15 20:14:24 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191619976820563968",
  "geo" : { },
  "id_str" : "191620373673033728",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp my old dog tessa was like that - old family dog that grew up with me and my siblings... Very sad when she died :(",
  "id" : 191620373673033728,
  "in_reply_to_status_id" : 191619976820563968,
  "created_at" : "2012-04-15 20:13:51 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191619298760982528",
  "geo" : { },
  "id_str" : "191619586473476097",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley reminds me of my old dog tessa - and my parents dog is getting on in years too - golden labs.. Tooo sad :(",
  "id" : 191619586473476097,
  "in_reply_to_status_id" : 191619298760982528,
  "created_at" : "2012-04-15 20:10:44 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191618028708962304",
  "geo" : { },
  "id_str" : "191619045550850049",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley Oh I couldn't watch that - not on a Sunday night - would kill me :( Very sad film :( :( :(",
  "id" : 191619045550850049,
  "in_reply_to_status_id" : 191618028708962304,
  "created_at" : "2012-04-15 20:08:35 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.ustream.tv\" rel=\"nofollow\"\u003EUstream.TV\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/dpZMVeSg",
      "expanded_url" : "http:\/\/ustre.am\/BFFe\/2",
      "display_url" : "ustre.am\/BFFe\/2"
    } ]
  },
  "geo" : { },
  "id_str" : "191600004346036224",
  "text" : "I just checked into NodeUp on Ustream. Come watch and chat with me here http:\/\/t.co\/dpZMVeSg",
  "id" : 191600004346036224,
  "created_at" : "2012-04-15 18:52:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/zx1KATK0",
      "expanded_url" : "http:\/\/www.ustream.tv\/channel\/nodeup",
      "display_url" : "ustream.tv\/channel\/nodeup"
    } ]
  },
  "in_reply_to_status_id_str" : "191598536754855936",
  "geo" : { },
  "id_str" : "191599884158255104",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq http:\/\/t.co\/zx1KATK0",
  "id" : 191599884158255104,
  "in_reply_to_status_id" : 191598536754855936,
  "created_at" : "2012-04-15 18:52:26 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191596787126120448",
  "geo" : { },
  "id_str" : "191597890328731649",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq someone like you? If you are interested in developing then yeah - its pretty node heavy though.",
  "id" : 191597890328731649,
  "in_reply_to_status_id" : 191596787126120448,
  "created_at" : "2012-04-15 18:44:31 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Custom Colour Golf",
      "screen_name" : "c_c_golf",
      "indices" : [ 3, 12 ],
      "id_str" : "388863563",
      "id" : 388863563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/ZRoBbaGi",
      "expanded_url" : "http:\/\/fb.me\/Xi2pkufI",
      "display_url" : "fb.me\/Xi2pkufI"
    } ]
  },
  "geo" : { },
  "id_str" : "191578405895012353",
  "text" : "RT @c_c_golf: Rory Mcilroy moves back to world number 1 -... http:\/\/t.co\/ZRoBbaGi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/ZRoBbaGi",
        "expanded_url" : "http:\/\/fb.me\/Xi2pkufI",
        "display_url" : "fb.me\/Xi2pkufI"
      } ]
    },
    "geo" : { },
    "id_str" : "191576423390130177",
    "text" : "Rory Mcilroy moves back to world number 1 -... http:\/\/t.co\/ZRoBbaGi",
    "id" : 191576423390130177,
    "created_at" : "2012-04-15 17:19:13 +0000",
    "user" : {
      "name" : "Custom Colour Golf",
      "screen_name" : "c_c_golf",
      "protected" : false,
      "id_str" : "388863563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2732936088\/7694dc302d80e8f5429d42e5d9594d92_normal.jpeg",
      "id" : 388863563,
      "verified" : false
    }
  },
  "id" : 191578405895012353,
  "created_at" : "2012-04-15 17:27:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 26, 33 ],
      "id_str" : "285766850",
      "id" : 285766850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191553924942135296",
  "text" : "Am looking forward to the @NodeUp cast tonight.. Am a big fan of express so interested to hear what they've to say about it.",
  "id" : 191553924942135296,
  "created_at" : "2012-04-15 15:49:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 32, 46 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191519780820357120",
  "geo" : { },
  "id_str" : "191525432628215808",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @michaelnsimpson @peter_omalley Enjoy tomorrow :) Illegal move though...",
  "id" : 191525432628215808,
  "in_reply_to_status_id" : 191519780820357120,
  "created_at" : "2012-04-15 13:56:36 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191484770847432704",
  "text" : "A new low.... 3 episodes of Ally McBeal watched this morning. Even I would kick myself in the nuts for that....",
  "id" : 191484770847432704,
  "created_at" : "2012-04-15 11:15:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191434691990130689",
  "geo" : { },
  "id_str" : "191482128008089600",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson dunno yet. Sounds awesome though... :D",
  "id" : 191482128008089600,
  "in_reply_to_status_id" : 191434691990130689,
  "created_at" : "2012-04-15 11:04:31 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191479798072221696",
  "geo" : { },
  "id_str" : "191480129518706688",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda what kinda kinky shit you up to son? Oil, brake fluid? :)",
  "id" : 191480129518706688,
  "in_reply_to_status_id" : 191479798072221696,
  "created_at" : "2012-04-15 10:56:35 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191473836531785728",
  "geo" : { },
  "id_str" : "191479572276051971",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda out of interest.... wtf were they?",
  "id" : 191479572276051971,
  "in_reply_to_status_id" : 191473836531785728,
  "created_at" : "2012-04-15 10:54:22 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ewing",
      "screen_name" : "brianjewing",
      "indices" : [ 3, 15 ],
      "id_str" : "328097214",
      "id" : 328097214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191318629520908288",
  "text" : "RT @brianjewing: What if a 'universe' is just a subatomic particle of a greater entity? Attempting to fathom that scale makes my brain s ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "191305190769565696",
    "text" : "What if a 'universe' is just a subatomic particle of a greater entity? Attempting to fathom that scale makes my brain sore. Night.",
    "id" : 191305190769565696,
    "created_at" : "2012-04-14 23:21:26 +0000",
    "user" : {
      "name" : "Brian Ewing",
      "screen_name" : "brianjewing",
      "protected" : false,
      "id_str" : "328097214",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000153299590\/2d428311455441fad63cd54fb53fd207_normal.png",
      "id" : 328097214,
      "verified" : false
    }
  },
  "id" : 191318629520908288,
  "created_at" : "2012-04-15 00:14:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "welldone",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/9PZeKZvq",
      "expanded_url" : "http:\/\/www.blacknorth.tv\/",
      "display_url" : "blacknorth.tv"
    }, {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/s0dZB51Y",
      "expanded_url" : "http:\/\/trailers.apple.com\/trailers\/sony_pictures\/looper\/",
      "display_url" : "trailers.apple.com\/trailers\/sony_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191290323497000961",
  "text" : "Local company http:\/\/t.co\/9PZeKZvq worked on the Looper trailer - amazing work.. http:\/\/t.co\/s0dZB51Y - Very happy for Kris & co.. #welldone",
  "id" : 191290323497000961,
  "created_at" : "2012-04-14 22:22:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191283421526495233",
  "geo" : { },
  "id_str" : "191285761495138305",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I think they are next to useless to be honest. But that's just my opinion :) I've data-ported a few of their apps.. Not good.",
  "id" : 191285761495138305,
  "in_reply_to_status_id" : 191283421526495233,
  "created_at" : "2012-04-14 22:04:14 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191256948224688128",
  "geo" : { },
  "id_str" : "191282922366570496",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq pfffft well if it's northgate it says it all really... Useless bunch that lot.",
  "id" : 191282922366570496,
  "in_reply_to_status_id" : 191256948224688128,
  "created_at" : "2012-04-14 21:52:57 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191255363465646080",
  "geo" : { },
  "id_str" : "191255569015906304",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq you gotta link to this - would love to read that.. How can something that is *FREE* and *WORKS* be more expensive :D",
  "id" : 191255569015906304,
  "in_reply_to_status_id" : 191255363465646080,
  "created_at" : "2012-04-14 20:04:15 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191254548956975104",
  "geo" : { },
  "id_str" : "191254886615220225",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq Ahhhh!!! Drives me nuts... Hopefully the Uni's advocate open source solutions - doubt it though :)",
  "id" : 191254886615220225,
  "in_reply_to_status_id" : 191254548956975104,
  "created_at" : "2012-04-14 20:01:32 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191254312247242753",
  "geo" : { },
  "id_str" : "191254586995118080",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I just discovered the sign in thing a few weeks back and haven't looked back :) Its brilliant :)",
  "id" : 191254586995118080,
  "in_reply_to_status_id" : 191254312247242753,
  "created_at" : "2012-04-14 20:00:21 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191253742761422848",
  "geo" : { },
  "id_str" : "191253896428138497",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq see - the licence fees alone for your school must be high.. Stupid politics. No need for it. Grrrrr",
  "id" : 191253896428138497,
  "in_reply_to_status_id" : 191253742761422848,
  "created_at" : "2012-04-14 19:57:36 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191253452595265538",
  "geo" : { },
  "id_str" : "191253775321804801",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq on my windows machine I just have newzbin and chrome running now. Chrome apps is quite good tbf. Am just mac whore now :(",
  "id" : 191253775321804801,
  "in_reply_to_status_id" : 191253452595265538,
  "created_at" : "2012-04-14 19:57:08 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191253100856754177",
  "geo" : { },
  "id_str" : "191253249158950914",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq any windows machine just gives me the shits now. There is no need for things to be so complicated on it.",
  "id" : 191253249158950914,
  "in_reply_to_status_id" : 191253100856754177,
  "created_at" : "2012-04-14 19:55:02 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191252903007232001",
  "geo" : { },
  "id_str" : "191253074776563712",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq was always a Gnome fan. Oh right so gnome3 didn't cut the mustard then? Feck - must set up a VM and get to it I guess :(",
  "id" : 191253074776563712,
  "in_reply_to_status_id" : 191252903007232001,
  "created_at" : "2012-04-14 19:54:20 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191248137241894913",
  "geo" : { },
  "id_str" : "191250087765225472",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq Been five years since I used a Loonix desktop now so out of that loop. Dunno if I could go back but \"have to\" is a good master :)",
  "id" : 191250087765225472,
  "in_reply_to_status_id" : 191248137241894913,
  "created_at" : "2012-04-14 19:42:28 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191244627729321984",
  "text" : "Horses are such magnificent creatures... Such a waste.. Poor things :(",
  "id" : 191244627729321984,
  "created_at" : "2012-04-14 19:20:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191243595561451520",
  "geo" : { },
  "id_str" : "191244311009046528",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq tried Ubuntu a while back... Hate the new GUI. So let's hope I don't leave for a long while.",
  "id" : 191244311009046528,
  "in_reply_to_status_id" : 191243595561451520,
  "created_at" : "2012-04-14 19:19:31 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191243595561451520",
  "geo" : { },
  "id_str" : "191244139000635392",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq if I ever leave Tascomi I'll have to get one though. Couldn't justify a mac for personal use - but they are lovely.",
  "id" : 191244139000635392,
  "in_reply_to_status_id" : 191243595561451520,
  "created_at" : "2012-04-14 19:18:50 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191243595561451520",
  "geo" : { },
  "id_str" : "191243856854003712",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I had to go there with the sis a few years ago. I had to bite my tounge a few times listening to them. But it's their job I guess.",
  "id" : 191243856854003712,
  "in_reply_to_status_id" : 191243595561451520,
  "created_at" : "2012-04-14 19:17:43 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191197732516540417",
  "geo" : { },
  "id_str" : "191202978462572547",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq Your Mum bought you a lappytop? :D Sweeeet - shoving Ubuntu on it?",
  "id" : 191202978462572547,
  "in_reply_to_status_id" : 191197732516540417,
  "created_at" : "2012-04-14 16:35:17 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 17, 31 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191107510680297473",
  "geo" : { },
  "id_str" : "191129940241039360",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @BerryBlonde84 I was in Lurgan there for a short time.. So doing lots of cooking and freezing in prep for next week :D",
  "id" : 191129940241039360,
  "in_reply_to_status_id" : 191107510680297473,
  "created_at" : "2012-04-14 11:45:03 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rory Mcilroy",
      "screen_name" : "McIlroyRory",
      "indices" : [ 3, 15 ],
      "id_str" : "188039706",
      "id" : 188039706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191129724888678400",
  "text" : "RT @McIlroyRory: If anyone is having a bad day, remember that today in 1976 Ronald Wayne sold his 10% stake in Apple for $800. Now it's  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "191125234345189376",
    "text" : "If anyone is having a bad day, remember that today in 1976 Ronald Wayne sold his 10% stake in Apple for $800. Now it's worth $58,065,210,000",
    "id" : 191125234345189376,
    "created_at" : "2012-04-14 11:26:21 +0000",
    "user" : {
      "name" : "Rory Mcilroy",
      "screen_name" : "McIlroyRory",
      "protected" : false,
      "id_str" : "188039706",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000341922263\/1fb57a677d31a5f1529fa1f51f434d6d_normal.jpeg",
      "id" : 188039706,
      "verified" : true
    }
  },
  "id" : 191129724888678400,
  "created_at" : "2012-04-14 11:44:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191122493535301632",
  "text" : "Driving my Dad to the breakers yard where he's just sold his lorry. Sad.. That's him now 100% retired. No turning back now.",
  "id" : 191122493535301632,
  "created_at" : "2012-04-14 11:15:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191102119326138368",
  "geo" : { },
  "id_str" : "191106966700032001",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson which one of you  made this, and how do I go about marrying them???",
  "id" : 191106966700032001,
  "in_reply_to_status_id" : 191102119326138368,
  "created_at" : "2012-04-14 10:13:46 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190894834284892163",
  "geo" : { },
  "id_str" : "190898215997022208",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall pffffft. Just kick and you wont sink... I know how well you can kick.. Bully! :(",
  "id" : 190898215997022208,
  "in_reply_to_status_id" : 190894834284892163,
  "created_at" : "2012-04-13 20:24:16 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Neil",
      "screen_name" : "afneil",
      "indices" : [ 3, 10 ],
      "id_str" : "136004952",
      "id" : 136004952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190889392129323008",
  "text" : "RT @afneil: Quite depressed by prevalence on twitter of punk egalitarianism coupled with idea that free speech fine provided you say wha ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "190882892719730690",
    "text" : "Quite depressed by prevalence on twitter of punk egalitarianism coupled with idea that free speech fine provided you say what I agree with.",
    "id" : 190882892719730690,
    "created_at" : "2012-04-13 19:23:22 +0000",
    "user" : {
      "name" : "Andrew Neil",
      "screen_name" : "afneil",
      "protected" : false,
      "id_str" : "136004952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1774112287\/image_normal.jpg",
      "id" : 136004952,
      "verified" : true
    }
  },
  "id" : 190889392129323008,
  "created_at" : "2012-04-13 19:49:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190863441538457601",
  "geo" : { },
  "id_str" : "190870322705215488",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall Like the new profile pic.... Please tell me you fell in though straight after this?? Please :D",
  "id" : 190870322705215488,
  "in_reply_to_status_id" : 190863441538457601,
  "created_at" : "2012-04-13 18:33:25 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190856320008724480",
  "geo" : { },
  "id_str" : "190856612708229120",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson woooooooo hooooooooo!!!!! Running hug in the am???",
  "id" : 190856612708229120,
  "in_reply_to_status_id" : 190856320008724480,
  "created_at" : "2012-04-13 17:38:57 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblem",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190855331738419200",
  "text" : "Well that's the end of my lovely 10 days off... Back to porridge on Monday... This Sunday evening is gonna be a bitch... #firstworldproblem",
  "id" : 190855331738419200,
  "created_at" : "2012-04-13 17:33:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190854486066081792",
  "text" : "Just watched Super 8. Very good film. J J Abrahams doing a good film.... WTF is happening?",
  "id" : 190854486066081792,
  "created_at" : "2012-04-13 17:30:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 17, 25 ],
      "id_str" : "79820731",
      "id" : 79820731
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 26, 38 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 39, 52 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 53, 67 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190831816633106432",
  "geo" : { },
  "id_str" : "190849831273644033",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @tascomi @niall_adams @rickyhassard @peter_omalley sounds good :) You heard him fellas P.A.R.T.Y",
  "id" : 190849831273644033,
  "in_reply_to_status_id" : 190831816633106432,
  "created_at" : "2012-04-13 17:12:00 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 20, 34 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190697036851576833",
  "text" : "I owe an apology to @peter_omalley - I am thick :D",
  "id" : 190697036851576833,
  "created_at" : "2012-04-13 07:04:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baconfridays",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190558917783330816",
  "geo" : { },
  "id_str" : "190559152832122880",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson you are such a fucking failure as a man.... You disgust me! You are barred from #baconfridays if you fail the quiz on Mon!",
  "id" : 190559152832122880,
  "in_reply_to_status_id" : 190558917783330816,
  "created_at" : "2012-04-12 21:56:57 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190558575293243392",
  "text" : "Fucking cunts cut off the last note of the training montage......... No need ITV4!!!!! That's just wrong :(",
  "id" : 190558575293243392,
  "created_at" : "2012-04-12 21:54:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 67, 83 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190557948525817856",
  "text" : "And there is the training montage.... You better still be watching @michaelnsimpson",
  "id" : 190557948525817856,
  "created_at" : "2012-04-12 21:52:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rocky",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190554581065932800",
  "text" : "Women weaken your legs... So says Mickey.. Must be true. Fucking genius saying... #rocky",
  "id" : 190554581065932800,
  "created_at" : "2012-04-12 21:38:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/190531190036504576\/photo\/1",
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/osiHCdwk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqTnG50CIAAYN4n.jpg",
      "id_str" : "190531190040698880",
      "id" : 190531190040698880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqTnG50CIAAYN4n.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/osiHCdwk"
    } ],
    "hashtags" : [ {
      "text" : "thingsthatareawesome",
      "indices" : [ 18, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190531190036504576",
  "text" : "Rocky Rocky Rocky #thingsthatareawesome http:\/\/t.co\/osiHCdwk",
  "id" : 190531190036504576,
  "created_at" : "2012-04-12 20:05:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190530231646425088",
  "geo" : { },
  "id_str" : "190530796988280832",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @michaelnsimpson but this has to be done if any of us is WFH on a Friday :) I won't at home though or I'd be tempted :)",
  "id" : 190530796988280832,
  "in_reply_to_status_id" : 190530231646425088,
  "created_at" : "2012-04-12 20:04:16 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/190530198205251585\/photo\/1",
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/l18nbxKI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqTmNK9CQAI7YGP.jpg",
      "id_str" : "190530198209445890",
      "id" : 190530198209445890,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqTmNK9CQAI7YGP.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/l18nbxKI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190522117257826304",
  "geo" : { },
  "id_str" : "190530198205251585",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley proof :) http:\/\/t.co\/l18nbxKI",
  "id" : 190530198205251585,
  "in_reply_to_status_id" : 190522117257826304,
  "created_at" : "2012-04-12 20:01:54 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190522117257826304",
  "geo" : { },
  "id_str" : "190529918231265280",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley you fail Peter :) Learn how twitter scales you inbred - tweet counts are not exact. :) Well they are but not that current.",
  "id" : 190529918231265280,
  "in_reply_to_status_id" : 190522117257826304,
  "created_at" : "2012-04-12 20:00:47 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190529289140178944",
  "geo" : { },
  "id_str" : "190529514030370816",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @rickyhassard am gutted I am missing bacon Fridays...",
  "id" : 190529514030370816,
  "in_reply_to_status_id" : 190529289140178944,
  "created_at" : "2012-04-12 19:59:10 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manchallange",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190528858485829633",
  "geo" : { },
  "id_str" : "190529346514075649",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @michaelnsimpson pop quiz on Monday on the two films. 10 questions... Through out the day.. #manchallange",
  "id" : 190529346514075649,
  "in_reply_to_status_id" : 190528858485829633,
  "created_at" : "2012-04-12 19:58:30 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190512156737933315",
  "geo" : { },
  "id_str" : "190513933738713089",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley send me a pic of baconfridays - shirts are optional ;)",
  "id" : 190513933738713089,
  "in_reply_to_status_id" : 190512156737933315,
  "created_at" : "2012-04-12 18:57:16 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 105, 119 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "antihipstermovement",
      "indices" : [ 120, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190478548702732289",
  "text" : "Only thing that matters in business is buying for one and selling for two. So Proposition Joe said.. \/cc @No_Underscore #antihipstermovement",
  "id" : 190478548702732289,
  "created_at" : "2012-04-12 16:36:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190475638463930370",
  "text" : "Fuck... I have eight tweets to before the 6000th one... I must talk some shit here.. Must think of something profound to say....",
  "id" : 190475638463930370,
  "created_at" : "2012-04-12 16:25:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 32, 44 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 45, 58 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190448319317807104",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley @niall_adams @RickyHassard Fuck the lot of you. I am going to Crumlin dump now... Bacon Fridays without me!",
  "id" : 190448319317807104,
  "created_at" : "2012-04-12 14:36:32 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 32, 44 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 45, 58 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190447912143167490",
  "geo" : { },
  "id_str" : "190448197179674624",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley @niall_adams @RickyHassard Nooooooo - its not bacon fridays without me!!!!!!!!!",
  "id" : 190448197179674624,
  "in_reply_to_status_id" : 190447912143167490,
  "created_at" : "2012-04-12 14:36:03 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190436483746902016",
  "geo" : { },
  "id_str" : "190436709152989184",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore Sammuel L Jackson :)",
  "id" : 190436709152989184,
  "in_reply_to_status_id" : 190436483746902016,
  "created_at" : "2012-04-12 13:50:24 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190398848525545472",
  "geo" : { },
  "id_str" : "190400406529114113",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @michaelnsimpson Well Sammie L broke every bone in his body in that film... So just goes to show ya :D",
  "id" : 190400406529114113,
  "in_reply_to_status_id" : 190398848525545472,
  "created_at" : "2012-04-12 11:26:09 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bringsitallback",
      "indices" : [ 87, 103 ]
    }, {
      "text" : "breakingniallisawesome",
      "indices" : [ 104, 127 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190386508010762240",
  "geo" : { },
  "id_str" : "190389305024327680",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @michaelnsimpson \"Here Niall. \"Work Reports\" \"Ards\" \"Dataport Wednesday\". #bringsitallback #breakingniallisawesome",
  "id" : 190389305024327680,
  "in_reply_to_status_id" : 190386508010762240,
  "created_at" : "2012-04-12 10:42:02 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "breakingniallisawesome",
      "indices" : [ 74, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190381763393110016",
  "geo" : { },
  "id_str" : "190381993639419905",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams and i'll be the twat to break it no doubt.. #breakingniallisawesome",
  "id" : 190381993639419905,
  "in_reply_to_status_id" : 190381763393110016,
  "created_at" : "2012-04-12 10:12:59 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190379994374090753",
  "geo" : { },
  "id_str" : "190381321762258944",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams Am back on Monday though ;)",
  "id" : 190381321762258944,
  "in_reply_to_status_id" : 190379994374090753,
  "created_at" : "2012-04-12 10:10:18 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 81, 94 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190367893815439362",
  "text" : "This man just saw a squirrel fight and didn't film it... Epic Fail... EPIC.. \/cc @stevebiscuit - now go stand in the corner :(",
  "id" : 190367893815439362,
  "created_at" : "2012-04-12 09:16:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190366973627080704",
  "geo" : { },
  "id_str" : "190367247833894913",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Whoooo-hoooooooo! :D Congrats.",
  "id" : 190367247833894913,
  "in_reply_to_status_id" : 190366973627080704,
  "created_at" : "2012-04-12 09:14:23 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190366833042395136",
  "geo" : { },
  "id_str" : "190367178887933952",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll then its stil nice :D Call yourself a red head... I hate gingers ya see... and you are not that.",
  "id" : 190367178887933952,
  "in_reply_to_status_id" : 190366833042395136,
  "created_at" : "2012-04-12 09:14:06 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190366008106688512",
  "geo" : { },
  "id_str" : "190366341243486208",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll KK. I actually checked this time. So I can now say - pic or stfu :D",
  "id" : 190366341243486208,
  "in_reply_to_status_id" : 190366008106688512,
  "created_at" : "2012-04-12 09:10:47 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontletmedownstephen",
      "indices" : [ 99, 120 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190362660179689472",
  "geo" : { },
  "id_str" : "190366042973941760",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit did you video it??? Please tell me you took a video. Wasted opportunity otherwise... #dontletmedownstephen",
  "id" : 190366042973941760,
  "in_reply_to_status_id" : 190362660179689472,
  "created_at" : "2012-04-12 09:09:36 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190201363974729728",
  "geo" : { },
  "id_str" : "190201866481696771",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Sorry must have missed the pic. That's really nice :)",
  "id" : 190201866481696771,
  "in_reply_to_status_id" : 190201363974729728,
  "created_at" : "2012-04-11 22:17:13 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190191584212561921",
  "geo" : { },
  "id_str" : "190201180532637698",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll pic or stfu :)",
  "id" : 190201180532637698,
  "in_reply_to_status_id" : 190191584212561921,
  "created_at" : "2012-04-11 22:14:29 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190163188111769600",
  "text" : "am doing... am doing... Too much coffee today :D",
  "id" : 190163188111769600,
  "created_at" : "2012-04-11 19:43:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 43, 51 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190163099356119041",
  "text" : "Before I bomb out and doing what the great @PeeweeM said to do and giving g+ a new go. Might be worth it... Dunno...",
  "id" : 190163099356119041,
  "created_at" : "2012-04-11 19:43:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190147617253113856",
  "geo" : { },
  "id_str" : "190153375344640000",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore cheers C:) Not bad for 26 ;)",
  "id" : 190153375344640000,
  "in_reply_to_status_id" : 190147617253113856,
  "created_at" : "2012-04-11 19:04:32 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 3, 10 ],
      "id_str" : "285766850",
      "id" : 285766850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190153199712342016",
  "text" : "RT @NodeUp: NodeUp will be live this Sunday with a special framework authors throwdown: Express vs Flatiron vs Geddy vs Tako vs SocketSt ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "190144272815755264",
    "text" : "NodeUp will be live this Sunday with a special framework authors throwdown: Express vs Flatiron vs Geddy vs Tako vs SocketStream.",
    "id" : 190144272815755264,
    "created_at" : "2012-04-11 18:28:22 +0000",
    "user" : {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "protected" : false,
      "id_str" : "285766850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1675860861\/logo2_normal.jpg",
      "id" : 285766850,
      "verified" : false
    }
  },
  "id" : 190153199712342016,
  "created_at" : "2012-04-11 19:03:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190123877509251073",
  "geo" : { },
  "id_str" : "190146699342249985",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 cheers Marcus :)",
  "id" : 190146699342249985,
  "in_reply_to_status_id" : 190123877509251073,
  "created_at" : "2012-04-11 18:38:00 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190143324445884417",
  "geo" : { },
  "id_str" : "190146622267727872",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett cheers Moffett :)",
  "id" : 190146622267727872,
  "in_reply_to_status_id" : 190143324445884417,
  "created_at" : "2012-04-11 18:37:42 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby News",
      "screen_name" : "ruby_news",
      "indices" : [ 3, 13 ],
      "id_str" : "16903992",
      "id" : 16903992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/5WmZfrSc",
      "expanded_url" : "http:\/\/bit.ly\/ItxO0j",
      "display_url" : "bit.ly\/ItxO0j"
    } ]
  },
  "geo" : { },
  "id_str" : "190116754373099520",
  "text" : "RT @ruby_news: Ubuntu is finally getting a new version of Ruby http:\/\/t.co\/5WmZfrSc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/5WmZfrSc",
        "expanded_url" : "http:\/\/bit.ly\/ItxO0j",
        "display_url" : "bit.ly\/ItxO0j"
      } ]
    },
    "geo" : { },
    "id_str" : "190116175290703875",
    "text" : "Ubuntu is finally getting a new version of Ruby http:\/\/t.co\/5WmZfrSc",
    "id" : 190116175290703875,
    "created_at" : "2012-04-11 16:36:43 +0000",
    "user" : {
      "name" : "Ruby News",
      "screen_name" : "ruby_news",
      "protected" : false,
      "id_str" : "16903992",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1224369862\/Ruby-News-Logo_normal.png",
      "id" : 16903992,
      "verified" : false
    }
  },
  "id" : 190116754373099520,
  "created_at" : "2012-04-11 16:39:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190114988365586432",
  "geo" : { },
  "id_str" : "190116648521449472",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM I have to say I would be lost without it now. Its just a tool though - but a pretty good one :)",
  "id" : 190116648521449472,
  "in_reply_to_status_id" : 190114988365586432,
  "created_at" : "2012-04-11 16:38:35 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190113881090297858",
  "geo" : { },
  "id_str" : "190114365641457664",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM twitter is excellent for information isn't it? :)",
  "id" : 190114365641457664,
  "in_reply_to_status_id" : 190113881090297858,
  "created_at" : "2012-04-11 16:29:31 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190031872519184384",
  "geo" : { },
  "id_str" : "190032658112327681",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR aye, I think it's funny :) Might have misjudged that though :)",
  "id" : 190032658112327681,
  "in_reply_to_status_id" : 190031872519184384,
  "created_at" : "2012-04-11 11:04:50 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/190031077807636481\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/3gofOJcU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqMgQilCQAE8Z4K.jpg",
      "id_str" : "190031077811830785",
      "id" : 190031077811830785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqMgQilCQAE8Z4K.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/3gofOJcU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190031077807636481",
  "text" : "From my parents... My Mum still signs it like I was 7 for a laugh. This year my Dad got to sign it too :) http:\/\/t.co\/3gofOJcU",
  "id" : 190031077807636481,
  "created_at" : "2012-04-11 10:58:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189986081427558400",
  "geo" : { },
  "id_str" : "189992648323510272",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq cheers :)",
  "id" : 189992648323510272,
  "in_reply_to_status_id" : 189986081427558400,
  "created_at" : "2012-04-11 08:25:51 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189974107503333376",
  "geo" : { },
  "id_str" : "189975731483324416",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb I don't know what you are on about :)",
  "id" : 189975731483324416,
  "in_reply_to_status_id" : 189974107503333376,
  "created_at" : "2012-04-11 07:18:38 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 13, 26 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189754747555823617",
  "text" : "Off to annoy @Paul_Moffett - he better be wearing something slutty!!!!",
  "id" : 189754747555823617,
  "created_at" : "2012-04-10 16:40:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189728968470040576",
  "geo" : { },
  "id_str" : "189745479423229954",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I'm planning to do that on Thursday. Nothing like a big fyck off clear out!",
  "id" : 189745479423229954,
  "in_reply_to_status_id" : 189728968470040576,
  "created_at" : "2012-04-10 16:03:42 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 4, 11 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sortitoutffs",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189745059854434304",
  "text" : "Oi! @BekaBR am actually outside my house here with tesco shopping waiting for this fuckin hale stones to go over!!!! #sortitoutffs",
  "id" : 189745059854434304,
  "created_at" : "2012-04-10 16:02:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189718007340208128",
  "geo" : { },
  "id_str" : "189719421097480192",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb darn tootin :)",
  "id" : 189719421097480192,
  "in_reply_to_status_id" : 189718007340208128,
  "created_at" : "2012-04-10 14:20:09 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189718284155887616",
  "geo" : { },
  "id_str" : "189719373576028160",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq  One of my minor gripes with learning stuff. I hate the 'Hello World' examples - but I guess they serve a purpose. Keep it up!",
  "id" : 189719373576028160,
  "in_reply_to_status_id" : 189718284155887616,
  "created_at" : "2012-04-10 14:19:58 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189718628625686529",
  "geo" : { },
  "id_str" : "189719163143585792",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore Bryson Street.. Just keep the engine running - guff the stuff out. One side will blame the other :) Just run like fuck!",
  "id" : 189719163143585792,
  "in_reply_to_status_id" : 189718628625686529,
  "created_at" : "2012-04-10 14:19:07 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189717435488800768",
  "text" : "Ohhhh.... I got away with it :D Ha ha ha... Oul fella even answered the phone...",
  "id" : 189717435488800768,
  "created_at" : "2012-04-10 14:12:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189716988451500032",
  "text" : "Right... Lets see.... Can I talk my Mum into making me a sandwich??? Dad is retired now so he's guarding their house... Lets see!!!",
  "id" : 189716988451500032,
  "created_at" : "2012-04-10 14:10:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189714655936131073",
  "text" : "@MarkAMcGregor Aye - we'll technically she was filming in Crumlin - Ballydonaghy in a farm there..",
  "id" : 189714655936131073,
  "created_at" : "2012-04-10 14:01:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189713197341736961",
  "geo" : { },
  "id_str" : "189713390145511425",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb oh no.. I don't like gingers.. Red head women are usually hot..",
  "id" : 189713390145511425,
  "in_reply_to_status_id" : 189713197341736961,
  "created_at" : "2012-04-10 13:56:11 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189712702640361472",
  "text" : "Gillian Anderson in Glenavy... Filming.. Yup... Ha :D Liam Neeson was here a few years back but he's Irish so doesn't count!",
  "id" : 189712702640361472,
  "created_at" : "2012-04-10 13:53:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189698938910158849",
  "text" : "Am quite liking cloud9's IDE to be honest...",
  "id" : 189698938910158849,
  "created_at" : "2012-04-10 12:58:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189684789316550657",
  "geo" : { },
  "id_str" : "189697476649955328",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq it is fun :)",
  "id" : 189697476649955328,
  "in_reply_to_status_id" : 189684789316550657,
  "created_at" : "2012-04-10 12:52:57 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsthatmakemorninghappy",
      "indices" : [ 71, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189680848461766656",
  "geo" : { },
  "id_str" : "189681080096399360",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley i am not in tomorrow or thursday or friday and you are. #thingsthatmakemorninghappy ;)",
  "id" : 189681080096399360,
  "in_reply_to_status_id" : 189680848461766656,
  "created_at" : "2012-04-10 11:47:48 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 10, 17 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189679143284248577",
  "geo" : { },
  "id_str" : "189679438164787200",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @bekabr You are in work so I still win :D :D :D",
  "id" : 189679438164787200,
  "in_reply_to_status_id" : 189679143284248577,
  "created_at" : "2012-04-10 11:41:16 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 16, 23 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sortitoutffs",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189678922017947649",
  "text" : "Oi!!! Beautiful @BekaBR - fucking hailstones in April?????? I was out in the garden when that happened!!! #sortitoutffs",
  "id" : 189678922017947649,
  "created_at" : "2012-04-10 11:39:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxine Cassidy",
      "screen_name" : "maxinecassidy",
      "indices" : [ 0, 14 ],
      "id_str" : "24679127",
      "id" : 24679127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189646636077686784",
  "geo" : { },
  "id_str" : "189646959831826433",
  "in_reply_to_user_id" : 24679127,
  "text" : "@maxinecassidy going on holiday on your own you mean? Hell to the no!!! I went to NY on my own and loved it. You do exactly what u want!",
  "id" : 189646959831826433,
  "in_reply_to_status_id" : 189646636077686784,
  "created_at" : "2012-04-10 09:32:13 +0000",
  "in_reply_to_screen_name" : "maxinecassidy",
  "in_reply_to_user_id_str" : "24679127",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189645945242271744",
  "geo" : { },
  "id_str" : "189646551600201730",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda interesting :D I must poke you for info at some point then.. Of course this is rage mood dependant :)",
  "id" : 189646551600201730,
  "in_reply_to_status_id" : 189645945242271744,
  "created_at" : "2012-04-10 09:30:36 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189645676265746432",
  "geo" : { },
  "id_str" : "189645856855703552",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda so I can annoy you about node then on that super sekret channel we have? What do you use it for?",
  "id" : 189645856855703552,
  "in_reply_to_status_id" : 189645676265746432,
  "created_at" : "2012-04-10 09:27:50 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189645505461104642",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda well I take it that it was express that died - could have been oauth or connect. Something died anyway :)",
  "id" : 189645505461104642,
  "created_at" : "2012-04-10 09:26:26 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189644769486585857",
  "geo" : { },
  "id_str" : "189645267828604928",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda it was a pretty old version of node that I accidently rolled back to and certain areas of express died on it.",
  "id" : 189645267828604928,
  "in_reply_to_status_id" : 189644769486585857,
  "created_at" : "2012-04-10 09:25:29 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189642919962087424",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit its as if I've woken up from a near 5 year old coma and went \"Feed me with hipster programming shiz\" :D",
  "id" : 189642919962087424,
  "created_at" : "2012-04-10 09:16:10 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189642019075919872",
  "geo" : { },
  "id_str" : "189642678219194369",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda and node just seems to have grabbed me a bit more. Still not sure of its actual application yet but time will tell..",
  "id" : 189642678219194369,
  "in_reply_to_status_id" : 189642019075919872,
  "created_at" : "2012-04-10 09:15:12 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189642019075919872",
  "geo" : { },
  "id_str" : "189642433015988224",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda node? I just like it - its new. Ruby is nice enough but save from the hipster element its the same shit different language.",
  "id" : 189642433015988224,
  "in_reply_to_status_id" : 189642019075919872,
  "created_at" : "2012-04-10 09:14:14 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189641866151596032",
  "geo" : { },
  "id_str" : "189642237406224384",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit I could but I find this way a bit more interesting. You learn more by doing things this way in the long run I think.",
  "id" : 189642237406224384,
  "in_reply_to_status_id" : 189641866151596032,
  "created_at" : "2012-04-10 09:13:27 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189641535271337984",
  "text" : "My fuck up has been fixed...\n\nstevies-mac-2: ~ $ node -v\nv0.7.8-pre\n\nYup its unstable but that's how best to learn I think. #nodejs",
  "id" : 189641535271337984,
  "created_at" : "2012-04-10 09:10:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189411029569114113",
  "text" : "Fuck it - just got texted \"Drumsticks - on now\". Don't have to tell me twice. Geek shit can wait :D It really can....",
  "id" : 189411029569114113,
  "created_at" : "2012-04-09 17:54:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189410297692434433",
  "text" : "I've got about 30mins before I have to head out to fix this... That was fucking dumb :D",
  "id" : 189410297692434433,
  "created_at" : "2012-04-09 17:51:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189410143925059584",
  "text" : "Ohhh I just majorly fucked up. - \n\n18:49:29 stevies-mac: ~\/bin $ node -v\nv0.5.11-pre\n\nThink its fair for me say \"Shit\". :D",
  "id" : 189410143925059584,
  "created_at" : "2012-04-09 17:51:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189406977724653570",
  "geo" : { },
  "id_str" : "189407334219522048",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid possibly. But its a business and a business only exists to make \u00A3. This move made them \u00A3. So fair play is say.",
  "id" : 189407334219522048,
  "in_reply_to_status_id" : 189406977724653570,
  "created_at" : "2012-04-09 17:40:02 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189406171151605760",
  "text" : "All the usual bile on twitter re: Instagram being bought by FB. Fair play to them I say. Hate jealousy..",
  "id" : 189406171151605760,
  "created_at" : "2012-04-09 17:35:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsthatareawesome",
      "indices" : [ 42, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189399452023398400",
  "text" : "A wee two hour power nap on a  afternoon. #thingsthatareawesome",
  "id" : 189399452023398400,
  "created_at" : "2012-04-09 17:08:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189330102465724417",
  "text" : "I hate it when tv shows adaptions from books deviate from the storyline for no good reason. Grrrrrrrrrrrrrr",
  "id" : 189330102465724417,
  "created_at" : "2012-04-09 12:33:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly Sweeney",
      "screen_name" : "HFCSween",
      "indices" : [ 0, 9 ],
      "id_str" : "48001141",
      "id" : 48001141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189323561176006656",
  "geo" : { },
  "id_str" : "189329819660599296",
  "in_reply_to_user_id" : 48001141,
  "text" : "@HFCSween when is it on?",
  "id" : 189329819660599296,
  "in_reply_to_status_id" : 189323561176006656,
  "created_at" : "2012-04-09 12:32:01 +0000",
  "in_reply_to_screen_name" : "HFCSween",
  "in_reply_to_user_id_str" : "48001141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189276325029228545",
  "geo" : { },
  "id_str" : "189276598850162688",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I could get well used to this I am tellin ya. So relaxed right now its not even funny :D Think I might soil myself tbf :)",
  "id" : 189276598850162688,
  "in_reply_to_status_id" : 189276325029228545,
  "created_at" : "2012-04-09 09:00:32 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189274885586026496",
  "text" : "Ahhh a \"DVD\" episode of Mad Men and Game of Thornes to start a Monday morning. Carlsberg don't do Mondays but if they did.....",
  "id" : 189274885586026496,
  "created_at" : "2012-04-09 08:53:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189115779638239232",
  "geo" : { },
  "id_str" : "189121579706368000",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight Just looked it up there - seems alright am on the fence. Deffo gonna see Promethus if you are up for that... Looks amazing!",
  "id" : 189121579706368000,
  "in_reply_to_status_id" : 189115779638239232,
  "created_at" : "2012-04-08 22:44:32 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatgamewayplayingboss",
      "indices" : [ 23, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189111439234052097",
  "geo" : { },
  "id_str" : "189111750879232000",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight Tank? #whatgamewayplayingboss?",
  "id" : 189111750879232000,
  "in_reply_to_status_id" : 189111439234052097,
  "created_at" : "2012-04-08 22:05:29 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189104657602330624",
  "text" : "Not really feeling the masters this year...",
  "id" : 189104657602330624,
  "created_at" : "2012-04-08 21:37:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsthatareawesome",
      "indices" : [ 86, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188986241797206016",
  "text" : "Nothing makes me smile quite like when you see a dog use a zebra crossing on its own. #thingsthatareawesome",
  "id" : 188986241797206016,
  "created_at" : "2012-04-08 13:46:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188934935120330753",
  "text" : "BT Fuck with my downloadings on a Sunday... 120Kb\/s... Pfffffffttttt... Now to head into Belfast again.. Might move there ffs.. Hate it :(",
  "id" : 188934935120330753,
  "created_at" : "2012-04-08 10:22:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188931710942068736",
  "text" : "I just found \"Community\"....",
  "id" : 188931710942068736,
  "created_at" : "2012-04-08 10:10:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188927625413132288",
  "geo" : { },
  "id_str" : "188931546105913344",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning @peter_omalley get a room :D",
  "id" : 188931546105913344,
  "in_reply_to_status_id" : 188927625413132288,
  "created_at" : "2012-04-08 10:09:25 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188910139036807168",
  "text" : "Liam Neeson is a star! He answered \"Are you a better baddie or goodie?\" - He just stared and said \"I am motivated by the writing only!\". :D",
  "id" : 188910139036807168,
  "created_at" : "2012-04-08 08:44:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188720629296537600",
  "geo" : { },
  "id_str" : "188722762263699458",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq what be your user account?",
  "id" : 188722762263699458,
  "in_reply_to_status_id" : 188720629296537600,
  "created_at" : "2012-04-07 20:19:47 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188719865417306112",
  "geo" : { },
  "id_str" : "188720143566782464",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq sounds good :) As long as you find it interesting you will learn. That's what I always think.",
  "id" : 188720143566782464,
  "in_reply_to_status_id" : 188719865417306112,
  "created_at" : "2012-04-07 20:09:23 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188719007027838979",
  "geo" : { },
  "id_str" : "188719335404089345",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq personal projects are the best ways to learn I think. You're doing the right thing. You want to change jobs?",
  "id" : 188719335404089345,
  "in_reply_to_status_id" : 188719007027838979,
  "created_at" : "2012-04-07 20:06:10 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188719147151147010",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I'll start to contribute again like I did back in the good oul days :) 2000 wasn't that long ago ;)",
  "id" : 188719147151147010,
  "created_at" : "2012-04-07 20:05:25 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188718707453865986",
  "geo" : { },
  "id_str" : "188718985183891456",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq But I've had enough of standing on the sidelines lately... So I've started to learn new shit again and maybe just maybe...",
  "id" : 188718985183891456,
  "in_reply_to_status_id" : 188718707453865986,
  "created_at" : "2012-04-07 20:04:46 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188718602638200832",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq and in 10 years there will be a generation or two of 'devs' that are next to useless - as they've done fuck all but 'support' :(",
  "id" : 188718602638200832,
  "created_at" : "2012-04-07 20:03:15 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188718366696030208",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq look at the work INI is doing. Instead of investing in local talent they bring in mutli national companies here...",
  "id" : 188718366696030208,
  "created_at" : "2012-04-07 20:02:19 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188717966710415360",
  "geo" : { },
  "id_str" : "188718246453719040",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I know :( Pathetic.. Unfort like all political crap - they go for the short gains instead of long term...",
  "id" : 188718246453719040,
  "in_reply_to_status_id" : 188717966710415360,
  "created_at" : "2012-04-07 20:01:50 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188718058163011587",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq in saying that I was stuck in my old ways and have been learning constantly for the last 3\/4 months. Its been interesting :)",
  "id" : 188718058163011587,
  "created_at" : "2012-04-07 20:01:05 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188717445983371265",
  "geo" : { },
  "id_str" : "188717878126714880",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I always said that 'sendit' moved to the cloud in 2006. If a company hasn't organically moved to it by now they are crap :(",
  "id" : 188717878126714880,
  "in_reply_to_status_id" : 188717445983371265,
  "created_at" : "2012-04-07 20:00:23 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188717557375709184",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq three years there has been in influx of 'hipsters' in IT. Kids that can't actually build stuff from the ground up.",
  "id" : 188717557375709184,
  "created_at" : "2012-04-07 19:59:06 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188717048048795650",
  "geo" : { },
  "id_str" : "188717364026687490",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq i can see where my anal views has stopped me these last five\/six years. However there is no doubt in my mind that in the last..",
  "id" : 188717364026687490,
  "in_reply_to_status_id" : 188717048048795650,
  "created_at" : "2012-04-07 19:58:20 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188716433524523009",
  "geo" : { },
  "id_str" : "188716977462841344",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley I'll check back in an few hours... I can sense when nipples can be shown for banter - tis a gift :D",
  "id" : 188716977462841344,
  "in_reply_to_status_id" : 188716433524523009,
  "created_at" : "2012-04-07 19:56:48 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188716136131600384",
  "geo" : { },
  "id_str" : "188716771186982912",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq the IT world is as fashion conscience as well the fashion world... 8 years ago it was 'thin client', 3 years ago was 'the cloud'.",
  "id" : 188716771186982912,
  "in_reply_to_status_id" : 188716136131600384,
  "created_at" : "2012-04-07 19:55:59 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188716136131600384",
  "geo" : { },
  "id_str" : "188716397172502529",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq youtube has some excellent tutorials. However hearing the word 'app' every 10seconds destroys me....",
  "id" : 188716397172502529,
  "in_reply_to_status_id" : 188716136131600384,
  "created_at" : "2012-04-07 19:54:29 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188715275611406336",
  "geo" : { },
  "id_str" : "188716032821690368",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley Am watching the masters & have had 2 awesome days off. If u are drunk take a pic and show us some nipple ;)",
  "id" : 188716032821690368,
  "in_reply_to_status_id" : 188715275611406336,
  "created_at" : "2012-04-07 19:53:03 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188714747020054528",
  "geo" : { },
  "id_str" : "188715503164997632",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq I find the interface\/front-end the most boring part of the process. Am getting better like. If I can be of any help etc...",
  "id" : 188715503164997632,
  "in_reply_to_status_id" : 188714747020054528,
  "created_at" : "2012-04-07 19:50:56 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "indices" : [ 42, 53 ],
      "id_str" : "66949689",
      "id" : 66949689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188714149893771264",
  "text" : "Am really impressed at the excellent work @blacknorth is doing this weather. I don't give out these compliments easy either.",
  "id" : 188714149893771264,
  "created_at" : "2012-04-07 19:45:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188713551832154112",
  "geo" : { },
  "id_str" : "188713864563662851",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq those qualities should make a good coder. Means you have little time for the mundane crap. That's my feeling on it anyway.",
  "id" : 188713864563662851,
  "in_reply_to_status_id" : 188713551832154112,
  "created_at" : "2012-04-07 19:44:26 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188713385309904898",
  "geo" : { },
  "id_str" : "188713705490497536",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq No not really. Like any MVC it gets 80% of the way there. It is quite handy. I just need to write something in it now.",
  "id" : 188713705490497536,
  "in_reply_to_status_id" : 188713385309904898,
  "created_at" : "2012-04-07 19:43:48 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188712137315725312",
  "geo" : { },
  "id_str" : "188712574844551169",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq and don't call it an 'app'. Feckin hipster talk. It is a 'service' - all these things are services :)",
  "id" : 188712574844551169,
  "in_reply_to_status_id" : 188712137315725312,
  "created_at" : "2012-04-07 19:39:18 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188712137315725312",
  "geo" : { },
  "id_str" : "188712390622326784",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq ah right :) I am reading Node and RoR stuff. Much learning these last few weeks :) What you think of RoR?",
  "id" : 188712390622326784,
  "in_reply_to_status_id" : 188712137315725312,
  "created_at" : "2012-04-07 19:38:34 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188710458612645891",
  "text" : "Sitting down to watch the masters.... Perfect :)",
  "id" : 188710458612645891,
  "created_at" : "2012-04-07 19:30:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188703567392157696",
  "geo" : { },
  "id_str" : "188707834685431808",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson yo mike!!!!!!! What you up to?",
  "id" : 188707834685431808,
  "in_reply_to_status_id" : 188703567392157696,
  "created_at" : "2012-04-07 19:20:28 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188703059575177216",
  "geo" : { },
  "id_str" : "188703203687276544",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin yes it is.",
  "id" : 188703203687276544,
  "in_reply_to_status_id" : 188703059575177216,
  "created_at" : "2012-04-07 19:02:04 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Braziel",
      "screen_name" : "Braziel",
      "indices" : [ 0, 8 ],
      "id_str" : "776654",
      "id" : 776654
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 75, 91 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manchallenge",
      "indices" : [ 92, 105 ]
    }, {
      "text" : "cremeeggs",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188642085577048066",
  "geo" : { },
  "id_str" : "188682234755166208",
  "in_reply_to_user_id" : 776654,
  "text" : "@Braziel this man ate six in under 10mins as a man challenge recently. \/cc @michaelnsimpson #manchallenge #cremeeggs",
  "id" : 188682234755166208,
  "in_reply_to_status_id" : 188642085577048066,
  "created_at" : "2012-04-07 17:38:44 +0000",
  "in_reply_to_screen_name" : "Braziel",
  "in_reply_to_user_id_str" : "776654",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188672115086602241",
  "text" : "Ahhh back home from Belfast.... Spending too much time in that place this weather.. Need to go stand in a field for a bit to climatise again",
  "id" : 188672115086602241,
  "created_at" : "2012-04-07 16:58:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/188345243198959618\/photo\/1",
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/hPgLCXNX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ap0jADRCMAEBB4P.jpg",
      "id_str" : "188345243203153921",
      "id" : 188345243203153921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ap0jADRCMAEBB4P.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/hPgLCXNX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188345243198959618",
  "text" : "Gotta love work colleagues http:\/\/t.co\/hPgLCXNX",
  "id" : 188345243198959618,
  "created_at" : "2012-04-06 19:19:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.ustream.tv\" rel=\"nofollow\"\u003EUstream.TV\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/dpZMVeSg",
      "expanded_url" : "http:\/\/ustre.am\/BFFe\/2",
      "display_url" : "ustre.am\/BFFe\/2"
    } ]
  },
  "geo" : { },
  "id_str" : "188339170295549952",
  "text" : "I just checked into NodeUp on Ustream. Come watch and chat with me here http:\/\/t.co\/dpZMVeSg",
  "id" : 188339170295549952,
  "created_at" : "2012-04-06 18:55:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188334061083832321",
  "geo" : { },
  "id_str" : "188334617441484800",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley Aye but still. I got to abuse you for a bit :)",
  "id" : 188334617441484800,
  "in_reply_to_status_id" : 188334061083832321,
  "created_at" : "2012-04-06 18:37:26 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188329673778933760",
  "geo" : { },
  "id_str" : "188329849625133056",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley I'm watching it on BBC2 dicklick!!!!",
  "id" : 188329849625133056,
  "in_reply_to_status_id" : 188329673778933760,
  "created_at" : "2012-04-06 18:18:29 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188323923912441856",
  "geo" : { },
  "id_str" : "188326918817460224",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley watch the masters ffs... Enough of this football lark... Peasent.",
  "id" : 188326918817460224,
  "in_reply_to_status_id" : 188323923912441856,
  "created_at" : "2012-04-06 18:06:51 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fanboytweet",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188305103126667266",
  "geo" : { },
  "id_str" : "188306733851095040",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne pfffft. Ke$ha would be lucky to be be 30% as awesome as you! #fanboytweet",
  "id" : 188306733851095040,
  "in_reply_to_status_id" : 188305103126667266,
  "created_at" : "2012-04-06 16:46:38 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188292717489557505",
  "geo" : { },
  "id_str" : "188294927808073731",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues Anne Hathaway though...... And Meryl Streep :)",
  "id" : 188294927808073731,
  "in_reply_to_status_id" : 188292717489557505,
  "created_at" : "2012-04-06 15:59:43 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "suckmemore",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188290789368020992",
  "geo" : { },
  "id_str" : "188294063596908544",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR I am off today already a Nd off all next week. #suckmemore",
  "id" : 188294063596908544,
  "in_reply_to_status_id" : 188290789368020992,
  "created_at" : "2012-04-06 15:56:17 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188279449974882304",
  "geo" : { },
  "id_str" : "188279558557016064",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery never said I wasn't a twat.",
  "id" : 188279558557016064,
  "in_reply_to_status_id" : 188279449974882304,
  "created_at" : "2012-04-06 14:58:39 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188279081937272833",
  "text" : "I spent most of today in Belfast.. First time in a long time I've been there during a work day.. Still the same - full of fucking twats!",
  "id" : 188279081937272833,
  "created_at" : "2012-04-06 14:56:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 8, 21 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188278915951886340",
  "text" : "Bet you @RickyHassard is loving having the upstairs office to himself today.",
  "id" : 188278915951886340,
  "created_at" : "2012-04-06 14:56:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188247704961417216",
  "geo" : { },
  "id_str" : "188278137828814848",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr best. tweet. this. year. so. far.",
  "id" : 188278137828814848,
  "in_reply_to_status_id" : 188247704961417216,
  "created_at" : "2012-04-06 14:53:00 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 3, 16 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 28, 34 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/PIV33loa",
      "expanded_url" : "http:\/\/instagr.am\/p\/JE_4-IjAW-\/",
      "display_url" : "instagr.am\/p\/JE_4-IjAW-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "188250437558870016",
  "text" : "RT @RickyHassard: Beaten by @swmcc http:\/\/t.co\/PIV33loa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 10, 16 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 37 ],
        "url" : "http:\/\/t.co\/PIV33loa",
        "expanded_url" : "http:\/\/instagr.am\/p\/JE_4-IjAW-\/",
        "display_url" : "instagr.am\/p\/JE_4-IjAW-\/"
      } ]
    },
    "geo" : { },
    "id_str" : "188247148587003904",
    "text" : "Beaten by @swmcc http:\/\/t.co\/PIV33loa",
    "id" : 188247148587003904,
    "created_at" : "2012-04-06 12:49:52 +0000",
    "user" : {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "protected" : false,
      "id_str" : "5684272",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1317084795\/Screen_shot_2011-04-19_at_13.00.12_normal.png",
      "id" : 5684272,
      "verified" : false
    }
  },
  "id" : 188250437558870016,
  "created_at" : "2012-04-06 13:02:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/UsiEu27u",
      "expanded_url" : "http:\/\/m.deadline.com\/2012\/04\/jimmy-smits-sons-of-anarchy-neron-nero-padilla-fx-drama\/",
      "display_url" : "m.deadline.com\/2012\/04\/jimmy-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "188019098435854336",
  "text" : "http:\/\/t.co\/UsiEu27u Nope it's true :( He's good though. Liked him in Dexter and TWW. Still though, get your own show!!!",
  "id" : 188019098435854336,
  "created_at" : "2012-04-05 21:43:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188018374788390912",
  "text" : "Ok. It better be a joke that Jimmy Smitts is gonna be on Sons of Anarchy. Does he have to guest star in every hit show for a season? WTF",
  "id" : 188018374788390912,
  "created_at" : "2012-04-05 21:40:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188003116027871232",
  "geo" : { },
  "id_str" : "188017871660654593",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM going to Starbucks and bringing out my mac to do stuff is pretty much against all I stand for :)",
  "id" : 188017871660654593,
  "in_reply_to_status_id" : 188003116027871232,
  "created_at" : "2012-04-05 21:38:48 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/0PLB5xKg",
      "expanded_url" : "http:\/\/instagram-engineering.tumblr.com\/post\/20541814340\/keeping-instagram-up-with-over-a-million-new-users-in",
      "display_url" : "instagram-engineering.tumblr.com\/post\/205418143\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "188017652160143362",
  "text" : "http:\/\/t.co\/0PLB5xKg Very interesting scaling shiz from Instagram using node.js",
  "id" : 188017652160143362,
  "created_at" : "2012-04-05 21:37:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/187998776303169537\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/4FSZo1eh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Apvn5BgCMAIWtQz.jpg",
      "id_str" : "187998776307363842",
      "id" : 187998776307363842,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Apvn5BgCMAIWtQz.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4FSZo1eh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187998776303169537",
  "text" : "No one wanted to play tonight. So while in Belfast went to *$. Playing with node.js in here. Fuckin shameful http:\/\/t.co\/4FSZo1eh",
  "id" : 187998776303169537,
  "created_at" : "2012-04-05 20:22:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187967553241489408",
  "geo" : { },
  "id_str" : "187971991930798080",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley oh i would never leave it broken... Just hope it doesn't have to reboot between now and I get back ;)",
  "id" : 187971991930798080,
  "in_reply_to_status_id" : 187967553241489408,
  "created_at" : "2012-04-05 18:36:29 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187964598396272640",
  "geo" : { },
  "id_str" : "187965471952343040",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley think I fucked up mcdonagh... not too sure.. Fuck it - am on holiday :D",
  "id" : 187965471952343040,
  "in_reply_to_status_id" : 187964598396272640,
  "created_at" : "2012-04-05 18:10:35 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187962993882046464",
  "text" : "Server resize fail... Gonna play with some node.js for 30mins to make myself feel smart.. Hipster smart - but smart none the less :(",
  "id" : 187962993882046464,
  "created_at" : "2012-04-05 18:00:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 3, 16 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 41, 47 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187930803114745857",
  "text" : "RT @RickyHassard: i take it back because @swmcc has just beaten me in trac wars :(",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 23, 29 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187930703009284097",
    "text" : "i take it back because @swmcc has just beaten me in trac wars :(",
    "id" : 187930703009284097,
    "created_at" : "2012-04-05 15:52:25 +0000",
    "user" : {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "protected" : false,
      "id_str" : "5684272",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1317084795\/Screen_shot_2011-04-19_at_13.00.12_normal.png",
      "id" : 5684272,
      "verified" : false
    }
  },
  "id" : 187930803114745857,
  "created_at" : "2012-04-05 15:52:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Dale",
      "screen_name" : "dalerocks",
      "indices" : [ 0, 10 ],
      "id_str" : "39041248",
      "id" : 39041248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187893048984866816",
  "geo" : { },
  "id_str" : "187896018615025664",
  "in_reply_to_user_id" : 39041248,
  "text" : "@dalerocks There you go - done :) Am now away to sand blast myself...",
  "id" : 187896018615025664,
  "in_reply_to_status_id" : 187893048984866816,
  "created_at" : "2012-04-05 13:34:36 +0000",
  "in_reply_to_screen_name" : "dalerocks",
  "in_reply_to_user_id_str" : "39041248",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Dale",
      "screen_name" : "dalerocks",
      "indices" : [ 3, 13 ],
      "id_str" : "39041248",
      "id" : 39041248
    }, {
      "name" : "Unbounce",
      "screen_name" : "unbounce",
      "indices" : [ 57, 66 ],
      "id_str" : "65304372",
      "id" : 65304372
    }, {
      "name" : "Holibob",
      "screen_name" : "Holibobapp",
      "indices" : [ 85, 96 ],
      "id_str" : "524523254",
      "id" : 524523254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/84oy7Ear",
      "expanded_url" : "http:\/\/ow.ly\/a65YL",
      "display_url" : "ow.ly\/a65YL"
    } ]
  },
  "geo" : { },
  "id_str" : "187895918530531330",
  "text" : "RT @dalerocks: my new blog post - the A\/B\/Cs of creating @unbounce landing pages for @Holibobapp http:\/\/t.co\/84oy7Ear",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Unbounce",
        "screen_name" : "unbounce",
        "indices" : [ 42, 51 ],
        "id_str" : "65304372",
        "id" : 65304372
      }, {
        "name" : "Holibob",
        "screen_name" : "Holibobapp",
        "indices" : [ 70, 81 ],
        "id_str" : "524523254",
        "id" : 524523254
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/84oy7Ear",
        "expanded_url" : "http:\/\/ow.ly\/a65YL",
        "display_url" : "ow.ly\/a65YL"
      } ]
    },
    "geo" : { },
    "id_str" : "187891396890472449",
    "text" : "my new blog post - the A\/B\/Cs of creating @unbounce landing pages for @Holibobapp http:\/\/t.co\/84oy7Ear",
    "id" : 187891396890472449,
    "created_at" : "2012-04-05 13:16:14 +0000",
    "user" : {
      "name" : "Rich Dale",
      "screen_name" : "dalerocks",
      "protected" : false,
      "id_str" : "39041248",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/206622330\/rich-web_normal.jpg",
      "id" : 39041248,
      "verified" : false
    }
  },
  "id" : 187895918530531330,
  "created_at" : "2012-04-05 13:34:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Dale",
      "screen_name" : "dalerocks",
      "indices" : [ 0, 10 ],
      "id_str" : "39041248",
      "id" : 39041248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187891396890472449",
  "geo" : { },
  "id_str" : "187891684108017664",
  "in_reply_to_user_id" : 39041248,
  "text" : "@dalerocks really enjoying these articles Rich. And you know me.. I don't say things like that easily :) Kinda disgusts me to say in fact :)",
  "id" : 187891684108017664,
  "in_reply_to_status_id" : 187891396890472449,
  "created_at" : "2012-04-05 13:17:23 +0000",
  "in_reply_to_screen_name" : "dalerocks",
  "in_reply_to_user_id_str" : "39041248",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187837365597896704",
  "geo" : { },
  "id_str" : "187838661973377025",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson am still unbreakable... just want Niall to choke to death - a universal constant is me wishing him harm and horrid death.",
  "id" : 187838661973377025,
  "in_reply_to_status_id" : 187837365597896704,
  "created_at" : "2012-04-05 09:46:41 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187833143397580800",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams hope you choked to death on it you rat bastard!",
  "id" : 187833143397580800,
  "created_at" : "2012-04-05 09:24:45 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187666529301696514",
  "text" : "By my great grandmother 61years ago :) And she mentions my Dad in a family tree aged 4 :) Hand written :) Made me smile :)",
  "id" : 187666529301696514,
  "created_at" : "2012-04-04 22:22:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187666103571447809",
  "text" : "What a lovely surprise. Got an email from folks from America that traced their ancestry. Just got a scanned in letter written...",
  "id" : 187666103571447809,
  "created_at" : "2012-04-04 22:21:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187610387225657344",
  "geo" : { },
  "id_str" : "187641319936638976",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson No I didn't. That would be illegal, immoral and wrong. In fact, who the fuck are you, who is this?? ;)",
  "id" : 187641319936638976,
  "in_reply_to_status_id" : 187610387225657344,
  "created_at" : "2012-04-04 20:42:31 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 27, 39 ],
      "id_str" : "216299334",
      "id" : 216299334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187554407230083072",
  "geo" : { },
  "id_str" : "187557487149453312",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I've called @piersmorgan a wanker a few times if that counts.. I hope he RT'd me but hasn't so far...",
  "id" : 187557487149453312,
  "in_reply_to_status_id" : 187554407230083072,
  "created_at" : "2012-04-04 15:09:24 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187535729100996609",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning Welcome to the dirty\/flirty thirites. xxxxxxxxxxxx",
  "id" : 187535729100996609,
  "created_at" : "2012-04-04 13:42:56 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187531155912929282",
  "geo" : { },
  "id_str" : "187531467436457984",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 You are just too tight. Plain and simple :)",
  "id" : 187531467436457984,
  "in_reply_to_status_id" : 187531155912929282,
  "created_at" : "2012-04-04 13:26:00 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boojum Belfast",
      "screen_name" : "boojum_belfast",
      "indices" : [ 3, 18 ],
      "id_str" : "281123406",
      "id" : 281123406
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 20, 26 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 27, 34 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187529930282770432",
  "text" : "RT @boojum_belfast: @swmcc @padzor   Now, now boys. Mrs. boojum is ginger so we've got no issues here",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "padzor",
        "screen_name" : "padzor",
        "indices" : [ 7, 14 ],
        "id_str" : "60141834",
        "id" : 60141834
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "187520545716318209",
    "geo" : { },
    "id_str" : "187522476652232704",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @padzor   Now, now boys. Mrs. boojum is ginger so we've got no issues here",
    "id" : 187522476652232704,
    "in_reply_to_status_id" : 187520545716318209,
    "created_at" : "2012-04-04 12:50:17 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Boojum Belfast",
      "screen_name" : "boojum_belfast",
      "protected" : false,
      "id_str" : "281123406",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1377668053\/boojumlogo_normal.jpg",
      "id" : 281123406,
      "verified" : false
    }
  },
  "id" : 187529930282770432,
  "created_at" : "2012-04-04 13:19:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boojum Belfast",
      "screen_name" : "boojum_belfast",
      "indices" : [ 0, 15 ],
      "id_str" : "281123406",
      "id" : 281123406
    }, {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 16, 23 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187524662983540737",
  "geo" : { },
  "id_str" : "187524956517699588",
  "in_reply_to_user_id" : 281123406,
  "text" : "@boojum_belfast @padzor So that'd be a no on the free one then :) Ahhh well - will be getting one come the weekend so all good :)",
  "id" : 187524956517699588,
  "in_reply_to_status_id" : 187524662983540737,
  "created_at" : "2012-04-04 13:00:08 +0000",
  "in_reply_to_screen_name" : "boojum_belfast",
  "in_reply_to_user_id_str" : "281123406",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    }, {
      "name" : "Boojum Belfast",
      "screen_name" : "boojum_belfast",
      "indices" : [ 8, 23 ],
      "id_str" : "281123406",
      "id" : 281123406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187520232431173634",
  "geo" : { },
  "id_str" : "187520545716318209",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor @boojum_belfast and he is ginger boojum..... I have no hair but at least I am not ginger :)",
  "id" : 187520545716318209,
  "in_reply_to_status_id" : 187520232431173634,
  "created_at" : "2012-04-04 12:42:36 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boojum Belfast",
      "screen_name" : "boojum_belfast",
      "indices" : [ 8, 23 ],
      "id_str" : "281123406",
      "id" : 281123406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187517394544099328",
  "text" : "Woooo.. @boojum_belfast is now following me.. Does this mean I get a free burrito? :D :D :D :D",
  "id" : 187517394544099328,
  "created_at" : "2012-04-04 12:30:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187494723076890625",
  "text" : "OH: \"Thanks very much for your company. It is nice to feel like a team again\". \"Maybe we don't like you!\". \"Fuck off!!!\".",
  "id" : 187494723076890625,
  "created_at" : "2012-04-04 11:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 24, 37 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187461442537144322",
  "text" : "Public declaration that @RickyHassard is now banned from the pilgrimage as he gets me shouted at by shop assistants. \"I am on my break!!!\"",
  "id" : 187461442537144322,
  "created_at" : "2012-04-04 08:47:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 17, 26 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187459718929850369",
  "text" : "Thanks very much @ManyHues for the lovely cookies :D :D :D :D",
  "id" : 187459718929850369,
  "created_at" : "2012-04-04 08:40:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187286566408962048",
  "text" : "It's too damn cold!!!! Snow in April!!!! Sort it out @beka_bee FFS!!!!",
  "id" : 187286566408962048,
  "created_at" : "2012-04-03 21:12:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "helen cupples",
      "screen_name" : "helencupples",
      "indices" : [ 15, 28 ],
      "id_str" : "43220559",
      "id" : 43220559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187264541820850177",
  "geo" : { },
  "id_str" : "187285951284908032",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @helencupples happy birthday to your mum\/gran :)",
  "id" : 187285951284908032,
  "in_reply_to_status_id" : 187264541820850177,
  "created_at" : "2012-04-03 21:10:25 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187270790868242432",
  "geo" : { },
  "id_str" : "187272918105997313",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson tomorrow morning :)",
  "id" : 187272918105997313,
  "in_reply_to_status_id" : 187270790868242432,
  "created_at" : "2012-04-03 20:18:37 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187256507325366272",
  "text" : "Nothing like coming home at 8pm and opening the fridge to make some dinner and finding the left over chicken stir fry you made yesterday :)",
  "id" : 187256507325366272,
  "created_at" : "2012-04-03 19:13:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Braff",
      "screen_name" : "zachbraff",
      "indices" : [ 0, 10 ],
      "id_str" : "76997832",
      "id" : 76997832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187180455714496516",
  "geo" : { },
  "id_str" : "187181797656891393",
  "in_reply_to_user_id" : 76997832,
  "text" : "@zachbraff My boss said  \"You're fired.\"",
  "id" : 187181797656891393,
  "in_reply_to_status_id" : 187180455714496516,
  "created_at" : "2012-04-03 14:16:32 +0000",
  "in_reply_to_screen_name" : "zachbraff",
  "in_reply_to_user_id_str" : "76997832",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187156241489989632",
  "geo" : { },
  "id_str" : "187157316829839361",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne what's up G?",
  "id" : 187157316829839361,
  "in_reply_to_status_id" : 187156241489989632,
  "created_at" : "2012-04-03 12:39:16 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 32, 48 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 51, 63 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmcc10daysoffworksoon",
      "indices" : [ 102, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187087492971892736",
  "text" : "Ha! Neither the duo of assholes @michaelnsimpson & @niall_adams OR the cleaners can destroy me today! #swmcc10daysoffworksoon",
  "id" : 187087492971892736,
  "created_at" : "2012-04-03 08:01:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186917926564139009",
  "text" : "Nothing like going home and having the electric, house ins and rates bill through your letter box. Think that deserves a FUCK RIGHT OFF!",
  "id" : 186917926564139009,
  "created_at" : "2012-04-02 20:48:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Andrew ",
      "screen_name" : "AGRMoore",
      "indices" : [ 17, 26 ],
      "id_str" : "20197876",
      "id" : 20197876
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 46, 60 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186793717250793474",
  "geo" : { },
  "id_str" : "186795681602740225",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @agrmoore you in later mike? @jenporterhall just kicked my ass in a game of darts :(",
  "id" : 186795681602740225,
  "in_reply_to_status_id" : 186793717250793474,
  "created_at" : "2012-04-02 12:42:15 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 31, 45 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 92, 104 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186770054258491392",
  "text" : "Am spending too much time with @jenporterhall - i am now as ditzy and blonde as her.... \/cc @niall_adams",
  "id" : 186770054258491392,
  "created_at" : "2012-04-02 11:00:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/186569060224479232\/photo\/1",
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/1baja2VY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApbTkmECMAIyolM.jpg",
      "id_str" : "186569060228673538",
      "id" : 186569060228673538,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApbTkmECMAIyolM.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/1baja2VY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186569060224479232",
  "text" : "What the fuck is that ginger twat doing alongside these two? Random. http:\/\/t.co\/1baja2VY",
  "id" : 186569060224479232,
  "created_at" : "2012-04-01 21:41:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew ",
      "screen_name" : "AGRMoore",
      "indices" : [ 0, 9 ],
      "id_str" : "20197876",
      "id" : 20197876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186555309622439937",
  "geo" : { },
  "id_str" : "186563313310773249",
  "in_reply_to_user_id" : 20197876,
  "text" : "@AGRMoore is this just a remake??? WTAF....",
  "id" : 186563313310773249,
  "in_reply_to_status_id" : 186555309622439937,
  "created_at" : "2012-04-01 21:18:54 +0000",
  "in_reply_to_screen_name" : "AGRMoore",
  "in_reply_to_user_id_str" : "20197876",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186556069261225984",
  "geo" : { },
  "id_str" : "186562565550252033",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll manatees!! ;)",
  "id" : 186562565550252033,
  "in_reply_to_status_id" : 186556069261225984,
  "created_at" : "2012-04-01 21:15:56 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McMaster",
      "screen_name" : "s_mc_master",
      "indices" : [ 0, 12 ],
      "id_str" : "501270359",
      "id" : 501270359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186552586969690113",
  "geo" : { },
  "id_str" : "186562476417105921",
  "in_reply_to_user_id" : 501270359,
  "text" : "@s_mc_master it was very good. Spoilt a bit by being a 12A though. A very good watch.",
  "id" : 186562476417105921,
  "in_reply_to_status_id" : 186552586969690113,
  "created_at" : "2012-04-01 21:15:35 +0000",
  "in_reply_to_screen_name" : "s_mc_master",
  "in_reply_to_user_id_str" : "501270359",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186546217566748673",
  "geo" : { },
  "id_str" : "186547912338186242",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley did he not cry too? That film destroyed me...",
  "id" : 186547912338186242,
  "in_reply_to_status_id" : 186546217566748673,
  "created_at" : "2012-04-01 20:17:42 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186539523839238145",
  "geo" : { },
  "id_str" : "186543624186642432",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll :(",
  "id" : 186543624186642432,
  "in_reply_to_status_id" : 186539523839238145,
  "created_at" : "2012-04-01 20:00:40 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186538247193767936",
  "geo" : { },
  "id_str" : "186538422616326144",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Guess we are just gonna have to man up and get on with it though :(",
  "id" : 186538422616326144,
  "in_reply_to_status_id" : 186538247193767936,
  "created_at" : "2012-04-01 19:40:00 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186538247193767936",
  "geo" : { },
  "id_str" : "186538354433728512",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll I didn't find the book you are on that hard. Then again I was on holiday. This book is really hard to get into too :(",
  "id" : 186538354433728512,
  "in_reply_to_status_id" : 186538247193767936,
  "created_at" : "2012-04-01 19:39:44 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186538067136491520",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll I am on 'A Feast for Crows'... Part 1.",
  "id" : 186538067136491520,
  "created_at" : "2012-04-01 19:38:35 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186537619923025920",
  "geo" : { },
  "id_str" : "186537792862568449",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll it is brilliant.. Watch out for it. SOS p2 - really? :( Hang on to I see if that is the one I am currently on....",
  "id" : 186537792862568449,
  "in_reply_to_status_id" : 186537619923025920,
  "created_at" : "2012-04-01 19:37:30 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186537159220674561",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll on my easter break.. It was a hard read like... Hopefully was just too much too soon. You seen 'Boss' with Kelsey Grammer?",
  "id" : 186537159220674561,
  "created_at" : "2012-04-01 19:34:59 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186535864120250369",
  "geo" : { },
  "id_str" : "186536954035318785",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll I was adding a few new books to the bookshelf and saw SoS Part 1... Only got 3\/4 chapters in last time. Hoping to get to it",
  "id" : 186536954035318785,
  "in_reply_to_status_id" : 186535864120250369,
  "created_at" : "2012-04-01 19:34:10 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186535143836614656",
  "geo" : { },
  "id_str" : "186535626135437312",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll You watching mad men and game of thrones??? :)",
  "id" : 186535626135437312,
  "in_reply_to_status_id" : 186535143836614656,
  "created_at" : "2012-04-01 19:28:53 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 8, 21 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186515691891986432",
  "geo" : { },
  "id_str" : "186517400303321088",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe @stevebiscuit All this new learning stuff. Tis a golden age of.... Trying to think of something profound t.. Sugartits! :D There!",
  "id" : 186517400303321088,
  "in_reply_to_status_id" : 186515691891986432,
  "created_at" : "2012-04-01 18:16:28 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186512987002118144",
  "text" : "which I do in my current job - but it was really refreshing to see something other than the normal applications being talked about is all.",
  "id" : 186512987002118144,
  "created_at" : "2012-04-01 17:58:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186512787651035136",
  "text" : "There's is nothing wrong with the service industry. But after 12 years in it - it would be nice to produce something tangible and exportable",
  "id" : 186512787651035136,
  "created_at" : "2012-04-01 17:58:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 126, 133 ],
      "id_str" : "17843859",
      "id" : 17843859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186512302479114240",
  "text" : "This is the kind of stuff we need to be thinking about - not stupid 'hello world' or 'social web' stuff. Very interesting \/cc @rtweed",
  "id" : 186512302479114240,
  "created_at" : "2012-04-01 17:56:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 38, 45 ],
      "id_str" : "17843859",
      "id" : 17843859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/Mx7BKtLW",
      "expanded_url" : "http:\/\/www.slideshare.net\/robtweed\/nodejs-its-potential-in-healthcare",
      "display_url" : "slideshare.net\/robtweed\/nodej\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186511984165007360",
  "text" : "Just saw a really interesting talk by @rtweed re: node.js in the health industry.. http:\/\/t.co\/Mx7BKtLW - great to see this. Thanks rob :)",
  "id" : 186511984165007360,
  "created_at" : "2012-04-01 17:54:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "indices" : [ 0, 8 ],
      "id_str" : "20479813",
      "id" : 20479813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186478956864737281",
  "geo" : { },
  "id_str" : "186483140947214336",
  "in_reply_to_user_id" : 20479813,
  "text" : "@MMFlint you sir are a fucking knob.",
  "id" : 186483140947214336,
  "in_reply_to_status_id" : 186478956864737281,
  "created_at" : "2012-04-01 16:00:20 +0000",
  "in_reply_to_screen_name" : "MMFlint",
  "in_reply_to_user_id_str" : "20479813",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "couldntmakethisshitup",
      "indices" : [ 116, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186461668958674944",
  "text" : "\"I'd like to live in an area of social deprivation because I think it's important to get a feel of what it's like.\" #couldntmakethisshitup",
  "id" : 186461668958674944,
  "created_at" : "2012-04-01 14:35:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 96, 111 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186243622558105600",
  "text" : "Lucky I wasn't out tonight.... Went to see The Hunger Games as it happens. Can't help but think @Georgina_Milne would be awesome at that..",
  "id" : 186243622558105600,
  "created_at" : "2012-04-01 00:08:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186243327048421377",
  "text" : "Nothing like fixing a server at 1am on a Sunday morning to make you happy. 4 day week though so am just gonna have to suck it up I guess ;)",
  "id" : 186243327048421377,
  "created_at" : "2012-04-01 00:07:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]