Grailbird.data.tweets_2010_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil McClure",
      "screen_name" : "overture8",
      "indices" : [ 0, 10 ],
      "id_str" : "19857364",
      "id" : 19857364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19901467275",
  "geo" : { },
  "id_str" : "19901848841",
  "in_reply_to_user_id" : 19857364,
  "text" : "@overture8 Yeeeoooo. We dont have to pay tax now.. Fuck em :D",
  "id" : 19901848841,
  "in_reply_to_status_id" : 19901467275,
  "created_at" : "2010-07-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "overture8",
  "in_reply_to_user_id_str" : "19857364",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19907759917",
  "text" : "sonos player just came on with Rick Astley.. This might be a Friday.. but I will kill.. don't test me!",
  "id" : 19907759917,
  "created_at" : "2010-07-30 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rocknroll",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19943592762",
  "text" : "Would I lie to you? Great show... Now to bed. #rocknroll",
  "id" : 19943592762,
  "created_at" : "2010-07-30 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19811274649",
  "geo" : { },
  "id_str" : "19811505767",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe is that me? :(",
  "id" : 19811505767,
  "in_reply_to_status_id" : 19811274649,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19812177745",
  "text" : "still hating the way Mail.app deals with attachment saving.",
  "id" : 19812177745,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19816360701",
  "text" : "\"if he dies, he dies\"",
  "id" : 19816360701,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 32, 39 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19819404985",
  "geo" : { },
  "id_str" : "19825417402",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes I hate seagulls. Get @srushe to tell you the seagull story of me in NY Liberty Island... Not good!",
  "id" : 19825417402,
  "in_reply_to_status_id" : 19819404985,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19831194823",
  "text" : "created my own \/etc\/init.d\/ script there. I know its small - but it makes thing look so more professional :)",
  "id" : 19831194823,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19832406866",
  "text" : "http:\/\/failblog.org\/2010\/07\/27\/orchestra-fail\/ made me laugh",
  "id" : 19832406866,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19838402976",
  "geo" : { },
  "id_str" : "19841618132",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop I was using tweetdeck on iPhone and mac. Got fed up with it and just use twitter stuff.",
  "id" : 19841618132,
  "in_reply_to_status_id" : 19838402976,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 30, 36 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19740037194",
  "text" : "In the right corner.. we have @swmcc.. in the left corner we have HTML for Office.. No low blows, no standing eight count.. LETS GET IT ON!",
  "id" : 19740037194,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19740132742",
  "geo" : { },
  "id_str" : "19740511894",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop I hate HTML at the best of times... But lets see. Think a Rocky-esque training montage is needed..",
  "id" : 19740511894,
  "in_reply_to_status_id" : 19740132742,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19740645253",
  "geo" : { },
  "id_str" : "19741168671",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop http:\/\/www.youtube.com\/watch?v=IwvoTDoO9Hg no like that!",
  "id" : 19741168671,
  "in_reply_to_status_id" : 19740645253,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19740645253",
  "geo" : { },
  "id_str" : "19741548239",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop am actually listening to that montage as I do this ya know.. its helping ;)",
  "id" : 19741548239,
  "in_reply_to_status_id" : 19740645253,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19742776065",
  "geo" : { },
  "id_str" : "19744448312",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Congrats :)))))",
  "id" : 19744448312,
  "in_reply_to_status_id" : 19742776065,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19746039975",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop just found out the HTML has to look perfect in word 2002! Think I need to bring out the Top Gun soundtrack for that!",
  "id" : 19746039975,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19757829663",
  "geo" : { },
  "id_str" : "19767124528",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit your geekage is always at 11. Need a whole new disk for you my friend. :)",
  "id" : 19767124528,
  "in_reply_to_status_id" : 19757829663,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19647624821",
  "text" : "How do you tell a communist? It's someone who reads Marx and Lenin. How do you tell an anti-Communist? Someone who understands Marx &Lenin.",
  "id" : 19647624821,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19668138081",
  "text" : "When did sperm start to present newsrooms?? They were adults in my day!!",
  "id" : 19668138081,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19562138904",
  "geo" : { },
  "id_str" : "19565002494",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings fucking bastard! Now the rest of the day is gonna so slow!!! Grrrrrrrrr",
  "id" : 19565002494,
  "in_reply_to_status_id" : 19562138904,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19574087224",
  "text" : "Using the CPAN shell is crap :\/",
  "id" : 19574087224,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19580301046",
  "text" : "postgis stuff hurts my head.. and what comes to the rescue - a Perl script :) Awwww... Perl - there is fuck all it can't do! :)",
  "id" : 19580301046,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19592224041",
  "text" : "Watching Dexter. What a great show!!",
  "id" : 19592224041,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19507103162",
  "geo" : { },
  "id_str" : "19512828567",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings @bk_gordon all games will pale against the old republic...",
  "id" : 19512828567,
  "in_reply_to_status_id" : 19507103162,
  "created_at" : "2010-07-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19518783613",
  "geo" : { },
  "id_str" : "19519384043",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings Me too.. Wont happen though. Release date for spring next year.. Probably be Xmas 11 before it hits here.. Can't wait :)",
  "id" : 19519384043,
  "in_reply_to_status_id" : 19518783613,
  "created_at" : "2010-07-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19414126393",
  "text" : "Michael Sheen is in the new Tron film.. Good sign - he is an impressive actor! Lets hope they don't Matrix it up though!",
  "id" : 19414126393,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19450561160",
  "text" : "A Brian and Stewie episode on at the minute... Class..",
  "id" : 19450561160,
  "created_at" : "2010-07-24 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HULKGORAAAAA",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19245495346",
  "text" : "just done a grep on a js\/ directory to find out where a function lives.. It returned me back four files where it lives. #HULKGORAAAAA",
  "id" : 19245495346,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19246394502",
  "geo" : { },
  "id_str" : "19248736192",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop Nginx any good then? Is it really small fast and light?",
  "id" : 19248736192,
  "in_reply_to_status_id" : 19246394502,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19265125699",
  "text" : "Spent the whole working day re-jigging some awful code about.. Come 17:00 it all fell into place.. Not sure if that was on purpose or not ;)",
  "id" : 19265125699,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul McKeever",
      "screen_name" : "paulmckeever",
      "indices" : [ 0, 13 ],
      "id_str" : "15741536",
      "id" : 15741536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19269006894",
  "geo" : { },
  "id_str" : "19269293319",
  "in_reply_to_user_id" : 15741536,
  "text" : "@paulmckeever now you said it tomorrow is going to go very very very slowly... :)",
  "id" : 19269293319,
  "in_reply_to_status_id" : 19269006894,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "paulmckeever",
  "in_reply_to_user_id_str" : "15741536",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul McKeever",
      "screen_name" : "paulmckeever",
      "indices" : [ 0, 13 ],
      "id_str" : "15741536",
      "id" : 15741536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19323930859",
  "geo" : { },
  "id_str" : "19324890381",
  "in_reply_to_user_id" : 15741536,
  "text" : "@paulmckeever now that you have blatantly said it... Euggghh.. And its sunny outside. Double kick in the stones :)",
  "id" : 19324890381,
  "in_reply_to_status_id" : 19323930859,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "paulmckeever",
  "in_reply_to_user_id_str" : "15741536",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19329425274",
  "text" : "I hate how Mail.app handles downloading files..",
  "id" : 19329425274,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19377349791",
  "text" : "Watching Flight Club... I am Tyler's $something_witty",
  "id" : 19377349791,
  "created_at" : "2010-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 54, 61 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19083225417",
  "text" : "for the first time in 6 years of working with the man @srushe has declined a cup of tea!",
  "id" : 19083225417,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC This Week",
      "screen_name" : "bbcthisweek",
      "indices" : [ 13, 25 ],
      "id_str" : "78602972",
      "id" : 78602972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19083310755",
  "text" : "zoesalmon on @bbcthisweek.. What!! What!!! FFS.. I give up... Get someone good on.. If Calum Best shows up again I am gonna boycott it!",
  "id" : 19083310755,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19083436032",
  "text" : "have just checked out zoe salmons twitter page.. Can Oonna King not come back.. Or get Dianne back - if she has forgiven Andrew that is ;)",
  "id" : 19083436032,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19083539543",
  "text" : "Am sorry - am just really fucked off at them getting in celebs on that have nothing of value to say... Hope she suprised me.. doubt it!",
  "id" : 19083539543,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    }, {
      "name" : "Ciaran Hurley",
      "screen_name" : "PapaHurley",
      "indices" : [ 17, 28 ],
      "id_str" : "19614568",
      "id" : 19614568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18983912522",
  "geo" : { },
  "id_str" : "18984285719",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings @PapaHurley mother visited again?",
  "id" : 18984285719,
  "in_reply_to_status_id" : 18983912522,
  "created_at" : "2010-07-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "everyfuckingtimeihaveanewmachine",
      "indices" : [ 95, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18993325039",
  "text" : "bert:~# perldoc RPC::XML::Server\nYou need to install the perl-doc package to use this program. #everyfuckingtimeihaveanewmachine",
  "id" : 18993325039,
  "created_at" : "2010-07-20 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19000157355",
  "text" : "am now using Itsy for tweets.. Tweetdeck was getting to slow.",
  "id" : 19000157355,
  "created_at" : "2010-07-20 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18897595057",
  "text" : "news.bbc.co.uk now redirects to bbc.co.uk\/news. Will the brand 'experts' please stop fucking with that site.. Its really fucknig me off!",
  "id" : 18897595057,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18908057897",
  "geo" : { },
  "id_str" : "18910184732",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes he's been elected for another term now - so he wont be caring at all :(",
  "id" : 18910184732,
  "in_reply_to_status_id" : 18908057897,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18910418891",
  "geo" : { },
  "id_str" : "18910617557",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes my MP is now the Rev McCrea... how crap is that? Lucky water was poured on my head as a baby in a church he likes.. Wanker! Grrrr",
  "id" : 18910617557,
  "in_reply_to_status_id" : 18910418891,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18910666851",
  "text" : "I now have the anger thanks to @mnehughes reminding what a bigoted useless wanker and hypocrite his MP is!",
  "id" : 18910666851,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18912252498",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes deal :)",
  "id" : 18912252498,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18928397248",
  "text" : "Worked like a fucker today - got lots done.. Hopefully tomorrow will be the same!",
  "id" : 18928397248,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18917146996",
  "geo" : { },
  "id_str" : "18928457994",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop just *2 you lazy git!",
  "id" : 18928457994,
  "in_reply_to_status_id" : 18917146996,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "productofthebbc",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18931252717",
  "text" : "#productofthebbc Get with the times and start to advertise you commie bastards :) Only joking.... or am I??? :)",
  "id" : 18931252717,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18936093075",
  "geo" : { },
  "id_str" : "18940483911",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne kick em all in the nuts. Your place does *heart* the overtime. Not a good work\/life balance :( Kick em in the nuts!",
  "id" : 18940483911,
  "in_reply_to_status_id" : 18936093075,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18946826011",
  "text" : "Ian Paisley Jnr just said 'fabulous' in a tee-vee documentary there... Just sayin is all... ;)",
  "id" : 18946826011,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18945465108",
  "geo" : { },
  "id_str" : "18946858962",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit developer fail.. Its in the rules that you shall not giveth another developer a ticket..",
  "id" : 18946858962,
  "in_reply_to_status_id" : 18945465108,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chancingarm",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18673277609",
  "geo" : { },
  "id_str" : "18673350620",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes Did it work? I am not grumpy but a bit deflated... Your husband might make me a cuppa to cheer me up? #chancingarm",
  "id" : 18673350620,
  "in_reply_to_status_id" : 18673277609,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18673621342",
  "text" : "Bananarama on the sonos player there now... Someone is going to die before 4:30... yup",
  "id" : 18673621342,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 36, 43 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18673644780",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes he did it too :) Yay for @srushe :))",
  "id" : 18673644780,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18673779348",
  "geo" : { },
  "id_str" : "18673853141",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes its funny though. I woke up to that story this mornin... And my first thought was how can they still be fucking up? Impressive",
  "id" : 18673853141,
  "in_reply_to_status_id" : 18673779348,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18675361971",
  "geo" : { },
  "id_str" : "18675472246",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop i did that once. Heart-burn city.. Disgusting things.",
  "id" : 18675472246,
  "in_reply_to_status_id" : 18675361971,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18680005869",
  "text" : "This pleases me. http:\/\/www.bbc.co.uk\/news\/magazine-10633782",
  "id" : 18680005869,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18684349623",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes still eating grumpy bars?",
  "id" : 18684349623,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18686153418",
  "geo" : { },
  "id_str" : "18686641448",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings romantic was it? ;)",
  "id" : 18686641448,
  "in_reply_to_status_id" : 18686153418,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18687105240",
  "geo" : { },
  "id_str" : "18688864199",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe @mnehughes as long as it aint star trek it'll be all good :)",
  "id" : 18688864199,
  "in_reply_to_status_id" : 18687105240,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18689559700",
  "geo" : { },
  "id_str" : "18690050868",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes class :D",
  "id" : 18690050868,
  "in_reply_to_status_id" : 18689559700,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18718098664",
  "geo" : { },
  "id_str" : "18718476484",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes isn't it! Stupid remake",
  "id" : 18718476484,
  "in_reply_to_status_id" : 18718098664,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18588967763",
  "geo" : { },
  "id_str" : "18589025134",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit crack your neck",
  "id" : 18589025134,
  "in_reply_to_status_id" : 18588967763,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18589369417",
  "geo" : { },
  "id_str" : "18589496126",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop its just coffee ffs ricky :) In saying that I am gonna make myself some joe now!",
  "id" : 18589496126,
  "in_reply_to_status_id" : 18589369417,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18589935598",
  "text" : "Fuel!!! :)  http:\/\/yfrog.com\/3uknsej",
  "id" : 18589935598,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/yfrog.com\" rel=\"nofollow\"\u003EYfrog\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 71, 77 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18590030425",
  "text" : "Ha! Look at my laptop bag dumped on the coffee table there! How rude! (@swmcc)http:\/\/yfrog.com\/3uknsej",
  "id" : 18590030425,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18590117339",
  "geo" : { },
  "id_str" : "18590195135",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop Aye fancy coffee machine and an even fancier milk machine. Those machines need about as much RAM as our main DB Server :)",
  "id" : 18590195135,
  "in_reply_to_status_id" : 18590117339,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18590811226",
  "geo" : { },
  "id_str" : "18591083511",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Yup I'm centre right, but a liberal one.. A liberal conservative I like to style myself .A liberal capitalist - I like :)",
  "id" : 18591083511,
  "in_reply_to_status_id" : 18590811226,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18594032592",
  "geo" : { },
  "id_str" : "18594714606",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes you'll get used to it.. Then when they do a major change again you will be saying this again :)",
  "id" : 18594714606,
  "in_reply_to_status_id" : 18594032592,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 16, 31 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18594804268",
  "geo" : { },
  "id_str" : "18595074820",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @Georgina_Milne for PM! :)",
  "id" : 18595074820,
  "in_reply_to_status_id" : 18594804268,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 103, 110 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18595541427",
  "text" : "when Phil Collins \"Different Kinda Love\" is blasting out of the speakers, you know its time for me and @srushe to commender the sonos player",
  "id" : 18595541427,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18595905261",
  "geo" : { },
  "id_str" : "18595941155",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop the red bull girls have moved next door?????? FFS... Why couldn't they be there 17months ago! Grrrrrrrrr :)",
  "id" : 18595941155,
  "in_reply_to_status_id" : 18595905261,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18595926252",
  "geo" : { },
  "id_str" : "18596005861",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop George Michael came on there... Am getting very close to starting my sonos app and destroying all!",
  "id" : 18596005861,
  "in_reply_to_status_id" : 18595926252,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC This Week",
      "screen_name" : "bbcthisweek",
      "indices" : [ 14, 26 ],
      "id_str" : "78602972",
      "id" : 78602972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18634525675",
  "text" : "Abi Titmus on @bbcthisweek? WTF!!!",
  "id" : 18634525675,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18623183828",
  "geo" : { },
  "id_str" : "18634600230",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop iPhone 4?",
  "id" : 18634600230,
  "in_reply_to_status_id" : 18623183828,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18639645115",
  "text" : "Instead of watching the political progs I took my Mum to see Shrek 3D. Some quality mothership time. Class :)",
  "id" : 18639645115,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18553956354",
  "geo" : { },
  "id_str" : "18585544261",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne I think she talks absolute nonsense, but there is something about her. I'm more of a Maggie fan tbh (not like that).",
  "id" : 18585544261,
  "in_reply_to_status_id" : 18553956354,
  "created_at" : "2010-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18519205284",
  "text" : "2.5 hours till I get to head home and get on with domestic shiz.. Growing up is a pain in the dick!",
  "id" : 18519205284,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18553701022",
  "text" : "Sallybeecow is on bbc question time tomorrow. Hopefully her left wing nonsense will put a stop to my crush on her!",
  "id" : 18553701022,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thereslkaratekidandnotthstremakewankonteevee",
      "indices" : [ 42, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18280174506",
  "text" : "Fear does not exist in this dojo does it? #thereslkaratekidandnotthstremakewankonteevee",
  "id" : 18280174506,
  "created_at" : "2010-07-11 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18102923314",
  "text" : "I really want to read Alister Campbells book - I think the man is very intelligent and shiz... but giving that twat money... dunno",
  "id" : 18102923314,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Sally Bercow",
      "screen_name" : "SallyBercow",
      "indices" : [ 0, 12 ],
      "id_str" : "1437815449",
      "id" : 1437815449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18105485570",
  "text" : "@SallyBercow sounds like a story out of Everybody Loves Raymond",
  "id" : 18105485570,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18105501061",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne enjoying your day offski?",
  "id" : 18105501061,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18105839861",
  "geo" : { },
  "id_str" : "18106006656",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne no I am not. But its a nice Friday regardless.. Just hope the phone stops sometime soon :) But come 4:30 3 day weekend!! :D",
  "id" : 18106006656,
  "in_reply_to_status_id" : 18105839861,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18125004513",
  "geo" : { },
  "id_str" : "18125595783",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne are you ready, ready, ready?",
  "id" : 18125595783,
  "in_reply_to_status_id" : 18125004513,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18017250335",
  "geo" : { },
  "id_str" : "18018979051",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne what happened the previous manager?",
  "id" : 18018979051,
  "in_reply_to_status_id" : 18017250335,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18020810303",
  "geo" : { },
  "id_str" : "18020967740",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit is the drama still on going?",
  "id" : 18020967740,
  "in_reply_to_status_id" : 18020810303,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul McKeever",
      "screen_name" : "paulmckeever",
      "indices" : [ 0, 13 ],
      "id_str" : "15741536",
      "id" : 15741536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18021576383",
  "geo" : { },
  "id_str" : "18026963718",
  "in_reply_to_user_id" : 15741536,
  "text" : "@paulmckeever when you present with an iPad helps. Well it helps me anyway :)",
  "id" : 18026963718,
  "in_reply_to_status_id" : 18021576383,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "paulmckeever",
  "in_reply_to_user_id_str" : "15741536",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18041295090",
  "text" : "Three day weekend coming up. This pleases me.",
  "id" : 18041295090,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18043038777",
  "geo" : { },
  "id_str" : "18043719475",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings really - they deleted it automatically? That's fairly stupid of them :)",
  "id" : 18043719475,
  "in_reply_to_status_id" : 18043038777,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18051906965",
  "text" : "This tub of ice cream just cost me \u00A34.29. Think I am gonna sleep with it at that price.  http:\/\/yfrog.com\/bcg15afj",
  "id" : 18051906965,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18067130945",
  "text" : "Can't be arsed with QT tonight.. But this week should be good. Deffo Andrew Neil is the best thing on the BBC - even though he is smarmy!",
  "id" : 18067130945,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18068141263",
  "text" : "Ohhhhh David Milliband is looking very casual on bbcthisweek.. Wonder if he will impress me doubt it. Bring back Dianne.",
  "id" : 18068141263,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wank",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18068731899",
  "text" : "The 'Professor' on bbcthisweek just said we come out of a depression. Don't remember being in one. Night Sue Ellen, Night John Boy #wank",
  "id" : 18068731899,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18068820411",
  "text" : "Feck me... Could Milliband get his trousers further up??  Simon Cowell would be proud..",
  "id" : 18068820411,
  "created_at" : "2010-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17934495372",
  "geo" : { },
  "id_str" : "17935105685",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop a big case of gayness i think",
  "id" : 17935105685,
  "in_reply_to_status_id" : 17934495372,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17933345111",
  "geo" : { },
  "id_str" : "17935116649",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit many like the olden days or just about 20 odd :)",
  "id" : 17935116649,
  "in_reply_to_status_id" : 17933345111,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17935374880",
  "text" : "@rforbes_simpson Mugabe then Kyle - aye - the two are almost the same :)",
  "id" : 17935374880,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17935257457",
  "geo" : { },
  "id_str" : "17935387124",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit contract rates on a 12 hour day.. *kerrrrching*",
  "id" : 17935387124,
  "in_reply_to_status_id" : 17935257457,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17936976945",
  "text" : "waiting for a 1.1Gb sql file to be inserted via psql -Uxxx &lt; file.sql - is there a faster way its taken fookin ages!",
  "id" : 17936976945,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 49, 56 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17939554892",
  "text" : "horrible bug destoryed - thanks to the beautiful @srushe  for his help ;)",
  "id" : 17939554892,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17939860450",
  "text" : "I wish the iPhone would have an office setting - where it'll turn off my push settings for fb, twitter and Mail. Then revert when I leave.",
  "id" : 17939860450,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17943331281",
  "text" : "hooked up to GIS and time bands.. So Monday 8-6 I am in work - but if I am out of 'this' area shove on the push notifications..",
  "id" : 17943331281,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17854090945",
  "geo" : { },
  "id_str" : "17854247580",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit thief.. Madonna wanna thief at that!",
  "id" : 17854247580,
  "in_reply_to_status_id" : 17854090945,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17854490869",
  "geo" : { },
  "id_str" : "17855044888",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit already have one dude :) already have one :) \/me points on pointy bra! :)",
  "id" : 17855044888,
  "in_reply_to_status_id" : 17854490869,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17859766036",
  "geo" : { },
  "id_str" : "17860149236",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe and I do lunghes and jumping jacks while I wait for it to rise ;)",
  "id" : 17860149236,
  "in_reply_to_status_id" : 17859766036,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17861948547",
  "geo" : { },
  "id_str" : "17861983989",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne duuuuuuuuuuuuuuuude! No need. No need!!! Duuuuuuudddeeee",
  "id" : 17861983989,
  "in_reply_to_status_id" : 17861948547,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17862939941",
  "geo" : { },
  "id_str" : "17863131548",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne dude!!! stop it! :)",
  "id" : 17863131548,
  "in_reply_to_status_id" : 17862939941,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17863809681",
  "geo" : { },
  "id_str" : "17864122974",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe :) \/me puts on pointy bra and sings \"Like a virgin....\"",
  "id" : 17864122974,
  "in_reply_to_status_id" : 17863809681,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17878863396",
  "text" : "Super dooper bug came across my desk there. Well not actually super dooper - but deffo a pain in the ass!",
  "id" : 17878863396,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17782325734",
  "geo" : { },
  "id_str" : "17782542288",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit what is over?",
  "id" : 17782542288,
  "in_reply_to_status_id" : 17782325734,
  "created_at" : "2010-07-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17796508869",
  "text" : "Head just melted doing a query on a tally report there.. Need coffee.. CBA going to the kitchen though... Hard times.",
  "id" : 17796508869,
  "created_at" : "2010-07-05 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17801190056",
  "geo" : { },
  "id_str" : "17801587902",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne that sounds like fun",
  "id" : 17801587902,
  "in_reply_to_status_id" : 17801190056,
  "created_at" : "2010-07-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pathetic",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17708312497",
  "text" : "Andrew Marr crapping himself over star salaries bring released. #pathetic",
  "id" : 17708312497,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17715947192",
  "text" : "I just bought a copy of the Sunday Mail.. Man they really don't give us right wingers a good name. Idiots :)",
  "id" : 17715947192,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17716660869",
  "text" : "Hmmmm. Messa hungry... What to eat. Cupboards are bare - Mum isn't at home - Dad guarding food with life.. Trip to tescos then. Fuck!",
  "id" : 17716660869,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17728149894",
  "text" : "I have a crush on Sally Bercow - this is wrong on so many levels.",
  "id" : 17728149894,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17722195769",
  "geo" : { },
  "id_str" : "17728457713",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne lol... We found the mummified remains of our first cat when we were clearing out the hay shed 6 years ago!",
  "id" : 17728457713,
  "in_reply_to_status_id" : 17722195769,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17732484227",
  "geo" : { },
  "id_str" : "17733177963",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne it was my Granny's place. The cat moved there when my parents got me. It was jealous of me. 20 years later we found it...",
  "id" : 17733177963,
  "in_reply_to_status_id" : 17732484227,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17732484227",
  "geo" : { },
  "id_str" : "17733233827",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne we just burnt it with the rest of the other hay!! Was a bit mad though.. Must have went in there to die!",
  "id" : 17733233827,
  "in_reply_to_status_id" : 17732484227,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17740275737",
  "text" : "Clarkson 'v' Campbell.. A fight where I hope both sides lose and lose badly.",
  "id" : 17740275737,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17745023715",
  "text" : "Family guy doing star wars with a rocky training montage. Fucking awesome.",
  "id" : 17745023715,
  "created_at" : "2010-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17635930245",
  "geo" : { },
  "id_str" : "17645287422",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit must have needed it.",
  "id" : 17645287422,
  "in_reply_to_status_id" : 17635930245,
  "created_at" : "2010-07-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17556310967",
  "text" : "have to go to ards now.. what a shite way to start a Friday. Hopefully it will get better... Russell Brand film tonight to c.. so doubt it!",
  "id" : 17556310967,
  "created_at" : "2010-07-02 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17573193839",
  "geo" : { },
  "id_str" : "17577480009",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings it probably hates you more... I know I do ;)",
  "id" : 17577480009,
  "in_reply_to_status_id" : 17573193839,
  "created_at" : "2010-07-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17577643307",
  "geo" : { },
  "id_str" : "17580163710",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings :) Was in Ards today - no love for anyone today! But 10mins till I get offski for the weekend :)  xx",
  "id" : 17580163710,
  "in_reply_to_status_id" : 17577643307,
  "created_at" : "2010-07-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]