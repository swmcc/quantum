Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 81, 93 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174994152956768256",
  "geo" : { },
  "id_str" : "174994555119218688",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 oh he'll just think its me being a dick :) I had this battle with @niall_adams once - he kicked my ass in it :(",
  "id" : 174994555119218688,
  "in_reply_to_status_id" : 174994152956768256,
  "created_at" : "2012-02-29 23:08:47 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "didnotthinkthisthrough",
      "indices" : [ 110, 133 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174993391191465985",
  "geo" : { },
  "id_str" : "174993717046943744",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 Yeah - and he also gets up at 6am to get to work these days - so he'll get his revenge.. Shit. #didnotthinkthisthrough",
  "id" : 174993717046943744,
  "in_reply_to_status_id" : 174993391191465985,
  "created_at" : "2012-02-29 23:05:28 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 30, 44 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/174992894120300545\/photo\/1",
      "indices" : [ 45, 64 ],
      "url" : "http:\/\/t.co\/HmXnzBC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Am2zHCyCEAIjE4W.jpg",
      "id_str" : "174992894124494850",
      "id" : 174992894124494850,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am2zHCyCEAIjE4W.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/HmXnzBC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174992894120300545",
  "text" : "He should be awake now :) \/cc @BerryBlonde84 http:\/\/t.co\/HmXnzBC",
  "id" : 174992894120300545,
  "created_at" : "2012-02-29 23:02:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174991554094694400",
  "geo" : { },
  "id_str" : "174991964234727424",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @stimpled0rf shit... I was trying to remember what I said I was gonna be.... Crap.. Is he sleeping.. Hang on....",
  "id" : 174991964234727424,
  "in_reply_to_status_id" : 174991554094694400,
  "created_at" : "2012-02-29 22:58:30 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cakesforlife",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174796386519351298",
  "geo" : { },
  "id_str" : "174991772303368192",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Me!!! Good looking and can bake like that - can't see a downside :D #cakesforlife",
  "id" : 174991772303368192,
  "in_reply_to_status_id" : 174796386519351298,
  "created_at" : "2012-02-29 22:57:44 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174936837759045632",
  "geo" : { },
  "id_str" : "174990992066355201",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @stimpled0rf remember.... bridesmaid.... :D",
  "id" : 174990992066355201,
  "in_reply_to_status_id" : 174936837759045632,
  "created_at" : "2012-02-29 22:54:38 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174990086692286465",
  "text" : "Boojum was awesome.......",
  "id" : 174990086692286465,
  "created_at" : "2012-02-29 22:51:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 30, 43 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174969258533601280",
  "geo" : { },
  "id_str" : "174989985978650626",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley @RickyHassard is that all you got at M&S??????? :D :D :D",
  "id" : 174989985978650626,
  "in_reply_to_status_id" : 174969258533601280,
  "created_at" : "2012-02-29 22:50:38 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 57, 69 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174932763642830848",
  "geo" : { },
  "id_str" : "174989862699671553",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard not enter... It is ENTER ENTER ENTER. Also @niall_adams screwed with your chair. I know better than to screw with u b4 11am.",
  "id" : 174989862699671553,
  "in_reply_to_status_id" : 174932763642830848,
  "created_at" : "2012-02-29 22:50:09 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 48, 62 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174908498835021824",
  "text" : "\"I don't like frogs...But I like Kermit\"... \/cc @jenporterhall",
  "id" : 174908498835021824,
  "created_at" : "2012-02-29 17:26:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174884398045462529",
  "text" : "It felt like Spring earlier today - but now its gotten all cloudy and grey again... WTF... Sort it out nature!",
  "id" : 174884398045462529,
  "created_at" : "2012-02-29 15:51:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 88, 101 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 102, 116 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174843474292649984",
  "text" : "Just got my sublime installation fixed after a week of it not working.. Thank feck. \/cc @RickyHassard @peter_omalley",
  "id" : 174843474292649984,
  "created_at" : "2012-02-29 13:08:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boojum Belfast",
      "screen_name" : "boojum_belfast",
      "indices" : [ 2, 17 ],
      "id_str" : "281123406",
      "id" : 281123406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174839200607256578",
  "text" : "A @boojum_belfast tonight and a 'build a burger' tomorrow night... Think in anyone's world that is a 'WIN'.",
  "id" : 174839200607256578,
  "created_at" : "2012-02-29 12:51:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 36, 50 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reallymeanthespinningbeachballofdeath",
      "indices" : [ 51, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174814017146191872",
  "text" : "\"I hate the spinning rainbow..\" \/cc @jenporterhall #reallymeanthespinningbeachballofdeath :D",
  "id" : 174814017146191872,
  "created_at" : "2012-02-29 11:11:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174627050714431488",
  "geo" : { },
  "id_str" : "174627794695884802",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues hope you feel better soon... Feel guilty cos I can't make you anything like you did for us (aka me me me)...",
  "id" : 174627794695884802,
  "in_reply_to_status_id" : 174627050714431488,
  "created_at" : "2012-02-28 22:51:25 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 13, 25 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174620810382807042",
  "geo" : { },
  "id_str" : "174627591288913920",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @stimpled0rf hell yeah!!!!",
  "id" : 174627591288913920,
  "in_reply_to_status_id" : 174620810382807042,
  "created_at" : "2012-02-28 22:50:36 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conchur Moore",
      "screen_name" : "conchubar1",
      "indices" : [ 3, 14 ],
      "id_str" : "72619790",
      "id" : 72619790
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "6degrees",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174621674140991488",
  "text" : "RT @conchubar1: So apparently these students in #6degrees can get from bangor to the ravenhill road and bangor to the Holylands in like  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "6degrees",
        "indices" : [ 32, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174621471635804160",
    "text" : "So apparently these students in #6degrees can get from bangor to the ravenhill road and bangor to the Holylands in like 5 mins. Magical...",
    "id" : 174621471635804160,
    "created_at" : "2012-02-28 22:26:17 +0000",
    "user" : {
      "name" : "Conchur Moore",
      "screen_name" : "conchubar1",
      "protected" : false,
      "id_str" : "72619790",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2215198609\/conchur_modelling_normal.jpg",
      "id" : 72619790,
      "verified" : false
    }
  },
  "id" : 174621674140991488,
  "created_at" : "2012-02-28 22:27:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McMaster",
      "screen_name" : "s_mc_master",
      "indices" : [ 0, 12 ],
      "id_str" : "501270359",
      "id" : 501270359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174617216057217024",
  "geo" : { },
  "id_str" : "174619307903430656",
  "in_reply_to_user_id" : 501270359,
  "text" : "@s_mc_master yeah very sad. Really impressed so far. Episode 5 was worthy of a series finale.",
  "id" : 174619307903430656,
  "in_reply_to_status_id" : 174617216057217024,
  "created_at" : "2012-02-28 22:17:41 +0000",
  "in_reply_to_screen_name" : "s_mc_master",
  "in_reply_to_user_id_str" : "501270359",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174616337790926849",
  "geo" : { },
  "id_str" : "174616892642828290",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf roooooaaaaaad triiiiipppppppp :) :)",
  "id" : 174616892642828290,
  "in_reply_to_status_id" : 174616337790926849,
  "created_at" : "2012-02-28 22:08:06 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 13, 23 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174594516467195906",
  "geo" : { },
  "id_str" : "174610843131056129",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @Burkazoid Mike this is why you are a knob :)",
  "id" : 174610843131056129,
  "in_reply_to_status_id" : 174594516467195906,
  "created_at" : "2012-02-28 21:44:03 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174608804674142208",
  "geo" : { },
  "id_str" : "174610565103226880",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues Ohhhh and Spartacus is now epic... Episode 5 was worthy of a finale... Honestly.",
  "id" : 174610565103226880,
  "in_reply_to_status_id" : 174608804674142208,
  "created_at" : "2012-02-28 21:42:57 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174608804674142208",
  "geo" : { },
  "id_str" : "174610452133855233",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues it is a hard watch... I still made it through all the same.. Looking forward to the sequel :)",
  "id" : 174610452133855233,
  "in_reply_to_status_id" : 174608804674142208,
  "created_at" : "2012-02-28 21:42:30 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174606319305760768",
  "text" : "New episode of Spartacus was epic!!!! :D",
  "id" : 174606319305760768,
  "created_at" : "2012-02-28 21:26:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174582113541165056",
  "geo" : { },
  "id_str" : "174586251909926912",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb well played dickhead.... well played :)",
  "id" : 174586251909926912,
  "in_reply_to_status_id" : 174582113541165056,
  "created_at" : "2012-02-28 20:06:20 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174581382075514880",
  "geo" : { },
  "id_str" : "174581791917748224",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb you actually went and looked up my old employment records. You sad sad man :) Well played :D You'll forget between now and then :)",
  "id" : 174581791917748224,
  "in_reply_to_status_id" : 174581382075514880,
  "created_at" : "2012-02-28 19:48:37 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 46, 58 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174526974650359808",
  "text" : "Just noticed that I have a three meeting with @stimpled0rf on Thursday. 2 hour meeting today. Not good shiz - lucky he's sexc ;)",
  "id" : 174526974650359808,
  "created_at" : "2012-02-28 16:10:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174518225894256640",
  "geo" : { },
  "id_str" : "174518612307083264",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll who-hooooo!!!!! :D",
  "id" : 174518612307083264,
  "in_reply_to_status_id" : 174518225894256640,
  "created_at" : "2012-02-28 15:37:34 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174514849735393280",
  "geo" : { },
  "id_str" : "174518107837186048",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll you back?????? :D",
  "id" : 174518107837186048,
  "in_reply_to_status_id" : 174514849735393280,
  "created_at" : "2012-02-28 15:35:33 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 26, 40 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174516228415696896",
  "text" : "Full respect to the great @jenporterhall Hillsborough -&gt; Belfast (Bedford St) -&gt; Lisburn in 30mins....",
  "id" : 174516228415696896,
  "created_at" : "2012-02-28 15:28:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    }, {
      "name" : "joanne pedlow",
      "screen_name" : "joanneped",
      "indices" : [ 8, 18 ],
      "id_str" : "23190715",
      "id" : 23190715
    }, {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 63, 79 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174500315448614912",
  "geo" : { },
  "id_str" : "174500994229600256",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR @joanneped Ahhhh right... You should go on - nevermind @eight_one_eight just leave him with some Hagan Daas and he'll be grand :)",
  "id" : 174500994229600256,
  "in_reply_to_status_id" : 174500315448614912,
  "created_at" : "2012-02-28 14:27:33 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nash",
      "screen_name" : "Nash076",
      "indices" : [ 3, 11 ],
      "id_str" : "122711186",
      "id" : 122711186
    }, {
      "name" : "Ramsey Nasser",
      "screen_name" : "ra",
      "indices" : [ 133, 136 ],
      "id_str" : "376807850",
      "id" : 376807850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174500181843259393",
  "text" : "RT @Nash076: To give you a comparison, the Raspberry Pi would be about $14.25 in 1984.  The original Macintosh was $2,495 at launch. @Ra ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Raspberry Pi",
        "screen_name" : "Raspberry_Pi",
        "indices" : [ 120, 133 ],
        "id_str" : "302666251",
        "id" : 302666251
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174491461499359232",
    "text" : "To give you a comparison, the Raspberry Pi would be about $14.25 in 1984.  The original Macintosh was $2,495 at launch. @Raspberry_Pi",
    "id" : 174491461499359232,
    "created_at" : "2012-02-28 13:49:40 +0000",
    "user" : {
      "name" : "Nash",
      "screen_name" : "Nash076",
      "protected" : false,
      "id_str" : "122711186",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1798302063\/image1328155974_normal.png",
      "id" : 122711186,
      "verified" : false
    }
  },
  "id" : 174500181843259393,
  "created_at" : "2012-02-28 14:24:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 20, 32 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174499430605660160",
  "text" : "2 hour meeting with @stimpled0rf done. Apology buns delivered... This Tuesday hasn't been too bad considering.",
  "id" : 174499430605660160,
  "created_at" : "2012-02-28 14:21:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    }, {
      "name" : "joanne pedlow",
      "screen_name" : "joanneped",
      "indices" : [ 8, 18 ],
      "id_str" : "23190715",
      "id" : 23190715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174494048604786689",
  "geo" : { },
  "id_str" : "174498947153408000",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR @joanneped really? this saturday? Have I got that right...",
  "id" : 174498947153408000,
  "in_reply_to_status_id" : 174494048604786689,
  "created_at" : "2012-02-28 14:19:25 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174457146740715520",
  "geo" : { },
  "id_str" : "174457275195473921",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf I just did when you saw my internet history and said \"DELETE EVERYTHING... EVERYTHING!!!\" :D",
  "id" : 174457275195473921,
  "in_reply_to_status_id" : 174457146740715520,
  "created_at" : "2012-02-28 11:33:50 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsseehowthisgoes",
      "indices" : [ 107, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174455213141401600",
  "text" : "Note to self... Make sure you are both working from the same hymn sheet re: work changes. \/cc @stimpledorf #letsseehowthisgoes",
  "id" : 174455213141401600,
  "created_at" : "2012-02-28 11:25:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174434624347447296",
  "geo" : { },
  "id_str" : "174434900538179584",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb you do that - if you can find it. I haven't worked there in years :D",
  "id" : 174434900538179584,
  "in_reply_to_status_id" : 174434624347447296,
  "created_at" : "2012-02-28 10:04:55 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174433134916546560",
  "geo" : { },
  "id_str" : "174434652742877184",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe it was not meant to piss ya off :)\nI'll give you a hug to make up for it :)",
  "id" : 174434652742877184,
  "in_reply_to_status_id" : 174433134916546560,
  "created_at" : "2012-02-28 10:03:56 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174430392005300224",
  "text" : "I hate today already..... Stupid ass Tuesday....",
  "id" : 174430392005300224,
  "created_at" : "2012-02-28 09:47:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174413628739555329",
  "geo" : { },
  "id_str" : "174421952021266432",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb you will lapse - memory aint that good anymore at your age ;)",
  "id" : 174421952021266432,
  "in_reply_to_status_id" : 174413628739555329,
  "created_at" : "2012-02-28 09:13:28 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174413628739555329",
  "geo" : { },
  "id_str" : "174421898497769472",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb so far out dude :D But is this gonna be a morning everyday thing - so you get it right. Don't think you have the commitment. :)",
  "id" : 174421898497769472,
  "in_reply_to_status_id" : 174413628739555329,
  "created_at" : "2012-02-28 09:13:15 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thewayitshouldbe",
      "indices" : [ 101, 118 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174200455986020352",
  "geo" : { },
  "id_str" : "174200785909977089",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Thank fuck for that - was getting a tumor by being behaved Considered yourself to be ripped! #thewayitshouldbe",
  "id" : 174200785909977089,
  "in_reply_to_status_id" : 174200455986020352,
  "created_at" : "2012-02-27 18:34:38 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174199952040407040",
  "geo" : { },
  "id_str" : "174200181720498177",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR awesome :D So I take it on this one we can rip the pish out each other and I don't have to censor myself? :)",
  "id" : 174200181720498177,
  "in_reply_to_status_id" : 174199952040407040,
  "created_at" : "2012-02-27 18:32:14 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174197530064728065",
  "geo" : { },
  "id_str" : "174199928757817344",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Consider yourself tweeted! :)",
  "id" : 174199928757817344,
  "in_reply_to_status_id" : 174197530064728065,
  "created_at" : "2012-02-27 18:31:14 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174189918485086208",
  "geo" : { },
  "id_str" : "174191491877584896",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb bring it ho bag!",
  "id" : 174191491877584896,
  "in_reply_to_status_id" : 174189918485086208,
  "created_at" : "2012-02-27 17:57:42 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174180279894814720",
  "geo" : { },
  "id_str" : "174182817834598400",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb It is :D",
  "id" : 174182817834598400,
  "in_reply_to_status_id" : 174180279894814720,
  "created_at" : "2012-02-27 17:23:14 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 3, 12 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 14, 20 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174178180607913985",
  "text" : "RT @kirkcoyb: @swmcc 33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33 FIN",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "174175494693060609",
    "geo" : { },
    "id_str" : "174175899284017152",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc 33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33 FIN",
    "id" : 174175899284017152,
    "in_reply_to_status_id" : 174175494693060609,
    "created_at" : "2012-02-27 16:55:45 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "protected" : false,
      "id_str" : "80937118",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000265464803\/bb3bfe9f836643408ac5700a775f8f25_normal.jpeg",
      "id" : 80937118,
      "verified" : false
    }
  },
  "id" : 174178180607913985,
  "created_at" : "2012-02-27 17:04:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174176138439045120",
  "geo" : { },
  "id_str" : "174176824815923200",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb wouldn't expect any less from you sir... But if you get it wrong and miss a day then you can never take the piss again ;)",
  "id" : 174176824815923200,
  "in_reply_to_status_id" : 174176138439045120,
  "created_at" : "2012-02-27 16:59:25 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174175061262082048",
  "geo" : { },
  "id_str" : "174175494693060609",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb only works when I do it :) Not for a while yet - around 6 weeks out I am afraid boyo :D",
  "id" : 174175494693060609,
  "in_reply_to_status_id" : 174175061262082048,
  "created_at" : "2012-02-27 16:54:08 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Simpson",
      "screen_name" : "BBCMarkSimpson",
      "indices" : [ 3, 18 ],
      "id_str" : "296319355",
      "id" : 296319355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173853487992545281",
  "text" : "RT @BBCMarkSimpson: Holywood, Co Down, holds its breath as its most famous son is only 18 holes from being top of the world, at 22 years ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Rory",
        "indices" : [ 122, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173849821755604992",
    "text" : "Holywood, Co Down, holds its breath as its most famous son is only 18 holes from being top of the world, at 22 years old. #Rory",
    "id" : 173849821755604992,
    "created_at" : "2012-02-26 19:20:02 +0000",
    "user" : {
      "name" : "Mark Simpson",
      "screen_name" : "BBCMarkSimpson",
      "protected" : false,
      "id_str" : "296319355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1347301218\/mark_simpson23_normal.jpg",
      "id" : 296319355,
      "verified" : true
    }
  },
  "id" : 173853487992545281,
  "created_at" : "2012-02-26 19:34:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rebecca brownlie",
      "screen_name" : "RB__Photography",
      "indices" : [ 0, 16 ],
      "id_str" : "21508246",
      "id" : 21508246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173841241690226689",
  "geo" : { },
  "id_str" : "173844765979320322",
  "in_reply_to_user_id" : 21508246,
  "text" : "@RB__Photography hmmmmmm..... Let's see.... 50p... Leave that one with me..",
  "id" : 173844765979320322,
  "in_reply_to_status_id" : 173841241690226689,
  "created_at" : "2012-02-26 18:59:56 +0000",
  "in_reply_to_screen_name" : "RB__Photography",
  "in_reply_to_user_id_str" : "21508246",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rebecca brownlie",
      "screen_name" : "RB__Photography",
      "indices" : [ 0, 16 ],
      "id_str" : "21508246",
      "id" : 21508246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173837739450572801",
  "geo" : { },
  "id_str" : "173840616235601920",
  "in_reply_to_user_id" : 21508246,
  "text" : "@RB__Photography no starting until 10 and home for 4:30... Think that's enough.",
  "id" : 173840616235601920,
  "in_reply_to_status_id" : 173837739450572801,
  "created_at" : "2012-02-26 18:43:27 +0000",
  "in_reply_to_screen_name" : "RB__Photography",
  "in_reply_to_user_id_str" : "21508246",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rebecca brownlie",
      "screen_name" : "RB__Photography",
      "indices" : [ 0, 16 ],
      "id_str" : "21508246",
      "id" : 21508246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173815391221596160",
  "geo" : { },
  "id_str" : "173836980646449153",
  "in_reply_to_user_id" : 21508246,
  "text" : "@RB__Photography am willing to hear your proposals.",
  "id" : 173836980646449153,
  "in_reply_to_status_id" : 173815391221596160,
  "created_at" : "2012-02-26 18:29:00 +0000",
  "in_reply_to_screen_name" : "RB__Photography",
  "in_reply_to_user_id_str" : "21508246",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173812908743065600",
  "text" : "Weekends should be three days long... This two day business just isn't cutting it for me anymore.",
  "id" : 173812908743065600,
  "created_at" : "2012-02-26 16:53:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rebecca brownlie",
      "screen_name" : "RB__Photography",
      "indices" : [ 0, 16 ],
      "id_str" : "21508246",
      "id" : 21508246
    }, {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 70, 86 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173718896283619329",
  "geo" : { },
  "id_str" : "173719213570142208",
  "in_reply_to_user_id" : 21508246,
  "text" : "@RB__Photography It just takes time - but you'll soon get used to it. @eight_one_eight show her how its done will ya :D",
  "id" : 173719213570142208,
  "in_reply_to_status_id" : 173718896283619329,
  "created_at" : "2012-02-26 10:41:02 +0000",
  "in_reply_to_screen_name" : "RB__Photography",
  "in_reply_to_user_id_str" : "21508246",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rebecca brownlie",
      "screen_name" : "RB__Photography",
      "indices" : [ 23, 39 ],
      "id_str" : "21508246",
      "id" : 21508246
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 68, 75 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 77, 89 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 94, 109 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173718792319401984",
  "text" : "Everyone should follow @RB__Photography... She's just as awesome as @srushe, @stimpled0rf and @Georgina_Milne. Which is pretty awesome :)",
  "id" : 173718792319401984,
  "created_at" : "2012-02-26 10:39:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rebecca brownlie",
      "screen_name" : "RB__Photography",
      "indices" : [ 0, 16 ],
      "id_str" : "21508246",
      "id" : 21508246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173716541643300864",
  "geo" : { },
  "id_str" : "173718310557450241",
  "in_reply_to_user_id" : 21508246,
  "text" : "@RB__Photography awesome :D",
  "id" : 173718310557450241,
  "in_reply_to_status_id" : 173716541643300864,
  "created_at" : "2012-02-26 10:37:27 +0000",
  "in_reply_to_screen_name" : "RB__Photography",
  "in_reply_to_user_id_str" : "21508246",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173521968283385856",
  "geo" : { },
  "id_str" : "173546429611130881",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery not quite :)",
  "id" : 173546429611130881,
  "in_reply_to_status_id" : 173521968283385856,
  "created_at" : "2012-02-25 23:14:27 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 14, 28 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173490426056159232",
  "geo" : { },
  "id_str" : "173491762831171584",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @peter_omalley Its a good shout. Never had to get in without queuing though which annoys me... Enjoy the pizza Pete!",
  "id" : 173491762831171584,
  "in_reply_to_status_id" : 173490426056159232,
  "created_at" : "2012-02-25 19:37:14 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173489849133826048",
  "text" : "Season 2 of Damages put to bed. Netflix doesn't offer S3 or 4... Guess I am gonna have to buy the boxset... Oh - nowhere is open.....",
  "id" : 173489849133826048,
  "created_at" : "2012-02-25 19:29:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 15, 27 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173488296427667456",
  "geo" : { },
  "id_str" : "173488885664456704",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @Kirstylvssp FFS!!!!!!!",
  "id" : 173488885664456704,
  "in_reply_to_status_id" : 173488296427667456,
  "created_at" : "2012-02-25 19:25:48 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173187479984279552",
  "geo" : { },
  "id_str" : "173192646028820480",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll you back.....? :)",
  "id" : 173192646028820480,
  "in_reply_to_status_id" : 173187479984279552,
  "created_at" : "2012-02-24 23:48:39 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 83, 97 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173184765095190528",
  "text" : "Actually it was really shit... I REALLY believe that. Do you know what I mean? \/cc @jenporterhall",
  "id" : 173184765095190528,
  "created_at" : "2012-02-24 23:17:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173179016352763904",
  "geo" : { },
  "id_str" : "173179533497864192",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb haven't seen that yet. This is so bad I can't stop watching.",
  "id" : 173179533497864192,
  "in_reply_to_status_id" : 173179016352763904,
  "created_at" : "2012-02-24 22:56:32 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173178138484948993",
  "geo" : { },
  "id_str" : "173178307318263808",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb it's fucking awful.... Worst. Film. Ever.",
  "id" : 173178307318263808,
  "in_reply_to_status_id" : 173178138484948993,
  "created_at" : "2012-02-24 22:51:40 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 87, 101 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173177512300527616",
  "text" : "I am watching Colombiana.... It's really shit... Like really shit. To quote the lovely @jenporterhall SERIOUSLY, it's shit!!!",
  "id" : 173177512300527616,
  "created_at" : "2012-02-24 22:48:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173142149896994816",
  "text" : "Getting used to new glasses is always a pain...",
  "id" : 173142149896994816,
  "created_at" : "2012-02-24 20:28:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 60, 73 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173070791284494336",
  "text" : "Didn't think it was possible to be tripped up by a wall but @RickyHassard just did it. Awesome to witness :)",
  "id" : 173070791284494336,
  "created_at" : "2012-02-24 15:44:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173013238173270016",
  "text" : "It is Friday - but it doesn't feel like it.... Future bro in law is gonna show me SWTOR tonight though.. Sweet :D",
  "id" : 173013238173270016,
  "created_at" : "2012-02-24 11:55:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 69, 78 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 79, 94 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 95, 104 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 105, 117 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 39, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173012726707273729",
  "text" : "Don't do this usually but its Friday - #FF Cos they is all awesome - @kirkcoyb @Georgina_Milne @ManyHues @stimpled0rf",
  "id" : 173012726707273729,
  "created_at" : "2012-02-24 11:53:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Stephen McMaster",
      "screen_name" : "s_mc_master",
      "indices" : [ 16, 28 ],
      "id_str" : "501270359",
      "id" : 501270359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172974066934890496",
  "geo" : { },
  "id_str" : "172975102600806400",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @s_mc_master and cos the blonde one threatened me I think you should eat an egg if I eat a tin of pineapples.. Deal?",
  "id" : 172975102600806400,
  "in_reply_to_status_id" : 172974066934890496,
  "created_at" : "2012-02-24 09:24:12 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Stephen McMaster",
      "screen_name" : "s_mc_master",
      "indices" : [ 16, 28 ],
      "id_str" : "501270359",
      "id" : 501270359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172974066934890496",
  "geo" : { },
  "id_str" : "172974717265907712",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @s_mc_master Done. :)",
  "id" : 172974717265907712,
  "in_reply_to_status_id" : 172974066934890496,
  "created_at" : "2012-02-24 09:22:40 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172966787615432704",
  "geo" : { },
  "id_str" : "172973563274473473",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley told you it would be Monday...",
  "id" : 172973563274473473,
  "in_reply_to_status_id" : 172966787615432704,
  "created_at" : "2012-02-24 09:18:05 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172823427370061825",
  "geo" : { },
  "id_str" : "172827904198197248",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley Anytime bungle :) I now know where you live though... That thought will linger :D",
  "id" : 172827904198197248,
  "in_reply_to_status_id" : 172823427370061825,
  "created_at" : "2012-02-23 23:39:18 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 1, 13 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 15, 27 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 28, 42 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 53, 59 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172827803291631616",
  "text" : "\u201C@stimpled0rf: @niall_adams @BerryBlonde84 dickhead, @swmcc is definitely my favourite\u201D AWESOME - I'm his favourite :D :D :D :D :D",
  "id" : 172827803291631616,
  "created_at" : "2012-02-23 23:38:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 15, 27 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 28, 40 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172796720013524993",
  "geo" : { },
  "id_str" : "172798989341696001",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @niall_adams @stimpled0rf only if I can get a monacle",
  "id" : 172798989341696001,
  "in_reply_to_status_id" : 172796720013524993,
  "created_at" : "2012-02-23 21:44:24 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172796720013524993",
  "geo" : { },
  "id_str" : "172798954646409216",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84",
  "id" : 172798954646409216,
  "in_reply_to_status_id" : 172796720013524993,
  "created_at" : "2012-02-23 21:44:15 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 15, 27 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 28, 40 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172792478175465473",
  "geo" : { },
  "id_str" : "172792712137949185",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @niall_adams @stimpled0rf ??",
  "id" : 172792712137949185,
  "in_reply_to_status_id" : 172792478175465473,
  "created_at" : "2012-02-23 21:19:27 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 15, 27 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172790606396006401",
  "geo" : { },
  "id_str" : "172792106102947840",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @niall_adams ahem!!!!!!",
  "id" : 172792106102947840,
  "in_reply_to_status_id" : 172790606396006401,
  "created_at" : "2012-02-23 21:17:03 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 3, 11 ],
      "id_str" : "79820731",
      "id" : 79820731
    }, {
      "name" : "Craigavon Council",
      "screen_name" : "craigavonc",
      "indices" : [ 26, 37 ],
      "id_str" : "140128228",
      "id" : 140128228
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nilgaconf",
      "indices" : [ 64, 74 ]
    }, {
      "text" : "wedevel",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172759422584631297",
  "text" : "RT @tascomi: Good luck to @craigavonc nominated for an award at #nilgaconf with Tascomi's Te-Store procurement software system. #wedevel ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Craigavon Council",
        "screen_name" : "craigavonc",
        "indices" : [ 13, 24 ],
        "id_str" : "140128228",
        "id" : 140128228
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nilgaconf",
        "indices" : [ 51, 61 ]
      }, {
        "text" : "wedevelopthefuture",
        "indices" : [ 115, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172749934892814338",
    "text" : "Good luck to @craigavonc nominated for an award at #nilgaconf with Tascomi's Te-Store procurement software system. #wedevelopthefuture",
    "id" : 172749934892814338,
    "created_at" : "2012-02-23 18:29:28 +0000",
    "user" : {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "protected" : false,
      "id_str" : "79820731",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1736918497\/tascomi_twitter_t_normal.jpg",
      "id" : 79820731,
      "verified" : false
    }
  },
  "id" : 172759422584631297,
  "created_at" : "2012-02-23 19:07:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172725943146786816",
  "geo" : { },
  "id_str" : "172726482727219200",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf oh yeah... forgot about me doing that ;)",
  "id" : 172726482727219200,
  "in_reply_to_status_id" : 172725943146786816,
  "created_at" : "2012-02-23 16:56:17 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172716481291894784",
  "geo" : { },
  "id_str" : "172718816340606979",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf payback will be swift.... and deadly. just so you know.",
  "id" : 172718816340606979,
  "in_reply_to_status_id" : 172716481291894784,
  "created_at" : "2012-02-23 16:25:49 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 107, 119 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172715726115840000",
  "text" : "I come down to work in the downstairs office in Tascomi only to leave my phone upstars... It is war!!! \/cc @stimpled0rf",
  "id" : 172715726115840000,
  "created_at" : "2012-02-23 16:13:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172715067014512640",
  "text" : "Midgets are hot.",
  "id" : 172715067014512640,
  "created_at" : "2012-02-23 16:10:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172656330497208320",
  "geo" : { },
  "id_str" : "172660460221497344",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @stimpled0rf he let his guard down..... I was just walking past... didn't set out to do it to him.",
  "id" : 172660460221497344,
  "in_reply_to_status_id" : 172656330497208320,
  "created_at" : "2012-02-23 12:33:56 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 13, 27 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172652855742836737",
  "geo" : { },
  "id_str" : "172655100634988544",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @berryblonde84 you were weak and left the key in the door. I couldn't pass it and not....",
  "id" : 172655100634988544,
  "in_reply_to_status_id" : 172652855742836737,
  "created_at" : "2012-02-23 12:12:38 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172650540784812032",
  "geo" : { },
  "id_str" : "172650791985885184",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @stimpled0rf Oh no.. Just locked him in the toilets for about 15\/20mins... He has two left this week - so he's done well :)",
  "id" : 172650791985885184,
  "in_reply_to_status_id" : 172650540784812032,
  "created_at" : "2012-02-23 11:55:31 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172641096722157569",
  "text" : "10mins so far.....",
  "id" : 172641096722157569,
  "created_at" : "2012-02-23 11:16:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172594483937026048",
  "text" : "Dreamt I wrote an API in PHP last night... I need a week off :)",
  "id" : 172594483937026048,
  "created_at" : "2012-02-23 08:11:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172467522875043841",
  "text" : "Hmmmm starting to wonder if I shoved too much washing in the machine there... Guess I'll find out tomorrow... Now a Damages eppy :)",
  "id" : 172467522875043841,
  "created_at" : "2012-02-22 23:47:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172438217600139265",
  "geo" : { },
  "id_str" : "172438557955330048",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard looks awesome... Enjoy :)",
  "id" : 172438557955330048,
  "in_reply_to_status_id" : 172438217600139265,
  "created_at" : "2012-02-22 21:52:10 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172414675898740737",
  "text" : "Fuck sake... Just read on that amazon link that you are supposed to put on the lid.... Fucking hell Stephen... Lucky I is pretty ;)",
  "id" : 172414675898740737,
  "created_at" : "2012-02-22 20:17:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http:\/\/t.co\/FIOdTU4",
      "expanded_url" : "http:\/\/www.amazon.co.uk\/Eddingtons-Silicone-Eggshell-Egg-Poachers\/dp\/B001FAT2O4\/ref=sr_1_2?ie=UTF8&qid=1329941727&sr=8-2",
      "display_url" : "amazon.co.uk\/Eddingtons-Sil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172414330510381056",
  "text" : "Meh meh meh.. Poached eggs take so much longer when you use these bad boys... http:\/\/t.co\/FIOdTU4",
  "id" : 172414330510381056,
  "created_at" : "2012-02-22 20:15:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172407614444027904",
  "geo" : { },
  "id_str" : "172414078831173632",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Yes we really must!! Been ages.",
  "id" : 172414078831173632,
  "in_reply_to_status_id" : 172407614444027904,
  "created_at" : "2012-02-22 20:14:54 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 95, 108 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172406336598978560",
  "geo" : { },
  "id_str" : "172407090248290305",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Driving. Not drinking at a work after xmas do. Got way too drunk ended up assualting @RickyHassard and not in the way you'd think!",
  "id" : 172407090248290305,
  "in_reply_to_status_id" : 172406336598978560,
  "created_at" : "2012-02-22 19:47:08 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172405794518728705",
  "text" : "Downloaded in 45 seconds at an average of 4.3 MB\/s - and on an unrelated note.. Time for an eppy of New Girl with my poached egg :)",
  "id" : 172405794518728705,
  "created_at" : "2012-02-22 19:41:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172392881129144321",
  "geo" : { },
  "id_str" : "172405415135551488",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb I have to be honest - not looking that forward to it... I am ungreatful feck... I know.",
  "id" : 172405415135551488,
  "in_reply_to_status_id" : 172392881129144321,
  "created_at" : "2012-02-22 19:40:28 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/172399065311625216\/photo\/1",
      "indices" : [ 19, 38 ],
      "url" : "http:\/\/t.co\/6brazt4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmR8CVeCQAEKXXR.jpg",
      "id_str" : "172399065311625217",
      "id" : 172399065311625217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmR8CVeCQAEKXXR.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/6brazt4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172399065311625216",
  "text" : "Brotherly Love ... http:\/\/t.co\/6brazt4",
  "id" : 172399065311625216,
  "created_at" : "2012-02-22 19:15:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172391978737205248",
  "geo" : { },
  "id_str" : "172392468921335808",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb work paid for us to have a box which was nice. So heading there tomorrow night. Haven't a fqn clue what to do...",
  "id" : 172392468921335808,
  "in_reply_to_status_id" : 172391978737205248,
  "created_at" : "2012-02-22 18:49:02 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172391807378915330",
  "text" : "Think I'll put an end to this Wednesday... Darts tomorrow for us Tascomi folk.. Guess I should read the dummies guide to being a man....",
  "id" : 172391807378915330,
  "created_at" : "2012-02-22 18:46:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172388444432121856",
  "geo" : { },
  "id_str" : "172389572062363648",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb shitty guitar band pretending to be hardcore rockers.... I think they are pretty much the same ;)",
  "id" : 172389572062363648,
  "in_reply_to_status_id" : 172388444432121856,
  "created_at" : "2012-02-22 18:37:31 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172304582163173376",
  "geo" : { },
  "id_str" : "172317705792270336",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne wasn't a lie in... I woke up at 6 - raring to go... Then something happened and i thought it wise not to go! Next time G.",
  "id" : 172317705792270336,
  "in_reply_to_status_id" : 172304582163173376,
  "created_at" : "2012-02-22 13:51:57 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172296208516263936",
  "geo" : { },
  "id_str" : "172297318907908096",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe :D I never thought about it that way....",
  "id" : 172297318907908096,
  "in_reply_to_status_id" : 172296208516263936,
  "created_at" : "2012-02-22 12:30:56 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http:\/\/t.co\/7HLBCdG",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/education-17125538",
      "display_url" : "bbc.co.uk\/news\/education\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172293332372951040",
  "text" : "The private sector in schools.... Don't think this is a good idea.. http:\/\/t.co\/7HLBCdG",
  "id" : 172293332372951040,
  "created_at" : "2012-02-22 12:15:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172293033247780864",
  "text" : "I have given up coke and fizzy drinks... So what should I give up for lent??? Hmmmmm.....",
  "id" : 172293033247780864,
  "created_at" : "2012-02-22 12:13:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172279917835333632",
  "geo" : { },
  "id_str" : "172280512310804482",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues this is the only time that I will say the following words \"You can never have too much ginger\" :)",
  "id" : 172280512310804482,
  "in_reply_to_status_id" : 172279917835333632,
  "created_at" : "2012-02-22 11:24:09 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 14, 29 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172272148176572416",
  "geo" : { },
  "id_str" : "172272985498058753",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @georgina_milne awesome.....",
  "id" : 172272985498058753,
  "in_reply_to_status_id" : 172272148176572416,
  "created_at" : "2012-02-22 10:54:15 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 3, 18 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 41, 54 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 67, 73 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172272779759075328",
  "text" : "RT @Georgina_Milne: Dreamed that i found @Stevebiscuit in bed with @swmcc .thankfully I woke up!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Wilkin",
        "screen_name" : "stevebiscuit",
        "indices" : [ 21, 34 ],
        "id_str" : "14068466",
        "id" : 14068466
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 47, 53 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172271950595489792",
    "text" : "Dreamed that i found @Stevebiscuit in bed with @swmcc .thankfully I woke up!",
    "id" : 172271950595489792,
    "created_at" : "2012-02-22 10:50:08 +0000",
    "user" : {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "protected" : false,
      "id_str" : "15344533",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1562857707\/meee_normal.jpg",
      "id" : 15344533,
      "verified" : false
    }
  },
  "id" : 172272779759075328,
  "created_at" : "2012-02-22 10:53:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172260022871523328",
  "text" : "Hate when you are talking to someone on the phone and they talk over you!",
  "id" : 172260022871523328,
  "created_at" : "2012-02-22 10:02:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172245441499512832",
  "text" : "It is Wednesday today... Don't stay it out loud or it will fuck off and it will be Monday again. Be vewy vewy quiet!!",
  "id" : 172245441499512832,
  "created_at" : "2012-02-22 09:04:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 41, 50 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172081816751181824",
  "text" : "Stupid twitter. My thanks to the awesome @ManyHues for the lovely ginger biscuits was in my drafts. Thank you very much they were lovely :)",
  "id" : 172081816751181824,
  "created_at" : "2012-02-21 22:14:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172033783657267202",
  "text" : "Dishes washed. Latest episode of the walking dead has made its way to america.. And have the latest eppy of Spartacus to watch.. sweet :D",
  "id" : 172033783657267202,
  "created_at" : "2012-02-21 19:03:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172018327215026176",
  "text" : "Update done... Now to go home for some home cooking :D",
  "id" : 172018327215026176,
  "created_at" : "2012-02-21 18:02:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172014345151201281",
  "text" : "212\/307 - ffs...",
  "id" : 172014345151201281,
  "created_at" : "2012-02-21 17:46:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172009158822989824",
  "text" : "I should have started this yum update on my own shitty server under screen.. Cos its now 17:25 and... 27\/307 - and it still has to install!",
  "id" : 172009158822989824,
  "created_at" : "2012-02-21 17:25:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172007829346070528",
  "text" : "Updating libgcc 1\/307... Zzzzzzzzzzz",
  "id" : 172007829346070528,
  "created_at" : "2012-02-21 17:20:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172007410402209793",
  "text" : "I hate Centos.... I really really do.",
  "id" : 172007410402209793,
  "created_at" : "2012-02-21 17:18:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 11, 21 ],
      "id_str" : "9713742",
      "id" : 9713742
    }, {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 22, 31 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171997423755993088",
  "geo" : { },
  "id_str" : "171997801566314496",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus @burkazoid @akaihane Kazza.. You made me fuck all in the way of buns during our 3 year tenure at VHS\/Sendit\/BlackStar!!!!!!!",
  "id" : 171997801566314496,
  "in_reply_to_status_id" : 171997423755993088,
  "created_at" : "2012-02-21 16:40:46 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 3, 12 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171996363997982721",
  "text" : "Oi @akaihane what you cooking @bkgStatus tonight... It better be good for dragging him to that hipster-fest last night ;)",
  "id" : 171996363997982721,
  "created_at" : "2012-02-21 16:35:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 15, 27 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 28, 41 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 42, 56 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171873351025958912",
  "geo" : { },
  "id_str" : "171877632055574528",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @ryancunning @rickyhassard @peter_omalley I am fore-going the pancakes - just not feeling it today...",
  "id" : 171877632055574528,
  "in_reply_to_status_id" : 171873351025958912,
  "created_at" : "2012-02-21 08:43:15 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171686244416368641",
  "geo" : { },
  "id_str" : "171686497005744128",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley cheers pete. found that b4 - but it doesn't tell me where abouts the fucking file is :( Stupid ass shiz!",
  "id" : 171686497005744128,
  "in_reply_to_status_id" : 171686244416368641,
  "created_at" : "2012-02-20 20:03:45 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171680012007772160",
  "text" : "... fuck it - I am going home :(",
  "id" : 171680012007772160,
  "created_at" : "2012-02-20 19:37:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171679968332488704",
  "text" : "and '\/etc\/init.d\/psql start' - that's it.. Simples... Why is everything else so fucking complicated... fucks me right off.. In fact....",
  "id" : 171679968332488704,
  "created_at" : "2012-02-20 19:37:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171679826590183424",
  "text" : "Also pretty much the same problem on getting postgres to start on my mac. On debian it is 'apt-get install postgres-server'",
  "id" : 171679826590183424,
  "created_at" : "2012-02-20 19:37:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171679533907460098",
  "text" : "Fuck this. Going back to the Terminal world where things are simple. If anyone can help me out great. But it shouldn't be this hard to fix!",
  "id" : 171679533907460098,
  "created_at" : "2012-02-20 19:36:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171678212823330818",
  "text" : "Okers. Deleting the app did fuck all - prefs most be stored somewhere else. This is why I use VIM none of this wank with it... FUCKING BALLS",
  "id" : 171678212823330818,
  "created_at" : "2012-02-20 19:30:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171677413208625152",
  "text" : "Fuck it - re-installing.",
  "id" : 171677413208625152,
  "created_at" : "2012-02-20 19:27:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171672881724530688",
  "text" : "Okay.. So say you fucked up your config file for SFTP in sublime... Where do I go to edit the file... Google gods aren't helping....",
  "id" : 171672881724530688,
  "created_at" : "2012-02-20 19:09:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171603037826199552",
  "text" : ".... or at least have created or helped create something yourself before yapping. The odd website or webapp doesnt' count either!....",
  "id" : 171603037826199552,
  "created_at" : "2012-02-20 14:32:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171602794321686529",
  "text" : "Just me making a point. I see any tweets going out from anyone yapping about u.tv I will unfollow.. Be supportive of local biz....",
  "id" : 171602794321686529,
  "created_at" : "2012-02-20 14:31:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171571531506388992",
  "text" : "Fucking knew picking up that phone call was a bad idea... Grrrrrrr",
  "id" : 171571531506388992,
  "created_at" : "2012-02-20 12:26:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171537941129199618",
  "geo" : { },
  "id_str" : "171540683428073472",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid sweet - not that it matters like. But still annoying - doubt they'll be giving us any credit back due to lack of service.",
  "id" : 171540683428073472,
  "in_reply_to_status_id" : 171537941129199618,
  "created_at" : "2012-02-20 10:24:20 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 22, 36 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 38, 52 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "O2 in the UK",
      "screen_name" : "O2",
      "indices" : [ 73, 76 ],
      "id_str" : "15133627",
      "id" : 15133627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171530472243998720",
  "geo" : { },
  "id_str" : "171534131304468480",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid I am. Also @peter_omalley. @jenporterhall can though - all on @o2.",
  "id" : 171534131304468480,
  "in_reply_to_status_id" : 171530472243998720,
  "created_at" : "2012-02-20 09:58:18 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171331295085985792",
  "geo" : { },
  "id_str" : "171331548912693248",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall Am watching Upstairs Downstairs... I dunno.. You have a very low opinion of me.. I think i will hit you tomorrow!",
  "id" : 171331548912693248,
  "in_reply_to_status_id" : 171331295085985792,
  "created_at" : "2012-02-19 20:33:19 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171322411495600129",
  "geo" : { },
  "id_str" : "171322567297204224",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I think we both know the answer to that! ;)",
  "id" : 171322567297204224,
  "in_reply_to_status_id" : 171322411495600129,
  "created_at" : "2012-02-19 19:57:37 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 3, 10 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "The Yellow Door ",
      "screen_name" : "theyellowdoor",
      "indices" : [ 12, 26 ],
      "id_str" : "1732546484",
      "id" : 1732546484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170992369569759232",
  "text" : "RT @srushe: @TheYellowDoor No! Definitely not! I'm watching Danish TV, or Korean film, or independent cinema from Brazil. But definitely ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Yellow Door ",
        "screen_name" : "theyellowdoor",
        "indices" : [ 0, 14 ],
        "id_str" : "1732546484",
        "id" : 1732546484
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "170988069917425664",
    "geo" : { },
    "id_str" : "170988544674897921",
    "in_reply_to_user_id" : 19249555,
    "text" : "@TheYellowDoor No! Definitely not! I'm watching Danish TV, or Korean film, or independent cinema from Brazil. But definitely not Casualty!!!",
    "id" : 170988544674897921,
    "in_reply_to_status_id" : 170988069917425664,
    "created_at" : "2012-02-18 21:50:20 +0000",
    "in_reply_to_screen_name" : "kathrynrushe",
    "in_reply_to_user_id_str" : "19249555",
    "user" : {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "protected" : false,
      "id_str" : "761761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414429155\/DangerMan_normal.jpg",
      "id" : 761761,
      "verified" : false
    }
  },
  "id" : 170992369569759232,
  "created_at" : "2012-02-18 22:05:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170968779235401729",
  "text" : "... so have gotten hold of the first 3 episodes of Luck with Dustin Hoffman - should be good :D",
  "id" : 170968779235401729,
  "created_at" : "2012-02-18 20:31:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170968493460684800",
  "text" : "My nerd fest of the John Adams biopic is ruined. Seems I have downloaded the shitty 70's version ...",
  "id" : 170968493460684800,
  "created_at" : "2012-02-18 20:30:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "to",
      "indices" : [ 38, 41 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170909864174956544",
  "geo" : { },
  "id_str" : "170911258550337536",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore apt-get install bridge #to get over it",
  "id" : 170911258550337536,
  "in_reply_to_status_id" : 170909864174956544,
  "created_at" : "2012-02-18 16:43:14 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170893011767664642",
  "geo" : { },
  "id_str" : "170906906913804288",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams he better come out of that maze!",
  "id" : 170906906913804288,
  "in_reply_to_status_id" : 170893011767664642,
  "created_at" : "2012-02-18 16:25:56 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170868656849436672",
  "geo" : { },
  "id_str" : "170869763592040450",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams brilliant....",
  "id" : 170869763592040450,
  "in_reply_to_status_id" : 170868656849436672,
  "created_at" : "2012-02-18 13:58:20 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170834078243885056",
  "geo" : { },
  "id_str" : "170851490544623617",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams :D :D :D :D :D :D",
  "id" : 170851490544623617,
  "in_reply_to_status_id" : 170834078243885056,
  "created_at" : "2012-02-18 12:45:44 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170826011611627521",
  "geo" : { },
  "id_str" : "170826560276934656",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams This is awesome!!!! :D",
  "id" : 170826560276934656,
  "in_reply_to_status_id" : 170826011611627521,
  "created_at" : "2012-02-18 11:06:40 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 15, 27 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Longleat",
      "screen_name" : "Longleat",
      "indices" : [ 62, 71 ],
      "id_str" : "171437056",
      "id" : 171437056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170809926388678656",
  "geo" : { },
  "id_str" : "170810660249288704",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @niall_adams Fuck sake!!! Snoopy gets to go to @Longleat - am happy for him. Picture with the monkeys!! :D",
  "id" : 170810660249288704,
  "in_reply_to_status_id" : 170809926388678656,
  "created_at" : "2012-02-18 10:03:29 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170651766784917505",
  "geo" : { },
  "id_str" : "170653065421127682",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf everything ok? I downloaded John Adams biopic and stupid ass films..",
  "id" : 170653065421127682,
  "in_reply_to_status_id" : 170651766784917505,
  "created_at" : "2012-02-17 23:37:16 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170649557309460480",
  "geo" : { },
  "id_str" : "170650523647741952",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf what you playing? I just downloaded the whole interweb and made carrot and parsnip soup :)",
  "id" : 170650523647741952,
  "in_reply_to_status_id" : 170649557309460480,
  "created_at" : "2012-02-17 23:27:10 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170648375493001216",
  "geo" : { },
  "id_str" : "170650263282135040",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall good voice but she turns me...",
  "id" : 170650263282135040,
  "in_reply_to_status_id" : 170648375493001216,
  "created_at" : "2012-02-17 23:26:07 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 3, 16 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170606201556570112",
  "text" : "RT @RickyHassard: @swmcc do do do do dododo do do di do di do do do",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "170604693083525120",
    "geo" : { },
    "id_str" : "170606015333675008",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc do do do do dododo do do di do di do do do",
    "id" : 170606015333675008,
    "in_reply_to_status_id" : 170604693083525120,
    "created_at" : "2012-02-17 20:30:18 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "protected" : false,
      "id_str" : "5684272",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1317084795\/Screen_shot_2011-04-19_at_13.00.12_normal.png",
      "id" : 5684272,
      "verified" : false
    }
  },
  "id" : 170606201556570112,
  "created_at" : "2012-02-17 20:31:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170604693083525120",
  "text" : "My task for this weekend is to either play the Star Wars Cantina song on the piano.... House guests can fuck off about the noise :D",
  "id" : 170604693083525120,
  "created_at" : "2012-02-17 20:25:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 28, 41 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170595732322131968",
  "geo" : { },
  "id_str" : "170604266438930432",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @stimpled0rf @RickyHassard is it wrong that this has made me burger horny????? What an epic burger... I want one!",
  "id" : 170604266438930432,
  "in_reply_to_status_id" : 170595732322131968,
  "created_at" : "2012-02-17 20:23:21 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170560595337297920",
  "geo" : { },
  "id_str" : "170564916636430336",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall just a keek day for a Friday is all :\/",
  "id" : 170564916636430336,
  "in_reply_to_status_id" : 170560595337297920,
  "created_at" : "2012-02-17 17:46:59 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170517523639451651",
  "text" : "This Friday sucks big time.....",
  "id" : 170517523639451651,
  "created_at" : "2012-02-17 14:38:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 28, 41 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170511016373911553",
  "geo" : { },
  "id_str" : "170511184217374720",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @peter_omalley @rickyhassard It's on.. It's on like donkey kong!!!!!!!!",
  "id" : 170511184217374720,
  "in_reply_to_status_id" : 170511016373911553,
  "created_at" : "2012-02-17 14:13:28 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 10, 19 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170477333474586624",
  "geo" : { },
  "id_str" : "170487161513189378",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @akaihane TGS - of course. It is awesome. So trashy. I know... I know. i can feel your look!",
  "id" : 170487161513189378,
  "in_reply_to_status_id" : 170477333474586624,
  "created_at" : "2012-02-17 12:38:01 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 0, 9 ],
      "id_str" : "14961440",
      "id" : 14961440
    }, {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 10, 19 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170458555558789120",
  "geo" : { },
  "id_str" : "170461165128921088",
  "in_reply_to_user_id" : 14961440,
  "text" : "@akaihane @kirkcoyb name me the reality show? Geordie Shore is just so bad its good....",
  "id" : 170461165128921088,
  "in_reply_to_status_id" : 170458555558789120,
  "created_at" : "2012-02-17 10:54:43 +0000",
  "in_reply_to_screen_name" : "akaihane",
  "in_reply_to_user_id_str" : "14961440",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 4, 13 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 45, 54 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170450255429648384",
  "text" : "#FF @kirkcoyb - cos he turned 35 today.. And @akaihane - cos she has really bad taste in TV - seriously bad....",
  "id" : 170450255429648384,
  "created_at" : "2012-02-17 10:11:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 54 ],
      "url" : "http:\/\/t.co\/YyNJO55",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/blogs\/wondermonkey\/2012\/02\/super-predatory-humans.shtml",
      "display_url" : "bbc.co.uk\/blogs\/wondermo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170446742104457219",
  "text" : "Brilliant article by Matt Walker - http:\/\/t.co\/YyNJO55",
  "id" : 170446742104457219,
  "created_at" : "2012-02-17 09:57:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170443741432258560",
  "text" : "OH: I was singing the Nial Adams song...",
  "id" : 170443741432258560,
  "created_at" : "2012-02-17 09:45:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170267568727273472",
  "text" : "Some people should not be allowed near youtube.... Am just sayin... NO NAMES.. THEY KNOW WHO THEY ARE!!!!!!! :D",
  "id" : 170267568727273472,
  "created_at" : "2012-02-16 22:05:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    }, {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 28, 42 ],
      "id_str" : "49953918",
      "id" : 49953918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170177999474397184",
  "geo" : { },
  "id_str" : "170178541323943936",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings @bkgstatus @rickthejackal any of you lot tried STWOR - I can't justify the upgrade of a PC for it.",
  "id" : 170178541323943936,
  "in_reply_to_status_id" : 170177999474397184,
  "created_at" : "2012-02-16 16:11:40 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170171019615666176",
  "geo" : { },
  "id_str" : "170175325207134208",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop I prefer Debian and Ubuntu - just makes things so much easier I find.",
  "id" : 170175325207134208,
  "in_reply_to_status_id" : 170171019615666176,
  "created_at" : "2012-02-16 15:58:53 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170172262421504000",
  "geo" : { },
  "id_str" : "170175187554279424",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings read up on OS gubbins - fuck all to do with old school - hipster :D",
  "id" : 170175187554279424,
  "in_reply_to_status_id" : 170172262421504000,
  "created_at" : "2012-02-16 15:58:21 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170170370291269632",
  "geo" : { },
  "id_str" : "170170788668911616",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop use a proper OS and stop using that Redhat shite... In saying that I use CentOS in work - hate that too :)",
  "id" : 170170788668911616,
  "in_reply_to_status_id" : 170170370291269632,
  "created_at" : "2012-02-16 15:40:52 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170169733956640770",
  "text" : "\/etc\/init.d\/today restart",
  "id" : 170169733956640770,
  "created_at" : "2012-02-16 15:36:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "needaholiday",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http:\/\/t.co\/MAmS0gs",
      "expanded_url" : "http:\/\/ftp.postgresql.org\/pub\/source\/v9.1.2\/postgresql-9.1.2.tar.gz",
      "display_url" : "ftp.postgresql.org\/pub\/source\/v9.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170163656988950528",
  "text" : "I just did this on the terminal 'curl http:\/\/t.co\/MAmS0gs' - I kid you not :( #needaholiday",
  "id" : 170163656988950528,
  "created_at" : "2012-02-16 15:12:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170133664775151616",
  "geo" : { },
  "id_str" : "170135600094130177",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop ridiculous isn't it. If I can get the programme within 2 days of it airing in the states I leave it. Otherwise.. Newzbin :D",
  "id" : 170135600094130177,
  "in_reply_to_status_id" : 170133664775151616,
  "created_at" : "2012-02-16 13:21:02 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170133314487844864",
  "text" : "\"The 500th episode will air n the US on 19th February and will be shown in the UK on Sky One in June.\" - They just don't fucking get it :(",
  "id" : 170133314487844864,
  "created_at" : "2012-02-16 13:11:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170132244067917824",
  "text" : "My car is now legal for the next six months :D Ha ha... No fear of DOE cameras and police check points! Awesomeage!",
  "id" : 170132244067917824,
  "created_at" : "2012-02-16 13:07:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170096053507469312",
  "geo" : { },
  "id_str" : "170096436715859968",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe looks to me that something is happening... I am giving it two more episodes before I give up.",
  "id" : 170096436715859968,
  "in_reply_to_status_id" : 170096053507469312,
  "created_at" : "2012-02-16 10:45:25 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 0, 13 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170092060169338880",
  "geo" : { },
  "id_str" : "170093969479434240",
  "in_reply_to_user_id" : 17287895,
  "text" : "@GreasyFringe last weeks episode was quite good. But they need to get moving soon... Should start to go somewhere soon I hope.",
  "id" : 170093969479434240,
  "in_reply_to_status_id" : 170092060169338880,
  "created_at" : "2012-02-16 10:35:37 +0000",
  "in_reply_to_screen_name" : "FrederickFringe",
  "in_reply_to_user_id_str" : "17287895",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea McVeigh",
      "screen_name" : "worldinaglass",
      "indices" : [ 3, 17 ],
      "id_str" : "366115249",
      "id" : 366115249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170081194296348672",
  "text" : "RT @worldinaglass: Frack frack frackidy frack frack frack",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170081054273699840",
    "text" : "Frack frack frackidy frack frack frack",
    "id" : 170081054273699840,
    "created_at" : "2012-02-16 09:44:17 +0000",
    "user" : {
      "name" : "Andrea McVeigh",
      "screen_name" : "worldinaglass",
      "protected" : false,
      "id_str" : "366115249",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2125788138\/Twitter_daffs_normal.jpg",
      "id" : 366115249,
      "verified" : false
    }
  },
  "id" : 170081194296348672,
  "created_at" : "2012-02-16 09:44:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170070643419787264",
  "text" : "Car past :D Forgot mobile and wallet though :( Well I forgot my mobile still not 100% on the location of the wallet.",
  "id" : 170070643419787264,
  "created_at" : "2012-02-16 09:02:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 0, 9 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169926793816576000",
  "geo" : { },
  "id_str" : "170045257361272832",
  "in_reply_to_user_id" : 14961440,
  "text" : "@akaihane pfffffffffttttttt",
  "id" : 170045257361272832,
  "in_reply_to_status_id" : 169926793816576000,
  "created_at" : "2012-02-16 07:22:03 +0000",
  "in_reply_to_screen_name" : "akaihane",
  "in_reply_to_user_id_str" : "14961440",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169912231696400384",
  "text" : "Dunno... I think the 10oClockLive lot are too smug and trying to be too funny... Maybe its just me. Time for firefly...",
  "id" : 169912231696400384,
  "created_at" : "2012-02-15 22:33:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 7, 21 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 22, 34 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 90, 103 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sometimeshisideasscrewyouover",
      "indices" : [ 104, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169909529096626176",
  "geo" : { },
  "id_str" : "169909731236921344",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @peter_omalley @stimpled0rf You get the hot sauce for the mutli man challenge? \/cc @RickyHassard #sometimeshisideasscrewyouover",
  "id" : 169909731236921344,
  "in_reply_to_status_id" : 169909529096626176,
  "created_at" : "2012-02-15 22:23:31 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169909248862601216",
  "geo" : { },
  "id_str" : "169909529096626176",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @stimpled0rf In 2 days - four down.. Could be. He lost two within the space of 30seconds once on Monday morning 9am...",
  "id" : 169909529096626176,
  "in_reply_to_status_id" : 169909248862601216,
  "created_at" : "2012-02-15 22:22:43 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169908190874570753",
  "text" : "Just watched 3 episodes of Geordie Shore... Awesome show... Just awesome. Love trashy TV...",
  "id" : 169908190874570753,
  "created_at" : "2012-02-15 22:17:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169907304928514048",
  "geo" : { },
  "id_str" : "169907673117110272",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @peter_omalley Too cocky.. Show some class man! :)",
  "id" : 169907673117110272,
  "in_reply_to_status_id" : 169907304928514048,
  "created_at" : "2012-02-15 22:15:20 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169903606449971200",
  "text" : "Every night when I'm going to bed I shove on Firefly on Netflix to watch while I go to sleep. Have to say it is pure balls.",
  "id" : 169903606449971200,
  "created_at" : "2012-02-15 21:59:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169870666361880577",
  "geo" : { },
  "id_str" : "169870883509379072",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard do I look like I eat salads??? I mean the cottage pie. Tis in the hoven now chooking!!!",
  "id" : 169870883509379072,
  "in_reply_to_status_id" : 169870666361880577,
  "created_at" : "2012-02-15 19:49:09 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 33, 46 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hegivesgoodideas",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169865771164504065",
  "text" : "He has more cons than pros.. But @RickyHassard gave a great suggestion for tea the other day. Its cooking in the kitchen.. #hegivesgoodideas",
  "id" : 169865771164504065,
  "created_at" : "2012-02-15 19:28:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169814142654492673",
  "geo" : { },
  "id_str" : "169814200242286592",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley you two are on my list!",
  "id" : 169814200242286592,
  "in_reply_to_status_id" : 169814142654492673,
  "created_at" : "2012-02-15 16:03:54 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169813357774372865",
  "geo" : { },
  "id_str" : "169813815284862976",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll awesome call on the Yazoo...",
  "id" : 169813815284862976,
  "in_reply_to_status_id" : 169813357774372865,
  "created_at" : "2012-02-15 16:02:23 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169810335212118017",
  "geo" : { },
  "id_str" : "169812650061082624",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp oh no... he just wanted more food... Well in particular my home made biscuits that a friend made. Elmo was in Newcastle on Sat",
  "id" : 169812650061082624,
  "in_reply_to_status_id" : 169810335212118017,
  "created_at" : "2012-02-15 15:57:45 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 7, 19 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169803890248781825",
  "text" : "Yay... @stimpled0rf is back into the office tomorrow :D How long before he loses all his man cards.. Two days - it can be done ;)",
  "id" : 169803890248781825,
  "created_at" : "2012-02-15 15:22:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 11, 25 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 74, 83 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169803618751483904",
  "text" : "Apparently @peter_omalley isn't happy that I didn't share my biccies that @ManyHues kindly gave me.. I have an answer: fuck you peter!",
  "id" : 169803618751483904,
  "created_at" : "2012-02-15 15:21:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169794621826805760",
  "geo" : { },
  "id_str" : "169795511644205058",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll oh noooo. I'd be sucking up to you making tea and stuff cos you = baking goddess. I am all talk - easy to be nasty on twitter :D",
  "id" : 169795511644205058,
  "in_reply_to_status_id" : 169794621826805760,
  "created_at" : "2012-02-15 14:49:39 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169792418558902274",
  "geo" : { },
  "id_str" : "169793602464120833",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll I'll leave you to it now - but cannot let this pass without taking the piss. Rules are rules!",
  "id" : 169793602464120833,
  "in_reply_to_status_id" : 169792418558902274,
  "created_at" : "2012-02-15 14:42:04 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 21, 30 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 66, 73 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169793441142816768",
  "text" : "Thanks to the lovely @ManyHues for the choco biccies :D This time @srushe didn't eat them on me :D They were awesome :D",
  "id" : 169793441142816768,
  "created_at" : "2012-02-15 14:41:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169790743618142210",
  "geo" : { },
  "id_str" : "169791802356932608",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll man up!!!!",
  "id" : 169791802356932608,
  "in_reply_to_status_id" : 169790743618142210,
  "created_at" : "2012-02-15 14:34:54 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169790055982972928",
  "geo" : { },
  "id_str" : "169791755636580354",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop cheers ricky... will give it a go for a week and see.. Loving the fact you can use VIM commands in them. Hipster meets old fuck",
  "id" : 169791755636580354,
  "in_reply_to_status_id" : 169790055982972928,
  "created_at" : "2012-02-15 14:34:43 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169787719634001920",
  "geo" : { },
  "id_str" : "169789287892660224",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop am giving this sublime thing a go keep with you hipsters - is it any good?",
  "id" : 169789287892660224,
  "in_reply_to_status_id" : 169787719634001920,
  "created_at" : "2012-02-15 14:24:55 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169787149221249026",
  "geo" : { },
  "id_str" : "169787307275198464",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll just have to take it I am afraid... Tis the way of the world :D You'd be doing the same in their position :)",
  "id" : 169787307275198464,
  "in_reply_to_status_id" : 169787149221249026,
  "created_at" : "2012-02-15 14:17:03 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 1, 12 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Andrew ",
      "screen_name" : "AGRMoore",
      "indices" : [ 14, 23 ],
      "id_str" : "20197876",
      "id" : 20197876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169786932027588608",
  "text" : "\u201C@Alana_Doll: @AGRMoore em.. I'm in bloody work till 8!!\u201D Awesome... the pain wont stop till then :D :D :D I do feel sorry for ya like :D",
  "id" : 169786932027588608,
  "created_at" : "2012-02-15 14:15:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169786576212197376",
  "geo" : { },
  "id_str" : "169786788095852545",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll ha ha ha ha :D Awesome.. Are you in work now then? Class... Nothing as good as someone else with a hangover in work :D",
  "id" : 169786788095852545,
  "in_reply_to_status_id" : 169786576212197376,
  "created_at" : "2012-02-15 14:14:59 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169781950159130624",
  "geo" : { },
  "id_str" : "169786087164743680",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll at least you still have a head :D Where did you go?",
  "id" : 169786087164743680,
  "in_reply_to_status_id" : 169781950159130624,
  "created_at" : "2012-02-15 14:12:12 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169779549842837504",
  "geo" : { },
  "id_str" : "169780533562318848",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll sore head? :D",
  "id" : 169780533562318848,
  "in_reply_to_status_id" : 169779549842837504,
  "created_at" : "2012-02-15 13:50:08 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169738511065423872",
  "geo" : { },
  "id_str" : "169743809800970240",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin Blog about it :D Blog about it :D",
  "id" : 169743809800970240,
  "in_reply_to_status_id" : 169738511065423872,
  "created_at" : "2012-02-15 11:24:12 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169719883674828800",
  "geo" : { },
  "id_str" : "169733240301682688",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin oh anything. I just think the whole thing is interesting - so just wondering if anyone has any xp on it locally.",
  "id" : 169733240301682688,
  "in_reply_to_status_id" : 169719883674828800,
  "created_at" : "2012-02-15 10:42:12 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169721753763987458",
  "geo" : { },
  "id_str" : "169723796247412736",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight :D Grow a set man :D",
  "id" : 169723796247412736,
  "in_reply_to_status_id" : 169721753763987458,
  "created_at" : "2012-02-15 10:04:40 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169718449864581121",
  "geo" : { },
  "id_str" : "169719395617210368",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @stimpled0rf if Snoopy failed to appear we would be having a problem.. And you should have let him go with the GS girls :D",
  "id" : 169719395617210368,
  "in_reply_to_status_id" : 169718449864581121,
  "created_at" : "2012-02-15 09:47:11 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169718806778888192",
  "geo" : { },
  "id_str" : "169719278680018947",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor and ginger... Don't forget ginger!",
  "id" : 169719278680018947,
  "in_reply_to_status_id" : 169718806778888192,
  "created_at" : "2012-02-15 09:46:43 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169719223646556160",
  "text" : "Anyone have any xp in building a render farm? I would like to hear your stories.",
  "id" : 169719223646556160,
  "created_at" : "2012-02-15 09:46:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169558584290574336",
  "geo" : { },
  "id_str" : "169718597181128704",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight :D Shaddddaaaaappppp - you still in the BM?",
  "id" : 169718597181128704,
  "in_reply_to_status_id" : 169558584290574336,
  "created_at" : "2012-02-15 09:44:01 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 25, 32 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169701514154225665",
  "text" : "Weird dream #46 - Me and @srushe in work decided to go to The Plough on a tandem for... shoe shopping... WTF is wrong with me????",
  "id" : 169701514154225665,
  "created_at" : "2012-02-15 08:36:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169523110431834112",
  "text" : "Car back - 170quid.... Not that bad - new front spring needed at 60quid... Fucking pot holes.. Hopefully she passes.",
  "id" : 169523110431834112,
  "created_at" : "2012-02-14 20:47:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169454051975626754",
  "geo" : { },
  "id_str" : "169454181235703809",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe fuck sake :(",
  "id" : 169454181235703809,
  "in_reply_to_status_id" : 169454051975626754,
  "created_at" : "2012-02-14 16:13:19 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169453299672678400",
  "geo" : { },
  "id_str" : "169453541042298881",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb in two months time i will be 33... But tomorrow I am still 32.... ;)",
  "id" : 169453541042298881,
  "in_reply_to_status_id" : 169453299672678400,
  "created_at" : "2012-02-14 16:10:47 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Ruse",
      "screen_name" : "SRuse",
      "indices" : [ 15, 21 ],
      "id_str" : "21408180",
      "id" : 21408180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169453344375586816",
  "text" : "Road trip with @sruse later!",
  "id" : 169453344375586816,
  "created_at" : "2012-02-14 16:10:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169438981501628419",
  "geo" : { },
  "id_str" : "169453091979141121",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa same here.. when i hit 50 I can take a lump sum.. That's in almost 17 years... been working 12. Working sucks!!!",
  "id" : 169453091979141121,
  "in_reply_to_status_id" : 169438981501628419,
  "created_at" : "2012-02-14 16:09:00 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169451454598352896",
  "geo" : { },
  "id_str" : "169452752127266816",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35 35",
  "id" : 169452752127266816,
  "in_reply_to_status_id" : 169451454598352896,
  "created_at" : "2012-02-14 16:07:39 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169448646348247040",
  "text" : "This day, I can say quite clearly has sucked major ass.",
  "id" : 169448646348247040,
  "created_at" : "2012-02-14 15:51:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169438030233481216",
  "geo" : { },
  "id_str" : "169447792488611840",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb no craic at all... Lies.. It is today and it is 35 :D",
  "id" : 169447792488611840,
  "in_reply_to_status_id" : 169438030233481216,
  "created_at" : "2012-02-14 15:47:56 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169429161105039361",
  "geo" : { },
  "id_str" : "169432655887212544",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne working is for losers :D If I get my car back this week I am heading up the cave hill again :D Am getting there like ;)",
  "id" : 169432655887212544,
  "in_reply_to_status_id" : 169429161105039361,
  "created_at" : "2012-02-14 14:47:47 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169422605114294272",
  "geo" : { },
  "id_str" : "169425762733133825",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Riches don't make a man rich.They only make him busier. - ignore me :)",
  "id" : 169425762733133825,
  "in_reply_to_status_id" : 169422605114294272,
  "created_at" : "2012-02-14 14:20:24 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 18, 27 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169420969524461568",
  "text" : "Happy Birthday to @kirkcoyb - 35 today! :D",
  "id" : 169420969524461568,
  "created_at" : "2012-02-14 14:01:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169419871195635714",
  "geo" : { },
  "id_str" : "169420898665902080",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb :D Just one of those days Kirky :D Any craic? Oh Happpppyyyy Birthday :D",
  "id" : 169420898665902080,
  "in_reply_to_status_id" : 169419871195635714,
  "created_at" : "2012-02-14 14:01:04 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169419217907625984",
  "geo" : { },
  "id_str" : "169420794164809728",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor think the official term is 'cunted right off'",
  "id" : 169420794164809728,
  "in_reply_to_status_id" : 169419217907625984,
  "created_at" : "2012-02-14 14:00:39 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/QjTLufs",
      "expanded_url" : "http:\/\/i.imgur.com\/7u7lM.gif",
      "display_url" : "i.imgur.com\/7u7lM.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "169418928550969344",
  "text" : "http:\/\/t.co\/QjTLufs",
  "id" : 169418928550969344,
  "created_at" : "2012-02-14 13:53:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169391013759164416",
  "geo" : { },
  "id_str" : "169392091049377792",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne what women?",
  "id" : 169392091049377792,
  "in_reply_to_status_id" : 169391013759164416,
  "created_at" : "2012-02-14 12:06:36 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/169352823329402880\/photo\/1",
      "indices" : [ 24, 43 ],
      "url" : "http:\/\/t.co\/Ov96WZk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlmpftyCMAAQu2h.jpg",
      "id_str" : "169352823333597184",
      "id" : 169352823333597184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlmpftyCMAAQu2h.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/Ov96WZk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169352823329402880",
  "text" : "Waiting for the bus.... http:\/\/t.co\/Ov96WZk",
  "id" : 169352823329402880,
  "created_at" : "2012-02-14 09:30:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169336332374650880",
  "text" : "Worst thing about public transport - when the bus is there early. I was there 10mins before dep time.. 4 other ppl missed it too. :(",
  "id" : 169336332374650880,
  "created_at" : "2012-02-14 08:25:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169187473417703424",
  "geo" : { },
  "id_str" : "169187665885937664",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I am no fan of Lisburn - but there is no fucking way Lisburn is the same as the west.. No fucking way!",
  "id" : 169187665885937664,
  "in_reply_to_status_id" : 169187473417703424,
  "created_at" : "2012-02-13 22:34:17 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169186758892859392",
  "geo" : { },
  "id_str" : "169186871065313280",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams thought you lived in Lisburn though? :)",
  "id" : 169186871065313280,
  "in_reply_to_status_id" : 169186758892859392,
  "created_at" : "2012-02-13 22:31:08 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169177961352790016",
  "geo" : { },
  "id_str" : "169178726939115520",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf anywhere but the west is a good bet and some parts of the north are best to avoid.",
  "id" : 169178726939115520,
  "in_reply_to_status_id" : 169177961352790016,
  "created_at" : "2012-02-13 21:58:46 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169177961352790016",
  "geo" : { },
  "id_str" : "169178227024211969",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf I'll need to get you a house warming present (with internal web cam of course)...",
  "id" : 169178227024211969,
  "in_reply_to_status_id" : 169177961352790016,
  "created_at" : "2012-02-13 21:56:47 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169162154979762177",
  "geo" : { },
  "id_str" : "169169715858640896",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf you find anywhere?",
  "id" : 169169715858640896,
  "in_reply_to_status_id" : 169162154979762177,
  "created_at" : "2012-02-13 21:22:57 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 14, 28 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 29, 43 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169139179777826818",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @jenporterhall @peter_omalley Think she is actually gonna die from laughing...",
  "id" : 169139179777826818,
  "created_at" : "2012-02-13 19:21:37 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 92, 105 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 106, 120 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 121, 135 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169139094050455552",
  "text" : "Showing my sister this Dixie Dude stuff was not a good idea. Repeat - not a good idea!! \/cc @RickyHassard @jenporterhall @peter_omalley",
  "id" : 169139094050455552,
  "created_at" : "2012-02-13 19:21:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 29, 41 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169108182663303168",
  "text" : "I just said the following to @niall_adams - \"I got the numbers right - just in the wrong order\". That's how I roll :)",
  "id" : 169108182663303168,
  "created_at" : "2012-02-13 17:18:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 15, 29 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 30, 42 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 43, 55 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169104923739439104",
  "geo" : { },
  "id_str" : "169105741951664128",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @berryblonde84 @stimpled0rf @niall_adams Peter just asked me if they could do double burgers.... Man Challenge :D",
  "id" : 169105741951664128,
  "in_reply_to_status_id" : 169104923739439104,
  "created_at" : "2012-02-13 17:08:45 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 28, 42 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 43, 55 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169104235387035648",
  "geo" : { },
  "id_str" : "169104346070519808",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @peter_omalley @berryblonde84 @stimpled0rf makes sense, you are a twat after all :D",
  "id" : 169104346070519808,
  "in_reply_to_status_id" : 169104235387035648,
  "created_at" : "2012-02-13 17:03:12 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 28, 42 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 43, 55 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169102944967458816",
  "geo" : { },
  "id_str" : "169103095962419202",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @peter_omalley @berryblonde84 @stimpled0rf its almost as good as a boojum... It would be a hard call between the two IMVHO.",
  "id" : 169103095962419202,
  "in_reply_to_status_id" : 169102944967458816,
  "created_at" : "2012-02-13 16:58:14 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 9, 23 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169102633171300352",
  "text" : "Oh I met @BerryBlonde84 on my travels today. She is pretty cool :) She gave me back Snoopy so we are friends now :)",
  "id" : 169102633171300352,
  "created_at" : "2012-02-13 16:56:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 28, 42 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169080024245346306",
  "geo" : { },
  "id_str" : "169083515420426240",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @peter_omalley @berryblonde84 you go for a belfast bap option?",
  "id" : 169083515420426240,
  "in_reply_to_status_id" : 169080024245346306,
  "created_at" : "2012-02-13 15:40:26 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 117, 131 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169058476964847616",
  "text" : "I made a ref to Slum Dog Millionaire today to a man from Derry. A new low and slightly racist of me too I think. \/cc @No_Underscore",
  "id" : 169058476964847616,
  "created_at" : "2012-02-13 14:00:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 35, 47 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 92, 106 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169053825687240704",
  "geo" : { },
  "id_str" : "169055734447882240",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe I flashed a bit of leg and @stimpled0rf pulled over... Was either him or the lovely @jenporterhall - either one ;)",
  "id" : 169055734447882240,
  "in_reply_to_status_id" : 169053825687240704,
  "created_at" : "2012-02-13 13:50:02 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169055023991504896",
  "geo" : { },
  "id_str" : "169055603195523073",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore that I do :D But I am going on Who Wants to be a Millionaire tonight so fingers crossed ;)",
  "id" : 169055603195523073,
  "in_reply_to_status_id" : 169055023991504896,
  "created_at" : "2012-02-13 13:49:31 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169053904137490433",
  "in_reply_to_user_id" : 33658328,
  "text" : "@no_underscore ... were very uneven.",
  "id" : 169053904137490433,
  "created_at" : "2012-02-13 13:42:46 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169053264036380672",
  "geo" : { },
  "id_str" : "169053800257163266",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore i never post anything of note.. ever.. But I can rhyme... look at this. There once was a young man named Cairan who's balls..",
  "id" : 169053800257163266,
  "in_reply_to_status_id" : 169053264036380672,
  "created_at" : "2012-02-13 13:42:21 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169052135785381888",
  "geo" : { },
  "id_str" : "169052383744245760",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor awk there is plenty of love there. We just have an odd way of talking to each other :D But she is a dumb fucker like..",
  "id" : 169052383744245760,
  "in_reply_to_status_id" : 169052135785381888,
  "created_at" : "2012-02-13 13:36:43 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169051974900264962",
  "geo" : { },
  "id_str" : "169052172703629312",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe I got here this morning :D Getting back would be a problem though :)",
  "id" : 169052172703629312,
  "in_reply_to_status_id" : 169051974900264962,
  "created_at" : "2012-02-13 13:35:53 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169051490193911810",
  "geo" : { },
  "id_str" : "169051651695587328",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor she's really anal about what lane to get into and stuff like that. She can't follow directions. Basically she's a stupid bitch :D",
  "id" : 169051651695587328,
  "in_reply_to_status_id" : 169051490193911810,
  "created_at" : "2012-02-13 13:33:49 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169051122869346304",
  "geo" : { },
  "id_str" : "169051516387340288",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Pfffttt. small one :D Make it a big one :) Drinking on a school night too!!!",
  "id" : 169051516387340288,
  "in_reply_to_status_id" : 169051122869346304,
  "created_at" : "2012-02-13 13:33:16 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169051235255726080",
  "text" : "Sister is coming down to pick me up later as I am carless for a few days.. Stupid wench needed directions to Hillsborough though :(",
  "id" : 169051235255726080,
  "created_at" : "2012-02-13 13:32:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169046447109574656",
  "geo" : { },
  "id_str" : "169051088643821570",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll being 30 isn't that bad :D You feel no guilt in staying in and doing boring geeky things anymore. At least I don't :D",
  "id" : 169051088643821570,
  "in_reply_to_status_id" : 169046447109574656,
  "created_at" : "2012-02-13 13:31:35 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169038120661168128",
  "geo" : { },
  "id_str" : "169050823576387584",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Where you drinking to celebrate this stupid non holiday then? Will there be a hang-over on Wednesday morning?",
  "id" : 169050823576387584,
  "in_reply_to_status_id" : 169038120661168128,
  "created_at" : "2012-02-13 13:30:31 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Fresh Made Media",
      "screen_name" : "studiofmm",
      "indices" : [ 15, 25 ],
      "id_str" : "137625620",
      "id" : 137625620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169035622537900033",
  "geo" : { },
  "id_str" : "169050296318832640",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @studiofmm did you man that to rhyme C... Cos if you did you deserve to be de-balled...",
  "id" : 169050296318832640,
  "in_reply_to_status_id" : 169035622537900033,
  "created_at" : "2012-02-13 13:28:26 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 7, 19 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169016858706583552",
  "text" : "I miss @stimpled0rf there is no one to play with today....",
  "id" : 169016858706583552,
  "created_at" : "2012-02-13 11:15:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169007375624318976",
  "geo" : { },
  "id_str" : "169007764255944705",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Unfair.... Illegal... Well played. Lucky you are a baking godess or such tweets would cause you instant pain\/death :)",
  "id" : 169007764255944705,
  "in_reply_to_status_id" : 169007375624318976,
  "created_at" : "2012-02-13 10:39:25 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169006368001490944",
  "text" : "I am grateful for my job. I work with great people... But by fuck I do hate Mondays.... I really really \/really\/ *really* do!",
  "id" : 169006368001490944,
  "created_at" : "2012-02-13 10:33:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168743461703520257",
  "geo" : { },
  "id_str" : "168745510138679296",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams hurry up and watch the rest :)",
  "id" : 168745510138679296,
  "in_reply_to_status_id" : 168743461703520257,
  "created_at" : "2012-02-12 17:17:19 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168714145544417282",
  "geo" : { },
  "id_str" : "168720726856183811",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams what you talking about poncho?",
  "id" : 168720726856183811,
  "in_reply_to_status_id" : 168714145544417282,
  "created_at" : "2012-02-12 15:38:50 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 109, 123 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168698324852031489",
  "text" : "Am just saying... If someone shoves on any Whitney songs tomorrow on sonos this week they get a kickin!! \/cc @jenporterhall",
  "id" : 168698324852031489,
  "created_at" : "2012-02-12 14:09:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168490951361302528",
  "text" : "I just moved my bedroom around for the first time in 4 years. Gonna wake up wondering where the fuck I am tomorrow :D",
  "id" : 168490951361302528,
  "created_at" : "2012-02-12 00:25:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 1, 13 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/Hai6hba",
      "expanded_url" : "http:\/\/twitter.com\/stimpled0rf\/status\/168437468109086722\/photo\/1",
      "display_url" : "pic.twitter.com\/Hai6hba"
    } ]
  },
  "geo" : { },
  "id_str" : "168490805445656576",
  "text" : "\u201C@stimpled0rf: Nice afternoon at The Baltic seeing the Liz Price exhibition, even Snoopy seemed to enjoy the cocktails http:\/\/t.co\/Hai6hba\u201D",
  "id" : 168490805445656576,
  "created_at" : "2012-02-12 00:25:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168407285423550467",
  "text" : "My sky plus box just died.... Don't really use sky that much anymore do doubt I'll get it fixed. 20quid better off a month now I'd say..",
  "id" : 168407285423550467,
  "created_at" : "2012-02-11 18:53:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168362066669879297",
  "geo" : { },
  "id_str" : "168373490720833536",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @peter_omalley a tampon could put your manliness to shame at the minute mike!!!!",
  "id" : 168373490720833536,
  "in_reply_to_status_id" : 168362066669879297,
  "created_at" : "2012-02-11 16:39:03 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168310494619385857",
  "geo" : { },
  "id_str" : "168346514706538496",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @stimpled0rf Well played. Just make sure he gets a go on someone from the geordie shore will ya please? :D",
  "id" : 168346514706538496,
  "in_reply_to_status_id" : 168310494619385857,
  "created_at" : "2012-02-11 14:51:51 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168299642444980224",
  "geo" : { },
  "id_str" : "168300312623464448",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf Noooooo!!!!!!!!!!!!!!",
  "id" : 168300312623464448,
  "in_reply_to_status_id" : 168299642444980224,
  "created_at" : "2012-02-11 11:48:16 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168290658153537536",
  "text" : "Also seems I am over 5000 tweets now... Dunno what my 5000 tweet was - but am sure it was mature, profound and awesome. Just like me! :D",
  "id" : 168290658153537536,
  "created_at" : "2012-02-11 11:09:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168290262882320384",
  "text" : "Must get up and forage for food. Tesco shop done last night so it wont be hard... Star Wars: The Clone Wars and porridge :D",
  "id" : 168290262882320384,
  "created_at" : "2012-02-11 11:08:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 15, 27 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168087401665806337",
  "geo" : { },
  "id_str" : "168119659198021632",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @Kirstylvssp that is impressive eating - even for you...",
  "id" : 168119659198021632,
  "in_reply_to_status_id" : 168087401665806337,
  "created_at" : "2012-02-10 23:50:24 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168085644374048769",
  "text" : "Downloaded in 41 seconds at an average of 4.4 MB\/s - not bad for a 200Mb file :D",
  "id" : 168085644374048769,
  "created_at" : "2012-02-10 21:35:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168085431064338433",
  "text" : "Dead excited about the lamp and bookcase I got at Ikea.. Sad sad sad... TBBT downloaded :D :D Sweet!!!!",
  "id" : 168085431064338433,
  "created_at" : "2012-02-10 21:34:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168083224222896129",
  "geo" : { },
  "id_str" : "168083520823107584",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke you pass :)",
  "id" : 168083520823107584,
  "in_reply_to_status_id" : 168083224222896129,
  "created_at" : "2012-02-10 21:26:48 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168079827138654208",
  "geo" : { },
  "id_str" : "168083038574608384",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley then man is a machine. He also had a sausage bap for breakfast and a huge chip at lunch! He has worms!",
  "id" : 168083038574608384,
  "in_reply_to_status_id" : 168079827138654208,
  "created_at" : "2012-02-10 21:24:53 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 3, 15 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 30, 44 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168082859280711680",
  "text" : "RT @Kirstylvssp: Just watched @peter_omalley eat a whole large dominos pizza I gave up after half of mine and still can't move.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter O'Malley",
        "screen_name" : "peter_omalley",
        "indices" : [ 13, 27 ],
        "id_str" : "437697624",
        "id" : 437697624
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168079827138654208",
    "text" : "Just watched @peter_omalley eat a whole large dominos pizza I gave up after half of mine and still can't move.",
    "id" : 168079827138654208,
    "created_at" : "2012-02-10 21:12:08 +0000",
    "user" : {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "protected" : false,
      "id_str" : "453312717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2167020438\/image_normal.jpg",
      "id" : 453312717,
      "verified" : false
    }
  },
  "id" : 168082859280711680,
  "created_at" : "2012-02-10 21:24:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168072857929261057",
  "geo" : { },
  "id_str" : "168082756109213696",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa it's a good watch. Gets better. An on episode 12.",
  "id" : 168082756109213696,
  "in_reply_to_status_id" : 168072857929261057,
  "created_at" : "2012-02-10 21:23:46 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cracksthewhip",
      "indices" : [ 69, 83 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168055556425265152",
  "geo" : { },
  "id_str" : "168082317972221952",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke you write test cases for those sixty lines young fella? #cracksthewhip",
  "id" : 168082317972221952,
  "in_reply_to_status_id" : 168055556425265152,
  "created_at" : "2012-02-10 21:22:02 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168082052044951552",
  "text" : "Just in the door.... Ikea then Tesco... Rock and roll lifestyle. Now to download TBBT and watch it with some tea and possibly a twix!!",
  "id" : 168082052044951552,
  "created_at" : "2012-02-10 21:20:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 26, 40 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167953291894980608",
  "geo" : { },
  "id_str" : "167961799159853056",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @niall_adams @berryblonde84 you said that the tones matched her cardigan!!!! Don't try and justify it!",
  "id" : 167961799159853056,
  "in_reply_to_status_id" : 167953291894980608,
  "created_at" : "2012-02-10 13:23:08 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 16, 28 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167949131489357824",
  "text" : "Epic hat tip to @stimpled0rf. Poor bastard has been sneezing and blowing his nose all day...",
  "id" : 167949131489357824,
  "created_at" : "2012-02-10 12:32:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167924990031839233",
  "geo" : { },
  "id_str" : "167926768743882752",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @stimpled0rf he wont be sick for this trip... He is sneezing and blowing his nose a good bit more than usual :D",
  "id" : 167926768743882752,
  "in_reply_to_status_id" : 167924990031839233,
  "created_at" : "2012-02-10 11:03:56 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 122, 134 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167919622539055106",
  "text" : "He did the man challenge.. Tea spoonful of out of date english mustard - held for 5 seconds then swallowed... Hats off to @stimpled0rf",
  "id" : 167919622539055106,
  "created_at" : "2012-02-10 10:35:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 11, 23 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 24, 37 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167915485252427777",
  "geo" : { },
  "id_str" : "167916708563124224",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid @stimpled0rf @rickyhassard I am at a loss..... Can you think of one?",
  "id" : 167916708563124224,
  "in_reply_to_status_id" : 167915485252427777,
  "created_at" : "2012-02-10 10:23:57 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 13, 23 ],
      "id_str" : "9713742",
      "id" : 9713742
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 24, 37 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167913631751749633",
  "geo" : { },
  "id_str" : "167913840397385728",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @burkazoid @rickyhassard all man cards down.. Now for a man challenge..... Only way to save himself this week.",
  "id" : 167913840397385728,
  "in_reply_to_status_id" : 167913631751749633,
  "created_at" : "2012-02-10 10:12:33 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 11, 23 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167909403289333761",
  "geo" : { },
  "id_str" : "167912966476410880",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid @stimpled0rf yes it was :D",
  "id" : 167912966476410880,
  "in_reply_to_status_id" : 167909403289333761,
  "created_at" : "2012-02-10 10:09:05 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 3, 16 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167912254723985408",
  "text" : "RT @RickyHassard: @swmcc man card down! man card down!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167903529837674496",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc man card down! man card down!",
    "id" : 167903529837674496,
    "created_at" : "2012-02-10 09:31:35 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "protected" : false,
      "id_str" : "5684272",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1317084795\/Screen_shot_2011-04-19_at_13.00.12_normal.png",
      "id" : 5684272,
      "verified" : false
    }
  },
  "id" : 167912254723985408,
  "created_at" : "2012-02-10 10:06:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167908432702214144",
  "text" : "Right tweets.... If a man complements a woman on her shoes goes with a cardigan.. Is that an unmanly thing to do?",
  "id" : 167908432702214144,
  "created_at" : "2012-02-10 09:51:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167746456055316481",
  "geo" : { },
  "id_str" : "167746809995862017",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @peter_omalley I wish!",
  "id" : 167746809995862017,
  "in_reply_to_status_id" : 167746456055316481,
  "created_at" : "2012-02-09 23:08:50 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167730226237939712",
  "geo" : { },
  "id_str" : "167745875089694721",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @stimpled0rf of course I will. For his Mike.",
  "id" : 167745875089694721,
  "in_reply_to_status_id" : 167730226237939712,
  "created_at" : "2012-02-09 23:05:07 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/167704465762287616\/photo\/1",
      "indices" : [ 12, 31 ],
      "url" : "http:\/\/t.co\/kwUL2M4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlPOUrVCAAE2iwd.jpg",
      "id_str" : "167704465766481921",
      "id" : 167704465766481921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlPOUrVCAAE2iwd.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/kwUL2M4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167704465762287616",
  "text" : "It hurts :( http:\/\/t.co\/kwUL2M4",
  "id" : 167704465762287616,
  "created_at" : "2012-02-09 20:20:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167695565747003392",
  "text" : "Just got tweetdesk on chrome for my pc at home... Am very very very impressed. And no Air updates :D",
  "id" : 167695565747003392,
  "created_at" : "2012-02-09 19:45:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167691327138562048",
  "geo" : { },
  "id_str" : "167691595066507264",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa this whole time of following i never noticed :)",
  "id" : 167691595066507264,
  "in_reply_to_status_id" : 167691327138562048,
  "created_at" : "2012-02-09 19:29:26 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167670746355732480",
  "geo" : { },
  "id_str" : "167691082606448640",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa pic or stfu :)",
  "id" : 167691082606448640,
  "in_reply_to_status_id" : 167670746355732480,
  "created_at" : "2012-02-09 19:27:24 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 16, 29 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167603007356289024",
  "text" : "Am now hungry.. @RickyHassard just had what I think cold be the best lunch ever.......",
  "id" : 167603007356289024,
  "created_at" : "2012-02-09 13:37:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167555245830979584",
  "text" : "Forgetting how to spell SMART? That's a paddlin'",
  "id" : 167555245830979584,
  "created_at" : "2012-02-09 10:27:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Tracy Adams",
      "screen_name" : "tracy2710",
      "indices" : [ 13, 23 ],
      "id_str" : "241879307",
      "id" : 241879307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167547345649668096",
  "geo" : { },
  "id_str" : "167550927853719552",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @tracy2710 you sell one more god damn thing and i am gonna cut your jacobs off!",
  "id" : 167550927853719552,
  "in_reply_to_status_id" : 167547345649668096,
  "created_at" : "2012-02-09 10:10:28 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Adams",
      "screen_name" : "tracy2710",
      "indices" : [ 0, 10 ],
      "id_str" : "241879307",
      "id" : 241879307
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 11, 23 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167546181164085248",
  "geo" : { },
  "id_str" : "167547150593556480",
  "in_reply_to_user_id" : 241879307,
  "text" : "@tracy2710 @niall_adams he was acting sick.... He was skipping about yesterday.",
  "id" : 167547150593556480,
  "in_reply_to_status_id" : 167546181164085248,
  "created_at" : "2012-02-09 09:55:28 +0000",
  "in_reply_to_screen_name" : "tracy2710",
  "in_reply_to_user_id_str" : "241879307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167395833157910529",
  "geo" : { },
  "id_str" : "167523823833464833",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore Stick with it. It is good for what it is. I think it came of age in Season 2. Check out Sons of Anarchy.",
  "id" : 167523823833464833,
  "in_reply_to_status_id" : 167395833157910529,
  "created_at" : "2012-02-09 08:22:46 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167387228916563969",
  "geo" : { },
  "id_str" : "167523600482570240",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore looking forward to that spiderman film. Looks very good.",
  "id" : 167523600482570240,
  "in_reply_to_status_id" : 167387228916563969,
  "created_at" : "2012-02-09 08:21:53 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "footballjokeiamaboy",
      "indices" : [ 109, 129 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167346533149310977",
  "geo" : { },
  "id_str" : "167347699149049856",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley apparently Gazza has shown up at the FA headquarters with a bargin bucket and a fishing road. #footballjokeiamaboy!!! :D",
  "id" : 167347699149049856,
  "in_reply_to_status_id" : 167346533149310977,
  "created_at" : "2012-02-08 20:42:55 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 58, 65 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167232846568755202",
  "text" : "Just destroyed @stimpled0rf with the same thing I said to @srushe this morning.",
  "id" : 167232846568755202,
  "created_at" : "2012-02-08 13:06:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167188337520676864",
  "geo" : { },
  "id_str" : "167193296320462849",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe and it was only four words as well... And the first three were \"I am not...\" :D",
  "id" : 167193296320462849,
  "in_reply_to_status_id" : 167188337520676864,
  "created_at" : "2012-02-08 10:29:22 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 3, 10 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 43, 49 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167193188010958848",
  "text" : "RT @srushe: I've just heard something from @swmcc which made me hold my head in my hands in shock. He is a disturbing man!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 31, 37 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167188337520676864",
    "text" : "I've just heard something from @swmcc which made me hold my head in my hands in shock. He is a disturbing man!",
    "id" : 167188337520676864,
    "created_at" : "2012-02-08 10:09:40 +0000",
    "user" : {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "protected" : false,
      "id_str" : "761761",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1414429155\/DangerMan_normal.jpg",
      "id" : 761761,
      "verified" : false
    }
  },
  "id" : 167193188010958848,
  "created_at" : "2012-02-08 10:28:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 15, 29 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167016521586065408",
  "geo" : { },
  "id_str" : "167017638818615296",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @jenporterhall I think Jenni is still cross after Browniegate",
  "id" : 167017638818615296,
  "in_reply_to_status_id" : 167016521586065408,
  "created_at" : "2012-02-07 22:51:22 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167010997826109440",
  "geo" : { },
  "id_str" : "167016121327820800",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll I am going to be in my bitter shell then lol... Am ok with it now like.... But still... Grrrrrrr.",
  "id" : 167016121327820800,
  "in_reply_to_status_id" : 167010997826109440,
  "created_at" : "2012-02-07 22:45:20 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167015631953199107",
  "geo" : { },
  "id_str" : "167015882940350465",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley I think you'll find Snoopy has never once invited her over. She comes over.... Dirty harlot!!!",
  "id" : 167015882940350465,
  "in_reply_to_status_id" : 167015631953199107,
  "created_at" : "2012-02-07 22:44:24 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166993105587945472",
  "geo" : { },
  "id_str" : "167010417191829504",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll stupid non holiday.... I am glad I don't have to partake in it. Hell I didn't even partake in it last year. Am glad now like :)",
  "id" : 167010417191829504,
  "in_reply_to_status_id" : 166993105587945472,
  "created_at" : "2012-02-07 22:22:41 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167008555872948224",
  "geo" : { },
  "id_str" : "167009744937156608",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @peter_omalley syphilis",
  "id" : 167009744937156608,
  "in_reply_to_status_id" : 167008555872948224,
  "created_at" : "2012-02-07 22:20:00 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167006787747332097",
  "geo" : { },
  "id_str" : "167009688427311104",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley the further I am away the further Snoopy is. Doubt that'll stop that nympho Minnie though....",
  "id" : 167009688427311104,
  "in_reply_to_status_id" : 167006787747332097,
  "created_at" : "2012-02-07 22:19:47 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166993919589105665",
  "geo" : { },
  "id_str" : "167004670391361536",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley probably. I miss my old Petorian desk...",
  "id" : 167004670391361536,
  "in_reply_to_status_id" : 166993919589105665,
  "created_at" : "2012-02-07 21:59:50 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 15, 29 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167004174859509761",
  "geo" : { },
  "id_str" : "167004511108476928",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @jenporterhall you couldn't hit me with Minnie when I was close :) Plus you are a stinky girl so can't throw! :)",
  "id" : 167004511108476928,
  "in_reply_to_status_id" : 167004174859509761,
  "created_at" : "2012-02-07 21:59:12 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "indices" : [ 3, 10 ],
      "id_str" : "14060295",
      "id" : 14060295
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 89, 94 ]
    }, {
      "text" : "titanicQ",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166967017440677888",
  "text" : "RT @cimota: No decent mobile infrastructure, no wifi. And this is the Innovation Centre. #fail #titanicQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fail",
        "indices" : [ 77, 82 ]
      }, {
        "text" : "titanicQ",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.613541394, -5.9022567793 ]
    },
    "id_str" : "166960694779068416",
    "text" : "No decent mobile infrastructure, no wifi. And this is the Innovation Centre. #fail #titanicQ",
    "id" : 166960694779068416,
    "created_at" : "2012-02-07 19:05:06 +0000",
    "user" : {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "protected" : false,
      "id_str" : "14060295",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2844403973\/36986f401fc4df14d5abe8b38c1301cc_normal.jpeg",
      "id" : 14060295,
      "verified" : false
    }
  },
  "id" : 166967017440677888,
  "created_at" : "2012-02-07 19:30:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166941257246048257",
  "geo" : { },
  "id_str" : "166953637120180226",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus had too much guff on it and in the drawers to actually move.",
  "id" : 166953637120180226,
  "in_reply_to_status_id" : 166941257246048257,
  "created_at" : "2012-02-07 18:37:03 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166925636223504385",
  "geo" : { },
  "id_str" : "166953241383415808",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke ring up your council and get a bulky lift. You should get a number free a year.",
  "id" : 166953241383415808,
  "in_reply_to_status_id" : 166925636223504385,
  "created_at" : "2012-02-07 18:35:29 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166952309375516672",
  "text" : "Operation: Prove I Aint A Ginger - I had to shave it off after work. Was too itchy and patchy! I aint a ginger though.. NEVER!",
  "id" : 166952309375516672,
  "created_at" : "2012-02-07 18:31:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166948504927862784",
  "geo" : { },
  "id_str" : "166952105087729664",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe after that it has to be TBBT... Need to talk about it to someone! Oh and get watching Spartacus!",
  "id" : 166952105087729664,
  "in_reply_to_status_id" : 166948504927862784,
  "created_at" : "2012-02-07 18:30:58 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166948613031870466",
  "geo" : { },
  "id_str" : "166951956366110720",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg oh no.. I moved the other desk back to where mine was :)",
  "id" : 166951956366110720,
  "in_reply_to_status_id" : 166948613031870466,
  "created_at" : "2012-02-07 18:30:22 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166940093301530625",
  "text" : "Just moved desks.. And I actually mean I just moved my current desk to a new space...",
  "id" : 166940093301530625,
  "created_at" : "2012-02-07 17:43:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166878360423759873",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll that brownie was what can only be described as \"MOST. FUCKING. AWESOME. BUN. EVER\". Seriously... HA-MAZ-HING!!!! Thank you :D",
  "id" : 166878360423759873,
  "created_at" : "2012-02-07 13:37:56 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 4, 16 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166875941598019584",
  "text" : "And @stimpled0rf is done another man card. Only in the door less than 5mins.",
  "id" : 166875941598019584,
  "created_at" : "2012-02-07 13:28:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 12, 24 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 25, 37 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166865042313187328",
  "geo" : { },
  "id_str" : "166865260836429826",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @niall_adams @stimpled0rf Oh its okay.. Niall is just evil :D He comes across as nice but he really isn't :)",
  "id" : 166865260836429826,
  "in_reply_to_status_id" : 166865042313187328,
  "created_at" : "2012-02-07 12:45:53 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 12, 24 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 25, 37 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166862824017104896",
  "geo" : { },
  "id_str" : "166864035441147906",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @niall_adams @stimpled0rf he is not a very nice man Alana.",
  "id" : 166864035441147906,
  "in_reply_to_status_id" : 166862824017104896,
  "created_at" : "2012-02-07 12:41:00 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 12, 24 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anyexcuse",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166847208367460352",
  "geo" : { },
  "id_str" : "166847369881718784",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @stimpled0rf I am still gonna frisk him when he gets in :) #anyexcuse",
  "id" : 166847369881718784,
  "in_reply_to_status_id" : 166847208367460352,
  "created_at" : "2012-02-07 11:34:47 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 63, 75 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166846142569660416",
  "geo" : { },
  "id_str" : "166846678362628098",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Send away, please :D Haven't got them.. I'll frisk @stimpled0rf when he comes in :)",
  "id" : 166846678362628098,
  "in_reply_to_status_id" : 166846142569660416,
  "created_at" : "2012-02-07 11:32:02 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166844473471545344",
  "geo" : { },
  "id_str" : "166845462912040961",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Well done :D Keep at it etc... I am down a size as well but I got a shit lot more to do :)",
  "id" : 166845462912040961,
  "in_reply_to_status_id" : 166844473471545344,
  "created_at" : "2012-02-07 11:27:12 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166638701710028802",
  "geo" : { },
  "id_str" : "166639091436359682",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall shut it blondie.. Nothing wrong with being careful!!",
  "id" : 166639091436359682,
  "in_reply_to_status_id" : 166638701710028802,
  "created_at" : "2012-02-06 21:47:10 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Hurley",
      "screen_name" : "PapaHurley",
      "indices" : [ 3, 14 ],
      "id_str" : "19614568",
      "id" : 19614568
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 16, 22 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166631351519420416",
  "text" : "RT @PapaHurley: @swmcc Some very thick fog over Divis Mountain tonight but some oul doll infront was doin 2 mph all the way home. Just i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "166624315138256896",
    "geo" : { },
    "id_str" : "166630194327732224",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Some very thick fog over Divis Mountain tonight but some oul doll infront was doin 2 mph all the way home. Just in ffs.",
    "id" : 166630194327732224,
    "in_reply_to_status_id" : 166624315138256896,
    "created_at" : "2012-02-06 21:11:48 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Ciaran Hurley",
      "screen_name" : "PapaHurley",
      "protected" : false,
      "id_str" : "19614568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1782738363\/Screen_shot_2012-01-26_at_11.56.54_normal.png",
      "id" : 19614568,
      "verified" : false
    }
  },
  "id" : 166631351519420416,
  "created_at" : "2012-02-06 21:16:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166624315138256896",
  "text" : "Some very thick fog over Divis Mountain tonight. Which was nice considering a R driver was up my arse the whole way home. Fuckin idiot.",
  "id" : 166624315138256896,
  "created_at" : "2012-02-06 20:48:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166573919468400640",
  "text" : "Never agreed with anything that Ian Paisley ever said or stood for. But still an 85 year old man\/grandfather\/father.. Hope he gets well soon",
  "id" : 166573919468400640,
  "created_at" : "2012-02-06 17:28:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166522870003011584",
  "geo" : { },
  "id_str" : "166538429176352769",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll :D Best. Quote. Ever.",
  "id" : 166538429176352769,
  "in_reply_to_status_id" : 166522870003011584,
  "created_at" : "2012-02-06 15:07:10 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166512544989712386",
  "text" : "Nothing like your vm filling up to 100% in the middle of a data port... Yup...",
  "id" : 166512544989712386,
  "created_at" : "2012-02-06 13:24:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166495007501598721",
  "text" : "Funny.. Must be getting soft in my old age.. As I just issued a 'graceful' restart on apache.",
  "id" : 166495007501598721,
  "created_at" : "2012-02-06 12:14:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 13, 27 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166474948498563073",
  "geo" : { },
  "id_str" : "166479961073516544",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @berryblonde84 he lost another one as well... That's down two in a matter of minutes.. Not good.. Not good at all.",
  "id" : 166479961073516544,
  "in_reply_to_status_id" : 166474948498563073,
  "created_at" : "2012-02-06 11:14:50 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 11, 18 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166478552743686144",
  "text" : "\/me misses @srushe... Get well soon! :)",
  "id" : 166478552743686144,
  "created_at" : "2012-02-06 11:09:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 4, 16 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166474007862976514",
  "text" : "And @stimpled0rf kept his man card for all of 10seconds when I handed him back his full quota this morning. New record!",
  "id" : 166474007862976514,
  "created_at" : "2012-02-06 10:51:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166455308095455232",
  "text" : "Monday = crap... Monday + data port = ubber crap.... Ahh well best get on with it... First a cuppa :)",
  "id" : 166455308095455232,
  "created_at" : "2012-02-06 09:36:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 22, 35 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166266071853187072",
  "text" : "*Imaginary hat tip to @RickyHassard on recommending Rounders as a film. Excellent film.",
  "id" : 166266071853187072,
  "created_at" : "2012-02-05 21:04:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166263853808746496",
  "text" : "The level of racism against the Chinese on Top Gear is worrying. Funny as fuck but worrying.",
  "id" : 166263853808746496,
  "created_at" : "2012-02-05 20:56:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166261348366422016",
  "geo" : { },
  "id_str" : "166263418070904832",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Sam up for that :) Need a food name though.. Took a wee trip up the cave hill today. Getting ma training on :)",
  "id" : 166263418070904832,
  "in_reply_to_status_id" : 166261348366422016,
  "created_at" : "2012-02-05 20:54:22 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166244399955705857",
  "geo" : { },
  "id_str" : "166245551761924096",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll bake sales, enter competitions! Gotta get you out there... Not blowing sunshine up your ass. Your baking is amazing!",
  "id" : 166245551761924096,
  "in_reply_to_status_id" : 166244399955705857,
  "created_at" : "2012-02-05 19:43:22 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166244024552919041",
  "geo" : { },
  "id_str" : "166244269965844481",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll :) Baking goddess!!! Open a shop! :)",
  "id" : 166244269965844481,
  "in_reply_to_status_id" : 166244024552919041,
  "created_at" : "2012-02-05 19:38:17 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166244169252212737",
  "text" : "Gordon the gopher!!!!!!!!",
  "id" : 166244169252212737,
  "created_at" : "2012-02-05 19:37:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166242664692453377",
  "geo" : { },
  "id_str" : "166243826816663554",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll meant to say that it wouldn't be the same if it was raining on the strand. And as for baking goodness.... You is awesome :) :)",
  "id" : 166243826816663554,
  "in_reply_to_status_id" : 166242664692453377,
  "created_at" : "2012-02-05 19:36:31 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166240954771181568",
  "geo" : { },
  "id_str" : "166242273762357248",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll won't really the on the strand though....",
  "id" : 166242273762357248,
  "in_reply_to_status_id" : 166240954771181568,
  "created_at" : "2012-02-05 19:30:21 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166215652204490752",
  "text" : "Eugghh tomorrow is Monday. Fucking hate that when it happens. The diff on a Friday evening and a Sunday evening is getting starker.",
  "id" : 166215652204490752,
  "created_at" : "2012-02-05 17:44:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 1, 16 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166064415249149953",
  "text" : "\u201C@Georgina_Milne: @swmcc i could try to be more hardcore,but don't think its possible!\u201D Awesome :)",
  "id" : 166064415249149953,
  "created_at" : "2012-02-05 07:43:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165901784878026752",
  "geo" : { },
  "id_str" : "165903114292051968",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore was awesome I think. He kept on digging.",
  "id" : 165903114292051968,
  "in_reply_to_status_id" : 165901784878026752,
  "created_at" : "2012-02-04 21:02:39 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165901528648003585",
  "geo" : { },
  "id_str" : "165902206653042689",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa was brilliant :)",
  "id" : 165902206653042689,
  "in_reply_to_status_id" : 165901528648003585,
  "created_at" : "2012-02-04 20:59:03 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165901103693709312",
  "text" : "That last fellaon take me out was comedy gold",
  "id" : 165901103693709312,
  "created_at" : "2012-02-04 20:54:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165885985085857792",
  "geo" : { },
  "id_str" : "165888320944082944",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues well it's weird to see a new Spartacus. Should be good...",
  "id" : 165888320944082944,
  "in_reply_to_status_id" : 165885985085857792,
  "created_at" : "2012-02-04 20:03:52 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165885593082011649",
  "geo" : { },
  "id_str" : "165888140249276417",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne hardcore shiz!!!",
  "id" : 165888140249276417,
  "in_reply_to_status_id" : 165885593082011649,
  "created_at" : "2012-02-04 20:03:09 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "older",
      "indices" : [ 33, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165849711058763776",
  "geo" : { },
  "id_str" : "165877000060420096",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke acoustic coupler :) #older",
  "id" : 165877000060420096,
  "in_reply_to_status_id" : 165849711058763776,
  "created_at" : "2012-02-04 19:18:53 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165849297777213440",
  "geo" : { },
  "id_str" : "165876877750321152",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke that's freaking awesome. BT are a bit arsey with me during peak hours and weekends",
  "id" : 165876877750321152,
  "in_reply_to_status_id" : 165849297777213440,
  "created_at" : "2012-02-04 19:18:24 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165830234514538497",
  "geo" : { },
  "id_str" : "165831325725638657",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke I'd say that'll change in a few hours :) What's the FUP on Virgin? Anything between 12am and 6am?",
  "id" : 165831325725638657,
  "in_reply_to_status_id" : 165830234514538497,
  "created_at" : "2012-02-04 16:17:23 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165800370436706305",
  "geo" : { },
  "id_str" : "165828081033031681",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues You watching the new season of Spatacus? Only one episode in. Not too bad so far. Hopefully will be on par with Season 1.",
  "id" : 165828081033031681,
  "in_reply_to_status_id" : 165800370436706305,
  "created_at" : "2012-02-04 16:04:30 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165800370436706305",
  "geo" : { },
  "id_str" : "165827888854212609",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues I was on 512Kb since 2002 (dial up prior to that). Decided to go for Infinity in August. Tis great :) How is @srsuhe?",
  "id" : 165827888854212609,
  "in_reply_to_status_id" : 165800370436706305,
  "created_at" : "2012-02-04 16:03:44 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165790355751575552",
  "geo" : { },
  "id_str" : "165827576571510786",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke 100!! How fast do you need to get your email? :D",
  "id" : 165827576571510786,
  "in_reply_to_status_id" : 165790355751575552,
  "created_at" : "2012-02-04 16:02:29 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165808950258827264",
  "geo" : { },
  "id_str" : "165809635440332802",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf am heading to the dump now. Having a big clear out. If I see any facility dicks I'll beat the living fuck out if them!",
  "id" : 165809635440332802,
  "in_reply_to_status_id" : 165808950258827264,
  "created_at" : "2012-02-04 14:51:12 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165788664432037888",
  "text" : "4.3MB\/s downloads... Gotta fucking love it. No way I could go back to 512Kb...",
  "id" : 165788664432037888,
  "created_at" : "2012-02-04 13:27:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165785549246955520",
  "text" : "Latest episode of Star Wars: The Clone Wars and Big Bang Theory downloaded. Now time to watch with some pancakes and a cuppa tea :D",
  "id" : 165785549246955520,
  "created_at" : "2012-02-04 13:15:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 28, 40 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165785387212619776",
  "text" : "Wondering what girly things @stimpled0rf is doing at the mo......",
  "id" : 165785387212619776,
  "created_at" : "2012-02-04 13:14:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165750756127944705",
  "geo" : { },
  "id_str" : "165784202434973696",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight car park on the boucher road... I've spotted this car doing this several times now.... Idiots.",
  "id" : 165784202434973696,
  "in_reply_to_status_id" : 165750756127944705,
  "created_at" : "2012-02-04 13:10:08 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/165744849662910464\/photo\/1",
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/2yCF1zT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkzYEAfCIAEtO4w.jpg",
      "id_str" : "165744849667104769",
      "id" : 165744849667104769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkzYEAfCIAEtO4w.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/2yCF1zT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165744849662910464",
  "text" : "Am pretty sure it is now legal to kill this wanker? http:\/\/t.co\/2yCF1zT",
  "id" : 165744849662910464,
  "created_at" : "2012-02-04 10:33:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rt Hon Jim Hacker MP",
      "screen_name" : "JimHacker",
      "indices" : [ 3, 13 ],
      "id_str" : "125027878",
      "id" : 125027878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165734876207788032",
  "text" : "RT @JimHacker: 30 years ago simply being discovered having an affair meant the end of a Cabinet Secretary's career. No one gave a stuff  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165520693872689152",
    "text" : "30 years ago simply being discovered having an affair meant the end of a Cabinet Secretary's career. No one gave a stuff how fast one drove!",
    "id" : 165520693872689152,
    "created_at" : "2012-02-03 19:43:03 +0000",
    "user" : {
      "name" : "Rt Hon Jim Hacker MP",
      "screen_name" : "JimHacker",
      "protected" : false,
      "id_str" : "125027878",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1330196420\/index_normal.jpg",
      "id" : 125027878,
      "verified" : false
    }
  },
  "id" : 165734876207788032,
  "created_at" : "2012-02-04 09:54:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165500122954870784",
  "text" : "School boy error. Am on the Tates Road aka car park right now. Meh. Abba came on the radio and I drifted off.",
  "id" : 165500122954870784,
  "created_at" : "2012-02-03 18:21:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165144978467725313",
  "geo" : { },
  "id_str" : "165148204768313345",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams got the English one on twitter yet???",
  "id" : 165148204768313345,
  "in_reply_to_status_id" : 165144978467725313,
  "created_at" : "2012-02-02 19:02:54 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 26, 40 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165109884470300673",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf is a star... @peter_omalley sucks.",
  "id" : 165109884470300673,
  "created_at" : "2012-02-02 16:30:38 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165097797765443585",
  "text" : "Working a half day with the off half being in the morning... It is a load of dick.. Seriously.. Big load of dick!",
  "id" : 165097797765443585,
  "created_at" : "2012-02-02 15:42:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 30, 43 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164859850365480960",
  "geo" : { },
  "id_str" : "164862858872631297",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley @rickyhassard chicken",
  "id" : 164862858872631297,
  "in_reply_to_status_id" : 164859850365480960,
  "created_at" : "2012-02-02 00:09:03 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 30, 43 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164856146555961344",
  "geo" : { },
  "id_str" : "164858634281566208",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley @rickyhassard We demand pic of you in your PJ's.. Not for perv reasons - just for the sillyness of it :)",
  "id" : 164858634281566208,
  "in_reply_to_status_id" : 164856146555961344,
  "created_at" : "2012-02-01 23:52:15 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 1, 13 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 45, 51 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 53, 65 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164822909053960192",
  "text" : "\u201C@niall_adams: One of my proudest moments - \u201C@swmcc: @niall_adams could be worse.. Could be for 3:30am and says \"Niall says fuck you!\" :)\u201D\u201D",
  "id" : 164822909053960192,
  "created_at" : "2012-02-01 21:30:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Tracy Adams",
      "screen_name" : "tracy2710",
      "indices" : [ 69, 79 ],
      "id_str" : "241879307",
      "id" : 241879307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164817847284023297",
  "geo" : { },
  "id_str" : "164822874325135360",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams even more proud than when you got engaged to the lovely @tracy2710 - huh? You heartless bastard!!",
  "id" : 164822874325135360,
  "in_reply_to_status_id" : 164817847284023297,
  "created_at" : "2012-02-01 21:30:10 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164817683269955584",
  "geo" : { },
  "id_str" : "164821479039569920",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams grrrrrrr",
  "id" : 164821479039569920,
  "in_reply_to_status_id" : 164817683269955584,
  "created_at" : "2012-02-01 21:24:37 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164817102925082626",
  "geo" : { },
  "id_str" : "164817433658527744",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams could be worse.. Could be for 3:30am and says \"Niall says fuck you!\" :)",
  "id" : 164817433658527744,
  "in_reply_to_status_id" : 164817102925082626,
  "created_at" : "2012-02-01 21:08:33 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164794522088386560",
  "geo" : { },
  "id_str" : "164795504771862529",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa ignore unless you want it to inspect your system - but I can see no reason for it to unless you are signing up for a beta test.",
  "id" : 164795504771862529,
  "in_reply_to_status_id" : 164794522088386560,
  "created_at" : "2012-02-01 19:41:24 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 14, 29 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164766533241933824",
  "geo" : { },
  "id_str" : "164795197576847360",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @georgina_milne good luck Steve :) I gotta feeling she will destroy you!",
  "id" : 164795197576847360,
  "in_reply_to_status_id" : 164766533241933824,
  "created_at" : "2012-02-01 19:40:11 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 17, 29 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164700092731899904",
  "text" : "Just fucked over @stimpled0rf - felt awesome to be fair :)",
  "id" : 164700092731899904,
  "created_at" : "2012-02-01 13:22:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 1, 13 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 54, 60 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164644328310980608",
  "text" : "\u201C@stimpled0rf: Can't beat getting wolf whistled at by @swmcc whilst strolling through Hillsborough to start the morning.\u201D",
  "id" : 164644328310980608,
  "created_at" : "2012-02-01 09:40:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164619175887769600",
  "text" : "Thank fuck Jan is over... Hopefully Feb will be nicer... \/me looks outside.... Fuck :(",
  "id" : 164619175887769600,
  "created_at" : "2012-02-01 08:00:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]