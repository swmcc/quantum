Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241639481147535360",
  "geo" : { },
  "id_str" : "241657580072611840",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke euggggghhhhhh.....",
  "id" : 241657580072611840,
  "in_reply_to_status_id" : 241639481147535360,
  "created_at" : "2012-08-31 22:03:51 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241591974413619202",
  "geo" : { },
  "id_str" : "241654862700478466",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull what!!!! FFS!!! Stay safe!!! I dunno.....",
  "id" : 241654862700478466,
  "in_reply_to_status_id" : 241591974413619202,
  "created_at" : "2012-08-31 21:53:03 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/241612511084957696\/photo\/1",
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/6if9CuGq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1phTHjCUAAQaaQ.jpg",
      "id_str" : "241612511089152000",
      "id" : 241612511089152000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1phTHjCUAAQaaQ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/6if9CuGq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241612511084957696",
  "text" : "There is also a lamp shade in here that looks like a giant side ways clitirous :) http:\/\/t.co\/6if9CuGq",
  "id" : 241612511084957696,
  "created_at" : "2012-08-31 19:04:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 30, 46 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 59, 73 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241606127169716224",
  "text" : "Dear Twitter a man (me) and a @michaelnsimpson destroyed a @peter_omalley today! His title of supreme fat bastard is now gone!",
  "id" : 241606127169716224,
  "created_at" : "2012-08-31 18:39:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 60, 76 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241548759593545728",
  "text" : "I made the best cup of coffee in the world ever. Fact.....  @michaelnsimpson said \"I want that in my mouth, now\". Think it was the coffee",
  "id" : 241548759593545728,
  "created_at" : "2012-08-31 14:51:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241513297487228929",
  "text" : "Awesome comment on a trac that has been bombing about between two people... Last comment: \"maybe now...if it's not I will strangle myself\"",
  "id" : 241513297487228929,
  "created_at" : "2012-08-31 12:30:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 54, 66 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241491254301573120",
  "text" : "I hate ordering food for picky fuckers.. Never again! @ryancunning @michalensimpson and that weird hippy dude.",
  "id" : 241491254301573120,
  "created_at" : "2012-08-31 11:02:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241466144031133696",
  "text" : "Doing an \"fgrep -r 'TODO:' in a project to see all the 'little' 'nice' things you wanted  to do...",
  "id" : 241466144031133696,
  "created_at" : "2012-08-31 09:23:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Cherry",
      "screen_name" : "_LisaCherry",
      "indices" : [ 0, 12 ],
      "id_str" : "147521442",
      "id" : 147521442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241444956223442945",
  "geo" : { },
  "id_str" : "241452208074391552",
  "in_reply_to_user_id" : 147521442,
  "text" : "@_LisaCherry do you find twitter or facebook better for your stuff?",
  "id" : 241452208074391552,
  "in_reply_to_status_id" : 241444956223442945,
  "created_at" : "2012-08-31 08:27:47 +0000",
  "in_reply_to_screen_name" : "_LisaCherry",
  "in_reply_to_user_id_str" : "147521442",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241451733115621377",
  "geo" : { },
  "id_str" : "241451928423383040",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson and the fact it is a chicken burger and not red meat. Chuck will not be happy!",
  "id" : 241451928423383040,
  "in_reply_to_status_id" : 241451733115621377,
  "created_at" : "2012-08-31 08:26:40 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 7, 21 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 33, 49 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241450018463162368",
  "text" : "Me and @peter_omalley are taking @michaelnsimpson to see the expendables 2 later and he says \"How do I get excited for this film?\"",
  "id" : 241450018463162368,
  "created_at" : "2012-08-31 08:19:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 22, 38 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241187332991111169",
  "text" : "During a coffee break @michaelnsimpson said the following to me, I kid you not \"I am aware of Chuck Norris and who he is\".",
  "id" : 241187332991111169,
  "created_at" : "2012-08-30 14:55:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 72, 78 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241184568839921664",
  "text" : "FYI: The code had two table rows called the same thing 'ct_row' - extra @swmcc points if you can guess what I did :)",
  "id" : 241184568839921664,
  "created_at" : "2012-08-30 14:44:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241184388392579072",
  "text" : "I've been at work for three years and I just used my first curse word in our source code :) Wonder why it has taken me this long? :)",
  "id" : 241184388392579072,
  "created_at" : "2012-08-30 14:43:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241176487728914433",
  "text" : "It is beyond me how people can use windows on a daily basis.. Luckily work gives me a lovely mac.",
  "id" : 241176487728914433,
  "created_at" : "2012-08-30 14:12:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Postini",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "emailsecurity",
      "indices" : [ 84, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/LOfvjAY4",
      "expanded_url" : "http:\/\/fb.me\/1pD4lwLMv",
      "display_url" : "fb.me\/1pD4lwLMv"
    } ]
  },
  "geo" : { },
  "id_str" : "241174210175700992",
  "text" : "RT @maildistiller: Here at Maildistiller we've had our say on the #Postini debacle! #emailsecurity http:\/\/t.co\/LOfvjAY4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Postini",
        "indices" : [ 47, 55 ]
      }, {
        "text" : "emailsecurity",
        "indices" : [ 65, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/LOfvjAY4",
        "expanded_url" : "http:\/\/fb.me\/1pD4lwLMv",
        "display_url" : "fb.me\/1pD4lwLMv"
      } ]
    },
    "geo" : { },
    "id_str" : "241170143781203969",
    "text" : "Here at Maildistiller we've had our say on the #Postini debacle! #emailsecurity http:\/\/t.co\/LOfvjAY4",
    "id" : 241170143781203969,
    "created_at" : "2012-08-30 13:46:57 +0000",
    "user" : {
      "name" : "ProofpointEssentials",
      "screen_name" : "Proofpoint_SMB",
      "protected" : false,
      "id_str" : "152962481",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3754782848\/438736811a4e19f957757c58e218bd63_normal.png",
      "id" : 152962481,
      "verified" : false
    }
  },
  "id" : 241174210175700992,
  "created_at" : "2012-08-30 14:03:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 3, 16 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241171848589611008",
  "text" : "RT @marcus_r1975: @swmcc I've been using IE for the last few days.  It feels like I'm back at School and I've been made to do PE in my p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "241164880298786816",
    "geo" : { },
    "id_str" : "241168692170346496",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc I've been using IE for the last few days.  It feels like I'm back at School and I've been made to do PE in my pants. So embarrassing!",
    "id" : 241168692170346496,
    "in_reply_to_status_id" : 241164880298786816,
    "created_at" : "2012-08-30 13:41:11 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "protected" : true,
      "id_str" : "445071004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227024744\/image_normal.jpg",
      "id" : 445071004,
      "verified" : false
    }
  },
  "id" : 241171848589611008,
  "created_at" : "2012-08-30 13:53:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Internet Explorer 9",
      "screen_name" : "IE9Brasil",
      "indices" : [ 29, 39 ],
      "id_str" : "181294156",
      "id" : 181294156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241164880298786816",
  "text" : "See those cool adverts about @IE9Brasil being cool... It is a big pile of steaming wank! Dress it up how you want. Wank it will ever be!",
  "id" : 241164880298786816,
  "created_at" : "2012-08-30 13:26:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241112162486067200",
  "geo" : { },
  "id_str" : "241122305986662400",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @rickyhassard I just lifted a man card off your desk.",
  "id" : 241122305986662400,
  "in_reply_to_status_id" : 241112162486067200,
  "created_at" : "2012-08-30 10:36:52 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal",
      "screen_name" : "mikeal",
      "indices" : [ 0, 7 ],
      "id_str" : "668423",
      "id" : 668423
    }, {
      "name" : "Node Dublin",
      "screen_name" : "NodeDublin",
      "indices" : [ 75, 86 ],
      "id_str" : "614155381",
      "id" : 614155381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241097752363298816",
  "in_reply_to_user_id" : 668423,
  "text" : "@mikeal Enjoy yourself in our fine country :D Wish I could have made it to @NodeDublin",
  "id" : 241097752363298816,
  "created_at" : "2012-08-30 08:59:18 +0000",
  "in_reply_to_screen_name" : "mikeal",
  "in_reply_to_user_id_str" : "668423",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241096981714444289",
  "text" : "Or I am going to put a load of petrol around me - light myself on fire just to fuck people up :D",
  "id" : 241096981714444289,
  "created_at" : "2012-08-30 08:56:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241096809328541697",
  "text" : "I am in that film that has Clooney in it and there is this big fuck off wave that I am just ignoring but I know it is going to crush me!",
  "id" : 241096809328541697,
  "created_at" : "2012-08-30 08:55:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/pinterest.com\" rel=\"nofollow\"\u003EPinterest\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/6Y3RecNq",
      "expanded_url" : "http:\/\/pinterest.com\/pin\/139259813448625708\/",
      "display_url" : "pinterest.com\/pin\/1392598134\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240968159375548416",
  "text" : "This is so interesting! Excited to do more! http:\/\/t.co\/6Y3RecNq",
  "id" : 240968159375548416,
  "created_at" : "2012-08-30 00:24:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240915290051997696",
  "text" : "Sir Patrick Stewart really is a gentleman.",
  "id" : 240915290051997696,
  "created_at" : "2012-08-29 20:54:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240871628253319168",
  "geo" : { },
  "id_str" : "240874341611479040",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson it'll be like a fish watching tv. Just won't comprehend the sheer awesomeness of what he is watching.",
  "id" : 240874341611479040,
  "in_reply_to_status_id" : 240871628253319168,
  "created_at" : "2012-08-29 18:11:32 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "indices" : [ 3, 19 ],
      "id_str" : "402824193",
      "id" : 402824193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "node",
      "indices" : [ 65, 70 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "perl",
      "indices" : [ 79, 84 ]
    }, {
      "text" : "developer",
      "indices" : [ 85, 95 ]
    }, {
      "text" : "coding",
      "indices" : [ 96, 103 ]
    }, {
      "text" : "programmer",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/pUpy6O4v",
      "expanded_url" : "http:\/\/bit.ly\/TtL0V6",
      "display_url" : "bit.ly\/TtL0V6"
    } ]
  },
  "geo" : { },
  "id_str" : "240865830156509185",
  "text" : "RT @NodeJsCommunity: Embed Perl for Node.js http:\/\/t.co\/pUpy6O4v #node #nodejs #perl #developer #coding #programmer ** VPS -&gt; http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "node",
        "indices" : [ 44, 49 ]
      }, {
        "text" : "nodejs",
        "indices" : [ 50, 57 ]
      }, {
        "text" : "perl",
        "indices" : [ 58, 63 ]
      }, {
        "text" : "developer",
        "indices" : [ 64, 74 ]
      }, {
        "text" : "coding",
        "indices" : [ 75, 82 ]
      }, {
        "text" : "programmer",
        "indices" : [ 83, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/pUpy6O4v",
        "expanded_url" : "http:\/\/bit.ly\/TtL0V6",
        "display_url" : "bit.ly\/TtL0V6"
      }, {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/Vy90P7mX",
        "expanded_url" : "http:\/\/bit.ly\/Ov5pXK",
        "display_url" : "bit.ly\/Ov5pXK"
      } ]
    },
    "geo" : { },
    "id_str" : "240860497992364032",
    "text" : "Embed Perl for Node.js http:\/\/t.co\/pUpy6O4v #node #nodejs #perl #developer #coding #programmer ** VPS -&gt; http:\/\/... http:\/\/t.co\/Vy90P7mX",
    "id" : 240860497992364032,
    "created_at" : "2012-08-29 17:16:32 +0000",
    "user" : {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "protected" : false,
      "id_str" : "402824193",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1627924583\/njscomm_normal.jpg",
      "id" : 402824193,
      "verified" : false
    }
  },
  "id" : 240865830156509185,
  "created_at" : "2012-08-29 17:37:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 12, 25 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 37, 50 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240838021744828416",
  "text" : "Small world @nicholabates works with @Paul_Moffett - hmmm - small world indeed.",
  "id" : 240838021744828416,
  "created_at" : "2012-08-29 15:47:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fanboy",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240837762742366211",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates I just started to follow you. You are now one of my fav tweet type people. #fanboy",
  "id" : 240837762742366211,
  "created_at" : "2012-08-29 15:46:11 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 1, 14 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "culturetech",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240837362094059520",
  "text" : "\u201C@nicholabates: Apologies for the sweary presentation, I tried to behave, but then I thought Fuck It - Derry can handle it ;-) #culturetech\u201D",
  "id" : 240837362094059520,
  "created_at" : "2012-08-29 15:44:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 39, 52 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "famouslastwords",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240806755225960448",
  "text" : "Weird day. Can't get much weirder than @RickyHassard quoting the bodyguard over and over then singing Paul Simon to me... #famouslastwords",
  "id" : 240806755225960448,
  "created_at" : "2012-08-29 13:42:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "staythefuckout",
      "indices" : [ 120, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240802541972107264",
  "text" : "Nothing quite annoys me as half the office following me into the kitchen when I want to make a cup of coffee on my own. #staythefuckout :)",
  "id" : 240802541972107264,
  "created_at" : "2012-08-29 13:26:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240793183108345857",
  "text" : "Today is sucking major dick. But still - it is a new afternoon.",
  "id" : 240793183108345857,
  "created_at" : "2012-08-29 12:49:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ihateyou",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240745277978447872",
  "geo" : { },
  "id_str" : "240745470706741248",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu Ha remember me???? I am your brother!!!!! Have I even seen you since you were back? #ihateyou",
  "id" : 240745470706741248,
  "in_reply_to_status_id" : 240745277978447872,
  "created_at" : "2012-08-29 09:39:27 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 52, 60 ],
      "id_str" : "79820731",
      "id" : 79820731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240699330166669312",
  "text" : "I dreamt last night I installed a new git server in @tascomi. Think its because I am merging branches today but still - weird and sad :(",
  "id" : 240699330166669312,
  "created_at" : "2012-08-29 06:36:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crumlin",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "glenavy",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240520470636662784",
  "text" : "Twitter people is the hannastown rd still closed? #crumlin #glenavy",
  "id" : 240520470636662784,
  "created_at" : "2012-08-28 18:45:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240041559893106690",
  "text" : "I am Ron Swanson",
  "id" : 240041559893106690,
  "created_at" : "2012-08-27 11:02:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239800036509245441",
  "geo" : { },
  "id_str" : "239815891464896512",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams \/me dances",
  "id" : 239815891464896512,
  "in_reply_to_status_id" : 239800036509245441,
  "created_at" : "2012-08-26 20:05:38 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 30, 43 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239786952205950976",
  "geo" : { },
  "id_str" : "239799474678022144",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams good man. Invite @RickyHassard round.",
  "id" : 239799474678022144,
  "in_reply_to_status_id" : 239786952205950976,
  "created_at" : "2012-08-26 19:00:24 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239487072321298433",
  "text" : "RIP Neil Armstrong :(",
  "id" : 239487072321298433,
  "created_at" : "2012-08-25 22:19:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 19, 31 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 32, 45 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 72, 78 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238940313366970368",
  "text" : "\u201C@michaelnsimpson: @niall_adams @RickyHassard  I can't decide if i like @swmcc in gorilla or sloth form.\u201D",
  "id" : 238940313366970368,
  "created_at" : "2012-08-24 10:06:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238939000721780737",
  "geo" : { },
  "id_str" : "238939224274001920",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams best. tweet. ever.",
  "id" : 238939224274001920,
  "in_reply_to_status_id" : 238939000721780737,
  "created_at" : "2012-08-24 10:02:05 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 6, 21 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238916917014958082",
  "text" : "I see @Georgina_Milne is tweeting more this weather. This pleases me greatly :D",
  "id" : 238916917014958082,
  "created_at" : "2012-08-24 08:33:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/238906420647575552\/photo\/1",
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/XgfMH7n3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1DEH7GCQAAEleU.jpg",
      "id_str" : "238906420651769856",
      "id" : 238906420651769856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1DEH7GCQAAEleU.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/XgfMH7n3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238906420647575552",
  "text" : "And I didn't :) I was in. http:\/\/t.co\/XgfMH7n3",
  "id" : 238906420647575552,
  "created_at" : "2012-08-24 07:51:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238729918253498368",
  "geo" : { },
  "id_str" : "238737562263498752",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson yes I will after last weeks fuck up. A week since we last seen each other.. Running hug in order?",
  "id" : 238737562263498752,
  "in_reply_to_status_id" : 238729918253498368,
  "created_at" : "2012-08-23 20:40:45 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238646151644069888",
  "geo" : { },
  "id_str" : "238666584489607168",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson you fucking disgust me..",
  "id" : 238666584489607168,
  "in_reply_to_status_id" : 238646151644069888,
  "created_at" : "2012-08-23 15:58:42 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 26, 39 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238603336817987584",
  "text" : "Best. Sandwich. Ever. \/cc @RickyHassard",
  "id" : 238603336817987584,
  "created_at" : "2012-08-23 11:47:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lough Shore",
      "screen_name" : "loughshore",
      "indices" : [ 3, 14 ],
      "id_str" : "215992556",
      "id" : 215992556
    }, {
      "name" : "The Shore Film",
      "screen_name" : "theshorefilm",
      "indices" : [ 40, 53 ],
      "id_str" : "202819500",
      "id" : 202819500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/nMGeJvtQ",
      "expanded_url" : "http:\/\/bit.ly\/NGV6oC",
      "display_url" : "bit.ly\/NGV6oC"
    } ]
  },
  "geo" : { },
  "id_str" : "238567935705219072",
  "text" : "RT @loughshore: The Oscar-winning short @theshorefilm premieres tonight on RT\u00C9 One at 10.15 pm http:\/\/t.co\/nMGeJvtQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Shore Film",
        "screen_name" : "theshorefilm",
        "indices" : [ 24, 37 ],
        "id_str" : "202819500",
        "id" : 202819500
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/nMGeJvtQ",
        "expanded_url" : "http:\/\/bit.ly\/NGV6oC",
        "display_url" : "bit.ly\/NGV6oC"
      } ]
    },
    "geo" : { },
    "id_str" : "238560623611502592",
    "text" : "The Oscar-winning short @theshorefilm premieres tonight on RT\u00C9 One at 10.15 pm http:\/\/t.co\/nMGeJvtQ",
    "id" : 238560623611502592,
    "created_at" : "2012-08-23 08:57:39 +0000",
    "user" : {
      "name" : "Lough Shore",
      "screen_name" : "loughshore",
      "protected" : false,
      "id_str" : "215992556",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2289162078\/tfmy6pbzxb24ue7094hz_normal.jpeg",
      "id" : 215992556,
      "verified" : false
    }
  },
  "id" : 238567935705219072,
  "created_at" : "2012-08-23 09:26:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairplaytohimisay",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238545194323165184",
  "text" : "Prince Harry naked in Las Vegas... There isn't one of you fuckers who wouldn't do the same thing if given the chance! :) #fairplaytohimisay",
  "id" : 238545194323165184,
  "created_at" : "2012-08-23 07:56:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/IWCmuUwz",
      "expanded_url" : "http:\/\/i.imgur.com\/7k0wy.jpg",
      "display_url" : "i.imgur.com\/7k0wy.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "238356634819244032",
  "text" : "This is the cutest thing ever.... http:\/\/t.co\/IWCmuUwz",
  "id" : 238356634819244032,
  "created_at" : "2012-08-22 19:27:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238294258854006786",
  "geo" : { },
  "id_str" : "238356145931161600",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I love this. Make me into a sloth!!!",
  "id" : 238356145931161600,
  "in_reply_to_status_id" : 238294258854006786,
  "created_at" : "2012-08-22 19:25:08 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238356040796733441",
  "text" : "OH: \"I left the coke in the car..... Is this what is called an 'EPIC FAIL'?\" - \"No - just fucking stupid!\".",
  "id" : 238356040796733441,
  "created_at" : "2012-08-22 19:24:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 10, 23 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238216302504837120",
  "text" : "Peep talk @RickyHassard style \"I need to man up.\" \"Yes you do!\" - excellent :D",
  "id" : 238216302504837120,
  "created_at" : "2012-08-22 10:09:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 3, 12 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/qamrMppE",
      "expanded_url" : "http:\/\/onion.com\/PzeP5T",
      "display_url" : "onion.com\/PzeP5T"
    } ]
  },
  "geo" : { },
  "id_str" : "237962930300260352",
  "text" : "RT @TheOnion: Pregnant Woman Relieved To Learn Her Rape Was Illegitimate http:\/\/t.co\/qamrMppE",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/qamrMppE",
        "expanded_url" : "http:\/\/onion.com\/PzeP5T",
        "display_url" : "onion.com\/PzeP5T"
      } ]
    },
    "geo" : { },
    "id_str" : "237692815839223808",
    "text" : "Pregnant Woman Relieved To Learn Her Rape Was Illegitimate http:\/\/t.co\/qamrMppE",
    "id" : 237692815839223808,
    "created_at" : "2012-08-20 23:29:18 +0000",
    "user" : {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "protected" : false,
      "id_str" : "14075928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3654358881\/476bd54bd9c2bc0f9a38b4e097ce6af5_normal.jpeg",
      "id" : 14075928,
      "verified" : true
    }
  },
  "id" : 237962930300260352,
  "created_at" : "2012-08-21 17:22:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "disgracetomygender",
      "indices" : [ 115, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237662769460154368",
  "geo" : { },
  "id_str" : "237962529240907776",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop come on!! you know it's women's fault for going out of the house and wearing skirts above the ankle. #disgracetomygender",
  "id" : 237962529240907776,
  "in_reply_to_status_id" : 237662769460154368,
  "created_at" : "2012-08-21 17:21:02 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 7, 22 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wantmyteabuddyback",
      "indices" : [ 23, 42 ]
    }, {
      "text" : "promance",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237274521604874240",
  "text" : "I miss @annette_mccull #wantmyteabuddyback #promance",
  "id" : 237274521604874240,
  "created_at" : "2012-08-19 19:47:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsonlyabrothercansaytoyou",
      "indices" : [ 106, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237273602926452736",
  "text" : "OH: \"Did you have the same thing as Karen last night and if you did - do you have a dose of the shites?\"' #thingsonlyabrothercansaytoyou",
  "id" : 237273602926452736,
  "created_at" : "2012-08-19 19:43:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236891919093993472",
  "geo" : { },
  "id_str" : "236919543149252608",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr name and shame.. If someone fucks up my steak they better best run... Fuck sake - am now horny for steak...",
  "id" : 236919543149252608,
  "in_reply_to_status_id" : 236891919093993472,
  "created_at" : "2012-08-18 20:16:35 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236766130251919360",
  "text" : "My parents are married 42 years today....",
  "id" : 236766130251919360,
  "created_at" : "2012-08-18 10:06:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236374345818198016",
  "geo" : { },
  "id_str" : "236382336281890816",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit I know it is not good.... These last three\/four weeks have not been good for the twitter PR machine.",
  "id" : 236382336281890816,
  "in_reply_to_status_id" : 236374345818198016,
  "created_at" : "2012-08-17 08:41:55 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236376595538010113",
  "text" : "And I now know Newtownards has a cinema!!!!",
  "id" : 236376595538010113,
  "created_at" : "2012-08-17 08:19:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236372540447158274",
  "geo" : { },
  "id_str" : "236372922581794816",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson actually your meeting was for 10. WTF you doing leaving at 8:50am to get to Antrim from Hillsborough!",
  "id" : 236372922581794816,
  "in_reply_to_status_id" : 236372540447158274,
  "created_at" : "2012-08-17 08:04:30 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236372540447158274",
  "geo" : { },
  "id_str" : "236372652388921344",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I fail...but you make stupid meeting times for a Friday morning! I blame you!",
  "id" : 236372652388921344,
  "in_reply_to_status_id" : 236372540447158274,
  "created_at" : "2012-08-17 08:03:26 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236372284749791232",
  "text" : "It is Friday - I can't hear out of my left ear. In other news - I got shit loads done this week... Now to end off on a good note :D",
  "id" : 236372284749791232,
  "created_at" : "2012-08-17 08:01:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236230511222198274",
  "geo" : { },
  "id_str" : "236230831088205826",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa DUUUUUUUDDDDE",
  "id" : 236230831088205826,
  "in_reply_to_status_id" : 236230511222198274,
  "created_at" : "2012-08-16 22:39:53 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236228892984213506",
  "text" : "Would love to go to nodedublin - but it at over \u00A3200 a day its not worth it personally. Can think of better things to spend that on :)",
  "id" : 236228892984213506,
  "created_at" : "2012-08-16 22:32:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 56, 69 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 70, 84 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 85, 93 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 94, 110 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236219324296220674",
  "text" : "Tomorrow I am only going to talk like Clubber Lang! \/cc @RickyHassard @peter_omalley @HaVoCT5 @michaelnsimpson",
  "id" : 236219324296220674,
  "created_at" : "2012-08-16 21:54:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236212587119902720",
  "geo" : { },
  "id_str" : "236217221070848000",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley man card down.",
  "id" : 236217221070848000,
  "in_reply_to_status_id" : 236212587119902720,
  "created_at" : "2012-08-16 21:45:48 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/236178388606414848\/photo\/1",
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/FYbFQ9g6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0cS_jzCcAA_jKP.jpg",
      "id_str" : "236178388610609152",
      "id" : 236178388610609152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0cS_jzCcAA_jKP.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/FYbFQ9g6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236178388606414848",
  "text" : "I just need to learn Japanese then...... http:\/\/t.co\/FYbFQ9g6",
  "id" : 236178388606414848,
  "created_at" : "2012-08-16 19:11:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "igrewupinniicanjokeaboutterror",
      "indices" : [ 108, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236119880301154304",
  "text" : "That feeling when you find 1 bug - only to have 3 more in its place. Like terrorist cells only more sneaky! #igrewupinniicanjokeaboutterror",
  "id" : 236119880301154304,
  "created_at" : "2012-08-16 15:19:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/ehDdW1gd",
      "expanded_url" : "http:\/\/instagr.am\/p\/OYgk94hX8S\/",
      "display_url" : "instagr.am\/p\/OYgk94hX8S\/"
    } ]
  },
  "geo" : { },
  "id_str" : "236022809413963776",
  "text" : "New Mug http:\/\/t.co\/ehDdW1gd",
  "id" : 236022809413963776,
  "created_at" : "2012-08-16 08:53:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 28, 35 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236022040631578624",
  "text" : "I have such a geek crush on @github at the minute - it is rather pathetic... Anyway back to the day job :D",
  "id" : 236022040631578624,
  "created_at" : "2012-08-16 08:50:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235999951363121152",
  "geo" : { },
  "id_str" : "236021182099496962",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ Enjoy :D",
  "id" : 236021182099496962,
  "in_reply_to_status_id" : 235999951363121152,
  "created_at" : "2012-08-16 08:46:49 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235848217013657600",
  "geo" : { },
  "id_str" : "235848941797769218",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley yup :(",
  "id" : 235848941797769218,
  "in_reply_to_status_id" : 235848217013657600,
  "created_at" : "2012-08-15 21:22:24 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/n0QPLFFg",
      "expanded_url" : "http:\/\/blackstar.co.uk\/about-magento-demo-store",
      "display_url" : "blackstar.co.uk\/about-magento-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235843539802677249",
  "text" : "sites I used to work for (which in its day was very good) at least get the about us working FFS - http:\/\/t.co\/n0QPLFFg",
  "id" : 235843539802677249,
  "created_at" : "2012-08-15 21:00:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235843324420956160",
  "text" : "I am insulting, crude and quite immature on twitter. But I do try and show some class.. But please - if you are going to revive one of the",
  "id" : 235843324420956160,
  "created_at" : "2012-08-15 21:00:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235842290755702784",
  "text" : "Say what you want about the people that changed blackstar to sendit - but at least they weren't this fucking dumb..",
  "id" : 235842290755702784,
  "created_at" : "2012-08-15 20:55:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/iKgf3b6d",
      "expanded_url" : "http:\/\/www.blackstar.co.uk",
      "display_url" : "blackstar.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "235842014636298240",
  "text" : "then the geniuses let someone have http:\/\/t.co\/iKgf3b6d - and let them put what is possibly a site from 1997 on it!",
  "id" : 235842014636298240,
  "created_at" : "2012-08-15 20:54:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/28xLcPx9",
      "expanded_url" : "http:\/\/BlackStar.co.uk",
      "display_url" : "BlackStar.co.uk"
    }, {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/93OgjSPo",
      "expanded_url" : "http:\/\/Sendit.com",
      "display_url" : "Sendit.com"
    } ]
  },
  "geo" : { },
  "id_str" : "235841857718996993",
  "text" : "I used to work for http:\/\/t.co\/28xLcPx9 - they then changed it to http:\/\/t.co\/93OgjSPo - then sold it to a white label...",
  "id" : 235841857718996993,
  "created_at" : "2012-08-15 20:54:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 17, 27 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/235841169068814337\/photo\/1",
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/7MfzN7We",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0XgSzJCcAA8xPo.jpg",
      "id_str" : "235841169077202944",
      "id" : 235841169077202944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0XgSzJCcAA8xPo.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/7MfzN7We"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235841169068814337",
  "text" : "Sibling love \/cc @Xtinamccu http:\/\/t.co\/7MfzN7We",
  "id" : 235841169068814337,
  "created_at" : "2012-08-15 20:51:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235757777484648448",
  "geo" : { },
  "id_str" : "235818183649525760",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues Hmmm usual stuff... Seems a good idea but not really living up to its promise... If there is nothing else on I guess so.",
  "id" : 235818183649525760,
  "in_reply_to_status_id" : 235757777484648448,
  "created_at" : "2012-08-15 19:20:10 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235732050227904512",
  "geo" : { },
  "id_str" : "235737481369235457",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues you given continuum a go? I don't know what to make of it tbh.... Still on the wall.",
  "id" : 235737481369235457,
  "in_reply_to_status_id" : 235732050227904512,
  "created_at" : "2012-08-15 13:59:30 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235730252918321152",
  "geo" : { },
  "id_str" : "235731512505552896",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues i gave up on it - seemed a bit too odd for me - good premise then got lost I think.",
  "id" : 235731512505552896,
  "in_reply_to_status_id" : 235730252918321152,
  "created_at" : "2012-08-15 13:35:46 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235670733391548416",
  "text" : "I smell of carex handwash and it is turning me.... This is all.",
  "id" : 235670733391548416,
  "created_at" : "2012-08-15 09:34:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the black telescope",
      "screen_name" : "blacktelescope",
      "indices" : [ 0, 15 ],
      "id_str" : "14932763",
      "id" : 14932763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235455677995290624",
  "geo" : { },
  "id_str" : "235465084896432128",
  "in_reply_to_user_id" : 14932763,
  "text" : "@blacktelescope you ok?",
  "id" : 235465084896432128,
  "in_reply_to_status_id" : 235455677995290624,
  "created_at" : "2012-08-14 19:57:05 +0000",
  "in_reply_to_screen_name" : "blacktelescope",
  "in_reply_to_user_id_str" : "14932763",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235339648329719808",
  "geo" : { },
  "id_str" : "235362084324528128",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke yes. why yes i am :)",
  "id" : 235362084324528128,
  "in_reply_to_status_id" : 235339648329719808,
  "created_at" : "2012-08-14 13:07:48 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235339121227337728",
  "text" : "Note to self: When there is a dude being interviewed in the training room - do not say \"FUCK OFF\" several times out loud.... Bad craic.",
  "id" : 235339121227337728,
  "created_at" : "2012-08-14 11:36:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fivewordsthatdestroyedmymorning",
      "indices" : [ 22, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235296286004350977",
  "text" : "\"nope I don't see it\" #fivewordsthatdestroyedmymorning",
  "id" : 235296286004350977,
  "created_at" : "2012-08-14 08:46:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235289695247032320",
  "text" : "Day 2 of Operation: Quit everything - after a cup of tea and the cleaners go home...",
  "id" : 235289695247032320,
  "created_at" : "2012-08-14 08:20:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webcamnippleshot",
      "indices" : [ 56, 73 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235101148934189056",
  "geo" : { },
  "id_str" : "235102326849941505",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit wear something sexy for tomorrow on gtalk #webcamnippleshot",
  "id" : 235102326849941505,
  "in_reply_to_status_id" : 235101148934189056,
  "created_at" : "2012-08-13 19:55:37 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235098089504002049",
  "text" : "That feeling when you goto the kitchen and discover that someone didn't put the oven on. That someone is me. A kick in the dick is needed.",
  "id" : 235098089504002049,
  "created_at" : "2012-08-13 19:38:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235096533899571200",
  "geo" : { },
  "id_str" : "235096989057032192",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ amazing to watch someone that has such control over a musical instrument.",
  "id" : 235096989057032192,
  "in_reply_to_status_id" : 235096533899571200,
  "created_at" : "2012-08-13 19:34:24 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235094628041388032",
  "geo" : { },
  "id_str" : "235095755122176000",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit You on gtalk later - I need some advice\/dirty talk later if you are avail - if not I'll come from deep cover tomorrow :)",
  "id" : 235095755122176000,
  "in_reply_to_status_id" : 235094628041388032,
  "created_at" : "2012-08-13 19:29:30 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/bT0ZJrCN",
      "expanded_url" : "http:\/\/youtu.be\/PB3RbO7updc",
      "display_url" : "youtu.be\/PB3RbO7updc"
    } ]
  },
  "geo" : { },
  "id_str" : "235091088740855808",
  "text" : "http:\/\/t.co\/bT0ZJrCN",
  "id" : 235091088740855808,
  "created_at" : "2012-08-13 19:10:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/n1KMAepk",
      "expanded_url" : "http:\/\/dlvr.it\/20Hfyx",
      "display_url" : "dlvr.it\/20Hfyx"
    } ]
  },
  "geo" : { },
  "id_str" : "235089706075963392",
  "text" : "CIA Declassifies Amazing 1972 Spy Satellite Capsule Deep-Sea Rescue http:\/\/t.co\/n1KMAepk",
  "id" : 235089706075963392,
  "created_at" : "2012-08-13 19:05:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 93, 99 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235042055817150465",
  "text" : "\u201C@michaelnsimpson: The only positive thing to come out of the past 60 minutes is introducing @swmcc to Ron Swanson\u201D",
  "id" : 235042055817150465,
  "created_at" : "2012-08-13 15:56:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235041336787599361",
  "text" : "The new \"close everything off\" in work today worked a treat. Still answered emails and talked to ppl but got shit loads done.",
  "id" : 235041336787599361,
  "created_at" : "2012-08-13 15:53:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235007163003711488",
  "geo" : { },
  "id_str" : "235039098706993152",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll cos you are classy - and I should not utter such words to you.",
  "id" : 235039098706993152,
  "in_reply_to_status_id" : 235007163003711488,
  "created_at" : "2012-08-13 15:44:22 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234973119029325824",
  "geo" : { },
  "id_str" : "234991938703597568",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll must resist joke... must resist joke.........",
  "id" : 234991938703597568,
  "in_reply_to_status_id" : 234973119029325824,
  "created_at" : "2012-08-13 12:36:58 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234942813467463680",
  "text" : "After this cup of tea I am shutting myself off from the world to see what happens workwise.....",
  "id" : 234942813467463680,
  "created_at" : "2012-08-13 09:21:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234787955682705408",
  "text" : "I am in &lt;3 with Townsend....",
  "id" : 234787955682705408,
  "created_at" : "2012-08-12 23:06:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234787404605706240",
  "text" : "Even at 20% The Who are ten times better than the guff that was before them...",
  "id" : 234787404605706240,
  "created_at" : "2012-08-12 23:04:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234787007958757376",
  "geo" : { },
  "id_str" : "234787214524022785",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight but you wouldn't have got them mixed up though? :)",
  "id" : 234787214524022785,
  "in_reply_to_status_id" : 234787007958757376,
  "created_at" : "2012-08-12 23:03:28 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "disgusted",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234786820771155968",
  "text" : "OH: \"Ohhh The Who sang that - I thought that was Bon Jovi\"....... #disgusted",
  "id" : 234786820771155968,
  "created_at" : "2012-08-12 23:01:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234786448291794945",
  "text" : "Finally - The Who :D",
  "id" : 234786448291794945,
  "created_at" : "2012-08-12 23:00:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234785055107600384",
  "geo" : { },
  "id_str" : "234785168651599872",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 you not in?",
  "id" : 234785168651599872,
  "in_reply_to_status_id" : 234785055107600384,
  "created_at" : "2012-08-12 22:55:20 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234784153806196739",
  "text" : "Take That!!!! I am going to sleep now... I wanted The Who.....",
  "id" : 234784153806196739,
  "created_at" : "2012-08-12 22:51:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234778019963731968",
  "text" : "Boris holding the flag - what could go wrong? :)",
  "id" : 234778019963731968,
  "created_at" : "2012-08-12 22:26:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234777036265254912",
  "geo" : { },
  "id_str" : "234777169694425088",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 you hurt me :(",
  "id" : 234777169694425088,
  "in_reply_to_status_id" : 234777036265254912,
  "created_at" : "2012-08-12 22:23:33 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234775666653007874",
  "geo" : { },
  "id_str" : "234776704629997568",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 why?",
  "id" : 234776704629997568,
  "in_reply_to_status_id" : 234775666653007874,
  "created_at" : "2012-08-12 22:21:42 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234776298965327872",
  "text" : "Could they have not found anyone else other than Jessie J? :( George would have been brilliant at this part!",
  "id" : 234776298965327872,
  "created_at" : "2012-08-12 22:20:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234775893464215552",
  "text" : "Just tells you the class of Freddie, May and Taylor - they've ignited that stadium!!! :D",
  "id" : 234775893464215552,
  "created_at" : "2012-08-12 22:18:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234774848113610753",
  "text" : "Now we are talking!!!!",
  "id" : 234774848113610753,
  "created_at" : "2012-08-12 22:14:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234774571801247746",
  "geo" : { },
  "id_str" : "234774724633313280",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight I dont get Muse at this point -they are hardly a feel good band.",
  "id" : 234774724633313280,
  "in_reply_to_status_id" : 234774571801247746,
  "created_at" : "2012-08-12 22:13:50 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234774396135411712",
  "text" : "So we just had Eric Idle to come and get everyone going and now Muse??? I dont get it... I really don't.... Also he's faking that guitar...",
  "id" : 234774396135411712,
  "created_at" : "2012-08-12 22:12:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234773957293768705",
  "text" : "Muse???",
  "id" : 234773957293768705,
  "created_at" : "2012-08-12 22:10:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234772639162445825",
  "text" : "BRILLIANT - ERIC IDLE :D :D :D :D :D :D",
  "id" : 234772639162445825,
  "created_at" : "2012-08-12 22:05:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234772053591486466",
  "text" : "Are they teasing me again?????",
  "id" : 234772053591486466,
  "created_at" : "2012-08-12 22:03:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Banes",
      "screen_name" : "chrisbanes",
      "indices" : [ 3, 14 ],
      "id_str" : "18872463",
      "id" : 18872463
    }, {
      "name" : "BBC Sport",
      "screen_name" : "BBCSport",
      "indices" : [ 36, 45 ],
      "id_str" : "265902729",
      "id" : 265902729
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClosingCeremony",
      "indices" : [ 46, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234771085751635970",
  "text" : "RT @chrisbanes: We want more Boris! @BBCSport #ClosingCeremony",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC Sport",
        "screen_name" : "BBCSport",
        "indices" : [ 20, 29 ],
        "id_str" : "265902729",
        "id" : 265902729
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ClosingCeremony",
        "indices" : [ 30, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "234771012540059650",
    "text" : "We want more Boris! @BBCSport #ClosingCeremony",
    "id" : 234771012540059650,
    "created_at" : "2012-08-12 21:59:05 +0000",
    "user" : {
      "name" : "Chris Banes",
      "screen_name" : "chrisbanes",
      "protected" : false,
      "id_str" : "18872463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000437939758\/37c9d1229cdd054dd112c373db303783_normal.jpeg",
      "id" : 18872463,
      "verified" : false
    }
  },
  "id" : 234771085751635970,
  "created_at" : "2012-08-12 21:59:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234770773557014529",
  "text" : "Well Boris dancing made up for it..",
  "id" : 234770773557014529,
  "created_at" : "2012-08-12 21:58:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234770126434611200",
  "text" : "THEY ARE NEVER COMING DOWN EITHER....",
  "id" : 234770126434611200,
  "created_at" : "2012-08-12 21:55:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234769990572707840",
  "text" : "SPICE GIRLS... ARE YOU FUCKING KIDDING ME... MY BALLS JUST WENT STRAIGHT INTO MY STOMACH",
  "id" : 234769990572707840,
  "created_at" : "2012-08-12 21:55:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234769761316261888",
  "text" : "This is gonna be bad - i can feel it....",
  "id" : 234769761316261888,
  "created_at" : "2012-08-12 21:54:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openingceremony",
      "indices" : [ 111, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234769147488268289",
  "text" : "I swear the busker that stands out the back of castle court is gonna be on that stage next by the looks of it. #openingceremony",
  "id" : 234769147488268289,
  "created_at" : "2012-08-12 21:51:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234768815546839040",
  "text" : "I have yet to see one 'Legend' - well maybe Michael\/Lennox and the cock tease of Bowie - everyone else... big pile of wank....",
  "id" : 234768815546839040,
  "created_at" : "2012-08-12 21:50:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234768453314166787",
  "geo" : { },
  "id_str" : "234768625117036544",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight nope but Jordan and Peter Andre are coming up soon.",
  "id" : 234768625117036544,
  "in_reply_to_status_id" : 234768453314166787,
  "created_at" : "2012-08-12 21:49:36 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234768539955900416",
  "text" : "We were doing so well up until 9pm tonight.... I am going to shoredtich tomorrow and gonna slap every twat!",
  "id" : 234768539955900416,
  "created_at" : "2012-08-12 21:49:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234767674838749184",
  "text" : "Ha Jessie J the crowd don't want to sing along with you :D Ha :D :D",
  "id" : 234767674838749184,
  "created_at" : "2012-08-12 21:45:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234767479904272384",
  "text" : "My life's ambition is to find the committee that decided that having Russel Brand on and stab them to death with a blunt thing...",
  "id" : 234767479904272384,
  "created_at" : "2012-08-12 21:45:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234766572605026304",
  "geo" : { },
  "id_str" : "234767022247010305",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett fuck sake..... that was terrible.. but Fatboy is making up for it :D",
  "id" : 234767022247010305,
  "in_reply_to_status_id" : 234766572605026304,
  "created_at" : "2012-08-12 21:43:14 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234766680662888449",
  "text" : "Fat Boy Slim - thank feck.......",
  "id" : 234766680662888449,
  "created_at" : "2012-08-12 21:41:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234766613574991872",
  "text" : "Seriously some terrorist shoot that fuck right now!!!",
  "id" : 234766613574991872,
  "created_at" : "2012-08-12 21:41:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234765986815954946",
  "geo" : { },
  "id_str" : "234766267725258754",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett FUCK FUCK FUCK FUCK",
  "id" : 234766267725258754,
  "in_reply_to_status_id" : 234765986815954946,
  "created_at" : "2012-08-12 21:40:14 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234766125714509824",
  "text" : "THAT CUNT IS SINGING A BEATLES SONG.... FUCKING HELL........... FUCK OFF AND DIE YOU CUNT!!!!",
  "id" : 234766125714509824,
  "created_at" : "2012-08-12 21:39:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234765989907165184",
  "text" : "RUSSELL BRAND.... FUCK OFF AND DIE... ARE YOU FUCKING KIDDING ME???",
  "id" : 234765989907165184,
  "created_at" : "2012-08-12 21:39:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234763867455107072",
  "text" : "Annie Lennox - hmmmmm - a bit of class at last but still - up it a bit more.",
  "id" : 234763867455107072,
  "created_at" : "2012-08-12 21:30:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234763518623219712",
  "geo" : { },
  "id_str" : "234763624382615553",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight that makes more sense now ;) :D :D",
  "id" : 234763624382615553,
  "in_reply_to_status_id" : 234763518623219712,
  "created_at" : "2012-08-12 21:29:44 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234762828052049921",
  "geo" : { },
  "id_str" : "234763218252337152",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ they better not have.. but understandable if they said no...",
  "id" : 234763218252337152,
  "in_reply_to_status_id" : 234762828052049921,
  "created_at" : "2012-08-12 21:28:07 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234762866585108480",
  "text" : "I have yet to see Bowie... they are cock teasing me....... Not on.....",
  "id" : 234762866585108480,
  "created_at" : "2012-08-12 21:26:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "closingceremony",
      "indices" : [ 48, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234762509377216513",
  "text" : "If they bring out Bowie all is forgiven........ #closingceremony",
  "id" : 234762509377216513,
  "created_at" : "2012-08-12 21:25:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234762401856249857",
  "text" : "Bowie!!!!!!! BRING OUT BOWIE!!!!!!",
  "id" : 234762401856249857,
  "created_at" : "2012-08-12 21:24:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234762094325686273",
  "geo" : { },
  "id_str" : "234762343979040769",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight :D I am gutted.. the kasier chiefs.. this is getting worse and worse...",
  "id" : 234762343979040769,
  "in_reply_to_status_id" : 234762094325686273,
  "created_at" : "2012-08-12 21:24:39 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234762152135782402",
  "text" : "Nothing like expecting The Who and then getting those twats (Kasier Chiefs)...",
  "id" : 234762152135782402,
  "created_at" : "2012-08-12 21:23:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234761943704039424",
  "text" : "KAISER CHIEFS..... THAT'S IT - I AM BECOMING AN IRISH CITIZEN....",
  "id" : 234761943704039424,
  "created_at" : "2012-08-12 21:23:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "closingceremony",
      "indices" : [ 101, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234761494896730112",
  "text" : "I hear a rumour the Spice Girls are in this ceremony? WTAF!!! Shoredtich wankers - fuck. right. off. #closingceremony",
  "id" : 234761494896730112,
  "created_at" : "2012-08-12 21:21:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234760717797040129",
  "geo" : { },
  "id_str" : "234760990686855171",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight but he still all his hair - the bastard.",
  "id" : 234760990686855171,
  "in_reply_to_status_id" : 234760717797040129,
  "created_at" : "2012-08-12 21:19:16 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234760717797040129",
  "geo" : { },
  "id_str" : "234760938627137537",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight this is terrible.. I enjoyed everyday of the games up until 9pm... I hope it gets better soon...",
  "id" : 234760938627137537,
  "in_reply_to_status_id" : 234760717797040129,
  "created_at" : "2012-08-12 21:19:04 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234759675306987520",
  "text" : "George Michael - really??!?!? And he's wearing leather? So many wrong things wrong... Only 140 characters.. So. FUCK THIS SHIT!!!",
  "id" : 234759675306987520,
  "created_at" : "2012-08-12 21:14:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AngryBritain.com",
      "screen_name" : "AngryBritain",
      "indices" : [ 3, 16 ],
      "id_str" : "15589307",
      "id" : 15589307
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "closingceremony",
      "indices" : [ 31, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234758365136445442",
  "text" : "RT @AngryBritain: This Olympic #closingceremony is like the last episode of Lost.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "closingceremony",
        "indices" : [ 13, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "234753567062384640",
    "text" : "This Olympic #closingceremony is like the last episode of Lost.",
    "id" : 234753567062384640,
    "created_at" : "2012-08-12 20:49:46 +0000",
    "user" : {
      "name" : "AngryBritain.com",
      "screen_name" : "AngryBritain",
      "protected" : false,
      "id_str" : "15589307",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1157281387\/union_seat_normal.jpg",
      "id" : 15589307,
      "verified" : false
    }
  },
  "id" : 234758365136445442,
  "created_at" : "2012-08-12 21:08:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234755928715575297",
  "geo" : { },
  "id_str" : "234758159040905216",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore yeah - seems like some people from shoreditch just wanked on a page.. I lost all hope when Madness came out.",
  "id" : 234758159040905216,
  "in_reply_to_status_id" : 234755928715575297,
  "created_at" : "2012-08-12 21:08:01 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234702271827570688",
  "text" : "I want to be 10 again.... I fucking love the goonies....",
  "id" : 234702271827570688,
  "created_at" : "2012-08-12 17:25:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "heyyouguys",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234699037188689920",
  "text" : "The Goonies is on channel 5.... #heyyouguys Awesome Sunday show... I've hidden the remote - this is to be watched - regardless!",
  "id" : 234699037188689920,
  "created_at" : "2012-08-12 17:13:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea McVeigh",
      "screen_name" : "worldinaglass",
      "indices" : [ 3, 17 ],
      "id_str" : "366115249",
      "id" : 366115249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234688041564913664",
  "text" : "RT @worldinaglass: If David Bowie plays the closing ceremony tonight I will snog my TV. Fact.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "234681051677618176",
    "text" : "If David Bowie plays the closing ceremony tonight I will snog my TV. Fact.",
    "id" : 234681051677618176,
    "created_at" : "2012-08-12 16:01:37 +0000",
    "user" : {
      "name" : "Andrea McVeigh",
      "screen_name" : "worldinaglass",
      "protected" : false,
      "id_str" : "366115249",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2125788138\/Twitter_daffs_normal.jpg",
      "id" : 366115249,
      "verified" : false
    }
  },
  "id" : 234688041564913664,
  "created_at" : "2012-08-12 16:29:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234637658473771008",
  "geo" : { },
  "id_str" : "234637802166431745",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu FUCK SAKE... YES.. NOW LEAVE ME ALONE YOU DRAMA QUEEN!!!!",
  "id" : 234637802166431745,
  "in_reply_to_status_id" : 234637658473771008,
  "created_at" : "2012-08-12 13:09:46 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234361477555945472",
  "text" : "I can't wait to read the back stepping from those inbreds that called Mo a plastic Brit. Whole country was behind him there.",
  "id" : 234361477555945472,
  "created_at" : "2012-08-11 18:51:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234242613648175104",
  "geo" : { },
  "id_str" : "234242988346310656",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson indeed :D",
  "id" : 234242988346310656,
  "in_reply_to_status_id" : 234242613648175104,
  "created_at" : "2012-08-11 11:00:55 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234232062964551680",
  "geo" : { },
  "id_str" : "234234568109080576",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson FUCK SAKE MICHAEL..",
  "id" : 234234568109080576,
  "in_reply_to_status_id" : 234232062964551680,
  "created_at" : "2012-08-11 10:27:27 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 13, 20 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233938680585256961",
  "geo" : { },
  "id_str" : "233938771882676224",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @srushe as long as your sexy ass is alright buddy :D",
  "id" : 233938771882676224,
  "in_reply_to_status_id" : 233938680585256961,
  "created_at" : "2012-08-10 14:52:04 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Adams MBE",
      "screen_name" : "NicolaAdams2012",
      "indices" : [ 44, 60 ],
      "id_str" : "87429715",
      "id" : 87429715
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doneyourselfproud",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233938075720495104",
  "text" : "Have to say it was a privilege to watch how @NicolaAdams2012 conducted herself after winning gold. Her grin said it all. #doneyourselfproud",
  "id" : 233938075720495104,
  "created_at" : "2012-08-10 14:49:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the black telescope",
      "screen_name" : "blacktelescope",
      "indices" : [ 0, 15 ],
      "id_str" : "14932763",
      "id" : 14932763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233933347049570304",
  "geo" : { },
  "id_str" : "233934011041456128",
  "in_reply_to_user_id" : 14932763,
  "text" : "@blacktelescope I am okay with that :D",
  "id" : 233934011041456128,
  "in_reply_to_status_id" : 233933347049570304,
  "created_at" : "2012-08-10 14:33:09 +0000",
  "in_reply_to_screen_name" : "blacktelescope",
  "in_reply_to_user_id_str" : "14932763",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the black telescope",
      "screen_name" : "blacktelescope",
      "indices" : [ 0, 15 ],
      "id_str" : "14932763",
      "id" : 14932763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233932054394458112",
  "geo" : { },
  "id_str" : "233932816243638272",
  "in_reply_to_user_id" : 14932763,
  "text" : "@blacktelescope yeah - weird. I am tired though. Wasn't even drunk - just stayed up until 11:30 playing poker! Few beers. Ahh well :D",
  "id" : 233932816243638272,
  "in_reply_to_status_id" : 233932054394458112,
  "created_at" : "2012-08-10 14:28:24 +0000",
  "in_reply_to_screen_name" : "blacktelescope",
  "in_reply_to_user_id_str" : "14932763",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233931053537058817",
  "text" : "I am NEVER drinking on a school night again ever EVER EVER. Not hungover just useless.. Too old for this shit! Good night though :D",
  "id" : 233931053537058817,
  "created_at" : "2012-08-10 14:21:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 12, 28 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 57, 64 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233924479150088192",
  "geo" : { },
  "id_str" : "233924899729719296",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @michaelnsimpson Everyone loves it so far... @srushe is heading my head at the mo... :D",
  "id" : 233924899729719296,
  "in_reply_to_status_id" : 233924479150088192,
  "created_at" : "2012-08-10 13:56:56 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233895672741519360",
  "text" : "\u201C@michaelnsimpson: Brilliant, \"Oh aye, stalker in a classy way Mike.\" Just what i needed to hear to make things better\u201D He has much to learn",
  "id" : 233895672741519360,
  "created_at" : "2012-08-10 12:00:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 8, 16 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youbeautifulmanyou",
      "indices" : [ 58, 77 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233886241861554176",
  "geo" : { },
  "id_str" : "233888654764957696",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe @havoct5 am busy now... will when this is over ;) #youbeautifulmanyou",
  "id" : 233888654764957696,
  "in_reply_to_status_id" : 233886241861554176,
  "created_at" : "2012-08-10 11:32:55 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 65, 71 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 107, 121 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233882659787534336",
  "text" : "RT @HaVoCT5: gutted thought i was gonna be able to sit down with @swmcc and watch the rhythmic gymnastics. @peter_omalley lied to us! ju ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 52, 58 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Peter O'Malley",
        "screen_name" : "peter_omalley",
        "indices" : [ 94, 108 ],
        "id_str" : "437697624",
        "id" : 437697624
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233882551104716800",
    "text" : "gutted thought i was gonna be able to sit down with @swmcc and watch the rhythmic gymnastics. @peter_omalley lied to us! just not fair!",
    "id" : 233882551104716800,
    "created_at" : "2012-08-10 11:08:40 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 233882659787534336,
  "created_at" : "2012-08-10 11:09:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233872709648531456",
  "text" : "OH: \"Stop making my brother gay with ur sexiness :P\"",
  "id" : 233872709648531456,
  "created_at" : "2012-08-10 10:29:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233860562545688576",
  "geo" : { },
  "id_str" : "233860800853454849",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne who says I want to win..Just want to help a buddy out who needs to beat someone up! What's up? - sure work is fin - :D :D :D",
  "id" : 233860800853454849,
  "in_reply_to_status_id" : 233860562545688576,
  "created_at" : "2012-08-10 09:42:14 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233859880992268288",
  "geo" : { },
  "id_str" : "233860220491812864",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne bring it!",
  "id" : 233860220491812864,
  "in_reply_to_status_id" : 233859880992268288,
  "created_at" : "2012-08-10 09:39:56 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 17, 25 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233859622623125504",
  "text" : "I kid you not... @HaVoCT5 just gave me a sneaky love bite!!! You do not know want to know how this happened. I feel violated!",
  "id" : 233859622623125504,
  "created_at" : "2012-08-10 09:37:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233847922280759297",
  "geo" : { },
  "id_str" : "233849848938520576",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull barf :(",
  "id" : 233849848938520576,
  "in_reply_to_status_id" : 233847922280759297,
  "created_at" : "2012-08-10 08:58:43 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 3, 17 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 19, 35 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 36, 47 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 107, 113 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233847771130654720",
  "text" : "RT @ChrisKnowles_: @michaelnsimpson @Alana_Doll nicely done! Not too scary looking after all... So how was @swmcc 's sticky cream slidin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike ",
        "screen_name" : "michaelnsimpson",
        "indices" : [ 0, 16 ],
        "id_str" : "311597138",
        "id" : 311597138
      }, {
        "name" : "Alana",
        "screen_name" : "Alana_Doll",
        "indices" : [ 17, 28 ],
        "id_str" : "67130324",
        "id" : 67130324
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 88, 94 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "233669556525207553",
    "geo" : { },
    "id_str" : "233676082694483968",
    "in_reply_to_user_id" : 311597138,
    "text" : "@michaelnsimpson @Alana_Doll nicely done! Not too scary looking after all... So how was @swmcc 's sticky cream sliding down your throat?",
    "id" : 233676082694483968,
    "in_reply_to_status_id" : 233669556525207553,
    "created_at" : "2012-08-09 21:28:14 +0000",
    "in_reply_to_screen_name" : "michaelnsimpson",
    "in_reply_to_user_id_str" : "311597138",
    "user" : {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "protected" : false,
      "id_str" : "241959103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2926965131\/2eaf8d76e348f155b1079a71275e2ceb_normal.png",
      "id" : 241959103,
      "verified" : false
    }
  },
  "id" : 233847771130654720,
  "created_at" : "2012-08-10 08:50:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233847167066972160",
  "geo" : { },
  "id_str" : "233847513143201792",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull :D :D Enjoy your time off..",
  "id" : 233847513143201792,
  "in_reply_to_status_id" : 233847167066972160,
  "created_at" : "2012-08-10 08:49:26 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 16, 29 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 30, 42 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feelingsthatcantbebeatbutcanberepeateduntilyougetback",
      "indices" : [ 68, 122 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233846411333083136",
  "geo" : { },
  "id_str" : "233846812128206848",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @rickyhassard @niall_adams My nuts in your tea cup. #feelingsthatcantbebeatbutcanberepeateduntilyougetback",
  "id" : 233846812128206848,
  "in_reply_to_status_id" : 233846411333083136,
  "created_at" : "2012-08-10 08:46:39 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 29, 45 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 72, 83 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233846679932133376",
  "text" : "Really enjoyed last night at @michaelnsimpson house for some poker. And @Alana_Doll made the best \"Stevie Sex Face Cake\" ever.",
  "id" : 233846679932133376,
  "created_at" : "2012-08-10 08:46:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233637558612013056",
  "geo" : { },
  "id_str" : "233804670550806528",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 I came fourth which I was happy about :)",
  "id" : 233804670550806528,
  "in_reply_to_status_id" : 233637558612013056,
  "created_at" : "2012-08-10 05:59:11 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 32, 38 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233563023296569344",
  "text" : "RT @HaVoCT5: Pretty sure me and @swmcc have just had the greatest 10mins of the day, watching the artistic gymnasts on the bbc stream..# ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 19, 25 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "needatug",
        "indices" : [ 122, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233562873052409856",
    "text" : "Pretty sure me and @swmcc have just had the greatest 10mins of the day, watching the artistic gymnasts on the bbc stream..#needatug",
    "id" : 233562873052409856,
    "created_at" : "2012-08-09 13:58:22 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 233563023296569344,
  "created_at" : "2012-08-09 13:58:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233551223574380545",
  "text" : "OH: \"this is shocking, imagine the sex!\"",
  "id" : 233551223574380545,
  "created_at" : "2012-08-09 13:12:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 16, 32 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 33, 47 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 48, 61 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 62, 69 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 70, 78 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 79, 93 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 94, 106 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233508596049121280",
  "geo" : { },
  "id_str" : "233508764043579393",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @michaelnsimpson @chrisknowles_ @rickyhassard @srushe @havoct5 @peter_omalley @ryancunning \nmob mentality... sorry",
  "id" : 233508764043579393,
  "in_reply_to_status_id" : 233508596049121280,
  "created_at" : "2012-08-09 10:23:22 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 16, 32 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 33, 47 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 48, 61 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 62, 69 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 70, 78 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 79, 93 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 94, 106 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233508327517208577",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @michaelnsimpson @chrisknowles_ @rickyhassard @srushe @havoct5 @peter_omalley @ryancunning \ngonna tea bag your plate!",
  "id" : 233508327517208577,
  "created_at" : "2012-08-09 10:21:38 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233503678873628674",
  "geo" : { },
  "id_str" : "233508053692084225",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM Noooonow you've said it out loud it will go cloudy!!!! :D",
  "id" : 233508053692084225,
  "in_reply_to_status_id" : 233503678873628674,
  "created_at" : "2012-08-09 10:20:33 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233507109952688129",
  "geo" : { },
  "id_str" : "233507260058460161",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull don't be that person Annette.. you are better than this :D",
  "id" : 233507260058460161,
  "in_reply_to_status_id" : 233507109952688129,
  "created_at" : "2012-08-09 10:17:23 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna",
      "screen_name" : "Annagetic",
      "indices" : [ 3, 13 ],
      "id_str" : "35600944",
      "id" : 35600944
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Annagetic\/status\/233457675864768512\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/PqWp6z97",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Az1ohPBCAAAicSL.jpg",
      "id_str" : "233457675868962816",
      "id" : 233457675868962816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Az1ohPBCAAAicSL.jpg",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/PqWp6z97"
    } ],
    "hashtags" : [ {
      "text" : "EqualMarriage",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233506632108236800",
  "text" : "RT @Annagetic: Quick &amp; easy flow chart to give to the critics of same-sex marriage! #EqualMarriage http:\/\/t.co\/PqWp6z97",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Annagetic\/status\/233457675864768512\/photo\/1",
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/PqWp6z97",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Az1ohPBCAAAicSL.jpg",
        "id_str" : "233457675868962816",
        "id" : 233457675868962816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Az1ohPBCAAAicSL.jpg",
        "sizes" : [ {
          "h" : 623,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/PqWp6z97"
      } ],
      "hashtags" : [ {
        "text" : "EqualMarriage",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233457675864768512",
    "text" : "Quick &amp; easy flow chart to give to the critics of same-sex marriage! #EqualMarriage http:\/\/t.co\/PqWp6z97",
    "id" : 233457675864768512,
    "created_at" : "2012-08-09 07:00:22 +0000",
    "user" : {
      "name" : "Anna",
      "screen_name" : "Annagetic",
      "protected" : false,
      "id_str" : "35600944",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000197810917\/deee4bb9aaa2ffa59dbbec8e9b33a29f_normal.jpeg",
      "id" : 35600944,
      "verified" : false
    }
  },
  "id" : 233506632108236800,
  "created_at" : "2012-08-09 10:14:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 30, 44 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 45, 58 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 59, 66 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 67, 75 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 76, 90 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 91, 103 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233502556335255552",
  "geo" : { },
  "id_str" : "233502734588989440",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @michaelnsimpson @chrisknowles_ @rickyhassard @srushe @havoct5 @peter_omalley @ryancunning CUNT",
  "id" : 233502734588989440,
  "in_reply_to_status_id" : 233502556335255552,
  "created_at" : "2012-08-09 09:59:24 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233493994598969344",
  "geo" : { },
  "id_str" : "233498733613035520",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson :D Awesome.... Think of the pilgrimage tomorrow dude....",
  "id" : 233498733613035520,
  "in_reply_to_status_id" : 233493994598969344,
  "created_at" : "2012-08-09 09:43:30 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "handytip",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233487724634574848",
  "text" : "If only for replacing relative paths... require('..\/..\/shared\/session') and require('session'); #handytip",
  "id" : 233487724634574848,
  "created_at" : "2012-08-09 08:59:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "handytip",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233486912126607360",
  "text" : "One thing that has become apparent the more I use express.js - make *everything* a module if you can. #handytip",
  "id" : 233486912126607360,
  "created_at" : "2012-08-09 08:56:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 17, 25 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233321273600651265",
  "geo" : { },
  "id_str" : "233321640170246144",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @havoct5 don't need to come in as I have already outside your door. The thought of you mere feet away in your pjs did it ;)",
  "id" : 233321640170246144,
  "in_reply_to_status_id" : 233321273600651265,
  "created_at" : "2012-08-08 21:59:48 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 17, 25 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/233321022936477698\/photo\/1",
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/w32eEy9f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzzsO_MCcAEbp5H.jpg",
      "id_str" : "233321022940672001",
      "id" : 233321022940672001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzzsO_MCcAEbp5H.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/w32eEy9f"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233320672833720320",
  "geo" : { },
  "id_str" : "233321022936477698",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @havoct5 like what..... A peekaboooooo http:\/\/t.co\/w32eEy9f",
  "id" : 233321022936477698,
  "in_reply_to_status_id" : 233320672833720320,
  "created_at" : "2012-08-08 21:57:22 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 17, 25 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Gumtree.com",
      "screen_name" : "Gumtree",
      "indices" : [ 73, 81 ],
      "id_str" : "19088546",
      "id" : 19088546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233320490956120064",
  "geo" : { },
  "id_str" : "233320692656001024",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @havoct5 I have photographic evidence plus an advert on @gumtree",
  "id" : 233320692656001024,
  "in_reply_to_status_id" : 233320490956120064,
  "created_at" : "2012-08-08 21:56:02 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 17, 25 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233316492031188992",
  "geo" : { },
  "id_str" : "233320492763860993",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @havoct5 when we start to play truth or day....",
  "id" : 233320492763860993,
  "in_reply_to_status_id" : 233316492031188992,
  "created_at" : "2012-08-08 21:55:15 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "37signals Changelog",
      "screen_name" : "37changes",
      "indices" : [ 1, 11 ],
      "id_str" : "113395745",
      "id" : 113395745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/0N810dv9",
      "expanded_url" : "http:\/\/bit.ly\/RqJnJo",
      "display_url" : "bit.ly\/RqJnJo"
    } ]
  },
  "geo" : { },
  "id_str" : "233300504858488832",
  "text" : "\u201C@37changes: Basecamp new feature: Turn a discussion into a to-do http:\/\/t.co\/0N810dv9\u201D &lt;3 &lt;3",
  "id" : 233300504858488832,
  "created_at" : "2012-08-08 20:35:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/233273637690552320\/photo\/1",
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/YeplTYX4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzzBIzZCMAA93rl.jpg",
      "id_str" : "233273637694746624",
      "id" : 233273637694746624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzzBIzZCMAA93rl.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/YeplTYX4"
    } ],
    "hashtags" : [ {
      "text" : "thehumanraceisfucked",
      "indices" : [ 10, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233273637690552320",
  "text" : "Lovely :) #thehumanraceisfucked http:\/\/t.co\/YeplTYX4",
  "id" : 233273637690552320,
  "created_at" : "2012-08-08 18:49:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233219370455805953",
  "geo" : { },
  "id_str" : "233219712832651264",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus you know it bitch!!! Plus I have sinatra, rails and node.js 'apps' (express.js) on a private github repo for personal use!!",
  "id" : 233219712832651264,
  "in_reply_to_status_id" : 233219370455805953,
  "created_at" : "2012-08-08 15:14:47 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233218901901713409",
  "geo" : { },
  "id_str" : "233219174535675904",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus i've got 'Rework' to read on the bus tomorrow.. I am reading that book on public transport... I am an IMD graduate :D :D",
  "id" : 233219174535675904,
  "in_reply_to_status_id" : 233218901901713409,
  "created_at" : "2012-08-08 15:12:38 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233218210047094784",
  "geo" : { },
  "id_str" : "233218298655944704",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ when I touch your lips......",
  "id" : 233218298655944704,
  "in_reply_to_status_id" : 233218210047094784,
  "created_at" : "2012-08-08 15:09:10 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "takemybreathaway",
      "indices" : [ 55, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233217700661428224",
  "geo" : { },
  "id_str" : "233217884174819329",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ like in Top Gun???????????????????????? #takemybreathaway",
  "id" : 233217884174819329,
  "in_reply_to_status_id" : 233217700661428224,
  "created_at" : "2012-08-08 15:07:31 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233217018822803456",
  "geo" : { },
  "id_str" : "233217643530825728",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus I am okay with that. Do not talk to me whilst on public transport is a good rule of thumb :D",
  "id" : 233217643530825728,
  "in_reply_to_status_id" : 233217018822803456,
  "created_at" : "2012-08-08 15:06:33 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233216400959889409",
  "text" : "I'm getting the bus into work tomorrow morning... Should be fun...",
  "id" : 233216400959889409,
  "created_at" : "2012-08-08 15:01:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233183343930396672",
  "text" : "I gave in... iTunes you get your stupid update.... Was a long hard fought battle tough...",
  "id" : 233183343930396672,
  "created_at" : "2012-08-08 12:50:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233138520473083904",
  "text" : "Brain fart this morning with svn branching.. Updating a branch after a few months of just being left alone... Hmmm what could go wrong ;)",
  "id" : 233138520473083904,
  "created_at" : "2012-08-08 09:52:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 12, 28 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 29, 42 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232953114972524544",
  "geo" : { },
  "id_str" : "232957175373389826",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @michaelnsimpson @rickyhassard noooooooooooooooooooooooooooooooo!!!!!!!!!!!",
  "id" : 232957175373389826,
  "in_reply_to_status_id" : 232953114972524544,
  "created_at" : "2012-08-07 21:51:33 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232924624898383873",
  "text" : "I have just out grossed myself out... That was new...... I hope not to repeat it.",
  "id" : 232924624898383873,
  "created_at" : "2012-08-07 19:42:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 31, 42 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232923999183720450",
  "geo" : { },
  "id_str" : "232924246781857792",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @RickyHassard @Alana_Doll I am not. I've a tonne of these saved up for Thursday as I am going down the back of your throat!",
  "id" : 232924246781857792,
  "in_reply_to_status_id" : 232923999183720450,
  "created_at" : "2012-08-07 19:40:42 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 31, 42 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232920761285881856",
  "geo" : { },
  "id_str" : "232923877087510528",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @RickyHassard @Alana_Doll I guarantee that on Thursday that the afore mentioned statement will be true - cream and all :)",
  "id" : 232923877087510528,
  "in_reply_to_status_id" : 232920761285881856,
  "created_at" : "2012-08-07 19:39:14 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jules",
      "screen_name" : "Julesb155",
      "indices" : [ 0, 10 ],
      "id_str" : "567275097",
      "id" : 567275097
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 11, 27 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232921878241611777",
  "geo" : { },
  "id_str" : "232923724423258112",
  "in_reply_to_user_id" : 567275097,
  "text" : "@Julesb155 @michaelnsimpson I have no doubt ;)",
  "id" : 232923724423258112,
  "in_reply_to_status_id" : 232921878241611777,
  "created_at" : "2012-08-07 19:38:38 +0000",
  "in_reply_to_screen_name" : "Julesb155",
  "in_reply_to_user_id_str" : "567275097",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 14, 25 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 26, 42 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232918679027843073",
  "geo" : { },
  "id_str" : "232919337839759360",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @alana_doll @michaelnsimpson come Thursday night all of you will have a price of me I side you :) x",
  "id" : 232919337839759360,
  "in_reply_to_status_id" : 232918679027843073,
  "created_at" : "2012-08-07 19:21:12 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 12, 28 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232911558748037121",
  "geo" : { },
  "id_str" : "232913029807878144",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @michaelnsimpson I am soooo excited.......",
  "id" : 232913029807878144,
  "in_reply_to_status_id" : 232911558748037121,
  "created_at" : "2012-08-07 18:56:08 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 12, 28 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Olivia",
      "screen_name" : "missoliviarose",
      "indices" : [ 29, 44 ],
      "id_str" : "19209237",
      "id" : 19209237
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 45, 59 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232891886191382528",
  "geo" : { },
  "id_str" : "232891995918581760",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @michaelnsimpson @missoliviarose @peter_omalley it is 1962!!!",
  "id" : 232891995918581760,
  "in_reply_to_status_id" : 232891886191382528,
  "created_at" : "2012-08-07 17:32:33 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 12, 28 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Olivia",
      "screen_name" : "missoliviarose",
      "indices" : [ 29, 44 ],
      "id_str" : "19209237",
      "id" : 19209237
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 45, 59 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232891151395467264",
  "geo" : { },
  "id_str" : "232891871892996096",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @michaelnsimpson @missoliviarose @peter_omalley I didn't want to be too harsh...",
  "id" : 232891871892996096,
  "in_reply_to_status_id" : 232891151395467264,
  "created_at" : "2012-08-07 17:32:03 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 17, 28 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Olivia",
      "screen_name" : "missoliviarose",
      "indices" : [ 29, 44 ],
      "id_str" : "19209237",
      "id" : 19209237
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 45, 59 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232890545284997120",
  "geo" : { },
  "id_str" : "232890950047899649",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @alana_doll @missoliviarose @peter_omalley takes a bow... takes a bow..",
  "id" : 232890950047899649,
  "in_reply_to_status_id" : 232890545284997120,
  "created_at" : "2012-08-07 17:28:24 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 1, 15 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 29, 35 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 67, 83 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232890088131018752",
  "text" : "\u201C@peter_omalley: Congrats to @swmcc on finally managing to 'twape' @michaelnsimpson. His persistence should be an inspiration to others! :o)",
  "id" : 232890088131018752,
  "created_at" : "2012-08-07 17:24:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 8, 15 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/U1aqdNWJ",
      "expanded_url" : "http:\/\/zachholman.com\/talk\/how-to-build-a-github",
      "display_url" : "zachholman.com\/talk\/how-to-bu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232775130605051904",
  "text" : "I &lt;3 @github.. Huge geek crush... and now this - http:\/\/t.co\/U1aqdNWJ - *geek swoon*",
  "id" : 232775130605051904,
  "created_at" : "2012-08-07 09:48:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232774870444941312",
  "text" : "So... I wrote several node.js thingies last night - one was a swear jar for me.. Decided to write in node.js for shiz and giggelz.. :)",
  "id" : 232774870444941312,
  "created_at" : "2012-08-07 09:47:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232772706905505792",
  "text" : "OH: \"I put myself in that position as i had the Stevie voice in my head\"",
  "id" : 232772706905505792,
  "created_at" : "2012-08-07 09:38:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232772637754023936",
  "text" : "OH \"i had some woman talking to me last night about buying a vibrator - i was nearly violently sick\"",
  "id" : 232772637754023936,
  "created_at" : "2012-08-07 09:38:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232594824291835904",
  "geo" : { },
  "id_str" : "232605260278009857",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu one time... one time....",
  "id" : 232605260278009857,
  "in_reply_to_status_id" : 232594824291835904,
  "created_at" : "2012-08-06 22:33:10 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232548230213287936",
  "geo" : { },
  "id_str" : "232550660254601216",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson ha fucking ha asshole",
  "id" : 232550660254601216,
  "in_reply_to_status_id" : 232548230213287936,
  "created_at" : "2012-08-06 18:56:12 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232538541903732736",
  "text" : "Right.. I swear I bought eggs on Thursday night..... I did.... Where are they though?",
  "id" : 232538541903732736,
  "created_at" : "2012-08-06 18:08:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232519635659014144",
  "geo" : { },
  "id_str" : "232531915440283648",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu Hmmmmmm.... So it is... FUCK OFF AND DIE BITCH - there :) Its okay stalkers - she's my sister and we have a special relationship",
  "id" : 232531915440283648,
  "in_reply_to_status_id" : 232519635659014144,
  "created_at" : "2012-08-06 17:41:43 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 13, 26 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232499690107723776",
  "geo" : { },
  "id_str" : "232500238332600321",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @stevebiscuit it is up your ass you sexy dutch bastard :D",
  "id" : 232500238332600321,
  "in_reply_to_status_id" : 232499690107723776,
  "created_at" : "2012-08-06 15:35:51 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 14, 26 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "THATISFIVEWORDS",
      "indices" : [ 52, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232491878791127041",
  "geo" : { },
  "id_str" : "232498378964103168",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @willemkokke FUCK YOU BOTH ASSHOLES.. #THATISFIVEWORDS",
  "id" : 232498378964103168,
  "in_reply_to_status_id" : 232491878791127041,
  "created_at" : "2012-08-06 15:28:27 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232486251356372993",
  "geo" : { },
  "id_str" : "232490098678190080",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit it is :D FUCK YOU PENDATIC ARSEHOLE! Is also four as it happens ;)",
  "id" : 232490098678190080,
  "in_reply_to_status_id" : 232486251356372993,
  "created_at" : "2012-08-06 14:55:33 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232486581984980992",
  "geo" : { },
  "id_str" : "232490008173486080",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard that gives me an idea.....",
  "id" : 232490008173486080,
  "in_reply_to_status_id" : 232486581984980992,
  "created_at" : "2012-08-06 14:55:12 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232489084545806336",
  "geo" : { },
  "id_str" : "232489596225720320",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke that would destroy me :D",
  "id" : 232489596225720320,
  "in_reply_to_status_id" : 232489084545806336,
  "created_at" : "2012-08-06 14:53:33 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232485526215720960",
  "text" : "Five words that fuck me off more than anything in the world.. \"Internet Explorer (Not Responding)... FUCK. OFF. AND. DIE.",
  "id" : 232485526215720960,
  "created_at" : "2012-08-06 14:37:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232466310905348096",
  "text" : "OH: \"I wouldn't race her for a fiver!!\" \"What does that mean?\" \"It means, I wouldn't race her for a fiver.\" \"Ohhhh....\"",
  "id" : 232466310905348096,
  "created_at" : "2012-08-06 13:21:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232466185340461056",
  "text" : "OH: \"She has so much core strength I bet you she could.....\"",
  "id" : 232466185340461056,
  "created_at" : "2012-08-06 13:20:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232464144622817280",
  "geo" : { },
  "id_str" : "232466083100114944",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @rickyhassard Fuck you lot... I made sense :D :D :D :D",
  "id" : 232466083100114944,
  "in_reply_to_status_id" : 232464144622817280,
  "created_at" : "2012-08-06 13:20:07 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232454719996579840",
  "geo" : { },
  "id_str" : "232454946241515520",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke fuck off!!!! so do I!!!!",
  "id" : 232454946241515520,
  "in_reply_to_status_id" : 232454719996579840,
  "created_at" : "2012-08-06 12:35:52 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter",
      "screen_name" : "PeterOMalley",
      "indices" : [ 75, 88 ],
      "id_str" : "45685217",
      "id" : 45685217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232446861397614595",
  "text" : "Thanks very much to Mrs O'Malley - she made the bestest cheese bread.. \/cc @peteromalley",
  "id" : 232446861397614595,
  "created_at" : "2012-08-06 12:03:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232430543797641216",
  "geo" : { },
  "id_str" : "232434160109756416",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop yeah - the best way. Don't tie down to one language.",
  "id" : 232434160109756416,
  "in_reply_to_status_id" : 232430543797641216,
  "created_at" : "2012-08-06 11:13:16 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232421754327408640",
  "geo" : { },
  "id_str" : "232429922277281792",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop Yeah. I've moved away from PHP for anything new though. Loving Rails and Node at the mo.",
  "id" : 232429922277281792,
  "in_reply_to_status_id" : 232421754327408640,
  "created_at" : "2012-08-06 10:56:26 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232418231531487232",
  "geo" : { },
  "id_str" : "232420098894356480",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop I wish PHP was Rails - would make life so much nicer and happier for me right now.",
  "id" : 232420098894356480,
  "in_reply_to_status_id" : 232418231531487232,
  "created_at" : "2012-08-06 10:17:24 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Waxon",
      "indices" : [ 46, 52 ]
    }, {
      "text" : "STRIKEFIRST",
      "indices" : [ 77, 89 ]
    }, {
      "text" : "Banzai",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232152486708920320",
  "geo" : { },
  "id_str" : "232159180511911937",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 Brilliant film :) Good holiday? #Waxon...waxoff.Waxon...waxoff #STRIKEFIRST.STRIKEHARD.NOMERCYSIR #Banzai,Daniel-san",
  "id" : 232159180511911937,
  "in_reply_to_status_id" : 232152486708920320,
  "created_at" : "2012-08-05 17:00:36 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232142756812845056",
  "geo" : { },
  "id_str" : "232142881576599552",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues *swooooon* :)",
  "id" : 232142881576599552,
  "in_reply_to_status_id" : 232142756812845056,
  "created_at" : "2012-08-05 15:55:50 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232142039758802944",
  "geo" : { },
  "id_str" : "232142480945082369",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues what?!?!? What!!?! Luckily your last tweet discussed the butternut squash soup so your awesomeness is still intact.",
  "id" : 232142480945082369,
  "in_reply_to_status_id" : 232142039758802944,
  "created_at" : "2012-08-05 15:54:15 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232137761027670016",
  "geo" : { },
  "id_str" : "232141663869480961",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues karate kid is on channel 5. Watch that instead. :)",
  "id" : 232141663869480961,
  "in_reply_to_status_id" : 232137761027670016,
  "created_at" : "2012-08-05 15:51:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sweeptheleg",
      "indices" : [ 46, 58 ]
    }, {
      "text" : "nomercy",
      "indices" : [ 59, 67 ]
    }, {
      "text" : "puthiminabodybag",
      "indices" : [ 68, 85 ]
    }, {
      "text" : "finishim",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "cranetechniquenoadefence",
      "indices" : [ 96, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232140063918657536",
  "text" : "Nope. Karate Kid is on channel 5. No Tesco :) #sweeptheleg #nomercy #puthiminabodybag #finishim #cranetechniquenoadefence (until the sequel)",
  "id" : 232140063918657536,
  "created_at" : "2012-08-05 15:44:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232138317221732352",
  "geo" : { },
  "id_str" : "232138541038198784",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 you put them to room temp for an hour or do before cooking... Can't wait to scoff one",
  "id" : 232138541038198784,
  "in_reply_to_status_id" : 232138317221732352,
  "created_at" : "2012-08-05 15:38:35 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nomnomnom",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232137649480138752",
  "text" : "Apparently if you prod me enough I end up going to Tesco on a Sunday.. Got two rib eye steaks getting to room temp now as well. #nomnomnom",
  "id" : 232137649480138752,
  "created_at" : "2012-08-05 15:35:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "olymics2012",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232129331588120576",
  "text" : "I've watched every second of this match and am on the edge of my seat! #olymics2012",
  "id" : 232129331588120576,
  "created_at" : "2012-08-05 15:02:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232079673121714178",
  "geo" : { },
  "id_str" : "232080302065975298",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke it always makes me take a double look at the code for no good reason. Winds me up :) Great minds eh? ;)",
  "id" : 232080302065975298,
  "in_reply_to_status_id" : 232079673121714178,
  "created_at" : "2012-08-05 11:47:10 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codeocd",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232070094115704832",
  "text" : "#codeocd 80 character limit is a must.. And no assignments in conditions either... Grrrrr... Makes me whince looking at such things.",
  "id" : 232070094115704832,
  "created_at" : "2012-08-05 11:06:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Eaton",
      "screen_name" : "georgeeaton",
      "indices" : [ 3, 15 ],
      "id_str" : "20668369",
      "id" : 20668369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231865760404873217",
  "text" : "RT @georgeeaton: Guessing the Daily Mail will quietly forget that it called Mo Farah a \"plastic Brit\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231859281144713216",
    "text" : "Guessing the Daily Mail will quietly forget that it called Mo Farah a \"plastic Brit\".",
    "id" : 231859281144713216,
    "created_at" : "2012-08-04 21:08:55 +0000",
    "user" : {
      "name" : "George Eaton",
      "screen_name" : "georgeeaton",
      "protected" : false,
      "id_str" : "20668369",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1151721372\/70596_61301825_7925641_n_normal.jpg",
      "id" : 20668369,
      "verified" : false
    }
  },
  "id" : 231865760404873217,
  "created_at" : "2012-08-04 21:34:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Collin",
      "screen_name" : "robbiereviews",
      "indices" : [ 3, 17 ],
      "id_str" : "17835068",
      "id" : 17835068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231865679291236353",
  "text" : "RT @robbiereviews: Really enjoying the novelty of watching likeable, talented people on TV on a Saturday night.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231858197437235201",
    "text" : "Really enjoying the novelty of watching likeable, talented people on TV on a Saturday night.",
    "id" : 231858197437235201,
    "created_at" : "2012-08-04 21:04:36 +0000",
    "user" : {
      "name" : "Robbie Collin",
      "screen_name" : "robbiereviews",
      "protected" : false,
      "id_str" : "17835068",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3074230907\/561e1c18dd26a8ebf382088e3d747447_normal.jpeg",
      "id" : 17835068,
      "verified" : false
    }
  },
  "id" : 231865679291236353,
  "created_at" : "2012-08-04 21:34:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 65, 73 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231858146644217857",
  "text" : "Is it wrong that I'm looking forward to the YouTube talks on how @twitter has coped with event data load like the olympics?",
  "id" : 231858146644217857,
  "created_at" : "2012-08-04 21:04:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 1, 8 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Jessica Ennis-Hill",
      "screen_name" : "J_Ennis",
      "indices" : [ 83, 91 ],
      "id_str" : "156380350",
      "id" : 156380350
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rejoco\/status\/231856321421508608\/photo\/1",
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/fcr2yAfq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aze4GI5CAAE-PHA.jpg",
      "id_str" : "231856321438285825",
      "id" : 231856321438285825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aze4GI5CAAE-PHA.jpg",
      "sizes" : [ {
        "h" : 119,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 643
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 643
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fcr2yAfq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231856683331235841",
  "text" : "\u201C@rejoco: this is what Mo Farah winning gold does to twitter already bubbling from @j_ennis http:\/\/t.co\/fcr2yAfq\u201D I &lt;3 metrics like that",
  "id" : 231856683331235841,
  "created_at" : "2012-08-04 20:58:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "olymics2012",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231854161241718784",
  "text" : "I am loving this! #olymics2012",
  "id" : 231854161241718784,
  "created_at" : "2012-08-04 20:48:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231800363345387520",
  "text" : "I spent the last two hours looking at a load of peeps go round a fucking wooden floor over and over... Addictive :) Loving the Olympics..",
  "id" : 231800363345387520,
  "created_at" : "2012-08-04 17:14:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 31, 43 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 44, 55 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231784162921693186",
  "geo" : { },
  "id_str" : "231800196361768960",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @michaelnsimpson @niall_adams @alana_doll You fucking love it.......",
  "id" : 231800196361768960,
  "in_reply_to_status_id" : 231784162921693186,
  "created_at" : "2012-08-04 17:14:08 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaryMcCall",
      "screen_name" : "MaryTreatTicket",
      "indices" : [ 0, 16 ],
      "id_str" : "512178113",
      "id" : 512178113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231754007532675072",
  "geo" : { },
  "id_str" : "231766579057156098",
  "in_reply_to_user_id" : 512178113,
  "text" : "@MaryTreatTicket three different people on just above min wage to get one pair of shoes. How are they still in business?",
  "id" : 231766579057156098,
  "in_reply_to_status_id" : 231754007532675072,
  "created_at" : "2012-08-04 15:00:33 +0000",
  "in_reply_to_screen_name" : "MaryTreatTicket",
  "in_reply_to_user_id_str" : "512178113",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231760331536486401",
  "geo" : { },
  "id_str" : "231760471521374210",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ Sons of Anarchy style?",
  "id" : 231760471521374210,
  "in_reply_to_status_id" : 231760331536486401,
  "created_at" : "2012-08-04 14:36:16 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231760355112677376",
  "text" : "Going to start Breaking Bad Season 2 episode 3 again... I have heard good things...",
  "id" : 231760355112677376,
  "created_at" : "2012-08-04 14:35:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 3, 14 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 16, 22 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 23, 39 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crimewatch",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/Wu8xzfj2",
      "expanded_url" : "http:\/\/twitpic.com\/afb392",
      "display_url" : "twitpic.com\/afb392"
    } ]
  },
  "geo" : { },
  "id_str" : "231692615224029184",
  "text" : "RT @Alana_Doll: @swmcc @michaelnsimpson have you seen this man #crimewatch http:\/\/t.co\/Wu8xzfj2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Mike ",
        "screen_name" : "michaelnsimpson",
        "indices" : [ 7, 23 ],
        "id_str" : "311597138",
        "id" : 311597138
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "crimewatch",
        "indices" : [ 47, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/Wu8xzfj2",
        "expanded_url" : "http:\/\/twitpic.com\/afb392",
        "display_url" : "twitpic.com\/afb392"
      } ]
    },
    "in_reply_to_status_id_str" : "231479061829013505",
    "geo" : { },
    "id_str" : "231691336250703872",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @michaelnsimpson have you seen this man #crimewatch http:\/\/t.co\/Wu8xzfj2",
    "id" : 231691336250703872,
    "in_reply_to_status_id" : 231479061829013505,
    "created_at" : "2012-08-04 10:01:33 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "protected" : false,
      "id_str" : "67130324",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3578323065\/bb177ebc2b37f1d2ee6f3eec1af258d0_normal.jpeg",
      "id" : 67130324,
      "verified" : false
    }
  },
  "id" : 231692615224029184,
  "created_at" : "2012-08-04 10:06:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 12, 28 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231691336250703872",
  "geo" : { },
  "id_str" : "231692473473327104",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @michaelnsimpson This is your sistine chapel...",
  "id" : 231692473473327104,
  "in_reply_to_status_id" : 231691336250703872,
  "created_at" : "2012-08-04 10:06:04 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231500989058928641",
  "text" : "RT @HaVoCT5: this is my 100th tweet, and also me realising what u learn at University is fuck all to do with the real world!....",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230439274787528704",
    "text" : "this is my 100th tweet, and also me realising what u learn at University is fuck all to do with the real world!....",
    "id" : 230439274787528704,
    "created_at" : "2012-07-31 23:06:19 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 231500989058928641,
  "created_at" : "2012-08-03 21:25:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231497404057276417",
  "geo" : { },
  "id_str" : "231500693213679616",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ I know you'd think it wasn't her native language ;)",
  "id" : 231500693213679616,
  "in_reply_to_status_id" : 231497404057276417,
  "created_at" : "2012-08-03 21:24:00 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 17, 28 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231466506096087040",
  "geo" : { },
  "id_str" : "231479061829013505",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @alana_doll I love that woman.... If she pulls this off then Alana you are a genius...",
  "id" : 231479061829013505,
  "in_reply_to_status_id" : 231466506096087040,
  "created_at" : "2012-08-03 19:58:03 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 30, 41 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 46, 52 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231466111865090048",
  "text" : "\u201C@michaelnsimpson: So tonight @Alana_Doll saw @swmcc sex face, still not quite sure how she took it\u201D Yeah, yeah she did!! :D :D :D :D",
  "id" : 231466111865090048,
  "created_at" : "2012-08-03 19:06:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 10, 23 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231343079616049152",
  "text" : "Awesome.. @RickyHassard just made me laugh out loud.. Which isn't easily done today - but by fuck he did it :D :D :D :D :D :D",
  "id" : 231343079616049152,
  "created_at" : "2012-08-03 10:57:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231329717763063808",
  "text" : "Also - bad call on Total Recall being released in the States and not in the UK... If only there was a way I could see it today ;)",
  "id" : 231329717763063808,
  "created_at" : "2012-08-03 10:04:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231329266518876160",
  "text" : "There is a meeting going on in the next room to me.. Am tempted to sit in and see how many time i utter the words \"fucking wank\".",
  "id" : 231329266518876160,
  "created_at" : "2012-08-03 10:02:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 0, 9 ],
      "id_str" : "9488072",
      "id" : 9488072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231320050756354048",
  "geo" : { },
  "id_str" : "231320523789975552",
  "in_reply_to_user_id" : 9488072,
  "text" : "@shylands same with me only the other way about... Really pisses me off... And then my name being pronounced as \"McCullagh\" not \"McCullough\"",
  "id" : 231320523789975552,
  "in_reply_to_status_id" : 231320050756354048,
  "created_at" : "2012-08-03 09:28:05 +0000",
  "in_reply_to_screen_name" : "shylands",
  "in_reply_to_user_id_str" : "9488072",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MultiFunctionalApp",
      "screen_name" : "MultiFunctAPP",
      "indices" : [ 0, 14 ],
      "id_str" : "529437619",
      "id" : 529437619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231143002779832320",
  "geo" : { },
  "id_str" : "231300806358466561",
  "in_reply_to_user_id" : 529437619,
  "text" : "@MultiFunctAPP none on the Newtownards Road. Only open positions are for the Hillsborough office.",
  "id" : 231300806358466561,
  "in_reply_to_status_id" : 231143002779832320,
  "created_at" : "2012-08-03 08:09:44 +0000",
  "in_reply_to_screen_name" : "MultiFunctAPP",
  "in_reply_to_user_id_str" : "529437619",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/231283651374100481\/photo\/1",
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/Qjxm7K84",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzWvQWrCMAA_6y-.jpg",
      "id_str" : "231283651378294784",
      "id" : 231283651378294784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzWvQWrCMAA_6y-.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/Qjxm7K84"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231283651374100481",
  "text" : "He used to be so polite :) http:\/\/t.co\/Qjxm7K84",
  "id" : 231283651374100481,
  "created_at" : "2012-08-03 07:01:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231142301940977664",
  "text" : "Car keys - WHERE THE FUCK ARE YOU??????",
  "id" : 231142301940977664,
  "created_at" : "2012-08-02 21:39:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MultiFunctionalApp",
      "screen_name" : "MultiFunctAPP",
      "indices" : [ 0, 14 ],
      "id_str" : "529437619",
      "id" : 529437619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231093147260821504",
  "geo" : { },
  "id_str" : "231130792082956288",
  "in_reply_to_user_id" : 529437619,
  "text" : "@MultiFunctAPP main office is in Hillsborough yes :)",
  "id" : 231130792082956288,
  "in_reply_to_status_id" : 231093147260821504,
  "created_at" : "2012-08-02 20:54:09 +0000",
  "in_reply_to_screen_name" : "MultiFunctAPP",
  "in_reply_to_user_id_str" : "529437619",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230980328456593408",
  "geo" : { },
  "id_str" : "230980650621075457",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee enjoy - feel the burn!",
  "id" : 230980650621075457,
  "in_reply_to_status_id" : 230980328456593408,
  "created_at" : "2012-08-02 10:57:33 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230977908955574273",
  "text" : "An apache helicopter is awesome....",
  "id" : 230977908955574273,
  "created_at" : "2012-08-02 10:46:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230970803456466944",
  "text" : "OH: \"YOU ARE NOT GOING TO SHIT IN  MY APARTMENT!\"",
  "id" : 230970803456466944,
  "created_at" : "2012-08-02 10:18:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230964888875458560",
  "text" : "I really want to play truth or dare right now.....I am 'ballsy'... TED",
  "id" : 230964888875458560,
  "created_at" : "2012-08-02 09:54:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230964136635416576",
  "text" : "I really want to play truth or date right now...... I am 'ballsy'... TED",
  "id" : 230964136635416576,
  "created_at" : "2012-08-02 09:51:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Adams",
      "screen_name" : "tracy2710",
      "indices" : [ 0, 10 ],
      "id_str" : "241879307",
      "id" : 241879307
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 11, 23 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230619665011965952",
  "geo" : { },
  "id_str" : "230748373848834048",
  "in_reply_to_user_id" : 241879307,
  "text" : "@tracy2710 @niall_adams battery has ran out. He says he loves you loads. So do I :) x",
  "id" : 230748373848834048,
  "in_reply_to_status_id" : 230619665011965952,
  "created_at" : "2012-08-01 19:34:34 +0000",
  "in_reply_to_screen_name" : "tracy2710",
  "in_reply_to_user_id_str" : "241879307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 1, 16 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 33, 39 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Men's Humor",
      "screen_name" : "MensHumor",
      "indices" : [ 42, 52 ],
      "id_str" : "355741893",
      "id" : 355741893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230694615936798720",
  "text" : "\u201C@annette_mccull: Especially you @swmcc  \u201C@MensHumor: My coworkers irritate me on Wednesday...and any other day ending in \"y\".\u201D\u201D she &lt;3's me",
  "id" : 230694615936798720,
  "created_at" : "2012-08-01 16:00:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230630992531042304",
  "text" : "So a recruiter just asked me if I was interested in a job that my company is currently looking for.. *facepalm*",
  "id" : 230630992531042304,
  "created_at" : "2012-08-01 11:48:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230623620345516032",
  "geo" : { },
  "id_str" : "230623879163432962",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher screw you - you are doing my sister. We aren't mates ;) Seriously though - if you need a hand give me a shout ;)",
  "id" : 230623879163432962,
  "in_reply_to_status_id" : 230623620345516032,
  "created_at" : "2012-08-01 11:19:52 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230622637292933120",
  "geo" : { },
  "id_str" : "230622857061883904",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher it is stable - but generally so out of date. Ubuntu and debian are just much nicer IMHO.",
  "id" : 230622857061883904,
  "in_reply_to_status_id" : 230622637292933120,
  "created_at" : "2012-08-01 11:15:48 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230621774646226944",
  "geo" : { },
  "id_str" : "230621920570253312",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher its just awful I think. Very out of date. Ubuntu or Debian is my distro of choice.",
  "id" : 230621920570253312,
  "in_reply_to_status_id" : 230621774646226944,
  "created_at" : "2012-08-01 11:12:05 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230615941954805760",
  "geo" : { },
  "id_str" : "230616620425420800",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher centos is awful :(",
  "id" : 230616620425420800,
  "in_reply_to_status_id" : 230615941954805760,
  "created_at" : "2012-08-01 10:51:01 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230614003775307777",
  "geo" : { },
  "id_str" : "230614181169221632",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher what distro you using? can you not use ssh to get into it and install what you want? :)",
  "id" : 230614181169221632,
  "in_reply_to_status_id" : 230614003775307777,
  "created_at" : "2012-08-01 10:41:20 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230600162383384576",
  "geo" : { },
  "id_str" : "230611586786680832",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher wrong. It isn't complicated - just different. And better. So man up!",
  "id" : 230611586786680832,
  "in_reply_to_status_id" : 230600162383384576,
  "created_at" : "2012-08-01 10:31:01 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]