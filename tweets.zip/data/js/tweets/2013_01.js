Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297106088761909248",
  "geo" : { },
  "id_str" : "297111131871404032",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu FUCK. SAKE.",
  "id" : 297111131871404032,
  "in_reply_to_status_id" : 297106088761909248,
  "created_at" : "2013-01-31 22:36:28 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297084579490168833",
  "text" : "Just home. That was not fun....",
  "id" : 297084579490168833,
  "created_at" : "2013-01-31 20:50:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297075808873357312",
  "geo" : { },
  "id_str" : "297084483935559680",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning you use netbeans and navicat. Therefore your opinion is wrong by default ;)",
  "id" : 297084483935559680,
  "in_reply_to_status_id" : 297075808873357312,
  "created_at" : "2013-01-31 20:50:35 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/297072670179213312\/photo\/1",
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/1wV6i1NR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BB9qBQLCQAEqfbL.jpg",
      "id_str" : "297072670183407617",
      "id" : 297072670183407617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB9qBQLCQAEqfbL.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/1wV6i1NR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297072670179213312",
  "text" : "Really Argos... Opera as the browser? Why? http:\/\/t.co\/1wV6i1NR",
  "id" : 297072670179213312,
  "created_at" : "2013-01-31 20:03:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nico Fell",
      "screen_name" : "nicofell",
      "indices" : [ 0, 9 ],
      "id_str" : "23814128",
      "id" : 23814128
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dedication",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296962388807262208",
  "geo" : { },
  "id_str" : "297002253900996608",
  "in_reply_to_user_id" : 23814128,
  "text" : "@nicofell I did mine from season2 to season5 in the space of a week and a half. #dedication",
  "id" : 297002253900996608,
  "in_reply_to_status_id" : 296962388807262208,
  "created_at" : "2013-01-31 15:23:50 +0000",
  "in_reply_to_screen_name" : "nicofell",
  "in_reply_to_user_id_str" : "23814128",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nico Fell",
      "screen_name" : "nicofell",
      "indices" : [ 0, 9 ],
      "id_str" : "23814128",
      "id" : 23814128
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dedication",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296962388807262208",
  "geo" : { },
  "id_str" : "297002197760233474",
  "in_reply_to_user_id" : 23814128,
  "text" : "@nicofell I did mine from season2 to season5 in the space of a week and a half. #dedication",
  "id" : 297002197760233474,
  "in_reply_to_status_id" : 296962388807262208,
  "created_at" : "2013-01-31 15:23:36 +0000",
  "in_reply_to_screen_name" : "nicofell",
  "in_reply_to_user_id_str" : "23814128",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 59 ],
      "url" : "https:\/\/t.co\/R1irRaEH",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/time-butler\/id460856856?mt=12",
      "display_url" : "itunes.apple.com\/us\/app\/time-bu\u2026"
    }, {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/4ezvw06A",
      "expanded_url" : "http:\/\/yfrog.com\/obfh2np",
      "display_url" : "yfrog.com\/obfh2np"
    } ]
  },
  "geo" : { },
  "id_str" : "297001986363125760",
  "text" : "Started to use Time Butler for work - https:\/\/t.co\/R1irRaEH - this sounds about right so far today. http:\/\/t.co\/4ezvw06A",
  "id" : 297001986363125760,
  "created_at" : "2013-01-31 15:22:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 59 ],
      "url" : "https:\/\/t.co\/R1irRaEH",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/time-butler\/id460856856?mt=12",
      "display_url" : "itunes.apple.com\/us\/app\/time-bu\u2026"
    }, {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/4ezvw06A",
      "expanded_url" : "http:\/\/yfrog.com\/obfh2np",
      "display_url" : "yfrog.com\/obfh2np"
    } ]
  },
  "geo" : { },
  "id_str" : "297001937293934592",
  "text" : "Started to use Time Butler for work - https:\/\/t.co\/R1irRaEH - this sounds about right so far today. http:\/\/t.co\/4ezvw06A",
  "id" : 297001937293934592,
  "created_at" : "2013-01-31 15:22:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "luvit",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296949635203878912",
  "text" : "I swear - i am gonna order my lunch in JSON the amount I have seen these last few days :) #luvit :)",
  "id" : 296949635203878912,
  "created_at" : "2013-01-31 11:54:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296946736226783232",
  "text" : "OH: \"Those sleeping tablets are quite dangerous. Once xxxx used them and she woke up the next morning with no recollection that we had sex\"",
  "id" : 296946736226783232,
  "created_at" : "2013-01-31 11:43:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 25, 34 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296937219741061120",
  "text" : "Got fucked over there by @davehedo - feel dirty\u2026 Never again\u2026. Bastard :)",
  "id" : 296937219741061120,
  "created_at" : "2013-01-31 11:05:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296926264621686784",
  "text" : "Mmmmmm just got pissed off with email again. All work email is now read in mutt... And so it continues.",
  "id" : 296926264621686784,
  "created_at" : "2013-01-31 10:21:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 3, 17 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 19, 34 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 106, 112 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296917610946252800",
  "text" : "RT @peter_omalley: @annette_mccull If there isn't  any swear words in his speech then I refuse to believe @swmcc had any part in writing ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Annette",
        "screen_name" : "annette_mccull",
        "indices" : [ 0, 15 ],
        "id_str" : "161635397",
        "id" : 161635397
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 87, 93 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "296916705928683520",
    "geo" : { },
    "id_str" : "296917529778089984",
    "in_reply_to_user_id" : 804717,
    "text" : "@annette_mccull If there isn't  any swear words in his speech then I refuse to believe @swmcc had any part in writing it himself!! :)",
    "id" : 296917529778089984,
    "in_reply_to_status_id" : 296916705928683520,
    "created_at" : "2013-01-31 09:47:10 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "protected" : false,
      "id_str" : "437697624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1706604039\/eC7Ba2I7_normal",
      "id" : 437697624,
      "verified" : false
    }
  },
  "id" : 296917610946252800,
  "created_at" : "2013-01-31 09:47:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296914312004521984",
  "geo" : { },
  "id_str" : "296916705928683520",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull euggggh photos, forgot about them :( Speeches - meh not too worried about that.",
  "id" : 296916705928683520,
  "in_reply_to_status_id" : 296914312004521984,
  "created_at" : "2013-01-31 09:43:53 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296916500651077632",
  "text" : "OH: \"If you'd have come in here like you are now I'd have just put you in the cock category, but you came in here as a nice guy\"",
  "id" : 296916500651077632,
  "created_at" : "2013-01-31 09:43:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 3, 13 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/0uYybx94",
      "expanded_url" : "http:\/\/www.stephenmccalden.com\/blog\/2013\/01\/30\/fmc-best-wedding-rap-song\/",
      "display_url" : "stephenmccalden.com\/blog\/2013\/01\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296732105096974336",
  "text" : "RT @smccalden: FMC : 'Best Wedding Rap Song' for Paul getting married Sat http:\/\/t.co\/0uYybx94",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/0uYybx94",
        "expanded_url" : "http:\/\/www.stephenmccalden.com\/blog\/2013\/01\/30\/fmc-best-wedding-rap-song\/",
        "display_url" : "stephenmccalden.com\/blog\/2013\/01\/3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "296729422432722945",
    "text" : "FMC : 'Best Wedding Rap Song' for Paul getting married Sat http:\/\/t.co\/0uYybx94",
    "id" : 296729422432722945,
    "created_at" : "2013-01-30 21:19:41 +0000",
    "user" : {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "protected" : false,
      "id_str" : "169048119",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1169599362\/5bccf87c-8216-4684-bad8-61ad974596df_normal.png",
      "id" : 169048119,
      "verified" : false
    }
  },
  "id" : 296732105096974336,
  "created_at" : "2013-01-30 21:30:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/5UjAUp3M",
      "expanded_url" : "http:\/\/instagr.am\/p\/VHxHR-hX92\/",
      "display_url" : "instagr.am\/p\/VHxHR-hX92\/"
    } ]
  },
  "geo" : { },
  "id_str" : "296717038955659264",
  "text" : "The oul fella http:\/\/t.co\/5UjAUp3M",
  "id" : 296717038955659264,
  "created_at" : "2013-01-30 20:30:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 3, 10 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296707875395481600",
  "text" : "RT @holman: For every person you\u2019ll upset by swearing, there\u2019ll be a hundred cringing when you use weasel words like \u201Cfrick\u201D. Just say fuck.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296703339696111617",
    "text" : "For every person you\u2019ll upset by swearing, there\u2019ll be a hundred cringing when you use weasel words like \u201Cfrick\u201D. Just say fuck.",
    "id" : 296703339696111617,
    "created_at" : "2013-01-30 19:36:03 +0000",
    "user" : {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "protected" : false,
      "id_str" : "11322372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1444317557\/holman_normal.png",
      "id" : 11322372,
      "verified" : false
    }
  },
  "id" : 296707875395481600,
  "created_at" : "2013-01-30 19:54:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toughcrowd",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296612842147303424",
  "geo" : { },
  "id_str" : "296621447370121218",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid not too worried about the speech. However several edits will have to be done now that the rehearsal has been done. #toughcrowd",
  "id" : 296621447370121218,
  "in_reply_to_status_id" : 296612842147303424,
  "created_at" : "2013-01-30 14:10:38 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankfuck",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296590973507608577",
  "text" : "Way to pick up these suits - last ballixy part of the wedding duties - then its just eating and drinking. #thankfuck",
  "id" : 296590973507608577,
  "created_at" : "2013-01-30 12:09:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keavy",
      "screen_name" : "keavy",
      "indices" : [ 3, 9 ],
      "id_str" : "8605362",
      "id" : 8605362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296392338140459010",
  "text" : "RT @keavy: I miss the NHS, and a simple focus on, y'know, the patient's health. The system here seems so many layers of money orientated ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296361087224397825",
    "text" : "I miss the NHS, and a simple focus on, y'know, the patient's health. The system here seems so many layers of money orientated crazy.",
    "id" : 296361087224397825,
    "created_at" : "2013-01-29 20:56:03 +0000",
    "user" : {
      "name" : "keavy",
      "screen_name" : "keavy",
      "protected" : false,
      "id_str" : "8605362",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1252714941\/keavy_headshot_500_normal.jpeg",
      "id" : 8605362,
      "verified" : false
    }
  },
  "id" : 296392338140459010,
  "created_at" : "2013-01-29 23:00:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/11KAYBw8",
      "expanded_url" : "http:\/\/instagr.am\/p\/VFCV3ehX1H\/",
      "display_url" : "instagr.am\/p\/VFCV3ehX1H\/"
    } ]
  },
  "geo" : { },
  "id_str" : "296332864881033218",
  "text" : "Kate made a lovely dinner. Thank you very much. http:\/\/t.co\/11KAYBw8",
  "id" : 296332864881033218,
  "created_at" : "2013-01-29 19:03:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/m9wuuYQm",
      "expanded_url" : "http:\/\/instagr.am\/p\/VEpiigBXyY\/",
      "display_url" : "instagr.am\/p\/VEpiigBXyY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "296278157844172800",
  "text" : "My work mug that the boss bought me :) http:\/\/t.co\/m9wuuYQm",
  "id" : 296278157844172800,
  "created_at" : "2013-01-29 15:26:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/8JY4Zrgs",
      "expanded_url" : "http:\/\/instagr.am\/p\/VEC2QvhX87\/",
      "display_url" : "instagr.am\/p\/VEC2QvhX87\/"
    } ]
  },
  "geo" : { },
  "id_str" : "296193057450237952",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel is a champion among men. http:\/\/t.co\/8JY4Zrgs",
  "id" : 296193057450237952,
  "created_at" : "2013-01-29 09:48:22 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 83, 90 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295639957542932481",
  "text" : "I love my new job - has to be said... Work with good people - but I really do miss @srushe :(",
  "id" : 295639957542932481,
  "created_at" : "2013-01-27 21:10:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ZeroDarkThirty",
      "indices" : [ 13, 28 ]
    }, {
      "text" : "GetGlue",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/JbImHoy0",
      "expanded_url" : "http:\/\/getglue.com\/movies\/zero_dark_thirty\/kathryn_bigelow?s=t&ref=swmcc",
      "display_url" : "getglue.com\/movies\/zero_da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295547875314790401",
  "text" : "I'm watching #ZeroDarkThirty with 52 others on #GetGlue http:\/\/t.co\/JbImHoy0",
  "id" : 295547875314790401,
  "created_at" : "2013-01-27 15:04:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetGlue",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/LneFc79Q",
      "expanded_url" : "http:\/\/getglue.com\/stickers\/turner\/the_19th_annual_sag_awards_film_nominees?s=ts&ref=swmcc",
      "display_url" : "getglue.com\/stickers\/turne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295547875428028417",
  "text" : "I unlocked the The 19th Annual SAG Awards Film Nominees sticker on #GetGlue! http:\/\/t.co\/LneFc79Q",
  "id" : 295547875428028417,
  "created_at" : "2013-01-27 15:04:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 0, 8 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295325303000145923",
  "geo" : { },
  "id_str" : "295325799660285952",
  "in_reply_to_user_id" : 120378343,
  "text" : "@kouphax hope to hell you are in the front room.. just sayin like ;)",
  "id" : 295325799660285952,
  "in_reply_to_status_id" : 295325303000145923,
  "created_at" : "2013-01-27 00:22:12 +0000",
  "in_reply_to_screen_name" : "kouphax",
  "in_reply_to_user_id_str" : "120378343",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295319504509095936",
  "geo" : { },
  "id_str" : "295319721589477376",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning good :) Enjoy :)",
  "id" : 295319721589477376,
  "in_reply_to_status_id" : 295319504509095936,
  "created_at" : "2013-01-26 23:58:03 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295319319594795008",
  "text" : "Also it seems Derry people can keep time it seems *cringe*",
  "id" : 295319319594795008,
  "created_at" : "2013-01-26 23:56:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295319196634578944",
  "text" : "That audience is as dead as fuck... As much as I don't like yon prick that's a good song....",
  "id" : 295319196634578944,
  "created_at" : "2013-01-26 23:55:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295317382124154881",
  "text" : "Gary Lightbody - the wannabe Bono... I would never tire of slapping that face! Also he's about as Derry as my cock!",
  "id" : 295317382124154881,
  "created_at" : "2013-01-26 23:48:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295315732122722304",
  "text" : "I would love it if the three priests just did a quick version of my lovely horse.",
  "id" : 295315732122722304,
  "created_at" : "2013-01-26 23:42:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295300161104662529",
  "text" : "Fuck sake. Phil Coulter being followed by Nadine Coyle.... Something wrong with this...",
  "id" : 295300161104662529,
  "created_at" : "2013-01-26 22:40:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295298946207739904",
  "text" : "I gotta say it but I *heart* Phil Coulter. Can do without the singing though.",
  "id" : 295298946207739904,
  "created_at" : "2013-01-26 22:35:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/295291083817111554\/photo\/1",
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/AfSADpm6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBkVrR0CUAAoan0.png",
      "id_str" : "295291083829694464",
      "id" : 295291083829694464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBkVrR0CUAAoan0.png",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/AfSADpm6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295291083817111554",
  "text" : "Yup - this is about right... Think I need to watch my language on this twitter thing a bit... http:\/\/t.co\/AfSADpm6",
  "id" : 295291083817111554,
  "created_at" : "2013-01-26 22:04:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetcloud.icodeforlove.com\/\" rel=\"nofollow\"\u003ETweet Cloud\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TweetCloud",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/qgaI49V6",
      "expanded_url" : "http:\/\/w33.us\/dsvq",
      "display_url" : "w33.us\/dsvq"
    }, {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/4gNVXHhb",
      "expanded_url" : "http:\/\/twitpic.com\/byiu1s",
      "display_url" : "twitpic.com\/byiu1s"
    } ]
  },
  "geo" : { },
  "id_str" : "295290629540425728",
  "text" : "Just generated a #TweetCloud, my top words are: fuck, time, christmas - http:\/\/t.co\/qgaI49V6 (http:\/\/t.co\/4gNVXHhb)",
  "id" : 295290629540425728,
  "created_at" : "2013-01-26 22:02:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Warrior",
      "indices" : [ 13, 21 ]
    }, {
      "text" : "GetGlue",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/0jIVRLug",
      "expanded_url" : "http:\/\/getglue.com\/movies\/warrior\/gavin_oconnor?s=t&ref=swmcc",
      "display_url" : "getglue.com\/movies\/warrior\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295260987475501056",
  "text" : "I'm watching #Warrior on #GetGlue http:\/\/t.co\/0jIVRLug",
  "id" : 295260987475501056,
  "created_at" : "2013-01-26 20:04:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295232966857224192",
  "geo" : { },
  "id_str" : "295233162194345985",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson yes. why yes it is. The dude that fucked me over with that show Lost and is doing the Star Trek films. Ball cock :(",
  "id" : 295233162194345985,
  "in_reply_to_status_id" : 295232966857224192,
  "created_at" : "2013-01-26 18:14:05 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295205322858041344",
  "text" : "Disney...... Fuck you!!!!!!",
  "id" : 295205322858041344,
  "created_at" : "2013-01-26 16:23:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetGlue",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/HZCHqmO7",
      "expanded_url" : "http:\/\/getglue.com\/stickers\/experiment_subject?s=ts&ref=swmcc",
      "display_url" : "getglue.com\/stickers\/exper\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294917265466478592",
  "text" : "I unlocked the Experiment Subject sticker on #GetGlue! http:\/\/t.co\/HZCHqmO7",
  "id" : 294917265466478592,
  "created_at" : "2013-01-25 21:18:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fringe",
      "indices" : [ 13, 20 ]
    }, {
      "text" : "GetGlue",
      "indices" : [ 40, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/t20wUua7",
      "expanded_url" : "http:\/\/getglue.com\/tv_shows\/fringe?s=t&ref=swmcc",
      "display_url" : "getglue.com\/tv_shows\/fring\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294917265218994176",
  "text" : "I'm watching #Fringe with 163 others on #GetGlue http:\/\/t.co\/t20wUua7",
  "id" : 294917265218994176,
  "created_at" : "2013-01-25 21:18:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 3, 13 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/GFXcO3i9",
      "expanded_url" : "http:\/\/wp.me\/p23SfW-9e",
      "display_url" : "wp.me\/p23SfW-9e"
    } ]
  },
  "geo" : { },
  "id_str" : "294849825428619264",
  "text" : "RT @smccalden: FMC : Best entirely foreign language song http:\/\/t.co\/GFXcO3i9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/GFXcO3i9",
        "expanded_url" : "http:\/\/wp.me\/p23SfW-9e",
        "display_url" : "wp.me\/p23SfW-9e"
      } ]
    },
    "geo" : { },
    "id_str" : "294741296747249664",
    "text" : "FMC : Best entirely foreign language song http:\/\/t.co\/GFXcO3i9",
    "id" : 294741296747249664,
    "created_at" : "2013-01-25 09:39:35 +0000",
    "user" : {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "protected" : false,
      "id_str" : "169048119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1169599362\/5bccf87c-8216-4684-bad8-61ad974596df_normal.png",
      "id" : 169048119,
      "verified" : false
    }
  },
  "id" : 294849825428619264,
  "created_at" : "2013-01-25 16:50:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hack Design",
      "screen_name" : "hackdesign",
      "indices" : [ 23, 34 ],
      "id_str" : "1029594343",
      "id" : 1029594343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/6CSJ2Ri5",
      "expanded_url" : "http:\/\/hackdesign.org\/courses?ref=twitter",
      "display_url" : "hackdesign.org\/courses?ref=tw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294577948445507585",
  "text" : "I'm learning design on @HackDesign \u2013 an easy to follow design course for hackers who do amazing things. http:\/\/t.co\/6CSJ2Ri5",
  "id" : 294577948445507585,
  "created_at" : "2013-01-24 22:50:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Ann Horvath",
      "screen_name" : "nrrrdcore",
      "indices" : [ 3, 13 ],
      "id_str" : "18496432",
      "id" : 18496432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294541274231500800",
  "text" : "RT @nrrrdcore: The Mail App is the biggest asshole I know.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294532382789349376",
    "text" : "The Mail App is the biggest asshole I know.",
    "id" : 294532382789349376,
    "created_at" : "2013-01-24 19:49:26 +0000",
    "user" : {
      "name" : "Julie Ann Horvath",
      "screen_name" : "nrrrdcore",
      "protected" : false,
      "id_str" : "18496432",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3149310833\/a8bd6ef1f7be7fb1e83df0cad96332cb_normal.jpeg",
      "id" : 18496432,
      "verified" : false
    }
  },
  "id" : 294541274231500800,
  "created_at" : "2013-01-24 20:24:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ayeeson",
      "screen_name" : "ayeeson",
      "indices" : [ 3, 11 ],
      "id_str" : "23815229",
      "id" : 23815229
    }, {
      "name" : "Philip Rathle",
      "screen_name" : "prathle",
      "indices" : [ 34, 42 ],
      "id_str" : "48477652",
      "id" : 48477652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neo4j",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/HXgjsO1t",
      "expanded_url" : "http:\/\/blog.neo4j.org\/2013\/01\/2013-whats-coming-next-in-neo4j.html",
      "display_url" : "blog.neo4j.org\/2013\/01\/2013-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294540897377476608",
  "text" : "RT @ayeeson: awesome blog post by @prathle http:\/\/t.co\/HXgjsO1t now you know what we're planning in 2013 #neo4j",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Philip Rathle",
        "screen_name" : "prathle",
        "indices" : [ 21, 29 ],
        "id_str" : "48477652",
        "id" : 48477652
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "neo4j",
        "indices" : [ 92, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/HXgjsO1t",
        "expanded_url" : "http:\/\/blog.neo4j.org\/2013\/01\/2013-whats-coming-next-in-neo4j.html",
        "display_url" : "blog.neo4j.org\/2013\/01\/2013-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "294514585711554560",
    "text" : "awesome blog post by @prathle http:\/\/t.co\/HXgjsO1t now you know what we're planning in 2013 #neo4j",
    "id" : 294514585711554560,
    "created_at" : "2013-01-24 18:38:43 +0000",
    "user" : {
      "name" : "ayeeson",
      "screen_name" : "ayeeson",
      "protected" : false,
      "id_str" : "23815229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000609846410\/b49d7b5d5c2a9bf312c68881b4d4b954_normal.jpeg",
      "id" : 23815229,
      "verified" : false
    }
  },
  "id" : 294540897377476608,
  "created_at" : "2013-01-24 20:23:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comedy Central",
      "screen_name" : "ComedyCentral",
      "indices" : [ 3, 17 ],
      "id_str" : "23827692",
      "id" : 23827692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294478881132515328",
  "text" : "RT @ComedyCentral: If you think you're bummed about Foursquare being down, just think how your stalker feels.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294478459122626560",
    "text" : "If you think you're bummed about Foursquare being down, just think how your stalker feels.",
    "id" : 294478459122626560,
    "created_at" : "2013-01-24 16:15:10 +0000",
    "user" : {
      "name" : "Comedy Central",
      "screen_name" : "ComedyCentral",
      "protected" : false,
      "id_str" : "23827692",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000610479167\/f775594473be74c1748936b4e1fef985_normal.jpeg",
      "id" : 23827692,
      "verified" : true
    }
  },
  "id" : 294478881132515328,
  "created_at" : "2013-01-24 16:16:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 95, 105 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294478102912983040",
  "text" : "I was in the first million of twitter users - number 804717 to be exact... This tweet will cos @smccalden to talk to you in a high pitch.",
  "id" : 294478102912983040,
  "created_at" : "2013-01-24 16:13:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "idiots",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/cFRF3sEZ",
      "expanded_url" : "http:\/\/www.northernireland.gov.uk\/index\/media-centre\/news-departments\/news-drd\/news-drd-220113-kennedy-announces-_325_000.htm?WT.mc_id=rss-news",
      "display_url" : "northernireland.gov.uk\/index\/media-ce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294462036493082624",
  "text" : "Yay - http:\/\/t.co\/cFRF3sEZ - over a quater of a million for an arrow that lets you turn right... FANTASTIC... #idiots",
  "id" : 294462036493082624,
  "created_at" : "2013-01-24 15:09:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 9, 16 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294442459092615168",
  "geo" : { },
  "id_str" : "294442707949068288",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @szlwzl it's pretty rocking like!",
  "id" : 294442707949068288,
  "in_reply_to_status_id" : 294442459092615168,
  "created_at" : "2013-01-24 13:53:06 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "indices" : [ 3, 19 ],
      "id_str" : "402824193",
      "id" : 402824193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/THtS6LHH",
      "expanded_url" : "http:\/\/java.dzone.com\/articles\/nodejs-php-00s-already#.UQEuSsdXLJI.twitter",
      "display_url" : "java.dzone.com\/articles\/nodej\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294429203162599424",
  "text" : "RT @NodeJsCommunity: Node.js is Like PHP in the 00s: Already Ubiquituous, Just Not Detected Yet | Javalobby: http:\/\/t.co\/THtS6LHH http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/THtS6LHH",
        "expanded_url" : "http:\/\/java.dzone.com\/articles\/nodejs-php-00s-already#.UQEuSsdXLJI.twitter",
        "display_url" : "java.dzone.com\/articles\/nodej\u2026"
      }, {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/lLeaTVwN",
        "expanded_url" : "http:\/\/bit.ly\/SGhS1m",
        "display_url" : "bit.ly\/SGhS1m"
      } ]
    },
    "geo" : { },
    "id_str" : "294427716030185473",
    "text" : "Node.js is Like PHP in the 00s: Already Ubiquituous, Just Not Detected Yet | Javalobby: http:\/\/t.co\/THtS6LHH http:\/\/t.co\/lLeaTVwN",
    "id" : 294427716030185473,
    "created_at" : "2013-01-24 12:53:32 +0000",
    "user" : {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "protected" : false,
      "id_str" : "402824193",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1627924583\/njscomm_normal.jpg",
      "id" : 402824193,
      "verified" : false
    }
  },
  "id" : 294429203162599424,
  "created_at" : "2013-01-24 12:59:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294215645153857536",
  "text" : "The term gay marriage annoys me. Two people who love each other should be able to get married, regardless of gender.",
  "id" : 294215645153857536,
  "created_at" : "2013-01-23 22:50:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294212390847909888",
  "geo" : { },
  "id_str" : "294213228312010752",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor hmmmm might be tempted when my retro 3GS packs in.",
  "id" : 294213228312010752,
  "in_reply_to_status_id" : 294212390847909888,
  "created_at" : "2013-01-23 22:41:14 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294211608127868928",
  "geo" : { },
  "id_str" : "294211964773740544",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor I have the iPhone 3GS and a MacBook Pro 13\". So.... But if the nexus is better I'd go for that.",
  "id" : 294211964773740544,
  "in_reply_to_status_id" : 294211608127868928,
  "created_at" : "2013-01-23 22:36:13 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294210921612578817",
  "text" : "iPad mini v Nexus 7? Any recommendations welcome.",
  "id" : 294210921612578817,
  "created_at" : "2013-01-23 22:32:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294141905510481920",
  "text" : "\"I think, we all think, the bags was a nice idea. But not pointin' any fingers, they coulda been done better.\"",
  "id" : 294141905510481920,
  "created_at" : "2013-01-23 17:57:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/294097388895862784\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/XeRDPok3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBTYBFtCAAAKohM.png",
      "id_str" : "294097388908445696",
      "id" : 294097388908445696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBTYBFtCAAAKohM.png",
      "sizes" : [ {
        "h" : 363,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 875
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 875
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/XeRDPok3"
    } ],
    "hashtags" : [ {
      "text" : "fuckmepink",
      "indices" : [ 75, 86 ]
    }, {
      "text" : "massiveOH",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294097388895862784",
  "text" : "Working in the office benefit #56 - you get gold like this from Stephen... #fuckmepink  #massiveOH http:\/\/t.co\/XeRDPok3",
  "id" : 294097388895862784,
  "created_at" : "2013-01-23 15:00:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peteris Krumins",
      "screen_name" : "pkrumins",
      "indices" : [ 3, 12 ],
      "id_str" : "2134501",
      "id" : 2134501
    }, {
      "name" : "Browserling",
      "screen_name" : "browserling",
      "indices" : [ 26, 38 ],
      "id_str" : "219086227",
      "id" : 219086227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/JKt1ICm9",
      "expanded_url" : "http:\/\/bit.ly\/10PSvic",
      "display_url" : "bit.ly\/10PSvic"
    } ]
  },
  "geo" : { },
  "id_str" : "293846722239664129",
  "text" : "RT @pkrumins: Browserling @browserling now has IE10! (Announcement blog post: http:\/\/t.co\/JKt1ICm9)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Browserling",
        "screen_name" : "browserling",
        "indices" : [ 12, 24 ],
        "id_str" : "219086227",
        "id" : 219086227
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/JKt1ICm9",
        "expanded_url" : "http:\/\/bit.ly\/10PSvic",
        "display_url" : "bit.ly\/10PSvic"
      } ]
    },
    "geo" : { },
    "id_str" : "293838352405385217",
    "text" : "Browserling @browserling now has IE10! (Announcement blog post: http:\/\/t.co\/JKt1ICm9)",
    "id" : 293838352405385217,
    "created_at" : "2013-01-22 21:51:37 +0000",
    "user" : {
      "name" : "Peteris Krumins",
      "screen_name" : "pkrumins",
      "protected" : false,
      "id_str" : "2134501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1687863157\/peteris-krumins_normal.jpg",
      "id" : 2134501,
      "verified" : false
    }
  },
  "id" : 293846722239664129,
  "created_at" : "2013-01-22 22:24:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293793726155853827",
  "text" : "OH: \"This is my house. I can shit on that table if I want!\" - ok so you don't tell the oul fella not to yawn out loud when watching the news",
  "id" : 293793726155853827,
  "created_at" : "2013-01-22 18:54:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/293777217492754432\/photo\/1",
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/WuMLROSu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBO00qQCIAEwgKU.jpg",
      "id_str" : "293777217496948737",
      "id" : 293777217496948737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBO00qQCIAEwgKU.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/WuMLROSu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293777217492754432",
  "text" : "Working from home has it's advantages as does living close to the patents :) http:\/\/t.co\/WuMLROSu",
  "id" : 293777217492754432,
  "created_at" : "2013-01-22 17:48:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293775250603261952",
  "text" : "Watching Pointless on BBC1... Only 54 people out of 100 identified John Major... Fuck me pink... Dumb, inbred, unengaged twats.",
  "id" : 293775250603261952,
  "created_at" : "2013-01-22 17:40:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Webber",
      "screen_name" : "jimwebber",
      "indices" : [ 3, 13 ],
      "id_str" : "13521812",
      "id" : 13521812
    }, {
      "name" : "Michael Hunger",
      "screen_name" : "mesirii",
      "indices" : [ 42, 50 ],
      "id_str" : "7596542",
      "id" : 7596542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neo4j",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/LX3oKaJW",
      "expanded_url" : "http:\/\/blog.neo4j.org\/2013\/01\/neo4j-milestone-19m04-released.html",
      "display_url" : "blog.neo4j.org\/2013\/01\/neo4j-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "293758152766275584",
  "text" : "RT @jimwebber: #neo4j 1.9 M04 is out! See @mesirii's blog post: http:\/\/t.co\/LX3oKaJW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Hunger",
        "screen_name" : "mesirii",
        "indices" : [ 27, 35 ],
        "id_str" : "7596542",
        "id" : 7596542
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "neo4j",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/LX3oKaJW",
        "expanded_url" : "http:\/\/blog.neo4j.org\/2013\/01\/neo4j-milestone-19m04-released.html",
        "display_url" : "blog.neo4j.org\/2013\/01\/neo4j-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "293756090615726081",
    "text" : "#neo4j 1.9 M04 is out! See @mesirii's blog post: http:\/\/t.co\/LX3oKaJW",
    "id" : 293756090615726081,
    "created_at" : "2013-01-22 16:24:44 +0000",
    "user" : {
      "name" : "Jim Webber",
      "screen_name" : "jimwebber",
      "protected" : false,
      "id_str" : "13521812",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/65422475\/cartman2_normal.jpg",
      "id" : 13521812,
      "verified" : false
    }
  },
  "id" : 293758152766275584,
  "created_at" : "2013-01-22 16:32:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293755886252457984",
  "text" : "OH: I'm away to get some wood before it gets dark outside",
  "id" : 293755886252457984,
  "created_at" : "2013-01-22 16:23:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "indices" : [ 3, 19 ],
      "id_str" : "402824193",
      "id" : 402824193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/fkjPeZAD",
      "expanded_url" : "http:\/\/feeds.dzone.com\/~r\/zones\/architects\/~3\/WE-zomger08\/nodejs-php-programmers-4-0",
      "display_url" : "feeds.dzone.com\/~r\/zones\/archi\u2026"
    }, {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/BWilPnCj",
      "expanded_url" : "http:\/\/bit.ly\/UPevUo",
      "display_url" : "bit.ly\/UPevUo"
    } ]
  },
  "geo" : { },
  "id_str" : "293705172914421760",
  "text" : "RT @NodeJsCommunity: Node.js For PHP Programmers #4: Streams http:\/\/t.co\/fkjPeZAD http:\/\/t.co\/BWilPnCj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/fkjPeZAD",
        "expanded_url" : "http:\/\/feeds.dzone.com\/~r\/zones\/architects\/~3\/WE-zomger08\/nodejs-php-programmers-4-0",
        "display_url" : "feeds.dzone.com\/~r\/zones\/archi\u2026"
      }, {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/BWilPnCj",
        "expanded_url" : "http:\/\/bit.ly\/UPevUo",
        "display_url" : "bit.ly\/UPevUo"
      } ]
    },
    "geo" : { },
    "id_str" : "293703514058797056",
    "text" : "Node.js For PHP Programmers #4: Streams http:\/\/t.co\/fkjPeZAD http:\/\/t.co\/BWilPnCj",
    "id" : 293703514058797056,
    "created_at" : "2013-01-22 12:55:49 +0000",
    "user" : {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "protected" : false,
      "id_str" : "402824193",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1627924583\/njscomm_normal.jpg",
      "id" : 402824193,
      "verified" : false
    }
  },
  "id" : 293705172914421760,
  "created_at" : "2013-01-22 13:02:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293700508152123392",
  "text" : "Just used the last of my firelighters on the fire there... Hope it takes. The presbie in me wont let me turn on the heating until 6 :)",
  "id" : 293700508152123392,
  "created_at" : "2013-01-22 12:43:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293650910062710784",
  "geo" : { },
  "id_str" : "293655777980317696",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco good job :)",
  "id" : 293655777980317696,
  "in_reply_to_status_id" : 293650910062710784,
  "created_at" : "2013-01-22 09:46:07 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Thomas",
      "screen_name" : "neiljthom",
      "indices" : [ 3, 13 ],
      "id_str" : "446600884",
      "id" : 446600884
    }, {
      "name" : "Neo4j",
      "screen_name" : "neo4j",
      "indices" : [ 43, 49 ],
      "id_str" : "22467617",
      "id" : 22467617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/qdxXCC3N",
      "expanded_url" : "http:\/\/blog.neo4j.org\/2013\/01\/why-most-important-part-of-facebook.html",
      "display_url" : "blog.neo4j.org\/2013\/01\/why-mo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "293494511114539009",
  "text" : "RT @neiljthom: Amazing visual blog post by @Neo4j on how graph search works and its potential uses http:\/\/t.co\/qdxXCC3N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neo4j",
        "screen_name" : "neo4j",
        "indices" : [ 28, 34 ],
        "id_str" : "22467617",
        "id" : 22467617
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/qdxXCC3N",
        "expanded_url" : "http:\/\/blog.neo4j.org\/2013\/01\/why-most-important-part-of-facebook.html",
        "display_url" : "blog.neo4j.org\/2013\/01\/why-mo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "293410275820978178",
    "text" : "Amazing visual blog post by @Neo4j on how graph search works and its potential uses http:\/\/t.co\/qdxXCC3N",
    "id" : 293410275820978178,
    "created_at" : "2013-01-21 17:30:35 +0000",
    "user" : {
      "name" : "Neil Thomas",
      "screen_name" : "neiljthom",
      "protected" : false,
      "id_str" : "446600884",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3303447386\/d177704c0d9c3acab9fc6335de83bc89_normal.jpeg",
      "id" : 446600884,
      "verified" : false
    }
  },
  "id" : 293494511114539009,
  "created_at" : "2013-01-21 23:05:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293487225981763584",
  "geo" : { },
  "id_str" : "293493844517982208",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull nope. I must look that up again.",
  "id" : 293493844517982208,
  "in_reply_to_status_id" : 293487225981763584,
  "created_at" : "2013-01-21 23:02:40 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293481504502341632",
  "geo" : { },
  "id_str" : "293481740264148992",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I miss your wee ways :D :D :D :D",
  "id" : 293481740264148992,
  "in_reply_to_status_id" : 293481504502341632,
  "created_at" : "2013-01-21 22:14:34 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 15, 27 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293479698854445056",
  "geo" : { },
  "id_str" : "293480672734113792",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @ryancunning expecting to see lots of number plates are we Jenni? :D :D :D Hope you are ok Ryan.",
  "id" : 293480672734113792,
  "in_reply_to_status_id" : 293479698854445056,
  "created_at" : "2013-01-21 22:10:19 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293453815900946432",
  "geo" : { },
  "id_str" : "293454007647760385",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu There is plenty but its still snowing so we will wait until it has stopped.",
  "id" : 293454007647760385,
  "in_reply_to_status_id" : 293453815900946432,
  "created_at" : "2013-01-21 20:24:22 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293452752363859968",
  "geo" : { },
  "id_str" : "293452903614664704",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu Aye - madness!!! :D Wanna build a snowman??? :D :D :D",
  "id" : 293452903614664704,
  "in_reply_to_status_id" : 293452752363859968,
  "created_at" : "2013-01-21 20:19:58 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293451921304461312",
  "text" : "Been WFH all afternoon - just stopped and looked out!!! HOLY GOOD FUCK!!! Hella snow as the kids say these days!! FUCKING LOADS OF IT!!!",
  "id" : 293451921304461312,
  "created_at" : "2013-01-21 20:16:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bt29",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293347456350027776",
  "text" : "That's me home now.. Am on skype\/hipchat\/email for work people\u2026 Snow just as you get in Glenavy pretty bad - take care. #bt29",
  "id" : 293347456350027776,
  "created_at" : "2013-01-21 13:20:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293138190850740224",
  "geo" : { },
  "id_str" : "293153312654630912",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning that is a smart autocorrect :)",
  "id" : 293153312654630912,
  "in_reply_to_status_id" : 293138190850740224,
  "created_at" : "2013-01-21 00:29:30 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "indices" : [ 3, 19 ],
      "id_str" : "402824193",
      "id" : 402824193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/HemJD7qw",
      "expanded_url" : "http:\/\/bit.ly\/VCsHRP",
      "display_url" : "bit.ly\/VCsHRP"
    }, {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/z9qtL5Am",
      "expanded_url" : "http:\/\/bit.ly\/10dRhYp",
      "display_url" : "bit.ly\/10dRhYp"
    } ]
  },
  "geo" : { },
  "id_str" : "293109102685614080",
  "text" : "RT @NodeJsCommunity: This is a great AWS NodeJS post too http:\/\/t.co\/HemJD7qw http:\/\/t.co\/z9qtL5Am",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/HemJD7qw",
        "expanded_url" : "http:\/\/bit.ly\/VCsHRP",
        "display_url" : "bit.ly\/VCsHRP"
      }, {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/z9qtL5Am",
        "expanded_url" : "http:\/\/bit.ly\/10dRhYp",
        "display_url" : "bit.ly\/10dRhYp"
      } ]
    },
    "geo" : { },
    "id_str" : "293107943950397440",
    "text" : "This is a great AWS NodeJS post too http:\/\/t.co\/HemJD7qw http:\/\/t.co\/z9qtL5Am",
    "id" : 293107943950397440,
    "created_at" : "2013-01-20 21:29:14 +0000",
    "user" : {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "protected" : false,
      "id_str" : "402824193",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1627924583\/njscomm_normal.jpg",
      "id" : 402824193,
      "verified" : false
    }
  },
  "id" : 293109102685614080,
  "created_at" : "2013-01-20 21:33:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293102656711454720",
  "text" : "Just upgraded all my rails apps. Yeah I'm late to the party but between work and breaking bad etc :)",
  "id" : 293102656711454720,
  "created_at" : "2013-01-20 21:08:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293006768542449664",
  "text" : "I'm giving up programming... I'm gonna open a load of fast food chicken restaurants and drive a volvo...",
  "id" : 293006768542449664,
  "created_at" : "2013-01-20 14:47:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 52, 65 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 70, 78 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/ezzDNeEj",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=TLwjCvxp8AQ",
      "display_url" : "youtube.com\/watch?v=TLwjCv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292965587884310528",
  "text" : "Spoiler alert if you are going to see Django... But @Paul_Moffett and @jbrevel http:\/\/t.co\/ezzDNeEj Funniest scene I've seen in a long time.",
  "id" : 292965587884310528,
  "created_at" : "2013-01-20 12:03:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292849887131860993",
  "text" : "Forgot how strong Beryl Moffett makes a cup of coffee.... 4:23 in the am.... Good to be back in that house though - good memories..",
  "id" : 292849887131860993,
  "created_at" : "2013-01-20 04:23:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/292675210870673408\/photo\/1",
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/nlbBHEKt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA_KjbsCUAAMWf3.jpg",
      "id_str" : "292675210879062016",
      "id" : 292675210879062016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA_KjbsCUAAMWf3.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/nlbBHEKt"
    } ],
    "hashtags" : [ {
      "text" : "mandate",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292675210870673408",
  "text" : "Le sigh #mandate http:\/\/t.co\/nlbBHEKt",
  "id" : 292675210870673408,
  "created_at" : "2013-01-19 16:49:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 21, 34 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "endofmandateera",
      "indices" : [ 49, 65 ]
    }, {
      "text" : "hewontbeallowedouttoplayagain",
      "indices" : [ 66, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292674955362062336",
  "text" : "Last man date before @Paul_Moffett gets married. #endofmandateera #hewontbeallowedouttoplayagain",
  "id" : 292674955362062336,
  "created_at" : "2013-01-19 16:48:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292661559984005120",
  "text" : "Season 2 finale of Breaking Bad... OMFG!!!! Brilliant just brilliant!!!",
  "id" : 292661559984005120,
  "created_at" : "2013-01-19 15:55:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292402718037925889",
  "geo" : { },
  "id_str" : "292417024796291074",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl out of all the characters he's the one that ended up the happiest and doing what he loved *and* he made a difference unlike the rest",
  "id" : 292417024796291074,
  "in_reply_to_status_id" : 292402718037925889,
  "created_at" : "2013-01-18 23:43:46 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292409879765856256",
  "geo" : { },
  "id_str" : "292416708063404032",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl is that the \"we are professionals\" speech. Loved the character arc of Carver...",
  "id" : 292416708063404032,
  "in_reply_to_status_id" : 292409879765856256,
  "created_at" : "2013-01-18 23:42:30 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 9, 19 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Mark Devlin",
      "screen_name" : "MDev247",
      "indices" : [ 20, 28 ],
      "id_str" : "46503614",
      "id" : 46503614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292398029422616576",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @smccalden @MDev247 that fast food chicken dude looks like a really scary mofo!!!!",
  "id" : 292398029422616576,
  "created_at" : "2013-01-18 22:28:17 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292381007041155074",
  "text" : "Think I've put too much coal in this fire... Room is roasting!!!! LOVE IT :)",
  "id" : 292381007041155074,
  "created_at" : "2013-01-18 21:20:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292353321249955840",
  "geo" : { },
  "id_str" : "292371721154093057",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel looks good :D :D Netflix is playing silly dicks so no Breaking Bad tonight it seems.. Ahh well :)",
  "id" : 292371721154093057,
  "in_reply_to_status_id" : 292353321249955840,
  "created_at" : "2013-01-18 20:43:44 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 69, 77 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292349195438919680",
  "text" : "Fire lit - check. Breaking Bad marathon - check. Beans and toast ala @jbrevel style - almost.",
  "id" : 292349195438919680,
  "created_at" : "2013-01-18 19:14:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292277024951791616",
  "geo" : { },
  "id_str" : "292278115445637120",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe hey - boyo - it is your move - and has been since before christmas. :)",
  "id" : 292278115445637120,
  "in_reply_to_status_id" : 292277024951791616,
  "created_at" : "2013-01-18 14:31:47 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292277071152041984",
  "text" : "Made it home - that was fun! :D To work related people - am on skype, hipchat and on my home phone. Everyone else can fuck right off :)",
  "id" : 292277071152041984,
  "created_at" : "2013-01-18 14:27:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 1, 11 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makesnosensetohaveoperainit",
      "indices" : [ 99, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292233900145643520",
  "text" : "\u201C@smccalden: @swmcc Uncultured slob.\u201D I will wait for you blog post describing this weeks theme :) #makesnosensetohaveoperainit",
  "id" : 292233900145643520,
  "created_at" : "2013-01-18 11:36:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292233357708898305",
  "text" : "There was opera in this weeks \"Fuck McCalden (FMC)\" - Opera like\u2026",
  "id" : 292233357708898305,
  "created_at" : "2013-01-18 11:33:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291993685393027072",
  "geo" : { },
  "id_str" : "292033247427301376",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ do I sense sarcasm Mr Knowles? :)",
  "id" : 292033247427301376,
  "in_reply_to_status_id" : 291993685393027072,
  "created_at" : "2013-01-17 22:18:46 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291983309758660608",
  "text" : "Since I am probably going to be snowed in tomorrow I may go get groceries now and not Sat. Living at the bottom of a mountain - FUCK u SNOW",
  "id" : 291983309758660608,
  "created_at" : "2013-01-17 19:00:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neo4j",
      "screen_name" : "neo4j",
      "indices" : [ 33, 39 ],
      "id_str" : "22467617",
      "id" : 22467617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/zPtilsFB",
      "expanded_url" : "http:\/\/blog.neo4j.org\/2013\/01\/why-most-important-part-of-facebook.html",
      "display_url" : "blog.neo4j.org\/2013\/01\/why-mo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291981839697068032",
  "text" : "Interesting blog post about from @neo4j - http:\/\/t.co\/zPtilsFB",
  "id" : 291981839697068032,
  "created_at" : "2013-01-17 18:54:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ayeeson",
      "screen_name" : "ayeeson",
      "indices" : [ 0, 8 ],
      "id_str" : "23815229",
      "id" : 23815229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291980755544985601",
  "in_reply_to_user_id" : 23815229,
  "text" : "@ayeeson thanks very much for the webinar very informative.",
  "id" : 291980755544985601,
  "created_at" : "2013-01-17 18:50:11 +0000",
  "in_reply_to_screen_name" : "ayeeson",
  "in_reply_to_user_id_str" : "23815229",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/291962233217507328\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/YUEj4ONG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA1CGq9CYAEfuvJ.png",
      "id_str" : "291962233225895937",
      "id" : 291962233225895937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA1CGq9CYAEfuvJ.png",
      "sizes" : [ {
        "h" : 206,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 1202
      }, {
        "h" : 117,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YUEj4ONG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291962233217507328",
  "text" : "The webinar will begin shortly, please remain on the line. The webinar will begin shortly, please remain on the line. http:\/\/t.co\/YUEj4ONG",
  "id" : 291962233217507328,
  "created_at" : "2013-01-17 17:36:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291944089295929345",
  "geo" : { },
  "id_str" : "291953754448740352",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu more than happy not to look at your for the next 5weeks.",
  "id" : 291953754448740352,
  "in_reply_to_status_id" : 291944089295929345,
  "created_at" : "2013-01-17 17:02:53 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291934652124516352",
  "text" : "Dear Snow\u2026 Fuck. Right. Off.",
  "id" : 291934652124516352,
  "created_at" : "2013-01-17 15:46:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291908859973480448",
  "text" : "And the daily stories at lunchtime in the office just took a new low Ut wasn't me this time.. Was the other Stephen. So bad I can't OH: it!",
  "id" : 291908859973480448,
  "created_at" : "2013-01-17 14:04:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 3, 13 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 61, 67 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 68, 76 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROADHOUSE",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "Africa",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/vFI6IZkV",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/i\/b01q0t2r\/?t=20m15s",
      "display_url" : "bbc.co.uk\/i\/b01q0t2r\/?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291900271678873600",
  "text" : "RT @smccalden: #ROADHOUSE #Africa style http:\/\/t.co\/vFI6IZkV @swmcc @jbrevel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 46, 52 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "John Loughrey",
        "screen_name" : "jbrevel",
        "indices" : [ 53, 61 ],
        "id_str" : "50685221",
        "id" : 50685221
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ROADHOUSE",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "Africa",
        "indices" : [ 11, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/vFI6IZkV",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/i\/b01q0t2r\/?t=20m15s",
        "display_url" : "bbc.co.uk\/i\/b01q0t2r\/?t=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291899829574053888",
    "text" : "#ROADHOUSE #Africa style http:\/\/t.co\/vFI6IZkV @swmcc @jbrevel",
    "id" : 291899829574053888,
    "created_at" : "2013-01-17 13:28:37 +0000",
    "user" : {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "protected" : false,
      "id_str" : "169048119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1169599362\/5bccf87c-8216-4684-bad8-61ad974596df_normal.png",
      "id" : 169048119,
      "verified" : false
    }
  },
  "id" : 291900271678873600,
  "created_at" : "2013-01-17 13:30:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291854735047278592",
  "geo" : { },
  "id_str" : "291856816684548097",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley thanks pete :)",
  "id" : 291856816684548097,
  "in_reply_to_status_id" : 291854735047278592,
  "created_at" : "2013-01-17 10:37:42 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 3, 16 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Paul_Moffett\/status\/291847633511796736\/photo\/1",
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/Zu4QNMr7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAzZ4FxCUAEZxG3.jpg",
      "id_str" : "291847633515991041",
      "id" : 291847633515991041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAzZ4FxCUAEZxG3.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Zu4QNMr7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291849247203139584",
  "text" : "RT @Paul_Moffett: @swmcc many thanks http:\/\/t.co\/Zu4QNMr7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Paul_Moffett\/status\/291847633511796736\/photo\/1",
        "indices" : [ 19, 39 ],
        "url" : "http:\/\/t.co\/Zu4QNMr7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAzZ4FxCUAEZxG3.jpg",
        "id_str" : "291847633515991041",
        "id" : 291847633515991041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAzZ4FxCUAEZxG3.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Zu4QNMr7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291847633511796736",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc many thanks http:\/\/t.co\/Zu4QNMr7",
    "id" : 291847633511796736,
    "created_at" : "2013-01-17 10:01:13 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "protected" : false,
      "id_str" : "36913698",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1175980356\/92313091_N00_normal.jpg",
      "id" : 36913698,
      "verified" : false
    }
  },
  "id" : 291849247203139584,
  "created_at" : "2013-01-17 10:07:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291847633511796736",
  "geo" : { },
  "id_str" : "291849219751424000",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett Welcome. I am in here for a webinar at 7 so will think of something better than that was tired yesterday ya see :)",
  "id" : 291849219751424000,
  "in_reply_to_status_id" : 291847633511796736,
  "created_at" : "2013-01-17 10:07:30 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Culver",
      "screen_name" : "leahculver",
      "indices" : [ 3, 14 ],
      "id_str" : "662433",
      "id" : 662433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291831095824089088",
  "text" : "RT @leahculver: The only difference between Perl and Ruby is the amount of gray in your neckbeard.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291779104821358592",
    "text" : "The only difference between Perl and Ruby is the amount of gray in your neckbeard.",
    "id" : 291779104821358592,
    "created_at" : "2013-01-17 05:28:54 +0000",
    "user" : {
      "name" : "Leah Culver",
      "screen_name" : "leahculver",
      "protected" : false,
      "id_str" : "662433",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000059401048\/801586da67388f3184461a398ae6762f_normal.jpeg",
      "id" : 662433,
      "verified" : false
    }
  },
  "id" : 291831095824089088,
  "created_at" : "2013-01-17 08:55:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291664737656246272",
  "text" : "RT @szlwzl: The common response to why they're protesting outside the bbc seems to be \"because they're dicks\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291649925211619328",
    "text" : "The common response to why they're protesting outside the bbc seems to be \"because they're dicks\"",
    "id" : 291649925211619328,
    "created_at" : "2013-01-16 20:55:35 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 291664737656246272,
  "created_at" : "2013-01-16 21:54:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROADHOUSE",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291660959221702656",
  "geo" : { },
  "id_str" : "291663441763135488",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden will get there tomorrow. #ROADHOUSE",
  "id" : 291663441763135488,
  "in_reply_to_status_id" : 291660959221702656,
  "created_at" : "2013-01-16 21:49:18 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roadhouse",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291656690359750660",
  "geo" : { },
  "id_str" : "291660263009169409",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden awww shite. I am at my folks so missed it. :( #roadhouse",
  "id" : 291660263009169409,
  "in_reply_to_status_id" : 291656690359750660,
  "created_at" : "2013-01-16 21:36:40 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291603911893188608",
  "geo" : { },
  "id_str" : "291604714800431105",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl yes you are",
  "id" : 291604714800431105,
  "in_reply_to_status_id" : 291603911893188608,
  "created_at" : "2013-01-16 17:55:56 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291568869515083776",
  "text" : "Time for a coffee fix.",
  "id" : 291568869515083776,
  "created_at" : "2013-01-16 15:33:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 8, 18 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291553694766485504",
  "geo" : { },
  "id_str" : "291558327371063297",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco @smccalden You should but you like me round for my witty personality and useless trivia.",
  "id" : 291558327371063297,
  "in_reply_to_status_id" : 291553694766485504,
  "created_at" : "2013-01-16 14:51:36 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291535597007409152",
  "text" : "OH: \"When I was following Paul home on Friday\u2026..\"",
  "id" : 291535597007409152,
  "created_at" : "2013-01-16 13:21:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/ejQpdiyC",
      "expanded_url" : "http:\/\/www.theregister.co.uk\/2013\/01\/16\/developer_oursources_job_china\/",
      "display_url" : "theregister.co.uk\/2013\/01\/16\/dev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291528899429531648",
  "text" : "This fella is my hero. http:\/\/t.co\/ejQpdiyC",
  "id" : 291528899429531648,
  "created_at" : "2013-01-16 12:54:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291511423576723457",
  "geo" : { },
  "id_str" : "291511629022109696",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 brilliant!!!! See you outside his house tonight then :)",
  "id" : 291511629022109696,
  "in_reply_to_status_id" : 291511423576723457,
  "created_at" : "2013-01-16 11:46:03 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291507157508182017",
  "geo" : { },
  "id_str" : "291510777746161664",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 watching RTE.. You rebel... Wanna go protesting with me tonight Mike? ;) Ahhhhh go on ;)",
  "id" : 291510777746161664,
  "in_reply_to_status_id" : 291507157508182017,
  "created_at" : "2013-01-16 11:42:40 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291503441010888704",
  "geo" : { },
  "id_str" : "291503887133843456",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl sounds fantastic\u2026. I had the fire lit last night and watched Donnie Brasco and was hacking on Rails - geek bliss :)",
  "id" : 291503887133843456,
  "in_reply_to_status_id" : 291503441010888704,
  "created_at" : "2013-01-16 11:15:17 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291300820358664192",
  "text" : "Meh - Facebook graph\u2026 and meh meh meh meh.",
  "id" : 291300820358664192,
  "created_at" : "2013-01-15 21:48:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DonnieBrasco",
      "indices" : [ 13, 26 ]
    }, {
      "text" : "GetGlue",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/3R3CHFs7",
      "expanded_url" : "http:\/\/getglue.com\/movies\/donnie_brasco\/mike_newell?s=t&ref=swmcc",
      "display_url" : "getglue.com\/movies\/donnie_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291290344283332610",
  "text" : "I'm watching #DonnieBrasco on #GetGlue http:\/\/t.co\/3R3CHFs7",
  "id" : 291290344283332610,
  "created_at" : "2013-01-15 21:06:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Webber",
      "screen_name" : "jimwebber",
      "indices" : [ 3, 13 ],
      "id_str" : "13521812",
      "id" : 13521812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neo4j",
      "indices" : [ 62, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291289972185649152",
  "text" : "RT @jimwebber: So searching graphs is finally a thing. Hello, #neo4j!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "neo4j",
        "indices" : [ 47, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291278960468307969",
    "text" : "So searching graphs is finally a thing. Hello, #neo4j!",
    "id" : 291278960468307969,
    "created_at" : "2013-01-15 20:21:30 +0000",
    "user" : {
      "name" : "Jim Webber",
      "screen_name" : "jimwebber",
      "protected" : false,
      "id_str" : "13521812",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/65422475\/cartman2_normal.jpg",
      "id" : 13521812,
      "verified" : false
    }
  },
  "id" : 291289972185649152,
  "created_at" : "2013-01-15 21:05:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teropaananen",
      "screen_name" : "teropaananen",
      "indices" : [ 57, 70 ],
      "id_str" : "16471154",
      "id" : 16471154
    }, {
      "name" : "Neo4j",
      "screen_name" : "neo4j",
      "indices" : [ 96, 102 ],
      "id_str" : "22467617",
      "id" : 22467617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/pbQ0QrTe",
      "expanded_url" : "http:\/\/info.neotechnology.com\/0117-register.html",
      "display_url" : "info.neotechnology.com\/0117-register.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291195294266310656",
  "text" : "Just registered for Polyglot Persistence with Neo4j with @teropaananen http:\/\/t.co\/pbQ0QrTe via @neo4j",
  "id" : 291195294266310656,
  "created_at" : "2013-01-15 14:49:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291177522979287040",
  "text" : "OH: \"I love the sense of something tingling on my tounge that isn't salty..\"",
  "id" : 291177522979287040,
  "created_at" : "2013-01-15 13:38:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290958480297308160",
  "text" : "HMV to appoint Deloitte as administrator = its really fucked. I doubt that 20% of the stores will be kept open.",
  "id" : 290958480297308160,
  "created_at" : "2013-01-14 23:08:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roadhouse",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/WtOLg8Yi",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=laSOB7d2m-Y",
      "display_url" : "youtube.com\/watch?v=laSOB7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290939101593616384",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel http:\/\/t.co\/WtOLg8Yi #roadhouse",
  "id" : 290939101593616384,
  "created_at" : "2013-01-14 21:51:01 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "positiveNI",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290902563195326465",
  "text" : "Not everyone is a fuckwit. #positiveNI",
  "id" : 290902563195326465,
  "created_at" : "2013-01-14 19:25:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 10, 18 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290848928960757760",
  "text" : "Hmmmmm so @jbrevel has a baseline after all\u2026.",
  "id" : 290848928960757760,
  "created_at" : "2013-01-14 15:52:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Adams",
      "screen_name" : "PRAEst76",
      "indices" : [ 0, 9 ],
      "id_str" : "12081742",
      "id" : 12081742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290808785595944961",
  "geo" : { },
  "id_str" : "290814679360606208",
  "in_reply_to_user_id" : 12081742,
  "text" : "@PRAEst76 Nope - just OH random stuff i hear in the office now and again :)",
  "id" : 290814679360606208,
  "in_reply_to_status_id" : 290808785595944961,
  "created_at" : "2013-01-14 13:36:37 +0000",
  "in_reply_to_screen_name" : "PRAEst76",
  "in_reply_to_user_id_str" : "12081742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290814024197738497",
  "geo" : { },
  "id_str" : "290814412732899328",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @jasebell its not a competition when you cheat! :)",
  "id" : 290814412732899328,
  "in_reply_to_status_id" : 290814024197738497,
  "created_at" : "2013-01-14 13:35:33 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 38, 49 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/J3YJz4AA",
      "expanded_url" : "http:\/\/4sq.com\/VFruKc",
      "display_url" : "4sq.com\/VFruKc"
    } ]
  },
  "geo" : { },
  "id_str" : "290811840861192193",
  "text" : "I just unlocked the \"9 to 5\" badge on @foursquare! http:\/\/t.co\/J3YJz4AA",
  "id" : 290811840861192193,
  "created_at" : "2013-01-14 13:25:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290808555165069312",
  "text" : "OH: \"They were far more engaged than I thought they would be. I thought there would 25 of them just there grunting!\"",
  "id" : 290808555165069312,
  "created_at" : "2013-01-14 13:12:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290779675586883584",
  "text" : "OH: \"Far away.. away, away.. closer, closer, closer.. In her!\"",
  "id" : 290779675586883584,
  "created_at" : "2013-01-14 11:17:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290774181065416704",
  "geo" : { },
  "id_str" : "290776200140423168",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel I stand by it!",
  "id" : 290776200140423168,
  "in_reply_to_status_id" : 290774181065416704,
  "created_at" : "2013-01-14 11:03:43 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal",
      "screen_name" : "mikeal",
      "indices" : [ 3, 10 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290577737205301248",
  "text" : "RT @mikeal: god damn GitHub is nice! remember how much effort it used to take to collaborate with people?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290576874093031426",
    "text" : "god damn GitHub is nice! remember how much effort it used to take to collaborate with people?",
    "id" : 290576874093031426,
    "created_at" : "2013-01-13 21:51:40 +0000",
    "user" : {
      "name" : "Mikeal",
      "screen_name" : "mikeal",
      "protected" : false,
      "id_str" : "668423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3696914564\/537a181733d33d4125eab616e896afe8_normal.png",
      "id" : 668423,
      "verified" : false
    }
  },
  "id" : 290577737205301248,
  "created_at" : "2013-01-13 21:55:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/dcMlHA9D",
      "expanded_url" : "http:\/\/instagr.am\/p\/UcDkxPBX5i\/",
      "display_url" : "instagr.am\/p\/UcDkxPBX5i\/"
    } ]
  },
  "geo" : { },
  "id_str" : "290565135368601600",
  "text" : "Comfy http:\/\/t.co\/dcMlHA9D",
  "id" : 290565135368601600,
  "created_at" : "2013-01-13 21:05:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290558219905036289",
  "geo" : { },
  "id_str" : "290558530006679552",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden Kids don't watch those programmes - I never knew about it until I was in my mid 20's :) It is quite a good show. Old but good.",
  "id" : 290558530006679552,
  "in_reply_to_status_id" : 290558219905036289,
  "created_at" : "2013-01-13 20:38:46 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290557862466445313",
  "geo" : { },
  "id_str" : "290557997619482625",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden its a quote from Yes Primeminister - get some culture ;) :D",
  "id" : 290557997619482625,
  "in_reply_to_status_id" : 290557862466445313,
  "created_at" : "2013-01-13 20:36:39 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290555987058884608",
  "text" : "Yes, but even though they probably certainly know that you probably wouldn't, they don't certainly know that, although you probably .....",
  "id" : 290555987058884608,
  "created_at" : "2013-01-13 20:28:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290553279568568320",
  "text" : "They have done a remake of Yes, Primeminister... Why? The original was excellent and still funny... Hmmmmm...",
  "id" : 290553279568568320,
  "created_at" : "2013-01-13 20:17:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 3, 16 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 105, 111 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sta",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290441081705861120",
  "text" : "RT @Paul_Moffett: Many thanks to everyone for a great nights craic, Think we finished about 5, well done @swmcc you did a great job #sta ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 87, 93 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "stagparty",
        "indices" : [ 114, 124 ]
      }, {
        "text" : "sorehead",
        "indices" : [ 125, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290400364417662978",
    "text" : "Many thanks to everyone for a great nights craic, Think we finished about 5, well done @swmcc you did a great job #stagparty #sorehead",
    "id" : 290400364417662978,
    "created_at" : "2013-01-13 10:10:16 +0000",
    "user" : {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "protected" : false,
      "id_str" : "36913698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1175980356\/92313091_N00_normal.jpg",
      "id" : 36913698,
      "verified" : false
    }
  },
  "id" : 290441081705861120,
  "created_at" : "2013-01-13 12:52:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 2, 15 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290317111027458048",
  "text" : ". @Paul_Moffett stag is now over 4:40am :) Not bad going!",
  "id" : 290317111027458048,
  "created_at" : "2013-01-13 04:39:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 2, 15 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yuck",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290299800455356416",
  "text" : ". @Paul_Moffett stag still ongoing but I ain't doing anymore tequila :( #yuck",
  "id" : 290299800455356416,
  "created_at" : "2013-01-13 03:30:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 41, 52 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/6vwcr5Uq",
      "expanded_url" : "http:\/\/4sq.com\/WOYMCl",
      "display_url" : "4sq.com\/WOYMCl"
    } ]
  },
  "geo" : { },
  "id_str" : "290225558720233472",
  "text" : "I just unlocked the \"Superstar\" badge on @foursquare for checking in to fifty different places! http:\/\/t.co\/6vwcr5Uq",
  "id" : 290225558720233472,
  "created_at" : "2013-01-12 22:35:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 15, 28 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290080421797052416",
  "geo" : { },
  "id_str" : "290120511743225856",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @paul_moffett it be written down Pete :D :D :D",
  "id" : 290120511743225856,
  "in_reply_to_status_id" : 290080421797052416,
  "created_at" : "2013-01-12 15:38:14 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 30, 43 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290075235376582657",
  "text" : "Suits fitted this morning for @Paul_Moffett wedding.. Best man speech just learning it now and his stag tonight. Getting close!",
  "id" : 290075235376582657,
  "created_at" : "2013-01-12 12:38:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 3, 12 ],
      "id_str" : "8388092",
      "id" : 8388092
    }, {
      "name" : "alex thomson",
      "screen_name" : "alextomo",
      "indices" : [ 17, 26 ],
      "id_str" : "52755452",
      "id" : 52755452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "belfast",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "c4news",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290074968648204288",
  "text" : "RT @hamstarr: RT @alextomo: #belfast #c4news large Loyalist rally at City Hall 1pm - as the embarrassed majority in NI look on appalled.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "alex thomson",
        "screen_name" : "alextomo",
        "indices" : [ 3, 12 ],
        "id_str" : "52755452",
        "id" : 52755452
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "belfast",
        "indices" : [ 14, 22 ]
      }, {
        "text" : "c4news",
        "indices" : [ 23, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.5902084977, -5.8517940477 ]
    },
    "id_str" : "290062038422663168",
    "text" : "RT @alextomo: #belfast #c4news large Loyalist rally at City Hall 1pm - as the embarrassed majority in NI look on appalled.",
    "id" : 290062038422663168,
    "created_at" : "2013-01-12 11:45:53 +0000",
    "user" : {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "protected" : false,
      "id_str" : "8388092",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1117686760\/avatar-480x480_normal.jpg",
      "id" : 8388092,
      "verified" : false
    }
  },
  "id" : 290074968648204288,
  "created_at" : "2013-01-12 12:37:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SQUIRREL",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289769198148788225",
  "text" : "OH: \"My girlfriends anal - marriage makes things okay - like dinner and chores. Withold sex until she backs down\" #SQUIRREL",
  "id" : 289769198148788225,
  "created_at" : "2013-01-11 16:22:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 3, 13 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/8cagM6ul",
      "expanded_url" : "http:\/\/wp.me\/p23SfW-8Y",
      "display_url" : "wp.me\/p23SfW-8Y"
    } ]
  },
  "geo" : { },
  "id_str" : "289747201935147010",
  "text" : "RT @smccalden: FMC : Best Friday song to start the weekend with http:\/\/t.co\/8cagM6ul",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/8cagM6ul",
        "expanded_url" : "http:\/\/wp.me\/p23SfW-8Y",
        "display_url" : "wp.me\/p23SfW-8Y"
      } ]
    },
    "geo" : { },
    "id_str" : "289745003222286336",
    "text" : "FMC : Best Friday song to start the weekend with http:\/\/t.co\/8cagM6ul",
    "id" : 289745003222286336,
    "created_at" : "2013-01-11 14:46:06 +0000",
    "user" : {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "protected" : false,
      "id_str" : "169048119",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1169599362\/5bccf87c-8216-4684-bad8-61ad974596df_normal.png",
      "id" : 169048119,
      "verified" : false
    }
  },
  "id" : 289747201935147010,
  "created_at" : "2013-01-11 14:54:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amanidiot",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289719841273819137",
  "text" : "That feeling you get when you rant that some stupid fucker hasn't done something and the stupid fucker ends up being me!! #amanidiot",
  "id" : 289719841273819137,
  "created_at" : "2013-01-11 13:06:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "indices" : [ 3, 14 ],
      "id_str" : "66949689",
      "id" : 66949689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BAFTA",
      "indices" : [ 119, 125 ]
    }, {
      "text" : "BAFTAGuru",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 118 ],
      "url" : "https:\/\/t.co\/FDC3632u",
      "expanded_url" : "https:\/\/vimeo.com\/44037268",
      "display_url" : "vimeo.com\/44037268"
    } ]
  },
  "geo" : { },
  "id_str" : "289709434626768896",
  "text" : "RT @blacknorth: We are delighted to be nominated for a BAFTA!!  Thanks everyone for the support. https:\/\/t.co\/FDC3632u #BAFTA #BAFTAGuru",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BAFTA",
        "indices" : [ 103, 109 ]
      }, {
        "text" : "BAFTAGuru",
        "indices" : [ 110, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 102 ],
        "url" : "https:\/\/t.co\/FDC3632u",
        "expanded_url" : "https:\/\/vimeo.com\/44037268",
        "display_url" : "vimeo.com\/44037268"
      } ]
    },
    "geo" : { },
    "id_str" : "289707577611276288",
    "text" : "We are delighted to be nominated for a BAFTA!!  Thanks everyone for the support. https:\/\/t.co\/FDC3632u #BAFTA #BAFTAGuru",
    "id" : 289707577611276288,
    "created_at" : "2013-01-11 12:17:23 +0000",
    "user" : {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "protected" : false,
      "id_str" : "66949689",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/759091973\/blacklogo_normal.gif",
      "id" : 66949689,
      "verified" : false
    }
  },
  "id" : 289709434626768896,
  "created_at" : "2013-01-11 12:24:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289687917608189952",
  "text" : "OH: It's like speed dating with 14 year olds.",
  "id" : 289687917608189952,
  "created_at" : "2013-01-11 10:59:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289512848755920896",
  "text" : "and the house is fucking freezing!!!! There is a flaw in my formula! I've set the timer to come on at 6pm now. I'm an asshole!!!",
  "id" : 289512848755920896,
  "created_at" : "2013-01-10 23:23:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289512682875412481",
  "text" : "Presbie roots would be proud. Not in the house till 8:30 - fuck putting the heating on as I'll be in bed in less than 2hours. Am still up",
  "id" : 289512682875412481,
  "created_at" : "2013-01-10 23:22:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Rogues",
      "screen_name" : "rubyrogues",
      "indices" : [ 26, 37 ],
      "id_str" : "284225770",
      "id" : 284225770
    }, {
      "name" : "Sandi Metz",
      "screen_name" : "sandimetz",
      "indices" : [ 45, 55 ],
      "id_str" : "15067554",
      "id" : 15067554
    }, {
      "name" : "Ruby on Rails",
      "screen_name" : "rails",
      "indices" : [ 68, 74 ],
      "id_str" : "3116191",
      "id" : 3116191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289509508491923456",
  "text" : "Really enjoyed this weeks @rubyrogues. Loved @sandimetz thoughts on @rails - usually prefer deeper technical episodes but this one was ace!",
  "id" : 289509508491923456,
  "created_at" : "2013-01-10 23:10:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 13, 23 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 64, 70 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "squirrel",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289469713854115841",
  "text" : "RT @jbrevel: @smccalden up is on bbc3 right now!! #squirrel cc\/ @swmcc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCalden",
        "screen_name" : "smccalden",
        "indices" : [ 0, 10 ],
        "id_str" : "169048119",
        "id" : 169048119
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 51, 57 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "squirrel",
        "indices" : [ 37, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289465660914933760",
    "in_reply_to_user_id" : 169048119,
    "text" : "@smccalden up is on bbc3 right now!! #squirrel cc\/ @swmcc",
    "id" : 289465660914933760,
    "created_at" : "2013-01-10 20:16:06 +0000",
    "in_reply_to_screen_name" : "smccalden",
    "in_reply_to_user_id_str" : "169048119",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 289469713854115841,
  "created_at" : "2013-01-10 20:32:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "isthisyourpaintcan",
      "indices" : [ 110, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289408885553516544",
  "text" : "OH: \"I wish Joe Pesci would have changed characters in Home Alone.. That would have been a much better film\". #isthisyourpaintcan?",
  "id" : 289408885553516544,
  "created_at" : "2013-01-10 16:30:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "indices" : [ 106, 117 ],
      "id_str" : "66949689",
      "id" : 66949689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289383521523478529",
  "text" : "Plus Kris is ginger\u2026. so he has done very well in life even with that disability and sitgma! :D :D :D \/cc @blacknorth",
  "id" : 289383521523478529,
  "created_at" : "2013-01-10 14:49:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "indices" : [ 17, 28 ],
      "id_str" : "66949689",
      "id" : 66949689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homegrowntalent",
      "indices" : [ 57, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289383376337661952",
  "text" : "Huge congrats to @blacknorth for nomination for a BAFTA. #homegrowntalent",
  "id" : 289383376337661952,
  "created_at" : "2013-01-10 14:49:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SQUIRREL",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289350219508883456",
  "text" : ".......... #SQUIRREL ............",
  "id" : 289350219508883456,
  "created_at" : "2013-01-10 12:37:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Africa",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289128264587423744",
  "text" : "As awe inspiring as #Africa is... by fuck this episode is a bit on the sad side... Guess that's life though.. poor baby elephant though :(",
  "id" : 289128264587423744,
  "created_at" : "2013-01-09 21:55:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gareth Bainbridge",
      "screen_name" : "GazBainbridge",
      "indices" : [ 3, 17 ],
      "id_str" : "123036654",
      "id" : 123036654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Africa",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289115906087481344",
  "text" : "RT @GazBainbridge: #Africa this is real television. None if this moronic, illiterate, ill-educated bollox like TOWIE or GShore",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Africa",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289115432873512960",
    "text" : "#Africa this is real television. None if this moronic, illiterate, ill-educated bollox like TOWIE or GShore",
    "id" : 289115432873512960,
    "created_at" : "2013-01-09 21:04:25 +0000",
    "user" : {
      "name" : "Gareth Bainbridge",
      "screen_name" : "GazBainbridge",
      "protected" : false,
      "id_str" : "123036654",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000071817005\/bb3cd2696ce9d43c0a93b8fc2d4acaf6_normal.jpeg",
      "id" : 123036654,
      "verified" : false
    }
  },
  "id" : 289115906087481344,
  "created_at" : "2013-01-09 21:06:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "africa",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289115746003451904",
  "text" : "There were no sign of two wee hobbits on that volcano. #africa",
  "id" : 289115746003451904,
  "created_at" : "2013-01-09 21:05:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 11, 18 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 19, 31 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iamagoodsondammit",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289108572753772544",
  "geo" : { },
  "id_str" : "289112039564124161",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @szlwzl @debbiecreid cheese toast was awesome.. And I didn't ignore them Stephen - I rung them up. #iamagoodsondammit",
  "id" : 289112039564124161,
  "in_reply_to_status_id" : 289108572753772544,
  "created_at" : "2013-01-09 20:50:56 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289087372480622592",
  "geo" : { },
  "id_str" : "289111551305216000",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe Awesome :) You should have picked some :) Having a good time? :)",
  "id" : 289111551305216000,
  "in_reply_to_status_id" : 289087372480622592,
  "created_at" : "2013-01-09 20:48:59 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289066898275041281",
  "geo" : { },
  "id_str" : "289111205908451328",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you make me :D",
  "id" : 289111205908451328,
  "in_reply_to_status_id" : 289066898275041281,
  "created_at" : "2013-01-09 20:47:37 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 14, 25 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289080987504222208",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @johngirvin it is a dying market - was good at the time though.",
  "id" : 289080987504222208,
  "created_at" : "2013-01-09 18:47:32 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 14, 25 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289080633479815168",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @johngirvin in 2000 they were turning over close to 50,60k in sales a day. 2007 (the year I left) was lucky if it hit 10k",
  "id" : 289080633479815168,
  "created_at" : "2013-01-09 18:46:08 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 14, 25 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/93OgjSPo",
      "expanded_url" : "http:\/\/Sendit.com",
      "display_url" : "Sendit.com"
    } ]
  },
  "in_reply_to_status_id_str" : "289079435322339328",
  "geo" : { },
  "id_str" : "289080299449638912",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @johngirvin Even in 2007 http:\/\/t.co\/93OgjSPo (as it was then) was dying against amazon &amp; we had a wholesaler to back us.",
  "id" : 289080299449638912,
  "in_reply_to_status_id" : 289079435322339328,
  "created_at" : "2013-01-09 18:44:48 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/289079892325322752\/photo\/1",
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/jxAqufHR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAMEoWYCUAA97Uq.jpg",
      "id_str" : "289079892329517056",
      "id" : 289079892329517056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAMEoWYCUAA97Uq.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/jxAqufHR"
    } ],
    "hashtags" : [ {
      "text" : "result",
      "indices" : [ 51, 58 ]
    }, {
      "text" : "roadhouse",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289079892325322752",
  "text" : "Living so close to the parents has its advantages! #result #roadhouse http:\/\/t.co\/jxAqufHR",
  "id" : 289079892325322752,
  "created_at" : "2013-01-09 18:43:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 9, 21 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GHOST",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288971063533137920",
  "geo" : { },
  "id_str" : "288971849973514240",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @debbiecreid #GHOST",
  "id" : 288971849973514240,
  "in_reply_to_status_id" : 288971063533137920,
  "created_at" : "2013-01-09 11:33:52 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288967408528531456",
  "geo" : { },
  "id_str" : "288970214459195394",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid cheers. Just sickness this time. Wasn't feeling 100% yest &amp; last night was a train wreck. Will be in tomorrow. Miss the craic.",
  "id" : 288970214459195394,
  "in_reply_to_status_id" : 288967408528531456,
  "created_at" : "2013-01-09 11:27:22 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 51, 61 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SQUIRREL",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/dPXZdbsD",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=GxJj64D5alE",
      "display_url" : "youtube.com\/watch?v=GxJj64\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288966037364416514",
  "text" : "I meant that this video reminds me of working with @smccalden #SQUIRREL - http:\/\/t.co\/dPXZdbsD",
  "id" : 288966037364416514,
  "created_at" : "2013-01-09 11:10:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 83, 93 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SQUIRREL",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288964878708899841",
  "text" : "I miss the craic today :( Being sick is shit.. But this reminds me of working with @smccalden #SQUIRREL",
  "id" : 288964878708899841,
  "created_at" : "2013-01-09 11:06:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/288740618153385985\/photo\/1",
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/ng0vWmn1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAHQD_mCYAAalSy.jpg",
      "id_str" : "288740618157580288",
      "id" : 288740618157580288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAHQD_mCYAAalSy.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/ng0vWmn1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288740618153385985",
  "text" : "I need to reassess my life, or at least the stupid shit I talk about on Twitter. http:\/\/t.co\/ng0vWmn1",
  "id" : 288740618153385985,
  "created_at" : "2013-01-08 20:15:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susanna Reid",
      "screen_name" : "susannareid100",
      "indices" : [ 3, 18 ],
      "id_str" : "19477583",
      "id" : 19477583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288737629124558848",
  "text" : "RT @susannareid100: You can keep your Borgen and Killing and Breaking Bad. Because nothing, nothing beats The West Wing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288723974878294016",
    "text" : "You can keep your Borgen and Killing and Breaking Bad. Because nothing, nothing beats The West Wing.",
    "id" : 288723974878294016,
    "created_at" : "2013-01-08 19:08:54 +0000",
    "user" : {
      "name" : "Susanna Reid",
      "screen_name" : "susannareid100",
      "protected" : false,
      "id_str" : "19477583",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000040936357\/4eb8d0eed29d4603c790d7ab89614aec_normal.jpeg",
      "id" : 19477583,
      "verified" : true
    }
  },
  "id" : 288737629124558848,
  "created_at" : "2013-01-08 20:03:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 27, 34 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brokemycherry",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 71 ],
      "url" : "https:\/\/t.co\/8g7XUAzR",
      "expanded_url" : "https:\/\/github.com\/datasift\/NodeJS-Consumer\/pull\/11",
      "display_url" : "github.com\/datasift\/NodeJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288683316184494081",
  "text" : "My first 'pull request' on @github accepted :D :D https:\/\/t.co\/8g7XUAzR #brokemycherry",
  "id" : 288683316184494081,
  "created_at" : "2013-01-08 16:27:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "boo",
      "screen_name" : "ibobrik",
      "indices" : [ 3, 11 ],
      "id_str" : "15795956",
      "id" : 15795956
    }, {
      "name" : "node js",
      "screen_name" : "nodejs",
      "indices" : [ 51, 58 ],
      "id_str" : "91985735",
      "id" : 91985735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288667353976303616",
  "text" : "RT @ibobrik: 27TB of data read (from disk) for one @nodejs instance in production. still not crashed and with constant memory footprint. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "node js",
        "screen_name" : "nodejs",
        "indices" : [ 38, 45 ],
        "id_str" : "91985735",
        "id" : 91985735
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288554215922606081",
    "text" : "27TB of data read (from disk) for one @nodejs instance in production. still not crashed and with constant memory footprint. so cool",
    "id" : 288554215922606081,
    "created_at" : "2013-01-08 07:54:20 +0000",
    "user" : {
      "name" : "boo",
      "screen_name" : "ibobrik",
      "protected" : false,
      "id_str" : "15795956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2437804668\/image_normal.jpg",
      "id" : 15795956,
      "verified" : false
    }
  },
  "id" : 288667353976303616,
  "created_at" : "2013-01-08 15:23:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Bloch",
      "screen_name" : "AndrewBloch",
      "indices" : [ 3, 15 ],
      "id_str" : "19062754",
      "id" : 19062754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288634603969863680",
  "text" : "RT @AndrewBloch: A master class in customer service from Lego. Boy writes to Lego after losing a mini-figure. Here's their reply... http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/simonapps\/status\/288281355861762048\/photo\/1",
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/ldoMH29j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAAuXaQCIAAc3dl.jpg",
        "id_str" : "288281355870150656",
        "id" : 288281355870150656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAAuXaQCIAAc3dl.jpg",
        "sizes" : [ {
          "h" : 654,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 654,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 654,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/ldoMH29j"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288393587425701888",
    "text" : "A master class in customer service from Lego. Boy writes to Lego after losing a mini-figure. Here's their reply... http:\/\/t.co\/ldoMH29j",
    "id" : 288393587425701888,
    "created_at" : "2013-01-07 21:16:03 +0000",
    "user" : {
      "name" : "Andrew Bloch",
      "screen_name" : "AndrewBloch",
      "protected" : false,
      "id_str" : "19062754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000081556501\/a8dcf8e2c00be908922c05b37ef2479d_normal.jpeg",
      "id" : 19062754,
      "verified" : false
    }
  },
  "id" : 288634603969863680,
  "created_at" : "2013-01-08 13:13:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/ufaZWYhv",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=dXN3QFJRO-Y",
      "display_url" : "youtube.com\/watch?v=dXN3QF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288563802369314816",
  "text" : "This is the single most awesome thing I have ever seen on the internet yet. Pull ups like a boss! http:\/\/t.co\/ufaZWYhv",
  "id" : 288563802369314816,
  "created_at" : "2013-01-08 08:32:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288393453996486656",
  "geo" : { },
  "id_str" : "288394430241705984",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc twenty six day old.... I really fail. It's been a long day!",
  "id" : 288394430241705984,
  "in_reply_to_status_id" : 288393453996486656,
  "created_at" : "2013-01-07 21:19:24 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288393453996486656",
  "text" : "I just retweeted a twenty six year old tweet. I fail.",
  "id" : 288393453996486656,
  "created_at" : "2013-01-07 21:15:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gnip, Inc.",
      "screen_name" : "gnip",
      "indices" : [ 3, 8 ],
      "id_str" : "16958875",
      "id" : 16958875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/6AJ5w7cW",
      "expanded_url" : "http:\/\/bit.ly\/SRCpxs",
      "display_url" : "bit.ly\/SRCpxs"
    } ]
  },
  "geo" : { },
  "id_str" : "288392431752335360",
  "text" : "RT @gnip: Gnip's Highlight Reel for 2012 http:\/\/t.co\/6AJ5w7cW Sharing our company milestones from this year!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/6AJ5w7cW",
        "expanded_url" : "http:\/\/bit.ly\/SRCpxs",
        "display_url" : "bit.ly\/SRCpxs"
      } ]
    },
    "geo" : { },
    "id_str" : "278943620009181184",
    "text" : "Gnip's Highlight Reel for 2012 http:\/\/t.co\/6AJ5w7cW Sharing our company milestones from this year!",
    "id" : 278943620009181184,
    "created_at" : "2012-12-12 19:25:16 +0000",
    "user" : {
      "name" : "Gnip, Inc.",
      "screen_name" : "gnip",
      "protected" : false,
      "id_str" : "16958875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2439636286\/xvakulxcrzzbl1cjtm6w_normal.jpeg",
      "id" : 16958875,
      "verified" : true
    }
  },
  "id" : 288392431752335360,
  "created_at" : "2013-01-07 21:11:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rumble Labs",
      "screen_name" : "rumblelabs",
      "indices" : [ 18, 29 ],
      "id_str" : "20454184",
      "id" : 20454184
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/288332431319252993\/photo\/1",
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/CFveSKxk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BABc0ZLCQAANFjS.png",
      "id_str" : "288332431331835904",
      "id" : 288332431331835904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BABc0ZLCQAANFjS.png",
      "sizes" : [ {
        "h" : 102,
        "resize" : "fit",
        "w" : 943
      }, {
        "h" : 102,
        "resize" : "fit",
        "w" : 943
      }, {
        "h" : 37,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 65,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 102,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/CFveSKxk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288332431319252993",
  "text" : "Just noticed that @rumblelabs asset_sync repo has '666' stars against it... Freaky.. http:\/\/t.co\/CFveSKxk",
  "id" : 288332431319252993,
  "created_at" : "2013-01-07 17:13:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "namountofbleach",
      "indices" : [ 81, 97 ]
    }, {
      "text" : "closeyoureyesbitches",
      "indices" : [ 98, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288279783173922816",
  "text" : "I just freaked out the whole Repknight office there with one statement. #awesome #namountofbleach #closeyoureyesbitches",
  "id" : 288279783173922816,
  "created_at" : "2013-01-07 13:43:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288236806208626688",
  "geo" : { },
  "id_str" : "288240020601589760",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe enjoy :)",
  "id" : 288240020601589760,
  "in_reply_to_status_id" : 288236806208626688,
  "created_at" : "2013-01-07 11:05:50 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288229689389113344",
  "text" : "Fuckin new I shouldn't have opened that link......... \/me sees head explode.",
  "id" : 288229689389113344,
  "created_at" : "2013-01-07 10:24:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287971265300533248",
  "text" : "I know literally \/every\/ actor in Stand By Me. Amazing film.",
  "id" : 287971265300533248,
  "created_at" : "2013-01-06 17:17:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287952772576452608",
  "geo" : { },
  "id_str" : "287963528495763456",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you watching water ship down? I take it you are from that quote :) Amazing film.",
  "id" : 287963528495763456,
  "in_reply_to_status_id" : 287952772576452608,
  "created_at" : "2013-01-06 16:47:09 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287652211897561089",
  "geo" : { },
  "id_str" : "287662856781066242",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl nope I'm not neat a tee vee at the mo.",
  "id" : 287662856781066242,
  "in_reply_to_status_id" : 287652211897561089,
  "created_at" : "2013-01-05 20:52:24 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Parker",
      "screen_name" : "neverbendeasy",
      "indices" : [ 3, 17 ],
      "id_str" : "62000199",
      "id" : 62000199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/uqTg9T6a",
      "expanded_url" : "http:\/\/blog.smartbear.com\/software-quality\/bid\/167051\/14-Ways-to-Contribute-to-Open-Source-without-Being-a-Programming-Genius-or-a-Rock-Star?utm_source=StartupDigest+Reading+List+%28best+articles+on+startup+life%29+%5BStartup+Digest%5D&utm_campaign=70835031d2-StartupDigest_Reading_List_Jan4&utm_medium=email",
      "display_url" : "blog.smartbear.com\/software-quali\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287651293122682880",
  "text" : "RT @neverbendeasy: Great article on contributing to open source without being a programming genius or rock star http:\/\/t.co\/uqTg9T6a",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/uqTg9T6a",
        "expanded_url" : "http:\/\/blog.smartbear.com\/software-quality\/bid\/167051\/14-Ways-to-Contribute-to-Open-Source-without-Being-a-Programming-Genius-or-a-Rock-Star?utm_source=StartupDigest+Reading+List+%28best+articles+on+startup+life%29+%5BStartup+Digest%5D&utm_campaign=70835031d2-StartupDigest_Reading_List_Jan4&utm_medium=email",
        "display_url" : "blog.smartbear.com\/software-quali\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "287650841064792065",
    "text" : "Great article on contributing to open source without being a programming genius or rock star http:\/\/t.co\/uqTg9T6a",
    "id" : 287650841064792065,
    "created_at" : "2013-01-05 20:04:39 +0000",
    "user" : {
      "name" : "Erin Parker",
      "screen_name" : "neverbendeasy",
      "protected" : false,
      "id_str" : "62000199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2950013233\/6ead11497e8913dd0e5ba94a2c5edd8f_normal.jpeg",
      "id" : 62000199,
      "verified" : false
    }
  },
  "id" : 287651293122682880,
  "created_at" : "2013-01-05 20:06:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "jefferson ovalles",
      "screen_name" : "ElDivino",
      "indices" : [ 61, 70 ],
      "id_str" : "296975951",
      "id" : 296975951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287649829507723264",
  "geo" : { },
  "id_str" : "287651252253360128",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl we were both saying how good splash was as a film in @eldivino before Xmas there. It's not that bad a film ;)",
  "id" : 287651252253360128,
  "in_reply_to_status_id" : 287649829507723264,
  "created_at" : "2013-01-05 20:06:17 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Neubauer",
      "screen_name" : "peterneubauer",
      "indices" : [ 3, 17 ],
      "id_str" : "14721805",
      "id" : 14721805
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "in",
      "indices" : [ 117, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/84MLcuCE",
      "expanded_url" : "http:\/\/www.reco4j.org\/index.jsp",
      "display_url" : "reco4j.org\/index.jsp"
    } ]
  },
  "geo" : { },
  "id_str" : "287649833379057664",
  "text" : "RT @peterneubauer: The graph based recommender engine Reco4J: http:\/\/t.co\/84MLcuCE by Alessandro Negro. Pretty cool! #in",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "in",
        "indices" : [ 98, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/84MLcuCE",
        "expanded_url" : "http:\/\/www.reco4j.org\/index.jsp",
        "display_url" : "reco4j.org\/index.jsp"
      } ]
    },
    "geo" : { },
    "id_str" : "287639278245257216",
    "text" : "The graph based recommender engine Reco4J: http:\/\/t.co\/84MLcuCE by Alessandro Negro. Pretty cool! #in",
    "id" : 287639278245257216,
    "created_at" : "2013-01-05 19:18:42 +0000",
    "user" : {
      "name" : "Peter Neubauer",
      "screen_name" : "peterneubauer",
      "protected" : false,
      "id_str" : "14721805",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000529267759\/41cc29f7f7848ef5f452a43c7bd503b0_normal.png",
      "id" : 14721805,
      "verified" : false
    }
  },
  "id" : 287649833379057664,
  "created_at" : "2013-01-05 20:00:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 3, 13 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287604447008403457",
  "text" : "RT @carisenda: The loyalist flag protests should end like Bugsy Malone - big dance routine, that song, cops and rioters covered in custard.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "287574173486837760",
    "text" : "The loyalist flag protests should end like Bugsy Malone - big dance routine, that song, cops and rioters covered in custard.",
    "id" : 287574173486837760,
    "created_at" : "2013-01-05 15:00:00 +0000",
    "user" : {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "protected" : false,
      "id_str" : "212603717",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1513037620\/avatar_normal.png",
      "id" : 212603717,
      "verified" : false
    }
  },
  "id" : 287604447008403457,
  "created_at" : "2013-01-05 17:00:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 11, 18 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287331350942474240",
  "geo" : { },
  "id_str" : "287337854869336064",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @szlwzl the best tv show out ever. Wish I could pay for a mind wipe to watch it again.",
  "id" : 287337854869336064,
  "in_reply_to_status_id" : 287331350942474240,
  "created_at" : "2013-01-04 23:20:57 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 13, 26 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287230213849481219",
  "geo" : { },
  "id_str" : "287230327880032256",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @paul_moffett nope. he wrote it of his own free will :)",
  "id" : 287230327880032256,
  "in_reply_to_status_id" : 287230213849481219,
  "created_at" : "2013-01-04 16:13:41 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 13, 26 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287229590835965953",
  "geo" : { },
  "id_str" : "287229707848663040",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @paul_moffett he wrote it. fact.",
  "id" : 287229707848663040,
  "in_reply_to_status_id" : 287229590835965953,
  "created_at" : "2013-01-04 16:11:13 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 19, 29 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287227999261188097",
  "text" : "as you can imagine @smccalden jumped right on that. So what is fair is far :) I said the stupid thing\u2026 Its a fair cop.",
  "id" : 287227999261188097,
  "created_at" : "2013-01-04 16:04:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287227812132315136",
  "text" : "OH: \"Me and my dad were fucking each other\"\u2026 I said that - just forgot to add the \"over\" part! :D :D :D FML",
  "id" : 287227812132315136,
  "created_at" : "2013-01-04 16:03:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287224319086579713",
  "text" : "OH: \"Its hard\u2026 Like it is \/rock\/ HARD!!!\"",
  "id" : 287224319086579713,
  "created_at" : "2013-01-04 15:49:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 3, 16 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 26, 32 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287222121736843264",
  "text" : "RT @Paul_Moffett: belfast @swmcc rocks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 8, 14 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "287212545687842816",
    "text" : "belfast @swmcc rocks",
    "id" : 287212545687842816,
    "created_at" : "2013-01-04 15:03:01 +0000",
    "user" : {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "protected" : false,
      "id_str" : "36913698",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1175980356\/92313091_N00_normal.jpg",
      "id" : 36913698,
      "verified" : false
    }
  },
  "id" : 287222121736843264,
  "created_at" : "2013-01-04 15:41:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 62, 72 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287147525771784192",
  "text" : "OH: \"Who is this Rick James dude and why his he a bitch?\" \/cc @smccalden",
  "id" : 287147525771784192,
  "created_at" : "2013-01-04 10:44:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 3, 13 ],
      "id_str" : "240194412",
      "id" : 240194412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobfairy",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/gDPMoQTp",
      "expanded_url" : "http:\/\/rkt.me\/TxBios",
      "display_url" : "rkt.me\/TxBios"
    } ]
  },
  "geo" : { },
  "id_str" : "287140854001446912",
  "text" : "RT @RepKnight: Are you looking for a new challenge in 2013? We're hiring - again! http:\/\/t.co\/gDPMoQTp #jobfairy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/app.repknight.com\" rel=\"nofollow\"\u003ERepKnight\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobfairy",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/gDPMoQTp",
        "expanded_url" : "http:\/\/rkt.me\/TxBios",
        "display_url" : "rkt.me\/TxBios"
      } ]
    },
    "geo" : { },
    "id_str" : "287140072048967681",
    "text" : "Are you looking for a new challenge in 2013? We're hiring - again! http:\/\/t.co\/gDPMoQTp #jobfairy",
    "id" : 287140072048967681,
    "created_at" : "2013-01-04 10:15:02 +0000",
    "user" : {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "protected" : false,
      "id_str" : "240194412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1241221112\/repknight_avatar_twitter_normal.jpg",
      "id" : 240194412,
      "verified" : false
    }
  },
  "id" : 287140854001446912,
  "created_at" : "2013-01-04 10:18:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 61, 74 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286950163946278913",
  "text" : "Just got reminded of Django - looks awesome!! Awesome!!! \/cc @RickyHassard",
  "id" : 286950163946278913,
  "created_at" : "2013-01-03 21:40:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286949956928016384",
  "text" : "Blanket ban on anyone mentioning that celeb big bro stuff\u2026 Can't stand that shit\u2026 Breaking Bad is an example of a good tv show - not this!",
  "id" : 286949956928016384,
  "created_at" : "2013-01-03 21:39:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 3, 10 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286948619708424192",
  "text" : "So @github will be running on Rails 3.0 soon. Awesome. Hopefully they'll blog the process. :D",
  "id" : 286948619708424192,
  "created_at" : "2013-01-03 21:34:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Munroe",
      "screen_name" : "leemunroe",
      "indices" : [ 0, 10 ],
      "id_str" : "9445012",
      "id" : 9445012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286910045789245440",
  "geo" : { },
  "id_str" : "286948009923727360",
  "in_reply_to_user_id" : 9445012,
  "text" : "@leemunroe i'd do it for free to help a fellow norn iron fella. Sure let me know :)",
  "id" : 286948009923727360,
  "in_reply_to_status_id" : 286910045789245440,
  "created_at" : "2013-01-03 21:31:51 +0000",
  "in_reply_to_screen_name" : "leemunroe",
  "in_reply_to_user_id_str" : "9445012",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raspberry Pi",
      "screen_name" : "Raspberry_Pi",
      "indices" : [ 85, 98 ],
      "id_str" : "302666251",
      "id" : 302666251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286947714070089729",
  "text" : "Installed Plex on the samsung there. So still no need for an apple tv :) Might get a @Raspberry_Pi for the upstairs and kitchen tv though.",
  "id" : 286947714070089729,
  "created_at" : "2013-01-03 21:30:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 8, 19 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yesyoudid",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286915395196182529",
  "geo" : { },
  "id_str" : "286919178898780161",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco @johngirvin multi tasking JR, multi tasking. You just didn't hire me for my wit, charm and exceptional good looks like :) #yesyoudid",
  "id" : 286919178898780161,
  "in_reply_to_status_id" : 286915395196182529,
  "created_at" : "2013-01-03 19:37:17 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286900688775151616",
  "geo" : { },
  "id_str" : "286900805318086657",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin i'd be anyones bitch at consultant rates :)",
  "id" : 286900805318086657,
  "in_reply_to_status_id" : 286900688775151616,
  "created_at" : "2013-01-03 18:24:17 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286900011281817600",
  "geo" : { },
  "id_str" : "286900406527860739",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin nice one :) Yer own boss - sweet :)",
  "id" : 286900406527860739,
  "in_reply_to_status_id" : 286900011281817600,
  "created_at" : "2013-01-03 18:22:41 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286883342673129472",
  "geo" : { },
  "id_str" : "286891328254660608",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin you leaving? where you going?",
  "id" : 286891328254660608,
  "in_reply_to_status_id" : 286883342673129472,
  "created_at" : "2013-01-03 17:46:37 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286808523839512577",
  "geo" : { },
  "id_str" : "286877701128724480",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard good to see you have the faith. I fear a jacket that is self drying and a hover board isn't happening. An 80's cafe though...",
  "id" : 286877701128724480,
  "in_reply_to_status_id" : 286808523839512577,
  "created_at" : "2013-01-03 16:52:28 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 10, 23 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 24, 31 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286871350327508992",
  "geo" : { },
  "id_str" : "286871416467496961",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo @paul_moffett @rejoco vorsprung durch technik fuckos!",
  "id" : 286871416467496961,
  "in_reply_to_status_id" : 286871350327508992,
  "created_at" : "2013-01-03 16:27:30 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 8, 17 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notachance",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286868875662987265",
  "geo" : { },
  "id_str" : "286870502411218945",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco @davehedo I thought Dave just abandoned her so I thought I'd do the same. If I knew she was on show I'd have washed her. #notachance",
  "id" : 286870502411218945,
  "in_reply_to_status_id" : 286868875662987265,
  "created_at" : "2013-01-03 16:23:52 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instil",
      "screen_name" : "instil",
      "indices" : [ 0, 7 ],
      "id_str" : "804212370",
      "id" : 804212370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286865037132447744",
  "geo" : { },
  "id_str" : "286866919418646528",
  "in_reply_to_user_id" : 804212370,
  "text" : "@instil very interested to hear on your node.js event.. I've used it a few times in repknight. Would be good to see how others use it in NI.",
  "id" : 286866919418646528,
  "in_reply_to_status_id" : 286865037132447744,
  "created_at" : "2013-01-03 16:09:37 +0000",
  "in_reply_to_screen_name" : "instil",
  "in_reply_to_user_id_str" : "804212370",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instil",
      "screen_name" : "instil",
      "indices" : [ 3, 10 ],
      "id_str" : "804212370",
      "id" : 804212370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286866313173934080",
  "text" : "RT @instil: Interested in co-working.  We have a beautiful space, right in the centre of town, ideal for programmers, web designers, etc.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286865749782446080",
    "text" : "Interested in co-working.  We have a beautiful space, right in the centre of town, ideal for programmers, web designers, etc.",
    "id" : 286865749782446080,
    "created_at" : "2013-01-03 16:04:59 +0000",
    "user" : {
      "name" : "Instil",
      "screen_name" : "instil",
      "protected" : false,
      "id_str" : "804212370",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000501365999\/b91cd581faf889c8d54af0c5abe1aeb9_normal.png",
      "id" : 804212370,
      "verified" : false
    }
  },
  "id" : 286866313173934080,
  "created_at" : "2013-01-03 16:07:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 17, 25 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286854860740104193",
  "geo" : { },
  "id_str" : "286865356721643520",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @havoct5 for my secret santa contribution in here I got a 'butt plug' :) Point of order - I gave that to someone.",
  "id" : 286865356721643520,
  "in_reply_to_status_id" : 286854860740104193,
  "created_at" : "2013-01-03 16:03:25 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286847733929754625",
  "text" : "RT @HaVoCT5: 11 songs, 37.7mins, 382.3MB, Justin Bieber Under the mistletoe album??\n\nfucking awful, those 38mins id rather spend sniffin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 125, 131 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286846851297210369",
    "text" : "11 songs, 37.7mins, 382.3MB, Justin Bieber Under the mistletoe album??\n\nfucking awful, those 38mins id rather spend sniffing @swmcc's boxers",
    "id" : 286846851297210369,
    "created_at" : "2013-01-03 14:49:53 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 286847733929754625,
  "created_at" : "2013-01-03 14:53:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 3, 13 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286795944970829825",
  "text" : "RT @carisenda: Sass: a solution I don't want to a problem I never had.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286789813158432768",
    "text" : "Sass: a solution I don't want to a problem I never had.",
    "id" : 286789813158432768,
    "created_at" : "2013-01-03 11:03:14 +0000",
    "user" : {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "protected" : false,
      "id_str" : "212603717",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1513037620\/avatar_normal.png",
      "id" : 212603717,
      "verified" : false
    }
  },
  "id" : 286795944970829825,
  "created_at" : "2013-01-03 11:27:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286789118510370816",
  "text" : "And the first --hard reset of the year has occurred 'it reset --hard origin\/tidy_files' :D :D :D",
  "id" : 286789118510370816,
  "created_at" : "2013-01-03 11:00:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GiTLAB",
      "screen_name" : "gitlab",
      "indices" : [ 105, 112 ],
      "id_str" : "349647792",
      "id" : 349647792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286779719922352129",
  "text" : "Grrrr gitlab seems to error when you try and add more than four projects to a person\u2026 Pain in the ass :( @gitlab",
  "id" : 286779719922352129,
  "created_at" : "2013-01-03 10:23:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 23, 29 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 45, 52 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 85, 96 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/jFMVoshi",
      "expanded_url" : "http:\/\/4sq.com\/pTgij9",
      "display_url" : "4sq.com\/pTgij9"
    } ]
  },
  "geo" : { },
  "id_str" : "286774468129480704",
  "text" : "Achievement Unlocked: \u201C@swmcc: I just ousted @rejoco as the mayor of RepKnight HQ on @foursquare! http:\/\/t.co\/jFMVoshi\u201D",
  "id" : 286774468129480704,
  "created_at" : "2013-01-03 10:02:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 14, 21 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 54, 65 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/jFMVoshi",
      "expanded_url" : "http:\/\/4sq.com\/pTgij9",
      "display_url" : "4sq.com\/pTgij9"
    } ]
  },
  "geo" : { },
  "id_str" : "286774193226412034",
  "text" : "I just ousted @rejoco as the mayor of RepKnight HQ on @foursquare! http:\/\/t.co\/jFMVoshi",
  "id" : 286774193226412034,
  "created_at" : "2013-01-03 10:01:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyent",
      "screen_name" : "joyent",
      "indices" : [ 3, 10 ],
      "id_str" : "666523",
      "id" : 666523
    }, {
      "name" : "NewRelic",
      "screen_name" : "newrelic",
      "indices" : [ 113, 122 ],
      "id_str" : "15527007",
      "id" : 15527007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286555478002126848",
  "text" : "RT @joyent: Coding Forward: Meet the Awesome Developers Behind Obama\u2019s Successful 2012 Presidential Campaign via @NewRelic http:\/\/t.co\/h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NewRelic",
        "screen_name" : "newrelic",
        "indices" : [ 101, 110 ],
        "id_str" : "15527007",
        "id" : 15527007
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/htgsDOVv",
        "expanded_url" : "http:\/\/blog.newrelic.com\/2012\/12\/26\/code-forward-meet-the-awesome-developers-behind-obamas-successful-2012-presidential-campaign\/",
        "display_url" : "blog.newrelic.com\/2012\/12\/26\/cod\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "286555355167748096",
    "text" : "Coding Forward: Meet the Awesome Developers Behind Obama\u2019s Successful 2012 Presidential Campaign via @NewRelic http:\/\/t.co\/htgsDOVv",
    "id" : 286555355167748096,
    "created_at" : "2013-01-02 19:31:35 +0000",
    "user" : {
      "name" : "Joyent",
      "screen_name" : "joyent",
      "protected" : false,
      "id_str" : "666523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916295235\/joyent_avatar_normal.png",
      "id" : 666523,
      "verified" : true
    }
  },
  "id" : 286555478002126848,
  "created_at" : "2013-01-02 19:32:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286554963931451392",
  "geo" : { },
  "id_str" : "286555433299214336",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 got my handbrake working :) mot is next month so fingers crossed.",
  "id" : 286555433299214336,
  "in_reply_to_status_id" : 286554963931451392,
  "created_at" : "2013-01-02 19:31:53 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Ada Initiative",
      "screen_name" : "adainitiative",
      "indices" : [ 3, 17 ],
      "id_str" : "242645565",
      "id" : 242645565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "policccy",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/6DOZg4Xd",
      "expanded_url" : "http:\/\/adainitiative.org\/?p=1052",
      "display_url" : "adainitiative.org\/?p=1052"
    } ]
  },
  "geo" : { },
  "id_str" : "286555216847970305",
  "text" : "RT @adainitiative: Ending sexism in hacker culture: A work in progress http:\/\/t.co\/6DOZg4Xd #29c3 #policccy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "29c3",
        "indices" : [ 73, 78 ]
      }, {
        "text" : "policccy",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/6DOZg4Xd",
        "expanded_url" : "http:\/\/adainitiative.org\/?p=1052",
        "display_url" : "adainitiative.org\/?p=1052"
      } ]
    },
    "geo" : { },
    "id_str" : "286341781187072000",
    "text" : "Ending sexism in hacker culture: A work in progress http:\/\/t.co\/6DOZg4Xd #29c3 #policccy",
    "id" : 286341781187072000,
    "created_at" : "2013-01-02 05:22:55 +0000",
    "user" : {
      "name" : "The Ada Initiative",
      "screen_name" : "adainitiative",
      "protected" : false,
      "id_str" : "242645565",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237659527\/avatar-adainitiative2_normal.png",
      "id" : 242645565,
      "verified" : false
    }
  },
  "id" : 286555216847970305,
  "created_at" : "2013-01-02 19:31:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286542160034164737",
  "text" : "I can now park on hills! And it doesn't shake when you brake (much) :)",
  "id" : 286542160034164737,
  "created_at" : "2013-01-02 18:39:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Schaefer",
      "screen_name" : "dougschaefer",
      "indices" : [ 3, 16 ],
      "id_str" : "11675272",
      "id" : 11675272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "finallyge",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286514616949936128",
  "text" : "RT @dougschaefer: 500MB free at MongoLab. Nodejitsu at $3\/month for one app. Incredibly low barrier to entry these days. Wow. #finallyge ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "finallygetpaas",
        "indices" : [ 108, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286267388889026560",
    "text" : "500MB free at MongoLab. Nodejitsu at $3\/month for one app. Incredibly low barrier to entry these days. Wow. #finallygetpaas",
    "id" : 286267388889026560,
    "created_at" : "2013-01-02 00:27:18 +0000",
    "user" : {
      "name" : "Doug Schaefer",
      "screen_name" : "dougschaefer",
      "protected" : false,
      "id_str" : "11675272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2737765433\/526e310318f2a9f6710fab0360527062_normal.png",
      "id" : 11675272,
      "verified" : false
    }
  },
  "id" : 286514616949936128,
  "created_at" : "2013-01-02 16:49:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286422148451557376",
  "geo" : { },
  "id_str" : "286464189604712449",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight I know, they better get a move on! Happy New Year btw.",
  "id" : 286464189604712449,
  "in_reply_to_status_id" : 286422148451557376,
  "created_at" : "2013-01-02 13:29:19 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 42, 55 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286407975290171392",
  "text" : "2013 till no sign of a hover board... \/cc @RickyHassard",
  "id" : 286407975290171392,
  "created_at" : "2013-01-02 09:45:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cabinfever",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286248237277528065",
  "text" : "Working from home tomorrow due to the car being fixed... Am gonna miss the craic.. #cabinfever",
  "id" : 286248237277528065,
  "created_at" : "2013-01-01 23:11:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/QLx8sAPA",
      "expanded_url" : "http:\/\/blog.swm.cc\/2013\/01\/01\/new-year\/",
      "display_url" : "blog.swm.cc\/2013\/01\/01\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286244982426324993",
  "text" : "New blog post - http:\/\/t.co\/QLx8sAPA",
  "id" : 286244982426324993,
  "created_at" : "2013-01-01 22:58:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 3, 14 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 16, 22 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286213665303166976",
  "text" : "RT @Alana_Doll: @swmcc haha! You amaze me",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "286204317617254401",
    "geo" : { },
    "id_str" : "286204400945471489",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc haha! You amaze me",
    "id" : 286204400945471489,
    "in_reply_to_status_id" : 286204317617254401,
    "created_at" : "2013-01-01 20:17:01 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "protected" : false,
      "id_str" : "67130324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3578323065\/bb177ebc2b37f1d2ee6f3eec1af258d0_normal.jpeg",
      "id" : 67130324,
      "verified" : false
    }
  },
  "id" : 286213665303166976,
  "created_at" : "2013-01-01 20:53:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286202206951178241",
  "geo" : { },
  "id_str" : "286204317617254401",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll 50201600 - bar code for Creme eggs",
  "id" : 286204317617254401,
  "in_reply_to_status_id" : 286202206951178241,
  "created_at" : "2013-01-01 20:16:41 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286195024700510209",
  "geo" : { },
  "id_str" : "286196365556596737",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll too early for a 50201600",
  "id" : 286196365556596737,
  "in_reply_to_status_id" : 286195024700510209,
  "created_at" : "2013-01-01 19:45:05 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodson",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286195964983799809",
  "text" : "Just made the folks a roast to say thanks for feeding me for Christmas. Silverside (eye) 10hrs in the slow cooker. Awesome. #goodson :)",
  "id" : 286195964983799809,
  "created_at" : "2013-01-01 19:43:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286047849421099008",
  "text" : "Just saw an advert for Creme Egg.. Don't think I am alone in my thoughts on it. FUCK. RIGHT. OFF.",
  "id" : 286047849421099008,
  "created_at" : "2013-01-01 09:54:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285898192493613058",
  "text" : "Happy 2013",
  "id" : 285898192493613058,
  "created_at" : "2013-01-01 00:00:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]