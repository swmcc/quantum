Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933463336, -6.2125600416 ]
  },
  "id_str" : "131107235005861888",
  "text" : "I hate this stupid non holiday.....",
  "id" : 131107235005861888,
  "created_at" : "2011-10-31 20:36:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131102292370919425",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb dude - would you have a fiver on ya :D I don't want to have to go the shop to break this \u00A320.. If you can't I'll venture out ;)",
  "id" : 131102292370919425,
  "created_at" : "2011-10-31 20:16:36 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131047241203978241",
  "geo" : { },
  "id_str" : "131052124191727617",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I am off on Friday and Monday next week :) Next Sunday evening will be sweet boy! :D",
  "id" : 131052124191727617,
  "in_reply_to_status_id" : 131047241203978241,
  "created_at" : "2011-10-31 16:57:15 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 95, 107 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 117, 131 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131041396944670720",
  "text" : "This afternoon has dragged cos someone forgot the monday karma rules... And for once it wasn't @stimpled0rf - it was @No_Underscore",
  "id" : 131041396944670720,
  "created_at" : "2011-10-31 16:14:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131008839549075457",
  "geo" : { },
  "id_str" : "131009642011701249",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore saying time was going fast on a Monday. You business owners forget us wage slaves :D Karma will get you C... just wait and c!",
  "id" : 131009642011701249,
  "in_reply_to_status_id" : 131008839549075457,
  "created_at" : "2011-10-31 14:08:27 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131005041048944640",
  "geo" : { },
  "id_str" : "131007139266310144",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore Dude... It is a Monday.. This is the working man's version of a Sunday Morning Truce.. You just broke it! Game on bitch!",
  "id" : 131007139266310144,
  "in_reply_to_status_id" : 131005041048944640,
  "created_at" : "2011-10-31 13:58:30 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 50, 62 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131003101028163584",
  "text" : "Our work IRC channel has really eased comms. From @niall_adams exp. how he names things  \"you're a pile of atoms - I refer to you as 'dick'\"",
  "id" : 131003101028163584,
  "created_at" : "2011-10-31 13:42:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131000950352658433",
  "geo" : { },
  "id_str" : "131002342131773440",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore bastard.... You just made the day go slower by saying that.. No excuse for that C.. No fucking excuse a tall! Burn in hell!",
  "id" : 131002342131773440,
  "in_reply_to_status_id" : 131000950352658433,
  "created_at" : "2011-10-31 13:39:26 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130993936197095424",
  "geo" : { },
  "id_str" : "130995067233124353",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb you must be near 40 now ffs :D",
  "id" : 130995067233124353,
  "in_reply_to_status_id" : 130993936197095424,
  "created_at" : "2011-10-31 13:10:32 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130993936197095424",
  "geo" : { },
  "id_str" : "130995032504279041",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb you would know :D",
  "id" : 130995032504279041,
  "in_reply_to_status_id" : 130993936197095424,
  "created_at" : "2011-10-31 13:10:24 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "NicolaGrahamPlunkett",
      "screen_name" : "Nikkinoodles99",
      "indices" : [ 10, 25 ],
      "id_str" : "389093092",
      "id" : 389093092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130991713144668161",
  "geo" : { },
  "id_str" : "130992819325243392",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @nikkinoodles99 Thing is I was even talking to it to someone last night at around 10pm... 10 hours later - completely gone...",
  "id" : 130992819325243392,
  "in_reply_to_status_id" : 130991713144668161,
  "created_at" : "2011-10-31 13:01:36 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "NicolaGrahamPlunkett",
      "screen_name" : "Nikkinoodles99",
      "indices" : [ 10, 25 ],
      "id_str" : "389093092",
      "id" : 389093092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130991016852471808",
  "geo" : { },
  "id_str" : "130991502208942080",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @nikkinoodles99 fuck sake! Right tomorrow mornin... Promise.... Fuck me pink. Would go for after work - but forgot wallet :( 8am",
  "id" : 130991502208942080,
  "in_reply_to_status_id" : 130991016852471808,
  "created_at" : "2011-10-31 12:56:22 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 0, 9 ],
      "id_str" : "9488072",
      "id" : 9488072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130940535874654209",
  "geo" : { },
  "id_str" : "130940780276752384",
  "in_reply_to_user_id" : 9488072,
  "text" : "@shylands :D I thought you retweeted something by him this morning. Then I thought WTF would Matt Smith do with an app idea? :)",
  "id" : 130940780276752384,
  "in_reply_to_status_id" : 130940535874654209,
  "created_at" : "2011-10-31 09:34:49 +0000",
  "in_reply_to_screen_name" : "shylands",
  "in_reply_to_user_id_str" : "9488072",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 24, 31 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130940023519457280",
  "text" : "Awesome... I even think @srushe \"Good Morning\" was filled with sarcasm :D",
  "id" : 130940023519457280,
  "created_at" : "2011-10-31 09:31:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 16, 25 ],
      "id_str" : "9488072",
      "id" : 9488072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130938571463991296",
  "text" : "Ok.. I just saw @shylands new pic on twitter... Just me - or does he look a good bit like Matt Smith??? :D",
  "id" : 130938571463991296,
  "created_at" : "2011-10-31 09:26:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 34, 49 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/6G1uFhJo",
      "expanded_url" : "http:\/\/poemtweet.com\/2011\/10\/30\/mondays-not-as-good-as-sundays",
      "display_url" : "poemtweet.com\/2011\/10\/30\/mon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "130784303691997184",
  "text" : "http:\/\/t.co\/6G1uFhJo by the great @Georgina_Milne",
  "id" : 130784303691997184,
  "created_at" : "2011-10-30 23:13:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130404526422376448",
  "text" : "I thought I was better from last Thursday... I am wrong.... Dead wrong :(",
  "id" : 130404526422376448,
  "created_at" : "2011-10-29 22:03:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/130392207839592448\/photo\/1",
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/C44RDIVP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ac8_Ba4CAAAbr1d.jpg",
      "id_str" : "130392207843786752",
      "id" : 130392207843786752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ac8_Ba4CAAAbr1d.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C44RDIVP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130392207839592448",
  "text" : "Fuck..... http:\/\/t.co\/C44RDIVP",
  "id" : 130392207839592448,
  "created_at" : "2011-10-29 21:15:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5934132963, -6.2125184393 ]
  },
  "id_str" : "130347199006646272",
  "text" : "I am watching Strictly Come Dancing..... And I am enjoying it!",
  "id" : 130347199006646272,
  "created_at" : "2011-10-29 18:16:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933719012, -6.2126790397 ]
  },
  "id_str" : "130019789040123904",
  "text" : "Forgot I have to be at airport for 5am tomorrow morning. That's nice... That's fuckin nice!",
  "id" : 130019789040123904,
  "created_at" : "2011-10-28 20:35:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 14, 21 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129945840319086592",
  "geo" : { },
  "id_str" : "129947213089615873",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @padzor Almost brought the mail server in work down with a stupid bug :\/ Happens I suppose but still :\/",
  "id" : 129947213089615873,
  "in_reply_to_status_id" : 129945840319086592,
  "created_at" : "2011-10-28 15:46:44 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129945377406328832",
  "text" : "Well that was an interesting way to end a Friday ;)",
  "id" : 129945377406328832,
  "created_at" : "2011-10-28 15:39:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmhidesinthecorner",
      "indices" : [ 40, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129941375377604608",
  "text" : "\"Someone sent a load of emails there?!\" #swmhidesinthecorner",
  "id" : 129941375377604608,
  "created_at" : "2011-10-28 15:23:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129935241564528640",
  "text" : "Just had one of those moments where I start to doubt that I can actually programme!!!",
  "id" : 129935241564528640,
  "created_at" : "2011-10-28 14:59:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129920683621892096",
  "geo" : { },
  "id_str" : "129920952975888385",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe When steve showed it to me I got a pang of nostaliga. Mutt is so much nicer to use than any a GUI. Trust us :D",
  "id" : 129920952975888385,
  "in_reply_to_status_id" : 129920683621892096,
  "created_at" : "2011-10-28 14:02:23 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 4, 11 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/8ZgV3TBj",
      "expanded_url" : "http:\/\/lifehacker.com\/5574557\/how-to-use-the-fast-and-powerful-mutt-email-client-with-gmail",
      "display_url" : "lifehacker.com\/5574557\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129913881882664960",
  "text" : "via @srushe - http:\/\/t.co\/8ZgV3TBj - the way real men read their mail :D",
  "id" : 129913881882664960,
  "created_at" : "2011-10-28 13:34:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "NicolaGrahamPlunkett",
      "screen_name" : "Nikkinoodles99",
      "indices" : [ 10, 25 ],
      "id_str" : "389093092",
      "id" : 389093092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129852650056466432",
  "geo" : { },
  "id_str" : "129853343899205632",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @nikkinoodles99 I was off sick yesterday and forgot!! Monday I promise - first thing on Monday! :) Really really promise.",
  "id" : 129853343899205632,
  "in_reply_to_status_id" : 129852650056466432,
  "created_at" : "2011-10-28 09:33:44 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129295409674846208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933518819, -6.2126164773 ]
  },
  "id_str" : "129298902540234752",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard me too. Was screaming at the tv :)",
  "id" : 129298902540234752,
  "in_reply_to_status_id" : 129295409674846208,
  "created_at" : "2011-10-26 20:50:35 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toomuchinfo",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593344687, -6.2125198511 ]
  },
  "id_str" : "129298740145168384",
  "text" : "The bro had a bug at the weekend that did bad wicked things to him... I fear I have it. Time will tell I guess. #toomuchinfo",
  "id" : 129298740145168384,
  "created_at" : "2011-10-26 20:49:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129272565377138689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5977288995, -6.2107621439 ]
  },
  "id_str" : "129297920750137344",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe shit one... One of the reasons to have your files in \/etc\/corn.tab - but I like it in files. No back ups?",
  "id" : 129297920750137344,
  "in_reply_to_status_id" : 129272565377138689,
  "created_at" : "2011-10-26 20:46:41 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933517025, -6.212632037 ]
  },
  "id_str" : "129297616205922304",
  "text" : "I love Frozen Planet... Cheered when the wee penguin got away from the sea lion :)",
  "id" : 129297616205922304,
  "created_at" : "2011-10-26 20:45:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128949563385065472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933517311, -6.2126318884 ]
  },
  "id_str" : "129297278086295552",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard yeah we should. Name the time and place... Just wear something slutty :)",
  "id" : 129297278086295552,
  "in_reply_to_status_id" : 128949563385065472,
  "created_at" : "2011-10-26 20:44:07 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 6, 13 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 22, 28 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/129182595287224320\/photo\/1",
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/duO6I109",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Acry4s-CEAECBlH.jpg",
      "id_str" : "129182595291418625",
      "id" : 129182595291418625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Acry4s-CEAECBlH.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/duO6I109"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129182595287224320",
  "text" : "Damn! @srushe 157,631 @swmcc 0. http:\/\/t.co\/duO6I109",
  "id" : 129182595287224320,
  "created_at" : "2011-10-26 13:08:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/129175057984536577\/photo\/1",
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/mrEgdVT9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AcrsB-VCQAAjDOw.jpg",
      "id_str" : "129175057988730880",
      "id" : 129175057988730880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AcrsB-VCQAAjDOw.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/mrEgdVT9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129175057984536577",
  "text" : "Snoopy keeps watch http:\/\/t.co\/mrEgdVT9",
  "id" : 129175057984536577,
  "created_at" : "2011-10-26 12:38:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 59, 66 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 109, 115 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chess",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129173502438817793",
  "text" : "In the blue corner - wearing the red trunks with pink trim @srushe. In the blue corner wearing white yfronts @swmcc. Lets get it on. #chess",
  "id" : 129173502438817793,
  "created_at" : "2011-10-26 12:32:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933555907, -6.212628679 ]
  },
  "id_str" : "128923324679077889",
  "text" : "I love that new Tesco advert for the mobile phones :)",
  "id" : 128923324679077889,
  "created_at" : "2011-10-25 19:58:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128922254292680704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933555907, -6.212628679 ]
  },
  "id_str" : "128923205753774080",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf Happy he got a good write up. He has had a few hard weeks there. He says fuck all though. Found that out from a RSS feed :)",
  "id" : 128923205753774080,
  "in_reply_to_status_id" : 128922254292680704,
  "created_at" : "2011-10-25 19:57:42 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/5QYON1Cz",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/blogs\/stuartbailie\/2011\/10\/mccullough_was_here.shtml",
      "display_url" : "bbc.co.uk\/blogs\/stuartba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128918625003388930",
  "text" : "The bro got a good write up here.. http:\/\/t.co\/5QYON1Cz",
  "id" : 128918625003388930,
  "created_at" : "2011-10-25 19:39:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 0, 12 ],
      "id_str" : "216299334",
      "id" : 216299334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128818009312731136",
  "geo" : { },
  "id_str" : "128819744722784257",
  "in_reply_to_user_id" : 216299334,
  "text" : "@piersmorgan Lets face it - the tree is much more interesting.",
  "id" : 128819744722784257,
  "in_reply_to_status_id" : 128818009312731136,
  "created_at" : "2011-10-25 13:06:35 +0000",
  "in_reply_to_screen_name" : "piersmorgan",
  "in_reply_to_user_id_str" : "216299334",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128814660479750144",
  "text" : "Just killed two annoying bugs there... Felt good :)",
  "id" : 128814660479750144,
  "created_at" : "2011-10-25 12:46:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 12, 24 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128769760786784256",
  "geo" : { },
  "id_str" : "128770587878375424",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @stimpled0rf it is that good! Bestest. Cake. Ever.",
  "id" : 128770587878375424,
  "in_reply_to_status_id" : 128769760786784256,
  "created_at" : "2011-10-25 09:51:15 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 12, 24 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128766506350821376",
  "geo" : { },
  "id_str" : "128768522087178240",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @stimpled0rf It was amazing... Easily the best cake yet.. So light... Cake Coma... Yes... Awesomness... Thanks again :D",
  "id" : 128768522087178240,
  "in_reply_to_status_id" : 128766506350821376,
  "created_at" : "2011-10-25 09:43:02 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 11, 22 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 33, 45 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/128751844053889024\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/MhHuxPYG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AclrHrmCMAAG3do.jpg",
      "id_str" : "128751844062277632",
      "id" : 128751844062277632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AclrHrmCMAAG3do.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MhHuxPYG"
    } ],
    "hashtags" : [ {
      "text" : "bakinggoddess",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128751844053889024",
  "text" : "The lovely @Alana_Doll and great @stimpled0rf baked this for me.. Thanks very much. It's awesome! #bakinggoddess http:\/\/t.co\/MhHuxPYG",
  "id" : 128751844053889024,
  "created_at" : "2011-10-25 08:36:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933308189, -6.2126099593 ]
  },
  "id_str" : "128588772978851841",
  "text" : "Wow. Wow. Turned on Sky News. Cameron got his ass kicked! If you take in absents almost 100 defied the whip! Not even Major got that...",
  "id" : 128588772978851841,
  "created_at" : "2011-10-24 21:48:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128524669325295618",
  "text" : "Cos of the rain - it took me 45mins to get home... If you are travelling the roads near Glenavy be careful.. It really is bad out there!",
  "id" : 128524669325295618,
  "created_at" : "2011-10-24 17:34:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Crawford",
      "screen_name" : "Kitty_Crawford",
      "indices" : [ 3, 18 ],
      "id_str" : "21756710",
      "id" : 21756710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/GrridYSv",
      "expanded_url" : "http:\/\/www.facebook.com\/event.php?eid=264584740243841",
      "display_url" : "facebook.com\/event.php?eid=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128491686002311169",
  "text" : "RT @Kitty_Crawford: Hey folks, another reminder of my Halloween charity event, The Witching Hour. Check it out - \n\nhttp:\/\/t.co\/GrridYSv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/GrridYSv",
        "expanded_url" : "http:\/\/www.facebook.com\/event.php?eid=264584740243841",
        "display_url" : "facebook.com\/event.php?eid=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "128490419226017793",
    "text" : "Hey folks, another reminder of my Halloween charity event, The Witching Hour. Check it out - \n\nhttp:\/\/t.co\/GrridYSv",
    "id" : 128490419226017793,
    "created_at" : "2011-10-24 15:17:57 +0000",
    "user" : {
      "name" : "Kitty Crawford",
      "screen_name" : "Kitty_Crawford",
      "protected" : false,
      "id_str" : "21756710",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000559629985\/453956845836c7399a57763c448d9f7a_normal.jpeg",
      "id" : 21756710,
      "verified" : false
    }
  },
  "id" : 128491686002311169,
  "created_at" : "2011-10-24 15:22:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128487790685061121",
  "text" : "The bat-bat's have went on ma trackpad... So am reverting to using the trackpad on the laptop... Think its gonna be hard going!",
  "id" : 128487790685061121,
  "created_at" : "2011-10-24 15:07:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "NicolaGrahamPlunkett",
      "screen_name" : "Nikkinoodles99",
      "indices" : [ 10, 25 ],
      "id_str" : "389093092",
      "id" : 389093092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128448631576608769",
  "geo" : { },
  "id_str" : "128449225896898560",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @nikkinoodles99 well good luck trying to get that outta me on Friday... But you never know - you show me a bit of nipple......",
  "id" : 128449225896898560,
  "in_reply_to_status_id" : 128448631576608769,
  "created_at" : "2011-10-24 12:34:16 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128446908783001600",
  "text" : "Ha! @bbcconormac was in Glenavy today!! Awesome - one of the best journalists that BBC NI has to offer IMVHO.",
  "id" : 128446908783001600,
  "created_at" : "2011-10-24 12:25:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "NicolaGrahamPlunkett",
      "screen_name" : "Nikkinoodles99",
      "indices" : [ 10, 25 ],
      "id_str" : "389093092",
      "id" : 389093092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128440001703845888",
  "geo" : { },
  "id_str" : "128446049655332865",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @Nikkinoodles99 Feck.. I forgot about that! Of course I wants it... Can I pick it up on Friday :D",
  "id" : 128446049655332865,
  "in_reply_to_status_id" : 128440001703845888,
  "created_at" : "2011-10-24 12:21:39 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933665479, -6.2126698914 ]
  },
  "id_str" : "128216794073804800",
  "text" : "The difference between a Friday night and a Sunday is amazing...",
  "id" : 128216794073804800,
  "created_at" : "2011-10-23 21:10:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Bowen",
      "screen_name" : "jfjbowen",
      "indices" : [ 3, 12 ],
      "id_str" : "827588605",
      "id" : 827588605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Benghazi",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128214873552338944",
  "text" : "RT @jfjbowen: Brief moment of wifi in #Benghazi. City full of excited people. 1000s bullets going up into air. Wish they'd just cheer wh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Benghazi",
        "indices" : [ 24, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128210188481200128",
    "text" : "Brief moment of wifi in #Benghazi. City full of excited people. 1000s bullets going up into air. Wish they'd just cheer when they celebrate",
    "id" : 128210188481200128,
    "created_at" : "2011-10-23 20:44:25 +0000",
    "user" : {
      "name" : "Jeremy Bowen",
      "screen_name" : "BowenBBC",
      "protected" : false,
      "id_str" : "42501345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000379861830\/bb540a72768fd510d9c9c17c5a8c8060_normal.jpeg",
      "id" : 42501345,
      "verified" : false
    }
  },
  "id" : 128214873552338944,
  "created_at" : "2011-10-23 21:03:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Nolan",
      "screen_name" : "StephenNolan",
      "indices" : [ 0, 13 ],
      "id_str" : "36673147",
      "id" : 36673147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128198909960003585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933659058, -6.2126696366 ]
  },
  "id_str" : "128200044376633344",
  "in_reply_to_user_id" : 36673147,
  "text" : "@StephenNolan it's pretty bad. Constant rain all day.",
  "id" : 128200044376633344,
  "in_reply_to_status_id" : 128198909960003585,
  "created_at" : "2011-10-23 20:04:07 +0000",
  "in_reply_to_screen_name" : "StephenNolan",
  "in_reply_to_user_id_str" : "36673147",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933310788, -6.2123598157 ]
  },
  "id_str" : "128191714241417216",
  "text" : "Now there is a good performer - Bruno just kicked the Profs ass!!!",
  "id" : 128191714241417216,
  "created_at" : "2011-10-23 19:31:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xfactor",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593355389, -6.2126296361 ]
  },
  "id_str" : "128188155420618754",
  "text" : "Okay. It is now official - I am now middle aged.. Cos I haven't a fucking clue who this Prof Greene is... It's awful as well!!! #xfactor",
  "id" : 128188155420618754,
  "created_at" : "2011-10-23 19:16:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128185479584681984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.6054309627, -6.206672792 ]
  },
  "id_str" : "128187018999115777",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne good to hear :) Keep the tweets a comin too.. Hmmm how about a poem about how crap\nSunday evenings are cos of Mondays :)",
  "id" : 128187018999115777,
  "in_reply_to_status_id" : 128185479584681984,
  "created_at" : "2011-10-23 19:12:21 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "topgear",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933459909, -6.2124675969 ]
  },
  "id_str" : "128174234915713024",
  "text" : "Don't usually likeTop Gear.. But this episode in Bolivia is cracking me up :) #topgear",
  "id" : 128174234915713024,
  "created_at" : "2011-10-23 18:21:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128119252849926144",
  "text" : "After 20mins... They (Xbox) give me this: Your gamer tag is: AvailingWig3249. Bastards",
  "id" : 128119252849926144,
  "created_at" : "2011-10-23 14:43:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128118101500887040",
  "text" : "Setting up a Xbox Live Account is really starting to try my patience...",
  "id" : 128118101500887040,
  "created_at" : "2011-10-23 14:38:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gervais",
      "screen_name" : "rickygervais",
      "indices" : [ 0, 13 ],
      "id_str" : "20015311",
      "id" : 20015311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128063803584815104",
  "in_reply_to_user_id" : 20015311,
  "text" : "@rickygervais I just wateched when Karl met Warrick. Fucking genius. Great way to start a Sunday. Retweet that!",
  "id" : 128063803584815104,
  "created_at" : "2011-10-23 11:02:44 +0000",
  "in_reply_to_screen_name" : "rickygervais",
  "in_reply_to_user_id_str" : "20015311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593360162, -6.2123978072 ]
  },
  "id_str" : "127830441980993536",
  "text" : "I am watching the X-Factor at the mo at the folks house... What a pile of shite....",
  "id" : 127830441980993536,
  "created_at" : "2011-10-22 19:35:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127789771882901504",
  "geo" : { },
  "id_str" : "127790106869374976",
  "in_reply_to_user_id" : 19477583,
  "text" : "@susannar100 sure you can :D I do!!!",
  "id" : 127790106869374976,
  "in_reply_to_status_id" : 127789771882901504,
  "created_at" : "2011-10-22 16:55:10 +0000",
  "in_reply_to_screen_name" : "susannareid100",
  "in_reply_to_user_id_str" : "19477583",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 14, 29 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127782649044541440",
  "geo" : { },
  "id_str" : "127783091409391617",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @georgina_milne congrats G :D",
  "id" : 127783091409391617,
  "in_reply_to_status_id" : 127782649044541440,
  "created_at" : "2011-10-22 16:27:17 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127775003742715904",
  "geo" : { },
  "id_str" : "127782836815134721",
  "in_reply_to_user_id" : 19477583,
  "text" : "@susannar100 I get the impression you are not a fan of Belfast? :D",
  "id" : 127782836815134721,
  "in_reply_to_status_id" : 127775003742715904,
  "created_at" : "2011-10-22 16:26:17 +0000",
  "in_reply_to_screen_name" : "susannareid100",
  "in_reply_to_user_id_str" : "19477583",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 57, 65 ],
      "id_str" : "7885972",
      "id" : 7885972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmokeyAndTheBanditII",
      "indices" : [ 66, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/QVaDouEB",
      "expanded_url" : "http:\/\/bit.ly\/pNAqEs",
      "display_url" : "bit.ly\/pNAqEs"
    } ]
  },
  "geo" : { },
  "id_str" : "127716308983877632",
  "text" : "Nowhere near as good as I remember. http:\/\/t.co\/QVaDouEB @GetGlue #SmokeyAndTheBanditII",
  "id" : 127716308983877632,
  "created_at" : "2011-10-22 12:01:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127643506876485633",
  "geo" : { },
  "id_str" : "127668291140464640",
  "in_reply_to_user_id" : 19477583,
  "text" : "@susannar100 you can guess.... However its not raining... yet :)",
  "id" : 127668291140464640,
  "in_reply_to_status_id" : 127643506876485633,
  "created_at" : "2011-10-22 08:51:07 +0000",
  "in_reply_to_screen_name" : "susannareid100",
  "in_reply_to_user_id_str" : "19477583",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127481820240560128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933417949, -6.2125374553 ]
  },
  "id_str" : "127487077620260864",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall am sure it'll happen someday :)",
  "id" : 127487077620260864,
  "in_reply_to_status_id" : 127481820240560128,
  "created_at" : "2011-10-21 20:51:02 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Braziel",
      "screen_name" : "Braziel",
      "indices" : [ 0, 8 ],
      "id_str" : "776654",
      "id" : 776654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127454864652513280",
  "geo" : { },
  "id_str" : "127457308992217088",
  "in_reply_to_user_id" : 776654,
  "text" : "@Braziel pretty sure I didn't. Though the last few months have been a daze with me just coming out of it on Wed... Hmmmmm \/me checks...",
  "id" : 127457308992217088,
  "in_reply_to_status_id" : 127454864652513280,
  "created_at" : "2011-10-21 18:52:45 +0000",
  "in_reply_to_screen_name" : "Braziel",
  "in_reply_to_user_id_str" : "776654",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127454427459239937",
  "text" : "I just got called \"Sir\" on several occasions by different people in Tesco tonight... WTF did that happen?",
  "id" : 127454427459239937,
  "created_at" : "2011-10-21 18:41:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 70, 82 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127318672866942976",
  "geo" : { },
  "id_str" : "127326408455360512",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf Oh no - never! Was just focused on getting dogs done for @niall_adams - only so long I can ignore the man like :)",
  "id" : 127326408455360512,
  "in_reply_to_status_id" : 127318672866942976,
  "created_at" : "2011-10-21 10:12:36 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 7, 19 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127300035896557568",
  "text" : "I miss @stimpled0rf Its not Friday without the pilgrimage for the sausages of baps!",
  "id" : 127300035896557568,
  "created_at" : "2011-10-21 08:27:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127289252827512832",
  "text" : "&lt;6yearold&gt;I don't wanna go into work today... I don't wanna!!!!!! Waaaaahhhhh!!!!!!!&lt;\/6yearold&gt;",
  "id" : 127289252827512832,
  "created_at" : "2011-10-21 07:44:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126948881945735168",
  "text" : "I feel really really sick :(",
  "id" : 126948881945735168,
  "created_at" : "2011-10-20 09:12:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 60, 74 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126936849901039618",
  "geo" : { },
  "id_str" : "126946559563792385",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf these last few days its been George Michael... @jenporterhall - hmmmmm! :D",
  "id" : 126946559563792385,
  "in_reply_to_status_id" : 126936849901039618,
  "created_at" : "2011-10-20 09:03:13 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126650065082257408",
  "geo" : { },
  "id_str" : "126654968760500225",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe Awesome :D",
  "id" : 126654968760500225,
  "in_reply_to_status_id" : 126650065082257408,
  "created_at" : "2011-10-19 13:44:32 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 28, 41 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126632386539683840",
  "geo" : { },
  "id_str" : "126636168610717697",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne did you and @stevebiscuit have a good holiday?",
  "id" : 126636168610717697,
  "in_reply_to_status_id" : 126632386539683840,
  "created_at" : "2011-10-19 12:29:50 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126629398160998401",
  "text" : "I really hate the in_array function in php.. Like how hard is it to cope with an array with nothing in it?",
  "id" : 126629398160998401,
  "created_at" : "2011-10-19 12:02:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126583400726413312",
  "text" : "You can always tell how fucked off I am by the amount of coffee\/tea I drink in a given time. Been in here 2 hours and am on my 3rd cup!",
  "id" : 126583400726413312,
  "created_at" : "2011-10-19 09:00:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126569230572326912",
  "geo" : { },
  "id_str" : "126572237175271424",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne yeah - no way you are a nerd G.. :)",
  "id" : 126572237175271424,
  "in_reply_to_status_id" : 126569230572326912,
  "created_at" : "2011-10-19 08:15:47 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126400453322870784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933221833, -6.2127085246 ]
  },
  "id_str" : "126401532592783362",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @niall_adams best work I've done in a long time :)",
  "id" : 126401532592783362,
  "in_reply_to_status_id" : 126400453322870784,
  "created_at" : "2011-10-18 20:57:28 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126394238157066240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933714942, -6.2126631068 ]
  },
  "id_str" : "126401077141700610",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you're back :) :) :)",
  "id" : 126401077141700610,
  "in_reply_to_status_id" : 126394238157066240,
  "created_at" : "2011-10-18 20:55:39 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 13, 25 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126390389417574400",
  "geo" : { },
  "id_str" : "126391977330745344",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @stimpled0rf :D",
  "id" : 126391977330745344,
  "in_reply_to_status_id" : 126390389417574400,
  "created_at" : "2011-10-18 20:19:30 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 32, 44 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126387278892380160",
  "geo" : { },
  "id_str" : "126390205975506944",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I broke you... And @stimpled0rf broke today - he made a grown woman cry :D",
  "id" : 126390205975506944,
  "in_reply_to_status_id" : 126387278892380160,
  "created_at" : "2011-10-18 20:12:27 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126387278892380160",
  "geo" : { },
  "id_str" : "126390090141413376",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams you huffed :)",
  "id" : 126390090141413376,
  "in_reply_to_status_id" : 126387278892380160,
  "created_at" : "2011-10-18 20:12:00 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126386246334423040",
  "geo" : { },
  "id_str" : "126386678301593600",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I noticed the way he didn't huff either.. Unlike someone I can mention.",
  "id" : 126386678301593600,
  "in_reply_to_status_id" : 126386246334423040,
  "created_at" : "2011-10-18 19:58:26 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126273522724122624",
  "text" : "My brother, as nice as a person as he is - is possibly the biggest asshole I have ever met. And I know me!",
  "id" : 126273522724122624,
  "created_at" : "2011-10-18 12:28:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/126196386168438784\/photo\/1",
      "indices" : [ 39, 58 ],
      "url" : "http:\/\/t.co\/JJYxCFE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AcBW8dHCAAAwicz.jpg",
      "id_str" : "126196386172633088",
      "id" : 126196386172633088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AcBW8dHCAAAwicz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/JJYxCFE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126196386168438784",
  "text" : "Snoopy better cheer the fuck up today! http:\/\/t.co\/JJYxCFE",
  "id" : 126196386168438784,
  "created_at" : "2011-10-18 07:22:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125934515578355712",
  "text" : "I am greatful for my job - I really am... But fuck me pink - roll on hometime!!!",
  "id" : 125934515578355712,
  "created_at" : "2011-10-17 14:01:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125916546043346944",
  "text" : "Having to look up rsync commands annoys me.",
  "id" : 125916546043346944,
  "created_at" : "2011-10-17 12:50:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125912591963926529",
  "text" : "I've said it numerous times before.... but by fuck I do hate Mondays :(",
  "id" : 125912591963926529,
  "created_at" : "2011-10-17 12:34:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125703621840093184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.6101419954, -6.2058068964 ]
  },
  "id_str" : "125704472402993152",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall the tunes are alright. I have their Best Of album. But it's light hearted tunes. They don't pretend to be serious unlike GM!",
  "id" : 125704472402993152,
  "in_reply_to_status_id" : 125703621840093184,
  "created_at" : "2011-10-16 22:47:36 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125699960221073408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933597086, -6.2126866459 ]
  },
  "id_str" : "125700186004652032",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I am, I like them. Also have z huge crush on Claire from it.",
  "id" : 125700186004652032,
  "in_reply_to_status_id" : 125699960221073408,
  "created_at" : "2011-10-16 22:30:34 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125697422788792320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933585617, -6.2126857512 ]
  },
  "id_str" : "125699251887013888",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall Steps are reunited... Now there is a cool band :)",
  "id" : 125699251887013888,
  "in_reply_to_status_id" : 125697422788792320,
  "created_at" : "2011-10-16 22:26:51 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125618664010555392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933644469, -6.2126674575 ]
  },
  "id_str" : "125696366893727744",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall he's vastly over rated!",
  "id" : 125696366893727744,
  "in_reply_to_status_id" : 125618664010555392,
  "created_at" : "2011-10-16 22:15:23 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125172177187250176",
  "text" : "Airport run at 5am this morning.. Only up now - half of the Saturday already gone. Gonna be a short weekend :(",
  "id" : 125172177187250176,
  "created_at" : "2011-10-15 11:32:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 61, 73 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.577579, -5.9619387725 ]
  },
  "id_str" : "124903957540769792",
  "text" : "It's a sad day when the most action you've got in a while is @stimpled0rf touching you in a meeting :) Boundaries Simpson. Learn them ;)",
  "id" : 124903957540769792,
  "created_at" : "2011-10-14 17:46:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124838637878788096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.577485516, -5.9618518397 ]
  },
  "id_str" : "124903019711172609",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues chairs :) Ordered one :)",
  "id" : 124903019711172609,
  "in_reply_to_status_id" : 124838637878788096,
  "created_at" : "2011-10-14 17:42:55 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marty Pauley",
      "screen_name" : "maokt",
      "indices" : [ 133, 139 ],
      "id_str" : "15037624",
      "id" : 15037624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124858281125609472",
  "text" : "Look its a Marty!  Without blowing sunshine with his ass, easily the most talented programmer I have worked with and a real nice guy @maokt",
  "id" : 124858281125609472,
  "created_at" : "2011-10-14 14:45:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 50, 57 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124799427985678337",
  "geo" : { },
  "id_str" : "124833544517328896",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues where did you get the iPhone stand that @srushe uses :D I wants to get one :D",
  "id" : 124833544517328896,
  "in_reply_to_status_id" : 124799427985678337,
  "created_at" : "2011-10-14 13:06:50 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933394383, -6.2125199783 ]
  },
  "id_str" : "123379737430212609",
  "text" : "Steps are re-forming... Awesome :)",
  "id" : 123379737430212609,
  "created_at" : "2011-10-10 12:49:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123153131348570113",
  "geo" : { },
  "id_str" : "123153230451572737",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery ya wha?",
  "id" : 123153230451572737,
  "in_reply_to_status_id" : 123153131348570113,
  "created_at" : "2011-10-09 21:49:52 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123149455519256576",
  "geo" : { },
  "id_str" : "123153000830210049",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall Oul Pauline is too busy keeping tabs on her hubby :)",
  "id" : 123153000830210049,
  "in_reply_to_status_id" : 123149455519256576,
  "created_at" : "2011-10-09 21:48:58 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123146984247930880",
  "geo" : { },
  "id_str" : "123152829618716672",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery I followed Gary Barlow on twitter... Just saying - 16 years ago I would have been ashamed of such a thing. Now I am \"meh\".",
  "id" : 123152829618716672,
  "in_reply_to_status_id" : 123146984247930880,
  "created_at" : "2011-10-09 21:48:17 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123148480108707840",
  "geo" : { },
  "id_str" : "123148645842436096",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I know - was just watching that - and thinking that he should try yours!!!!! You should sell it!",
  "id" : 123148645842436096,
  "in_reply_to_status_id" : 123148480108707840,
  "created_at" : "2011-10-09 21:31:39 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GaryBarlow",
      "screen_name" : "GBarlowOfficial",
      "indices" : [ 16, 32 ],
      "id_str" : "1433320484",
      "id" : 1433320484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123139911854469120",
  "text" : "I just followed @GBarlowOfficial - the 16 year old version of me would seriously kick my ass right about now..",
  "id" : 123139911854469120,
  "created_at" : "2011-10-09 20:56:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 52, 60 ],
      "id_str" : "7885972",
      "id" : 7885972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Skyline",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 51 ],
      "url" : "http:\/\/t.co\/E8Vcid6",
      "expanded_url" : "http:\/\/bit.ly\/qk6N2V",
      "display_url" : "bit.ly\/qk6N2V"
    } ]
  },
  "geo" : { },
  "id_str" : "123098022186987520",
  "text" : "Supposed to be bad but sure.... http:\/\/t.co\/E8Vcid6 @GetGlue #Skyline",
  "id" : 123098022186987520,
  "created_at" : "2011-10-09 18:10:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123061000063819777",
  "text" : "\"Johnny, la gente esta muy loca\"",
  "id" : 123061000063819777,
  "created_at" : "2011-10-09 15:43:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59184944, -5.8831186343 ]
  },
  "id_str" : "122673908506832897",
  "text" : "At the brothers and he's got fuck all in the house... Useless bastard!",
  "id" : 122673908506832897,
  "created_at" : "2011-10-08 14:05:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 42, 50 ],
      "id_str" : "7885972",
      "id" : 7885972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/IK538aD",
      "expanded_url" : "http:\/\/bit.ly\/npSWD7",
      "display_url" : "bit.ly\/npSWD7"
    } ]
  },
  "geo" : { },
  "id_str" : "122388957186105344",
  "text" : "I unlocked the Check-in Rookie sticker on @GetGlue! http:\/\/t.co\/IK538aD",
  "id" : 122388957186105344,
  "created_at" : "2011-10-07 19:12:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 46, 54 ],
      "id_str" : "7885972",
      "id" : 7885972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GhostWriter",
      "indices" : [ 55, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/qUbNJTd",
      "expanded_url" : "http:\/\/bit.ly\/nBrKjo",
      "display_url" : "bit.ly\/nBrKjo"
    } ]
  },
  "geo" : { },
  "id_str" : "122388941797208064",
  "text" : "I'm watching Ghost Writer http:\/\/t.co\/qUbNJTd @GetGlue #GhostWriter",
  "id" : 122388941797208064,
  "created_at" : "2011-10-07 19:12:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122332300166955009",
  "geo" : { },
  "id_str" : "122333665534550017",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke wasn't what I was getting at. Its the self indulgence. Very asinine.",
  "id" : 122333665534550017,
  "in_reply_to_status_id" : 122332300166955009,
  "created_at" : "2011-10-07 15:33:13 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/P704TmF",
      "expanded_url" : "http:\/\/foundrs.posterous.com\/73465548",
      "display_url" : "foundrs.posterous.com\/73465548"
    } ]
  },
  "geo" : { },
  "id_str" : "122323799407468544",
  "text" : "I am sorry but this is just utter fucking wank of the highest order! http:\/\/t.co\/P704TmF",
  "id" : 122323799407468544,
  "created_at" : "2011-10-07 14:54:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 13, 23 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122248516012748800",
  "geo" : { },
  "id_str" : "122249261432844288",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @burkazoid I am quite liking it to be honest... can't beat girls aloud :D",
  "id" : 122249261432844288,
  "in_reply_to_status_id" : 122248516012748800,
  "created_at" : "2011-10-07 09:57:49 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122240867544207361",
  "text" : "I've just spilt coffee all down myself... I am 32... EPIC FAIL.",
  "id" : 122240867544207361,
  "created_at" : "2011-10-07 09:24:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122201772986081280",
  "geo" : { },
  "id_str" : "122214083150872577",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Lets hope. You in work today are you are getting ready for your holiday tomorrow?",
  "id" : 122214083150872577,
  "in_reply_to_status_id" : 122201772986081280,
  "created_at" : "2011-10-07 07:38:02 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122198659742965760",
  "text" : "\/me turns around on the swivel chair stroking a cat and says \"Ahhhh Mr. Friday, we meet again!\".",
  "id" : 122198659742965760,
  "created_at" : "2011-10-07 06:36:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122049332605227009",
  "geo" : { },
  "id_str" : "122064548340572160",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit i never really look in the mirror that much for obvious reasons - but I had a good look today! Man - its all gone :D",
  "id" : 122064548340572160,
  "in_reply_to_status_id" : 122049332605227009,
  "created_at" : "2011-10-06 21:43:50 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933475633, -6.21246403 ]
  },
  "id_str" : "122047412519960577",
  "text" : "Fucking hell I am seriously bald!!!!!",
  "id" : 122047412519960577,
  "created_at" : "2011-10-06 20:35:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Warwick McCullough",
      "screen_name" : "WarwickMcC",
      "indices" : [ 15, 26 ],
      "id_str" : "25477593",
      "id" : 25477593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122037427622789121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59335109, -6.21264049 ]
  },
  "id_str" : "122038594801115136",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @warwickmcc Don't try and understand... Just accept it.",
  "id" : 122038594801115136,
  "in_reply_to_status_id" : 122037427622789121,
  "created_at" : "2011-10-06 20:00:43 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 46, 54 ],
      "id_str" : "7885972",
      "id" : 7885972
    }, {
      "name" : "Blue Bloods on CBS!",
      "screen_name" : "BlueBloods_CBS",
      "indices" : [ 55, 70 ],
      "id_str" : "144925401",
      "id" : 144925401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/jMDYbdGD",
      "expanded_url" : "http:\/\/bit.ly\/o9kUmp",
      "display_url" : "bit.ly\/o9kUmp"
    } ]
  },
  "geo" : { },
  "id_str" : "122037408622575616",
  "text" : "I'm watching Blue Bloods http:\/\/t.co\/jMDYbdGD @GetGlue @BlueBloods_CBS",
  "id" : 122037408622575616,
  "created_at" : "2011-10-06 19:56:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121960103103574016",
  "geo" : { },
  "id_str" : "122015238588612608",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall pretty much :D",
  "id" : 122015238588612608,
  "in_reply_to_status_id" : 121960103103574016,
  "created_at" : "2011-10-06 18:27:54 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121883291182825472",
  "geo" : { },
  "id_str" : "121888911038480384",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg grumpy bollocks :D",
  "id" : 121888911038480384,
  "in_reply_to_status_id" : 121883291182825472,
  "created_at" : "2011-10-06 10:05:55 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121848715945316352",
  "geo" : { },
  "id_str" : "121850084282474499",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard happy birthday old man",
  "id" : 121850084282474499,
  "in_reply_to_status_id" : 121848715945316352,
  "created_at" : "2011-10-06 07:31:38 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933688633, -6.2126813867 ]
  },
  "id_str" : "121818368117444608",
  "text" : "Found out Steve Jobs had died on my iPhone this morning. Think most ppl will find out via one of his devices. That's a legacy few have. RIP.",
  "id" : 121818368117444608,
  "created_at" : "2011-10-06 05:25:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121548262254714880",
  "text" : "So.. php - in_array can't cope if the array it is searching against is NULL... That's nice - that's fucking nice.",
  "id" : 121548262254714880,
  "created_at" : "2011-10-05 11:32:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121532663055138817",
  "text" : "Am pretty sure he didn't mean it to come across that way - but that's how it will come across..",
  "id" : 121532663055138817,
  "created_at" : "2011-10-05 10:30:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121532303313862656",
  "text" : "So Cameron has effectively told us to stop spending and reduce our debts.. Great - exactly what the economy needs!",
  "id" : 121532303313862656,
  "created_at" : "2011-10-05 10:28:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 35, 46 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121529344660221954",
  "text" : "That was the bestest cupcake ever. @Alana_Doll - Baking Godess... Open a shop!!!!! :D",
  "id" : 121529344660221954,
  "created_at" : "2011-10-05 10:17:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593370528, -6.212544172 ]
  },
  "id_str" : "121484864334729216",
  "text" : "Epic. Almost. 10 hour. Sleep. Needed. It.",
  "id" : 121484864334729216,
  "created_at" : "2011-10-05 07:20:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121318502622691328",
  "geo" : { },
  "id_str" : "121319633591615488",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll awesome :D They will be awesome I am sure :)",
  "id" : 121319633591615488,
  "in_reply_to_status_id" : 121318502622691328,
  "created_at" : "2011-10-04 20:23:49 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121298143647236096",
  "text" : "Several things I hate doing - washing dishes, sunday evenings, paying tax, putting the bin out and resizing servers.. Resizing a server now.",
  "id" : 121298143647236096,
  "created_at" : "2011-10-04 18:58:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/NGZ6NxSu",
      "expanded_url" : "http:\/\/yfrog.com\/kg352itj",
      "display_url" : "yfrog.com\/kg352itj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593370528, -6.212544172 ]
  },
  "id_str" : "121296915274010624",
  "text" : "Super Wednesday  http:\/\/t.co\/NGZ6NxSu",
  "id" : 121296915274010624,
  "created_at" : "2011-10-04 18:53:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121290805951475714",
  "geo" : { },
  "id_str" : "121294362662535169",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore you can't tax without an MOT cert.",
  "id" : 121294362662535169,
  "in_reply_to_status_id" : 121290805951475714,
  "created_at" : "2011-10-04 18:43:24 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121287912682831872",
  "text" : "If there isn't an iPhone5 at the end of this talk there will be a lynching.. All this guff for an incremental upgrade...",
  "id" : 121287912682831872,
  "created_at" : "2011-10-04 18:17:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121168869552435200",
  "geo" : { },
  "id_str" : "121169010065801216",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll but your cakes are ha-maze-ing!!! Open up a shop ffs :D",
  "id" : 121169010065801216,
  "in_reply_to_status_id" : 121168869552435200,
  "created_at" : "2011-10-04 10:25:17 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121167902010380288",
  "geo" : { },
  "id_str" : "121168713780166656",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll seriously you should enter...",
  "id" : 121168713780166656,
  "in_reply_to_status_id" : 121167902010380288,
  "created_at" : "2011-10-04 10:24:07 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesomequoteoftheday",
      "indices" : [ 53, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121158806880268289",
  "text" : "OH: \"Stop trying to polish this turd, its more work\" #awesomequoteoftheday",
  "id" : 121158806880268289,
  "created_at" : "2011-10-04 09:44:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121140395907358721",
  "text" : "So - according to records I have to drink 3.5l of water today... Here goes.",
  "id" : 121140395907358721,
  "created_at" : "2011-10-04 08:31:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120998939792117761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933394583, -6.21258273 ]
  },
  "id_str" : "121041370428358656",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne bullshit you dont need to go on a diet.",
  "id" : 121041370428358656,
  "in_reply_to_status_id" : 120998939792117761,
  "created_at" : "2011-10-04 01:58:06 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 106, 117 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Annette McDonagh",
      "screen_name" : "AnnetteMcDonagh",
      "indices" : [ 121, 137 ],
      "id_str" : "1164404882",
      "id" : 1164404882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933394583, -6.21258273 ]
  },
  "id_str" : "121041164446072832",
  "text" : "Just woke up there.. Turned the tv on and \"The Great British Bake Off Is On\". Has to be wrong though.. No @Alana_Doll or @annettemcdonagh.",
  "id" : 121041164446072832,
  "created_at" : "2011-10-04 01:57:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120967382880632832",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf that was supposed be private... FFS.. Am away to bed...",
  "id" : 120967382880632832,
  "created_at" : "2011-10-03 21:04:06 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beardywanker",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120945161202180096",
  "text" : "\"And now, with today's technology, I can finally share my true vision for Star Wars with the world.\" #beardywanker",
  "id" : 120945161202180096,
  "created_at" : "2011-10-03 19:35:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120940928490942464",
  "geo" : { },
  "id_str" : "120942174811586560",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Another 1.5 session again?",
  "id" : 120942174811586560,
  "in_reply_to_status_id" : 120940928490942464,
  "created_at" : "2011-10-03 19:23:56 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120930849251274752",
  "text" : "Just in through the door and the heating is on within 5 mins.... What a pussy!",
  "id" : 120930849251274752,
  "created_at" : "2011-10-03 18:38:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120874908065603584",
  "geo" : { },
  "id_str" : "120876160094711808",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus wanker! Don't do it.. You still might have a chance to be in it!!!!!",
  "id" : 120876160094711808,
  "in_reply_to_status_id" : 120874908065603584,
  "created_at" : "2011-10-03 15:01:37 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120847762878238720",
  "geo" : { },
  "id_str" : "120863203549904896",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin Infinity is great though. I was getting 31mb the other day :D Fucking stupid speeds :)",
  "id" : 120863203549904896,
  "in_reply_to_status_id" : 120847762878238720,
  "created_at" : "2011-10-03 14:10:07 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Piven",
      "screen_name" : "jeremypiven",
      "indices" : [ 20, 32 ],
      "id_str" : "20221159",
      "id" : 20221159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120834256690880512",
  "text" : "Ohhhh I forgot that @jeremypiven  was in Ellen... He needs to star in an Ari Gold spin off to make up for it.",
  "id" : 120834256690880512,
  "created_at" : "2011-10-03 12:15:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120829330971557888",
  "text" : "Just found out why I am in such an arsey mood. Am wearing a new leg bandage today and its fuckin killing me. Good to know there is a reason.",
  "id" : 120829330971557888,
  "created_at" : "2011-10-03 11:55:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120828910786191360",
  "text" : "Fuck. Fuck. Fuck. And I have to say it again Fuck. Sunday evenings are shit - Monday is also shite... FUCK. FUCK. FUCK.",
  "id" : 120828910786191360,
  "created_at" : "2011-10-03 11:53:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120800516526706688",
  "text" : "Left my mobile at home. Asshole!!!!",
  "id" : 120800516526706688,
  "created_at" : "2011-10-03 10:01:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59334796, -6.21263542 ]
  },
  "id_str" : "120196608745938944",
  "text" : "Frost on Nixon is on BBC2 now! Cant wait. My Saturday evenings have definitely changed.",
  "id" : 120196608745938944,
  "created_at" : "2011-10-01 18:01:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120166018395017216",
  "geo" : { },
  "id_str" : "120184525211963392",
  "in_reply_to_user_id" : 19477583,
  "text" : "@susannar100 you wanna try living here! Rains constantly!",
  "id" : 120184525211963392,
  "in_reply_to_status_id" : 120166018395017216,
  "created_at" : "2011-10-01 17:13:18 +0000",
  "in_reply_to_screen_name" : "susannareid100",
  "in_reply_to_user_id_str" : "19477583",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120028869930663936",
  "text" : "I just played \"Rock, Paper, Scissors, Lizard, Spock\" and lost....",
  "id" : 120028869930663936,
  "created_at" : "2011-10-01 06:54:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]