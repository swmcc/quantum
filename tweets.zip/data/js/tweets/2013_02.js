Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 11, 18 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307252837493121024",
  "geo" : { },
  "id_str" : "307253002165686272",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @szlwzl must resist obvious trap......",
  "id" : 307253002165686272,
  "in_reply_to_status_id" : 307252837493121024,
  "created_at" : "2013-02-28 22:16:38 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 8, 18 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "genius",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/CIfkNHiSm8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=mkBi7xe2Mpk",
      "display_url" : "youtube.com\/watch?v=mkBi7x\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "307251713490968577",
  "geo" : { },
  "id_str" : "307252034455891968",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @smccalden http:\/\/t.co\/CIfkNHiSm8 this is what the internet is for! #genius",
  "id" : 307252034455891968,
  "in_reply_to_status_id" : 307251713490968577,
  "created_at" : "2013-02-28 22:12:48 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 11, 20 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307249973932748801",
  "geo" : { },
  "id_str" : "307250154061316098",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @davehedo yes but 90% of the stuff I say on this is your dumb remarks... like the one today - golden.. cannot repeat it though :(",
  "id" : 307250154061316098,
  "in_reply_to_status_id" : 307249973932748801,
  "created_at" : "2013-02-28 22:05:19 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 84, 94 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/L0DTdaHLam",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=BCv-HxktZFc",
      "display_url" : "youtube.com\/watch?v=BCv-Hx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307247824809119745",
  "text" : "Am trying to take my feed down a more techie route. Kinda hard when you work with a @smccalden but this is gold http:\/\/t.co\/L0DTdaHLam",
  "id" : 307247824809119745,
  "created_at" : "2013-02-28 21:56:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Engineering",
      "screen_name" : "TwitterEng",
      "indices" : [ 3, 14 ],
      "id_str" : "6844292",
      "id" : 6844292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307243746947383297",
  "text" : "RT @TwitterEng: We're open-sourcing Hosebird Client to provide a robust Java HTTP library for consuming Twitter's Streaming API. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/a73PDm8fBs",
        "expanded_url" : "http:\/\/engineering.twitter.com\/2013\/02\/drinking-from-streaming-api.html",
        "display_url" : "engineering.twitter.com\/2013\/02\/drinki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "307222708406583296",
    "text" : "We're open-sourcing Hosebird Client to provide a robust Java HTTP library for consuming Twitter's Streaming API. http:\/\/t.co\/a73PDm8fBs",
    "id" : 307222708406583296,
    "created_at" : "2013-02-28 20:16:16 +0000",
    "user" : {
      "name" : "Twitter Engineering",
      "screen_name" : "TwitterEng",
      "protected" : false,
      "id_str" : "6844292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2284174594\/apcu4c9tu2zkefnev0jt_normal.png",
      "id" : 6844292,
      "verified" : true
    }
  },
  "id" : 307243746947383297,
  "created_at" : "2013-02-28 21:39:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 11, 19 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 20, 33 ],
      "id_str" : "162449244",
      "id" : 162449244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307168111201755136",
  "geo" : { },
  "id_str" : "307174382323781632",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @jbrevel @justinMleary I don\u2019t want to be locked into the AMZN eco system though. Kindle will do for now.",
  "id" : 307174382323781632,
  "in_reply_to_status_id" : 307168111201755136,
  "created_at" : "2013-02-28 17:04:14 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307161951983775744",
  "text" : "I wussed out and bought myself a kindle instead of an iPad mini.. Will wait till they up the spec a bit at the end of the year.",
  "id" : 307161951983775744,
  "created_at" : "2013-02-28 16:14:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307137458657718273",
  "text" : "OH: \u201CI have to say - black artists will never win any Ivan Novello awards\u201D - I kid you not! Wasn\u2019t me\u2026.",
  "id" : 307137458657718273,
  "created_at" : "2013-02-28 14:37:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 30, 42 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307128536618115072",
  "geo" : { },
  "id_str" : "307129796721266688",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ @peter_omalley @ryancunning I think you should do it... Bring back Friday mornings before I left.",
  "id" : 307129796721266688,
  "in_reply_to_status_id" : 307128536618115072,
  "created_at" : "2013-02-28 14:07:04 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307112229763960832",
  "geo" : { },
  "id_str" : "307114457295900673",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop never heard of that - but will put that in my reading list :D",
  "id" : 307114457295900673,
  "in_reply_to_status_id" : 307112229763960832,
  "created_at" : "2013-02-28 13:06:07 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J5p5xKsNbD",
      "expanded_url" : "http:\/\/www.stevieawards.com\/",
      "display_url" : "stevieawards.com"
    } ]
  },
  "geo" : { },
  "id_str" : "307114296826019841",
  "text" : "http:\/\/t.co\/J5p5xKsNbD - awesome :D",
  "id" : 307114296826019841,
  "created_at" : "2013-02-28 13:05:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon UK",
      "screen_name" : "AmazonUK",
      "indices" : [ 60, 69 ],
      "id_str" : "209004862",
      "id" : 209004862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/CPWubfVpk1",
      "expanded_url" : "http:\/\/www.amazon.co.uk\/dp\/1933988177\/ref=cm_sw_r_tw_asp_0Bp9F.1A12KFE",
      "display_url" : "amazon.co.uk\/dp\/1933988177\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307111336079400960",
  "text" : "I just bought: 'Lucene in Action' by Michael McCandless via @amazonuk http:\/\/t.co\/CPWubfVpk1",
  "id" : 307111336079400960,
  "created_at" : "2013-02-28 12:53:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Moran",
      "screen_name" : "ianmoran",
      "indices" : [ 0, 9 ],
      "id_str" : "16236773",
      "id" : 16236773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306900726943207424",
  "geo" : { },
  "id_str" : "306900958032584704",
  "in_reply_to_user_id" : 16236773,
  "text" : "@ianmoran well I was being serious.. mutt is still by far the best mail client I have ever used.",
  "id" : 306900958032584704,
  "in_reply_to_status_id" : 306900726943207424,
  "created_at" : "2013-02-27 22:57:45 +0000",
  "in_reply_to_screen_name" : "ianmoran",
  "in_reply_to_user_id_str" : "16236773",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Moran",
      "screen_name" : "ianmoran",
      "indices" : [ 0, 9 ],
      "id_str" : "16236773",
      "id" : 16236773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/o1f5QrGbIg",
      "expanded_url" : "http:\/\/blog.swm.cc\/2012\/10\/06\/mutt-for-gmail\/",
      "display_url" : "blog.swm.cc\/2012\/10\/06\/mut\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "306880437836455936",
  "geo" : { },
  "id_str" : "306899839726272512",
  "in_reply_to_user_id" : 16236773,
  "text" : "@ianmoran you should try mutt.. never used elm. mutt is lovely. am using mutt exclusively now http:\/\/t.co\/o1f5QrGbIg",
  "id" : 306899839726272512,
  "in_reply_to_status_id" : 306880437836455936,
  "created_at" : "2013-02-27 22:53:18 +0000",
  "in_reply_to_screen_name" : "ianmoran",
  "in_reply_to_user_id_str" : "16236773",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 0, 9 ],
      "id_str" : "95932190",
      "id" : 95932190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "totheclient",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306793906274721792",
  "geo" : { },
  "id_str" : "306809927089938433",
  "in_reply_to_user_id" : 95932190,
  "text" : "@brrygrdn cap clue deploy #totheclient",
  "id" : 306809927089938433,
  "in_reply_to_status_id" : 306793906274721792,
  "created_at" : "2013-02-27 16:56:01 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 21, 31 ],
      "id_str" : "240194412",
      "id" : 240194412
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 68, 76 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306775516197814272",
  "text" : "Been a Queen fest in @RepKnight this afternoon.. Good stuffs... and @jbrevel has only played Scream &amp; Shout only once...",
  "id" : 306775516197814272,
  "created_at" : "2013-02-27 14:39:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306713034909429760",
  "geo" : { },
  "id_str" : "306713798675419136",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden Wanna compare the work you do in 2.5hrs to my .5hrs? ;) I was here until 7 last night bitch ;) I hope you get herpes.",
  "id" : 306713798675419136,
  "in_reply_to_status_id" : 306713034909429760,
  "created_at" : "2013-02-27 10:34:02 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "everyonecodinglikebosses",
      "indices" : [ 85, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306712690619977728",
  "text" : "You know shit is getting done with you come into the office and everyone is quiet :) #everyonecodinglikebosses",
  "id" : 306712690619977728,
  "created_at" : "2013-02-27 10:29:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basil McCrea",
      "screen_name" : "basilmccrea",
      "indices" : [ 3, 15 ],
      "id_str" : "42041977",
      "id" : 42041977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306712074279612416",
  "text" : "RT @basilmccrea: There are many who really believe in the union, who do not feel the need to wrap themselves in a flag to show they are  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306703034061312000",
    "text" : "There are many who really believe in the union, who do not feel the need to wrap themselves in a flag to show they are unionists.",
    "id" : 306703034061312000,
    "created_at" : "2013-02-27 09:51:16 +0000",
    "user" : {
      "name" : "Basil McCrea",
      "screen_name" : "basilmccrea",
      "protected" : false,
      "id_str" : "42041977",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/344513261574827699\/6378c1e4ca3a5b77848e43015049f10d_normal.jpeg",
      "id" : 42041977,
      "verified" : false
    }
  },
  "id" : 306712074279612416,
  "created_at" : "2013-02-27 10:27:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nottimewasting",
      "indices" : [ 22, 37 ]
    }, {
      "text" : "sitcomwaitingtohappen",
      "indices" : [ 38, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306509051611709441",
  "geo" : { },
  "id_str" : "306509609961672706",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll how much? #nottimewasting #sitcomwaitingtohappen",
  "id" : 306509609961672706,
  "in_reply_to_status_id" : 306509051611709441,
  "created_at" : "2013-02-26 21:02:40 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Dugan",
      "screen_name" : "adriandugan",
      "indices" : [ 0, 12 ],
      "id_str" : "69403865",
      "id" : 69403865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306502336602329088",
  "geo" : { },
  "id_str" : "306509307992760322",
  "in_reply_to_user_id" : 69403865,
  "text" : "@adriandugan sarcasm always implied with you :) Sure we've worked along and for enough idiots to know stupid policy when we see it :)",
  "id" : 306509307992760322,
  "in_reply_to_status_id" : 306502336602329088,
  "created_at" : "2013-02-26 21:01:28 +0000",
  "in_reply_to_screen_name" : "adriandugan",
  "in_reply_to_user_id_str" : "69403865",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/306508441839603713\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/5MEVUK24Ux",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEDvzc0CEAAjFd1.png",
      "id_str" : "306508441847992320",
      "id" : 306508441847992320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEDvzc0CEAAjFd1.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/5MEVUK24Ux"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306508441839603713",
  "text" : "He\u2019s learning how to respond to me well :) http:\/\/t.co\/5MEVUK24Ux",
  "id" : 306508441839603713,
  "created_at" : "2013-02-26 20:58:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 3, 9 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ted",
      "indices" : [ 63, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306487307593216000",
  "text" : "RT @Jason: Not to be cynical, but you flew your private get to #ted, paid $15k for a ticket &amp; then cried about the environment &amp; ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ted",
        "indices" : [ 52, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306483771279028225",
    "text" : "Not to be cynical, but you flew your private get to #ted, paid $15k for a ticket &amp; then cried about the environment &amp; poor? Come on.",
    "id" : 306483771279028225,
    "created_at" : "2013-02-26 19:19:59 +0000",
    "user" : {
      "name" : "jason",
      "screen_name" : "Jason",
      "protected" : false,
      "id_str" : "3840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1582247652\/Screen_shot_2011-10-10_at_2.54.06_PM_normal.png",
      "id" : 3840,
      "verified" : true
    }
  },
  "id" : 306487307593216000,
  "created_at" : "2013-02-26 19:34:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306486297369923587",
  "text" : "I don't get Yahoo!'s new working in the same place policy. Very outdated. Distributed working (when the enviro is right) works just as well.",
  "id" : 306486297369923587,
  "created_at" : "2013-02-26 19:30:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306481261160062976",
  "geo" : { },
  "id_str" : "306486009066033152",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq nope just gets you sucked off by certain people :)",
  "id" : 306486009066033152,
  "in_reply_to_status_id" : 306481261160062976,
  "created_at" : "2013-02-26 19:28:53 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306478193181880320",
  "geo" : { },
  "id_str" : "306484785042300928",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke :D You got me :)",
  "id" : 306484785042300928,
  "in_reply_to_status_id" : 306478193181880320,
  "created_at" : "2013-02-26 19:24:01 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 0, 9 ],
      "id_str" : "95932190",
      "id" : 95932190
    }, {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 10, 24 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306469117064519681",
  "geo" : { },
  "id_str" : "306469351773577216",
  "in_reply_to_user_id" : 95932190,
  "text" : "@brrygrdn @madebyrichard Enjoy Richard :D :D :D :D",
  "id" : 306469351773577216,
  "in_reply_to_status_id" : 306469117064519681,
  "created_at" : "2013-02-26 18:22:42 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306468441907417088",
  "text" : "The clique that is developing in the Belfast tech community makes me wanna puke sometimes.. Anyway mini rant over :D \/me goes home.",
  "id" : 306468441907417088,
  "created_at" : "2013-02-26 18:19:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 73, 79 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306368610962653184",
  "text" : "RT @jbrevel: OH: I would love to ride that pamela ballintine, she is hot @swmcc",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 60, 66 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306368219365638144",
    "text" : "OH: I would love to ride that pamela ballintine, she is hot @swmcc",
    "id" : 306368219365638144,
    "created_at" : "2013-02-26 11:40:50 +0000",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 306368610962653184,
  "created_at" : "2013-02-26 11:42:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 75, 83 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306367839890202624",
  "text" : "OH: \"I would ride the queen before I would ride Cate Blanchett\" I give you @jbrevel",
  "id" : 306367839890202624,
  "created_at" : "2013-02-26 11:39:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 13, 23 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toomanywords",
      "indices" : [ 115, 128 ]
    }, {
      "text" : "headphones",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306348408589910016",
  "text" : "Listening to @smccalden talking on skype is akin to having my stones rubbed with a cheesegrater... It really is :) #toomanywords #headphones",
  "id" : 306348408589910016,
  "created_at" : "2013-02-26 10:22:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/WfS6b4fIRM",
      "expanded_url" : "http:\/\/blog.swm.cc\/",
      "display_url" : "blog.swm.cc"
    } ]
  },
  "geo" : { },
  "id_str" : "306177653189275648",
  "text" : "Added Sept 2001 - Jan 2002 archives to my blog. Embarrassing to look back at but fuck it. http:\/\/t.co\/WfS6b4fIRM Lots more to add still...",
  "id" : 306177653189275648,
  "created_at" : "2013-02-25 23:03:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gliffy HQ",
      "screen_name" : "gliffy",
      "indices" : [ 3, 10 ],
      "id_str" : "16213460",
      "id" : 16213460
    }, {
      "name" : "Symantec",
      "screen_name" : "symantec",
      "indices" : [ 69, 78 ],
      "id_str" : "17476533",
      "id" : 17476533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BYOD",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/HFIwJTWpZD",
      "expanded_url" : "http:\/\/ow.ly\/i24fw",
      "display_url" : "ow.ly\/i24fw"
    } ]
  },
  "geo" : { },
  "id_str" : "306116637646532609",
  "text" : "RT @gliffy: How to create a successful #BYOD policy for your company @symantec http:\/\/t.co\/HFIwJTWpZD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Symantec",
        "screen_name" : "symantec",
        "indices" : [ 57, 66 ],
        "id_str" : "17476533",
        "id" : 17476533
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BYOD",
        "indices" : [ 27, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/HFIwJTWpZD",
        "expanded_url" : "http:\/\/ow.ly\/i24fw",
        "display_url" : "ow.ly\/i24fw"
      } ]
    },
    "geo" : { },
    "id_str" : "306108843396591616",
    "text" : "How to create a successful #BYOD policy for your company @symantec http:\/\/t.co\/HFIwJTWpZD",
    "id" : 306108843396591616,
    "created_at" : "2013-02-25 18:30:10 +0000",
    "user" : {
      "name" : "Gliffy HQ",
      "screen_name" : "gliffy",
      "protected" : false,
      "id_str" : "16213460",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2670891593\/c0cfc5d366340ecd82dabc1e8cc108fe_normal.png",
      "id" : 16213460,
      "verified" : true
    }
  },
  "id" : 306116637646532609,
  "created_at" : "2013-02-25 19:01:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/306076300299350016\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/9YloEhsPzJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD9mxgHCMAEX0Ju.png",
      "id_str" : "306076300303544321",
      "id" : 306076300303544321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD9mxgHCMAEX0Ju.png",
      "sizes" : [ {
        "h" : 48,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 48,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 48,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 22,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 38,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9YloEhsPzJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306076300299350016",
  "text" : "My first day of work over 13 years ago I was told never to use \"SELECT *\".. I ignored this last week. http:\/\/t.co\/9YloEhsPzJ",
  "id" : 306076300299350016,
  "created_at" : "2013-02-25 16:20:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Moran",
      "screen_name" : "ianmoran",
      "indices" : [ 7, 16 ],
      "id_str" : "16236773",
      "id" : 16236773
    }, {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 21, 30 ],
      "id_str" : "20543444",
      "id" : 20543444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305799406987378688",
  "text" : "Cheers @ianmoran and @HerrWulf I'll give that a go...",
  "id" : 305799406987378688,
  "created_at" : "2013-02-24 22:00:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/REkdhXYSYt",
      "expanded_url" : "http:\/\/app.net",
      "display_url" : "app.net"
    } ]
  },
  "geo" : { },
  "id_str" : "305788724975910914",
  "text" : "Anyone know of any good mac osx\/ios apps for http:\/\/t.co\/REkdhXYSYt?",
  "id" : 305788724975910914,
  "created_at" : "2013-02-24 21:18:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alasdair Stalker",
      "screen_name" : "alasdairstalker",
      "indices" : [ 3, 19 ],
      "id_str" : "192885085",
      "id" : 192885085
    }, {
      "name" : "Nodejitsu",
      "screen_name" : "nodejitsu",
      "indices" : [ 45, 55 ],
      "id_str" : "157442008",
      "id" : 157442008
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/alasdairstalker\/status\/305708652159979522\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/nGGhZSXOHI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD4YZkFCUAAa1KH.png",
      "id_str" : "305708652168368128",
      "id" : 305708652168368128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD4YZkFCUAAa1KH.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 127,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/nGGhZSXOHI"
    } ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "nodejitsu",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305788600405090305",
  "text" : "RT @alasdairstalker: Switching to NodeJS and @Nodejitsu for my website #nodejs #nodejitsu http:\/\/t.co\/nGGhZSXOHI",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nodejitsu",
        "screen_name" : "nodejitsu",
        "indices" : [ 24, 34 ],
        "id_str" : "157442008",
        "id" : 157442008
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/alasdairstalker\/status\/305708652159979522\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/nGGhZSXOHI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BD4YZkFCUAAa1KH.png",
        "id_str" : "305708652168368128",
        "id" : 305708652168368128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD4YZkFCUAAa1KH.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 127,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/nGGhZSXOHI"
      } ],
      "hashtags" : [ {
        "text" : "nodejs",
        "indices" : [ 50, 57 ]
      }, {
        "text" : "nodejitsu",
        "indices" : [ 58, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305708652159979522",
    "text" : "Switching to NodeJS and @Nodejitsu for my website #nodejs #nodejitsu http:\/\/t.co\/nGGhZSXOHI",
    "id" : 305708652159979522,
    "created_at" : "2013-02-24 15:59:57 +0000",
    "user" : {
      "name" : "Alasdair Stalker",
      "screen_name" : "alasdairstalker",
      "protected" : false,
      "id_str" : "192885085",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000177506310\/59c4b12f5f45d621fd7e4afe2fc412a2_normal.jpeg",
      "id" : 192885085,
      "verified" : false
    }
  },
  "id" : 305788600405090305,
  "created_at" : "2013-02-24 21:17:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305776170090233856",
  "geo" : { },
  "id_str" : "305776446029307904",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin Oh I know... But trying to find a silver lining on a Sunday night is hard sometimes...",
  "id" : 305776446029307904,
  "in_reply_to_status_id" : 305776170090233856,
  "created_at" : "2013-02-24 20:29:20 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305775029646397440",
  "geo" : { },
  "id_str" : "305775789574606850",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin you are a contractor now.. Think of the \u00A3\u00A3\u00A3 ;) That'll help.",
  "id" : 305775789574606850,
  "in_reply_to_status_id" : 305775029646397440,
  "created_at" : "2013-02-24 20:26:43 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 3, 10 ],
      "id_str" : "285766850",
      "id" : 285766850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/chzpjlIvXe",
      "expanded_url" : "http:\/\/nodeup.com",
      "display_url" : "nodeup.com"
    } ]
  },
  "geo" : { },
  "id_str" : "305759168227328001",
  "text" : "RT @NodeUp: we're live -- http:\/\/t.co\/chzpjlIvXe",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/chzpjlIvXe",
        "expanded_url" : "http:\/\/nodeup.com",
        "display_url" : "nodeup.com"
      } ]
    },
    "geo" : { },
    "id_str" : "305756848227770368",
    "text" : "we're live -- http:\/\/t.co\/chzpjlIvXe",
    "id" : 305756848227770368,
    "created_at" : "2013-02-24 19:11:27 +0000",
    "user" : {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "protected" : false,
      "id_str" : "285766850",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1675860861\/logo2_normal.jpg",
      "id" : 285766850,
      "verified" : false
    }
  },
  "id" : 305759168227328001,
  "created_at" : "2013-02-24 19:20:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305710833734909953",
  "geo" : { },
  "id_str" : "305711309486428160",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl it is cracking me up. Very good writing...",
  "id" : 305711309486428160,
  "in_reply_to_status_id" : 305710833734909953,
  "created_at" : "2013-02-24 16:10:30 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305707396515393536",
  "geo" : { },
  "id_str" : "305710278933372928",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl Am now on to Season 2 of MF...",
  "id" : 305710278933372928,
  "in_reply_to_status_id" : 305707396515393536,
  "created_at" : "2013-02-24 16:06:24 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Deborah Barnes",
      "screen_name" : "DeborahABarnes",
      "indices" : [ 13, 28 ],
      "id_str" : "23632553",
      "id" : 23632553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305699682976428032",
  "geo" : { },
  "id_str" : "305701169861378048",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @DeborahABarnes but if felt so right :)",
  "id" : 305701169861378048,
  "in_reply_to_status_id" : 305699682976428032,
  "created_at" : "2013-02-24 15:30:13 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305679006102077440",
  "text" : "Is it wrong to have a baked potato in bed???? Fuck it - I am trying it out. Going all ferrel today bitches!!! Episode 20 coming up!",
  "id" : 305679006102077440,
  "created_at" : "2013-02-24 14:02:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305674065182597120",
  "text" : "Since discovering Modern Family last night at 8pm I have watched 18 episodes.... This is not a good thing.",
  "id" : 305674065182597120,
  "created_at" : "2013-02-24 13:42:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305445055848665089",
  "text" : "Loving Modern Family",
  "id" : 305445055848665089,
  "created_at" : "2013-02-23 22:32:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305424399958425600",
  "text" : "I've found Modern Family....",
  "id" : 305424399958425600,
  "created_at" : "2013-02-23 21:10:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305413542306267136",
  "text" : "Fire lit... Laptop on and coding away - happy geek :D",
  "id" : 305413542306267136,
  "created_at" : "2013-02-23 20:27:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Parmenter",
      "screen_name" : "sazzy",
      "indices" : [ 3, 9 ],
      "id_str" : "13811562",
      "id" : 13811562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305413321534885888",
  "text" : "RT @sazzy: Watching TED talks in my pyjamas, eating popcorn and learning Ruby on Rails. Just the Saturday night I need this week.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305404639707279360",
    "text" : "Watching TED talks in my pyjamas, eating popcorn and learning Ruby on Rails. Just the Saturday night I need this week.",
    "id" : 305404639707279360,
    "created_at" : "2013-02-23 19:51:54 +0000",
    "user" : {
      "name" : "Sarah Parmenter",
      "screen_name" : "sazzy",
      "protected" : false,
      "id_str" : "13811562",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000185440169\/09ff2e972a25d0c13806eb0a4d96dcb5_normal.png",
      "id" : 13811562,
      "verified" : false
    }
  },
  "id" : 305413321534885888,
  "created_at" : "2013-02-23 20:26:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 0, 9 ],
      "id_str" : "9488072",
      "id" : 9488072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305275668806107137",
  "geo" : { },
  "id_str" : "305278193730990080",
  "in_reply_to_user_id" : 9488072,
  "text" : "@shylands amazing :D Have you read the books - this is only one part of the third book - the next part is EVEN better.",
  "id" : 305278193730990080,
  "in_reply_to_status_id" : 305275668806107137,
  "created_at" : "2013-02-23 11:29:27 +0000",
  "in_reply_to_screen_name" : "shylands",
  "in_reply_to_user_id_str" : "9488072",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305260700836696065",
  "geo" : { },
  "id_str" : "305262321146683393",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel sweet :D I even dreamt about it last night FFS. Weird that jquery or firebug wont see the response... Meh - brekkie :D",
  "id" : 305262321146683393,
  "in_reply_to_status_id" : 305260700836696065,
  "created_at" : "2013-02-23 10:26:23 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305260054309912576",
  "text" : "Right - gonna watch an episode of Banshee have my breakfast and then beat the ever living crap out of this bug I found at 5pm last night!",
  "id" : 305260054309912576,
  "created_at" : "2013-02-23 10:17:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 3, 16 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/OoZPGSxVsC",
      "expanded_url" : "https:\/\/gist.github.com\/LindseyB\/5015434",
      "display_url" : "gist.github.com\/LindseyB\/50154\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305050969517985792",
  "text" : "RT @lindseybieda: I created a collection of javascript and node.js resources and books, enjoy | https:\/\/t.co\/OoZPGSxVsC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/rstat.us\/\" rel=\"nofollow\"\u003ERstat.us App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/OoZPGSxVsC",
        "expanded_url" : "https:\/\/gist.github.com\/LindseyB\/5015434",
        "display_url" : "gist.github.com\/LindseyB\/50154\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "305017851545284608",
    "text" : "I created a collection of javascript and node.js resources and books, enjoy | https:\/\/t.co\/OoZPGSxVsC",
    "id" : 305017851545284608,
    "created_at" : "2013-02-22 18:14:57 +0000",
    "user" : {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "protected" : false,
      "id_str" : "14928483",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000083669843\/c4532f2e8ea74741ec3118ca0cd56fcb_normal.jpeg",
      "id" : 14928483,
      "verified" : false
    }
  },
  "id" : 305050969517985792,
  "created_at" : "2013-02-22 20:26:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AirPOS",
      "screen_name" : "AirPOS",
      "indices" : [ 3, 10 ],
      "id_str" : "53896598",
      "id" : 53896598
    }, {
      "name" : "PayPal UK",
      "screen_name" : "PayPalUK",
      "indices" : [ 33, 42 ],
      "id_str" : "108983630",
      "id" : 108983630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305050118275604480",
  "text" : "RT @AirPOS: AirPOS partners with @PayPalUK to offer PayPal Here to retailers. Catch us on stage at Mobile World Congress! More at http:\/ ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PayPal UK",
        "screen_name" : "PayPalUK",
        "indices" : [ 21, 30 ],
        "id_str" : "108983630",
        "id" : 108983630
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/kfmcKUegin",
        "expanded_url" : "http:\/\/blog.airpos.co.uk\/",
        "display_url" : "blog.airpos.co.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "305025260493881344",
    "text" : "AirPOS partners with @PayPalUK to offer PayPal Here to retailers. Catch us on stage at Mobile World Congress! More at http:\/\/t.co\/kfmcKUegin",
    "id" : 305025260493881344,
    "created_at" : "2013-02-22 18:44:23 +0000",
    "user" : {
      "name" : "AirPOS",
      "screen_name" : "AirPOS",
      "protected" : false,
      "id_str" : "53896598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1866882499\/AirPOS-512x512_normal.png",
      "id" : 53896598,
      "verified" : false
    }
  },
  "id" : 305050118275604480,
  "created_at" : "2013-02-22 20:23:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304999476836302849",
  "text" : "Hmmmm a javascript problem at 5pm on a Friday that is stopping my deploy. Think the correct word for this is \"FUCK FIRE\" :D",
  "id" : 304999476836302849,
  "created_at" : "2013-02-22 17:01:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 13, 23 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 24, 30 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whydoesnthekeepthesethingstohimself",
      "indices" : [ 80, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304974745437368321",
  "text" : "RT @jbrevel: @smccalden @swmcc it was mccaldens mother and him said it everyone #whydoesnthekeepthesethingstohimself",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCalden",
        "screen_name" : "smccalden",
        "indices" : [ 0, 10 ],
        "id_str" : "169048119",
        "id" : 169048119
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 11, 17 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whydoesnthekeepthesethingstohimself",
        "indices" : [ 67, 103 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "304974038281883649",
    "geo" : { },
    "id_str" : "304974681197383680",
    "in_reply_to_user_id" : 169048119,
    "text" : "@smccalden @swmcc it was mccaldens mother and him said it everyone #whydoesnthekeepthesethingstohimself",
    "id" : 304974681197383680,
    "in_reply_to_status_id" : 304974038281883649,
    "created_at" : "2013-02-22 15:23:24 +0000",
    "in_reply_to_screen_name" : "smccalden",
    "in_reply_to_user_id_str" : "169048119",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 304974745437368321,
  "created_at" : "2013-02-22 15:23:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 38, 46 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304973565076336640",
  "text" : "I think the last two OH's have killed @jbrevel he hasn't talked since that was said...",
  "id" : 304973565076336640,
  "created_at" : "2013-02-22 15:18:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304973291435745281",
  "text" : "... OH: \"Then in 1998 they got too hard and had to be replaced\"",
  "id" : 304973291435745281,
  "created_at" : "2013-02-22 15:17:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304973168404226048",
  "text" : "OH: \"My mother was one of the first people to have breast augmentation in NI.... It was in 1969\"...",
  "id" : 304973168404226048,
  "created_at" : "2013-02-22 15:17:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304903047711191040",
  "text" : "Just wasted the last 30 or so mins trying to get my laptop to work\u2026 Very annoying\u2026 Now to get more work done but first - coffee :D :D :D",
  "id" : 304903047711191040,
  "created_at" : "2013-02-22 10:38:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian J. Brennan",
      "screen_name" : "brianloveswords",
      "indices" : [ 3, 19 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304707767736881152",
  "text" : "RT @brianloveswords: Having a flexible API means writing lots and lots of tests.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "304693161480056832",
    "text" : "Having a flexible API means writing lots and lots of tests.",
    "id" : 304693161480056832,
    "created_at" : "2013-02-21 20:44:45 +0000",
    "user" : {
      "name" : "Brian J. Brennan",
      "screen_name" : "brianloveswords",
      "protected" : false,
      "id_str" : "17177251",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3426841674\/766c6a1633c935bccf8bfe1b872b70a8_normal.jpeg",
      "id" : 17177251,
      "verified" : false
    }
  },
  "id" : 304707767736881152,
  "created_at" : "2013-02-21 21:42:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 3, 19 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/UVHxDbi4mW",
      "expanded_url" : "http:\/\/j.mp\/W6c7Nf",
      "display_url" : "j.mp\/W6c7Nf"
    } ]
  },
  "geo" : { },
  "id_str" : "304682872936218624",
  "text" : "RT @newsycombinator: LinkedIn is now using the Play Framework http:\/\/t.co\/UVHxDbi4mW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.steer.me\" rel=\"nofollow\"\u003Enewsycombinator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/UVHxDbi4mW",
        "expanded_url" : "http:\/\/j.mp\/W6c7Nf",
        "display_url" : "j.mp\/W6c7Nf"
      } ]
    },
    "geo" : { },
    "id_str" : "304668074810937344",
    "text" : "LinkedIn is now using the Play Framework http:\/\/t.co\/UVHxDbi4mW",
    "id" : 304668074810937344,
    "created_at" : "2013-02-21 19:05:04 +0000",
    "user" : {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "protected" : false,
      "id_str" : "14335498",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000017952599\/cf443a6da9a74e5c9c1fcddf422ebb0e_normal.png",
      "id" : 14335498,
      "verified" : false
    }
  },
  "id" : 304682872936218624,
  "created_at" : "2013-02-21 20:03:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenavy Stats",
      "screen_name" : "GlenavyStats",
      "indices" : [ 3, 16 ],
      "id_str" : "1165838820",
      "id" : 1165838820
    }, {
      "name" : "Glenavy GAC",
      "screen_name" : "GlenavyGAC",
      "indices" : [ 57, 68 ],
      "id_str" : "457836792",
      "id" : 457836792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304682283024146434",
  "text" : "RT @GlenavyStats: Keep your eyes peeled for updates from @GlenavyGAC regarding the Festival Weekend. Keep your eyes peeled here for sati ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glenavy GAC",
        "screen_name" : "GlenavyGAC",
        "indices" : [ 39, 50 ],
        "id_str" : "457836792",
        "id" : 457836792
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "304630245468819457",
    "text" : "Keep your eyes peeled for updates from @GlenavyGAC regarding the Festival Weekend. Keep your eyes peeled here for satirical commentary on it",
    "id" : 304630245468819457,
    "created_at" : "2013-02-21 16:34:44 +0000",
    "user" : {
      "name" : "Glenavy Stats",
      "screen_name" : "GlenavyStats",
      "protected" : false,
      "id_str" : "1165838820",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000406575193\/335fde95cb5d037f1093e05a8b823f1d_normal.jpeg",
      "id" : 1165838820,
      "verified" : false
    }
  },
  "id" : 304682283024146434,
  "created_at" : "2013-02-21 20:01:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SQUIRREL",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304649393125089280",
  "geo" : { },
  "id_str" : "304658104744812544",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden and we got the #SQUIRREL look to on video.. Just need that captured and to gif it for hip chat :D",
  "id" : 304658104744812544,
  "in_reply_to_status_id" : 304649393125089280,
  "created_at" : "2013-02-21 18:25:27 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 12, 20 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/304576967896866817\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/hiBltdOmol",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDoTI3rCIAAr-Ox.jpg",
      "id_str" : "304576967905255424",
      "id" : 304576967905255424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDoTI3rCIAAr-Ox.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/hiBltdOmol"
    } ],
    "hashtags" : [ {
      "text" : "lockoslunches",
      "indices" : [ 52, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304576967896866817",
  "text" : "The awesome @jbrevel just made met lunch :) Thanks. #lockoslunches http:\/\/t.co\/hiBltdOmol",
  "id" : 304576967896866817,
  "created_at" : "2013-02-21 13:03:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ABexUpVpG0",
      "expanded_url" : "https:\/\/github.com\/swmcc\/cookbook\/commit\/b5c86f54445ac8303b448d0633910106974c4ce1",
      "display_url" : "github.com\/swmcc\/cookbook\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304548262931738624",
  "text" : "Finally got pissed off enough to amend my .profile to give me the git branch I am on\u2026 Hacked from somewhere else - https:\/\/t.co\/ABexUpVpG0",
  "id" : 304548262931738624,
  "created_at" : "2013-02-21 11:08:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 3, 16 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 52, 64 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/stevebiscuit\/status\/304339944871186433\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/XimPrEBfeV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDk7kUGCUAAGE9Q.jpg",
      "id_str" : "304339944879575040",
      "id" : 304339944879575040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDk7kUGCUAAGE9Q.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XimPrEBfeV"
    } ],
    "hashtags" : [ {
      "text" : "rubyconf_au",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304340859619536896",
  "text" : "RT @stevebiscuit: Today I'll be mostly representing @BelfastRuby #rubyconf_au http:\/\/t.co\/XimPrEBfeV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Belfast Ruby",
        "screen_name" : "BelfastRuby",
        "indices" : [ 34, 46 ],
        "id_str" : "454835425",
        "id" : 454835425
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/stevebiscuit\/status\/304339944871186433\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/XimPrEBfeV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDk7kUGCUAAGE9Q.jpg",
        "id_str" : "304339944879575040",
        "id" : 304339944879575040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDk7kUGCUAAGE9Q.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XimPrEBfeV"
      } ],
      "hashtags" : [ {
        "text" : "rubyconf_au",
        "indices" : [ 47, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ -37.824938, 145.001775 ]
    },
    "id_str" : "304339944871186433",
    "text" : "Today I'll be mostly representing @BelfastRuby #rubyconf_au http:\/\/t.co\/XimPrEBfeV",
    "id" : 304339944871186433,
    "created_at" : "2013-02-20 21:21:12 +0000",
    "user" : {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "protected" : false,
      "id_str" : "14068466",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1929736578\/steve_normal.png",
      "id" : 14068466,
      "verified" : false
    }
  },
  "id" : 304340859619536896,
  "created_at" : "2013-02-20 21:24:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304266240233447424",
  "text" : "OH: \u201CIt isn\u2019t wanky if you don\u2019t know\u201D",
  "id" : 304266240233447424,
  "created_at" : "2013-02-20 16:28:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 62, 72 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hewontstop",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304250528404221952",
  "text" : "Twitter people... I will give 100quid to anyone that can shut @smccalden the fuck up for the rest of the day! ;) #hewontstop",
  "id" : 304250528404221952,
  "created_at" : "2013-02-20 15:25:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304192406679597056",
  "geo" : { },
  "id_str" : "304192619603435521",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke nope - must have thrown it out. I have a spare - just need to tune it in. Very rarely use sky now so will get round to it :)",
  "id" : 304192619603435521,
  "in_reply_to_status_id" : 304192406679597056,
  "created_at" : "2013-02-20 11:35:46 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 113, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304186002061266944",
  "text" : "Also in that last tweet I got your and you\u2019re mixed up. I am going to see Die Hard later - today won\u2019t break me. #FUCKYOUWEDNESDAY",
  "id" : 304186002061266944,
  "created_at" : "2013-02-20 11:09:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304185690168651777",
  "text" : "\u201CShot to the heart and your too late\u2026 Darling you give loooovvvvveeee a bad name\u201D - that song is stuck in your head now. #FUCKYOUWEDNESDAY",
  "id" : 304185690168651777,
  "created_at" : "2013-02-20 11:08:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crafty Devil",
      "screen_name" : "craftydevil",
      "indices" : [ 0, 12 ],
      "id_str" : "16318081",
      "id" : 16318081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304170811282046976",
  "geo" : { },
  "id_str" : "304171352779259904",
  "in_reply_to_user_id" : 16318081,
  "text" : "@craftydevil congrats Rich",
  "id" : 304171352779259904,
  "in_reply_to_status_id" : 304170811282046976,
  "created_at" : "2013-02-20 10:11:16 +0000",
  "in_reply_to_screen_name" : "craftydevil",
  "in_reply_to_user_id_str" : "16318081",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304031225419534336",
  "text" : "Was having a crazy nightmare getting over to sleep there but realised that I left the tv on and One Born Every Minute was on. Not good :(",
  "id" : 304031225419534336,
  "created_at" : "2013-02-20 00:54:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Open Source",
      "screen_name" : "TwitterOSS",
      "indices" : [ 3, 14 ],
      "id_str" : "376825877",
      "id" : 376825877
    }, {
      "name" : "typeahead.js",
      "screen_name" : "typeahead",
      "indices" : [ 40, 50 ],
      "id_str" : "1090217586",
      "id" : 1090217586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303986478206300163",
  "text" : "RT @TwitterOSS: We open sourced twitter @typeahead (typeahead.js) today, our jQuery plugin for auto completion. Try it out! http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "typeahead.js",
        "screen_name" : "typeahead",
        "indices" : [ 24, 34 ],
        "id_str" : "1090217586",
        "id" : 1090217586
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/P6YwVaMS",
        "expanded_url" : "http:\/\/engineering.twitter.com\/2013\/02\/twitter-typeaheadjs-you-autocomplete-me.html",
        "display_url" : "engineering.twitter.com\/2013\/02\/twitte\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "303960678933331969",
    "text" : "We open sourced twitter @typeahead (typeahead.js) today, our jQuery plugin for auto completion. Try it out! http:\/\/t.co\/P6YwVaMS",
    "id" : 303960678933331969,
    "created_at" : "2013-02-19 20:14:07 +0000",
    "user" : {
      "name" : "Twitter Open Source",
      "screen_name" : "TwitterOSS",
      "protected" : false,
      "id_str" : "376825877",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000416683223\/1bc995c5cfe98cb3c621f1ba0bf99223_normal.png",
      "id" : 376825877,
      "verified" : true
    }
  },
  "id" : 303986478206300163,
  "created_at" : "2013-02-19 21:56:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 37, 43 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 62, 68 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 92, 98 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303931487777087488",
  "text" : "VPN won\u2019t connect - this a sign that @swmcc should go home so @swmcc is. Also talking about @swmcc in a tweet in the third person is freaky.",
  "id" : 303931487777087488,
  "created_at" : "2013-02-19 18:18:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303930587771719682",
  "text" : "The VPN has disconnected on me. I take this as a sign from the gods to go home :)",
  "id" : 303930587771719682,
  "created_at" : "2013-02-19 18:14:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303899988784721920",
  "geo" : { },
  "id_str" : "303902585654489090",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq :D Not much need for python in the oil NI. Pity like\u2026 JS is where I\u2019d say the future is.. Learn that too :)",
  "id" : 303902585654489090,
  "in_reply_to_status_id" : 303899988784721920,
  "created_at" : "2013-02-19 16:23:17 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303894228310822914",
  "text" : "\/me steps away from the computer for 20minutes\u2026 or work anyway :)",
  "id" : 303894228310822914,
  "created_at" : "2013-02-19 15:50:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 38, 45 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/303883172406493185\/photo\/1",
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/tu5VHDRb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDecIqECAAA_WIm.jpg",
      "id_str" : "303883172414881792",
      "id" : 303883172414881792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDecIqECAAA_WIm.jpg",
      "sizes" : [ {
        "h" : 493,
        "resize" : "fit",
        "w" : 845
      }, {
        "h" : 493,
        "resize" : "fit",
        "w" : 845
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tu5VHDRb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303883172406493185",
  "text" : "Discussing solutions to problems with @szlwzl over hipchat is always good :D http:\/\/t.co\/tu5VHDRb",
  "id" : 303883172406493185,
  "created_at" : "2013-02-19 15:06:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303826233483993089",
  "geo" : { },
  "id_str" : "303832399219924994",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda I have to get across the A26 on a daily basis - pain in the ass that it is. I hope they never dual it round Glenavy :)",
  "id" : 303832399219924994,
  "in_reply_to_status_id" : 303826233483993089,
  "created_at" : "2013-02-19 11:44:23 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303606054908985344",
  "geo" : { },
  "id_str" : "303611384967598081",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit that's what you get for being cocky re: jetlag ;)",
  "id" : 303611384967598081,
  "in_reply_to_status_id" : 303606054908985344,
  "created_at" : "2013-02-18 21:06:09 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 3, 10 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303581329700843520",
  "text" : "RT @holman: GitHub hit the 150 employee mark this morning. About \u2154 are remote. Never had anyone quit. Worrying about how your company wo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303576839132164097",
    "text" : "GitHub hit the 150 employee mark this morning. About \u2154 are remote. Never had anyone quit. Worrying about how your company works pays off.",
    "id" : 303576839132164097,
    "created_at" : "2013-02-18 18:48:53 +0000",
    "user" : {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "protected" : false,
      "id_str" : "11322372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1444317557\/holman_normal.png",
      "id" : 11322372,
      "verified" : false
    }
  },
  "id" : 303581329700843520,
  "created_at" : "2013-02-18 19:06:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/303560825606639616\/photo\/1",
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/8MiCqvj3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDZ29mpCEAEtZLh.jpg",
      "id_str" : "303560825610833921",
      "id" : 303560825610833921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDZ29mpCEAEtZLh.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/8MiCqvj3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303560825606639616",
  "text" : "They really do love me in here. Dave got me back - well played. Been there since Friday. http:\/\/t.co\/8MiCqvj3",
  "id" : 303560825606639616,
  "created_at" : "2013-02-18 17:45:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303539833098342400",
  "geo" : { },
  "id_str" : "303540273844191234",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin where you based now? Assumed you\u2019d be working from home.",
  "id" : 303540273844191234,
  "in_reply_to_status_id" : 303539833098342400,
  "created_at" : "2013-02-18 16:23:35 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/303514936431222784\/photo\/1",
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/iW3klKhX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDZNOgJCIAAUDla.jpg",
      "id_str" : "303514936435417088",
      "id" : 303514936435417088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDZNOgJCIAAUDla.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 881
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 881
      } ],
      "display_url" : "pic.twitter.com\/iW3klKhX"
    } ],
    "hashtags" : [ {
      "text" : "codelikeaboss",
      "indices" : [ 69, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303514936431222784",
  "text" : "Sometimes the only way to get through a Monday is to listen to this. #codelikeaboss http:\/\/t.co\/iW3klKhX",
  "id" : 303514936431222784,
  "created_at" : "2013-02-18 14:42:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303508468575371265",
  "text" : "OH: \u201CThere\u2019s too many people using the internet at the moment\u201D",
  "id" : 303508468575371265,
  "created_at" : "2013-02-18 14:17:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reco4j",
      "screen_name" : "reco4j",
      "indices" : [ 3, 10 ],
      "id_str" : "1072209276",
      "id" : 1072209276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neo4j",
      "indices" : [ 28, 34 ]
    }, {
      "text" : "Terracotta",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "BigMemory",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303501526121447424",
  "text" : "RT @reco4j: We deploy a new #neo4j cache based on #Terracotta #BigMemory. We tested it with some interesting result. For details: http:\/ ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "neo4j",
        "indices" : [ 16, 22 ]
      }, {
        "text" : "Terracotta",
        "indices" : [ 38, 49 ]
      }, {
        "text" : "BigMemory",
        "indices" : [ 50, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/h6zJ40gt",
        "expanded_url" : "http:\/\/news.reco4j.org\/",
        "display_url" : "news.reco4j.org"
      } ]
    },
    "geo" : { },
    "id_str" : "303493837412765696",
    "text" : "We deploy a new #neo4j cache based on #Terracotta #BigMemory. We tested it with some interesting result. For details: http:\/\/t.co\/h6zJ40gt",
    "id" : 303493837412765696,
    "created_at" : "2013-02-18 13:19:04 +0000",
    "user" : {
      "name" : "Reco4j",
      "screen_name" : "reco4j",
      "protected" : false,
      "id_str" : "1072209276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3215993682\/ea6133fe0f82aa2e53391d5663c205d9_normal.png",
      "id" : 1072209276,
      "verified" : false
    }
  },
  "id" : 303501526121447424,
  "created_at" : "2013-02-18 13:49:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lockoslunches",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303501413609250817",
  "text" : "RT @jbrevel: @swmcc Mmmm! 5 spice turkey breast with lettuce and cesar dressing in a toasted whole meal pitta ;-) #lockoslunches http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jbrevel\/status\/303500938646282240\/photo\/1",
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/oeWqTxrn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDZAfuWCYAA11AR.jpg",
        "id_str" : "303500938654670848",
        "id" : 303500938654670848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDZAfuWCYAA11AR.jpg",
        "sizes" : [ {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/oeWqTxrn"
      } ],
      "hashtags" : [ {
        "text" : "lockoslunches",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "303491942942126081",
    "geo" : { },
    "id_str" : "303500938646282240",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Mmmm! 5 spice turkey breast with lettuce and cesar dressing in a toasted whole meal pitta ;-) #lockoslunches http:\/\/t.co\/oeWqTxrn",
    "id" : 303500938646282240,
    "in_reply_to_status_id" : 303491942942126081,
    "created_at" : "2013-02-18 13:47:17 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 303501413609250817,
  "created_at" : "2013-02-18 13:49:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 65, 73 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/303491942942126081\/photo\/1",
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/dv5jUQMG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDY4UGuCMAAkWIh.png",
      "id_str" : "303491942946320384",
      "id" : 303491942946320384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDY4UGuCMAAkWIh.png",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 676
      } ],
      "display_url" : "pic.twitter.com\/dv5jUQMG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303491942942126081",
  "text" : "Really should do this.... But alas I wont...  True though... \/cc @jbrevel http:\/\/t.co\/dv5jUQMG",
  "id" : 303491942942126081,
  "created_at" : "2013-02-18 13:11:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oisin",
      "screen_name" : "oisin",
      "indices" : [ 3, 9 ],
      "id_str" : "8446902",
      "id" : 8446902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/oisin\/status\/303451064663957504\/photo\/1",
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/YthCrF68",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDYTIrRCYAA6EOc.png",
      "id_str" : "303451064668151808",
      "id" : 303451064668151808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDYTIrRCYAA6EOc.png",
      "sizes" : [ {
        "h" : 77,
        "resize" : "fit",
        "w" : 212
      }, {
        "h" : 77,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 77,
        "resize" : "fit",
        "w" : 212
      }, {
        "h" : 77,
        "resize" : "fit",
        "w" : 212
      }, {
        "h" : 77,
        "resize" : "fit",
        "w" : 212
      } ],
      "display_url" : "pic.twitter.com\/YthCrF68"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303482593200975872",
  "text" : "RT @oisin: I was all pissed off earlier on, but this IRC conversation has cheered me up :D http:\/\/t.co\/YthCrF68",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/oisin\/status\/303451064663957504\/photo\/1",
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/YthCrF68",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDYTIrRCYAA6EOc.png",
        "id_str" : "303451064668151808",
        "id" : 303451064668151808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDYTIrRCYAA6EOc.png",
        "sizes" : [ {
          "h" : 77,
          "resize" : "fit",
          "w" : 212
        }, {
          "h" : 77,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 77,
          "resize" : "fit",
          "w" : 212
        }, {
          "h" : 77,
          "resize" : "fit",
          "w" : 212
        }, {
          "h" : 77,
          "resize" : "fit",
          "w" : 212
        } ],
        "display_url" : "pic.twitter.com\/YthCrF68"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303451064663957504",
    "text" : "I was all pissed off earlier on, but this IRC conversation has cheered me up :D http:\/\/t.co\/YthCrF68",
    "id" : 303451064663957504,
    "created_at" : "2013-02-18 10:29:06 +0000",
    "user" : {
      "name" : "oisin",
      "screen_name" : "oisin",
      "protected" : false,
      "id_str" : "8446902",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000483810361\/d965a36e535aa4b015b9180d427cab46_normal.jpeg",
      "id" : 8446902,
      "verified" : false
    }
  },
  "id" : 303482593200975872,
  "created_at" : "2013-02-18 12:34:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 0, 9 ],
      "id_str" : "20543444",
      "id" : 20543444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303236197755527170",
  "geo" : { },
  "id_str" : "303236547736649730",
  "in_reply_to_user_id" : 20543444,
  "text" : "@HerrWulf depends on the emote server. But more than likely \u2018scp localfile username@server:\/where\/you\/want\u201D",
  "id" : 303236547736649730,
  "in_reply_to_status_id" : 303236197755527170,
  "created_at" : "2013-02-17 20:16:41 +0000",
  "in_reply_to_screen_name" : "HerrWulf",
  "in_reply_to_user_id_str" : "20543444",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 0, 9 ],
      "id_str" : "20543444",
      "id" : 20543444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303235288812113920",
  "geo" : { },
  "id_str" : "303236147079942144",
  "in_reply_to_user_id" : 20543444,
  "text" : "@HerrWulf on a mac it windows?",
  "id" : 303236147079942144,
  "in_reply_to_status_id" : 303235288812113920,
  "created_at" : "2013-02-17 20:15:05 +0000",
  "in_reply_to_screen_name" : "HerrWulf",
  "in_reply_to_user_id_str" : "20543444",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303091426454011905",
  "text" : "I must have thrown my sky+ remote out... Dammit....",
  "id" : 303091426454011905,
  "created_at" : "2013-02-17 10:40:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302912221342732289",
  "geo" : { },
  "id_str" : "302913983881543681",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 boys Michael. Compared to your girth try are mere boys.",
  "id" : 302913983881543681,
  "in_reply_to_status_id" : 302912221342732289,
  "created_at" : "2013-02-16 22:54:56 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/302910439451422720\/photo\/1",
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/IQipSMLC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDQncJaCcAEwwYB.png",
      "id_str" : "302910439455617025",
      "id" : 302910439455617025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDQncJaCcAEwwYB.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/IQipSMLC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302910439451422720",
  "text" : "My work mates love me. I always add helpful tips. And the love me for it. http:\/\/t.co\/IQipSMLC",
  "id" : 302910439451422720,
  "created_at" : "2013-02-16 22:40:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/7ltysfWb",
      "expanded_url" : "http:\/\/instagr.am\/p\/VzxAGlBX8R\/",
      "display_url" : "instagr.am\/p\/VzxAGlBX8R\/"
    } ]
  },
  "geo" : { },
  "id_str" : "302909240782249985",
  "text" : "Saturday nights. http:\/\/t.co\/7ltysfWb",
  "id" : 302909240782249985,
  "created_at" : "2013-02-16 22:36:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darth Vader",
      "screen_name" : "DepressedDarth",
      "indices" : [ 3, 18 ],
      "id_str" : "125122481",
      "id" : 125122481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302896021388800001",
  "text" : "RT @DepressedDarth: Dear JJ Abrams,\n\nIf you screw up the new Star Wars movie, I will start calling you Jar Jar Abrams.\n\nSincerely,\n\nDarth.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302817666001948672",
    "text" : "Dear JJ Abrams,\n\nIf you screw up the new Star Wars movie, I will start calling you Jar Jar Abrams.\n\nSincerely,\n\nDarth.",
    "id" : 302817666001948672,
    "created_at" : "2013-02-16 16:32:12 +0000",
    "user" : {
      "name" : "Darth Vader",
      "screen_name" : "DepressedDarth",
      "protected" : false,
      "id_str" : "125122481",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1125323984\/darthvader_normal.jpg",
      "id" : 125122481,
      "verified" : false
    }
  },
  "id" : 302896021388800001,
  "created_at" : "2013-02-16 21:43:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 3, 10 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/DmqnvdBw",
      "expanded_url" : "http:\/\/boxen.github.com\/",
      "display_url" : "boxen.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "302747349267140609",
  "text" : "RT @maddox: Boxen rules everything around me. Automate everything. \n\nhttp:\/\/t.co\/DmqnvdBw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/DmqnvdBw",
        "expanded_url" : "http:\/\/boxen.github.com\/",
        "display_url" : "boxen.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "302747222452355072",
    "text" : "Boxen rules everything around me. Automate everything. \n\nhttp:\/\/t.co\/DmqnvdBw",
    "id" : 302747222452355072,
    "created_at" : "2013-02-16 11:52:17 +0000",
    "user" : {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "protected" : false,
      "id_str" : "750823",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3056039504\/90937f21b7234d7cae8e4535d80283c2_normal.png",
      "id" : 750823,
      "verified" : false
    }
  },
  "id" : 302747349267140609,
  "created_at" : "2013-02-16 11:52:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302725693035397120",
  "text" : "Right - I sky+d Spartacus using the sky.app on the iphone. Problem being that its been so long since I watch sky I've misplaced the remote!",
  "id" : 302725693035397120,
  "created_at" : "2013-02-16 10:26:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Gatt",
      "screen_name" : "MeetJoeGatt",
      "indices" : [ 21, 33 ],
      "id_str" : "528034156",
      "id" : 528034156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302704119586627584",
  "text" : "Best bad guy ever... @MeetJoeGatt",
  "id" : 302704119586627584,
  "created_at" : "2013-02-16 09:01:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "indices" : [ 3, 19 ],
      "id_str" : "402824193",
      "id" : 402824193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/V3zWMTQw",
      "expanded_url" : "http:\/\/bit.ly\/Z2JVYJ",
      "display_url" : "bit.ly\/Z2JVYJ"
    }, {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/emR97f1I",
      "expanded_url" : "http:\/\/bit.ly\/12LuCE6",
      "display_url" : "bit.ly\/12LuCE6"
    } ]
  },
  "geo" : { },
  "id_str" : "302494595332337664",
  "text" : "RT @NodeJsCommunity: REST up! Using Node.js to write RESTful web services http:\/\/t.co\/V3zWMTQw #nodejs http:\/\/t.co\/emR97f1I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodejs",
        "indices" : [ 74, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/V3zWMTQw",
        "expanded_url" : "http:\/\/bit.ly\/Z2JVYJ",
        "display_url" : "bit.ly\/Z2JVYJ"
      }, {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/emR97f1I",
        "expanded_url" : "http:\/\/bit.ly\/12LuCE6",
        "display_url" : "bit.ly\/12LuCE6"
      } ]
    },
    "geo" : { },
    "id_str" : "302468445423927296",
    "text" : "REST up! Using Node.js to write RESTful web services http:\/\/t.co\/V3zWMTQw #nodejs http:\/\/t.co\/emR97f1I",
    "id" : 302468445423927296,
    "created_at" : "2013-02-15 17:24:31 +0000",
    "user" : {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "protected" : false,
      "id_str" : "402824193",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1627924583\/njscomm_normal.jpg",
      "id" : 402824193,
      "verified" : false
    }
  },
  "id" : 302494595332337664,
  "created_at" : "2013-02-15 19:08:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 3, 13 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 15, 21 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302411039251767296",
  "text" : "RT @smccalden: @swmcc : \"how do I get a fire to look like that?\" Me : \"that's a gas fire\" *facepalm*",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302393554624446464",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc : \"how do I get a fire to look like that?\" Me : \"that's a gas fire\" *facepalm*",
    "id" : 302393554624446464,
    "created_at" : "2013-02-15 12:26:56 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "protected" : false,
      "id_str" : "169048119",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1169599362\/5bccf87c-8216-4684-bad8-61ad974596df_normal.png",
      "id" : 169048119,
      "verified" : false
    }
  },
  "id" : 302411039251767296,
  "created_at" : "2013-02-15 13:36:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BT",
      "screen_name" : "BTCare",
      "indices" : [ 0, 7 ],
      "id_str" : "35737385",
      "id" : 35737385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302383474059399169",
  "geo" : { },
  "id_str" : "302388531114954752",
  "in_reply_to_user_id" : 35737385,
  "text" : "@BTCare am at work - will do when I am home and let you know - cheers :)",
  "id" : 302388531114954752,
  "in_reply_to_status_id" : 302383474059399169,
  "created_at" : "2013-02-15 12:06:58 +0000",
  "in_reply_to_screen_name" : "BTCare",
  "in_reply_to_user_id_str" : "35737385",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badmoodfridaysftw",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302371737700544512",
  "text" : "I just lost FMC again.. And there is no tea bags in the office\u2026 This is not helping my mood today. #badmoodfridaysftw",
  "id" : 302371737700544512,
  "created_at" : "2013-02-15 11:00:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302370649647751169",
  "geo" : { },
  "id_str" : "302371543089049601",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin will see when I get home. I was getting the low 20\u2019s lately\u2026 Does me rightly like. No way I could go back to 512k though :)",
  "id" : 302371543089049601,
  "in_reply_to_status_id" : 302370649647751169,
  "created_at" : "2013-02-15 10:59:28 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302369188016693249",
  "text" : "I got an email saying that BT have upgraded my line\u2026 So now I should get up to 76Mbit downloads\u2026. Believe it when I see it tbh...",
  "id" : 302369188016693249,
  "created_at" : "2013-02-15 10:50:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "heroku",
      "screen_name" : "heroku",
      "indices" : [ 108, 115 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geekcustody",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302185741700706305",
  "geo" : { },
  "id_str" : "302185992360718336",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl Possesion is 9\/10's of the law. He hasn't been ported to an offical server yet - still exists on my @heroku account. #geekcustody",
  "id" : 302185992360718336,
  "in_reply_to_status_id" : 302185741700706305,
  "created_at" : "2013-02-14 22:42:09 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302184020928761856",
  "geo" : { },
  "id_str" : "302185591561404417",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I want sole custody of Dug...",
  "id" : 302185591561404417,
  "in_reply_to_status_id" : 302184020928761856,
  "created_at" : "2013-02-14 22:40:34 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302183172555288576",
  "geo" : { },
  "id_str" : "302183455431729152",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you sir... are a disappointment.. We share joint custody of Dug as well... You think you know a person .....",
  "id" : 302183455431729152,
  "in_reply_to_status_id" : 302183172555288576,
  "created_at" : "2013-02-14 22:32:04 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302182868438904832",
  "text" : "Just been reminded - someone on my twitter list likes Love Actually.... Can't remember who it was but it was surprising..... Hmmmmmmmm",
  "id" : 302182868438904832,
  "created_at" : "2013-02-14 22:29:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302182311858937856",
  "geo" : { },
  "id_str" : "302182646459539457",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl its not as scary as the first one - but it still has demons in it.. and a scary kid. ahhh well - better than watching love actually!",
  "id" : 302182646459539457,
  "in_reply_to_status_id" : 302182311858937856,
  "created_at" : "2013-02-14 22:28:51 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302182086310244352",
  "text" : "I've just watched Paranomal Activity 4... Scared the living shit out of me... all the lights on in the house tonight then!",
  "id" : 302182086310244352,
  "created_at" : "2013-02-14 22:26:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 8, 16 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/OsLiVidF",
      "expanded_url" : "http:\/\/familyguy.wikia.com\/wiki\/Road_House",
      "display_url" : "familyguy.wikia.com\/wiki\/Road_House"
    }, {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/pIVSfB3t",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=sbAiY1ZF69U",
      "display_url" : "youtube.com\/watch?v=sbAiY1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "302176807485050882",
  "geo" : { },
  "id_str" : "302177933311762433",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @jbrevel awesome - I hope you said \"roadhouse\" after it. http:\/\/t.co\/OsLiVidF - http:\/\/t.co\/pIVSfB3t",
  "id" : 302177933311762433,
  "in_reply_to_status_id" : 302176807485050882,
  "created_at" : "2013-02-14 22:10:08 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 55, 63 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roadhouse",
      "indices" : [ 22, 32 ]
    }, {
      "text" : "roadhouse",
      "indices" : [ 33, 43 ]
    }, {
      "text" : "roadhouse",
      "indices" : [ 44, 54 ]
    }, {
      "text" : "GHOST",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302163734913236992",
  "geo" : { },
  "id_str" : "302176104188350464",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl Road house... #roadhouse #roadhouse #roadhouse @jbrevel #GHOST",
  "id" : 302176104188350464,
  "in_reply_to_status_id" : 302163734913236992,
  "created_at" : "2013-02-14 22:02:52 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlassian HipChat",
      "screen_name" : "HipChat",
      "indices" : [ 0, 8 ],
      "id_str" : "17810599",
      "id" : 17810599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302114812794646528",
  "geo" : { },
  "id_str" : "302118885480595458",
  "in_reply_to_user_id" : 17810599,
  "text" : "@HipChat Fantastic!! I refused to install air on my mac - giving this a go now :) :)",
  "id" : 302118885480595458,
  "in_reply_to_status_id" : 302114812794646528,
  "created_at" : "2013-02-14 18:15:30 +0000",
  "in_reply_to_screen_name" : "HipChat",
  "in_reply_to_user_id_str" : "17810599",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 0, 7 ],
      "id_str" : "17843859",
      "id" : 17843859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302114216716931072",
  "geo" : { },
  "id_str" : "302118642080964608",
  "in_reply_to_user_id" : 17843859,
  "text" : "@rtweed cheers :)",
  "id" : 302118642080964608,
  "in_reply_to_status_id" : 302114216716931072,
  "created_at" : "2013-02-14 18:14:32 +0000",
  "in_reply_to_screen_name" : "rtweed",
  "in_reply_to_user_id_str" : "17843859",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 22, 29 ],
      "id_str" : "17843859",
      "id" : 17843859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302112498801328129",
  "text" : "Thanks for the follow @rtweed You are doing very interesting things. Loved your talk on node.js  and vista last year.",
  "id" : 302112498801328129,
  "created_at" : "2013-02-14 17:50:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302105596889546752",
  "text" : "Nothing quite like re-factoring code and listening to the Top Gun theme tune\u2026 Nothing...",
  "id" : 302105596889546752,
  "created_at" : "2013-02-14 17:22:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302079946153664513",
  "geo" : { },
  "id_str" : "302098284355416064",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid I want them to ignore me Debbie! That\u2019s why I am here after they all leave. I work better without those knobs around :)",
  "id" : 302098284355416064,
  "in_reply_to_status_id" : 302079946153664513,
  "created_at" : "2013-02-14 16:53:38 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302070531274981376",
  "text" : "Ancient spirits of evil, transform this decayed form to Mumm-Ra, the Ever-Living!\"",
  "id" : 302070531274981376,
  "created_at" : "2013-02-14 15:03:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 11, 23 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302067718742495233",
  "text" : "Apart from @DebbieCReid I work with a bunch of knobs (London ppl exempt)... I come back from working to see a tirade of tweets against me!",
  "id" : 302067718742495233,
  "created_at" : "2013-02-14 14:52:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302049770594258945",
  "geo" : { },
  "id_str" : "302051107906138112",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo you fucking cock",
  "id" : 302051107906138112,
  "in_reply_to_status_id" : 302049770594258945,
  "created_at" : "2013-02-14 13:46:10 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301842233332748288",
  "geo" : { },
  "id_str" : "301954591367524353",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues dude!!!! What you doing watching that? :( :( :( Ohhh nook - that film is bad on about every level.",
  "id" : 301954591367524353,
  "in_reply_to_status_id" : 301842233332748288,
  "created_at" : "2013-02-14 07:22:39 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "indices" : [ 3, 19 ],
      "id_str" : "402824193",
      "id" : 402824193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/MCs8MwoN",
      "expanded_url" : "http:\/\/loadimpact.com\/blog\/nodejs-vs-php-using-load-impact-to-viaualize-nodejs-efficency",
      "display_url" : "loadimpact.com\/blog\/nodejs-vs\u2026"
    }, {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/PuzR06sm",
      "expanded_url" : "http:\/\/bit.ly\/V899Yi",
      "display_url" : "bit.ly\/V899Yi"
    } ]
  },
  "geo" : { },
  "id_str" : "301830012561158144",
  "text" : "RT @NodeJsCommunity: Node.js vs PHP - Let\u00B4s visualize node.js efficency. http:\/\/t.co\/MCs8MwoN http:\/\/t.co\/PuzR06sm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/MCs8MwoN",
        "expanded_url" : "http:\/\/loadimpact.com\/blog\/nodejs-vs-php-using-load-impact-to-viaualize-nodejs-efficency",
        "display_url" : "loadimpact.com\/blog\/nodejs-vs\u2026"
      }, {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/PuzR06sm",
        "expanded_url" : "http:\/\/bit.ly\/V899Yi",
        "display_url" : "bit.ly\/V899Yi"
      } ]
    },
    "geo" : { },
    "id_str" : "301633772120588288",
    "text" : "Node.js vs PHP - Let\u00B4s visualize node.js efficency. http:\/\/t.co\/MCs8MwoN http:\/\/t.co\/PuzR06sm",
    "id" : 301633772120588288,
    "created_at" : "2013-02-13 10:07:50 +0000",
    "user" : {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "protected" : false,
      "id_str" : "402824193",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1627924583\/njscomm_normal.jpg",
      "id" : 402824193,
      "verified" : false
    }
  },
  "id" : 301830012561158144,
  "created_at" : "2013-02-13 23:07:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 3, 18 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 30, 38 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/p9rCDXwZ",
      "expanded_url" : "http:\/\/twitter.com\/annette_mccull\/status\/301808753093779456\/photo\/1",
      "display_url" : "pic.twitter.com\/p9rCDXwZ"
    } ]
  },
  "geo" : { },
  "id_str" : "301809429366575104",
  "text" : "RT @annette_mccull: Fuck sake @YouTube what did I ever do to you? http:\/\/t.co\/p9rCDXwZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 10, 18 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/annette_mccull\/status\/301808753093779456\/photo\/1",
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/p9rCDXwZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDA9dj7CIAAcxTD.jpg",
        "id_str" : "301808753102168064",
        "id" : 301808753102168064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDA9dj7CIAAcxTD.jpg",
        "sizes" : [ {
          "h" : 83,
          "resize" : "fit",
          "w" : 293
        }, {
          "h" : 83,
          "resize" : "fit",
          "w" : 293
        }, {
          "h" : 83,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 83,
          "resize" : "fit",
          "w" : 293
        }, {
          "h" : 83,
          "resize" : "fit",
          "w" : 293
        } ],
        "display_url" : "pic.twitter.com\/p9rCDXwZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301808753093779456",
    "text" : "Fuck sake @YouTube what did I ever do to you? http:\/\/t.co\/p9rCDXwZ",
    "id" : 301808753093779456,
    "created_at" : "2013-02-13 21:43:08 +0000",
    "user" : {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "protected" : true,
      "id_str" : "161635397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000591917589\/beb3a4a248d02295741466ac18029379_normal.jpeg",
      "id" : 161635397,
      "verified" : false
    }
  },
  "id" : 301809429366575104,
  "created_at" : "2013-02-13 21:45:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301793904267780096",
  "text" : "That moment you think \u201Cfuck it, am leaving my laptop at work\u201D only to discover that you are still on call.. Yeah that\u2026 #FUCKYOUWEDNESDAY :)",
  "id" : 301793904267780096,
  "created_at" : "2013-02-13 20:44:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/301750309523447808\/photo\/1",
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/0pyvcEIF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDAITspCYAA_wcp.jpg",
      "id_str" : "301750309527642112",
      "id" : 301750309527642112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDAITspCYAA_wcp.jpg",
      "sizes" : [ {
        "h" : 174,
        "resize" : "fit",
        "w" : 451
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 451
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 451
      } ],
      "display_url" : "pic.twitter.com\/0pyvcEIF"
    } ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 23, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301750309523447808",
  "text" : "Head refusing to work\u2026 #FUCKYOUWEDNESDAY http:\/\/t.co\/0pyvcEIF",
  "id" : 301750309523447808,
  "created_at" : "2013-02-13 17:50:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youcanonlydosomuchsometimes",
      "indices" : [ 93, 121 ]
    }, {
      "text" : "grrrrrrrrrr",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301742130018267137",
  "text" : "I die a little every time I find a file that isn\u2019t in version control\u2026. I really really do\u2026. #youcanonlydosomuchsometimes #grrrrrrrrrr :) :)",
  "id" : 301742130018267137,
  "created_at" : "2013-02-13 17:18:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301716350345310208",
  "geo" : { },
  "id_str" : "301717630656581632",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe I think its a bit thing to get me think that actually works. I still have an alias to tail the errors. alias fuck=\u2018tail -f \/var\/l ;)",
  "id" : 301717630656581632,
  "in_reply_to_status_id" : 301716350345310208,
  "created_at" : "2013-02-13 15:41:03 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 52, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 21 ],
      "url" : "https:\/\/t.co\/zUbWIcs8",
      "expanded_url" : "https:\/\/github.com\/swmcc\/cookbook\/blob\/master\/git\/.aliases",
      "display_url" : "github.com\/swmcc\/cookbook\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301715240503083008",
  "text" : "https:\/\/t.co\/zUbWIcs8 - git push won\u2019t happen again #FUCKYOUWEDNESDAY",
  "id" : 301715240503083008,
  "created_at" : "2013-02-13 15:31:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 0, 9 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 31 ],
      "url" : "https:\/\/t.co\/zUbWIcs8",
      "expanded_url" : "https:\/\/github.com\/swmcc\/cookbook\/blob\/master\/git\/.aliases",
      "display_url" : "github.com\/swmcc\/cookbook\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "301713998187995137",
  "geo" : { },
  "id_str" : "301715007899578369",
  "in_reply_to_user_id" : 223516339,
  "text" : "@vduglued https:\/\/t.co\/zUbWIcs8 - already done :) Should save my sanity for another day at least.",
  "id" : 301715007899578369,
  "in_reply_to_status_id" : 301713998187995137,
  "created_at" : "2013-02-13 15:30:38 +0000",
  "in_reply_to_screen_name" : "vduglued",
  "in_reply_to_user_id_str" : "223516339",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 16, 24 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 25, 39 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301712545486602240",
  "geo" : { },
  "id_str" : "301713310561230848",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @HaVoCT5 @peter_omalley impressive\u2026 where are you? and that\u2019s just a starter? ;)",
  "id" : 301713310561230848,
  "in_reply_to_status_id" : 301712545486602240,
  "created_at" : "2013-02-13 15:23:53 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/301713199366025218\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/YqoA064m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC_mjmkCMAAWuDS.jpg",
      "id_str" : "301713199378608128",
      "id" : 301713199378608128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC_mjmkCMAAWuDS.jpg",
      "sizes" : [ {
        "h" : 110,
        "resize" : "fit",
        "w" : 408
      }, {
        "h" : 110,
        "resize" : "fit",
        "w" : 408
      }, {
        "h" : 92,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 110,
        "resize" : "fit",
        "w" : 408
      }, {
        "h" : 110,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/YqoA064m"
    } ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 90, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301713199366025218",
  "text" : "Number of times I do this on a daily basis is quite worrying. Quite apt for today though. #FUCKYOUWEDNESDAY http:\/\/t.co\/YqoA064m",
  "id" : 301713199366025218,
  "created_at" : "2013-02-13 15:23:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 3, 17 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301692241632694272",
  "text" : "RT @ChrisKnowles_: \" Ubuntu is an African word meaning 'I can't configure Debian' \"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301691950430576640",
    "text" : "\" Ubuntu is an African word meaning 'I can't configure Debian' \"",
    "id" : 301691950430576640,
    "created_at" : "2013-02-13 13:59:00 +0000",
    "user" : {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "protected" : false,
      "id_str" : "241959103",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2926965131\/2eaf8d76e348f155b1079a71275e2ceb_normal.png",
      "id" : 241959103,
      "verified" : false
    }
  },
  "id" : 301692241632694272,
  "created_at" : "2013-02-13 14:00:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301690673705414656",
  "text" : "\/etc\/init.d\/wednesday restart",
  "id" : 301690673705414656,
  "created_at" : "2013-02-13 13:53:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301630615126683649",
  "text" : "OH: \u201CSo, how stiff are your right now?\u201D",
  "id" : 301630615126683649,
  "created_at" : "2013-02-13 09:55:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301455968116559873",
  "geo" : { },
  "id_str" : "301459739668275202",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden we can use rake to do the db:migrations etc - wee tiny improvements next thing you know shit gets easier in the long run.",
  "id" : 301459739668275202,
  "in_reply_to_status_id" : 301455968116559873,
  "created_at" : "2013-02-12 22:36:17 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boooyaaaaaaa",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301455968116559873",
  "geo" : { },
  "id_str" : "301459467147567105",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden cap live deploy #boooyaaaaaaa :) When I am done with this sprint I'll have a look at doing the same with your stuffs.",
  "id" : 301459467147567105,
  "in_reply_to_status_id" : 301455968116559873,
  "created_at" : "2013-02-12 22:35:12 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Hamshere",
      "screen_name" : "tbrd",
      "indices" : [ 3, 8 ],
      "id_str" : "4149861",
      "id" : 4149861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/vIKlCCGZ",
      "expanded_url" : "http:\/\/simplebutgood.net\/?p=247",
      "display_url" : "simplebutgood.net\/?p=247"
    } ]
  },
  "geo" : { },
  "id_str" : "301438345463074816",
  "text" : "RT @tbrd: New blog post: Flight at TweetDeck - a look at building TweetDeck with Flight, Twitter's new JS Framework. http:\/\/t.co\/vIKlCCGZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/vIKlCCGZ",
        "expanded_url" : "http:\/\/simplebutgood.net\/?p=247",
        "display_url" : "simplebutgood.net\/?p=247"
      } ]
    },
    "geo" : { },
    "id_str" : "301364158753038337",
    "text" : "New blog post: Flight at TweetDeck - a look at building TweetDeck with Flight, Twitter's new JS Framework. http:\/\/t.co\/vIKlCCGZ",
    "id" : 301364158753038337,
    "created_at" : "2013-02-12 16:16:29 +0000",
    "user" : {
      "name" : "Tom Hamshere",
      "screen_name" : "tbrd",
      "protected" : false,
      "id_str" : "4149861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1056532521\/1_normal.jpg",
      "id" : 4149861,
      "verified" : false
    }
  },
  "id" : 301438345463074816,
  "created_at" : "2013-02-12 21:11:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nuno Job",
      "screen_name" : "dscape",
      "indices" : [ 3, 10 ],
      "id_str" : "9279552",
      "id" : 9279552
    }, {
      "name" : "Nodejitsu",
      "screen_name" : "nodejitsu",
      "indices" : [ 27, 37 ],
      "id_str" : "157442008",
      "id" : 157442008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301406518211923970",
  "text" : "RT @dscape: Super proud of @nodejitsu \u2014 Not everyday you launch 1 Business Plans 2 European DCs 3 Multi Provider Support 4 Major Partner ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nodejitsu",
        "screen_name" : "nodejitsu",
        "indices" : [ 15, 25 ],
        "id_str" : "157442008",
        "id" : 157442008
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301401011719901184",
    "text" : "Super proud of @nodejitsu \u2014 Not everyday you launch 1 Business Plans 2 European DCs 3 Multi Provider Support 4 Major Partnership 5 New site",
    "id" : 301401011719901184,
    "created_at" : "2013-02-12 18:42:55 +0000",
    "user" : {
      "name" : "Nuno Job",
      "screen_name" : "dscape",
      "protected" : false,
      "id_str" : "9279552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3557388878\/b143b6a24766a4b80d54b11d54f5cd59_normal.jpeg",
      "id" : 9279552,
      "verified" : false
    }
  },
  "id" : 301406518211923970,
  "created_at" : "2013-02-12 19:04:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 0, 13 ],
      "id_str" : "162449244",
      "id" : 162449244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301392483764563968",
  "geo" : { },
  "id_str" : "301398597713408000",
  "in_reply_to_user_id" : 162449244,
  "text" : "@justinMleary ;)",
  "id" : 301398597713408000,
  "in_reply_to_status_id" : 301392483764563968,
  "created_at" : "2013-02-12 18:33:20 +0000",
  "in_reply_to_screen_name" : "justinMleary",
  "in_reply_to_user_id_str" : "162449244",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "backofthefuckingnet",
      "indices" : [ 41, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301392191245398016",
  "text" : "She passed. 250quid for a years driving. #backofthefuckingnet",
  "id" : 301392191245398016,
  "created_at" : "2013-02-12 18:07:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 0, 13 ],
      "id_str" : "162449244",
      "id" : 162449244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301390076749959168",
  "geo" : { },
  "id_str" : "301390744025980930",
  "in_reply_to_user_id" : 162449244,
  "text" : "@justinMleary shit it panda! You are an endangered species!",
  "id" : 301390744025980930,
  "in_reply_to_status_id" : 301390076749959168,
  "created_at" : "2013-02-12 18:02:07 +0000",
  "in_reply_to_screen_name" : "justinMleary",
  "in_reply_to_user_id_str" : "162449244",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 0, 13 ],
      "id_str" : "162449244",
      "id" : 162449244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301389648742215680",
  "geo" : { },
  "id_str" : "301390048660692993",
  "in_reply_to_user_id" : 162449244,
  "text" : "@justinMleary ssssshhhhhh she will hear you!",
  "id" : 301390048660692993,
  "in_reply_to_status_id" : 301389648742215680,
  "created_at" : "2013-02-12 17:59:21 +0000",
  "in_reply_to_screen_name" : "justinMleary",
  "in_reply_to_user_id_str" : "162449244",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301389874446094337",
  "text" : "Man that is doing my MOT test just started talking to someone on his mobile. This could be very good OR very bad.",
  "id" : 301389874446094337,
  "created_at" : "2013-02-12 17:58:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 0, 13 ],
      "id_str" : "162449244",
      "id" : 162449244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301388928655695872",
  "geo" : { },
  "id_str" : "301389438049742849",
  "in_reply_to_user_id" : 162449244,
  "text" : "@justinMleary if age passes she\u2019ll get a valet on Friday.",
  "id" : 301389438049742849,
  "in_reply_to_status_id" : 301388928655695872,
  "created_at" : "2013-02-12 17:56:56 +0000",
  "in_reply_to_screen_name" : "justinMleary",
  "in_reply_to_user_id_str" : "162449244",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 0, 13 ],
      "id_str" : "162449244",
      "id" : 162449244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301388504871616512",
  "geo" : { },
  "id_str" : "301388741904318464",
  "in_reply_to_user_id" : 162449244,
  "text" : "@justinMleary she\u2019s up on the 17th so will have till then to fix her. But let\u2019s hope she passes.",
  "id" : 301388741904318464,
  "in_reply_to_status_id" : 301388504871616512,
  "created_at" : "2013-02-12 17:54:10 +0000",
  "in_reply_to_screen_name" : "justinMleary",
  "in_reply_to_user_id_str" : "162449244",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mot",
      "indices" : [ 40, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301388263762046978",
  "text" : "I hate this\u2026\u2026 Am waiting at the side\u2026.. #mot",
  "id" : 301388263762046978,
  "created_at" : "2013-02-12 17:52:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fashionvictims",
      "indices" : [ 48, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301386866979135488",
  "text" : "Also while I am here. VPS does not equal Cloud. #fashionvictims",
  "id" : 301386866979135488,
  "created_at" : "2013-02-12 17:46:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brickingit",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301386052705349632",
  "text" : "Awaiting my MOT. #brickingit",
  "id" : 301386052705349632,
  "created_at" : "2013-02-12 17:43:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 17, 25 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 26, 40 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301375049674420224",
  "geo" : { },
  "id_str" : "301375212153364482",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @HaVoCT5 @peter_omalley :D :D :D :D I\u2019m outside your flat getting MOT\u2019d in an hour Mike :D",
  "id" : 301375212153364482,
  "in_reply_to_status_id" : 301375049674420224,
  "created_at" : "2013-02-12 17:00:24 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 9, 23 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 76, 84 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301374082686013440",
  "geo" : { },
  "id_str" : "301374899631558658",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @peter_omalley I\u2019ve had a shit day too and this has cheered me and @jbrevel up :D Cheers Pete you fantastic human being!",
  "id" : 301374899631558658,
  "in_reply_to_status_id" : 301374082686013440,
  "created_at" : "2013-02-12 16:59:09 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Invest NI",
      "screen_name" : "InvestNINews",
      "indices" : [ 3, 16 ],
      "id_str" : "64692506",
      "id" : 64692506
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestNI",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301354329837813760",
  "text" : "RT @InvestNINews: Companies who invest in R&amp;D perform better. Find out how #InvestNI can help your business. Belfast 14 Feb http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InvestNI",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/gH2UjeqI",
        "expanded_url" : "http:\/\/bit.ly\/11003cO",
        "display_url" : "bit.ly\/11003cO"
      } ]
    },
    "geo" : { },
    "id_str" : "301298421694861312",
    "text" : "Companies who invest in R&amp;D perform better. Find out how #InvestNI can help your business. Belfast 14 Feb http:\/\/t.co\/gH2UjeqI",
    "id" : 301298421694861312,
    "created_at" : "2013-02-12 11:55:16 +0000",
    "user" : {
      "name" : "Invest NI",
      "screen_name" : "InvestNINews",
      "protected" : false,
      "id_str" : "64692506",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3432731363\/83456803b9a1dc3e3431bef13068d3c9_normal.jpeg",
      "id" : 64692506,
      "verified" : false
    }
  },
  "id" : 301354329837813760,
  "created_at" : "2013-02-12 15:37:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301287044360048641",
  "geo" : { },
  "id_str" : "301306346760970240",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley amazing... just amazing....",
  "id" : 301306346760970240,
  "in_reply_to_status_id" : 301287044360048641,
  "created_at" : "2013-02-12 12:26:45 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301248920196100096",
  "text" : "Right Tuesday - I am going to fucking destroy you!",
  "id" : 301248920196100096,
  "created_at" : "2013-02-12 08:38:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 60, 67 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greatminds",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301070653761671168",
  "text" : "Faster deploys are now possible - thank feck\u2026 Big thanks to @szlwzl for his help\u2026 #greatminds ;)",
  "id" : 301070653761671168,
  "created_at" : "2013-02-11 20:50:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 0, 11 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shitisntfunnyanymore",
      "indices" : [ 72, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301057073439993857",
  "geo" : { },
  "id_str" : "301058948147073025",
  "in_reply_to_user_id" : 5932682,
  "text" : "@davidjrice count to 10.. load up on the red bull shove on some RATM ;) #shitisntfunnyanymore",
  "id" : 301058948147073025,
  "in_reply_to_status_id" : 301057073439993857,
  "created_at" : "2013-02-11 20:03:41 +0000",
  "in_reply_to_screen_name" : "davidjrice",
  "in_reply_to_user_id_str" : "5932682",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 11, 19 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301041628381065216",
  "geo" : { },
  "id_str" : "301042140685955072",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @jbrevel sorry\u2026 I meant to say something else - thing is - I don\u2019t know what.. BUT I DIDN\u2019T MEAN TO SAY THAT!",
  "id" : 301042140685955072,
  "in_reply_to_status_id" : 301041628381065216,
  "created_at" : "2013-02-11 18:56:54 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 38, 48 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SQUIRREL",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301041544415309824",
  "text" : "The bot is called \u201CDoug\u201D in honour of @smccalden :D #SQUIRREL",
  "id" : 301041544415309824,
  "created_at" : "2013-02-11 18:54:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301041399942488065",
  "text" : "Working late tonight to get a few shitty things done. But going to work on the hipchat bot for a half an hour for some downtime...",
  "id" : 301041399942488065,
  "created_at" : "2013-02-11 18:53:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301039923140644864",
  "geo" : { },
  "id_str" : "301040110873505794",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_  aye - but it doesn\u2019t have git core as a package. The apt-get was to show how easy in debian\/ubuntu..",
  "id" : 301040110873505794,
  "in_reply_to_status_id" : 301039923140644864,
  "created_at" : "2013-02-11 18:48:50 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debian",
      "indices" : [ 114, 121 ]
    }, {
      "text" : "ubuntu",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301038989039763457",
  "text" : "I must be doing something wrong - there is no git-core in redhat????? I hate redhat... apt-get install git-core - #debian #ubuntu GRRRRR",
  "id" : 301038989039763457,
  "created_at" : "2013-02-11 18:44:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301025127481626624",
  "geo" : { },
  "id_str" : "301025736339369984",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel I have no idea what I meant to say in place of that... I feel ill and very very confused...",
  "id" : 301025736339369984,
  "in_reply_to_status_id" : 301025127481626624,
  "created_at" : "2013-02-11 17:51:42 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301021474112811008",
  "geo" : { },
  "id_str" : "301021577259126785",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson take a picture of one and shove it on my old desk :( :( :(",
  "id" : 301021577259126785,
  "in_reply_to_status_id" : 301021474112811008,
  "created_at" : "2013-02-11 17:35:11 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 1, 17 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/4aBWP0B4",
      "expanded_url" : "http:\/\/j.mp\/Y0SbHu",
      "display_url" : "j.mp\/Y0SbHu"
    } ]
  },
  "geo" : { },
  "id_str" : "301020992334086144",
  "text" : "\u201C@newsycombinator: Building Twitter Bootstrap http:\/\/t.co\/4aBWP0B4\u201D My own stuff uses TB.. It just works.. LOVE IT.",
  "id" : 301020992334086144,
  "created_at" : "2013-02-11 17:32:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301013017355747329",
  "geo" : { },
  "id_str" : "301019993066332161",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson FUCK SAKE I FORGOT ABOUT THAT :( :( :( :( :( :(",
  "id" : 301019993066332161,
  "in_reply_to_status_id" : 301013017355747329,
  "created_at" : "2013-02-11 17:28:53 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300876680686338048",
  "text" : "RT @sstephenson: Bash is now the lowest common denominator scripting tool. (Used to be Perl, but it\u2019s too hard to know what version you  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "300744610345533440",
    "text" : "Bash is now the lowest common denominator scripting tool. (Used to be Perl, but it\u2019s too hard to know what version you can target anymore.)",
    "id" : 300744610345533440,
    "created_at" : "2013-02-10 23:14:37 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1691186870\/500_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 300876680686338048,
  "created_at" : "2013-02-11 07:59:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300722583857397761",
  "geo" : { },
  "id_str" : "300723104311803904",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl :) Am looking forward to this. Missed the last one due to being sick - so really want to see this one.",
  "id" : 300723104311803904,
  "in_reply_to_status_id" : 300722583857397761,
  "created_at" : "2013-02-10 21:49:09 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bash!",
      "screen_name" : "devbash",
      "indices" : [ 16, 24 ],
      "id_str" : "454193975",
      "id" : 454193975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300722303908577282",
  "text" : "And just got my @devbash ticket for the 19th :) That should be an excellent talk!",
  "id" : 300722303908577282,
  "created_at" : "2013-02-10 21:45:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300622132843536385",
  "text" : "Bishop Brennan is in Harry Potter :D :D :D :D :D :D",
  "id" : 300622132843536385,
  "created_at" : "2013-02-10 15:07:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300535845750968320",
  "text" : "\"Meshi Geshi Gushi Gushi Meshi Mashi Mushi... Mothafucker !\"",
  "id" : 300535845750968320,
  "created_at" : "2013-02-10 09:25:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300448489886855168",
  "text" : "RT @szlwzl: My special skill in the hunger games would be making spaghetti bolognase or lasagna. I'm really good at that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "300411102217506816",
    "text" : "My special skill in the hunger games would be making spaghetti bolognase or lasagna. I'm really good at that.",
    "id" : 300411102217506816,
    "created_at" : "2013-02-10 01:09:22 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 300448489886855168,
  "created_at" : "2013-02-10 03:37:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bash!",
      "screen_name" : "devbash",
      "indices" : [ 0, 8 ],
      "id_str" : "454193975",
      "id" : 454193975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300018315231916032",
  "geo" : { },
  "id_str" : "300309952738783236",
  "in_reply_to_user_id" : 454193975,
  "text" : "@devbash can you give out hints?",
  "id" : 300309952738783236,
  "in_reply_to_status_id" : 300018315231916032,
  "created_at" : "2013-02-09 18:27:26 +0000",
  "in_reply_to_screen_name" : "devbash",
  "in_reply_to_user_id_str" : "454193975",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 11, 18 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300232049145569280",
  "geo" : { },
  "id_str" : "300236007142477824",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @szlwzl I can't have any :(",
  "id" : 300236007142477824,
  "in_reply_to_status_id" : 300232049145569280,
  "created_at" : "2013-02-09 13:33:36 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300221098660859904",
  "geo" : { },
  "id_str" : "300221633870843904",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl no choice dude. I need several implements that will bring me gratification I have yet to accomplish. FUCKING HATE THIS SHIT!",
  "id" : 300221633870843904,
  "in_reply_to_status_id" : 300221098660859904,
  "created_at" : "2013-02-09 12:36:30 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 42, 55 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300219727479988224",
  "text" : "Eugggh Ikea beckons... Then a coffee with @stevebiscuit - so not all too bad...",
  "id" : 300219727479988224,
  "created_at" : "2013-02-09 12:28:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 3, 13 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299953680529108995",
  "text" : "RT @smccalden: We all know they're bad but fact is they appear in most songs. This week's FMC topic was best song referencing\u2026 http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/II7Y2dkT",
        "expanded_url" : "http:\/\/wp.me\/p23SfW-9O",
        "display_url" : "wp.me\/p23SfW-9O"
      } ]
    },
    "geo" : { },
    "id_str" : "299946169377906689",
    "text" : "We all know they're bad but fact is they appear in most songs. This week's FMC topic was best song referencing\u2026 http:\/\/t.co\/II7Y2dkT",
    "id" : 299946169377906689,
    "created_at" : "2013-02-08 18:21:54 +0000",
    "user" : {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "protected" : false,
      "id_str" : "169048119",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1169599362\/5bccf87c-8216-4684-bad8-61ad974596df_normal.png",
      "id" : 169048119,
      "verified" : false
    }
  },
  "id" : 299953680529108995,
  "created_at" : "2013-02-08 18:51:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299895091844235265",
  "geo" : { },
  "id_str" : "299896918702706688",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin WHAT? WHAT? I hope you have told her that Han shoots first and that in no way does Vader shout 'Noooooo'.",
  "id" : 299896918702706688,
  "in_reply_to_status_id" : 299895091844235265,
  "created_at" : "2013-02-08 15:06:11 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 78, 85 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299894142799069185",
  "text" : "Nothing as bad as unfollowing a prick only for some asshole to retweet him ;) @padzor stop that please :)",
  "id" : 299894142799069185,
  "created_at" : "2013-02-08 14:55:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clock",
      "screen_name" : "clock",
      "indices" : [ 67, 73 ],
      "id_str" : "24866880",
      "id" : 24866880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299893437694627842",
  "text" : "On my working 50\/10 routine I have to say it is a pleasure to read @clock blog during the \u201910\u2019. Great company. Keep up the great work :)",
  "id" : 299893437694627842,
  "created_at" : "2013-02-08 14:52:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299864407184379904",
  "geo" : { },
  "id_str" : "299882411037192192",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull that looks epic. Love the wee bit of salad on the end.",
  "id" : 299882411037192192,
  "in_reply_to_status_id" : 299864407184379904,
  "created_at" : "2013-02-08 14:08:32 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299882145319632898",
  "text" : "OH: \u201CLesbians don\u2019t beat you off!!!\u201D",
  "id" : 299882145319632898,
  "created_at" : "2013-02-08 14:07:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NewRelic",
      "screen_name" : "newrelic",
      "indices" : [ 1, 10 ],
      "id_str" : "15527007",
      "id" : 15527007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/USXAfTLM",
      "expanded_url" : "http:\/\/bit.ly\/11RL7xI",
      "display_url" : "bit.ly\/11RL7xI"
    } ]
  },
  "geo" : { },
  "id_str" : "299644247739600896",
  "text" : "\u201C@newrelic: Why New Relic Is Raising $80 Million Now http:\/\/t.co\/USXAfTLM\u201D - Brilliant news for a brilliant product. Use it for my own stuff",
  "id" : 299644247739600896,
  "created_at" : "2013-02-07 22:22:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299587759092408320",
  "geo" : { },
  "id_str" : "299643479619952641",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson it is a good purchase I think. You about tomorrow - I have news for you and Pete! :D",
  "id" : 299643479619952641,
  "in_reply_to_status_id" : 299587759092408320,
  "created_at" : "2013-02-07 22:19:07 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "indices" : [ 3, 19 ],
      "id_str" : "402824193",
      "id" : 402824193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/WsFZYaZ1",
      "expanded_url" : "http:\/\/bit.ly\/WRbXHo",
      "display_url" : "bit.ly\/WRbXHo"
    }, {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/k3FWPe74",
      "expanded_url" : "http:\/\/bit.ly\/123tFGH",
      "display_url" : "bit.ly\/123tFGH"
    } ]
  },
  "geo" : { },
  "id_str" : "299643095157469186",
  "text" : "RT @NodeJsCommunity: Why Walmart is using Node.js #nodejs  http:\/\/t.co\/WsFZYaZ1 http:\/\/t.co\/k3FWPe74",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodejs",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/WsFZYaZ1",
        "expanded_url" : "http:\/\/bit.ly\/WRbXHo",
        "display_url" : "bit.ly\/WRbXHo"
      }, {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/k3FWPe74",
        "expanded_url" : "http:\/\/bit.ly\/123tFGH",
        "display_url" : "bit.ly\/123tFGH"
      } ]
    },
    "geo" : { },
    "id_str" : "299636239634677760",
    "text" : "Why Walmart is using Node.js #nodejs  http:\/\/t.co\/WsFZYaZ1 http:\/\/t.co\/k3FWPe74",
    "id" : 299636239634677760,
    "created_at" : "2013-02-07 21:50:21 +0000",
    "user" : {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "protected" : false,
      "id_str" : "402824193",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1627924583\/njscomm_normal.jpg",
      "id" : 402824193,
      "verified" : false
    }
  },
  "id" : 299643095157469186,
  "created_at" : "2013-02-07 22:17:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bt29",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299638504382668800",
  "text" : "Just back from Belfast - if you are coming over Hannastown be careful - black ice. #bt29",
  "id" : 299638504382668800,
  "created_at" : "2013-02-07 21:59:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299565026442878976",
  "geo" : { },
  "id_str" : "299565628753317890",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel you tweeting me from the bog you dirty bastard? :)",
  "id" : 299565628753317890,
  "in_reply_to_status_id" : 299565026442878976,
  "created_at" : "2013-02-07 17:09:46 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 16, 24 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299562709450633216",
  "text" : "I tip my hat to @jbrevel and his stalking skills :)",
  "id" : 299562709450633216,
  "created_at" : "2013-02-07 16:58:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/299560581445332992\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/lBLySGHW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BChAwv6CMAAL_CV.jpg",
      "id_str" : "299560581457915904",
      "id" : 299560581457915904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BChAwv6CMAAL_CV.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/lBLySGHW"
    } ],
    "hashtags" : [ {
      "text" : "bitch",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299560581445332992",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett we have your sauce bottle - we found it and are using and there is fuck all you can do about it! #bitch http:\/\/t.co\/lBLySGHW",
  "id" : 299560581445332992,
  "created_at" : "2013-02-07 16:49:43 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 27, 35 ],
      "id_str" : "17230018",
      "id" : 17230018
    }, {
      "name" : "iTunes Music",
      "screen_name" : "iTunesMusic",
      "indices" : [ 84, 96 ],
      "id_str" : "74580436",
      "id" : 74580436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299549328664576001",
  "text" : "I've given in and just got @Spotify premium account... Seems to be much better than @iTunesMusic",
  "id" : 299549328664576001,
  "created_at" : "2013-02-07 16:04:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loonix101fail",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299544918945308674",
  "text" : "Nothing makes you feel quite as thick as when you this warning:\n\ngandalf ~ $ screen -x 21\nAttaching from inside of screen?\n\n#loonix101fail",
  "id" : 299544918945308674,
  "created_at" : "2013-02-07 15:47:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299517905014505472",
  "geo" : { },
  "id_str" : "299518325355053056",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne I like them though. Miss your wee twitterness I do!!",
  "id" : 299518325355053056,
  "in_reply_to_status_id" : 299517905014505472,
  "created_at" : "2013-02-07 14:01:48 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flawinmyplan",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299517416793309184",
  "text" : "OH: \"I love that when there is a cock drawn on a post-it that I get the blame!!!\". \"Well in my defence it is signed 'Stevie'\". #flawinmyplan",
  "id" : 299517416793309184,
  "created_at" : "2013-02-07 13:58:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 0, 9 ],
      "id_str" : "9488072",
      "id" : 9488072
    }, {
      "name" : "Rumble Labs",
      "screen_name" : "rumblelabs",
      "indices" : [ 23, 34 ],
      "id_str" : "20454184",
      "id" : 20454184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299505901293948929",
  "in_reply_to_user_id" : 9488072,
  "text" : "@shylands love the new @rumblelabs site :)",
  "id" : 299505901293948929,
  "created_at" : "2013-02-07 13:12:26 +0000",
  "in_reply_to_screen_name" : "shylands",
  "in_reply_to_user_id_str" : "9488072",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 65, 75 ]
    }, {
      "text" : "nocoffeenocaffeine",
      "indices" : [ 76, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299485826549690369",
  "text" : "I just put some gourmet coffee on the pot \u2026 The grade \u2018A\u2019 shit - #justsayin #nocoffeenocaffeine",
  "id" : 299485826549690369,
  "created_at" : "2013-02-07 11:52:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 3, 16 ],
      "id_str" : "162449244",
      "id" : 162449244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299485538744926208",
  "text" : "RT @justinMleary: ex Police Sergeant I've been with the RepKnight team for one month. Loving life after public service, working with a g ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RepKnight",
        "screen_name" : "RepKnight",
        "indices" : [ 129, 139 ],
        "id_str" : "240194412",
        "id" : 240194412
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299484421583691777",
    "text" : "ex Police Sergeant I've been with the RepKnight team for one month. Loving life after public service, working with a great team. @RepKnight",
    "id" : 299484421583691777,
    "created_at" : "2013-02-07 11:47:04 +0000",
    "user" : {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "protected" : false,
      "id_str" : "162449244",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3067943105\/193e650a1585564fabb5fd9982852d33_normal.jpeg",
      "id" : 162449244,
      "verified" : false
    }
  },
  "id" : 299485538744926208,
  "created_at" : "2013-02-07 11:51:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299465547219865600",
  "text" : "Forgetting your laptop a mere 1 mile away from work is probably akin to a kick in the stones.. Not that I would know... nope - not moi!",
  "id" : 299465547219865600,
  "created_at" : "2013-02-07 10:32:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Phillips",
      "screen_name" : "lisaphillips",
      "indices" : [ 3, 16 ],
      "id_str" : "733383",
      "id" : 733383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 120 ],
      "url" : "https:\/\/t.co\/TFUJXtjQ",
      "expanded_url" : "https:\/\/github.com\/twitter\/mysql\/wiki\/Change-History#wiki-5.5.29.t10",
      "display_url" : "github.com\/twitter\/mysql\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299289325546377216",
  "text" : "RT @lisaphillips: New feature from Twitter's MySQL: Expose Operations Counters per Table. Yee Haw! https:\/\/t.co\/TFUJXtjQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 102 ],
        "url" : "https:\/\/t.co\/TFUJXtjQ",
        "expanded_url" : "https:\/\/github.com\/twitter\/mysql\/wiki\/Change-History#wiki-5.5.29.t10",
        "display_url" : "github.com\/twitter\/mysql\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299250569325981697",
    "text" : "New feature from Twitter's MySQL: Expose Operations Counters per Table. Yee Haw! https:\/\/t.co\/TFUJXtjQ",
    "id" : 299250569325981697,
    "created_at" : "2013-02-06 20:17:50 +0000",
    "user" : {
      "name" : "Lisa Phillips",
      "screen_name" : "lisaphillips",
      "protected" : false,
      "id_str" : "733383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000008510132\/5fff65395076b6dc6149c1f31961b9fa_normal.jpeg",
      "id" : 733383,
      "verified" : false
    }
  },
  "id" : 299289325546377216,
  "created_at" : "2013-02-06 22:51:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 9, 22 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 23, 30 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299258582023680001",
  "geo" : { },
  "id_str" : "299258977806585857",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @nicholabates @rejoco that's all my jokes done on that subject :) I've kinda freaked myself out.. That aint easily done either.",
  "id" : 299258977806585857,
  "in_reply_to_status_id" : 299258582023680001,
  "created_at" : "2013-02-06 20:51:14 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 14, 21 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 22, 30 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299258496262733824",
  "geo" : { },
  "id_str" : "299258629176037376",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates @rejoco @jbrevel I\u2019m done\u2026 :)",
  "id" : 299258629176037376,
  "in_reply_to_status_id" : 299258496262733824,
  "created_at" : "2013-02-06 20:49:51 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 14, 21 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 22, 30 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hedoesntreallyloveme",
      "indices" : [ 99, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/atkjUvZW",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1etAWDQZBsM",
      "display_url" : "youtube.com\/watch?v=1etAWD\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "299256219493875712",
  "geo" : { },
  "id_str" : "299257307785748480",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates @rejoco @jbrevel Locko will be fine - this happened last time - http:\/\/t.co\/atkjUvZW #hedoesntreallyloveme",
  "id" : 299257307785748480,
  "in_reply_to_status_id" : 299256219493875712,
  "created_at" : "2013-02-06 20:44:36 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "comeonyouknowiwasgoingtodoitatsomestage",
      "indices" : [ 83, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299252614317617152",
  "text" : "Yup - it has happened. I just set my jumper alight while putting a log on my fire. #comeonyouknowiwasgoingtodoitatsomestage",
  "id" : 299252614317617152,
  "created_at" : "2013-02-06 20:25:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Beeman",
      "screen_name" : "hadleybeeman",
      "indices" : [ 3, 16 ],
      "id_str" : "17053097",
      "id" : 17053097
    }, {
      "name" : "Francine Bennett",
      "screen_name" : "fhr",
      "indices" : [ 19, 23 ],
      "id_str" : "15197091",
      "id" : 15197091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299195678268198912",
  "text" : "RT @hadleybeeman: .@fhr's slides on Big Data in the NHS: summary of analytics on prescribing data. Plus an XKCD cartoon. :) http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Francine Bennett",
        "screen_name" : "fhr",
        "indices" : [ 1, 5 ],
        "id_str" : "15197091",
        "id" : 15197091
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/9txEY80c",
        "expanded_url" : "http:\/\/bit.ly\/VwUVjy",
        "display_url" : "bit.ly\/VwUVjy"
      } ]
    },
    "geo" : { },
    "id_str" : "296866040883851264",
    "text" : ".@fhr's slides on Big Data in the NHS: summary of analytics on prescribing data. Plus an XKCD cartoon. :) http:\/\/t.co\/9txEY80c #opendata",
    "id" : 296866040883851264,
    "created_at" : "2013-01-31 06:22:34 +0000",
    "user" : {
      "name" : "Hadley Beeman",
      "screen_name" : "hadleybeeman",
      "protected" : false,
      "id_str" : "17053097",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1689768600\/IMG_2849d_headshot_786x786_normal.jpg",
      "id" : 17053097,
      "verified" : false
    }
  },
  "id" : 299195678268198912,
  "created_at" : "2013-02-06 16:39:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 58, 72 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299195271261347841",
  "text" : "I\u2019m downing tools soon\u2026 Does mean that I have to stand up @jenporterhall though\u2026 She\u2019ll get over it ;)",
  "id" : 299195271261347841,
  "created_at" : "2013-02-06 16:38:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keavy",
      "screen_name" : "keavy",
      "indices" : [ 0, 6 ],
      "id_str" : "8605362",
      "id" : 8605362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299189018590068736",
  "geo" : { },
  "id_str" : "299190638539337728",
  "in_reply_to_user_id" : 8605362,
  "text" : "@keavy and you know, chin up - hope you are feeling better soon.",
  "id" : 299190638539337728,
  "in_reply_to_status_id" : 299189018590068736,
  "created_at" : "2013-02-06 16:19:41 +0000",
  "in_reply_to_screen_name" : "keavy",
  "in_reply_to_user_id_str" : "8605362",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keavy",
      "screen_name" : "keavy",
      "indices" : [ 0, 6 ],
      "id_str" : "8605362",
      "id" : 8605362
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 17, 24 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299189018590068736",
  "geo" : { },
  "id_str" : "299190507354079232",
  "in_reply_to_user_id" : 8605362,
  "text" : "@keavy I thought @github gave you universal health care? Or does that not mean what we take for granted in the UK?",
  "id" : 299190507354079232,
  "in_reply_to_status_id" : 299189018590068736,
  "created_at" : "2013-02-06 16:19:10 +0000",
  "in_reply_to_screen_name" : "keavy",
  "in_reply_to_user_id_str" : "8605362",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 1, 11 ],
      "id_str" : "212603717",
      "id" : 212603717
    }, {
      "name" : "Vagrant",
      "screen_name" : "vagrantup",
      "indices" : [ 83, 93 ],
      "id_str" : "229288992",
      "id" : 229288992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299173698664026112",
  "text" : "\u201C@carisenda: ssh -t host.local sudo lxc-start -d -n dev.local\u201D  Can you do this in @vagrantup ?",
  "id" : 299173698664026112,
  "created_at" : "2013-02-06 15:12:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 14, 22 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299166507013902337",
  "geo" : { },
  "id_str" : "299166615075975168",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates @jbrevel more than welcome :)",
  "id" : 299166615075975168,
  "in_reply_to_status_id" : 299166507013902337,
  "created_at" : "2013-02-06 14:44:13 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 14, 22 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299162824318517248",
  "geo" : { },
  "id_str" : "299163439060877312",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates @jbrevel ack well I have two holes...",
  "id" : 299163439060877312,
  "in_reply_to_status_id" : 299162824318517248,
  "created_at" : "2013-02-06 14:31:36 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 3, 16 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 62, 70 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 71, 77 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitamore",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/S7Nli7Jv",
      "expanded_url" : "http:\/\/twitamore.com\/jbrevel",
      "display_url" : "twitamore.com\/jbrevel"
    } ]
  },
  "geo" : { },
  "id_str" : "299162032815620096",
  "text" : "RT @nicholabates: says it all really ;-) http:\/\/t.co\/S7Nli7Jv\n@jbrevel @swmcc #twitamore",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Loughrey",
        "screen_name" : "jbrevel",
        "indices" : [ 44, 52 ],
        "id_str" : "50685221",
        "id" : 50685221
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 53, 59 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "twitamore",
        "indices" : [ 60, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/S7Nli7Jv",
        "expanded_url" : "http:\/\/twitamore.com\/jbrevel",
        "display_url" : "twitamore.com\/jbrevel"
      } ]
    },
    "geo" : { },
    "id_str" : "299161369821995008",
    "in_reply_to_user_id" : 50685221,
    "text" : "says it all really ;-) http:\/\/t.co\/S7Nli7Jv\n@jbrevel @swmcc #twitamore",
    "id" : 299161369821995008,
    "created_at" : "2013-02-06 14:23:23 +0000",
    "in_reply_to_screen_name" : "jbrevel",
    "in_reply_to_user_id_str" : "50685221",
    "user" : {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "protected" : false,
      "id_str" : "19125494",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2947508512\/c9075236946505819826a2f275f50186_normal.jpeg",
      "id" : 19125494,
      "verified" : false
    }
  },
  "id" : 299162032815620096,
  "created_at" : "2013-02-06 14:26:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299153018899795970",
  "geo" : { },
  "id_str" : "299153524816748544",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight nope no wednesday love - but this afternoon is looking better :) Am just tired and grumpy.",
  "id" : 299153524816748544,
  "in_reply_to_status_id" : 299153018899795970,
  "created_at" : "2013-02-06 13:52:12 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299152943091970050",
  "text" : "OH: \"Here, have a chip\"",
  "id" : 299152943091970050,
  "created_at" : "2013-02-06 13:49:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 107, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299131564162437121",
  "text" : "... FUCK you Wednesday, you can suck my dick. You can\u2019t get me Wednesday, cause you\u2019re just 24 hours long! #FUCKYOUWEDNESDAY",
  "id" : 299131564162437121,
  "created_at" : "2013-02-06 12:24:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299131005900562432",
  "text" : "When you hear the sound of Wednesday, don\u2019t you get too scared. Just grab your Wednesday buddy and say these magic words \u2026",
  "id" : 299131005900562432,
  "created_at" : "2013-02-06 12:22:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 88, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/Uvi0AOf3",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/entertainment-arts-21349152",
      "display_url" : "bbc.co.uk\/news\/entertain\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299130643709829120",
  "text" : "This Wednesday is a \u201CFUCK YOU WEDNESDAY\u201D - and it just got worse - http:\/\/t.co\/Uvi0AOf3 #FUCKYOUWEDNESDAY",
  "id" : 299130643709829120,
  "created_at" : "2013-02-06 12:21:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snowday",
      "indices" : [ 15, 23 ]
    }, {
      "text" : "wfh",
      "indices" : [ 24, 28 ]
    }, {
      "text" : "dontlikewfhthismuch",
      "indices" : [ 29, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/7ROIufeO",
      "expanded_url" : "http:\/\/instagr.am\/p\/VWGpR8hX-Q\/",
      "display_url" : "instagr.am\/p\/VWGpR8hX-Q\/"
    } ]
  },
  "geo" : { },
  "id_str" : "298735164803137536",
  "text" : "Current status #snowday #wfh #dontlikewfhthismuch http:\/\/t.co\/7ROIufeO",
  "id" : 298735164803137536,
  "created_at" : "2013-02-05 10:09:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298557805311430656",
  "text" : "He serviced her at Xmas but as this was MOT time he had to drive her to check a few things. My car is class, an aquired taste.",
  "id" : 298557805311430656,
  "created_at" : "2013-02-04 22:25:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298557452763402240",
  "text" : "When your mechanic says to you \u201CHow the fuck did you drive that thing?\u201D You know you\u2019ve left it too long between mechanic visits.",
  "id" : 298557452763402240,
  "created_at" : "2013-02-04 22:23:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "praiseallah",
      "indices" : [ 85, 97 ]
    }, {
      "text" : "crosseshimself",
      "indices" : [ 98, 113 ]
    }, {
      "text" : "killsagoat",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298557140736557057",
  "text" : "Car back 250 UK pands init! Hopefully she\u2019ll pass but won\u2019t know until next Tuesday. #praiseallah #crosseshimself #killsagoat",
  "id" : 298557140736557057,
  "created_at" : "2013-02-04 22:22:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298523150436671488",
  "geo" : { },
  "id_str" : "298555184508981250",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull too cute.",
  "id" : 298555184508981250,
  "in_reply_to_status_id" : 298523150436671488,
  "created_at" : "2013-02-04 22:14:37 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Halstead",
      "screen_name" : "nik",
      "indices" : [ 3, 7 ],
      "id_str" : "3364401",
      "id" : 3364401
    }, {
      "name" : "Brandon Doyle",
      "screen_name" : "mar",
      "indices" : [ 132, 136 ],
      "id_str" : "878482506",
      "id" : 878482506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/GTeYY6E6",
      "expanded_url" : "http:\/\/marketingland.com\/game-over-twitter-mentioned-in-50-of-super-bowl-commercials-facebook-only-8-google-shut-out-32420",
      "display_url" : "marketingland.com\/game-over-twit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298535933718962176",
  "text" : "RT @nik: Game Over: Twitter Mentioned In 50% Of Super Bowl Commercials, Facebook Only 8%, Google+ Shut Out http:\/\/t.co\/GTeYY6E6 via @mar ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marketing Land",
        "screen_name" : "Marketingland",
        "indices" : [ 123, 137 ],
        "id_str" : "12553672",
        "id" : 12553672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/GTeYY6E6",
        "expanded_url" : "http:\/\/marketingland.com\/game-over-twitter-mentioned-in-50-of-super-bowl-commercials-facebook-only-8-google-shut-out-32420",
        "display_url" : "marketingland.com\/game-over-twit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "298535192782577665",
    "text" : "Game Over: Twitter Mentioned In 50% Of Super Bowl Commercials, Facebook Only 8%, Google+ Shut Out http:\/\/t.co\/GTeYY6E6 via @marketingland",
    "id" : 298535192782577665,
    "created_at" : "2013-02-04 20:55:11 +0000",
    "user" : {
      "name" : "Nick Halstead",
      "screen_name" : "nik",
      "protected" : false,
      "id_str" : "3364401",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1823229022\/nick2png_normal.png",
      "id" : 3364401,
      "verified" : false
    }
  },
  "id" : 298535933718962176,
  "created_at" : "2013-02-04 20:58:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 3, 11 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298535328812240896",
  "text" : "RT @kouphax: \"Neo4j and Spray JSON\" giving what I've been doing recently I almost feel like Im blogging in my sleep under a pen name htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/2hBaUotZ",
        "expanded_url" : "http:\/\/feedly.com\/k\/14N6CnQ",
        "display_url" : "feedly.com\/k\/14N6CnQ"
      } ]
    },
    "geo" : { },
    "id_str" : "298526394139410432",
    "text" : "\"Neo4j and Spray JSON\" giving what I've been doing recently I almost feel like Im blogging in my sleep under a pen name http:\/\/t.co\/2hBaUotZ",
    "id" : 298526394139410432,
    "created_at" : "2013-02-04 20:20:13 +0000",
    "user" : {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "protected" : false,
      "id_str" : "120378343",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2961063596\/1fc369524d06311a3252f1897db67de8_normal.png",
      "id" : 120378343,
      "verified" : false
    }
  },
  "id" : 298535328812240896,
  "created_at" : "2013-02-04 20:55:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "indices" : [ 3, 12 ],
      "id_str" : "14278978",
      "id" : 14278978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298161914326966272",
  "text" : "RT @ericries: OK once you accept that Kevin Spacey simply can't do Ian Richardson, the new House of Cards gets better.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298129791721295872",
    "text" : "OK once you accept that Kevin Spacey simply can't do Ian Richardson, the new House of Cards gets better.",
    "id" : 298129791721295872,
    "created_at" : "2013-02-03 18:04:15 +0000",
    "user" : {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "protected" : false,
      "id_str" : "14278978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769304611\/image1327092761_normal.png",
      "id" : 14278978,
      "verified" : true
    }
  },
  "id" : 298161914326966272,
  "created_at" : "2013-02-03 20:11:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297991120888139776",
  "text" : "Recording this hangover for future reference\u2026. Fucking hell!!!!!",
  "id" : 297991120888139776,
  "created_at" : "2013-02-03 08:53:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/297728531096551424\/photo\/1",
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/FUwZ5kLW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCG-hYhCQAAtUKY.jpg",
      "id_str" : "297728531109134336",
      "id" : 297728531109134336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCG-hYhCQAAtUKY.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/FUwZ5kLW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297728531096551424",
  "text" : "Me and Mrs Moffett :) http:\/\/t.co\/FUwZ5kLW",
  "id" : 297728531096551424,
  "created_at" : "2013-02-02 15:29:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 3, 10 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 12, 18 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297664540898914304",
  "text" : "RT @rejoco: @swmcc bitch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "297621291178016769",
    "geo" : { },
    "id_str" : "297646850440327169",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc bitch",
    "id" : 297646850440327169,
    "in_reply_to_status_id" : 297621291178016769,
    "created_at" : "2013-02-02 10:05:13 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "protected" : false,
      "id_str" : "53053999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167317834\/6219cabb0a7785ac8acd656a39be2ab9_normal.jpeg",
      "id" : 53053999,
      "verified" : false
    }
  },
  "id" : 297664540898914304,
  "created_at" : "2013-02-02 11:15:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 14, 21 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 69, 80 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/nEjU2uKG",
      "expanded_url" : "http:\/\/4sq.com\/ZIqa7r",
      "display_url" : "4sq.com\/ZIqa7r"
    } ]
  },
  "geo" : { },
  "id_str" : "297621291178016769",
  "text" : "I just ousted @rejoco as the mayor of Locko's Red Room Of Passion on @foursquare! http:\/\/t.co\/nEjU2uKG",
  "id" : 297621291178016769,
  "created_at" : "2013-02-02 08:23:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wedding",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/1716IcZt",
      "expanded_url" : "http:\/\/instagr.am\/p\/VOMN2shX0e\/",
      "display_url" : "instagr.am\/p\/VOMN2shX0e\/"
    } ]
  },
  "geo" : { },
  "id_str" : "297621013590573056",
  "text" : "Current Status #wedding http:\/\/t.co\/1716IcZt",
  "id" : 297621013590573056,
  "created_at" : "2013-02-02 08:22:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 6, 19 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297484193846419456",
  "text" : "Right @Paul_Moffett has been fed... Now to put him to bed - he has a big day tomorrow....",
  "id" : 297484193846419456,
  "created_at" : "2013-02-01 23:18:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297414759396020224",
  "geo" : { },
  "id_str" : "297483935141748737",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues its not too bad to be fair. Good link :)",
  "id" : 297483935141748737,
  "in_reply_to_status_id" : 297414759396020224,
  "created_at" : "2013-02-01 23:17:51 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297469666056630273",
  "geo" : { },
  "id_str" : "297483451999846400",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall Cheers big ears!!! I will try my best :)",
  "id" : 297483451999846400,
  "in_reply_to_status_id" : 297469666056630273,
  "created_at" : "2013-02-01 23:15:56 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297341944135311360",
  "geo" : { },
  "id_str" : "297342384327491586",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit very good to know :)",
  "id" : 297342384327491586,
  "in_reply_to_status_id" : 297341944135311360,
  "created_at" : "2013-02-01 13:55:23 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetbot by Tapbots",
      "screen_name" : "tweetbot",
      "indices" : [ 7, 16 ],
      "id_str" : "274626857",
      "id" : 274626857
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 49, 56 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297341650571763714",
  "text" : "Giving @tweetbot a go\u2026. On the recommendation of @rejoco at \u00A313.99 it better be good ;)",
  "id" : 297341650571763714,
  "created_at" : "2013-02-01 13:52:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 8, 17 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 22, 35 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297336635442470912",
  "text" : "Oh yeah @davehedo got @Paul_Moffett pin number\u2026 So \"I fucked your mother\" will be on at around 11:30 ;) :D",
  "id" : 297336635442470912,
  "created_at" : "2013-02-01 13:32:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InfoQ",
      "screen_name" : "InfoQ",
      "indices" : [ 3, 9 ],
      "id_str" : "14073560",
      "id" : 14073560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/14ctqRN1",
      "expanded_url" : "http:\/\/bit.ly\/11rP5Nr",
      "display_url" : "bit.ly\/11rP5Nr"
    } ]
  },
  "geo" : { },
  "id_str" : "297332788280037376",
  "text" : "RT @InfoQ: Interview: Emil Eifrem on NoSQL, Graph Databases, and Neo4j http:\/\/t.co\/14ctqRN1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/14ctqRN1",
        "expanded_url" : "http:\/\/bit.ly\/11rP5Nr",
        "display_url" : "bit.ly\/11rP5Nr"
      } ]
    },
    "geo" : { },
    "id_str" : "297322475082113024",
    "text" : "Interview: Emil Eifrem on NoSQL, Graph Databases, and Neo4j http:\/\/t.co\/14ctqRN1",
    "id" : 297322475082113024,
    "created_at" : "2013-02-01 12:36:16 +0000",
    "user" : {
      "name" : "InfoQ",
      "screen_name" : "InfoQ",
      "protected" : false,
      "id_str" : "14073560",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/132099256\/infoq-square_normal.jpg",
      "id" : 14073560,
      "verified" : false
    }
  },
  "id" : 297332788280037376,
  "created_at" : "2013-02-01 13:17:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodtoknow",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297308482724577280",
  "geo" : { },
  "id_str" : "297331921380335616",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit they offer free wifi do they? #goodtoknow",
  "id" : 297331921380335616,
  "in_reply_to_status_id" : 297308482724577280,
  "created_at" : "2013-02-01 13:13:48 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Fry",
      "screen_name" : "stephenfry",
      "indices" : [ 3, 14 ],
      "id_str" : "15439395",
      "id" : 15439395
    }, {
      "name" : "Stonewall",
      "screen_name" : "stonewalluk",
      "indices" : [ 120, 132 ],
      "id_str" : "19651284",
      "id" : 19651284
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "equalmarriage",
      "indices" : [ 27, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297331036642222080",
  "text" : "RT @stephenfry: MPs debate #equalmarriage on Tuesday. Please tweet yours today to ask for a yes vote - useful info from @StonewallUK at  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stonewall",
        "screen_name" : "stonewalluk",
        "indices" : [ 104, 116 ],
        "id_str" : "19651284",
        "id" : 19651284
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "equalmarriage",
        "indices" : [ 11, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/yA2aypq9",
        "expanded_url" : "http:\/\/www.stonewall.org.uk\/contactyourmp",
        "display_url" : "stonewall.org.uk\/contactyourmp"
      } ]
    },
    "geo" : { },
    "id_str" : "297304940337037312",
    "text" : "MPs debate #equalmarriage on Tuesday. Please tweet yours today to ask for a yes vote - useful info from @StonewallUK at http:\/\/t.co\/yA2aypq9",
    "id" : 297304940337037312,
    "created_at" : "2013-02-01 11:26:36 +0000",
    "user" : {
      "name" : "Stephen Fry",
      "screen_name" : "stephenfry",
      "protected" : false,
      "id_str" : "15439395",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/344513261579148157\/ba4807791ef9cce28dc0d4aa2ce9372c_normal.jpeg",
      "id" : 15439395,
      "verified" : true
    }
  },
  "id" : 297331036642222080,
  "created_at" : "2013-02-01 13:10:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 17, 30 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hereishoping",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297326350543486976",
  "geo" : { },
  "id_str" : "297330910955728896",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @paul_moffett she's going away this weekend to get fixed for MOT\u2026 #hereishoping",
  "id" : 297330910955728896,
  "in_reply_to_status_id" : 297326350543486976,
  "created_at" : "2013-02-01 13:09:47 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297316016961236992",
  "geo" : { },
  "id_str" : "297326122981543936",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett her yearly MOT wash too and they fucked up doing the roof!",
  "id" : 297326122981543936,
  "in_reply_to_status_id" : 297316016961236992,
  "created_at" : "2013-02-01 12:50:46 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]