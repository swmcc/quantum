Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anssi Johansson",
      "screen_name" : "avij",
      "indices" : [ 0, 5 ],
      "id_str" : "19453209",
      "id" : 19453209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230379891269451776",
  "geo" : { },
  "id_str" : "230380546436513792",
  "in_reply_to_user_id" : 19453209,
  "text" : "@avij thanks :)",
  "id" : 230380546436513792,
  "in_reply_to_status_id" : 230379891269451776,
  "created_at" : "2012-07-31 19:12:57 +0000",
  "in_reply_to_screen_name" : "avij",
  "in_reply_to_user_id_str" : "19453209",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230378762846470144",
  "text" : "I fucking hate centos - \"Your server is running PHP version 5.1.6 but WordPress 3.4.1 requires at least 5.2.4.\"",
  "id" : 230378762846470144,
  "created_at" : "2012-07-31 19:05:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Tracy Adams",
      "screen_name" : "tracy2710",
      "indices" : [ 30, 40 ],
      "id_str" : "241879307",
      "id" : 241879307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230362417815777281",
  "geo" : { },
  "id_str" : "230364418599448577",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @michaelnsimpson @tracy2710 I am making gorilla noises right now ;)",
  "id" : 230364418599448577,
  "in_reply_to_status_id" : 230362417815777281,
  "created_at" : "2012-07-31 18:08:52 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230331172826271744",
  "text" : "Right I've put this off longenough... I need to go to Sainsburys or Tesco but I cannot be fucked....",
  "id" : 230331172826271744,
  "created_at" : "2012-07-31 15:56:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230327417472958464",
  "text" : "Calling out a local IT company is not something I usually would do... But you know... fuck it.",
  "id" : 230327417472958464,
  "created_at" : "2012-07-31 15:41:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230325903908016128",
  "geo" : { },
  "id_str" : "230326642009059328",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard I have respect for Rehab. I don't have any for Consilium.",
  "id" : 230326642009059328,
  "in_reply_to_status_id" : 230325903908016128,
  "created_at" : "2012-07-31 15:38:45 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/pO1Y18Rt",
      "expanded_url" : "http:\/\/syncni.com\/news\/6913",
      "display_url" : "syncni.com\/news\/6913"
    } ]
  },
  "geo" : { },
  "id_str" : "230325638437941250",
  "text" : "FUCK. RIGHT. OFF. http:\/\/t.co\/pO1Y18Rt I've worked \/with\/ these people.. I will NEVER work for them cos they are idiots! Simple!",
  "id" : 230325638437941250,
  "created_at" : "2012-07-31 15:34:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 3, 11 ],
      "id_str" : "79820731",
      "id" : 79820731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/LvH2Zljx",
      "expanded_url" : "http:\/\/www.tascomi.com\/aboutus\/jobs",
      "display_url" : "tascomi.com\/aboutus\/jobs"
    } ]
  },
  "geo" : { },
  "id_str" : "230297437129023489",
  "text" : "RT @tascomi: IMMEDIATE job vacancies for a Project Manager and a Grad Software Developer. Please see http:\/\/t.co\/LvH2Zljx for details",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/LvH2Zljx",
        "expanded_url" : "http:\/\/www.tascomi.com\/aboutus\/jobs",
        "display_url" : "tascomi.com\/aboutus\/jobs"
      } ]
    },
    "geo" : { },
    "id_str" : "230289642438656000",
    "text" : "IMMEDIATE job vacancies for a Project Manager and a Grad Software Developer. Please see http:\/\/t.co\/LvH2Zljx for details",
    "id" : 230289642438656000,
    "created_at" : "2012-07-31 13:11:43 +0000",
    "user" : {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "protected" : false,
      "id_str" : "79820731",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1736918497\/tascomi_twitter_t_normal.jpg",
      "id" : 79820731,
      "verified" : false
    }
  },
  "id" : 230297437129023489,
  "created_at" : "2012-07-31 13:42:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230247880802328577",
  "geo" : { },
  "id_str" : "230248480264818690",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit aye - that line made me boil... I've said it many times.. If you haven't moved to CC by now - you deserve to go bust. GRRR!!",
  "id" : 230248480264818690,
  "in_reply_to_status_id" : 230247880802328577,
  "created_at" : "2012-07-31 10:28:10 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/1aXFP7uD",
      "expanded_url" : "http:\/\/syncni.com\/news\/6910",
      "display_url" : "syncni.com\/news\/6910"
    } ]
  },
  "geo" : { },
  "id_str" : "230247110589681666",
  "text" : "\/me bangs head against the wall.. http:\/\/t.co\/1aXFP7uD",
  "id" : 230247110589681666,
  "created_at" : "2012-07-31 10:22:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lough Shore",
      "screen_name" : "loughshore",
      "indices" : [ 44, 55 ],
      "id_str" : "215992556",
      "id" : 215992556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/dsGu065k",
      "expanded_url" : "http:\/\/blog.loughshore.co\/post\/2909506162\/lough-shore-investments-the-new-approach-to-building",
      "display_url" : "blog.loughshore.co\/post\/290950616\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "230243227129745408",
  "text" : "Really good read - http:\/\/t.co\/dsGu065k \/cc @loughshore",
  "id" : 230243227129745408,
  "created_at" : "2012-07-31 10:07:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230239319766478848",
  "text" : "RT @HaVoCT5: mother fuckers! \"if anyone needs a lift i can lift them\" !!Nothing!! when stevie says?? \"Yeah Stevie ill take a lift\"...Ung ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230239202732826624",
    "text" : "mother fuckers! \"if anyone needs a lift i can lift them\" !!Nothing!! when stevie says?? \"Yeah Stevie ill take a lift\"...Ungreatful fuckers!",
    "id" : 230239202732826624,
    "created_at" : "2012-07-31 09:51:18 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 230239319766478848,
  "created_at" : "2012-07-31 09:51:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 13, 25 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 26, 40 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "couldnotletitpass",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230042237998858241",
  "geo" : { },
  "id_str" : "230047464697249794",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @Kirstylvssp @peter_omalley I'd say the new low will come when Pete knocks the living fuck out of me. #couldnotletitpass",
  "id" : 230047464697249794,
  "in_reply_to_status_id" : 230042237998858241,
  "created_at" : "2012-07-30 21:09:24 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230036392087007232",
  "text" : "9:20pm - freedom......",
  "id" : 230036392087007232,
  "created_at" : "2012-07-30 20:25:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 26, 40 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coudntlivewithmyselfifiletthispass",
      "indices" : [ 62, 97 ]
    }, {
      "text" : "peterwillkillmequicklyihope",
      "indices" : [ 98, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/IRVxcasf",
      "expanded_url" : "http:\/\/imgur.com\/3VTCM",
      "display_url" : "imgur.com\/3VTCM"
    } ]
  },
  "in_reply_to_status_id_str" : "230018791831121920",
  "geo" : { },
  "id_str" : "230019419437408256",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @niall_adams @peter_omalley http:\/\/t.co\/IRVxcasf #coudntlivewithmyselfifiletthispass #peterwillkillmequicklyihope",
  "id" : 230019419437408256,
  "in_reply_to_status_id" : 230018791831121920,
  "created_at" : "2012-07-30 19:17:57 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 26, 40 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230018081479602176",
  "geo" : { },
  "id_str" : "230018248815550464",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @niall_adams @peter_omalley MUST. RESIST. JOKE... MUST.... RESIST... JOKE... MUST... RESIST... MUST... RESIST...",
  "id" : 230018248815550464,
  "in_reply_to_status_id" : 230018081479602176,
  "created_at" : "2012-07-30 19:13:18 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SugarCRM",
      "screen_name" : "sugarcrm",
      "indices" : [ 13, 22 ],
      "id_str" : "2630841",
      "id" : 2630841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230017511314292736",
  "text" : "Just noticed @sugarcrm on this talk.. Ironic.. Unless their API has gotten friendly since 2008... ;)",
  "id" : 230017511314292736,
  "created_at" : "2012-07-30 19:10:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230016410523402240",
  "geo" : { },
  "id_str" : "230016698621767680",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard last talk was good. This fella sounds like his balls haven't dropped and he's still a virgin. Talking about \"q-values\"",
  "id" : 230016698621767680,
  "in_reply_to_status_id" : 230016410523402240,
  "created_at" : "2012-07-30 19:07:09 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230015472228241408",
  "geo" : { },
  "id_str" : "230015892136804352",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll google it dude :) Its just been released. Am on HSX waiting for that bad boy to float :D",
  "id" : 230015892136804352,
  "in_reply_to_status_id" : 230015472228241408,
  "created_at" : "2012-07-30 19:03:56 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230015091863605248",
  "geo" : { },
  "id_str" : "230015651106926593",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard the gaps.. Am sure there are more up to date info on google now. I am listening to RESTFUL API's FOR THE REST OF US...",
  "id" : 230015651106926593,
  "in_reply_to_status_id" : 230015091863605248,
  "created_at" : "2012-07-30 19:02:59 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230015091863605248",
  "geo" : { },
  "id_str" : "230015332184641537",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard He just confirmed it on a press conference... I am unsure re: this. It isn't that big a story - unless he is filling in",
  "id" : 230015332184641537,
  "in_reply_to_status_id" : 230015091863605248,
  "created_at" : "2012-07-30 19:01:43 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230014753798508544",
  "text" : "Am very happy @michaelnsimpson is back in work tomorrow. I missed him...",
  "id" : 230014753798508544,
  "created_at" : "2012-07-30 18:59:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 25, 39 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230001013342470146",
  "geo" : { },
  "id_str" : "230007073558110208",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams did you and @peter_omalley shower together? And if not, why not? :)",
  "id" : 230007073558110208,
  "in_reply_to_status_id" : 230001013342470146,
  "created_at" : "2012-07-30 18:28:54 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230005735680000001",
  "text" : "How can The Hobbit be three films?",
  "id" : 230005735680000001,
  "created_at" : "2012-07-30 18:23:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229987340309901312",
  "text" : "Currently listening to php|architect's Rest Summit on ClickWebinar",
  "id" : 229987340309901312,
  "created_at" : "2012-07-30 17:10:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 1, 9 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 11, 17 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229968054006738944",
  "text" : "\u201C@HaVoCT5: @swmcc fuck u and firestarter! cant beat some Avril Lavigne!\u201D Luckily I love him :D",
  "id" : 229968054006738944,
  "created_at" : "2012-07-30 15:53:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229963765213442048",
  "text" : "I also love it when someone \"follows\" me and then leaves within a week... Do people think I use this twitter thing properly?!? Do I fuck! :D",
  "id" : 229963765213442048,
  "created_at" : "2012-07-30 15:36:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229963431405555712",
  "text" : "Firestarter just came on the sonos player... FUCKING. BRING. IT.",
  "id" : 229963431405555712,
  "created_at" : "2012-07-30 15:35:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "indices" : [ 0, 10 ],
      "id_str" : "199486205",
      "id" : 199486205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229958526284480512",
  "geo" : { },
  "id_str" : "229958878442442752",
  "in_reply_to_user_id" : 199486205,
  "text" : "@AoifeB155 Yup - the volleyball was on yesterday too :) I'm just as bad as you.. Should tweet it next time though.. In fact, I will :)",
  "id" : 229958878442442752,
  "in_reply_to_status_id" : 229958526284480512,
  "created_at" : "2012-07-30 15:17:23 +0000",
  "in_reply_to_screen_name" : "AoifeB155",
  "in_reply_to_user_id_str" : "199486205",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "indices" : [ 0, 10 ],
      "id_str" : "199486205",
      "id" : 199486205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229957847616737280",
  "geo" : { },
  "id_str" : "229958278568882177",
  "in_reply_to_user_id" : 199486205,
  "text" : "@AoifeB155 I didn't say it was a bad thing - just thought it was funny in between my geek tweets :)",
  "id" : 229958278568882177,
  "in_reply_to_status_id" : 229957847616737280,
  "created_at" : "2012-07-30 15:15:00 +0000",
  "in_reply_to_screen_name" : "AoifeB155",
  "in_reply_to_user_id_str" : "199486205",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "indices" : [ 7, 17 ],
      "id_str" : "199486205",
      "id" : 199486205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229957539599642624",
  "text" : "Seeing @AoifeB155 melt down over the men's swimming is possibly the funniest thing I've seen on twitter in a long time :)",
  "id" : 229957539599642624,
  "created_at" : "2012-07-30 15:12:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229930044766699520",
  "text" : "OH: \"and i don't underestimate how much of a cock you can be :D\"",
  "id" : 229930044766699520,
  "created_at" : "2012-07-30 13:22:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229680725820055552",
  "text" : "Looking at the work diary and seeing your on support tomorrow... Fucker of fucks :D",
  "id" : 229680725820055552,
  "created_at" : "2012-07-29 20:52:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229663107637735424",
  "geo" : { },
  "id_str" : "229673672061878272",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I can't be bothered erecting it though... Will do it mid week. Am in late tomorrow for a webinar - geekout :)",
  "id" : 229673672061878272,
  "in_reply_to_status_id" : 229663107637735424,
  "created_at" : "2012-07-29 20:24:05 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229641137596547072",
  "geo" : { },
  "id_str" : "229653223529672704",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley A chair, a new display cabinet, two mirrors, two lamps and a bed for the spare room!",
  "id" : 229653223529672704,
  "in_reply_to_status_id" : 229641137596547072,
  "created_at" : "2012-07-29 19:02:49 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 3, 10 ],
      "id_str" : "285766850",
      "id" : 285766850
    }, {
      "name" : "Z\u0322\u0337\u0334\u0360\u0336",
      "screen_name" : "izs",
      "indices" : [ 53, 57 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "Mikeal",
      "screen_name" : "mikeal",
      "indices" : [ 58, 65 ],
      "id_str" : "668423",
      "id" : 668423
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 70, 82 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodeup",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/BfCbOeyn",
      "expanded_url" : "http:\/\/youtu.be\/1G7Eh1AS9fM",
      "display_url" : "youtu.be\/1G7Eh1AS9fM"
    } ]
  },
  "geo" : { },
  "id_str" : "229652001766662147",
  "text" : "RT @NodeUp: NodeUp will be live at noon pacific with @izs @mikeal and @dominictarr. Listen here http:\/\/t.co\/BfCbOeyn and join us in #nodeup.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "isaacs",
        "screen_name" : "izs",
        "indices" : [ 41, 45 ],
        "id_str" : "8038312",
        "id" : 8038312
      }, {
        "name" : "Mikeal",
        "screen_name" : "mikeal",
        "indices" : [ 46, 53 ],
        "id_str" : "668423",
        "id" : 668423
      }, {
        "name" : "Dominic Tarr",
        "screen_name" : "dominictarr",
        "indices" : [ 58, 70 ],
        "id_str" : "136933779",
        "id" : 136933779
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodeup",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/BfCbOeyn",
        "expanded_url" : "http:\/\/youtu.be\/1G7Eh1AS9fM",
        "display_url" : "youtu.be\/1G7Eh1AS9fM"
      } ]
    },
    "geo" : { },
    "id_str" : "229650280621412352",
    "text" : "NodeUp will be live at noon pacific with @izs @mikeal and @dominictarr. Listen here http:\/\/t.co\/BfCbOeyn and join us in #nodeup.",
    "id" : 229650280621412352,
    "created_at" : "2012-07-29 18:51:08 +0000",
    "user" : {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "protected" : false,
      "id_str" : "285766850",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1675860861\/logo2_normal.jpg",
      "id" : 285766850,
      "verified" : false
    }
  },
  "id" : 229652001766662147,
  "created_at" : "2012-07-29 18:57:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229634858660528129",
  "text" : "Ikea.... Now to build....",
  "id" : 229634858660528129,
  "created_at" : "2012-07-29 17:49:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229509087178665984",
  "text" : "Romney is in Israel today... \/me gets the popcorn",
  "id" : 229509087178665984,
  "created_at" : "2012-07-29 09:30:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229489277623492608",
  "geo" : { },
  "id_str" : "229505018536005633",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson Was a good night. However lost points for comparing Rocky to The Warrior and going on about his oesophagus.",
  "id" : 229505018536005633,
  "in_reply_to_status_id" : 229489277623492608,
  "created_at" : "2012-07-29 09:13:55 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 16, 32 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 33, 47 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229305292821766144",
  "geo" : { },
  "id_str" : "229305528717819907",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @michaelnsimpson @peter_omalley you should be here!!!",
  "id" : 229305528717819907,
  "in_reply_to_status_id" : 229305292821766144,
  "created_at" : "2012-07-28 20:01:12 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 16, 32 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 33, 47 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229301922253922305",
  "geo" : { },
  "id_str" : "229304139207806976",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @michaelnsimpson @peter_omalley this is epic",
  "id" : 229304139207806976,
  "in_reply_to_status_id" : 229301922253922305,
  "created_at" : "2012-07-28 19:55:41 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229149876703862784",
  "text" : "This Olympic thing is starting to win me over...",
  "id" : 229149876703862784,
  "created_at" : "2012-07-28 09:42:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Windsor",
      "screen_name" : "Queen_UK",
      "indices" : [ 3, 12 ],
      "id_str" : "140118545",
      "id" : 140118545
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "olympicceremony",
      "indices" : [ 90, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229128370791796736",
  "text" : "RT @Queen_UK: Give one some sodding warning when the camera is coming, for Christ's sake. #olympicceremony",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "olympicceremony",
        "indices" : [ 76, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228987806393978881",
    "text" : "Give one some sodding warning when the camera is coming, for Christ's sake. #olympicceremony",
    "id" : 228987806393978881,
    "created_at" : "2012-07-27 22:58:42 +0000",
    "user" : {
      "name" : "Elizabeth Windsor",
      "screen_name" : "Queen_UK",
      "protected" : false,
      "id_str" : "140118545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1519465232\/HMsmall_normal.jpg",
      "id" : 140118545,
      "verified" : false
    }
  },
  "id" : 229128370791796736,
  "created_at" : "2012-07-28 08:17:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229006818620366848",
  "text" : "Also loved the ceremony. But my fav moment is still in 96 when Ali got to light the flame.. That still plugs at my heart strings!",
  "id" : 229006818620366848,
  "created_at" : "2012-07-28 00:14:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229006604866039809",
  "text" : "Well at least McCartney can't be there for the closing. I love the man... He's still doing well for 70... But enough is enough :D",
  "id" : 229006604866039809,
  "created_at" : "2012-07-28 00:13:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228993687244390401",
  "text" : "Muhammad Ali - The Greatest",
  "id" : 228993687244390401,
  "created_at" : "2012-07-27 23:22:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 32, 44 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/228745927626723328\/photo\/1",
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/MkGJh5oG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyyrNZCCEAAHDhm.jpg",
      "id_str" : "228745927635111936",
      "id" : 228745927635111936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyyrNZCCEAAHDhm.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/MkGJh5oG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228745927626723328",
  "text" : "Friday morning pillow talk with @niall_adams http:\/\/t.co\/MkGJh5oG",
  "id" : 228745927626723328,
  "created_at" : "2012-07-27 06:57:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 15, 23 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228741383299686400",
  "geo" : { },
  "id_str" : "228741705808105472",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @havoct5 both... I'd go for both :) xxxxx",
  "id" : 228741705808105472,
  "in_reply_to_status_id" : 228741383299686400,
  "created_at" : "2012-07-27 06:40:47 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228739681959936000",
  "geo" : { },
  "id_str" : "228740442047528961",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley you are a beautiful man :)",
  "id" : 228740442047528961,
  "in_reply_to_status_id" : 228739681959936000,
  "created_at" : "2012-07-27 06:35:45 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228610211445891072",
  "text" : "Spent the whole night gardening :)",
  "id" : 228610211445891072,
  "created_at" : "2012-07-26 21:58:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "indices" : [ 3, 12 ],
      "id_str" : "224",
      "id" : 224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228609477031641089",
  "text" : "RT @davepell: Facebook shareholders feel like Twitter API users.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228589949866360832",
    "text" : "Facebook shareholders feel like Twitter API users.",
    "id" : 228589949866360832,
    "created_at" : "2012-07-26 20:37:45 +0000",
    "user" : {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "protected" : false,
      "id_str" : "224",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1131225374\/twTitle-1_normal.jpg",
      "id" : 224,
      "verified" : false
    }
  },
  "id" : 228609477031641089,
  "created_at" : "2012-07-26 21:55:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "indices" : [ 0, 10 ],
      "id_str" : "199486205",
      "id" : 199486205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228581284845330434",
  "geo" : { },
  "id_str" : "228609081093550080",
  "in_reply_to_user_id" : 199486205,
  "text" : "@AoifeB155 what an awful film though....",
  "id" : 228609081093550080,
  "in_reply_to_status_id" : 228581284845330434,
  "created_at" : "2012-07-26 21:53:46 +0000",
  "in_reply_to_screen_name" : "AoifeB155",
  "in_reply_to_user_id_str" : "199486205",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 32, 40 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228458993637527552",
  "text" : "OH: \"I wish I was a vagina!!!!\" @HaVoCT5 got very excited at saying this he gives me some seriously good quotes :D",
  "id" : 228458993637527552,
  "created_at" : "2012-07-26 11:57:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228445903407677440",
  "text" : "RT @substack: a lot of people are running around trying to make programming much harder than it actually is or needs to be",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228443678706892801",
    "text" : "a lot of people are running around trying to make programming much harder than it actually is or needs to be",
    "id" : 228443678706892801,
    "created_at" : "2012-07-26 10:56:31 +0000",
    "user" : {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 228445903407677440,
  "created_at" : "2012-07-26 11:05:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228442563076567040",
  "text" : "Really inspired by that talk last night... But I am in here doing support tickets and writing php... Hmmmmmmmm - lunch time soon :D",
  "id" : 228442563076567040,
  "created_at" : "2012-07-26 10:52:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian D. Quinn",
      "screen_name" : "briandq",
      "indices" : [ 0, 8 ],
      "id_str" : "17363843",
      "id" : 17363843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228188364107567105",
  "geo" : { },
  "id_str" : "228206532549021696",
  "in_reply_to_user_id" : 17363843,
  "text" : "@briandq Excellent talk last night btw :)",
  "id" : 228206532549021696,
  "in_reply_to_status_id" : 228188364107567105,
  "created_at" : "2012-07-25 19:14:11 +0000",
  "in_reply_to_screen_name" : "briandq",
  "in_reply_to_user_id_str" : "17363843",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 79, 87 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mktgcloud",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228179834340274176",
  "text" : "Facebook has some of the cleanest data there is - the metrics ARE reliable \/cc @garyvee #mktgcloud",
  "id" : 228179834340274176,
  "created_at" : "2012-07-25 17:28:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 1, 9 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 11, 17 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228154874989256704",
  "text" : "\u201C@HaVoCT5: @swmcc i wouldnt say love more like the apple acts as the gag and the fanta bottle, rhymes with mildo\u201D Classy fella :)",
  "id" : 228154874989256704,
  "created_at" : "2012-07-25 15:48:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 19, 27 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/228150533310009344\/photo\/1",
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/7MAG2I0Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyqNs4YCUAARJNz.jpg",
      "id_str" : "228150533322592256",
      "id" : 228150533322592256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyqNs4YCUAARJNz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/7MAG2I0Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228150533310009344",
  "text" : "He &lt;3 me :) \/cc @HaVoCT5 http:\/\/t.co\/7MAG2I0Z",
  "id" : 228150533310009344,
  "created_at" : "2012-07-25 15:31:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mktgcloud",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228147568692039682",
  "text" : "I have a webinar to attend at 6pm today that I forgot about... Should be good! #mktgcloud",
  "id" : 228147568692039682,
  "created_at" : "2012-07-25 15:19:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228140280501633024",
  "text" : "So this is the place for passive aggressive tweets to let people know what you are really thinking. I don't buy that! I AM FUCKED OFF!!!",
  "id" : 228140280501633024,
  "created_at" : "2012-07-25 14:50:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 1, 15 ],
      "id_str" : "49953918",
      "id" : 49953918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228095331458482176",
  "text" : "\u201C@RickTheJackal: Ultimate insult: You're a hipster\u201D And I sad it - and I think I touched a nerve ;)",
  "id" : 228095331458482176,
  "created_at" : "2012-07-25 11:52:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227898990350454784",
  "geo" : { },
  "id_str" : "228072192024399872",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore no there aren't! ;)",
  "id" : 228072192024399872,
  "in_reply_to_status_id" : 227898990350454784,
  "created_at" : "2012-07-25 10:20:22 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 32, 40 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228054301841432576",
  "geo" : { },
  "id_str" : "228054608130490368",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson @havoct5 not wound up. You've got me confused with someone that gives a fuck ;)",
  "id" : 228054608130490368,
  "in_reply_to_status_id" : 228054301841432576,
  "created_at" : "2012-07-25 09:10:30 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 15, 23 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 24, 40 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228053315496325120",
  "geo" : { },
  "id_str" : "228053532622876672",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @havoct5 @michaelnsimpson thought it was Thursday?? Well if someone wants to pick me up in the Kilgord rd!",
  "id" : 228053532622876672,
  "in_reply_to_status_id" : 228053315496325120,
  "created_at" : "2012-07-25 09:06:13 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 9, 25 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 26, 40 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228052321253330944",
  "geo" : { },
  "id_str" : "228052946418552832",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @michaelnsimpson @peter_omalley we judas bastard. Also seems my diesel light no longer works! Will be in soon. Pass it on!",
  "id" : 228052946418552832,
  "in_reply_to_status_id" : 228052321253330944,
  "created_at" : "2012-07-25 09:03:54 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 39, 47 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228034769194209282",
  "geo" : { },
  "id_str" : "228046551967223808",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley me and @HaVoCT5 before we left yesterday :)",
  "id" : 228046551967223808,
  "in_reply_to_status_id" : 228034769194209282,
  "created_at" : "2012-07-25 08:38:29 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 19, 27 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227804439925374976",
  "text" : "Just got twaped by @HaVoCT5 there - I have to keep it... All is fair in the game of war! :D",
  "id" : 227804439925374976,
  "created_at" : "2012-07-24 16:36:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/227803291621404672\/photo\/1",
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/8GRxRP5V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AylR4wQCMAEsCrm.jpg",
      "id_str" : "227803291625598977",
      "id" : 227803291625598977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AylR4wQCMAEsCrm.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/8GRxRP5V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227803291621404672",
  "text" : "Mick loves Donkeys? Ha I just love plain cock! Wanna see a pic of mines? @gaytubelandia http:\/\/t.co\/8GRxRP5V",
  "id" : 227803291621404672,
  "created_at" : "2012-07-24 16:31:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227802189660295170",
  "text" : "This is gonna be nasty :D",
  "id" : 227802189660295170,
  "created_at" : "2012-07-24 16:27:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227802145754324992",
  "text" : "The next few messages aren't mine. :D",
  "id" : 227802145754324992,
  "created_at" : "2012-07-24 16:27:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227799854745792513",
  "geo" : { },
  "id_str" : "227800122787000321",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit not at the ruby thing then I takes it?",
  "id" : 227800122787000321,
  "in_reply_to_status_id" : 227799854745792513,
  "created_at" : "2012-07-24 16:19:16 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyoutuesdayyoucansuckmyballs",
      "indices" : [ 40, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227785966750953472",
  "text" : "OH (via email): \n\nTo recap:\n\nNovember.\n\n#fuckyoutuesdayyoucansuckmyballs :D",
  "id" : 227785966750953472,
  "created_at" : "2012-07-24 15:23:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227763579632361472",
  "geo" : { },
  "id_str" : "227765136008572928",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll a melon groper! We've all done it!",
  "id" : 227765136008572928,
  "in_reply_to_status_id" : 227763579632361472,
  "created_at" : "2012-07-24 14:00:14 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED",
      "screen_name" : "ComedyTed",
      "indices" : [ 3, 13 ],
      "id_str" : "628640001",
      "id" : 628640001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227737169157029888",
  "text" : "RT @ComedyTed: Life is so short, so fuck it, just do what the fuck makes you happy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227736920174768129",
    "text" : "Life is so short, so fuck it, just do what the fuck makes you happy.",
    "id" : 227736920174768129,
    "created_at" : "2012-07-24 12:08:07 +0000",
    "user" : {
      "name" : "TED",
      "screen_name" : "ComedyTed",
      "protected" : false,
      "id_str" : "628640001",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2373500816\/TED_normal.jpeg",
      "id" : 628640001,
      "verified" : false
    }
  },
  "id" : 227737169157029888,
  "created_at" : "2012-07-24 12:09:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 3, 15 ],
      "id_str" : "454835425",
      "id" : 454835425
    }, {
      "name" : "Spree",
      "screen_name" : "spreecommerce",
      "indices" : [ 118, 132 ],
      "id_str" : "32545982",
      "id" : 32545982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227701985057583105",
  "text" : "RT @BelfastRuby: BelfastRuby4 tonight at 18:30 in the Rumble Laboratory. Come on down for a few beers and an intro to @spreecommerce.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Spree",
        "screen_name" : "spreecommerce",
        "indices" : [ 101, 115 ],
        "id_str" : "32545982",
        "id" : 32545982
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227701789934379008",
    "text" : "BelfastRuby4 tonight at 18:30 in the Rumble Laboratory. Come on down for a few beers and an intro to @spreecommerce.",
    "id" : 227701789934379008,
    "created_at" : "2012-07-24 09:48:31 +0000",
    "user" : {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "protected" : false,
      "id_str" : "454835425",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1752070239\/belfastruby-twitter-icon-2_normal.png",
      "id" : 454835425,
      "verified" : false
    }
  },
  "id" : 227701985057583105,
  "created_at" : "2012-07-24 09:49:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tuesdaybuddysong",
      "indices" : [ 99, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227678288825438208",
  "text" : "FUCK you Tuedsay, you can suck my dick. You can\u2019t get me Tuesday, cause you\u2019re just 24 hours long. #tuesdaybuddysong",
  "id" : 227678288825438208,
  "created_at" : "2012-07-24 08:15:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tuesdaybuddysong",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227678062299471872",
  "text" : "When you feel the threat of Tuesday, don\u2019t you get too scared. Just grab your Tuesday buddy and say these magic words: #tuesdaybuddysong",
  "id" : 227678062299471872,
  "created_at" : "2012-07-24 08:14:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 1, 13 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 15, 21 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ted",
      "indices" : [ 71, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227677579648303104",
  "text" : "\u201C@niall_adams: @swmcc We'll sing the Tuesday Buddy song together later #Ted\u201D  :D I shall sing this now...",
  "id" : 227677579648303104,
  "created_at" : "2012-07-24 08:12:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesomansaturday",
      "indices" : [ 22, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227662916638371841",
  "geo" : { },
  "id_str" : "227663963595370497",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley yes :) #awesomansaturday",
  "id" : 227663963595370497,
  "in_reply_to_status_id" : 227662916638371841,
  "created_at" : "2012-07-24 07:18:13 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fucktuesdays",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227660024401514496",
  "text" : "Right... I woke up thinking its Wed. In fact it is Tuesday. Today I am not going to send any arsey company wide emails :D #fucktuesdays",
  "id" : 227660024401514496,
  "created_at" : "2012-07-24 07:02:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 5, 21 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bromance",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227531409751945216",
  "text" : "Hope @michaelnsimpson is back in work tomorrow. #bromance",
  "id" : 227531409751945216,
  "created_at" : "2012-07-23 22:31:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227487311343013888",
  "text" : "Newsroom - briiiing it :)",
  "id" : 227487311343013888,
  "created_at" : "2012-07-23 19:36:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCKYOUMONDAY",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227100155969679360",
  "text" : "Tomorrow is Monday... This does not please me. EspecIally since tomorrow is going to be known as #FUCKYOUMONDAY",
  "id" : 227100155969679360,
  "created_at" : "2012-07-22 17:57:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 16, 24 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 25, 41 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "promancecontinuesthen",
      "indices" : [ 65, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226737648411238401",
  "geo" : { },
  "id_str" : "226737842100006913",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @HaVoCT5 @michaelnsimpson Your loss Sista!!!!!!! #promancecontinuesthen",
  "id" : 226737842100006913,
  "in_reply_to_status_id" : 226737648411238401,
  "created_at" : "2012-07-21 17:58:08 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 16, 24 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 25, 41 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226725047891529729",
  "geo" : { },
  "id_str" : "226737031060008961",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @HaVoCT5 @michaelnsimpson I cannot offer you a diamond... A winning smile and a handshake is all! Enjoy the party :D :D",
  "id" : 226737031060008961,
  "in_reply_to_status_id" : 226725047891529729,
  "created_at" : "2012-07-21 17:54:55 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 16, 28 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 29, 37 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 38, 45 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 46, 58 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 59, 75 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226682921262649344",
  "geo" : { },
  "id_str" : "226684363713150977",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @niall_adams @havoct5 @srushe @ryancunning @michaelnsimpson marry me!!!!",
  "id" : 226684363713150977,
  "in_reply_to_status_id" : 226682921262649344,
  "created_at" : "2012-07-21 14:25:38 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SparrowMail",
      "screen_name" : "sparrow",
      "indices" : [ 12, 20 ],
      "id_str" : "163449492",
      "id" : 163449492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226355895603453955",
  "text" : "Gutted that @sparrow has been bought as it was a good app. Happy for the team though - well done :D",
  "id" : 226355895603453955,
  "created_at" : "2012-07-20 16:40:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aoife Clare Byrne",
      "screen_name" : "AoifeB155",
      "indices" : [ 0, 10 ],
      "id_str" : "199486205",
      "id" : 199486205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226332146854424576",
  "geo" : { },
  "id_str" : "226335345699065856",
  "in_reply_to_user_id" : 199486205,
  "text" : "@AoifeB155 done!",
  "id" : 226335345699065856,
  "in_reply_to_status_id" : 226332146854424576,
  "created_at" : "2012-07-20 15:18:46 +0000",
  "in_reply_to_screen_name" : "AoifeB155",
  "in_reply_to_user_id_str" : "199486205",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 0, 14 ],
      "id_str" : "49953918",
      "id" : 49953918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226295706552520704",
  "geo" : { },
  "id_str" : "226296228181327872",
  "in_reply_to_user_id" : 49953918,
  "text" : "@RickTheJackal that's lovely... idiots.",
  "id" : 226296228181327872,
  "in_reply_to_status_id" : 226295706552520704,
  "created_at" : "2012-07-20 12:43:19 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226290029583020032",
  "geo" : { },
  "id_str" : "226290141411549185",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I LOVE YOU",
  "id" : 226290141411549185,
  "in_reply_to_status_id" : 226290029583020032,
  "created_at" : "2012-07-20 12:19:08 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 51, 59 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/226269581466009601\/photo\/1",
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/XhU3Yu1b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyPe_EsCAAAdHwd.png",
      "id_str" : "226269581470203904",
      "id" : 226269581470203904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyPe_EsCAAAdHwd.png",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XhU3Yu1b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226269581466009601",
  "text" : "These conversations are getting out of hand :) \/cc @HaVoCT5 http:\/\/t.co\/XhU3Yu1b",
  "id" : 226269581466009601,
  "created_at" : "2012-07-20 10:57:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226267031295627264",
  "text" : "OH: Did she hide it in her vagina!!",
  "id" : 226267031295627264,
  "created_at" : "2012-07-20 10:47:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226231250254446592",
  "geo" : { },
  "id_str" : "226233959246336000",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson probably the same place as your fucking balls!!!!!",
  "id" : 226233959246336000,
  "in_reply_to_status_id" : 226231250254446592,
  "created_at" : "2012-07-20 08:35:53 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Victoria Square",
      "screen_name" : "Victoria_Square",
      "indices" : [ 15, 31 ],
      "id_str" : "91979112",
      "id" : 91979112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226067193559916544",
  "geo" : { },
  "id_str" : "226079708138311681",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @Victoria_Square 9.40!!! For Belfast... I hope that comes with a side of 'blowjob' otherwise. Street parking for moi!",
  "id" : 226079708138311681,
  "in_reply_to_status_id" : 226067193559916544,
  "created_at" : "2012-07-19 22:22:57 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 26, 37 ],
      "id_str" : "5932682",
      "id" : 5932682
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 99, 111 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225932061633032193",
  "text" : "So - I am allowed to kick @davidjrice straight in the stones next Tuesday at the Ruby Meetup.. \/cc @BelfastRuby",
  "id" : 225932061633032193,
  "created_at" : "2012-07-19 12:36:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sonos",
      "screen_name" : "Sonos",
      "indices" : [ 22, 28 ],
      "id_str" : "16727022",
      "id" : 16727022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225931531342983168",
  "text" : "Pulp just came on the @sonos player... I might have to kill someone.",
  "id" : 225931531342983168,
  "created_at" : "2012-07-19 12:34:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225904464379379712",
  "text" : "Starting to get pretty pissed at the amount of foot traffic around me again... If you work with me - use the back way!!!",
  "id" : 225904464379379712,
  "created_at" : "2012-07-19 10:46:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 12, 20 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sohappy",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225896228515352576",
  "text" : "I just made @HaVoCT5 stop there with a remark I said! #sohappy",
  "id" : 225896228515352576,
  "created_at" : "2012-07-19 10:13:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225889608104308736",
  "text" : "OH: uou're corrupting me!",
  "id" : 225889608104308736,
  "created_at" : "2012-07-19 09:47:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 20, 34 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225659655911796736",
  "text" : "RT @HaVoCT5: @swmcc @peter_omalley and u forgot the best reply which was mines talking bout my girth :D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Peter O'Malley",
        "screen_name" : "peter_omalley",
        "indices" : [ 7, 21 ],
        "id_str" : "437697624",
        "id" : 437697624
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225658812672114688",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @peter_omalley and u forgot the best reply which was mines talking bout my girth :D",
    "id" : 225658812672114688,
    "created_at" : "2012-07-18 18:30:28 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 225659655911796736,
  "created_at" : "2012-07-18 18:33:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 9, 23 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225658812672114688",
  "geo" : { },
  "id_str" : "225659602367299585",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @peter_omalley me and mick are slowly destroying that office. We need separated.",
  "id" : 225659602367299585,
  "in_reply_to_status_id" : 225658812672114688,
  "created_at" : "2012-07-18 18:33:36 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 9, 23 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/225659063235653632\/photo\/1",
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/9OCXAOeJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyGzuPDCMAEK-ew.jpg",
      "id_str" : "225659063239847937",
      "id" : 225659063239847937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyGzuPDCMAEK-ew.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/9OCXAOeJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225658812672114688",
  "geo" : { },
  "id_str" : "225659063235653632",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @peter_omalley here it is. http:\/\/t.co\/9OCXAOeJ",
  "id" : 225659063235653632,
  "in_reply_to_status_id" : 225658812672114688,
  "created_at" : "2012-07-18 18:31:28 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 20, 34 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225658718082174977",
  "text" : "RT @HaVoCT5: @swmcc @peter_omalley first mesaage i didnt know who it was, didnt take long for me to figure it out tho! Twanged where did ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Peter O'Malley",
        "screen_name" : "peter_omalley",
        "indices" : [ 7, 21 ],
        "id_str" : "437697624",
        "id" : 437697624
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "225658163515514880",
    "geo" : { },
    "id_str" : "225658444789719040",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @peter_omalley first mesaage i didnt know who it was, didnt take long for me to figure it out tho! Twanged where did it cum from",
    "id" : 225658444789719040,
    "in_reply_to_status_id" : 225658163515514880,
    "created_at" : "2012-07-18 18:29:00 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 225658718082174977,
  "created_at" : "2012-07-18 18:30:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 9, 23 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/225658337243570177\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/ap1ekXix",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyGzD-iCIAAk3fo.jpg",
      "id_str" : "225658337251958784",
      "id" : 225658337251958784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyGzD-iCIAAk3fo.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/ap1ekXix"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225656999327719424",
  "geo" : { },
  "id_str" : "225658337243570177",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @peter_omalley him on. This was before he knew it was me! I talk dirty well from the female perspective http:\/\/t.co\/ap1ekXix",
  "id" : 225658337243570177,
  "in_reply_to_status_id" : 225656999327719424,
  "created_at" : "2012-07-18 18:28:35 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 9, 23 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225656999327719424",
  "geo" : { },
  "id_str" : "225658163515514880",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @peter_omalley got his number so was texting him today when he was at the funeral! He didn't know who it was. Apparently I turned.",
  "id" : 225658163515514880,
  "in_reply_to_status_id" : 225656999327719424,
  "created_at" : "2012-07-18 18:27:53 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 9, 23 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225656999327719424",
  "geo" : { },
  "id_str" : "225657685356457984",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @peter_omalley Aye school boy error saying \"I twanged myself thinking about you all afternoon\". Twanged like - fuck sake!",
  "id" : 225657685356457984,
  "in_reply_to_status_id" : 225656999327719424,
  "created_at" : "2012-07-18 18:25:59 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 14, 22 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225634054719029249",
  "text" : "I just turned @HaVoCT5 on :D",
  "id" : 225634054719029249,
  "created_at" : "2012-07-18 16:52:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225540067454763010",
  "text" : "OH: \"Actually nvm - i cant be confident thats u in the shitter even if u dont answer\"",
  "id" : 225540067454763010,
  "created_at" : "2012-07-18 10:38:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225516981934227456",
  "text" : "New rule.. 10am meetings - only come in just prior to 10am so you don't waste an hour thinking about the meeting :D",
  "id" : 225516981934227456,
  "created_at" : "2012-07-18 09:06:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 15, 27 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 28, 39 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 40, 56 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 57, 69 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 70, 84 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225342990279909377",
  "geo" : { },
  "id_str" : "225343186070016000",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ @niall_adams @alana_doll @michaelnsimpson @kirstylvssp @peter_omalley Grand total of 0. Zero. None left :)",
  "id" : 225343186070016000,
  "in_reply_to_status_id" : 225342990279909377,
  "created_at" : "2012-07-17 21:36:16 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 13, 24 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 25, 41 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 42, 54 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 55, 69 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 70, 84 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mancarddown",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225333192859713538",
  "geo" : { },
  "id_str" : "225336510310924288",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @alana_doll @michaelnsimpson @kirstylvssp @peter_omalley @chrisknowles_ #mancarddown it is then. Tis done!",
  "id" : 225336510310924288,
  "in_reply_to_status_id" : 225333192859713538,
  "created_at" : "2012-07-17 21:09:45 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 32, 46 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 47, 59 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mancardown",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225326688848982017",
  "geo" : { },
  "id_str" : "225327241356255232",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley @chrisknowles_ @niall_adams #mancardown men do not talk about tampons or fucking handbags!!!!",
  "id" : 225327241356255232,
  "in_reply_to_status_id" : 225326688848982017,
  "created_at" : "2012-07-17 20:32:55 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 17, 28 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 29, 41 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mancardown",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225319568707563521",
  "geo" : { },
  "id_str" : "225326996933189635",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @alana_doll @niall_adams fuck sake! Am reading my timeline now and seeing this! If you make one more ref #mancardown",
  "id" : 225326996933189635,
  "in_reply_to_status_id" : 225319568707563521,
  "created_at" : "2012-07-17 20:31:57 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225147130497613825",
  "text" : "SERIOUSLY - WHERE THE FUCK ARE MY CAR KEYS????",
  "id" : 225147130497613825,
  "created_at" : "2012-07-17 08:37:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225129622579331072",
  "geo" : { },
  "id_str" : "225129775746916352",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson what is his excuse? Gonna be one man card down!!!!",
  "id" : 225129775746916352,
  "in_reply_to_status_id" : 225129622579331072,
  "created_at" : "2012-07-17 07:28:15 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Kenny",
      "screen_name" : "bkenny",
      "indices" : [ 0, 7 ],
      "id_str" : "12585212",
      "id" : 12585212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224958013650382848",
  "geo" : { },
  "id_str" : "224958647967555585",
  "in_reply_to_user_id" : 12585212,
  "text" : "@bkenny just about to watch episode 4, so it's good then?",
  "id" : 224958647967555585,
  "in_reply_to_status_id" : 224958013650382848,
  "created_at" : "2012-07-16 20:08:15 +0000",
  "in_reply_to_screen_name" : "bkenny",
  "in_reply_to_user_id_str" : "12585212",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 31, 43 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224834551992696832",
  "geo" : { },
  "id_str" : "224957076777074690",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 @michaelnsimpson @niall_adams ha :) Pink kettle indeed :) :)",
  "id" : 224957076777074690,
  "in_reply_to_status_id" : 224834551992696832,
  "created_at" : "2012-07-16 20:02:01 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224899005824507904",
  "text" : "Anyone know where I can get wallpaper that tells ppl to stop doing it? Its driving me fucking nuts!",
  "id" : 224899005824507904,
  "created_at" : "2012-07-16 16:11:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224896860681277440",
  "text" : "Blatantly looking at my screen regardless of who you are really gets on my tits.",
  "id" : 224896860681277440,
  "created_at" : "2012-07-16 16:02:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224890488178737155",
  "text" : "OH: \"uck - i'm fine - just being a soppy emo cunt\"",
  "id" : 224890488178737155,
  "created_at" : "2012-07-16 15:37:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 45, 52 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224857810452758528",
  "text" : "I don't often get to the chance to work with @srushe these days - but when I do its a fucking pleasure to do so :D :D :D",
  "id" : 224857810452758528,
  "created_at" : "2012-07-16 13:27:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224826610543632385",
  "geo" : { },
  "id_str" : "224829554890510337",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ :D Sounds like you were up to some kinky shit!",
  "id" : 224829554890510337,
  "in_reply_to_status_id" : 224826610543632385,
  "created_at" : "2012-07-16 11:35:17 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224808520720195584",
  "text" : "OH: I have a small penis but it is deadly!",
  "id" : 224808520720195584,
  "created_at" : "2012-07-16 10:11:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Jules",
      "screen_name" : "Julesb155",
      "indices" : [ 17, 27 ],
      "id_str" : "567275097",
      "id" : 567275097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224801976750309377",
  "geo" : { },
  "id_str" : "224802806316544000",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @julesb155 not even TED... Teddy Ruckspin...",
  "id" : 224802806316544000,
  "in_reply_to_status_id" : 224801976750309377,
  "created_at" : "2012-07-16 09:49:00 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jules",
      "screen_name" : "Julesb155",
      "indices" : [ 1, 11 ],
      "id_str" : "567275097",
      "id" : 567275097
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224801671660843008",
  "text" : "\u201C@Julesb155: @michaelnsimpson because of cuddlegate 2012, I now christen you Ted.\u201D",
  "id" : 224801671660843008,
  "created_at" : "2012-07-16 09:44:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224801088434487297",
  "text" : "OH: Fuck sake just take the vagina by the flaps.",
  "id" : 224801088434487297,
  "created_at" : "2012-07-16 09:42:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224773869142155264",
  "text" : "Wanted to be in early today and have so much to do. No IRC or anything today - headphones on world out!",
  "id" : 224773869142155264,
  "created_at" : "2012-07-16 07:54:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224582152396873729",
  "geo" : { },
  "id_str" : "224587836047884288",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams As long as you brought Snoopy back in one bit I am happy :)",
  "id" : 224587836047884288,
  "in_reply_to_status_id" : 224582152396873729,
  "created_at" : "2012-07-15 19:34:47 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 1, 13 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 14, 20 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovethisman",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224581784497684480",
  "text" : "\"@niall_adams @swmcc Im back tomorrow though, and have decided its International Stevie day! Woohoo!\" #lovethisman",
  "id" : 224581784497684480,
  "created_at" : "2012-07-15 19:10:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224549336355307521",
  "geo" : { },
  "id_str" : "224549542857670656",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull sorry!!! I am a lying shite. It's Friday... I am a lying bollcoks.",
  "id" : 224549542857670656,
  "in_reply_to_status_id" : 224549336355307521,
  "created_at" : "2012-07-15 17:02:37 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224547586474901504",
  "text" : "FUCK SAKE... IT IS SUNDAY EVENING!!!!!! RAT FUCK!!!",
  "id" : 224547586474901504,
  "created_at" : "2012-07-15 16:54:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224215104407879680",
  "geo" : { },
  "id_str" : "224397300116619265",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams love it :)",
  "id" : 224397300116619265,
  "in_reply_to_status_id" : 224215104407879680,
  "created_at" : "2012-07-15 06:57:40 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/pinterest.com\" rel=\"nofollow\"\u003EPinterest\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/m8iuoS6U",
      "expanded_url" : "http:\/\/pinterest.com\/pin\/139259813448321595\/",
      "display_url" : "pinterest.com\/pin\/1392598134\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224322562103058432",
  "text" : "Waiting for next week to get more!! http:\/\/t.co\/m8iuoS6U",
  "id" : 224322562103058432,
  "created_at" : "2012-07-15 02:00:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224294581284503552",
  "geo" : { },
  "id_str" : "224295289035563008",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish I read the email but it only stuck in my head due to twitter updates. Very impressed :D",
  "id" : 224295289035563008,
  "in_reply_to_status_id" : 224294581284503552,
  "created_at" : "2012-07-15 00:12:18 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224292255291281409",
  "geo" : { },
  "id_str" : "224294269043752960",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish very impressed with your updates re: this... Keep it up :D",
  "id" : 224294269043752960,
  "in_reply_to_status_id" : 224292255291281409,
  "created_at" : "2012-07-15 00:08:15 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "virtualhighfive",
      "indices" : [ 18, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224170108514340864",
  "geo" : { },
  "id_str" : "224172564963004416",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson  #virtualhighfive",
  "id" : 224172564963004416,
  "in_reply_to_status_id" : 224170108514340864,
  "created_at" : "2012-07-14 16:04:39 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224145781731491840",
  "text" : "In the last two 48 hours I am pretty sure I have spent over 50% sleeping. Not ill. Just fucking lazy :D",
  "id" : 224145781731491840,
  "created_at" : "2012-07-14 14:18:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/223839697410080768\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/iVDF1G2q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Axs9BNMCQAEwH3Z.jpg",
      "id_str" : "223839697414275073",
      "id" : 223839697414275073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Axs9BNMCQAEwH3Z.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/iVDF1G2q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223839697410080768",
  "text" : "I just sent my dad a text message ending with an x!!! Wasn't thinking. It might come to nothing.. Dunno http:\/\/t.co\/iVDF1G2q",
  "id" : 223839697410080768,
  "created_at" : "2012-07-13 18:01:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223818182073389056",
  "geo" : { },
  "id_str" : "223838512514998272",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull ack... we will see :D First step - Ninja completeness... I intend to be a hussy!",
  "id" : 223838512514998272,
  "in_reply_to_status_id" : 223818182073389056,
  "created_at" : "2012-07-13 17:57:14 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223806396603445249",
  "geo" : { },
  "id_str" : "223806654955782144",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull I don't think I said that anywhere in that previous tweet :) But you'll deffo be cold in Dec wearing that!",
  "id" : 223806654955782144,
  "in_reply_to_status_id" : 223806396603445249,
  "created_at" : "2012-07-13 15:50:39 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223796977819856896",
  "geo" : { },
  "id_str" : "223805177449291776",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull ha ha :D Don't think you are gonna be doing much Ninja'ing on all fours. We said Ninja - not hussy (yet anyway).",
  "id" : 223805177449291776,
  "in_reply_to_status_id" : 223796977819856896,
  "created_at" : "2012-07-13 15:44:47 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "virtualhighfive",
      "indices" : [ 53, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223756884123983872",
  "geo" : { },
  "id_str" : "223766593769975808",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson fucking pizzas :D God speed Mike :D #virtualhighfive",
  "id" : 223766593769975808,
  "in_reply_to_status_id" : 223756884123983872,
  "created_at" : "2012-07-13 13:11:27 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223745510803128320",
  "geo" : { },
  "id_str" : "223749277741088768",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson voicemail. you fucking disgust me!",
  "id" : 223749277741088768,
  "in_reply_to_status_id" : 223745510803128320,
  "created_at" : "2012-07-13 12:02:39 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223738415395516416",
  "geo" : { },
  "id_str" : "223738547834863617",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 your loss then ;)",
  "id" : 223738547834863617,
  "in_reply_to_status_id" : 223738415395516416,
  "created_at" : "2012-07-13 11:20:01 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223725807066025984",
  "geo" : { },
  "id_str" : "223726008807849985",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull That's cos you weren't looking at my face... PERVERT! :D",
  "id" : 223726008807849985,
  "in_reply_to_status_id" : 223725807066025984,
  "created_at" : "2012-07-13 10:30:11 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223725183356252160",
  "geo" : { },
  "id_str" : "223725435576528896",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull if I was to come in today that's what you would see..",
  "id" : 223725435576528896,
  "in_reply_to_status_id" : 223725183356252160,
  "created_at" : "2012-07-13 10:27:55 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/ghyp1dqJ",
      "expanded_url" : "http:\/\/imgur.com\/kULVg",
      "display_url" : "imgur.com\/kULVg"
    } ]
  },
  "in_reply_to_status_id_str" : "223724527924948992",
  "geo" : { },
  "id_str" : "223724978330271744",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull http:\/\/t.co\/ghyp1dqJ",
  "id" : 223724978330271744,
  "in_reply_to_status_id" : 223724527924948992,
  "created_at" : "2012-07-13 10:26:06 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223723655522295808",
  "geo" : { },
  "id_str" : "223723862720905216",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe couldn't even see the fucking board at the minute.... I need bacon or something... My kingdom for bacon.",
  "id" : 223723862720905216,
  "in_reply_to_status_id" : 223723655522295808,
  "created_at" : "2012-07-13 10:21:40 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 15, 30 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 31, 47 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223723078985854976",
  "geo" : { },
  "id_str" : "223723642775805952",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @annette_mccull @michaelnsimpson I booked today off anyways :D I feel no shame... Enjoy working losers!!!",
  "id" : 223723642775805952,
  "in_reply_to_status_id" : 223723078985854976,
  "created_at" : "2012-07-13 10:20:47 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 3, 18 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 20, 26 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 27, 43 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 44, 58 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223722997607968769",
  "text" : "RT @annette_mccull: @swmcc @michaelnsimpson @peter_omalley you're a fucking lightweight",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Mike ",
        "screen_name" : "michaelnsimpson",
        "indices" : [ 7, 23 ],
        "id_str" : "311597138",
        "id" : 311597138
      }, {
        "name" : "Peter O'Malley",
        "screen_name" : "peter_omalley",
        "indices" : [ 24, 38 ],
        "id_str" : "437697624",
        "id" : 437697624
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "223722600772276224",
    "geo" : { },
    "id_str" : "223722911645712384",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @michaelnsimpson @peter_omalley you're a fucking lightweight",
    "id" : 223722911645712384,
    "in_reply_to_status_id" : 223722600772276224,
    "created_at" : "2012-07-13 10:17:53 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "protected" : true,
      "id_str" : "161635397",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000591917589\/beb3a4a248d02295741466ac18029379_normal.jpeg",
      "id" : 161635397,
      "verified" : false
    }
  },
  "id" : 223722997607968769,
  "created_at" : "2012-07-13 10:18:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 16, 32 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 33, 47 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223707191062958080",
  "geo" : { },
  "id_str" : "223722600772276224",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @michaelnsimpson @peter_omalley not coming in. am dying.. not worth it :( Euggggghhhh... I'd kick your ass anyway!",
  "id" : 223722600772276224,
  "in_reply_to_status_id" : 223707191062958080,
  "created_at" : "2012-07-13 10:16:39 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 17, 32 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 33, 47 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223705775783157760",
  "geo" : { },
  "id_str" : "223705932352327680",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @annette_mccull @peter_omalley right i am coming in now... don't fucking move!!!! IDIOT! :D",
  "id" : 223705932352327680,
  "in_reply_to_status_id" : 223705775783157760,
  "created_at" : "2012-07-13 09:10:25 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 17, 32 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 33, 47 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223705122717442051",
  "geo" : { },
  "id_str" : "223705447889252354",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @annette_mccull @peter_omalley fuck sake. you are off the races quick. I have a headache you pervert!!!",
  "id" : 223705447889252354,
  "in_reply_to_status_id" : 223705122717442051,
  "created_at" : "2012-07-13 09:08:29 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 16, 30 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 31, 47 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223700128094097408",
  "geo" : { },
  "id_str" : "223702993822953472",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @peter_omalley @michaelnsimpson will be in a bit. Yeah... Just a bit. Two monkeys and only banana in my head at the mo!",
  "id" : 223702993822953472,
  "in_reply_to_status_id" : 223700128094097408,
  "created_at" : "2012-07-13 08:58:44 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Annette McDonagh",
      "screen_name" : "AnnetteMcDonagh",
      "indices" : [ 62, 78 ],
      "id_str" : "1164404882",
      "id" : 1164404882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223681129859923969",
  "geo" : { },
  "id_str" : "223682054418743296",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley dudes.... Tooo fucking early! @annettemcdonagh they do not follow ninja ways :)",
  "id" : 223682054418743296,
  "in_reply_to_status_id" : 223681129859923969,
  "created_at" : "2012-07-13 07:35:32 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223561877559582720",
  "geo" : { },
  "id_str" : "223563514118291459",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues this stuff wasn't half bad... Its probably a bad idea to have twitter open and be kinda tipsy.. But sure... :)",
  "id" : 223563514118291459,
  "in_reply_to_status_id" : 223561877559582720,
  "created_at" : "2012-07-12 23:44:30 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223558424414261248",
  "text" : "Right. Tonight for the first time in 33 years I tried wine. I liked it. Some NZ wank. Two bottles... Lets see what happens...",
  "id" : 223558424414261248,
  "created_at" : "2012-07-12 23:24:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223516604447731712",
  "geo" : { },
  "id_str" : "223553352162754561",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues good :) Don't let them get you down. For you are fucking awesome and they suck ass!!! :D",
  "id" : 223553352162754561,
  "in_reply_to_status_id" : 223516604447731712,
  "created_at" : "2012-07-12 23:04:07 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223507339662209024",
  "geo" : { },
  "id_str" : "223516150477234176",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues that's awful. Give me their number plates! Seriously! Bastards!",
  "id" : 223516150477234176,
  "in_reply_to_status_id" : 223507339662209024,
  "created_at" : "2012-07-12 20:36:17 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 17, 25 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223396771068522497",
  "geo" : { },
  "id_str" : "223423500843630592",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @HaVoCT5 what is that?",
  "id" : 223423500843630592,
  "in_reply_to_status_id" : 223396771068522497,
  "created_at" : "2012-07-12 14:28:08 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nellybert",
      "screen_name" : "Nellybert",
      "indices" : [ 0, 10 ],
      "id_str" : "14925987",
      "id" : 14925987
    }, {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 11, 23 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ppltakeshittooseriously",
      "indices" : [ 52, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223384002147524608",
  "geo" : { },
  "id_str" : "223384506189627392",
  "in_reply_to_user_id" : 14925987,
  "text" : "@Nellybert @StrayTaoist I just don't give a shit :) #ppltakeshittooseriously",
  "id" : 223384506189627392,
  "in_reply_to_status_id" : 223384002147524608,
  "created_at" : "2012-07-12 11:53:11 +0000",
  "in_reply_to_screen_name" : "Nellybert",
  "in_reply_to_user_id_str" : "14925987",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 113, 121 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223377150991011840",
  "text" : "I don't hunt on grounds of religion, class, creed, sexual orientation or hair colour (save gingers). I only hunt @HaVoCT5 - cos he is sexy!",
  "id" : 223377150991011840,
  "created_at" : "2012-07-12 11:23:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ppltakeshittooseriously",
      "indices" : [ 94, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223376745561198592",
  "text" : "Been pointed out to me that my previous tweet could be seen as threatening. It. Was. A. Joke. #ppltakeshittooseriously",
  "id" : 223376745561198592,
  "created_at" : "2012-07-12 11:22:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "happytaighuntingday",
      "indices" : [ 118, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223347560356659200",
  "text" : "Bands seen. Hands shaken. Number of times I was asked \"Are you the one that plays the piano?\" 1. Fry now to be eaten. #happytaighuntingday",
  "id" : 223347560356659200,
  "created_at" : "2012-07-12 09:26:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223170901561180161",
  "geo" : { },
  "id_str" : "223176151886082048",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley its good. You should watch Sky channel 973 (ITV London) - Caddyshack is on. Possibly the funniest film ever.",
  "id" : 223176151886082048,
  "in_reply_to_status_id" : 223170901561180161,
  "created_at" : "2012-07-11 22:05:15 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223065282564988930",
  "text" : "OH: \"I don't have a vagina.. I wish I did.\" \"Yeah me too\"...",
  "id" : 223065282564988930,
  "created_at" : "2012-07-11 14:44:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 1, 9 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 11, 17 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HaVoCT5\/status\/223051327599689728\/photo\/1",
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/bEWHgmrE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxhwACyCQAAoDLV.jpg",
      "id_str" : "223051327603884032",
      "id" : 223051327603884032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxhwACyCQAAoDLV.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1840,
        "resize" : "fit",
        "w" : 3264
      } ],
      "display_url" : "pic.twitter.com\/bEWHgmrE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223052920952852480",
  "text" : "\u201C@HaVoCT5: @swmcc how you like those apples http:\/\/t.co\/bEWHgmrE\u201D PAR EXCELLENCE",
  "id" : 223052920952852480,
  "created_at" : "2012-07-11 13:55:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223044203964416001",
  "text" : "OH: \"You can ride my sister if you want\"",
  "id" : 223044203964416001,
  "created_at" : "2012-07-11 13:20:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223042299028975616",
  "geo" : { },
  "id_str" : "223042851980849153",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 I'm not the server guy!",
  "id" : 223042851980849153,
  "in_reply_to_status_id" : 223042299028975616,
  "created_at" : "2012-07-11 13:15:34 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223036536063660032",
  "text" : "OH: I think I would be a great gay!",
  "id" : 223036536063660032,
  "created_at" : "2012-07-11 12:50:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223033536867864576",
  "text" : "RT @HaVoCT5: @michaelnsimpson and the only reason why I have respect is because the fact u are tooling a OAP :D",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike ",
        "screen_name" : "michaelnsimpson",
        "indices" : [ 0, 16 ],
        "id_str" : "311597138",
        "id" : 311597138
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "223019831774027776",
    "geo" : { },
    "id_str" : "223032003140923392",
    "in_reply_to_user_id" : 311597138,
    "text" : "@michaelnsimpson and the only reason why I have respect is because the fact u are tooling a OAP :D",
    "id" : 223032003140923392,
    "in_reply_to_status_id" : 223019831774027776,
    "created_at" : "2012-07-11 12:32:27 +0000",
    "in_reply_to_screen_name" : "michaelnsimpson",
    "in_reply_to_user_id_str" : "311597138",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 223033536867864576,
  "created_at" : "2012-07-11 12:38:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223030328464384003",
  "text" : "OH: You dirty dog.. You asked me to do a deploy when you were playing darts!",
  "id" : 223030328464384003,
  "created_at" : "2012-07-11 12:25:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222998573799841792",
  "text" : "OH: \"I want to be a bitch, just so I can be a cunt!\"",
  "id" : 222998573799841792,
  "created_at" : "2012-07-11 10:19:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222715399400202241",
  "geo" : { },
  "id_str" : "222727333193334784",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ @michaelnsimpson A rat some coleslaw and a drain pripe.",
  "id" : 222727333193334784,
  "in_reply_to_status_id" : 222715399400202241,
  "created_at" : "2012-07-10 16:21:48 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222727233838653441",
  "text" : "OH: Why does everyone want to fuck me in the ass all of a sudden...",
  "id" : 222727233838653441,
  "created_at" : "2012-07-10 16:21:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 1, 7 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 43, 59 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222713891078144000",
  "text" : "\u201C@swmcc: Excited for my next man date with @michaelnsimpson\u201D This wasn't me that put this on - but it is true :D :D :D :D",
  "id" : 222713891078144000,
  "created_at" : "2012-07-10 15:28:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 34, 50 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222712029985783809",
  "text" : "Excited for my next man date with @michaelnsimpson",
  "id" : 222712029985783809,
  "created_at" : "2012-07-10 15:21:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 3, 17 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 29, 35 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "TinyLife",
      "screen_name" : "TinyLifeCharity",
      "indices" : [ 61, 77 ],
      "id_str" : "54850118",
      "id" : 54850118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222707686897221632",
  "text" : "RT @jenporterhall: Thank you @swmcc for donating a tenner to @TinyLifeCharity in memory of Rose and in lieu of my champion sprinting yes ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 10, 16 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "TinyLife",
        "screen_name" : "TinyLifeCharity",
        "indices" : [ 42, 58 ],
        "id_str" : "54850118",
        "id" : 54850118
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JessicanotJenni",
        "indices" : [ 124, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222706098141020162",
    "text" : "Thank you @swmcc for donating a tenner to @TinyLifeCharity in memory of Rose and in lieu of my champion sprinting yesterday #JessicanotJenni",
    "id" : 222706098141020162,
    "created_at" : "2012-07-10 14:57:26 +0000",
    "user" : {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "protected" : false,
      "id_str" : "227493010",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2257082551\/DSCF9612_normal.jpg",
      "id" : 227493010,
      "verified" : false
    }
  },
  "id" : 222707686897221632,
  "created_at" : "2012-07-10 15:03:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222683946603905024",
  "geo" : { },
  "id_str" : "222685155603656705",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I got to my desk before you did. Definition of outran - look it up. It is binary - I got the prior to you!",
  "id" : 222685155603656705,
  "in_reply_to_status_id" : 222683946603905024,
  "created_at" : "2012-07-10 13:34:13 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 15, 29 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222682272103542787",
  "text" : "I just out ran @jenporterhall I kid you not!",
  "id" : 222682272103542787,
  "created_at" : "2012-07-10 13:22:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mannight",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222586559038361602",
  "geo" : { },
  "id_str" : "222610866594529280",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley I'm there!!! #mannight",
  "id" : 222610866594529280,
  "in_reply_to_status_id" : 222586559038361602,
  "created_at" : "2012-07-10 08:39:01 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 17, 25 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222465950476279808",
  "geo" : { },
  "id_str" : "222467243328548864",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @havoct5 mick he got some mattress to fuck a bird on as he has only an air one. I got a wanking pillow x",
  "id" : 222467243328548864,
  "in_reply_to_status_id" : 222465950476279808,
  "created_at" : "2012-07-09 23:08:18 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 9, 25 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222465621026283522",
  "geo" : { },
  "id_str" : "222465868804800513",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @michaelnsimpson tweet some pics ;)",
  "id" : 222465868804800513,
  "in_reply_to_status_id" : 222465621026283522,
  "created_at" : "2012-07-09 23:02:50 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222461406761598976",
  "geo" : { },
  "id_str" : "222461678112092160",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 I fucking love it... It's my wank material...",
  "id" : 222461678112092160,
  "in_reply_to_status_id" : 222461406761598976,
  "created_at" : "2012-07-09 22:46:11 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222435775747330048",
  "geo" : { },
  "id_str" : "222443487092674561",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson the amount of yapping you did though...",
  "id" : 222443487092674561,
  "in_reply_to_status_id" : 222435775747330048,
  "created_at" : "2012-07-09 21:33:54 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222427802048282624",
  "geo" : { },
  "id_str" : "222428039437500416",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson pretty sure current Stevie could have pushed her into the boot!",
  "id" : 222428039437500416,
  "in_reply_to_status_id" : 222427802048282624,
  "created_at" : "2012-07-09 20:32:31 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckingpizzas",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222420723870871552",
  "geo" : { },
  "id_str" : "222425471655215106",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson you fucking loved it. That girl though... Am in love. Damn you for not circling back! #fuckingpizzas",
  "id" : 222425471655215106,
  "in_reply_to_status_id" : 222420723870871552,
  "created_at" : "2012-07-09 20:22:19 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222399890599329792",
  "text" : "OH: I just bought a sex mattress.",
  "id" : 222399890599329792,
  "created_at" : "2012-07-09 18:40:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222340483547009025",
  "text" : "OH: Bet you I am fucking class with a vagina.",
  "id" : 222340483547009025,
  "created_at" : "2012-07-09 14:44:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222328276704694272",
  "geo" : { },
  "id_str" : "222337435886039040",
  "in_reply_to_user_id" : 567275097,
  "text" : "@JulieAnnBrace @michaelnsimpson I like that hashtag :)",
  "id" : 222337435886039040,
  "in_reply_to_status_id" : 222328276704694272,
  "created_at" : "2012-07-09 14:32:30 +0000",
  "in_reply_to_screen_name" : "Julesb155",
  "in_reply_to_user_id_str" : "567275097",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 21, 37 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222321670893993985",
  "text" : "Two man cards down - @michaelnsimpson does not like lesbians..",
  "id" : 222321670893993985,
  "created_at" : "2012-07-09 13:29:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222316041517268992",
  "geo" : { },
  "id_str" : "222319959827685377",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson as you should... as you should.",
  "id" : 222319959827685377,
  "in_reply_to_status_id" : 222316041517268992,
  "created_at" : "2012-07-09 13:23:03 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222315853025255425",
  "text" : "OH: \"I don't want to be groomed!!\" :D Fucking quality line...",
  "id" : 222315853025255425,
  "created_at" : "2012-07-09 13:06:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222258628877488128",
  "geo" : { },
  "id_str" : "222271914624823296",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke slept past that.. Hit me at around 9:30 :(",
  "id" : 222271914624823296,
  "in_reply_to_status_id" : 222258628877488128,
  "created_at" : "2012-07-09 10:12:08 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222249905488539649",
  "text" : "That moment... You realise... That... It... Is... NOT FUCKING SUNDAY!!!!!!!!!",
  "id" : 222249905488539649,
  "created_at" : "2012-07-09 08:44:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222131938146779136",
  "geo" : { },
  "id_str" : "222239810641858560",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 Also re-grout your tiles ;)",
  "id" : 222239810641858560,
  "in_reply_to_status_id" : 222131938146779136,
  "created_at" : "2012-07-09 08:04:34 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222131938146779136",
  "geo" : { },
  "id_str" : "222239495184064512",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 I am only seeing this now... But its got me hard regardless ;)",
  "id" : 222239495184064512,
  "in_reply_to_status_id" : 222131938146779136,
  "created_at" : "2012-07-09 08:03:19 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HaVoCT5\/status\/222131938146779136\/photo\/1",
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/nH4a0F83",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxUr0iLCAAAebqo.jpg",
      "id_str" : "222131938150973440",
      "id" : 222131938150973440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxUr0iLCAAAebqo.jpg",
      "sizes" : [ {
        "h" : 3264,
        "resize" : "fit",
        "w" : 1840
      }, {
        "h" : 1816,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nH4a0F83"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222239332294074368",
  "text" : "RT @HaVoCT5: @swmcc now guess where am tweeting you from :D http:\/\/t.co\/nH4a0F83",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HaVoCT5\/status\/222131938146779136\/photo\/1",
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/nH4a0F83",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AxUr0iLCAAAebqo.jpg",
        "id_str" : "222131938150973440",
        "id" : 222131938150973440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxUr0iLCAAAebqo.jpg",
        "sizes" : [ {
          "h" : 3264,
          "resize" : "fit",
          "w" : 1840
        }, {
          "h" : 1816,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1064,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/nH4a0F83"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222131938146779136",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc now guess where am tweeting you from :D http:\/\/t.co\/nH4a0F83",
    "id" : 222131938146779136,
    "created_at" : "2012-07-09 00:55:56 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 222239332294074368,
  "created_at" : "2012-07-09 08:02:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Perkins",
      "screen_name" : "sueperkins",
      "indices" : [ 3, 14 ],
      "id_str" : "43963184",
      "id" : 43963184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222021902607200257",
  "text" : "RT @sueperkins: I really never thought it would be Andy Murray who'd break my 'crying at sport' cherry.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222019163760246785",
    "text" : "I really never thought it would be Andy Murray who'd break my 'crying at sport' cherry.",
    "id" : 222019163760246785,
    "created_at" : "2012-07-08 17:27:48 +0000",
    "user" : {
      "name" : "Sue Perkins",
      "screen_name" : "sueperkins",
      "protected" : false,
      "id_str" : "43963184",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2732719987\/2bbe18c6675a4dabd17672b6cf90cfa3_normal.png",
      "id" : 43963184,
      "verified" : true
    }
  },
  "id" : 222021902607200257,
  "created_at" : "2012-07-08 17:38:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221949137975918593",
  "text" : "Right fuck this. I am away to Tesco.. I want to watch the match a bit - but Dr. Fucking Who is being interviewd. Milking it much?????",
  "id" : 221949137975918593,
  "created_at" : "2012-07-08 12:49:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea McVeigh",
      "screen_name" : "worldinaglass",
      "indices" : [ 3, 17 ],
      "id_str" : "366115249",
      "id" : 366115249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221948332086542337",
  "text" : "RT @worldinaglass: Ladies, save yourself 500 pages of sub-Barbara Cartland pish. If you fancy a fiddle, Google pics of Ashton Kutcher in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "50shadesofgrey",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221947550436044800",
    "text" : "Ladies, save yourself 500 pages of sub-Barbara Cartland pish. If you fancy a fiddle, Google pics of Ashton Kutcher instead #50shadesofgrey",
    "id" : 221947550436044800,
    "created_at" : "2012-07-08 12:43:14 +0000",
    "user" : {
      "name" : "Andrea McVeigh",
      "screen_name" : "worldinaglass",
      "protected" : false,
      "id_str" : "366115249",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2125788138\/Twitter_daffs_normal.jpg",
      "id" : 366115249,
      "verified" : false
    }
  },
  "id" : 221948332086542337,
  "created_at" : "2012-07-08 12:46:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 12, 28 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Sammy Livingstone",
      "screen_name" : "SammyL84",
      "indices" : [ 29, 38 ],
      "id_str" : "49446419",
      "id" : 49446419
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 39, 53 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221947820721192960",
  "geo" : { },
  "id_str" : "221947977453940736",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @michaelnsimpson @SammyL84 @No_Underscore Ohhh an aristocrat....",
  "id" : 221947977453940736,
  "in_reply_to_status_id" : 221947820721192960,
  "created_at" : "2012-07-08 12:44:56 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 17, 28 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Sammy Livingstone",
      "screen_name" : "SammyL84",
      "indices" : [ 29, 38 ],
      "id_str" : "49446419",
      "id" : 49446419
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 39, 53 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221926965182087168",
  "geo" : { },
  "id_str" : "221947675292090368",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @Alana_Doll @SammyL84 @No_Underscore Did you say boojum?????? Who's boojum? Boojum? Boojum?",
  "id" : 221947675292090368,
  "in_reply_to_status_id" : 221926965182087168,
  "created_at" : "2012-07-08 12:43:44 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221947269405093889",
  "text" : "I'm not a fair weather fan, not even a fan really. But if Murray loses wonder how long before he's back to being 'Scottish'....",
  "id" : 221947269405093889,
  "created_at" : "2012-07-08 12:42:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea McVeigh",
      "screen_name" : "worldinaglass",
      "indices" : [ 3, 17 ],
      "id_str" : "366115249",
      "id" : 366115249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "50shadesofgrey",
      "indices" : [ 24, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221938483416141824",
  "text" : "RT @worldinaglass: Tbf, #50shadesofgrey has given me an interest in S&amp;M - in that I now what to severely punish EL James for such ba ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "50shadesofgrey",
        "indices" : [ 5, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221938158189817856",
    "text" : "Tbf, #50shadesofgrey has given me an interest in S&amp;M - in that I now what to severely punish EL James for such badly written, boring tosh",
    "id" : 221938158189817856,
    "created_at" : "2012-07-08 12:05:54 +0000",
    "user" : {
      "name" : "Andrea McVeigh",
      "screen_name" : "worldinaglass",
      "protected" : false,
      "id_str" : "366115249",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2125788138\/Twitter_daffs_normal.jpg",
      "id" : 366115249,
      "verified" : false
    }
  },
  "id" : 221938483416141824,
  "created_at" : "2012-07-08 12:07:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221898175072579585",
  "text" : "Stop playing that bugle and I will not look for you. If you don't, I will look for you, I will find you, and I will kill you! Its Sunday!",
  "id" : 221898175072579585,
  "created_at" : "2012-07-08 09:27:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/221543390146347008\/photo\/1",
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/vozMxs8W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxMUiiCCQAAsYXT.jpg",
      "id_str" : "221543390154735616",
      "id" : 221543390154735616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxMUiiCCQAAsYXT.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/vozMxs8W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221543390146347008",
  "text" : "Think this is what you would call a result :) http:\/\/t.co\/vozMxs8W",
  "id" : 221543390146347008,
  "created_at" : "2012-07-07 09:57:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/geekli.st\" rel=\"nofollow\"\u003EGeeklist Inc\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/pkEkurE7",
      "expanded_url" : "http:\/\/gkl.st\/swmcc",
      "display_url" : "gkl.st\/swmcc"
    }, {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/r6XuN6Vn",
      "expanded_url" : "http:\/\/bit.ly\/Mmv7v6",
      "display_url" : "bit.ly\/Mmv7v6"
    } ]
  },
  "geo" : { },
  "id_str" : "221537993998086144",
  "text" : "Check out my new Geeklist profile http:\/\/t.co\/pkEkurE7. get yours here http:\/\/t.co\/r6XuN6Vn",
  "id" : 221537993998086144,
  "created_at" : "2012-07-07 09:35:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221332414096621568",
  "geo" : { },
  "id_str" : "221355391307624449",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll well get you!!!! Paper hussy!!! :D",
  "id" : 221355391307624449,
  "in_reply_to_status_id" : 221332414096621568,
  "created_at" : "2012-07-06 21:30:12 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221331034757799936",
  "geo" : { },
  "id_str" : "221332261776265216",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll it was a good picture :) You are now Lisburn famous!",
  "id" : 221332261776265216,
  "in_reply_to_status_id" : 221331034757799936,
  "created_at" : "2012-07-06 19:58:18 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 19, 30 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/221330727625691136\/photo\/1",
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/QbyD6ZE2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxJTH8aCEAAyUuz.jpg",
      "id_str" : "221330727634079744",
      "id" : 221330727634079744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxJTH8aCEAAyUuz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/QbyD6ZE2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221330727625691136",
  "text" : "Spotted the lovely @Alana_Doll in the Ulster Star. http:\/\/t.co\/QbyD6ZE2",
  "id" : 221330727625691136,
  "created_at" : "2012-07-06 19:52:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HaVoCT5\/status\/221288723873140738\/photo\/1",
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/lr0mj3pU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxIs7AOCEAEZTzS.jpg",
      "id_str" : "221288723877335041",
      "id" : 221288723877335041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxIs7AOCEAEZTzS.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1840,
        "resize" : "fit",
        "w" : 3264
      } ],
      "display_url" : "pic.twitter.com\/lr0mj3pU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221289557721755649",
  "text" : "RT @HaVoCT5: @swmcc Guess where im tweeting you from http:\/\/t.co\/lr0mj3pU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HaVoCT5\/status\/221288723873140738\/photo\/1",
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/lr0mj3pU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AxIs7AOCEAEZTzS.jpg",
        "id_str" : "221288723877335041",
        "id" : 221288723877335041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxIs7AOCEAEZTzS.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1840,
          "resize" : "fit",
          "w" : 3264
        } ],
        "display_url" : "pic.twitter.com\/lr0mj3pU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "221237417288531969",
    "geo" : { },
    "id_str" : "221288723873140738",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Guess where im tweeting you from http:\/\/t.co\/lr0mj3pU",
    "id" : 221288723873140738,
    "in_reply_to_status_id" : 221237417288531969,
    "created_at" : "2012-07-06 17:05:18 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 221289557721755649,
  "created_at" : "2012-07-06 17:08:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 17, 25 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/221289453149360128\/photo\/1",
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/nIi1dJBi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxItlc_CEAAdn4A.jpg",
      "id_str" : "221289453153554432",
      "id" : 221289453153554432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxItlc_CEAAdn4A.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nIi1dJBi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221289453149360128",
  "text" : "Everyone this is @HaVoCT5 having a crap!!!! http:\/\/t.co\/nIi1dJBi",
  "id" : 221289453149360128,
  "created_at" : "2012-07-06 17:08:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221237417288531969",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 Guess where I am tweeting you from???",
  "id" : 221237417288531969,
  "created_at" : "2012-07-06 13:41:25 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 67, 75 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 106, 118 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221233561603276800",
  "text" : "The word 'chughy' ever heard of it? I think its a made up word and @HaVoCT5 is taking the piss out of me. @ryancunning you don't count!",
  "id" : 221233561603276800,
  "created_at" : "2012-07-06 13:26:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221211972312633344",
  "text" : "OH: \"If I could fuck a smell, this would be it\"",
  "id" : 221211972312633344,
  "created_at" : "2012-07-06 12:00:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 14, 28 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221197050417655809",
  "geo" : { },
  "id_str" : "221197493944320000",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 @chrisknowles_ :D Way to go!!! FUCK the weather Marcus... Good man :)",
  "id" : 221197493944320000,
  "in_reply_to_status_id" : 221197050417655809,
  "created_at" : "2012-07-06 11:02:46 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221196328804421632",
  "text" : "OH: \"Here, Stevie doesn't type one handed...\"",
  "id" : 221196328804421632,
  "created_at" : "2012-07-06 10:58:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCK",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221196203155652608",
  "text" : "*looks out window*.. Right - it is July... What the fuck is the craic with this fucking weather. Not fucking on. #FUCK",
  "id" : 221196203155652608,
  "created_at" : "2012-07-06 10:57:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221182898781433856",
  "geo" : { },
  "id_str" : "221183619828428800",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @michaelnsimpson I LOVE YOU WILLEM :D",
  "id" : 221183619828428800,
  "in_reply_to_status_id" : 221182898781433856,
  "created_at" : "2012-07-06 10:07:39 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 32, 48 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "peptalk",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221182566575775744",
  "text" : "It has become more frequent for @michaelnsimpson to say shout the following at me \"HOW THE FUCK DO YOU FUNCTION!?!?!?!\". #peptalk",
  "id" : 221182566575775744,
  "created_at" : "2012-07-06 10:03:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 5, 19 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221167990975119360",
  "text" : "Poor @peter_omalley is getting it on support today.... Poor bastard.",
  "id" : 221167990975119360,
  "created_at" : "2012-07-06 09:05:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221164514610126849",
  "text" : "MAN CARD DOWN.. MAN CARD DOWN.. One to go!!!",
  "id" : 221164514610126849,
  "created_at" : "2012-07-06 08:51:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Robbins",
      "screen_name" : "indexzero",
      "indices" : [ 3, 13 ],
      "id_str" : "13696102",
      "id" : 13696102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fucki",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221140813575503873",
  "text" : "RT @indexzero: OH: \"I have a bet going on at my office. I am telling my co-worker that you're a real person, he says you're not.\" #fucki ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fuckingrecruiters",
        "indices" : [ 115, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221104582162513920",
    "text" : "OH: \"I have a bet going on at my office. I am telling my co-worker that you're a real person, he says you're not.\" #fuckingrecruiters",
    "id" : 221104582162513920,
    "created_at" : "2012-07-06 04:53:34 +0000",
    "user" : {
      "name" : "Charlie Robbins",
      "screen_name" : "indexzero",
      "protected" : false,
      "id_str" : "13696102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3560668557\/9ca1de87dbf84f8dea2fa5ffa3c97a6e_normal.jpeg",
      "id" : 13696102,
      "verified" : false
    }
  },
  "id" : 221140813575503873,
  "created_at" : "2012-07-06 07:17:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 3, 11 ],
      "id_str" : "15966431",
      "id" : 15966431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221140420846034945",
  "text" : "RT @cobyism: Ted is a very funny movie. Go see it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221140289350418433",
    "text" : "Ted is a very funny movie. Go see it.",
    "id" : 221140289350418433,
    "created_at" : "2012-07-06 07:15:28 +0000",
    "user" : {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "protected" : false,
      "id_str" : "15966431",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3123946980\/3cc09be313449aec5cd1f0eed2865cad_normal.jpeg",
      "id" : 15966431,
      "verified" : false
    }
  },
  "id" : 221140420846034945,
  "created_at" : "2012-07-06 07:15:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 11, 27 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220843043329294336",
  "geo" : { },
  "id_str" : "220843938452480001",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid @michaelnsimpson github have the octogan, twitter have the bird... We have the umberella :D",
  "id" : 220843938452480001,
  "in_reply_to_status_id" : 220843043329294336,
  "created_at" : "2012-07-05 11:37:52 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 37, 50 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "servicerestarttoday",
      "indices" : [ 99, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220838200531353600",
  "text" : "Yeah i ask for a reboot on today and @rickyhassard tells me that I put my earphones in the fridge. #servicerestarttoday",
  "id" : 220838200531353600,
  "created_at" : "2012-07-05 11:15:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 11, 27 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220835614185107456",
  "geo" : { },
  "id_str" : "220837972461883392",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid @michaelnsimpson jump the bastard as all the business nerds are on holiday, newry or newtownnabbey. Thief! :D",
  "id" : 220837972461883392,
  "in_reply_to_status_id" : 220835614185107456,
  "created_at" : "2012-07-05 11:14:10 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220835504793468928",
  "text" : "Right.. where the fuck is the restart button on today?",
  "id" : 220835504793468928,
  "created_at" : "2012-07-05 11:04:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220804850848501760",
  "geo" : { },
  "id_str" : "220807034042458113",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke no way :D That would hurt my head.",
  "id" : 220807034042458113,
  "in_reply_to_status_id" : 220804850848501760,
  "created_at" : "2012-07-05 09:11:13 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220806604361170944",
  "text" : "Yes, I used the last tea-bag in work and didn't replace the box.. That's how I roll :D",
  "id" : 220806604361170944,
  "created_at" : "2012-07-05 09:09:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 1, 15 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 17, 23 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220795221242417154",
  "text" : "\u201C@peter_omalley: @swmcc I never expect you to function well! I am amazed you function full-stop!! :o)\u201D",
  "id" : 220795221242417154,
  "created_at" : "2012-07-05 08:24:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220778463055986689",
  "geo" : { },
  "id_str" : "220792075371814913",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley i am grand... Just do not be expecting me to function well :)",
  "id" : 220792075371814913,
  "in_reply_to_status_id" : 220778463055986689,
  "created_at" : "2012-07-05 08:11:47 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220786958132199424",
  "geo" : { },
  "id_str" : "220791827916271616",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist 18 years... Madness :D",
  "id" : 220791827916271616,
  "in_reply_to_status_id" : 220786958132199424,
  "created_at" : "2012-07-05 08:10:48 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220776073569378304",
  "text" : "FUCKING HELL!!!!!!",
  "id" : 220776073569378304,
  "created_at" : "2012-07-05 07:08:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thicko",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220612718854549504",
  "text" : "Brian Cox.. I want to kiss him in the face and kick him in the nuts. I understand stuff when he explains it - then it leaves me. #thicko",
  "id" : 220612718854549504,
  "created_at" : "2012-07-04 20:19:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220506314630115328",
  "geo" : { },
  "id_str" : "220506466979823617",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke its a nice enough place. Just shit sometimes gets to you :D",
  "id" : 220506466979823617,
  "in_reply_to_status_id" : 220506314630115328,
  "created_at" : "2012-07-04 13:16:53 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "passiveaggressivetweets",
      "indices" : [ 102, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220466535293132801",
  "text" : "like this office used to be really nice - but this last month or two its starting to grind me down... #passiveaggressivetweets",
  "id" : 220466535293132801,
  "created_at" : "2012-07-04 10:38:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220466224709111808",
  "text" : "thankfully they don't involve me but it means that the foot traffic around here is akin to a fucking tescos!",
  "id" : 220466224709111808,
  "created_at" : "2012-07-04 10:36:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220465764128395266",
  "text" : "Don't often bitch about work cos its usually quite good. But the amount of fucking meetings in here lately is getting insane!",
  "id" : 220465764128395266,
  "created_at" : "2012-07-04 10:35:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220444843015544835",
  "text" : "Papyia 2.50, lime 30p... Getting @jenportherhall to make you breakfast in work - priceless and awesome :D",
  "id" : 220444843015544835,
  "created_at" : "2012-07-04 09:12:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webgl",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 88 ],
      "url" : "https:\/\/t.co\/pC5A2U3c",
      "expanded_url" : "https:\/\/developer.mozilla.org\/en-US\/demosdetail\/snappytree\/launch",
      "display_url" : "developer.mozilla.org\/en-US\/demosdet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220444020424445952",
  "text" : "RT @karlton303: snappytree - #webgl procedural tree generation app https:\/\/t.co\/pC5A2U3c",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "webgl",
        "indices" : [ 13, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 72 ],
        "url" : "https:\/\/t.co\/pC5A2U3c",
        "expanded_url" : "https:\/\/developer.mozilla.org\/en-US\/demosdetail\/snappytree\/launch",
        "display_url" : "developer.mozilla.org\/en-US\/demosdet\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217722568721969152",
    "text" : "snappytree - #webgl procedural tree generation app https:\/\/t.co\/pC5A2U3c",
    "id" : 217722568721969152,
    "created_at" : "2012-06-26 20:54:40 +0000",
    "user" : {
      "name" : "Markus Repetschnig",
      "screen_name" : "mars_303",
      "protected" : false,
      "id_str" : "191045082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1571532553\/bla_normal.jpg",
      "id" : 191045082,
      "verified" : false
    }
  },
  "id" : 220444020424445952,
  "created_at" : "2012-07-04 09:08:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220430229242515456",
  "text" : "Came in this morning to a load of commits - time to merge them all with what I have. This wont be fun :) Earphone day I think :)",
  "id" : 220430229242515456,
  "created_at" : "2012-07-04 08:13:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220292052791988224",
  "text" : "I've got the theme from Rawhide going round and round in my head... This cannot lead to good dreams.....",
  "id" : 220292052791988224,
  "created_at" : "2012-07-03 23:04:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 14, 28 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220264783885242368",
  "geo" : { },
  "id_str" : "220272067587735553",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @jenporterhall went well considering :) I didn't curse once or teabag anyone so all in all a success :D",
  "id" : 220272067587735553,
  "in_reply_to_status_id" : 220264783885242368,
  "created_at" : "2012-07-03 21:45:28 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lonely",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220270017101561856",
  "geo" : { },
  "id_str" : "220271640137834496",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams you can come stay with me :D #lonely",
  "id" : 220271640137834496,
  "in_reply_to_status_id" : 220270017101561856,
  "created_at" : "2012-07-03 21:43:46 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220266506351689728",
  "geo" : { },
  "id_str" : "220268839378759680",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams Lusty Beg?",
  "id" : 220268839378759680,
  "in_reply_to_status_id" : 220266506351689728,
  "created_at" : "2012-07-03 21:32:38 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 14, 28 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220263394777903106",
  "geo" : { },
  "id_str" : "220264683410694144",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @jenporterhall you could have made 1k tonight if you'd have swapped buddy :)",
  "id" : 220264683410694144,
  "in_reply_to_status_id" : 220263394777903106,
  "created_at" : "2012-07-03 21:16:07 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220262187162279936",
  "text" : "Door shut - now newsroom... About fucking time!",
  "id" : 220262187162279936,
  "created_at" : "2012-07-03 21:06:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mature",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220187960996405250",
  "geo" : { },
  "id_str" : "220223730083840000",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight family drama lol so being passive aggressive on twitter. #mature :)",
  "id" : 220223730083840000,
  "in_reply_to_status_id" : 220187960996405250,
  "created_at" : "2012-07-03 18:33:23 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220178905242402816",
  "text" : "OH: That's some size of a dump he is having!",
  "id" : 220178905242402816,
  "created_at" : "2012-07-03 15:35:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220147534662873089",
  "text" : "A thousand quid to someone who wants to trade places with me tonight... Seriously - 1k.... :D",
  "id" : 220147534662873089,
  "created_at" : "2012-07-03 13:30:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 10, 26 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220134365118734340",
  "text" : "Just made @michaelnsimpson walk out of the kitchen in disgust :D Takes some skill. Think he actually left the building.. Mike WTFAY? :)",
  "id" : 220134365118734340,
  "created_at" : "2012-07-03 12:38:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 79, 92 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220112082518032384",
  "geo" : { },
  "id_str" : "220120884978003969",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne hell to the no. Just wondering who is gonna.. I have a feeling @stevebiscuit will volunteer :)",
  "id" : 220120884978003969,
  "in_reply_to_status_id" : 220112082518032384,
  "created_at" : "2012-07-03 11:44:43 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220102343453184000",
  "geo" : { },
  "id_str" : "220108430357180416",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne awesome that you are asking this on twitter... \/me gets the popcorn to see what happens :)",
  "id" : 220108430357180416,
  "in_reply_to_status_id" : 220102343453184000,
  "created_at" : "2012-07-03 10:55:13 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220088967285047296",
  "geo" : { },
  "id_str" : "220089729809518594",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc I mean the A1... FUCK SAKE.. ANYWAY - GRUMP STILL STANDS.. PEOPLE JUST FUCK OFF :D",
  "id" : 220089729809518594,
  "in_reply_to_status_id" : 220088967285047296,
  "created_at" : "2012-07-03 09:40:55 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DOINGMYFUCKINGNUTIN",
      "indices" : [ 88, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220088967285047296",
  "text" : "I might as well might as well move my desk to the A21.. About the same FUCKING TRAFFIC! #DOINGMYFUCKINGNUTIN",
  "id" : 220088967285047296,
  "created_at" : "2012-07-03 09:37:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 1, 17 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 82, 88 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220074721377656832",
  "text" : "\"@michaelnsimpson: That moment when you leave your phone unlocked on the desk and @swmcc is lurking about\u2026\" :D Almost got away with it too.",
  "id" : 220074721377656832,
  "created_at" : "2012-07-03 08:41:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220068520745115652",
  "text" : "Still waiting on getting this cup of tea.........",
  "id" : 220068520745115652,
  "created_at" : "2012-07-03 08:16:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220065105101070336",
  "text" : "I just wanted to start the day off with a cup of tea... But so many epic fails just trying to get there. Cleaners and clucking hens.",
  "id" : 220065105101070336,
  "created_at" : "2012-07-03 08:03:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarred McGinnis",
      "screen_name" : "JarredMcGinnis",
      "indices" : [ 3, 18 ],
      "id_str" : "57345997",
      "id" : 57345997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/nCACNEEN",
      "expanded_url" : "http:\/\/jakobwilton.com\/",
      "display_url" : "jakobwilton.com"
    } ]
  },
  "geo" : { },
  "id_str" : "219837426116472832",
  "text" : "RT @JarredMcGinnis: A coworker's 9 year old made a website. http:\/\/t.co\/nCACNEEN He set up google analytic. he'd be thrilled to watch th ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/nCACNEEN",
        "expanded_url" : "http:\/\/jakobwilton.com\/",
        "display_url" : "jakobwilton.com"
      } ]
    },
    "geo" : { },
    "id_str" : "219822785923526656",
    "text" : "A coworker's 9 year old made a website. http:\/\/t.co\/nCACNEEN He set up google analytic. he'd be thrilled to watch the traffic spike. pls RT.",
    "id" : 219822785923526656,
    "created_at" : "2012-07-02 16:00:10 +0000",
    "user" : {
      "name" : "Jarred McGinnis",
      "screen_name" : "JarredMcGinnis",
      "protected" : false,
      "id_str" : "57345997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/316559302\/JarredMcGinnisBW_normal.jpg",
      "id" : 57345997,
      "verified" : false
    }
  },
  "id" : 219837426116472832,
  "created_at" : "2012-07-02 16:58:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219817248557248513",
  "geo" : { },
  "id_str" : "219820154262011904",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr ok I will bite.... Why are you following Ronan Keating? :)",
  "id" : 219820154262011904,
  "in_reply_to_status_id" : 219817248557248513,
  "created_at" : "2012-07-02 15:49:43 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219810126029258753",
  "geo" : { },
  "id_str" : "219819984665313280",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams you are a fucking idiot. Donald Rumsfield did that - worked out well didn't it? ;)",
  "id" : 219819984665313280,
  "in_reply_to_status_id" : 219810126029258753,
  "created_at" : "2012-07-02 15:49:03 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219778621554962432",
  "text" : "OH: \"Go forth and suck todays dick\"... Apt - very apt.",
  "id" : 219778621554962432,
  "created_at" : "2012-07-02 13:04:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 42, 55 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 125 ],
      "url" : "https:\/\/t.co\/1hkE6ZIZ",
      "expanded_url" : "https:\/\/twitter.com\/swmcc\/status\/219545445549096960",
      "display_url" : "twitter.com\/swmcc\/status\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219551011596009473",
  "text" : "This was my 7000th tweet. And it involved @RickyHassard - this week is gonna suck major donkey dick.... https:\/\/t.co\/1hkE6ZIZ",
  "id" : 219551011596009473,
  "created_at" : "2012-07-01 22:00:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 28, 41 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219545801221869568",
  "geo" : { },
  "id_str" : "219546150909382656",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley @rickyhassard I hear by give you my permission to take my share and stick it up his ass or do as you see fit.",
  "id" : 219546150909382656,
  "in_reply_to_status_id" : 219545801221869568,
  "created_at" : "2012-07-01 21:40:56 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 14, 26 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 27, 41 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cheatinggypsybastard",
      "indices" : [ 109, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219544762053701632",
  "geo" : { },
  "id_str" : "219545445549096960",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @Kirstylvssp @peter_omalley if he does I hope he chokes to death on my five quids worth of it. #cheatinggypsybastard",
  "id" : 219545445549096960,
  "in_reply_to_status_id" : 219544762053701632,
  "created_at" : "2012-07-01 21:38:07 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 28, 41 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219543907585884160",
  "geo" : { },
  "id_str" : "219544031510806528",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley @rickyhassard Cheating. Gypsy.",
  "id" : 219544031510806528,
  "in_reply_to_status_id" : 219543907585884160,
  "created_at" : "2012-07-01 21:32:30 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 65, 78 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219534860228902913",
  "geo" : { },
  "id_str" : "219543225826947072",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley he's a cheating Gypsy!!! Inquest!!!! @RickyHassard - INQUEST!!!!!",
  "id" : 219543225826947072,
  "in_reply_to_status_id" : 219534860228902913,
  "created_at" : "2012-07-01 21:29:18 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 7, 15 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219511333731835904",
  "text" : "Right. @HaVoCT5 you better wear something sexy and slutty tomorrow. Cos I am on support and I want something pretty to look at tomorrow! :D",
  "id" : 219511333731835904,
  "created_at" : "2012-07-01 19:22:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219510845535821825",
  "text" : "200 quid to the first person that brings a bacon cheese burger to my house right now. You have 20mins. Then I am making this stir fry.",
  "id" : 219510845535821825,
  "created_at" : "2012-07-01 19:20:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219408044650536961",
  "geo" : { },
  "id_str" : "219410800295686145",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @michaelnsimpson accepted!",
  "id" : 219410800295686145,
  "in_reply_to_status_id" : 219408044650536961,
  "created_at" : "2012-07-01 12:43:05 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 8, 22 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amanasshole",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219407502364774401",
  "text" : "Dammit. @jenporterhall made lovely rice pudding and I forgot clean all about it. Tis still in the Tascomi fridge :( :( #amanasshole",
  "id" : 219407502364774401,
  "created_at" : "2012-07-01 12:29:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]