Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 10, 17 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384637936614260736",
  "geo" : { },
  "id_str" : "384656219635318784",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo @szlwzl wankers! pure wankers.",
  "id" : 384656219635318784,
  "in_reply_to_status_id" : 384637936614260736,
  "created_at" : "2013-09-30 12:29:23 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 3, 14 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384656163280674816",
  "text" : "RT @bigwetfish: No Breaking Bad Spoilers please!  I know it just landed on UK Netflix but no one here will see it until after work ^SK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384652196253806592",
    "text" : "No Breaking Bad Spoilers please!  I know it just landed on UK Netflix but no one here will see it until after work ^SK",
    "id" : 384652196253806592,
    "created_at" : "2013-09-30 12:13:24 +0000",
    "user" : {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "protected" : false,
      "id_str" : "21522311",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/624259936\/fish_normal.jpg",
      "id" : 21522311,
      "verified" : false
    }
  },
  "id" : 384656163280674816,
  "created_at" : "2013-09-30 12:29:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maurice Kelly",
      "screen_name" : "mauricerkelly",
      "indices" : [ 0, 14 ],
      "id_str" : "26198408",
      "id" : 26198408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384608965419888640",
  "geo" : { },
  "id_str" : "384616040933519360",
  "in_reply_to_user_id" : 26198408,
  "text" : "@mauricerkelly dunno. I probably still run it in more from my anal screen views. I love it so far though using it for the past 2 months.",
  "id" : 384616040933519360,
  "in_reply_to_status_id" : 384608965419888640,
  "created_at" : "2013-09-30 09:49:44 +0000",
  "in_reply_to_screen_name" : "mauricerkelly",
  "in_reply_to_user_id_str" : "26198408",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maurice Kelly",
      "screen_name" : "mauricerkelly",
      "indices" : [ 0, 14 ],
      "id_str" : "26198408",
      "id" : 26198408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384602020042534912",
  "geo" : { },
  "id_str" : "384604461374517249",
  "in_reply_to_user_id" : 26198408,
  "text" : "@mauricerkelly :D :D :D",
  "id" : 384604461374517249,
  "in_reply_to_status_id" : 384602020042534912,
  "created_at" : "2013-09-30 09:03:43 +0000",
  "in_reply_to_screen_name" : "mauricerkelly",
  "in_reply_to_user_id_str" : "26198408",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hugegeekthatway",
      "indices" : [ 71, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384603220762300416",
  "geo" : { },
  "id_str" : "384604415165865984",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher really - I can't wait to check the twitter stats on it. #hugegeekthatway. Hopefully you got no spoilers.",
  "id" : 384604415165865984,
  "in_reply_to_status_id" : 384603220762300416,
  "created_at" : "2013-09-30 09:03:32 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384600909977632768",
  "text" : "Haven't read any tweets this morning due to spoilers....",
  "id" : 384600909977632768,
  "created_at" : "2013-09-30 08:49:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/384600718306340864\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/PV9BmBDno2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVZgUMuCcAAx9Dm.png",
      "id_str" : "384600718314729472",
      "id" : 384600718314729472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVZgUMuCcAAx9Dm.png",
      "sizes" : [ {
        "h" : 197,
        "resize" : "fit",
        "w" : 247
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 247
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 247
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 247
      } ],
      "display_url" : "pic.twitter.com\/PV9BmBDno2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/9rV6JkHTe2",
      "expanded_url" : "https:\/\/gist.github.com\/swmcc\/5657497",
      "display_url" : "gist.github.com\/swmcc\/5657497"
    } ]
  },
  "geo" : { },
  "id_str" : "384600718306340864",
  "text" : "And thanks to my 'start_development' script on all my repos I am back quickly - https:\/\/t.co\/9rV6JkHTe2 http:\/\/t.co\/PV9BmBDno2",
  "id" : 384600718306340864,
  "created_at" : "2013-09-30 08:48:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/384600043937746944\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/UmnMDAH1lQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVZfs8gCUAAP-3F.png",
      "id_str" : "384600043946135552",
      "id" : 384600043946135552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVZfs8gCUAAP-3F.png",
      "sizes" : [ {
        "h" : 131,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 296
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 296
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 296
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 296
      } ],
      "display_url" : "pic.twitter.com\/UmnMDAH1lQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384600043937746944",
  "text" : "Shite - seems my laptop did a hard reboot sometime on Sunday. All tmux sessions gone :( http:\/\/t.co\/UmnMDAH1lQ",
  "id" : 384600043937746944,
  "created_at" : "2013-09-30 08:46:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384400255938465792",
  "text" : "Inter web blackout starts at 2230hours tonight. Breaking Bad embargo. Has to be done.",
  "id" : 384400255938465792,
  "created_at" : "2013-09-29 19:32:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384394560300122113",
  "geo" : { },
  "id_str" : "384395318714200064",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams yay I heart flowers :) :) :) :)",
  "id" : 384395318714200064,
  "in_reply_to_status_id" : 384394560300122113,
  "created_at" : "2013-09-29 19:12:40 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384387233014628352",
  "geo" : { },
  "id_str" : "384393440479678464",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams nice one - is your rabbit under there?",
  "id" : 384393440479678464,
  "in_reply_to_status_id" : 384387233014628352,
  "created_at" : "2013-09-29 19:05:12 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaryMcCall",
      "screen_name" : "MaryTreatTicket",
      "indices" : [ 0, 16 ],
      "id_str" : "512178113",
      "id" : 512178113
    }, {
      "name" : "TreatTicket Belfast",
      "screen_name" : "TreatTicket",
      "indices" : [ 17, 29 ],
      "id_str" : "251564674",
      "id" : 251564674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383910462124871680",
  "geo" : { },
  "id_str" : "383920375429472256",
  "in_reply_to_user_id" : 512178113,
  "text" : "@MaryTreatTicket @TreatTicket congrats :)",
  "id" : 383920375429472256,
  "in_reply_to_status_id" : 383910462124871680,
  "created_at" : "2013-09-28 11:45:25 +0000",
  "in_reply_to_screen_name" : "MaryTreatTicket",
  "in_reply_to_user_id_str" : "512178113",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaryMcCall",
      "screen_name" : "MaryTreatTicket",
      "indices" : [ 3, 19 ],
      "id_str" : "512178113",
      "id" : 512178113
    }, {
      "name" : "TreatTicket Belfast",
      "screen_name" : "TreatTicket",
      "indices" : [ 47, 59 ],
      "id_str" : "251564674",
      "id" : 251564674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BusinessEyeAwards",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383920321918554112",
  "text" : "RT @MaryTreatTicket: Absolutely delighted that @TreatTicket has been shortlsted for Best Online\/Digital Company by the #BusinessEyeAwards. \u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TreatTicket Belfast",
        "screen_name" : "TreatTicket",
        "indices" : [ 26, 38 ],
        "id_str" : "251564674",
        "id" : 251564674
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BusinessEyeAwards",
        "indices" : [ 98, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/LziYcSCVoA",
        "expanded_url" : "http:\/\/bit.ly\/hYXSV",
        "display_url" : "bit.ly\/hYXSV"
      } ]
    },
    "geo" : { },
    "id_str" : "383910462124871680",
    "text" : "Absolutely delighted that @TreatTicket has been shortlsted for Best Online\/Digital Company by the #BusinessEyeAwards. http:\/\/t.co\/LziYcSCVoA",
    "id" : 383910462124871680,
    "created_at" : "2013-09-28 11:06:01 +0000",
    "user" : {
      "name" : "MaryMcCall",
      "screen_name" : "MaryTreatTicket",
      "protected" : false,
      "id_str" : "512178113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3148644315\/8ada3385a4d205a8df2416d56b1b6687_normal.jpeg",
      "id" : 512178113,
      "verified" : false
    }
  },
  "id" : 383920321918554112,
  "created_at" : "2013-09-28 11:45:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383691025887531008",
  "geo" : { },
  "id_str" : "383691099836919809",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl he does - it is amazing!!!!!",
  "id" : 383691099836919809,
  "in_reply_to_status_id" : 383691025887531008,
  "created_at" : "2013-09-27 20:34:21 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383677682573389824",
  "geo" : { },
  "id_str" : "383690885268910081",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl love is gone... Parks is good though :)",
  "id" : 383690885268910081,
  "in_reply_to_status_id" : 383677682573389824,
  "created_at" : "2013-09-27 20:33:30 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383581313313546241",
  "geo" : { },
  "id_str" : "383618827663065088",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore grand stuff... will be next week. I'll bring some bics.",
  "id" : 383618827663065088,
  "in_reply_to_status_id" : 383581313313546241,
  "created_at" : "2013-09-27 15:47:10 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/eKFgwHLj6h",
      "expanded_url" : "http:\/\/goo.gl\/K4AgS0",
      "display_url" : "goo.gl\/K4AgS0"
    } ]
  },
  "geo" : { },
  "id_str" : "383580924249518081",
  "text" : "Willie Frazer is a fuckwit. http:\/\/t.co\/eKFgwHLj6h If I cared about religion I'd become a catholic just to differentiate myself from him.",
  "id" : 383580924249518081,
  "created_at" : "2013-09-27 13:16:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 13, 24 ],
      "id_str" : "14120151",
      "id" : 14120151
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 25, 32 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Instil",
      "screen_name" : "instil",
      "indices" : [ 40, 47 ],
      "id_str" : "804212370",
      "id" : 804212370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383568249356435458",
  "text" : "According to @foursquare @szlwzl was at @instil today - and no lunch invite.... Hmmmm love is gone Si Si.... No stalking for you anymore! :)",
  "id" : 383568249356435458,
  "created_at" : "2013-09-27 12:26:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "indices" : [ 0, 10 ],
      "id_str" : "1248789104",
      "id" : 1248789104
    }, {
      "name" : "Disgruntled Mage",
      "screen_name" : "tyndyll",
      "indices" : [ 11, 19 ],
      "id_str" : "19344990",
      "id" : 19344990
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 20, 27 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 28, 39 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383477038138814465",
  "geo" : { },
  "id_str" : "383564773943558144",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@hadooping @tyndyll @szlwzl @johngirvin cheers Jase :) Been a bit quiet lately settling into a new job but I'll be back soon :)",
  "id" : 383564773943558144,
  "in_reply_to_status_id" : 383477038138814465,
  "created_at" : "2013-09-27 12:12:23 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383560333874724864",
  "geo" : { },
  "id_str" : "383564503981371392",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore Where is FMM based now? Might call in for a cuppa sometime. Working back in the town centre... Bedford Street.",
  "id" : 383564503981371392,
  "in_reply_to_status_id" : 383560333874724864,
  "created_at" : "2013-09-27 12:11:18 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383496613068414978",
  "geo" : { },
  "id_str" : "383513186655150080",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson Hi - get in contact my son :)",
  "id" : 383513186655150080,
  "in_reply_to_status_id" : 383496613068414978,
  "created_at" : "2013-09-27 08:47:23 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383486281478856704",
  "geo" : { },
  "id_str" : "383486431504519169",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I know and two episodes of MF... If only there was a way to see them ASAP.... If only... Just gonna have to wait I guess :)",
  "id" : 383486431504519169,
  "in_reply_to_status_id" : 383486281478856704,
  "created_at" : "2013-09-27 07:01:04 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383344665023774720",
  "geo" : { },
  "id_str" : "383344893114200065",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I\u2019ve tried a few times but just couldn\u2019t see it through.",
  "id" : 383344893114200065,
  "in_reply_to_status_id" : 383344665023774720,
  "created_at" : "2013-09-26 21:38:39 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383344000511799296",
  "geo" : { },
  "id_str" : "383344275695874048",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl me either",
  "id" : 383344275695874048,
  "in_reply_to_status_id" : 383344000511799296,
  "created_at" : "2013-09-26 21:36:12 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 0, 9 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382870024379047939",
  "in_reply_to_user_id" : 223516339,
  "text" : "@vduglued SKYPE ;)",
  "id" : 382870024379047939,
  "created_at" : "2013-09-25 14:11:41 +0000",
  "in_reply_to_screen_name" : "vduglued",
  "in_reply_to_user_id_str" : "223516339",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382458347607584768",
  "geo" : { },
  "id_str" : "382479249904373760",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley FUCK YOU AND HAPPY BIRTHDAY :)",
  "id" : 382479249904373760,
  "in_reply_to_status_id" : 382458347607584768,
  "created_at" : "2013-09-24 12:18:53 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Bole",
      "screen_name" : "MichaelBole",
      "indices" : [ 20, 32 ],
      "id_str" : "197615538",
      "id" : 197615538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382428969284276224",
  "text" : "Just for the record @michaelbole does look really sick today....",
  "id" : 382428969284276224,
  "created_at" : "2013-09-24 08:59:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382251327168184320",
  "text" : "Breaking Bad - applause!!!!!!!",
  "id" : 382251327168184320,
  "created_at" : "2013-09-23 21:13:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david holmes",
      "screen_name" : "Holmes7David",
      "indices" : [ 56, 69 ],
      "id_str" : "552871219",
      "id" : 552871219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382151035717816320",
  "text" : "Coming up for air just to say - coding and listening to @Holmes7David is fucking awesome.",
  "id" : 382151035717816320,
  "created_at" : "2013-09-23 14:34:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382063882766151680",
  "geo" : { },
  "id_str" : "382112967849828352",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu how is the wall looking?",
  "id" : 382112967849828352,
  "in_reply_to_status_id" : 382063882766151680,
  "created_at" : "2013-09-23 12:03:25 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382060946510073856",
  "geo" : { },
  "id_str" : "382061172565872640",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu well its more so that we know.",
  "id" : 382061172565872640,
  "in_reply_to_status_id" : 382060946510073856,
  "created_at" : "2013-09-23 08:37:36 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382059976837300224",
  "geo" : { },
  "id_str" : "382060340499853312",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu there was nothing any of us could have done. That work was booked in advance :(",
  "id" : 382060340499853312,
  "in_reply_to_status_id" : 382059976837300224,
  "created_at" : "2013-09-23 08:34:18 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382059536615759872",
  "geo" : { },
  "id_str" : "382059788466540544",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu you should go out and ask.",
  "id" : 382059788466540544,
  "in_reply_to_status_id" : 382059536615759872,
  "created_at" : "2013-09-23 08:32:06 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382054332319137792",
  "geo" : { },
  "id_str" : "382058057452109825",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu No! I didn't see him at all - his car was away all weekend :( Chainsaws?",
  "id" : 382058057452109825,
  "in_reply_to_status_id" : 382054332319137792,
  "created_at" : "2013-09-23 08:25:13 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382034480602427392",
  "text" : "No twitter for me today - just in case someone spoils Breaking Bad for me.....",
  "id" : 382034480602427392,
  "created_at" : "2013-09-23 06:51:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381886204444422144",
  "geo" : { },
  "id_str" : "381886419448635392",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you say potato I say potato ;)",
  "id" : 381886419448635392,
  "in_reply_to_status_id" : 381886204444422144,
  "created_at" : "2013-09-22 21:03:12 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381885989108846592",
  "geo" : { },
  "id_str" : "381886061435445248",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you mean arousing?",
  "id" : 381886061435445248,
  "in_reply_to_status_id" : 381885989108846592,
  "created_at" : "2013-09-22 21:01:46 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burnme",
      "indices" : [ 28, 35 ]
    }, {
      "text" : "makemebleed",
      "indices" : [ 36, 48 ]
    }, {
      "text" : "onallfours",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381885594760392704",
  "geo" : { },
  "id_str" : "381885748313858048",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl yes please!!!!!!!!! #burnme #makemebleed #onallfours?",
  "id" : 381885748313858048,
  "in_reply_to_status_id" : 381885594760392704,
  "created_at" : "2013-09-22 21:00:32 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381884832265297921",
  "geo" : { },
  "id_str" : "381885328979927040",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl surely toast is supposed to be cold? If its perparedthe old fashioned way.",
  "id" : 381885328979927040,
  "in_reply_to_status_id" : 381884832265297921,
  "created_at" : "2013-09-22 20:58:52 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381883846436065280",
  "geo" : { },
  "id_str" : "381884438113955841",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl the cinder path was in full use at Whitaker Towers then\u2026.",
  "id" : 381884438113955841,
  "in_reply_to_status_id" : 381883846436065280,
  "created_at" : "2013-09-22 20:55:19 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381878288454778880",
  "geo" : { },
  "id_str" : "381883152563990528",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl do not speak ill of the dontown not when you watch that model drivel. Suppose it reminds you of yer childhood ya toff ;)",
  "id" : 381883152563990528,
  "in_reply_to_status_id" : 381878288454778880,
  "created_at" : "2013-09-22 20:50:13 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 3, 15 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381881497978171393",
  "text" : "RT @angryjogger: On a more positive note, this time last week I was shitting in a hedge in Belfast Harbour. So you know. Things could be wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381872838128697344",
    "text" : "On a more positive note, this time last week I was shitting in a hedge in Belfast Harbour. So you know. Things could be worse.",
    "id" : 381872838128697344,
    "created_at" : "2013-09-22 20:09:14 +0000",
    "user" : {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "protected" : false,
      "id_str" : "456868224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3538949975\/0e76b405cf65b63487e8da87d3494077_normal.jpeg",
      "id" : 456868224,
      "verified" : false
    }
  },
  "id" : 381881497978171393,
  "created_at" : "2013-09-22 20:43:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/VcZVjiZcid",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/tumblr_l6p29bkQpz1qzmowao1_500.jpg",
      "display_url" : "24.media.tumblr.com\/tumblr_l6p29bk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381838015691120640",
  "text" : "Dontown Abbey starts tonight..... http:\/\/t.co\/VcZVjiZcid",
  "id" : 381838015691120640,
  "created_at" : "2013-09-22 17:50:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381179200960352256",
  "geo" : { },
  "id_str" : "381179671960117248",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 I wasn\u2019t going to bother padding bu sooner or later apps won\u2019t work so might as weel up to date.",
  "id" : 381179671960117248,
  "in_reply_to_status_id" : 381179200960352256,
  "created_at" : "2013-09-20 22:14:50 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 1, 8 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 10, 16 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/v9hqUokj4b",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=kfVsfOSbJY0&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=kfVsfO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381179459082399744",
  "text" : "\u201C@szlwzl: @swmcc let\u2019s ask her. https:\/\/t.co\/v9hqUokj4b sing it Rebecca!\u201D Thought I got away it this week. Wonder how\u2019ll he do it next week?",
  "id" : 381179459082399744,
  "created_at" : "2013-09-20 22:13:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 12, 18 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/DvVc4vE3yy",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=kfVsfOSbJY0&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=kfVsfO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381179318199914496",
  "text" : "RT @szlwzl: @swmcc let's ask her. https:\/\/t.co\/DvVc4vE3yy sing it Rebecca!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/getfalcon.pro\" rel=\"nofollow\"\u003EFalcon-Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/DvVc4vE3yy",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=kfVsfOSbJY0&feature=youtube_gdata_player",
        "display_url" : "youtube.com\/watch?v=kfVsfO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381178721929297920",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc let's ask her. https:\/\/t.co\/DvVc4vE3yy sing it Rebecca!",
    "id" : 381178721929297920,
    "created_at" : "2013-09-20 22:11:03 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 381179318199914496,
  "created_at" : "2013-09-20 22:13:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 20, 27 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381177978325315584",
  "text" : "You are such a knob @szlwzl",
  "id" : 381177978325315584,
  "created_at" : "2013-09-20 22:08:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/381176365627625472\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/FlCvECtgxa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUo14ogCYAAbxap.png",
      "id_str" : "381176365526966272",
      "id" : 381176365526966272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUo14ogCYAAbxap.png",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FlCvECtgxa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381176365627625472",
  "text" : "Fuck sake!!!! I\u2019m updating you English twat!!!!!! http:\/\/t.co\/FlCvECtgxa",
  "id" : 381176365627625472,
  "created_at" : "2013-09-20 22:01:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShiftDock",
      "screen_name" : "shiftdock",
      "indices" : [ 3, 13 ],
      "id_str" : "555532046",
      "id" : 555532046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/U7xoq76oqo",
      "expanded_url" : "http:\/\/blog.shiftdock.com\/2013\/a-new-ShiftDock-shaped-by-you\/",
      "display_url" : "blog.shiftdock.com\/2013\/a-new-Shi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380760339022741507",
  "text" : "RT @shiftdock: Introducing the latest version of ShiftDock, shaped by our users. http:\/\/t.co\/U7xoq76oqo",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/U7xoq76oqo",
        "expanded_url" : "http:\/\/blog.shiftdock.com\/2013\/a-new-ShiftDock-shaped-by-you\/",
        "display_url" : "blog.shiftdock.com\/2013\/a-new-Shi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380757035924455424",
    "text" : "Introducing the latest version of ShiftDock, shaped by our users. http:\/\/t.co\/U7xoq76oqo",
    "id" : 380757035924455424,
    "created_at" : "2013-09-19 18:15:26 +0000",
    "user" : {
      "name" : "ShiftDock",
      "screen_name" : "shiftdock",
      "protected" : false,
      "id_str" : "555532046",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3505651062\/95a88815488e69e405baf681a2814aee_normal.png",
      "id" : 555532046,
      "verified" : false
    }
  },
  "id" : 380760339022741507,
  "created_at" : "2013-09-19 18:28:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 0, 9 ],
      "id_str" : "223516339",
      "id" : 223516339
    }, {
      "name" : "Mark Goody",
      "screen_name" : "marramgrass",
      "indices" : [ 10, 22 ],
      "id_str" : "8358552",
      "id" : 8358552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380741085938868224",
  "geo" : { },
  "id_str" : "380741576382627840",
  "in_reply_to_user_id" : 223516339,
  "text" : "@vduglued @marramgrass good :) No more wordpress bollocks.",
  "id" : 380741576382627840,
  "in_reply_to_status_id" : 380741085938868224,
  "created_at" : "2013-09-19 17:14:00 +0000",
  "in_reply_to_screen_name" : "vduglued",
  "in_reply_to_user_id_str" : "223516339",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Goody",
      "screen_name" : "marramgrass",
      "indices" : [ 0, 12 ],
      "id_str" : "8358552",
      "id" : 8358552
    }, {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 13, 22 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380740945211559936",
  "geo" : { },
  "id_str" : "380741504475492352",
  "in_reply_to_user_id" : 8358552,
  "text" : "@marramgrass @vduglued at burn house, turn right then turn left then turn right then turn left then turn right and go round the long way :)",
  "id" : 380741504475492352,
  "in_reply_to_status_id" : 380740945211559936,
  "created_at" : "2013-09-19 17:13:43 +0000",
  "in_reply_to_screen_name" : "marramgrass",
  "in_reply_to_user_id_str" : "8358552",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 0, 9 ],
      "id_str" : "223516339",
      "id" : 223516339
    }, {
      "name" : "Mark Goody",
      "screen_name" : "marramgrass",
      "indices" : [ 10, 22 ],
      "id_str" : "8358552",
      "id" : 8358552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380739815526117376",
  "geo" : { },
  "id_str" : "380739936502046720",
  "in_reply_to_user_id" : 223516339,
  "text" : "@vduglued @marramgrass yeah, that's never gonna happen :)",
  "id" : 380739936502046720,
  "in_reply_to_status_id" : 380739815526117376,
  "created_at" : "2013-09-19 17:07:29 +0000",
  "in_reply_to_screen_name" : "vduglued",
  "in_reply_to_user_id_str" : "223516339",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 0, 9 ],
      "id_str" : "223516339",
      "id" : 223516339
    }, {
      "name" : "Mark Goody",
      "screen_name" : "marramgrass",
      "indices" : [ 10, 22 ],
      "id_str" : "8358552",
      "id" : 8358552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380739608268783616",
  "geo" : { },
  "id_str" : "380739739269095425",
  "in_reply_to_user_id" : 223516339,
  "text" : "@vduglued @marramgrass By that rationale you live in Donagahdee :)",
  "id" : 380739739269095425,
  "in_reply_to_status_id" : 380739608268783616,
  "created_at" : "2013-09-19 17:06:42 +0000",
  "in_reply_to_screen_name" : "vduglued",
  "in_reply_to_user_id_str" : "223516339",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Goody",
      "screen_name" : "marramgrass",
      "indices" : [ 0, 12 ],
      "id_str" : "8358552",
      "id" : 8358552
    }, {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 17, 26 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380739231922282497",
  "geo" : { },
  "id_str" : "380739396695109632",
  "in_reply_to_user_id" : 8358552,
  "text" : "@marramgrass Oul @vduglued says you live in Glenavy?",
  "id" : 380739396695109632,
  "in_reply_to_status_id" : 380739231922282497,
  "created_at" : "2013-09-19 17:05:20 +0000",
  "in_reply_to_screen_name" : "marramgrass",
  "in_reply_to_user_id_str" : "8358552",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Goody",
      "screen_name" : "marramgrass",
      "indices" : [ 0, 12 ],
      "id_str" : "8358552",
      "id" : 8358552
    }, {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 13, 22 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380738857270251520",
  "geo" : { },
  "id_str" : "380739051709411328",
  "in_reply_to_user_id" : 8358552,
  "text" : "@marramgrass @vduglued it is like being a brick layer and living in a cardboard box.",
  "id" : 380739051709411328,
  "in_reply_to_status_id" : 380738857270251520,
  "created_at" : "2013-09-19 17:03:58 +0000",
  "in_reply_to_screen_name" : "marramgrass",
  "in_reply_to_user_id_str" : "8358552",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 0, 9 ],
      "id_str" : "223516339",
      "id" : 223516339
    }, {
      "name" : "Mark Goody",
      "screen_name" : "marramgrass",
      "indices" : [ 10, 22 ],
      "id_str" : "8358552",
      "id" : 8358552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380738304721047552",
  "geo" : { },
  "id_str" : "380738544207020032",
  "in_reply_to_user_id" : 223516339,
  "text" : "@vduglued @marramgrass smoke signals, drum beats, fucking carrier pigeon... Anything other than wordpress :) I use jekyll :)",
  "id" : 380738544207020032,
  "in_reply_to_status_id" : 380738304721047552,
  "created_at" : "2013-09-19 17:01:57 +0000",
  "in_reply_to_screen_name" : "vduglued",
  "in_reply_to_user_id_str" : "223516339",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Goody",
      "screen_name" : "marramgrass",
      "indices" : [ 0, 12 ],
      "id_str" : "8358552",
      "id" : 8358552
    }, {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 13, 22 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380737824091537408",
  "geo" : { },
  "id_str" : "380738124336214016",
  "in_reply_to_user_id" : 8358552,
  "text" : "@marramgrass @vduglued wordpress... wordpress.. we need to have words Aaron :)",
  "id" : 380738124336214016,
  "in_reply_to_status_id" : 380737824091537408,
  "created_at" : "2013-09-19 17:00:17 +0000",
  "in_reply_to_screen_name" : "marramgrass",
  "in_reply_to_user_id_str" : "8358552",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380409957386301440",
  "geo" : { },
  "id_str" : "380412018572144641",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir ack sure it\u2019s not a big upgrade on the OS front. Good luck.",
  "id" : 380412018572144641,
  "in_reply_to_status_id" : 380409957386301440,
  "created_at" : "2013-09-18 19:24:27 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/380399987672096768\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/o9CK3eQLBL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUdzxfoCIAAWrXk.jpg",
      "id_str" : "380399987676291072",
      "id" : 380399987676291072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUdzxfoCIAAWrXk.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/o9CK3eQLBL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380399987672096768",
  "text" : "I might be gone for quite some time. http:\/\/t.co\/o9CK3eQLBL",
  "id" : 380399987672096768,
  "created_at" : "2013-09-18 18:36:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "developerhug",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380397840725323777",
  "geo" : { },
  "id_str" : "380399196853260288",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir oh nasty :( Let me know how that goes. #developerhug",
  "id" : 380399196853260288,
  "in_reply_to_status_id" : 380397840725323777,
  "created_at" : "2013-09-18 18:33:30 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380345739605319681",
  "text" : "OH: \"I see Boardwalk Empire like Java. Alright but essentially shite\"",
  "id" : 380345739605319681,
  "created_at" : "2013-09-18 15:01:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "explainsit",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379988045715341313",
  "text" : "Found myself getting cross for no reason there.... Well there was a reason. Background music on the earphones was James Blunt. #explainsit",
  "id" : 379988045715341313,
  "created_at" : "2013-09-17 15:19:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harlem Cafe Belfast",
      "screen_name" : "Harlembelfast",
      "indices" : [ 16, 30 ],
      "id_str" : "833718595",
      "id" : 833718595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379958694642872320",
  "text" : "Great coffee at @Harlembelfast - but paying for a takeaway coffee is kinda annoying since you have to pay at the other end.",
  "id" : 379958694642872320,
  "created_at" : "2013-09-17 13:23:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379890031181049857",
  "text" : "Number of hours slept last night - 2 :( I am gonna find the rat bastard that has given me the cold and skin them alive.",
  "id" : 379890031181049857,
  "created_at" : "2013-09-17 08:50:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379652975779930114",
  "geo" : { },
  "id_str" : "379700480290463744",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin congrats :)",
  "id" : 379700480290463744,
  "in_reply_to_status_id" : 379652975779930114,
  "created_at" : "2013-09-16 20:17:03 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379686335256494080",
  "text" : "Breaking Bad just surpassed The Wire in my estimation\u2026. Two to go\u2026.",
  "id" : 379686335256494080,
  "created_at" : "2013-09-16 19:20:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379645773086220288",
  "geo" : { },
  "id_str" : "379645945236840449",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I just got your irc message today - whats your personal email address? :)",
  "id" : 379645945236840449,
  "in_reply_to_status_id" : 379645773086220288,
  "created_at" : "2013-09-16 16:40:21 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379585699189493760",
  "text" : "I have to be guarantor for someone. So far - 5 docs signe, \u00A3 statements, cc check and employment. Now I need to sign something in person!",
  "id" : 379585699189493760,
  "created_at" : "2013-09-16 12:40:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Translink",
      "screen_name" : "Translink_NI",
      "indices" : [ 0, 13 ],
      "id_str" : "118677636",
      "id" : 118677636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379535067561099264",
  "geo" : { },
  "id_str" : "379545919588274176",
  "in_reply_to_user_id" : 118677636,
  "text" : "@Translink_NI cheers :)",
  "id" : 379545919588274176,
  "in_reply_to_status_id" : 379535067561099264,
  "created_at" : "2013-09-16 10:02:53 +0000",
  "in_reply_to_screen_name" : "Translink_NI",
  "in_reply_to_user_id_str" : "118677636",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Translink",
      "screen_name" : "Translink_NI",
      "indices" : [ 0, 13 ],
      "id_str" : "118677636",
      "id" : 118677636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379528166731431936",
  "geo" : { },
  "id_str" : "379531829897736192",
  "in_reply_to_user_id" : 118677636,
  "text" : "@Translink_NI thanks. I currently have a card for the blacks rd journey - can I put this journey on that card as well?",
  "id" : 379531829897736192,
  "in_reply_to_status_id" : 379528166731431936,
  "created_at" : "2013-09-16 09:06:54 +0000",
  "in_reply_to_screen_name" : "Translink_NI",
  "in_reply_to_user_id_str" : "118677636",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Translink",
      "screen_name" : "Translink_NI",
      "indices" : [ 0, 13 ],
      "id_str" : "118677636",
      "id" : 118677636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379526500187242496",
  "in_reply_to_user_id" : 118677636,
  "text" : "@Translink_NI Hi. Can you tell me how much a monthly ticket would cost on the 106 - Glenavy -&gt; Belfast - please.",
  "id" : 379526500187242496,
  "created_at" : "2013-09-16 08:45:43 +0000",
  "in_reply_to_screen_name" : "Translink_NI",
  "in_reply_to_user_id_str" : "118677636",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 0, 7 ],
      "id_str" : "17843859",
      "id" : 17843859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379321979469586433",
  "geo" : { },
  "id_str" : "379322147614621696",
  "in_reply_to_user_id" : 17843859,
  "text" : "@rtweed Dammit!!! Good spot :)",
  "id" : 379322147614621696,
  "in_reply_to_status_id" : 379321979469586433,
  "created_at" : "2013-09-15 19:13:42 +0000",
  "in_reply_to_screen_name" : "rtweed",
  "in_reply_to_user_id_str" : "17843859",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379319378233544704",
  "geo" : { },
  "id_str" : "379319714062688257",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams It is quite common to leave it. I know of at least four people that never made it past season 2.",
  "id" : 379319714062688257,
  "in_reply_to_status_id" : 379319378233544704,
  "created_at" : "2013-09-15 19:04:01 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379318966826844160",
  "geo" : { },
  "id_str" : "379319151539417089",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I'll shove it down for later. Got too much to watch this weather with Breaking Bad, Empire and Sons.",
  "id" : 379319151539417089,
  "in_reply_to_status_id" : 379318966826844160,
  "created_at" : "2013-09-15 19:01:47 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "xfactor",
      "screen_name" : "xfactor",
      "indices" : [ 9, 17 ],
      "id_str" : "8320582",
      "id" : 8320582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "XFactor",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379318954398732288",
  "text" : "Fuck you @xfactor - reminding us about the heatweave when its blowing a gail outside on a Sunday evening as well. #XFactor",
  "id" : 379318954398732288,
  "created_at" : "2013-09-15 19:01:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379318392450473984",
  "geo" : { },
  "id_str" : "379318583399964672",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger and young. I go to bed between 10 and 11 and still find it hard to get up at 6:30 :)",
  "id" : 379318583399964672,
  "in_reply_to_status_id" : 379318392450473984,
  "created_at" : "2013-09-15 18:59:32 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 3, 15 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379318201898635264",
  "text" : "Yo @angryjogger do you get up at 5:30 every morning and what time do you hit the sack at every night then?",
  "id" : 379318201898635264,
  "created_at" : "2013-09-15 18:58:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379317705389928448",
  "geo" : { },
  "id_str" : "379318080481927168",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I couldn't get into it.",
  "id" : 379318080481927168,
  "in_reply_to_status_id" : 379317705389928448,
  "created_at" : "2013-09-15 18:57:32 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lolcommits",
      "screen_name" : "lolcommits",
      "indices" : [ 3, 14 ],
      "id_str" : "549720483",
      "id" : 549720483
    }, {
      "name" : "Matthew Hutchinson",
      "screen_name" : "matthutchin",
      "indices" : [ 95, 107 ],
      "id_str" : "808420",
      "id" : 808420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/NHYbRQZIOQ",
      "expanded_url" : "https:\/\/f.cloud.github.com\/assets\/40650\/1119431\/1930413c-1a76-11e3-8cbb-f85f210e5bec.gif",
      "display_url" : "f.cloud.github.com\/assets\/40650\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378882184460767232",
  "text" : "RT @lolcommits: lolcommits v0.5 is now out, with animated gif video capture support (thanks to @matthutchin!) https:\/\/t.co\/NHYbRQZIOQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Hutchinson",
        "screen_name" : "matthutchin",
        "indices" : [ 79, 91 ],
        "id_str" : "808420",
        "id" : 808420
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/NHYbRQZIOQ",
        "expanded_url" : "https:\/\/f.cloud.github.com\/assets\/40650\/1119431\/1930413c-1a76-11e3-8cbb-f85f210e5bec.gif",
        "display_url" : "f.cloud.github.com\/assets\/40650\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377811435319209984",
    "text" : "lolcommits v0.5 is now out, with animated gif video capture support (thanks to @matthutchin!) https:\/\/t.co\/NHYbRQZIOQ",
    "id" : 377811435319209984,
    "created_at" : "2013-09-11 15:10:40 +0000",
    "user" : {
      "name" : "lolcommits",
      "screen_name" : "lolcommits",
      "protected" : false,
      "id_str" : "549720483",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2193290017\/lolcommits_logo_300px_normal.png",
      "id" : 549720483,
      "verified" : false
    }
  },
  "id" : 378882184460767232,
  "created_at" : "2013-09-14 14:05:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378809406848516096",
  "geo" : { },
  "id_str" : "378815752435793920",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr happy birthday",
  "id" : 378815752435793920,
  "in_reply_to_status_id" : 378809406848516096,
  "created_at" : "2013-09-14 09:41:28 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378685322588332032",
  "geo" : { },
  "id_str" : "378777091400933376",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl :D Thankfully I went to bed early last night :)",
  "id" : 378777091400933376,
  "in_reply_to_status_id" : 378685322588332032,
  "created_at" : "2013-09-14 07:07:50 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378614166741086208",
  "geo" : { },
  "id_str" : "378614353567956992",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop yes sir. I\u2019m still in shock\u2026.",
  "id" : 378614353567956992,
  "in_reply_to_status_id" : 378614166741086208,
  "created_at" : "2013-09-13 20:21:10 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378600298522357760",
  "geo" : { },
  "id_str" : "378609704974700545",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop let me know what you think",
  "id" : 378609704974700545,
  "in_reply_to_status_id" : 378600298522357760,
  "created_at" : "2013-09-13 20:02:42 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378563823202230272",
  "geo" : { },
  "id_str" : "378593295615528960",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu already done. now fuck off and leave me alone :)",
  "id" : 378593295615528960,
  "in_reply_to_status_id" : 378563823202230272,
  "created_at" : "2013-09-13 18:57:30 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "everyfuckingtimeiforget",
      "indices" : [ 36, 60 ]
    }, {
      "text" : "everyfuckingtime",
      "indices" : [ 82, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378518823264997376",
  "text" : "bundle install --without production #everyfuckingtimeiforget --without production #everyfuckingtime",
  "id" : 378518823264997376,
  "created_at" : "2013-09-13 14:01:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378478187350859777",
  "geo" : { },
  "id_str" : "378505499752165376",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit FUCK. YOU. :)",
  "id" : 378505499752165376,
  "in_reply_to_status_id" : 378478187350859777,
  "created_at" : "2013-09-13 13:08:38 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378469086768152576",
  "geo" : { },
  "id_str" : "378475716003655680",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit coffee tomorrow? :)",
  "id" : 378475716003655680,
  "in_reply_to_status_id" : 378469086768152576,
  "created_at" : "2013-09-13 11:10:17 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378457343026925568",
  "geo" : { },
  "id_str" : "378458135284822016",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl well played asshole :)",
  "id" : 378458135284822016,
  "in_reply_to_status_id" : 378457343026925568,
  "created_at" : "2013-09-13 10:00:25 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 127, 134 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378456840750628864",
  "geo" : { },
  "id_str" : "378457092979314688",
  "in_reply_to_user_id" : 3604141,
  "text" : "It wouldn't be so bad if it was on the minute every minute - but the sneaky english toff has staggered the tweets!!!!! WANKER! @szlwzl",
  "id" : 378457092979314688,
  "in_reply_to_status_id" : 378456840750628864,
  "created_at" : "2013-09-13 09:56:17 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 17, 24 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378454341705035776",
  "geo" : { },
  "id_str" : "378454941318144000",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @szlwzl he's a fucking twat - i have Miley Cryus on full blast on my earphones right now to stop that song from getting in!",
  "id" : 378454941318144000,
  "in_reply_to_status_id" : 378454341705035776,
  "created_at" : "2013-09-13 09:47:44 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 38, 45 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/378453427337981952\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ZZCff99o5k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUCJYxTCcAEKQuB.png",
      "id_str" : "378453427342176257",
      "id" : 378453427342176257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUCJYxTCcAEKQuB.png",
      "sizes" : [ {
        "h" : 149,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 551
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 551
      }, {
        "h" : 92,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 551
      } ],
      "display_url" : "pic.twitter.com\/ZZCff99o5k"
    } ],
    "hashtags" : [ {
      "text" : "ihateyou",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378453427337981952",
  "text" : "Here we fucking go!!!!! #ihateyou \/cc @szlwzl http:\/\/t.co\/ZZCff99o5k",
  "id" : 378453427337981952,
  "created_at" : "2013-09-13 09:41:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maurice Kelly",
      "screen_name" : "mauricerkelly",
      "indices" : [ 0, 14 ],
      "id_str" : "26198408",
      "id" : 26198408
    }, {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 15, 27 ],
      "id_str" : "456868224",
      "id" : 456868224
    }, {
      "name" : "andygough",
      "screen_name" : "andygough",
      "indices" : [ 28, 38 ],
      "id_str" : "16174070",
      "id" : 16174070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "belfast",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378278500014510080",
  "geo" : { },
  "id_str" : "378278768596369408",
  "in_reply_to_user_id" : 26198408,
  "text" : "@mauricerkelly @angryjogger @andygough get him on ##belfast when he gets in :)",
  "id" : 378278768596369408,
  "in_reply_to_status_id" : 378278500014510080,
  "created_at" : "2013-09-12 22:07:41 +0000",
  "in_reply_to_screen_name" : "mauricerkelly",
  "in_reply_to_user_id_str" : "26198408",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    }, {
      "name" : "Maurice Kelly",
      "screen_name" : "mauricerkelly",
      "indices" : [ 57, 71 ],
      "id_str" : "26198408",
      "id" : 26198408
    }, {
      "name" : "andygough",
      "screen_name" : "andygough",
      "indices" : [ 76, 86 ],
      "id_str" : "16174070",
      "id" : 16174070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378231644723093504",
  "geo" : { },
  "id_str" : "378277803218591744",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger Ah right. Good move. You'll be working with @mauricerkelly and @andygough good people. Matt is a good fella. Balls of steel :)",
  "id" : 378277803218591744,
  "in_reply_to_status_id" : 378231644723093504,
  "created_at" : "2013-09-12 22:03:51 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378208544132456448",
  "geo" : { },
  "id_str" : "378213990075097088",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger where you going?",
  "id" : 378213990075097088,
  "in_reply_to_status_id" : 378208544132456448,
  "created_at" : "2013-09-12 17:50:16 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garth Gilmour",
      "screen_name" : "GarthGilmour",
      "indices" : [ 3, 16 ],
      "id_str" : "324050564",
      "id" : 324050564
    }, {
      "name" : "Instil",
      "screen_name" : "instil",
      "indices" : [ 22, 29 ],
      "id_str" : "804212370",
      "id" : 804212370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/JhTXoCRB1k",
      "expanded_url" : "http:\/\/instil.co",
      "display_url" : "instil.co"
    } ]
  },
  "geo" : { },
  "id_str" : "378123858005352449",
  "text" : "RT @GarthGilmour: New @instil site up at http:\/\/t.co\/JhTXoCRB1k Comments very welcome. Note 'random and honest' feedback from deliveries. N\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Instil",
        "screen_name" : "instil",
        "indices" : [ 4, 11 ],
        "id_str" : "804212370",
        "id" : 804212370
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/JhTXoCRB1k",
        "expanded_url" : "http:\/\/instil.co",
        "display_url" : "instil.co"
      } ]
    },
    "geo" : { },
    "id_str" : "378115170645467136",
    "text" : "New @instil site up at http:\/\/t.co\/JhTXoCRB1k Comments very welcome. Note 'random and honest' feedback from deliveries. No pressure then :-)",
    "id" : 378115170645467136,
    "created_at" : "2013-09-12 11:17:36 +0000",
    "user" : {
      "name" : "Garth Gilmour",
      "screen_name" : "GarthGilmour",
      "protected" : false,
      "id_str" : "324050564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1413151243\/GarthCropped_normal.jpg",
      "id" : 324050564,
      "verified" : false
    }
  },
  "id" : 378123858005352449,
  "created_at" : "2013-09-12 11:52:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 13, 27 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 28, 44 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378115741934837760",
  "geo" : { },
  "id_str" : "378115861015314432",
  "in_reply_to_user_id" : 804717,
  "text" : "@niall_adams @ChrisKnowles_ @michaelnsimpson ...was pretty grim... this one hits it home hard.",
  "id" : 378115861015314432,
  "in_reply_to_status_id" : 378115741934837760,
  "created_at" : "2013-09-12 11:20:20 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 13, 27 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 28, 44 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378113349923246080",
  "geo" : { },
  "id_str" : "378115741934837760",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @ChrisKnowles_ @michaelnsimpson You do - but it kinda set the tone for the opening episode next season. Cos I thought last...",
  "id" : 378115741934837760,
  "in_reply_to_status_id" : 378113349923246080,
  "created_at" : "2013-09-12 11:19:52 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disgruntled Mage",
      "screen_name" : "tyndyll",
      "indices" : [ 0, 8 ],
      "id_str" : "19344990",
      "id" : 19344990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/s8W5TBaFIp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ERqsrkwJnJs",
      "display_url" : "youtube.com\/watch?v=ERqsrk\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377832896335470592",
  "geo" : { },
  "id_str" : "377833252544708608",
  "in_reply_to_user_id" : 19344990,
  "text" : "@tyndyll Possibly. But Weezer's Buddy Holly reminds me of windows 95 - video on a 'putter back in 96 was a big deal - http:\/\/t.co\/s8W5TBaFIp",
  "id" : 377833252544708608,
  "in_reply_to_status_id" : 377832896335470592,
  "created_at" : "2013-09-11 16:37:21 +0000",
  "in_reply_to_screen_name" : "tyndyll",
  "in_reply_to_user_id_str" : "19344990",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disgruntled Mage",
      "screen_name" : "tyndyll",
      "indices" : [ 0, 8 ],
      "id_str" : "19344990",
      "id" : 19344990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377828434657181696",
  "geo" : { },
  "id_str" : "377832012054151168",
  "in_reply_to_user_id" : 19344990,
  "text" : "@tyndyll hmmmmm hard call... I would say the best video without a shadow of a doubt... Ahhh MTV back in the early 90's when it was good.",
  "id" : 377832012054151168,
  "in_reply_to_status_id" : 377828434657181696,
  "created_at" : "2013-09-11 16:32:26 +0000",
  "in_reply_to_screen_name" : "tyndyll",
  "in_reply_to_user_id_str" : "19344990",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377829122715553792",
  "text" : "Yeah - mapping ctrl + a for tmux was probably the dumbest thing I have done. And I've done some dumb things... Too late to change?",
  "id" : 377829122715553792,
  "created_at" : "2013-09-11 16:20:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377728376363950080",
  "geo" : { },
  "id_str" : "377728563769638912",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel I wont have a chance to watch them tonight or tomorrow so Friday eeeet eeessssss... Cannae wait! :)",
  "id" : 377728563769638912,
  "in_reply_to_status_id" : 377728376363950080,
  "created_at" : "2013-09-11 09:41:22 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377728128073736192",
  "geo" : { },
  "id_str" : "377728208684068864",
  "in_reply_to_user_id" : 804717,
  "text" : "@jbrevel also... Sons started last night :)",
  "id" : 377728208684068864,
  "in_reply_to_status_id" : 377728128073736192,
  "created_at" : "2013-09-11 09:39:57 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377727924167651328",
  "geo" : { },
  "id_str" : "377728128073736192",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel :D Everything is relative Locko :) Listening to Girls Aloud now :)",
  "id" : 377728128073736192,
  "in_reply_to_status_id" : 377727924167651328,
  "created_at" : "2013-09-11 09:39:38 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/377727538442690560\/photo\/1",
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/qYueqlnHYs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT31MegCcAAVqLs.png",
      "id_str" : "377727538463666176",
      "id" : 377727538463666176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT31MegCcAAVqLs.png",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/qYueqlnHYs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377727538442690560",
  "text" : "Ha! http:\/\/t.co\/qYueqlnHYs",
  "id" : 377727538442690560,
  "created_at" : "2013-09-11 09:37:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377418023721631744",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger I've decided to get my butt in gear after reading your blog :)",
  "id" : 377418023721631744,
  "created_at" : "2013-09-10 13:07:23 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 126, 138 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377417952678510592",
  "text" : "Matt has come such a long way from the boozed up programmer I worked with 4 years ago.. ASP coding and buckfast - good times. @angryjogger",
  "id" : 377417952678510592,
  "created_at" : "2013-09-10 13:07:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/yvw9YFq9nX",
      "expanded_url" : "http:\/\/angryjogger.com\/completing-my-first-ever-ultramarathon-the-titanic-quarter-50k-experience.html",
      "display_url" : "angryjogger.com\/completing-my-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377417660851445760",
  "text" : "Inspirational, funny and fair fucking play to ya Matt! http:\/\/t.co\/yvw9YFq9nX",
  "id" : 377417660851445760,
  "created_at" : "2013-09-10 13:05:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 0, 16 ],
      "id_str" : "25073877",
      "id" : 25073877
    }, {
      "name" : "LovingasaLedbetter",
      "screen_name" : "Y3llowL3dbetter",
      "indices" : [ 17, 33 ],
      "id_str" : "321428850",
      "id" : 321428850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377374141932134400",
  "geo" : { },
  "id_str" : "377415168172367872",
  "in_reply_to_user_id" : 25073877,
  "text" : "@realDonaldTrump @Y3llowL3dbetter Surely its not the governments job to create jobs - that's for business people?",
  "id" : 377415168172367872,
  "in_reply_to_status_id" : 377374141932134400,
  "created_at" : "2013-09-10 12:56:02 +0000",
  "in_reply_to_screen_name" : "realDonaldTrump",
  "in_reply_to_user_id_str" : "25073877",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clock",
      "screen_name" : "clock",
      "indices" : [ 0, 6 ],
      "id_str" : "24866880",
      "id" : 24866880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377108138400710656",
  "geo" : { },
  "id_str" : "377109696244506624",
  "in_reply_to_user_id" : 24866880,
  "text" : "@clock fairly important. It is much better to work with good people than anything else I think. But flexibility ranks high on my list.",
  "id" : 377109696244506624,
  "in_reply_to_status_id" : 377108138400710656,
  "created_at" : "2013-09-09 16:42:12 +0000",
  "in_reply_to_screen_name" : "clock",
  "in_reply_to_user_id_str" : "24866880",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377034183891116032",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger amazing, well done.",
  "id" : 377034183891116032,
  "created_at" : "2013-09-09 11:42:09 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376799068581675009",
  "text" : "Tinker Tailor Soldier Spy on now... That'll do pig, that'll do....",
  "id" : 376799068581675009,
  "created_at" : "2013-09-08 20:07:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susanna Reid",
      "screen_name" : "susannareid100",
      "indices" : [ 38, 53 ],
      "id_str" : "19477583",
      "id" : 19477583
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCD2013",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376407486271856640",
  "text" : "Only celeb I recognise on Strictly is @susannareid100 - not that I\u2019m a barometer for celebs though. #SCD2013",
  "id" : 376407486271856640,
  "created_at" : "2013-09-07 18:11:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 13, 21 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 22, 29 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376290195588780032",
  "geo" : { },
  "id_str" : "376323846145863680",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid @jbrevel @szlwzl :)",
  "id" : 376323846145863680,
  "in_reply_to_status_id" : 376290195588780032,
  "created_at" : "2013-09-07 12:39:31 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/376241279681581057\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/JiwpbL0xuB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTitc0jCcAA2KRo.jpg",
      "id_str" : "376241279538982912",
      "id" : 376241279538982912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTitc0jCcAA2KRo.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/JiwpbL0xuB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376241279681581057",
  "text" : "Dumbest dog in the world but I love her regardless. Almost 10 :( http:\/\/t.co\/JiwpbL0xuB",
  "id" : 376241279681581057,
  "created_at" : "2013-09-07 07:11:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 3, 9 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376233327398633472",
  "text" : "RT @Jason: Breaking bad season 4.... Jesus Christ, for the love of god.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376231399805566976",
    "text" : "Breaking bad season 4.... Jesus Christ, for the love of god.",
    "id" : 376231399805566976,
    "created_at" : "2013-09-07 06:32:10 +0000",
    "user" : {
      "name" : "jason",
      "screen_name" : "Jason",
      "protected" : false,
      "id_str" : "3840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1582247652\/Screen_shot_2011-10-10_at_2.54.06_PM_normal.png",
      "id" : 3840,
      "verified" : true
    }
  },
  "id" : 376233327398633472,
  "created_at" : "2013-09-07 06:39:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 3, 15 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 17, 23 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 24, 32 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 33, 40 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376021980496920577",
  "text" : "RT @DebbieCReid: @swmcc @jbrevel @szlwzl Miss you loads, Locko and Dave are pining for you! ;-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "John Loughrey",
        "screen_name" : "jbrevel",
        "indices" : [ 7, 15 ],
        "id_str" : "50685221",
        "id" : 50685221
      }, {
        "name" : "szlwzl",
        "screen_name" : "szlwzl",
        "indices" : [ 16, 23 ],
        "id_str" : "3604141",
        "id" : 3604141
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "375979395313172482",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.5053384966, -5.9557836782 ]
    },
    "id_str" : "376020241270444033",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @jbrevel @szlwzl Miss you loads, Locko and Dave are pining for you! ;-)",
    "id" : 376020241270444033,
    "in_reply_to_status_id" : 375979395313172482,
    "created_at" : "2013-09-06 16:33:06 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "protected" : false,
      "id_str" : "53155256",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000402062796\/48362b18cdee598e45ee405286ad7442_normal.png",
      "id" : 53155256,
      "verified" : false
    }
  },
  "id" : 376021980496920577,
  "created_at" : "2013-09-06 16:40:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 13, 21 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 22, 29 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376020241270444033",
  "geo" : { },
  "id_str" : "376021937673084928",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid @jbrevel @szlwzl Best. Tweet. Ever.",
  "id" : 376021937673084928,
  "in_reply_to_status_id" : 376020241270444033,
  "created_at" : "2013-09-06 16:39:50 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375996372430114816",
  "geo" : { },
  "id_str" : "375998517325471745",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues and the wraith was pretty cool too IIRC.",
  "id" : 375998517325471745,
  "in_reply_to_status_id" : 375996372430114816,
  "created_at" : "2013-09-06 15:06:46 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375994789696913408",
  "geo" : { },
  "id_str" : "375996105210609665",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues Ronan had one good story - when he went back to his home planet - but even that wasn't that well written was just kinda cool",
  "id" : 375996105210609665,
  "in_reply_to_status_id" : 375994789696913408,
  "created_at" : "2013-09-06 14:57:11 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375993831596232705",
  "geo" : { },
  "id_str" : "375994192717049856",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues I liked McKay - the rest I just related to SG which I thought was lazy writing.",
  "id" : 375994192717049856,
  "in_reply_to_status_id" : 375993831596232705,
  "created_at" : "2013-09-06 14:49:35 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375991564801421312",
  "geo" : { },
  "id_str" : "375993570743693312",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe I didn't say SGU was good - I said it has kept well :)",
  "id" : 375993570743693312,
  "in_reply_to_status_id" : 375991564801421312,
  "created_at" : "2013-09-06 14:47:07 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375984883421945856",
  "geo" : { },
  "id_str" : "375991408689037312",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues its being repeated on sky a good bit lately. It has aged badly and the writing is just awful. SGU on the other hand has kept well",
  "id" : 375991408689037312,
  "in_reply_to_status_id" : 375984883421945856,
  "created_at" : "2013-09-06 14:38:32 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 13, 21 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 22, 29 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375978734878482432",
  "geo" : { },
  "id_str" : "375979395313172482",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid @jbrevel @szlwzl Come on Debbie share the love :)",
  "id" : 375979395313172482,
  "in_reply_to_status_id" : 375978734878482432,
  "created_at" : "2013-09-06 13:50:47 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 9, 16 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "missyou",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375975055370362880",
  "geo" : { },
  "id_str" : "375975275273523202",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @szlwzl I work on Bedford Street but we are moving offices soon to be even closer to ya. I owe a lunch anyway I think ;) #missyou",
  "id" : 375975275273523202,
  "in_reply_to_status_id" : 375975055370362880,
  "created_at" : "2013-09-06 13:34:25 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 8, 16 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375972150521626624",
  "geo" : { },
  "id_str" : "375974034170585090",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @jbrevel fuck. you.",
  "id" : 375974034170585090,
  "in_reply_to_status_id" : 375972150521626624,
  "created_at" : "2013-09-06 13:29:29 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    }, {
      "name" : "Barry Adams",
      "screen_name" : "badams",
      "indices" : [ 13, 20 ],
      "id_str" : "10704902",
      "id" : 10704902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375937832549769216",
  "geo" : { },
  "id_str" : "375971337694498816",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger @badams good times though - you know - you coding while getting drunk on Buckfast and working to a stupid deadline for assholes",
  "id" : 375971337694498816,
  "in_reply_to_status_id" : 375937832549769216,
  "created_at" : "2013-09-06 13:18:46 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 46, 53 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 58, 66 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/PB7IWANh5z",
      "expanded_url" : "http:\/\/www.hakkabelfast.co.uk\/",
      "display_url" : "hakkabelfast.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "375971168508854272",
  "text" : "I was out at http:\/\/t.co\/PB7IWANh5z so missed @szlwzl and @jbrevel's tirade of Friday song crapness. Reason #568 to work in Belfast :)",
  "id" : 375971168508854272,
  "created_at" : "2013-09-06 13:18:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "indices" : [ 0, 10 ],
      "id_str" : "1248789104",
      "id" : 1248789104
    }, {
      "name" : "Tara Simpson",
      "screen_name" : "TaraSimpson",
      "indices" : [ 11, 23 ],
      "id_str" : "18995998",
      "id" : 18995998
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 24, 35 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Colin Mitchell",
      "screen_name" : "pixelpage",
      "indices" : [ 36, 46 ],
      "id_str" : "52710181",
      "id" : 52710181
    }, {
      "name" : "Disgruntled Mage",
      "screen_name" : "tyndyll",
      "indices" : [ 47, 55 ],
      "id_str" : "19344990",
      "id" : 19344990
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 56, 63 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375869127124344832",
  "geo" : { },
  "id_str" : "375911224388513792",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@hadooping @TaraSimpson @johngirvin @pixelpage @tyndyll @szlwzl Thanks Jase :)",
  "id" : 375911224388513792,
  "in_reply_to_status_id" : 375869127124344832,
  "created_at" : "2013-09-06 09:19:54 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Adams",
      "screen_name" : "badams",
      "indices" : [ 11, 18 ],
      "id_str" : "10704902",
      "id" : 10704902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375589786586603520",
  "text" : "Hat tip to @badams for having the balls to do say stuff that a good lot of the industry in NI knew already.",
  "id" : 375589786586603520,
  "created_at" : "2013-09-05 12:02:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 3, 10 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Darryl Collins",
      "screen_name" : "darrylxxx",
      "indices" : [ 30, 40 ],
      "id_str" : "1004331",
      "id" : 1004331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375589551667818496",
  "text" : "RT @srushe: Having worked for @darrylxxx previously the best I can say for him is that he proved the value of my joining a union many years\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Darryl Collins",
        "screen_name" : "darrylxxx",
        "indices" : [ 18, 28 ],
        "id_str" : "1004331",
        "id" : 1004331
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375539492020834304",
    "text" : "Having worked for @darrylxxx previously the best I can say for him is that he proved the value of my joining a union many years before.",
    "id" : 375539492020834304,
    "created_at" : "2013-09-05 08:42:46 +0000",
    "user" : {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "protected" : false,
      "id_str" : "761761",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1414429155\/DangerMan_normal.jpg",
      "id" : 761761,
      "verified" : false
    }
  },
  "id" : 375589551667818496,
  "created_at" : "2013-09-05 12:01:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/jJYOW50EfR",
      "expanded_url" : "http:\/\/osrc.dfm.io\/swmcc",
      "display_url" : "osrc.dfm.io\/swmcc"
    } ]
  },
  "geo" : { },
  "id_str" : "375353473153265664",
  "text" : "It must be true :) http:\/\/t.co\/jJYOW50EfR",
  "id" : 375353473153265664,
  "created_at" : "2013-09-04 20:23:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    }, {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 11, 23 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375238474296602625",
  "geo" : { },
  "id_str" : "375261275338461184",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda @StrayTaoist I thought this myself when I found out :) Apple products it is then for at least a year? ;)",
  "id" : 375261275338461184,
  "in_reply_to_status_id" : 375238474296602625,
  "created_at" : "2013-09-04 14:17:14 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374605165023604736",
  "text" : "I don't often burn bridges but when I do I really fucking nuke 'em. Nothing to be proud about just taking note...",
  "id" : 374605165023604736,
  "created_at" : "2013-09-02 18:50:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374559470845960192",
  "geo" : { },
  "id_str" : "374561036101091328",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne fair dos fair dos.",
  "id" : 374561036101091328,
  "in_reply_to_status_id" : 374559470845960192,
  "created_at" : "2013-09-02 15:54:44 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374558672854478848",
  "geo" : { },
  "id_str" : "374558826634022912",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne its Leiah ya fooping Mexican ;)",
  "id" : 374558826634022912,
  "in_reply_to_status_id" : 374558672854478848,
  "created_at" : "2013-09-02 15:45:57 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374543798908751872",
  "geo" : { },
  "id_str" : "374550886892068864",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne at least you knew his name this time ya tart ;)",
  "id" : 374550886892068864,
  "in_reply_to_status_id" : 374543798908751872,
  "created_at" : "2013-09-02 15:14:24 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/374273955487436800\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/ej0L8rLe8R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTGwLetCQAAaDxo.jpg",
      "id_str" : "374273955315466240",
      "id" : 374273955315466240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTGwLetCQAAaDxo.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ej0L8rLe8R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374273955487436800",
  "text" : "Shane and Pippa :) http:\/\/t.co\/ej0L8rLe8R",
  "id" : 374273955487436800,
  "created_at" : "2013-09-01 20:53:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Gibson",
      "screen_name" : "stuartgibson",
      "indices" : [ 3, 16 ],
      "id_str" : "6806292",
      "id" : 6806292
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xfactor",
      "indices" : [ 18, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374259439924424704",
  "text" : "RT @stuartgibson: #xfactor &lt;- This is a hashtag. Fucking use it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "xfactor",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374254491413250048",
    "text" : "#xfactor &lt;- This is a hashtag. Fucking use it.",
    "id" : 374254491413250048,
    "created_at" : "2013-09-01 19:36:38 +0000",
    "user" : {
      "name" : "Stuart Gibson",
      "screen_name" : "stuartgibson",
      "protected" : false,
      "id_str" : "6806292",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000478281384\/bf42b345b5e83f0ecb8e748040d185b6_normal.jpeg",
      "id" : 6806292,
      "verified" : false
    }
  },
  "id" : 374259439924424704,
  "created_at" : "2013-09-01 19:56:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374202816749113344",
  "geo" : { },
  "id_str" : "374259015104339969",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish if it\u2019s not gone ill take it :)",
  "id" : 374259015104339969,
  "in_reply_to_status_id" : 374202816749113344,
  "created_at" : "2013-09-01 19:54:37 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374238265865695232",
  "geo" : { },
  "id_str" : "374242805045940224",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard blog done yet? :)",
  "id" : 374242805045940224,
  "in_reply_to_status_id" : 374238265865695232,
  "created_at" : "2013-09-01 18:50:12 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374144664217337856",
  "geo" : { },
  "id_str" : "374144819792052225",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl but at least I'd be warm Si Si :)",
  "id" : 374144819792052225,
  "in_reply_to_status_id" : 374144664217337856,
  "created_at" : "2013-09-01 12:20:50 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374132572915105793",
  "text" : "My boiler has now stopped working... Fuck, arse and shit.... That's what I say :)",
  "id" : 374132572915105793,
  "created_at" : "2013-09-01 11:32:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374106291242663936",
  "geo" : { },
  "id_str" : "374117667784781824",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit Fucking hipster",
  "id" : 374117667784781824,
  "in_reply_to_status_id" : 374106291242663936,
  "created_at" : "2013-09-01 10:32:57 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]