Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153164377619578880",
  "text" : "Happy New Year twitter ppl!",
  "id" : 153164377619578880,
  "created_at" : "2011-12-31 17:23:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 54, 67 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153164248497922049",
  "text" : "Most irritating person in 2011.. In fact the universe @RickyHassard",
  "id" : 153164248497922049,
  "created_at" : "2011-12-31 17:22:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 43, 50 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 55, 67 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmcc2011awards",
      "indices" : [ 68, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153164059821359105",
  "text" : "Sexiest person I met in 2011... Joint with @srushe and @stimpled0rf #swmcc2011awards",
  "id" : 153164059821359105,
  "created_at" : "2011-12-31 17:22:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 44, 55 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmcc2011awards",
      "indices" : [ 56, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153163930955558912",
  "text" : "Most awesome person I didn't meet in 2011.. @Alana_Doll #swmcc2011awards",
  "id" : 153163930955558912,
  "created_at" : "2011-12-31 17:21:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 37, 52 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmcc2011awards",
      "indices" : [ 53, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153163836243968000",
  "text" : "Most awesome person I met in 2011... @Georgina_Milne #swmcc2011awards",
  "id" : 153163836243968000,
  "created_at" : "2011-12-31 17:21:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 21, 32 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ikindalikedit",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152890155190071298",
  "text" : "Best tweet of 2011: \u201C@magic8lisa: I was just totally hit on by a lesbian in Muriel's. #ikindalikedit\u201D",
  "id" : 152890155190071298,
  "created_at" : "2011-12-30 23:13:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jodie Marsh",
      "screen_name" : "JodieMarsh",
      "indices" : [ 0, 11 ],
      "id_str" : "362602301",
      "id" : 362602301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152873792107065345",
  "geo" : { },
  "id_str" : "152878182163431424",
  "in_reply_to_user_id" : 362602301,
  "text" : "@JodieMarsh what channel is your new show on - and when does it start - next month?",
  "id" : 152878182163431424,
  "in_reply_to_status_id" : 152873792107065345,
  "created_at" : "2011-12-30 22:26:13 +0000",
  "in_reply_to_screen_name" : "JodieMarsh",
  "in_reply_to_user_id_str" : "362602301",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 3, 17 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 19, 25 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152877578414342144",
  "text" : "RT @jenporterhall: @swmcc being in it on black ice on the ballyskeagh rd rates as one of my three near death experiences!! now you can g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "152866895937277953",
    "geo" : { },
    "id_str" : "152869811460902912",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc being in it on black ice on the ballyskeagh rd rates as one of my three near death experiences!! now you can go over 5mph ha ha",
    "id" : 152869811460902912,
    "in_reply_to_status_id" : 152866895937277953,
    "created_at" : "2011-12-30 21:52:57 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "protected" : false,
      "id_str" : "227493010",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2257082551\/DSCF9612_normal.jpg",
      "id" : 227493010,
      "verified" : false
    }
  },
  "id" : 152877578414342144,
  "created_at" : "2011-12-30 22:23:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 79, 93 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152866895937277953",
  "text" : "My car no longer shakes when it brakes and I can go down hills :D In your face @jenporterhall feckin drama queen :D",
  "id" : 152866895937277953,
  "created_at" : "2011-12-30 21:41:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152816770955231232",
  "text" : "Car fixed!!! I can now go down hills again! :)",
  "id" : 152816770955231232,
  "created_at" : "2011-12-30 18:22:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152801472155893762",
  "geo" : { },
  "id_str" : "152803076200341504",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda they want an \"export\" economy though. If only the interweb could be used for that ;)",
  "id" : 152803076200341504,
  "in_reply_to_status_id" : 152801472155893762,
  "created_at" : "2011-12-30 17:27:46 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Adams",
      "screen_name" : "tracy2710",
      "indices" : [ 0, 10 ],
      "id_str" : "241879307",
      "id" : 241879307
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 104, 116 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152740031071666176",
  "in_reply_to_user_id" : 241879307,
  "text" : "@tracy2710 I can just about remember meeting you - but I do remember that you were pure awesome :) Give @niall_adams a hug from me pls :D",
  "id" : 152740031071666176,
  "created_at" : "2011-12-30 13:17:15 +0000",
  "in_reply_to_screen_name" : "tracy2710",
  "in_reply_to_user_id_str" : "241879307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152705161637277697",
  "geo" : { },
  "id_str" : "152739053643644928",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe step all you want.. running hug coming up :)",
  "id" : 152739053643644928,
  "in_reply_to_status_id" : 152705161637277697,
  "created_at" : "2011-12-30 13:13:22 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152706822762008576",
  "geo" : { },
  "id_str" : "152738787657662464",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit Bandit country is civilisation. \/me plays a banjo and readies a cross brow :)",
  "id" : 152738787657662464,
  "in_reply_to_status_id" : 152706822762008576,
  "created_at" : "2011-12-30 13:12:19 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152693167114817536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933511462, -6.2125259832 ]
  },
  "id_str" : "152704800457367554",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe a month without seeing each other warrants a running hug on the 15th.....",
  "id" : 152704800457367554,
  "in_reply_to_status_id" : 152693167114817536,
  "created_at" : "2011-12-30 10:57:16 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152690175208726528",
  "geo" : { },
  "id_str" : "152692955889672192",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe Sorry about that - no car (getting fixed) so am stuck in the house :)",
  "id" : 152692955889672192,
  "in_reply_to_status_id" : 152690175208726528,
  "created_at" : "2011-12-30 10:10:12 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152690175208726528",
  "geo" : { },
  "id_str" : "152692843461345281",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe I just did that..... NO HANG ON... I AM NOT IN WORK :D HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA HA",
  "id" : 152692843461345281,
  "in_reply_to_status_id" : 152690175208726528,
  "created_at" : "2011-12-30 10:09:45 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152404189350346752",
  "text" : "Only getting 760kb\/s download speed right now :(",
  "id" : 152404189350346752,
  "created_at" : "2011-12-29 15:02:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152363991547645952",
  "text" : "Epic fail this year on the eating for free front... Heading to Tesco today... That's only four free eating days at the parents :( :(",
  "id" : 152363991547645952,
  "created_at" : "2011-12-29 12:23:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moz",
      "screen_name" : "wxmmoz",
      "indices" : [ 3, 10 ],
      "id_str" : "72522496",
      "id" : 72522496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mastermind",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152097436444262400",
  "text" : "RT @wxmmoz: Did this woman on #Mastermind really answer 'Jacobs Creek' to the Q 'which sparkling wine is named after the region in NE Fr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mastermind",
        "indices" : [ 18, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "152097290021126144",
    "text" : "Did this woman on #Mastermind really answer 'Jacobs Creek' to the Q 'which sparkling wine is named after the region in NE France it's from'?",
    "id" : 152097290021126144,
    "created_at" : "2011-12-28 18:43:14 +0000",
    "user" : {
      "name" : "Moz",
      "screen_name" : "wxmmoz",
      "protected" : false,
      "id_str" : "72522496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000099173945\/e74e467d3b5af3c19743f4190939a29a_normal.jpeg",
      "id" : 72522496,
      "verified" : false
    }
  },
  "id" : 152097436444262400,
  "created_at" : "2011-12-28 18:43:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152083832865173504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933764792, -6.2126221511 ]
  },
  "id_str" : "152086212574838785",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf *dignified silence*",
  "id" : 152086212574838785,
  "in_reply_to_status_id" : 152083832865173504,
  "created_at" : "2011-12-28 17:59:13 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152083006536953856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5934133092, -6.2124732488 ]
  },
  "id_str" : "152083307457298432",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf not talking to you until you have told me about boardwalk!",
  "id" : 152083307457298432,
  "in_reply_to_status_id" : 152083006536953856,
  "created_at" : "2011-12-28 17:47:40 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152074005745119232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933683315, -6.2126261419 ]
  },
  "id_str" : "152076482037026816",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf AHEM?!?!?????",
  "id" : 152076482037026816,
  "in_reply_to_status_id" : 152074005745119232,
  "created_at" : "2011-12-28 17:20:33 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 41 ],
      "url" : "http:\/\/t.co\/rT4Tkfz",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=hmRVJLhWri0",
      "display_url" : "youtube.com\/watch?v=hmRVJL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "151828383435735040",
  "text" : "Found my soul mate :) http:\/\/t.co\/rT4Tkfz",
  "id" : 151828383435735040,
  "created_at" : "2011-12-28 00:54:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151807640807284736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933536591, -6.2126033669 ]
  },
  "id_str" : "151819483621752832",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues oh without a doubt. Still probably the only good thing on tv since Downton Abbey thus Christmas - yeah, I said it :)",
  "id" : 151819483621752832,
  "in_reply_to_status_id" : 151807640807284736,
  "created_at" : "2011-12-28 00:19:20 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Weasel",
      "screen_name" : "KatieWeasel",
      "indices" : [ 3, 15 ],
      "id_str" : "198880015",
      "id" : 198880015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151782311166357504",
  "text" : "RT @KatieWeasel: Great Expectations, the story of an old woman who invites a 'boy of a certain age' into her home to play...a bit like C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "151737783168413697",
    "text" : "Great Expectations, the story of an old woman who invites a 'boy of a certain age' into her home to play...a bit like Caroline Flack!",
    "id" : 151737783168413697,
    "created_at" : "2011-12-27 18:54:41 +0000",
    "user" : {
      "name" : "Katie Weasel",
      "screen_name" : "KatieWeasel",
      "protected" : false,
      "id_str" : "198880015",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000553255949\/5fa9c7f39dece9d81ac78baffdd2fe5c_normal.jpeg",
      "id" : 198880015,
      "verified" : false
    }
  },
  "id" : 151782311166357504,
  "created_at" : "2011-12-27 21:51:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5932554844, -6.2119232337 ]
  },
  "id_str" : "151782106668859393",
  "text" : "I hate it when tv execs fuck with a classic. Changing parts of Great Expectations. Grrrrr. Dickens had it near perfect!!!",
  "id" : 151782106668859393,
  "created_at" : "2011-12-27 21:50:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933664157, -6.2122776467 ]
  },
  "id_str" : "151316577915117568",
  "text" : "Watching The Searchers with my Dad. It's deffo Christmas... A western from the 1950's.. Awesome.",
  "id" : 151316577915117568,
  "created_at" : "2011-12-26 15:00:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 14, 29 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151314536371195905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933814287, -6.2122971154 ]
  },
  "id_str" : "151316303204974593",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @georgina_milne you driving down to bandit country?? Good luck :)",
  "id" : 151316303204974593,
  "in_reply_to_status_id" : 151314536371195905,
  "created_at" : "2011-12-26 14:59:52 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150720117318230016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933661303, -6.212073558 ]
  },
  "id_str" : "150721592316542976",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery you are still a cunt in my eyes :)",
  "id" : 150721592316542976,
  "in_reply_to_status_id" : 150720117318230016,
  "created_at" : "2011-12-24 23:36:42 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 37, 46 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593377598, -6.2122652816 ]
  },
  "id_str" : "150719498402541569",
  "text" : "Merry Christmas to one and all. Even @slabbery...",
  "id" : 150719498402541569,
  "created_at" : "2011-12-24 23:28:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150717984304930817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933676115, -6.2122802859 ]
  },
  "id_str" : "150718068782399489",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery ya wha?",
  "id" : 150718068782399489,
  "in_reply_to_status_id" : 150717984304930817,
  "created_at" : "2011-12-24 23:22:42 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593367069, -6.2122563242 ]
  },
  "id_str" : "150717667752411137",
  "text" : "The bro just said as he handed my present to me \"I've been quite frugal this year\"... Bastard...",
  "id" : 150717667752411137,
  "created_at" : "2011-12-24 23:21:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150708777103015936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933813478, -6.2122971864 ]
  },
  "id_str" : "150717349429911552",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa depends how low your standards are ;) \/me fixes tie. Have a good one :) merry Christmas :)",
  "id" : 150717349429911552,
  "in_reply_to_status_id" : 150708777103015936,
  "created_at" : "2011-12-24 23:19:50 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 15, 27 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 28, 42 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 43, 55 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 56, 69 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 70, 77 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 78, 90 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150714644426788864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933813193, -6.2122972239 ]
  },
  "id_str" : "150716945094815744",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @ryancunning @jenporterhall @niall_adams @rickyhassard @srushe @stimpled0rf merry Christmas",
  "id" : 150716945094815744,
  "in_reply_to_status_id" : 150714644426788864,
  "created_at" : "2011-12-24 23:18:14 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/150688715012968450\/photo\/1",
      "indices" : [ 35, 54 ],
      "url" : "http:\/\/t.co\/D3P77tl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhdaloJCEAAxgwi.jpg",
      "id_str" : "150688715017162752",
      "id" : 150688715017162752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhdaloJCEAAxgwi.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/D3P77tl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933638967, -6.2125517397 ]
  },
  "id_str" : "150688715012968450",
  "text" : "Gotta love buddies you work with.. http:\/\/t.co\/D3P77tl",
  "id" : 150688715012968450,
  "created_at" : "2011-12-24 21:26:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150685891478822912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933404431, -6.2126493388 ]
  },
  "id_str" : "150686135054639105",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa it's very good.",
  "id" : 150686135054639105,
  "in_reply_to_status_id" : 150685891478822912,
  "created_at" : "2011-12-24 21:15:48 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150665229221638144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933418355, -6.2126393918 ]
  },
  "id_str" : "150677147894300673",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne on how you enjoy the pole and swimming :) pls. Merry Christmas :)",
  "id" : 150677147894300673,
  "in_reply_to_status_id" : 150665229221638144,
  "created_at" : "2011-12-24 20:40:06 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150656024121061377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933227332, -6.2123522784 ]
  },
  "id_str" : "150676883296620544",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams boiling is just wrong. Happy Christmas btw...",
  "id" : 150676883296620544,
  "in_reply_to_status_id" : 150656024121061377,
  "created_at" : "2011-12-24 20:39:03 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150640657470468097",
  "text" : "Forgot to make the soup for tomorrow. FUCK :(",
  "id" : 150640657470468097,
  "created_at" : "2011-12-24 18:15:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 109, 116 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150596258850025472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933485615, -6.2125904935 ]
  },
  "id_str" : "150596741203361792",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues I watched it too. \/) tidying has ceased... Going to start again soon :) Happy Christmas to you and @srushe  :)",
  "id" : 150596741203361792,
  "in_reply_to_status_id" : 150596258850025472,
  "created_at" : "2011-12-24 15:20:35 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150543900837294080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933541112, -6.2125245915 ]
  },
  "id_str" : "150544492469039105",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf that's not festive. For fuck sake man... Christmas Up :D",
  "id" : 150544492469039105,
  "in_reply_to_status_id" : 150543900837294080,
  "created_at" : "2011-12-24 11:52:58 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesomeage",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933418255, -6.2126409599 ]
  },
  "id_str" : "150542363704565760",
  "text" : "So far have watched Santa Claus: The Movie and Jingle All The Way. #awesomeage",
  "id" : 150542363704565760,
  "created_at" : "2011-12-24 11:44:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150523901384994816",
  "text" : "Now to tidy this house in prep for Santa :D",
  "id" : 150523901384994816,
  "created_at" : "2011-12-24 10:31:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pink Swastika Blog",
      "screen_name" : "GodsWordIsLaw",
      "indices" : [ 1, 15 ],
      "id_str" : "403553903",
      "id" : 403553903
    }, {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 17, 28 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933689516, -6.2125830024 ]
  },
  "id_str" : "150303854343372800",
  "text" : "\u201C@GodsWordIsLaw: @MailOnline Thank you so much for featuring me in a non-bias article.\u201D am pissing myself at this one. Fucking idiot :)",
  "id" : 150303854343372800,
  "created_at" : "2011-12-23 19:56:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pink Swastika Blog",
      "screen_name" : "GodsWordIsLaw",
      "indices" : [ 1, 15 ],
      "id_str" : "403553903",
      "id" : 403553903
    }, {
      "name" : "Alice Sheppard",
      "screen_name" : "alij812",
      "indices" : [ 17, 25 ],
      "id_str" : "19486262",
      "id" : 19486262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveSinnerHateSin",
      "indices" : [ 77, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933496833, -6.2125539667 ]
  },
  "id_str" : "150303423974215680",
  "text" : "\u201C@GodsWordIsLaw: @alij812 Im not anti-gay, I'm anti-sodomy. Leviticus 18:22. #LoveSinnerHateSin\u201D You adhere to all sins noted in the bible?",
  "id" : 150303423974215680,
  "created_at" : "2011-12-23 19:55:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150275615260557313",
  "text" : "The bro just rung me asking me about present ideas for the parents and the sis.. Talk about leaving it the last min... Asshole.",
  "id" : 150275615260557313,
  "created_at" : "2011-12-23 18:04:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150221795335745537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933246539, -6.2122552932 ]
  },
  "id_str" : "150234359163658240",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues good film though.",
  "id" : 150234359163658240,
  "in_reply_to_status_id" : 150221795335745537,
  "created_at" : "2011-12-23 15:20:37 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150180776124755970",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.4628886213, -6.0828222111 ]
  },
  "id_str" : "150181095902674944",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley not yet. Destroyed the world though and only got 88k... Stupid ass game!",
  "id" : 150181095902674944,
  "in_reply_to_status_id" : 150180776124755970,
  "created_at" : "2011-12-23 11:48:58 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 13, 23 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150141383209000960",
  "geo" : { },
  "id_str" : "150148980129538048",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @burkazoid Watch it - its good. Well the first 2 seasons are good - then it loses it way a bit - but still ace!",
  "id" : 150148980129538048,
  "in_reply_to_status_id" : 150141383209000960,
  "created_at" : "2011-12-23 09:41:21 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933292614, -6.2126506935 ]
  },
  "id_str" : "149983115169902593",
  "text" : "I'm never shaking hands with anyone ever again!",
  "id" : 149983115169902593,
  "created_at" : "2011-12-22 22:42:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149969622819540994",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593350568, -6.2126354272 ]
  },
  "id_str" : "149972885530873856",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you are awesome. Things will get better. I was there with Rehab. Hang on in there!",
  "id" : 149972885530873856,
  "in_reply_to_status_id" : 149969622819540994,
  "created_at" : "2011-12-22 22:01:36 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 13, 26 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149962908951003136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933513778, -6.2125261003 ]
  },
  "id_str" : "149965657717473280",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @rickyhassard pretty impressive cast on this film. Stars popping up everywhere!",
  "id" : 149965657717473280,
  "in_reply_to_status_id" : 149962908951003136,
  "created_at" : "2011-12-22 21:32:53 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckworkisay",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149961760600891392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933540299, -6.2125234382 ]
  },
  "id_str" : "149962352484290560",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne :( :( :( :( :( It's nearly Christmas is just around the corner. Plus you is awesome. #fuckworkisay",
  "id" : 149962352484290560,
  "in_reply_to_status_id" : 149961760600891392,
  "created_at" : "2011-12-22 21:19:45 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149948174646247424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933671062, -6.2125939155 ]
  },
  "id_str" : "149948490603180032",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne getting it tight? :(",
  "id" : 149948490603180032,
  "in_reply_to_status_id" : 149948174646247424,
  "created_at" : "2011-12-22 20:24:40 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 33, 46 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/149947705597231105\/photo\/1",
      "indices" : [ 78, 97 ],
      "url" : "http:\/\/t.co\/p5nAB9r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhS4pM-CAAAKizZ.jpg",
      "id_str" : "149947705605619712",
      "id" : 149947705605619712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhS4pM-CAAAKizZ.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/p5nAB9r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933543229, -6.2126330443 ]
  },
  "id_str" : "149947705597231105",
  "text" : "Watching Contagion so I can kick @RickyHassard in the Pandemic game tomorrow. http:\/\/t.co\/p5nAB9r",
  "id" : 149947705597231105,
  "created_at" : "2011-12-22 20:21:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149941179293761536",
  "text" : "Sabnzbd forgot my account details there... Very annoying. Getting lots of build errors lately too... Maybe time to move :(",
  "id" : 149941179293761536,
  "created_at" : "2011-12-22 19:55:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149872502498263040",
  "geo" : { },
  "id_str" : "149882532379377664",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb me too.... Am in - but am hoping for a half day.",
  "id" : 149882532379377664,
  "in_reply_to_status_id" : 149872502498263040,
  "created_at" : "2011-12-22 16:02:35 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149867681259077636",
  "geo" : { },
  "id_str" : "149869654041559040",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb half day tomorrow?",
  "id" : 149869654041559040,
  "in_reply_to_status_id" : 149867681259077636,
  "created_at" : "2011-12-22 15:11:24 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Lincoln",
      "screen_name" : "DaveLincoln",
      "indices" : [ 1, 13 ],
      "id_str" : "20432354",
      "id" : 20432354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149850732848357377",
  "text" : "\u201C@DaveLincoln: Dear all people that have already finished work for Christmas: Fuck you. Love from Dave\u201D s\/Dave\/Stephen\/",
  "id" : 149850732848357377,
  "created_at" : "2011-12-22 13:56:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mar\u00EDa Basia ",
      "screen_name" : "maria_basia",
      "indices" : [ 0, 12 ],
      "id_str" : "235508724",
      "id" : 235508724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149832085027299330",
  "geo" : { },
  "id_str" : "149837533814079489",
  "in_reply_to_user_id" : 235508724,
  "text" : "@maria_basia Merry Christmas to you too x",
  "id" : 149837533814079489,
  "in_reply_to_status_id" : 149832085027299330,
  "created_at" : "2011-12-22 13:03:46 +0000",
  "in_reply_to_screen_name" : "maria_basia",
  "in_reply_to_user_id_str" : "235508724",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 31, 46 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 61, 67 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/EhbFNBP",
      "expanded_url" : "http:\/\/tiny.cc\/u11y8",
      "display_url" : "tiny.cc\/u11y8"
    } ]
  },
  "geo" : { },
  "id_str" : "149825039116681216",
  "text" : "The lovely Georgina did this: \u201C@Georgina_Milne: Wee poem for @swmcc about hiking http:\/\/t.co\/EhbFNBP Any more requests for poems?\u201D",
  "id" : 149825039116681216,
  "created_at" : "2011-12-22 12:14:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 7, 19 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149804265488134144",
  "text" : "I miss @stimpled0rf",
  "id" : 149804265488134144,
  "created_at" : "2011-12-22 10:51:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149564874014466049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933369087, -6.2120452858 ]
  },
  "id_str" : "149566243794464768",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams awesome. And buns are on you tomorrow then :)",
  "id" : 149566243794464768,
  "in_reply_to_status_id" : 149564874014466049,
  "created_at" : "2011-12-21 19:05:45 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149559397192966144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933280933, -6.2119863113 ]
  },
  "id_str" : "149563610417475584",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams seriously?",
  "id" : 149563610417475584,
  "in_reply_to_status_id" : 149559397192966144,
  "created_at" : "2011-12-21 18:55:18 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 54, 67 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149498977870557184",
  "geo" : { },
  "id_str" : "149499675068735488",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf fucking shite.... on par with yesterday. @RickyHassard isn't helping to be honest... He laughs when he fucks us up!",
  "id" : 149499675068735488,
  "in_reply_to_status_id" : 149498977870557184,
  "created_at" : "2011-12-21 14:41:14 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149457782221971456",
  "geo" : { },
  "id_str" : "149459713757691904",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa that is a psychologist wet dream that.....",
  "id" : 149459713757691904,
  "in_reply_to_status_id" : 149457782221971456,
  "created_at" : "2011-12-21 12:02:27 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gervais",
      "screen_name" : "rickygervais",
      "indices" : [ 3, 16 ],
      "id_str" : "20015311",
      "id" : 20015311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149449723898638336",
  "text" : "RT @rickygervais: FAQ\nSecond Series of Life's Too Short\nPlanned for spring 2013\nAn Idiot Abroad Special: The Short Way Round planned for ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149447208847147008",
    "text" : "FAQ\nSecond Series of Life's Too Short\nPlanned for spring 2013\nAn Idiot Abroad Special: The Short Way Round planned for end of 2012\nPls RT",
    "id" : 149447208847147008,
    "created_at" : "2011-12-21 11:12:45 +0000",
    "user" : {
      "name" : "Ricky Gervais",
      "screen_name" : "rickygervais",
      "protected" : false,
      "id_str" : "20015311",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3035009585\/93fdaf003d2b213dd6c4d6cae860e76e_normal.jpeg",
      "id" : 20015311,
      "verified" : true
    }
  },
  "id" : 149449723898638336,
  "created_at" : "2011-12-21 11:22:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/dPlaPRH",
      "expanded_url" : "http:\/\/gu.com\/p\/347jb",
      "display_url" : "gu.com\/p\/347jb"
    } ]
  },
  "geo" : { },
  "id_str" : "149435292766568448",
  "text" : "I was just rated 'Gordon Gecko' in the Guardian's 'How revolutionary are you?' test. Try it yourself here: http:\/\/t.co\/dPlaPRH",
  "id" : 149435292766568448,
  "created_at" : "2011-12-21 10:25:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/cwVgaEt",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eM--4UklaL4&?cid=lftwitter_youtube_hobbittrailer",
      "display_url" : "youtube.com\/watch?v=eM--4U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "149418539068039168",
  "text" : "http:\/\/t.co\/cwVgaEt - AWESOME AWESOME. Must give the book a read again for a top up of knowledge on it :)",
  "id" : 149418539068039168,
  "created_at" : "2011-12-21 09:18:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933416285, -6.2126529861 ]
  },
  "id_str" : "149369291647631360",
  "text" : "Been up for the last two hours... Dunno why started another book... But am now watching One Tree Hill.. It is shit!",
  "id" : 149369291647631360,
  "created_at" : "2011-12-21 06:03:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149361399880101888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933498317, -6.2125997768 ]
  },
  "id_str" : "149365310892421120",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you are as awesome as ever! Also WTF you doing up so early, swimming?",
  "id" : 149365310892421120,
  "in_reply_to_status_id" : 149361399880101888,
  "created_at" : "2011-12-21 05:47:19 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Braziel",
      "screen_name" : "Braziel",
      "indices" : [ 0, 8 ],
      "id_str" : "776654",
      "id" : 776654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149253833334329344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5934965, -6.2129849167 ]
  },
  "id_str" : "149254622962388992",
  "in_reply_to_user_id" : 776654,
  "text" : "@Braziel and cooking outside. He needs a slap!",
  "id" : 149254622962388992,
  "in_reply_to_status_id" : 149253833334329344,
  "created_at" : "2011-12-20 22:27:29 +0000",
  "in_reply_to_screen_name" : "Braziel",
  "in_reply_to_user_id_str" : "776654",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149253822018097152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933067667, -6.2125968833 ]
  },
  "id_str" : "149254498529980417",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues I think you misunderstand the list! But you will soon understand :)",
  "id" : 149254498529980417,
  "in_reply_to_status_id" : 149253822018097152,
  "created_at" : "2011-12-20 22:27:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593321331, -6.2125848334 ]
  },
  "id_str" : "149253627675021312",
  "text" : "Am almost finished my Warren Buffett book... That was one hard ass read :)",
  "id" : 149253627675021312,
  "created_at" : "2011-12-20 22:23:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149253089768124416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933651849, -6.2126299827 ]
  },
  "id_str" : "149253417284534272",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues you are now on my list!!!!!!!",
  "id" : 149253417284534272,
  "in_reply_to_status_id" : 149253089768124416,
  "created_at" : "2011-12-20 22:22:42 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5934863167, -6.2129823833 ]
  },
  "id_str" : "149245448782225410",
  "text" : "I should learn to lock my phone...",
  "id" : 149245448782225410,
  "created_at" : "2011-12-20 21:51:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I FOLLOW BACK",
      "screen_name" : "GlRLTHINGS",
      "indices" : [ 3, 14 ],
      "id_str" : "126818692",
      "id" : 126818692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149238564318744576",
  "text" : "RT @GlRLTHINGS: His smile. His eyes. His lips. His hair. His laugh. His hands. His smirk. His humor. His weird faces. RT if you thought  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149235276449980416",
    "text" : "His smile. His eyes. His lips. His hair. His laugh. His hands. His smirk. His humor. His weird faces. RT if you thought of someone.",
    "id" : 149235276449980416,
    "created_at" : "2011-12-20 21:10:37 +0000",
    "user" : {
      "name" : "Classy Tweets\u2122",
      "screen_name" : "SoDamnUs",
      "protected" : false,
      "id_str" : "211722410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000594043608\/2a69c6d993f310aae2be91701e21b267_normal.jpeg",
      "id" : 211722410,
      "verified" : false
    }
  },
  "id" : 149238564318744576,
  "created_at" : "2011-12-20 21:23:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetGlue",
      "screen_name" : "getglue",
      "indices" : [ 34, 42 ],
      "id_str" : "7885972",
      "id" : 7885972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GroundhogDay",
      "indices" : [ 43, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 33 ],
      "url" : "http:\/\/t.co\/vrKI3cz",
      "expanded_url" : "http:\/\/bit.ly\/uoa414",
      "display_url" : "bit.ly\/uoa414"
    } ]
  },
  "geo" : { },
  "id_str" : "149233067981156353",
  "text" : "Awesome!!!!!! http:\/\/t.co\/vrKI3cz @GetGlue #GroundhogDay",
  "id" : 149233067981156353,
  "created_at" : "2011-12-20 21:01:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sonsofbitches",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149155473210355712",
  "text" : "048-bit private keys are required for all SSL and code signing certificates after October 1, 2013. #sonsofbitches",
  "id" : 149155473210355712,
  "created_at" : "2011-12-20 15:53:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149146813046337537",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard has totally fucked today in the ass.....",
  "id" : 149146813046337537,
  "created_at" : "2011-12-20 15:19:05 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149122452507721729",
  "geo" : { },
  "id_str" : "149123168894844928",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne hmmmmm on starting back to climbing up mountains :D",
  "id" : 149123168894844928,
  "in_reply_to_status_id" : 149122452507721729,
  "created_at" : "2011-12-20 13:45:08 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149117624612163584",
  "geo" : { },
  "id_str" : "149119234960662529",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa awesome.... Hope they appreciate the pure awesomeness of that film\/trilogy.",
  "id" : 149119234960662529,
  "in_reply_to_status_id" : 149117624612163584,
  "created_at" : "2011-12-20 13:29:30 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149098139251523585",
  "geo" : { },
  "id_str" : "149098784478072833",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @stimpled0rf I didn't even notice. Pete get a mug shot up will ya :D",
  "id" : 149098784478072833,
  "in_reply_to_status_id" : 149098139251523585,
  "created_at" : "2011-12-20 12:08:14 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Hamill",
      "screen_name" : "gdh_gdh",
      "indices" : [ 0, 8 ],
      "id_str" : "139846667",
      "id" : 139846667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149091745429340160",
  "geo" : { },
  "id_str" : "149093697705881600",
  "in_reply_to_user_id" : 139846667,
  "text" : "@gdh_gdh :D",
  "id" : 149093697705881600,
  "in_reply_to_status_id" : 149091745429340160,
  "created_at" : "2011-12-20 11:48:02 +0000",
  "in_reply_to_screen_name" : "gdh_gdh",
  "in_reply_to_user_id_str" : "139846667",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149086048197148672",
  "geo" : { },
  "id_str" : "149086764785606656",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @stimpled0rf this day sucks donkey dick.",
  "id" : 149086764785606656,
  "in_reply_to_status_id" : 149086048197148672,
  "created_at" : "2011-12-20 11:20:29 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149072003150778368",
  "geo" : { },
  "id_str" : "149079205886431232",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf I would put Boardwalk ahead of Homeland to be fair.. Closely followed by Sons.",
  "id" : 149079205886431232,
  "in_reply_to_status_id" : 149072003150778368,
  "created_at" : "2011-12-20 10:50:27 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933592352, -6.2126964334 ]
  },
  "id_str" : "149046698902171649",
  "text" : "My bro tells me fuck all.. Seems he's playing with the Stereophonics tonight in Shepherds Bush. Said nothing to me last night. Odd fucker!",
  "id" : 149046698902171649,
  "created_at" : "2011-12-20 08:41:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148912788033634304",
  "text" : "Like there are three cars at my folks - you think one of them could do it!!! Too many sibling and folk lifts for me lately...",
  "id" : 148912788033634304,
  "created_at" : "2011-12-19 23:49:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148912655728508928",
  "text" : "Bro rings me at 10:30 for a lift back into Belfast. He was over at my folks since 7:30 apparently :( Getting fed up with lifts grrrrr!!!!",
  "id" : 148912655728508928,
  "created_at" : "2011-12-19 23:48:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148856022092623873",
  "geo" : { },
  "id_str" : "148857683322212352",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf Its fully down :) Now to watch it.... :D Whoooo fucking hoooo.. Life will be so empty after this though... :(",
  "id" : 148857683322212352,
  "in_reply_to_status_id" : 148856022092623873,
  "created_at" : "2011-12-19 20:10:12 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148856022092623873",
  "geo" : { },
  "id_str" : "148856388880310272",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf We shall see. It is verifying now...... *bites nails*",
  "id" : 148856388880310272,
  "in_reply_to_status_id" : 148856022092623873,
  "created_at" : "2011-12-19 20:05:03 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148854967808172032",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf if I get a fail on this download I am just gonna start to cry down the phone to you!!!",
  "id" : 148854967808172032,
  "created_at" : "2011-12-19 19:59:24 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148854470573432832",
  "text" : "Just noticed that spydes now have their hair in a step... That was popular in my day. And yes I used to have hair you twats!!!",
  "id" : 148854470573432832,
  "created_at" : "2011-12-19 19:57:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148697355171012609",
  "text" : "Two processes that were taking up 100% of the CPU.... Hmmmmm...",
  "id" : 148697355171012609,
  "created_at" : "2011-12-19 09:33:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/148509491535691776\/photo\/1",
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/pL0zDYd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ag-cmIFCQAECeB_.jpg",
      "id_str" : "148509491544080385",
      "id" : 148509491544080385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ag-cmIFCQAECeB_.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/pL0zDYd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593364396, -6.2122618712 ]
  },
  "id_str" : "148509491535691776",
  "text" : "I get my sister to text me when she lands so then I can leave now and she has time to get her bags. http:\/\/t.co\/pL0zDYd",
  "id" : 148509491535691776,
  "created_at" : "2011-12-18 21:06:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933352946, -6.2124149117 ]
  },
  "id_str" : "148431941627158528",
  "text" : "Gene Wilder has Willy Wonka with real Ompa Lompas ... Now we are talking!",
  "id" : 148431941627158528,
  "created_at" : "2011-12-18 15:58:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Tracy Adams",
      "screen_name" : "tracy2710",
      "indices" : [ 26, 36 ],
      "id_str" : "241879307",
      "id" : 241879307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148396032324149248",
  "geo" : { },
  "id_str" : "148396376294825985",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @niall_adams @tracy2710 No pics of me on twitter!!! And I wasn't dancing!! I was merely walking in a really weird way!",
  "id" : 148396376294825985,
  "in_reply_to_status_id" : 148396032324149248,
  "created_at" : "2011-12-18 13:37:07 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Tracy Adams",
      "screen_name" : "tracy2710",
      "indices" : [ 13, 23 ],
      "id_str" : "241879307",
      "id" : 241879307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148392806728204288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933668454, -6.2124864405 ]
  },
  "id_str" : "148393981384986627",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @tracy2710 :(",
  "id" : 148393981384986627,
  "in_reply_to_status_id" : 148392806728204288,
  "created_at" : "2011-12-18 13:27:36 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148371594010574848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933716988, -6.212546416 ]
  },
  "id_str" : "148373347758120960",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams am grand. You? I can't mind much of what happened though.. No doubt you'll remind me.",
  "id" : 148373347758120960,
  "in_reply_to_status_id" : 148371594010574848,
  "created_at" : "2011-12-18 12:05:37 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933465688, -6.2125891036 ]
  },
  "id_str" : "148348632171683840",
  "text" : "Fucking flashbacks :( :( :(",
  "id" : 148348632171683840,
  "created_at" : "2011-12-18 10:27:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593363258, -6.2125523123 ]
  },
  "id_str" : "148333195442667520",
  "text" : "Boris on the Andrew Marr Show... \/me gets the popcorn.",
  "id" : 148333195442667520,
  "created_at" : "2011-12-18 09:26:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 15, 28 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148173157457600512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933695566, -6.2126682258 ]
  },
  "id_str" : "148179386733051904",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @rickyhassard Erm.. Rick I think it best if we both just take next week of work. She's gonna slag us all week :(",
  "id" : 148179386733051904,
  "in_reply_to_status_id" : 148173157457600512,
  "created_at" : "2011-12-17 23:14:53 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goforit",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148119359594823681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933829332, -6.2123933139 ]
  },
  "id_str" : "148140305592500224",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa still legal. #goforit",
  "id" : 148140305592500224,
  "in_reply_to_status_id" : 148119359594823681,
  "created_at" : "2011-12-17 20:39:35 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOVEFiLM",
      "screen_name" : "LOVEFiLM",
      "indices" : [ 3, 12 ],
      "id_str" : "19338359",
      "id" : 19338359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148126520802684929",
  "text" : "RT @LOVEFiLM: The Goonies is now available to watch instantly, as part of your package. Perfect weekend viewing, whatever your age! http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/RpGblPUk",
        "expanded_url" : "http:\/\/cot.ag\/ugC6tf",
        "display_url" : "cot.ag\/ugC6tf"
      } ]
    },
    "geo" : { },
    "id_str" : "148112030862286848",
    "text" : "The Goonies is now available to watch instantly, as part of your package. Perfect weekend viewing, whatever your age! http:\/\/t.co\/RpGblPUk",
    "id" : 148112030862286848,
    "created_at" : "2011-12-17 18:47:14 +0000",
    "user" : {
      "name" : "LOVEFiLM",
      "screen_name" : "LOVEFiLM",
      "protected" : false,
      "id_str" : "19338359",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000109151453\/897e9019b89d38a6efb860303b0f73d7_normal.jpeg",
      "id" : 19338359,
      "verified" : false
    }
  },
  "id" : 148126520802684929,
  "created_at" : "2011-12-17 19:44:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 15, 28 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 29, 41 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148069470789828608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59337245, -6.2128588667 ]
  },
  "id_str" : "148072787423145985",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @rickyhassard @stimpled0rf cheers :)",
  "id" : 148072787423145985,
  "in_reply_to_status_id" : 148069470789828608,
  "created_at" : "2011-12-17 16:11:18 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 15, 28 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 29, 41 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 65, 79 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5918827604, -5.8831564592 ]
  },
  "id_str" : "148052632588660736",
  "text" : "WTF! How many? @RickyHassard @stimpled0rf I didn't actually ride @peter_omalley did I?",
  "id" : 148052632588660736,
  "created_at" : "2011-12-17 14:51:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 13, 24 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147990473166954496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5918647698, -5.8831881063 ]
  },
  "id_str" : "148051617621622784",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @magic8lisa you get four a year free... But they take ages. Still waiting on my sofas being lifted.",
  "id" : 148051617621622784,
  "in_reply_to_status_id" : 147990473166954496,
  "created_at" : "2011-12-17 14:47:10 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 33, 47 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 121, 134 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5917969167, -5.8831982167 ]
  },
  "id_str" : "147749598973276160",
  "text" : "Have arrived safe and sound with @jenporterhall ungrateful fecker yapping about a free lift! My car has personality! \/cc @RickyHassard",
  "id" : 147749598973276160,
  "created_at" : "2011-12-16 18:47:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 10, 24 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.53047555, -6.0332100167 ]
  },
  "id_str" : "147741400170119168",
  "text" : "Tick tock @jenporterhall lol... Drinking needs done quickly :)",
  "id" : 147741400170119168,
  "created_at" : "2011-12-16 18:14:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147642271947427840",
  "geo" : { },
  "id_str" : "147654997511905280",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe you are still grumpy!",
  "id" : 147654997511905280,
  "in_reply_to_status_id" : 147642271947427840,
  "created_at" : "2011-12-16 12:31:09 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147449826378915840",
  "geo" : { },
  "id_str" : "147453528909164544",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe I better have the nice happy srushe tomorrow. You sound really grumpy!!! Cheer the fuck up! It is Christmas :D",
  "id" : 147453528909164544,
  "in_reply_to_status_id" : 147449826378915840,
  "created_at" : "2011-12-15 23:10:35 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 14, 26 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147351361690935296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.6001583664, -5.9292959919 ]
  },
  "id_str" : "147370742458224640",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @stimpled0rf what the hell!!!!! War! War has been declared!!!",
  "id" : 147370742458224640,
  "in_reply_to_status_id" : 147351361690935296,
  "created_at" : "2011-12-15 17:41:37 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147345715188858880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5979117167, -5.9325983833 ]
  },
  "id_str" : "147346420599500800",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf Get used to it. I intend to shoot in your face the marra ;) Too far??? Probably. Stand by it though!",
  "id" : 147346420599500800,
  "in_reply_to_status_id" : 147345715188858880,
  "created_at" : "2011-12-15 16:04:58 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147343320178360320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5979816872, -5.9326590782 ]
  },
  "id_str" : "147346219365175296",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard cloth ear. Was fantastic. Here I just bought a rug.. Won't fit in my car... Fuck sake!!",
  "id" : 147346219365175296,
  "in_reply_to_status_id" : 147343320178360320,
  "created_at" : "2011-12-15 16:04:10 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/147342268074967040\/photo\/1",
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/RrYaP8AX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Agt3Ax2CQAAY4Ib.jpg",
      "id_str" : "147342268083355648",
      "id" : 147342268083355648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Agt3Ax2CQAAY4Ib.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RrYaP8AX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5981847333, -5.9326413167 ]
  },
  "id_str" : "147342268074967040",
  "text" : "Just after epic lunch..... Cannot move... http:\/\/t.co\/RrYaP8AX",
  "id" : 147342268074967040,
  "created_at" : "2011-12-15 15:48:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/147313754164572160\/photo\/1",
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/hY2ad1kX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgtdFDPCMAATNCq.jpg",
      "id_str" : "147313754168766464",
      "id" : 147313754168766464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgtdFDPCMAATNCq.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hY2ad1kX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147313754164572160",
  "text" : "Honion Soup http:\/\/t.co\/hY2ad1kX",
  "id" : 147313754164572160,
  "created_at" : "2011-12-15 13:55:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147310660521426944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.6019713117, -5.9264850492 ]
  },
  "id_str" : "147311865834373120",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe ha ha :) Anger Steve... Use it :)",
  "id" : 147311865834373120,
  "in_reply_to_status_id" : 147310660521426944,
  "created_at" : "2011-12-15 13:47:40 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/147283176916660224\/photo\/1",
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/GuUGUxai",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgtBROHCMAAaqkz.jpg",
      "id_str" : "147283176920854528",
      "id" : 147283176920854528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgtBROHCMAAaqkz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/GuUGUxai"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147283176916660224",
  "text" : "Nun!!!! http:\/\/t.co\/GuUGUxai",
  "id" : 147283176916660224,
  "created_at" : "2011-12-15 11:53:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933615961, -6.212146906 ]
  },
  "id_str" : "147084385005469698",
  "text" : ".they were both mistakes and bitter disappointments and that I've been in a terrible accident and the dogs dead. Leaving a phone unguarded.",
  "id" : 147084385005469698,
  "created_at" : "2011-12-14 22:43:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933397937, -6.212136309 ]
  },
  "id_str" : "147082935449825280",
  "text" : "Just got threw out of my parents! Mums phone was on the kitchen table - unguarded. Two texts to siblings stating that...",
  "id" : 147082935449825280,
  "created_at" : "2011-12-14 22:37:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933294293, -6.2126517403 ]
  },
  "id_str" : "147062926283517952",
  "text" : "Steve Wozniak - what a loveable man.. Haven't seen an interview yet where he isn't humble and pleasant.",
  "id" : 147062926283517952,
  "created_at" : "2011-12-14 21:18:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 43, 55 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933367076, -6.2126469605 ]
  },
  "id_str" : "147061605413306370",
  "text" : "I've said it before and I'll say it again. @stimpled0rf is a fucking genius.",
  "id" : 147061605413306370,
  "created_at" : "2011-12-14 21:13:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146960105194274817",
  "geo" : { },
  "id_str" : "146960284689510401",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf You done well you twat!!! Take the compliment for what it is. I'll be feeling you up on Friday night - just so ya know :)",
  "id" : 146960284689510401,
  "in_reply_to_status_id" : 146960105194274817,
  "created_at" : "2011-12-14 14:30:36 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146930988860190720",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf is a fucking genius :D",
  "id" : 146930988860190720,
  "created_at" : "2011-12-14 12:34:12 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 14, 28 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146919371233693698",
  "text" : "In the office @jenporterhall is trying to do a Derry accent. Depending on what she says its either Jamican or Swedish",
  "id" : 146919371233693698,
  "created_at" : "2011-12-14 11:48:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933593583, -6.2126540434 ]
  },
  "id_str" : "146673192826716160",
  "text" : "Here this fucking thing is tweeting my location... Fuck sake!",
  "id" : 146673192826716160,
  "created_at" : "2011-12-13 19:29:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/146672852517658624\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/Fj2Lhuwj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgkWLqkCIAA3XxE.jpg",
      "id_str" : "146672852526047232",
      "id" : 146672852526047232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgkWLqkCIAA3XxE.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/Fj2Lhuwj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933552271, -6.2124548607 ]
  },
  "id_str" : "146672852517658624",
  "text" : "Watching The Inbetweeners film. Then heading to bed. Nabbed a free dinner at my folks cos I am sick ;) http:\/\/t.co\/Fj2Lhuwj",
  "id" : 146672852517658624,
  "created_at" : "2011-12-13 19:28:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zabbix Team",
      "screen_name" : "zabbix",
      "indices" : [ 3, 10 ],
      "id_str" : "127810439",
      "id" : 127810439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/9q6CbLri",
      "expanded_url" : "https:\/\/build.opensuse.org\/project\/show?project=home%3Akodai%3Azabbix",
      "display_url" : "build.opensuse.org\/project\/show?p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "146663276795801600",
  "text" : "RT @zabbix: We created RPM packages for CentOS 5 & 6 and RedHat 5 & 6 available from http:\/\/t.co\/9q6CbLri It's for early preview and tes ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/9q6CbLri",
        "expanded_url" : "https:\/\/build.opensuse.org\/project\/show?project=home%3Akodai%3Azabbix",
        "display_url" : "build.opensuse.org\/project\/show?p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "146641248231501824",
    "text" : "We created RPM packages for CentOS 5 & 6 and RedHat 5 & 6 available from http:\/\/t.co\/9q6CbLri It's for early preview and testing.",
    "id" : 146641248231501824,
    "created_at" : "2011-12-13 17:22:52 +0000",
    "user" : {
      "name" : "Zabbix Team",
      "screen_name" : "zabbix",
      "protected" : false,
      "id_str" : "127810439",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1326034822\/zabbix_logo_twitter_normal.png",
      "id" : 127810439,
      "verified" : false
    }
  },
  "id" : 146663276795801600,
  "created_at" : "2011-12-13 18:50:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 0, 11 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146647263551303680",
  "geo" : { },
  "id_str" : "146663124102168576",
  "in_reply_to_user_id" : 5932682,
  "text" : "@davidjrice erm... sorry about that... Think I'd learn after all this time :)",
  "id" : 146663124102168576,
  "in_reply_to_status_id" : 146647263551303680,
  "created_at" : "2011-12-13 18:49:48 +0000",
  "in_reply_to_screen_name" : "davidjrice",
  "in_reply_to_user_id_str" : "5932682",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 12, 25 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146619304882872320",
  "geo" : { },
  "id_str" : "146624970888445952",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @rickyhassard well worth the money I think :D Open a shop :)",
  "id" : 146624970888445952,
  "in_reply_to_status_id" : 146619304882872320,
  "created_at" : "2011-12-13 16:18:11 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146615525177430017",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll that fruit loaf.... what can I say.. Its just the bestest!!!!!",
  "id" : 146615525177430017,
  "created_at" : "2011-12-13 15:40:39 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146585859104317441",
  "text" : "Just had a massive coughing fit... Hate that...",
  "id" : 146585859104317441,
  "created_at" : "2011-12-13 13:42:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146565126101811201",
  "text" : "An electrician has just went into our 'server' room... Should be funny to hear the screams of him :)",
  "id" : 146565126101811201,
  "created_at" : "2011-12-13 12:20:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/146534385502535680\/photo\/1",
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/eNbbN7dY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgiYP0uCQAAWbAj.jpg",
      "id_str" : "146534385506729984",
      "id" : 146534385506729984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgiYP0uCQAAWbAj.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eNbbN7dY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146534385502535680",
  "text" : "Reindeer Bun!!!!! http:\/\/t.co\/eNbbN7dY",
  "id" : 146534385502535680,
  "created_at" : "2011-12-13 10:18:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146515060100050944",
  "text" : "I could venture in - but it head can't take cackling women at this hour and the cleaners need to do their job without me bombing about.",
  "id" : 146515060100050944,
  "created_at" : "2011-12-13 09:01:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146514864108605441",
  "text" : "Eugggggh... I feel like crap and my porridge is being held hostage in the kitchen by two cackling girls and several cleaners :(",
  "id" : 146514864108605441,
  "created_at" : "2011-12-13 09:00:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146341896434892800",
  "geo" : { },
  "id_str" : "146342581108879360",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf Sortta.... I think the show came of age in this season. Amazing writing.. Its kinda haunting - which is the sign of a good show",
  "id" : 146342581108879360,
  "in_reply_to_status_id" : 146341896434892800,
  "created_at" : "2011-12-12 21:36:04 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933646906, -6.2126069246 ]
  },
  "id_str" : "146341058261942272",
  "text" : "Boardwalk Empire. What a show. Fuck me pink....",
  "id" : 146341058261942272,
  "created_at" : "2011-12-12 21:30:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146270558651285504",
  "geo" : { },
  "id_str" : "146272417621356544",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore seen that just after I tweeted.",
  "id" : 146272417621356544,
  "in_reply_to_status_id" : 146270558651285504,
  "created_at" : "2011-12-12 16:57:16 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146266865105248256",
  "geo" : { },
  "id_str" : "146270191133786112",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore neither do I. But if your company got that tender you would have done the same thing :)",
  "id" : 146270191133786112,
  "in_reply_to_status_id" : 146266865105248256,
  "created_at" : "2011-12-12 16:48:25 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    }, {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 15, 24 ],
      "id_str" : "9488072",
      "id" : 9488072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146246597808881664",
  "geo" : { },
  "id_str" : "146247753306087424",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard @shylands if a company knocked on your door and offered you 200k for a website you'd do it :D",
  "id" : 146247753306087424,
  "in_reply_to_status_id" : 146246597808881664,
  "created_at" : "2011-12-12 15:19:16 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 0, 9 ],
      "id_str" : "9488072",
      "id" : 9488072
    }, {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 10, 24 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146245432480247810",
  "geo" : { },
  "id_str" : "146246300873134080",
  "in_reply_to_user_id" : 9488072,
  "text" : "@shylands @madebyrichard exactly the same :) Squeeze if for all its worth :)",
  "id" : 146246300873134080,
  "in_reply_to_status_id" : 146245432480247810,
  "created_at" : "2011-12-12 15:13:29 +0000",
  "in_reply_to_screen_name" : "shylands",
  "in_reply_to_user_id_str" : "9488072",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 0, 9 ],
      "id_str" : "9488072",
      "id" : 9488072
    }, {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 10, 24 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146245432480247810",
  "geo" : { },
  "id_str" : "146246203670138880",
  "in_reply_to_user_id" : 9488072,
  "text" : "@shylands @madebyrichard oh yeah - 20k shy of 200k on a website... FOI it sure. But if it was your either of your companies you would have..",
  "id" : 146246203670138880,
  "in_reply_to_status_id" : 146245432480247810,
  "created_at" : "2011-12-12 15:13:06 +0000",
  "in_reply_to_screen_name" : "shylands",
  "in_reply_to_user_id_str" : "9488072",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    }, {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 15, 24 ],
      "id_str" : "9488072",
      "id" : 9488072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146242424472223744",
  "geo" : { },
  "id_str" : "146242760486293507",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard @shylands Don't throw stones. Hated the twitter response to that site :( Very unprof. Well at least it went to  a local firm.",
  "id" : 146242760486293507,
  "in_reply_to_status_id" : 146242424472223744,
  "created_at" : "2011-12-12 14:59:25 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 3, 12 ],
      "id_str" : "9488072",
      "id" : 9488072
    }, {
      "name" : "NI Assembly",
      "screen_name" : "niassembly",
      "indices" : [ 36, 47 ],
      "id_str" : "14844466",
      "id" : 14844466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146240140476551170",
  "geo" : { },
  "id_str" : "146241249253396482",
  "in_reply_to_user_id" : 9488072,
  "text" : "Yo @shylands who got the tender for @niassembly?",
  "id" : 146241249253396482,
  "in_reply_to_status_id" : 146240140476551170,
  "created_at" : "2011-12-12 14:53:25 +0000",
  "in_reply_to_screen_name" : "shylands",
  "in_reply_to_user_id_str" : "9488072",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/nQQ1UdW4",
      "expanded_url" : "http:\/\/www.niassembly.gov.uk\/News-and-Media\/Blog-NIA\/Dates\/2011\/12\/New-Assembly-Shop-Window-Launched\/",
      "display_url" : "niassembly.gov.uk\/News-and-Media\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "146241028813365248",
  "text" : "Disgraceful - http:\/\/t.co\/nQQ1UdW4 - 180k for a website :(",
  "id" : 146241028813365248,
  "created_at" : "2011-12-12 14:52:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bakinggodess",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146178454906347520",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll you are amazing.. That shortbread was the best ever. Open a shop. #bakinggodess",
  "id" : 146178454906347520,
  "created_at" : "2011-12-12 10:43:54 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.593366026, -6.212539264 ]
  },
  "id_str" : "145986584905392129",
  "text" : "McLovin",
  "id" : 145986584905392129,
  "created_at" : "2011-12-11 22:01:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Fletcher",
      "screen_name" : "iammfj",
      "indices" : [ 3, 10 ],
      "id_str" : "19530610",
      "id" : 19530610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xfactor",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145973480159064064",
  "text" : "RT @iammfj: Why are Coldplay on? Do they think this is Children in Need as its been on so fucking long? #xfactor",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "xfactor",
        "indices" : [ 92, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145973046199595008",
    "text" : "Why are Coldplay on? Do they think this is Children in Need as its been on so fucking long? #xfactor",
    "id" : 145973046199595008,
    "created_at" : "2011-12-11 21:07:40 +0000",
    "user" : {
      "name" : "Matthew Fletcher",
      "screen_name" : "iammfj",
      "protected" : false,
      "id_str" : "19530610",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1471185893\/Eric_normal.jpg",
      "id" : 19530610,
      "verified" : false
    }
  },
  "id" : 145973480159064064,
  "created_at" : "2011-12-11 21:09:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GaryBarlow",
      "screen_name" : "GBarlowOfficial",
      "indices" : [ 19, 35 ],
      "id_str" : "1433320484",
      "id" : 1433320484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933798001, -6.2123955357 ]
  },
  "id_str" : "145966396315144192",
  "text" : "Should have gotten @GBarlowOfficial to write the winners song instead of opting for a cover. Weak ass shit.",
  "id" : 145966396315144192,
  "created_at" : "2011-12-11 20:41:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GaryBarlow",
      "screen_name" : "GBarlowOfficial",
      "indices" : [ 10, 26 ],
      "id_str" : "1433320484",
      "id" : 1433320484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xfacfor",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933913409, -6.2123929665 ]
  },
  "id_str" : "145966049030979584",
  "text" : "I thought @GBarlowOfficial was writing the winners song? There will be a plagal key change... Ha! There it is. Predictable. #xfacfor",
  "id" : 145966049030979584,
  "created_at" : "2011-12-11 20:39:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 13, 24 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145899601738739713",
  "geo" : { },
  "id_str" : "145918682005110784",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @alana_doll it was good - for the long game anyway... you suck :)",
  "id" : 145918682005110784,
  "in_reply_to_status_id" : 145899601738739713,
  "created_at" : "2011-12-11 17:31:39 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 20, 32 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145825928507953152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933560871, -6.2124576467 ]
  },
  "id_str" : "145875488055885824",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll noooooo @stimpled0rf has tainted your opinion....",
  "id" : 145875488055885824,
  "in_reply_to_status_id" : 145825928507953152,
  "created_at" : "2011-12-11 14:40:01 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145809755007496192",
  "geo" : { },
  "id_str" : "145822369083162624",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf I knew you would hate it! :)",
  "id" : 145822369083162624,
  "in_reply_to_status_id" : 145809755007496192,
  "created_at" : "2011-12-11 11:08:56 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145611185964847105",
  "geo" : { },
  "id_str" : "145611907154456576",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll :D Hope you like it. Am on eppy 5 of Homeland :D",
  "id" : 145611907154456576,
  "in_reply_to_status_id" : 145611185964847105,
  "created_at" : "2011-12-10 21:12:38 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.59333895, -6.21221065 ]
  },
  "id_str" : "145384105842978816",
  "text" : "6am on a Saturday morning.... Way. To. Early. Way. Too. Fucking. Cold.",
  "id" : 145384105842978816,
  "created_at" : "2011-12-10 06:07:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145228434212257792",
  "text" : "me \u00A32.50 for 48 hours... So... with that I go to my 'local' video shop - they will do it for a quid.",
  "id" : 145228434212257792,
  "created_at" : "2011-12-09 19:48:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 1, 13 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 67, 73 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 110, 122 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 123, 136 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145170562820485120",
  "text" : "\u201C@stimpled0rf: I've never seen a moment of joy quite like it after @swmcc fitted 4 tea cakes in his mouth cc\/ @niall_adams @RickyHassard\u201D",
  "id" : 145170562820485120,
  "created_at" : "2011-12-09 15:58:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145169075688054784",
  "geo" : { },
  "id_str" : "145169156562632704",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop not a chance.. there is a video of it - but that's not going anywhere!",
  "id" : 145169156562632704,
  "in_reply_to_status_id" : 145169075688054784,
  "created_at" : "2011-12-09 15:53:18 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145169088044470272",
  "text" : "...Tea cup cakes in my mouth... Not tea cups... I wish I could do that - would be a class porn star making millions if I could do that!",
  "id" : 145169088044470272,
  "created_at" : "2011-12-09 15:53:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145168893823033345",
  "text" : "I just fitted 4 tea cups in my mouth... Yeah - who said I had fuck all talent!!!",
  "id" : 145168893823033345,
  "created_at" : "2011-12-09 15:52:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145154127092125698",
  "text" : "I don't like the way MACos doesn't like faux as an argument to ps.. I always do ps faux | grep xxx - Muscle memory...",
  "id" : 145154127092125698,
  "created_at" : "2011-12-09 14:53:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145118939469451266",
  "geo" : { },
  "id_str" : "145119210501177344",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb felt it on Sun am tellin ya.. Even felt it on Mon :) But sure if I wasn't this age I'd be dead :) Still younger than you though :)",
  "id" : 145119210501177344,
  "in_reply_to_status_id" : 145118939469451266,
  "created_at" : "2011-12-09 12:34:50 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145117750195531777",
  "geo" : { },
  "id_str" : "145118184654118912",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Aye bar red next week sometime.. Lookin forward to it. Was out last weekend though and couldn't move all day sunday.. so dunno :)",
  "id" : 145118184654118912,
  "in_reply_to_status_id" : 145117750195531777,
  "created_at" : "2011-12-09 12:30:46 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145117097679265792",
  "geo" : { },
  "id_str" : "145117290315268096",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb its a nice bar - but too close to the west.. You get them all in there beating the shit out of each other :D Its true :D",
  "id" : 145117290315268096,
  "in_reply_to_status_id" : 145117097679265792,
  "created_at" : "2011-12-09 12:27:12 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 1, 11 ],
      "id_str" : "212603717",
      "id" : 212603717
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145116731281637376",
  "text" : "\u201C@carisenda: @swmcc alright shirley temple\u201D At last :D",
  "id" : 145116731281637376,
  "created_at" : "2011-12-09 12:24:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145115877396856832",
  "geo" : { },
  "id_str" : "145116058724990976",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb same... Where you heading too? You\/we used to have them dead early in Dec though - guess things have changed though.",
  "id" : 145116058724990976,
  "in_reply_to_status_id" : 145115877396856832,
  "created_at" : "2011-12-09 12:22:19 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145114463723454464",
  "geo" : { },
  "id_str" : "145114639221538817",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb its awesome!!! Stop being such a bah humbug :D You had your xmas do yet?",
  "id" : 145114639221538817,
  "in_reply_to_status_id" : 145114463723454464,
  "created_at" : "2011-12-09 12:16:40 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145113432507691008",
  "geo" : { },
  "id_str" : "145113605615005696",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Fucking awesome son... I &lt;3 that song.... You just have no class :)",
  "id" : 145113605615005696,
  "in_reply_to_status_id" : 145113432507691008,
  "created_at" : "2011-12-09 12:12:34 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145113020840939522",
  "text" : "I want a hippopotamus for Christmas only a hippopotamus will dooo.. Don't want a doll.. No dinky tinker toy, I want a hippopotamus to play..",
  "id" : 145113020840939522,
  "created_at" : "2011-12-09 12:10:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wastingmytimeyouare",
      "indices" : [ 114, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144885793771634690",
  "geo" : { },
  "id_str" : "144886820189126656",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf I was outside for the last three fucking hours and I didn't get a bent over shot of you at all!!!!!! #wastingmytimeyouare",
  "id" : 144886820189126656,
  "in_reply_to_status_id" : 144885793771634690,
  "created_at" : "2011-12-08 21:11:24 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144885235799175168",
  "geo" : { },
  "id_str" : "144885779754254336",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard you couldn't open a packet of biscuits today... Stones.. Glass houses.. :)",
  "id" : 144885779754254336,
  "in_reply_to_status_id" : 144885235799175168,
  "created_at" : "2011-12-08 21:07:16 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 8, 20 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144885489130934274",
  "text" : "Right.. @stimpled0rf am getting ready to watch Homeland... So we can discuss it on the pilgrimage tomorrow.. I know u haven't watched sons!",
  "id" : 144885489130934274,
  "created_at" : "2011-12-08 21:06:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144885035969949698",
  "text" : "Just back from Belfast... House is freezing.. Fucking bastarding timer never works when I wants it to! Maybe I am doing it wrong...",
  "id" : 144885035969949698,
  "created_at" : "2011-12-08 21:04:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144873074637029377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933554713, -6.2125266927 ]
  },
  "id_str" : "144882615583903747",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard You just declare war on me???",
  "id" : 144882615583903747,
  "in_reply_to_status_id" : 144873074637029377,
  "created_at" : "2011-12-08 20:54:42 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144789806235385856",
  "geo" : { },
  "id_str" : "144796134173450241",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings Ahh well - go make a cup of tea :D",
  "id" : 144796134173450241,
  "in_reply_to_status_id" : 144789806235385856,
  "created_at" : "2011-12-08 15:11:03 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144784268214808576",
  "geo" : { },
  "id_str" : "144786956319080449",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings :D :D :D :D :D :D :D :D :D :D :D :D :D :D :D :D :D :D :D :D :D :D :D Is it still as email heavy? :)",
  "id" : 144786956319080449,
  "in_reply_to_status_id" : 144784268214808576,
  "created_at" : "2011-12-08 14:34:35 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144756772639473664",
  "text" : "perl get_paid_info.pl &gt; raw_files\/paid.sql 2&gt; fuckyouyoushouldwork.bastard.thing",
  "id" : 144756772639473664,
  "created_at" : "2011-12-08 12:34:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144754267847274496",
  "text" : "Signs for a developer when you know something isn't going your way \"2&gt; whythefuckwontyouwork.bastard.thing\" :D",
  "id" : 144754267847274496,
  "created_at" : "2011-12-08 12:24:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the black telescope",
      "screen_name" : "blacktelescope",
      "indices" : [ 0, 15 ],
      "id_str" : "14932763",
      "id" : 14932763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144744627369545729",
  "geo" : { },
  "id_str" : "144744855195762688",
  "in_reply_to_user_id" : 14932763,
  "text" : "@blacktelescope you are right I don't moisturize.. Mainly cos I don't have a vagina.. You used to be cool with dreadlocks.. Hippie! :)",
  "id" : 144744855195762688,
  "in_reply_to_status_id" : 144744627369545729,
  "created_at" : "2011-12-08 11:47:17 +0000",
  "in_reply_to_screen_name" : "blacktelescope",
  "in_reply_to_user_id_str" : "14932763",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the black telescope",
      "screen_name" : "blacktelescope",
      "indices" : [ 0, 15 ],
      "id_str" : "14932763",
      "id" : 14932763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144742799101800450",
  "geo" : { },
  "id_str" : "144743972949065728",
  "in_reply_to_user_id" : 14932763,
  "text" : "@blacktelescope men don't wear scarves!!! Fact. Simples.",
  "id" : 144743972949065728,
  "in_reply_to_status_id" : 144742799101800450,
  "created_at" : "2011-12-08 11:43:47 +0000",
  "in_reply_to_screen_name" : "blacktelescope",
  "in_reply_to_user_id_str" : "14932763",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144717908663205889",
  "text" : "People that don't show up for interviews are just dumb. Dumb and ignorant. Just wasting professional peoples time.. Assholes.",
  "id" : 144717908663205889,
  "created_at" : "2011-12-08 10:00:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Robinson",
      "screen_name" : "gazrobot",
      "indices" : [ 0, 9 ],
      "id_str" : "1477065343",
      "id" : 1477065343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144509058253193216",
  "text" : "@gazrobot :D",
  "id" : 144509058253193216,
  "created_at" : "2011-12-07 20:10:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Robinson",
      "screen_name" : "gazrobot",
      "indices" : [ 0, 9 ],
      "id_str" : "1477065343",
      "id" : 1477065343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144508157685805057",
  "text" : "@gazrobot fuck the update.. Did you watch it? :)",
  "id" : 144508157685805057,
  "created_at" : "2011-12-07 20:06:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144507124855218176",
  "text" : "The finale (according to reports ;) ) of Sons of Anarchy was immense... Very smart I thought.. Can't wait to see it :D",
  "id" : 144507124855218176,
  "created_at" : "2011-12-07 20:02:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144490049080279042",
  "text" : "OH: \"This fucking light is doing my twat in\"... Awwww pure class :)",
  "id" : 144490049080279042,
  "created_at" : "2011-12-07 18:54:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144483497212522496",
  "geo" : { },
  "id_str" : "144488741304664064",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus just iso's you know for developing :D I tried that game - was good - but my pc isn't really up to running it. Might upgrade.",
  "id" : 144488741304664064,
  "in_reply_to_status_id" : 144483497212522496,
  "created_at" : "2011-12-07 18:49:35 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144483358506876930",
  "text" : "Of course the download is an ISO of a Debian boring thingie.. Not something interesting.. Nope... :)",
  "id" : 144483358506876930,
  "created_at" : "2011-12-07 18:28:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144483261861736449",
  "text" : "1.5Gb downloaded in 2m 04seconds.. Don't mind if I do :)",
  "id" : 144483261861736449,
  "created_at" : "2011-12-07 18:27:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144479582949609472",
  "text" : "It is downloading............",
  "id" : 144479582949609472,
  "created_at" : "2011-12-07 18:13:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OnPointEvents",
      "screen_name" : "Deactivated001",
      "indices" : [ 0, 15 ],
      "id_str" : "428440952",
      "id" : 428440952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144240295414988800",
  "geo" : { },
  "id_str" : "144457484529184768",
  "in_reply_to_user_id" : 288452305,
  "text" : "@deactivated001 I've unfollowed you now as 10pm NY time is something like 5am GMT time. I think your cool like - but not that cool ;)",
  "id" : 144457484529184768,
  "in_reply_to_status_id" : 144240295414988800,
  "created_at" : "2011-12-07 16:45:22 +0000",
  "in_reply_to_screen_name" : "ABFalecbaldwin",
  "in_reply_to_user_id_str" : "288452305",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 3, 13 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144444041856167936",
  "text" : "RT @carisenda: Just added \"use strict\"; to top of JS app I'm working on. Feel like a proper programmer now ;)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144436966296002561",
    "text" : "Just added \"use strict\"; to top of JS app I'm working on. Feel like a proper programmer now ;)",
    "id" : 144436966296002561,
    "created_at" : "2011-12-07 15:23:50 +0000",
    "user" : {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "protected" : false,
      "id_str" : "212603717",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1513037620\/avatar_normal.png",
      "id" : 212603717,
      "verified" : false
    }
  },
  "id" : 144444041856167936,
  "created_at" : "2011-12-07 15:51:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144411651729399808",
  "geo" : { },
  "id_str" : "144412651529842689",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore cardigan....",
  "id" : 144412651529842689,
  "in_reply_to_status_id" : 144411651729399808,
  "created_at" : "2011-12-07 13:47:13 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144185336220758016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933562514, -6.2125592269 ]
  },
  "id_str" : "144185677108617216",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall same thing could be said about goi g to church and praying. Expect it all Porter :)",
  "id" : 144185677108617216,
  "in_reply_to_status_id" : 144185336220758016,
  "created_at" : "2011-12-06 22:45:18 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144170488871133184",
  "geo" : { },
  "id_str" : "144178315740188673",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall shut it porter!!! Here that rice pudding was lovely :D Thanks very mucho :)",
  "id" : 144178315740188673,
  "in_reply_to_status_id" : 144170488871133184,
  "created_at" : "2011-12-06 22:16:03 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144165631070175232",
  "geo" : { },
  "id_str" : "144166356596686848",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams A really good luck charm it is then ;)",
  "id" : 144166356596686848,
  "in_reply_to_status_id" : 144165631070175232,
  "created_at" : "2011-12-06 21:28:32 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144165251095597056",
  "text" : "I found a pound when I flipped my mattress over there... That's a good luck charm aint it? :)",
  "id" : 144165251095597056,
  "created_at" : "2011-12-06 21:24:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144150740875739136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933337547, -6.2124889469 ]
  },
  "id_str" : "144155365708275712",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll it's nice. Very small though.",
  "id" : 144155365708275712,
  "in_reply_to_status_id" : 144150740875739136,
  "created_at" : "2011-12-06 20:44:52 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gervais",
      "screen_name" : "rickygervais",
      "indices" : [ 0, 13 ],
      "id_str" : "20015311",
      "id" : 20015311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144055300578742273",
  "geo" : { },
  "id_str" : "144056798356316160",
  "in_reply_to_user_id" : 20015311,
  "text" : "@rickygervais ginger people not make you cry and want to batter people?",
  "id" : 144056798356316160,
  "in_reply_to_status_id" : 144055300578742273,
  "created_at" : "2011-12-06 14:13:11 +0000",
  "in_reply_to_screen_name" : "rickygervais",
  "in_reply_to_user_id_str" : "20015311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144052943698657283",
  "geo" : { },
  "id_str" : "144054300493099008",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda was clients that were ringing up saying they couldn't see our software. We just came up from a powercut here as well.Bad timing.",
  "id" : 144054300493099008,
  "in_reply_to_status_id" : 144052943698657283,
  "created_at" : "2011-12-06 14:03:16 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thinkiaminlove",
      "indices" : [ 34, 49 ]
    }, {
      "text" : "mikeisgonnakillmenowbutscrewitcosyoumakecaskesANDjam",
      "indices" : [ 50, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144048039332552706",
  "geo" : { },
  "id_str" : "144049990149472256",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll you also make jam???? #thinkiaminlove #mikeisgonnakillmenowbutscrewitcosyoumakecaskesANDjam",
  "id" : 144049990149472256,
  "in_reply_to_status_id" : 144048039332552706,
  "created_at" : "2011-12-06 13:46:08 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144048636479815681",
  "geo" : { },
  "id_str" : "144049666198224896",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard they are good enough for hosting - stupid billing though and very expensive. Unless you are on a leased line they are crap.",
  "id" : 144049666198224896,
  "in_reply_to_status_id" : 144048636479815681,
  "created_at" : "2011-12-06 13:44:51 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144044302413209600",
  "geo" : { },
  "id_str" : "144046733637324800",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard They are next to useless for business in NI and very expensive to boot. I use their Infinity at home though and its great :)",
  "id" : 144046733637324800,
  "in_reply_to_status_id" : 144044302413209600,
  "created_at" : "2011-12-06 13:33:12 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144042969891217410",
  "text" : "BT fix your fucking DNS servers - caused me to have a minor heart attack there... BASTARDS :)",
  "id" : 144042969891217410,
  "created_at" : "2011-12-06 13:18:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 23, 37 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144008705367752704",
  "text" : "Attention Attention... @jenporterhall is awesome... That is all :D",
  "id" : 144008705367752704,
  "created_at" : "2011-12-06 11:02:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143807164438421504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933586125, -6.2121949883 ]
  },
  "id_str" : "143808074665304065",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc that last tweet was supposed to say \"jib\" and not \"job\". Guess job works just as well in that context all the same....",
  "id" : 143808074665304065,
  "in_reply_to_status_id" : 143807164438421504,
  "created_at" : "2011-12-05 21:44:51 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 51, 63 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/143807164438421504\/photo\/1",
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/xkEKPVEQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Af7n2qjCIAAhWw_.jpg",
      "id_str" : "143807164442615808",
      "id" : 143807164442615808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Af7n2qjCIAAhWw_.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/xkEKPVEQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5934124691, -6.2122786803 ]
  },
  "id_str" : "143807164438421504",
  "text" : "He likes the cut of my job I guess :) bottle it up @stimpled0rf and let it go come Wed ;) http:\/\/t.co\/xkEKPVEQ",
  "id" : 143807164438421504,
  "created_at" : "2011-12-05 21:41:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933695992, -6.2125457387 ]
  },
  "id_str" : "143793048608964608",
  "text" : "Fucking hell..... No amount of bleach..... None...........",
  "id" : 143793048608964608,
  "created_at" : "2011-12-05 20:45:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933138084, -6.2125454276 ]
  },
  "id_str" : "143792666168131584",
  "text" : "No no no no no no no nooooooooooooooooooooooooo!!!!!!!!!!!!",
  "id" : 143792666168131584,
  "created_at" : "2011-12-05 20:43:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BoardwalkEmpire",
      "indices" : [ 58, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933691112, -6.212549866 ]
  },
  "id_str" : "143792530188812288",
  "text" : "What the fuck..... What the fuck.... What the FUCK!!!!!!! #BoardwalkEmpire",
  "id" : 143792530188812288,
  "created_at" : "2011-12-05 20:43:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143772200758034432",
  "text" : "No fun driving home... Took me ages... Snow on top of that wee mountain.. Wouldn't want to try Hannastown tonight.. Stay in I think :)",
  "id" : 143772200758034432,
  "created_at" : "2011-12-05 19:22:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143736918943875072",
  "geo" : { },
  "id_str" : "143742483388563459",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe just RT'd that so she'll see it :D That's what you get for no tea :D",
  "id" : 143742483388563459,
  "in_reply_to_status_id" : 143736918943875072,
  "created_at" : "2011-12-05 17:24:13 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 3, 10 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 12, 18 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143742330481020928",
  "text" : "RT @srushe: @swmcc Who let that gobshite on the telly? - Good thing she doesn't follow me :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "143727960950718466",
    "geo" : { },
    "id_str" : "143736918943875072",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Who let that gobshite on the telly? - Good thing she doesn't follow me :)",
    "id" : 143736918943875072,
    "in_reply_to_status_id" : 143727960950718466,
    "created_at" : "2011-12-05 17:02:06 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "protected" : false,
      "id_str" : "761761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414429155\/DangerMan_normal.jpg",
      "id" : 761761,
      "verified" : false
    }
  },
  "id" : 143742330481020928,
  "created_at" : "2011-12-05 17:23:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thelights",
      "indices" : [ 73, 83 ]
    }, {
      "text" : "thelights",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "thelights",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/XEpicsZ5",
      "expanded_url" : "http:\/\/www.gotobelfast.com\/christmas_2011\/christmas_tv.aspx",
      "display_url" : "gotobelfast.com\/christmas_2011\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "143727960950718466",
  "text" : "Anyone know a certain blonde person in this video - http:\/\/t.co\/XEpicsZ5 #thelights #thelights #thelights",
  "id" : 143727960950718466,
  "created_at" : "2011-12-05 16:26:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143673140847980544",
  "geo" : { },
  "id_str" : "143673703262191616",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Congrats :D",
  "id" : 143673703262191616,
  "in_reply_to_status_id" : 143673140847980544,
  "created_at" : "2011-12-05 12:50:54 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143630354023063552",
  "text" : "That moment when you remember that you left your awesome lunch at home on the kitchen counter :(",
  "id" : 143630354023063552,
  "created_at" : "2011-12-05 09:58:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143609681372389377",
  "text" : "Fucking snow.... Will have to go to Hillsborough via Lisburn - wonder how long it will take me.....",
  "id" : 143609681372389377,
  "created_at" : "2011-12-05 08:36:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 12, 24 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143427507008442369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 54.5933616775, -6.212410273 ]
  },
  "id_str" : "143430690220941312",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @niall_adams nerds!!!!",
  "id" : 143430690220941312,
  "in_reply_to_status_id" : 143427507008442369,
  "created_at" : "2011-12-04 20:45:16 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143393120334258176",
  "text" : "6:15 and I am just out of bed... Fucking waste of a Sunday....",
  "id" : 143393120334258176,
  "created_at" : "2011-12-04 18:15:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143312059025723393",
  "text" : "I am slow roasting a chicken for dinner later... Think I may join it.. Me = fucked.....",
  "id" : 143312059025723393,
  "created_at" : "2011-12-04 12:53:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rory Mcilroy",
      "screen_name" : "McIlroyRory",
      "indices" : [ 0, 12 ],
      "id_str" : "188039706",
      "id" : 188039706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143309741635014657",
  "geo" : { },
  "id_str" : "143311792880353281",
  "in_reply_to_user_id" : 188039706,
  "text" : "@McIlroyRory congrats :)",
  "id" : 143311792880353281,
  "in_reply_to_status_id" : 143309741635014657,
  "created_at" : "2011-12-04 12:52:48 +0000",
  "in_reply_to_screen_name" : "McIlroyRory",
  "in_reply_to_user_id_str" : "188039706",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/XYMi3IVL",
      "expanded_url" : "http:\/\/www.yogab.co.uk",
      "display_url" : "yogab.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "143304975332806656",
  "text" : "If you are interested in Yoga check out YOGAB - http:\/\/t.co\/XYMi3IVL",
  "id" : 143304975332806656,
  "created_at" : "2011-12-04 12:25:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142994570391715840",
  "text" : "At 32 am I equipped for a 7 hour drinking session? I do not think it... Who's idea was it to have dinner at 6:30?? Grrrrr :D",
  "id" : 142994570391715840,
  "created_at" : "2011-12-03 15:52:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142740603023802368",
  "text" : "My new sofa is the dogs..... That is all... Its the fucking dogs!!!!",
  "id" : 142740603023802368,
  "created_at" : "2011-12-02 23:03:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142736740090789888",
  "geo" : { },
  "id_str" : "142740485491003392",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit Boom chica waaa waaa??? Booooom chica waaa waaaa.. I expect to see your abode in a porn film to be released :)",
  "id" : 142740485491003392,
  "in_reply_to_status_id" : 142736740090789888,
  "created_at" : "2011-12-02 23:02:38 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142347922854514688",
  "geo" : { },
  "id_str" : "142352664200609792",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf I am framing that print out :D",
  "id" : 142352664200609792,
  "in_reply_to_status_id" : 142347922854514688,
  "created_at" : "2011-12-01 21:21:34 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 30, 42 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142347636240953344",
  "text" : "I sat in a meeting today with @stimpled0rf today for 5.5hours. Sum total of meeting can be summed up: \"Can it be less scrolly?\" *KABOOOM*",
  "id" : 142347636240953344,
  "created_at" : "2011-12-01 21:01:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142347178332012544",
  "geo" : { },
  "id_str" : "142347371307741184",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @niall_adams Will give it a go... Wont be back in until Monday though.. Just gonna take the peace n quiet and do the DP.",
  "id" : 142347371307741184,
  "in_reply_to_status_id" : 142347178332012544,
  "created_at" : "2011-12-01 21:00:32 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142340292836720640",
  "geo" : { },
  "id_str" : "142346921732866049",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @niall_adams I just watched an eppy of HIMYM there.. Its doing my fucking nut in... Now I have to move 2 sofas :D",
  "id" : 142346921732866049,
  "in_reply_to_status_id" : 142340292836720640,
  "created_at" : "2011-12-01 20:58:45 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142337789739012096",
  "text" : "Five repair fails in a row.... \/me takes toys and goes home.",
  "id" : 142337789739012096,
  "created_at" : "2011-12-01 20:22:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yvonne Savage",
      "screen_name" : "AmandaPoole",
      "indices" : [ 3, 15 ],
      "id_str" : "1560156606",
      "id" : 1560156606
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetni",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142333511234371585",
  "text" : "RT @AmandaPoole: The Compassionate Friends group is run by and for bereaved parents. Remembrance service Glenavy Dec 4. #tweetni pls RT  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AmandaFBelfast\/status\/140755066616418304\/photo\/1",
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/v6FnupqX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AfQP_MJCEAAbFQ6.jpg",
        "id_str" : "140755066620612608",
        "id" : 140755066620612608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfQP_MJCEAAbFQ6.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 507
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 507
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 507
        }, {
          "h" : 483,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/v6FnupqX"
      } ],
      "hashtags" : [ {
        "text" : "tweetni",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "140755066616418304",
    "text" : "The Compassionate Friends group is run by and for bereaved parents. Remembrance service Glenavy Dec 4. #tweetni pls RT http:\/\/t.co\/v6FnupqX",
    "id" : 140755066616418304,
    "created_at" : "2011-11-27 11:33:18 +0000",
    "user" : {
      "name" : "Amanda Ferguson",
      "screen_name" : "AmandaFBelfast",
      "protected" : false,
      "id_str" : "20176196",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000130047676\/a5d950b883553fdd13a308b50e5bba20_normal.jpeg",
      "id" : 20176196,
      "verified" : false
    }
  },
  "id" : 142333511234371585,
  "created_at" : "2011-12-01 20:05:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOVEFiLM",
      "screen_name" : "LOVEFiLM",
      "indices" : [ 47, 56 ],
      "id_str" : "19338359",
      "id" : 19338359
    }, {
      "name" : "Dave Cross",
      "screen_name" : "davorg",
      "indices" : [ 84, 91 ],
      "id_str" : "14753",
      "id" : 14753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/eM75BDFF",
      "expanded_url" : "http:\/\/blog.dave.org.uk\/2011\/12\/lovefilm-and-silverlight.html",
      "display_url" : "blog.dave.org.uk\/2011\/12\/lovefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "142287561933602816",
  "text" : "Dave Cross puts it way better than I could re: @lovefilm - http:\/\/t.co\/eM75BDFF \/cc @davorg",
  "id" : 142287561933602816,
  "created_at" : "2011-12-01 17:02:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 34, 46 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142200835219263488",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall you missing me and @stimpled0rf - bet you are :D",
  "id" : 142200835219263488,
  "created_at" : "2011-12-01 11:18:15 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]