Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373898366838931457",
  "text" : "Instead of watching the X-Factor tonight I watched an episode of Scooby-Do with my honorary niece Pippa :) that\u2019s how to spend a Sat evening",
  "id" : 373898366838931457,
  "created_at" : "2013-08-31 20:01:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "indices" : [ 0, 10 ],
      "id_str" : "1248789104",
      "id" : 1248789104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373828535733194752",
  "geo" : { },
  "id_str" : "373828675998715904",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@hadooping Oh I know. I just have a flair for the dramatic :)",
  "id" : 373828675998715904,
  "in_reply_to_status_id" : 373828535733194752,
  "created_at" : "2013-08-31 15:24:36 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "indices" : [ 0, 10 ],
      "id_str" : "1248789104",
      "id" : 1248789104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373826794698600448",
  "geo" : { },
  "id_str" : "373828403155066880",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@hadooping and I created an issue about that - didn't whine like fuck.. Believe me son, when I whine you'll fuckin know ;)",
  "id" : 373828403155066880,
  "in_reply_to_status_id" : 373826794698600448,
  "created_at" : "2013-08-31 15:23:31 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "indices" : [ 0, 10 ],
      "id_str" : "1248789104",
      "id" : 1248789104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373826794698600448",
  "geo" : { },
  "id_str" : "373828266139721728",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@hadooping yeah I will.... :)",
  "id" : 373828266139721728,
  "in_reply_to_status_id" : 373826794698600448,
  "created_at" : "2013-08-31 15:22:58 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373794430953607169",
  "text" : "Just home.... now... now to watch Dexter :)",
  "id" : 373794430953607169,
  "created_at" : "2013-08-31 13:08:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 0, 9 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373763778179264512",
  "geo" : { },
  "id_str" : "373794338980892672",
  "in_reply_to_user_id" : 14961440,
  "text" : "@akaihane well he buys me flowers ;)",
  "id" : 373794338980892672,
  "in_reply_to_status_id" : 373763778179264512,
  "created_at" : "2013-08-31 13:08:09 +0000",
  "in_reply_to_screen_name" : "akaihane",
  "in_reply_to_user_id_str" : "14961440",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373754829534789632",
  "text" : "Some fucking bastard has given me the cold I think.... Fuck sake....",
  "id" : 373754829534789632,
  "created_at" : "2013-08-31 10:31:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373574262667608064",
  "geo" : { },
  "id_str" : "373575872206217216",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl not very hospitable but I'll take it",
  "id" : 373575872206217216,
  "in_reply_to_status_id" : 373574262667608064,
  "created_at" : "2013-08-30 22:40:03 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "missyoulots",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373569131779735552",
  "geo" : { },
  "id_str" : "373573753923317760",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl leave some milk and cookies outside your front door for me will ya..... feel a bit pekish ;) #missyoulots",
  "id" : 373573753923317760,
  "in_reply_to_status_id" : 373569131779735552,
  "created_at" : "2013-08-30 22:31:38 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/373475105751318528\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/BU0kNWlh5l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS7ZoUMCQAE-CZu.png",
      "id_str" : "373475105755512833",
      "id" : 373475105755512833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS7ZoUMCQAE-CZu.png",
      "sizes" : [ {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 834
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 834
      } ],
      "display_url" : "pic.twitter.com\/BU0kNWlh5l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373475105751318528",
  "text" : "He is a wanker though.... Applications for new best mate are avail on my website.... http:\/\/t.co\/BU0kNWlh5l",
  "id" : 373475105751318528,
  "created_at" : "2013-08-30 15:59:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/373474670260932608\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/xMp2LAoWJW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS7ZO93CUAAqxh-.png",
      "id_str" : "373474670265126912",
      "id" : 373474670265126912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS7ZO93CUAAqxh-.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 141,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 841
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 841
      } ],
      "display_url" : "pic.twitter.com\/xMp2LAoWJW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373474670260932608",
  "text" : "And friend for over 20 years love.... http:\/\/t.co\/xMp2LAoWJW",
  "id" : 373474670260932608,
  "created_at" : "2013-08-30 15:57:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/373471000718880769\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/sE5K7x1xG3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS7V5XwCMAAJG-u.png",
      "id_str" : "373471000723075072",
      "id" : 373471000723075072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS7V5XwCMAAJG-u.png",
      "sizes" : [ {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 511
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 511
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 511
      } ],
      "display_url" : "pic.twitter.com\/sE5K7x1xG3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373471000718880769",
  "text" : "And sister love too :) http:\/\/t.co\/sE5K7x1xG3",
  "id" : 373471000718880769,
  "created_at" : "2013-08-30 15:43:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/373470645599735808\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/IklB8XPy0O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS7Vks1CEAE51cw.png",
      "id_str" : "373470645603930113",
      "id" : 373470645603930113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS7Vks1CEAE51cw.png",
      "sizes" : [ {
        "h" : 428,
        "resize" : "fit",
        "w" : 471
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 471
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 471
      } ],
      "display_url" : "pic.twitter.com\/IklB8XPy0O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373470645599735808",
  "text" : "Brotherly love http:\/\/t.co\/IklB8XPy0O",
  "id" : 373470645599735808,
  "created_at" : "2013-08-30 15:41:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373468451337420801",
  "geo" : { },
  "id_str" : "373470080048193537",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 and we only worked together for what six weeks... in those six weeks we kinda broke most rules :)",
  "id" : 373470080048193537,
  "in_reply_to_status_id" : 373468451337420801,
  "created_at" : "2013-08-30 15:39:40 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thongflash",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373468451337420801",
  "geo" : { },
  "id_str" : "373468852719345664",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 awww there is the one of you on my desk posing.... They should have asked me for the one we took in the server room ;) #thongflash",
  "id" : 373468852719345664,
  "in_reply_to_status_id" : 373468451337420801,
  "created_at" : "2013-08-30 15:34:47 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 37, 43 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HaVoCT5\/status\/373468451337420801\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/1s4gQe9EIu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS7Tk-RIMAAoJNN.jpg",
      "id_str" : "373468451261919232",
      "id" : 373468451261919232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS7Tk-RIMAAoJNN.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/1s4gQe9EIu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373468605188280321",
  "text" : "RT @HaVoCT5: Ohh forgot the card lol @swmcc http:\/\/t.co\/1s4gQe9EIu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 24, 30 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HaVoCT5\/status\/373468451337420801\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/1s4gQe9EIu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BS7Tk-RIMAAoJNN.jpg",
        "id_str" : "373468451261919232",
        "id" : 373468451261919232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS7Tk-RIMAAoJNN.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/1s4gQe9EIu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373468451337420801",
    "text" : "Ohh forgot the card lol @swmcc http:\/\/t.co\/1s4gQe9EIu",
    "id" : 373468451337420801,
    "created_at" : "2013-08-30 15:33:12 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 373468605188280321,
  "created_at" : "2013-08-30 15:33:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 9, 17 ],
      "id_str" : "79820731",
      "id" : 79820731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373468161162899456",
  "geo" : { },
  "id_str" : "373468327512788992",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @tascomi which ones? :)",
  "id" : 373468327512788992,
  "in_reply_to_status_id" : 373468161162899456,
  "created_at" : "2013-08-30 15:32:42 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Tascomi",
      "screen_name" : "tascomi",
      "indices" : [ 31, 39 ],
      "id_str" : "79820731",
      "id" : 79820731
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 52, 58 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373468278489759744",
  "text" : "RT @HaVoCT5: Leaving card from @tascomi , well seen @swmcc was a bad influence 2 of the 4 photos regard him",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tascomi",
        "screen_name" : "tascomi",
        "indices" : [ 18, 26 ],
        "id_str" : "79820731",
        "id" : 79820731
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 39, 45 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373468161162899456",
    "text" : "Leaving card from @tascomi , well seen @swmcc was a bad influence 2 of the 4 photos regard him",
    "id" : 373468161162899456,
    "created_at" : "2013-08-30 15:32:02 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 373468278489759744,
  "created_at" : "2013-08-30 15:32:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373456166623653888",
  "geo" : { },
  "id_str" : "373456315487514624",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop awesome......",
  "id" : 373456315487514624,
  "in_reply_to_status_id" : 373456166623653888,
  "created_at" : "2013-08-30 14:44:58 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373453098012131328",
  "geo" : { },
  "id_str" : "373455177430208512",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you sir, are a fucking gaping asshole.",
  "id" : 373455177430208512,
  "in_reply_to_status_id" : 373453098012131328,
  "created_at" : "2013-08-30 14:40:27 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 25, 31 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storify",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/PHyvkRLffh",
      "expanded_url" : "http:\/\/sfy.co\/ePR8",
      "display_url" : "sfy.co\/ePR8"
    } ]
  },
  "geo" : { },
  "id_str" : "373455105569198080",
  "text" : "RT @szlwzl: How to annoy @swmcc pt 2 http:\/\/t.co\/PHyvkRLffh #storify",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 13, 19 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "storify",
        "indices" : [ 48, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/PHyvkRLffh",
        "expanded_url" : "http:\/\/sfy.co\/ePR8",
        "display_url" : "sfy.co\/ePR8"
      } ]
    },
    "geo" : { },
    "id_str" : "373453098012131328",
    "text" : "How to annoy @swmcc pt 2 http:\/\/t.co\/PHyvkRLffh #storify",
    "id" : 373453098012131328,
    "created_at" : "2013-08-30 14:32:11 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 373455105569198080,
  "created_at" : "2013-08-30 14:40:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rip",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373395273294163968",
  "text" : "Seamus Heaney has died.... :( Another good one goes. #rip",
  "id" : 373395273294163968,
  "created_at" : "2013-08-30 10:42:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373352191853346816",
  "geo" : { },
  "id_str" : "373360832576364544",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl And again I would have fallen for it only for the fact that two notifications came up at once.. \"Fool me once shame on you....\"",
  "id" : 373360832576364544,
  "in_reply_to_status_id" : 373352191853346816,
  "created_at" : "2013-08-30 08:25:33 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 8, 15 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/fEL20WXTWy",
      "expanded_url" : "https:\/\/vine.co\/v\/hi9wLJAiaI5",
      "display_url" : "vine.co\/v\/hi9wLJAiaI5"
    } ]
  },
  "geo" : { },
  "id_str" : "373225428871569408",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco @szlwzl don't fuck with me again! https:\/\/t.co\/fEL20WXTWy",
  "id" : 373225428871569408,
  "created_at" : "2013-08-29 23:27:31 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373223124420284416",
  "geo" : { },
  "id_str" : "373223448736047104",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco NO FUCKING NEED... NO FUCKING NEED. Fuck Syria you need bombed right now for that.... NO FUCKING NEED. LOW BLOW JR.. LOW BLOW",
  "id" : 373223448736047104,
  "in_reply_to_status_id" : 373223124420284416,
  "created_at" : "2013-08-29 23:19:38 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/373221906465296384\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/iTkr7OkM0C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS3zWLWCEAAkifZ.png",
      "id_str" : "373221906469490688",
      "id" : 373221906469490688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS3zWLWCEAAkifZ.png",
      "sizes" : [ {
        "h" : 573,
        "resize" : "fit",
        "w" : 424
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 424
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 424
      } ],
      "display_url" : "pic.twitter.com\/iTkr7OkM0C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373221906465296384",
  "text" : "This is what a wanker looks like in your timeline.... And yes \"that\" fucking song is in my head now. http:\/\/t.co\/iTkr7OkM0C",
  "id" : 373221906465296384,
  "created_at" : "2013-08-29 23:13:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 13, 20 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373219882835271680",
  "text" : "FUCK SAKE... @szlwzl sending me scheduled messages again about THAT FUCKING FRIDAY song.....",
  "id" : 373219882835271680,
  "created_at" : "2013-08-29 23:05:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 8, 16 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 17, 26 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373218193818406912",
  "geo" : { },
  "id_str" : "373218550753685504",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco @jbrevel @davehedo I am away from you twats for six days and I've forgot the fllth... either that or no longer horny cos no Dave ;)",
  "id" : 373218550753685504,
  "in_reply_to_status_id" : 373218193818406912,
  "created_at" : "2013-08-29 23:00:11 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373192599714004992",
  "text" : "And yeah I am going for georgian stripes... That's just how I fucking roll!!!! So new oil tank, two new doors.. The presbie in me is crying!",
  "id" : 373192599714004992,
  "created_at" : "2013-08-29 21:17:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373192417064648704",
  "text" : "I had a dude round today to measure a new back and front door. I am now looking forward to getting them. Who said getting old was fun?",
  "id" : 373192417064648704,
  "created_at" : "2013-08-29 21:16:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 13, 22 ],
      "id_str" : "95932190",
      "id" : 95932190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373129200825548800",
  "geo" : { },
  "id_str" : "373192175476957185",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @brrygrdn I for one never tire of his pussy stories.",
  "id" : 373192175476957185,
  "in_reply_to_status_id" : 373129200825548800,
  "created_at" : "2013-08-29 21:15:22 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 4, 13 ],
      "id_str" : "95932190",
      "id" : 95932190
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 25, 37 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373112322878742528",
  "text" : "Yay @brrygrdn talking at @BelfastRuby next Tuesday.. About fucking time son... about fucking time! :D",
  "id" : 373112322878742528,
  "created_at" : "2013-08-29 15:58:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372830532310032384",
  "text" : "Having a Google Auth app on my laptop offends me in every way possible..",
  "id" : 372830532310032384,
  "created_at" : "2013-08-28 21:18:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    }, {
      "name" : "Geek Dinner Club",
      "screen_name" : "GeekDinnerClub",
      "indices" : [ 14, 29 ],
      "id_str" : "469245111",
      "id" : 469245111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372725947666939904",
  "geo" : { },
  "id_str" : "372750782384189441",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es @GeekDinnerClub oil tank related business :D",
  "id" : 372750782384189441,
  "in_reply_to_status_id" : 372725947666939904,
  "created_at" : "2013-08-28 16:01:26 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Gibson",
      "screen_name" : "stuartgibson",
      "indices" : [ 0, 13 ],
      "id_str" : "6806292",
      "id" : 6806292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372742214667223040",
  "geo" : { },
  "id_str" : "372748782636511232",
  "in_reply_to_user_id" : 6806292,
  "text" : "@stuartgibson do what I did - and logout... then come back in again when it is safe :)",
  "id" : 372748782636511232,
  "in_reply_to_status_id" : 372742214667223040,
  "created_at" : "2013-08-28 15:53:29 +0000",
  "in_reply_to_screen_name" : "stuartgibson",
  "in_reply_to_user_id_str" : "6806292",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "indices" : [ 0, 10 ],
      "id_str" : "1248789104",
      "id" : 1248789104
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imabitch",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372705731134631936",
  "geo" : { },
  "id_str" : "372705901230039040",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@hadooping you should be using Github issues to tell me to wind my neck in and close the issue.. Then I'll promptly re-open it :D #imabitch",
  "id" : 372705901230039040,
  "in_reply_to_status_id" : 372705731134631936,
  "created_at" : "2013-08-28 13:03:06 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geek Dinner Club",
      "screen_name" : "GeekDinnerClub",
      "indices" : [ 21, 36 ],
      "id_str" : "469245111",
      "id" : 469245111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372692357235240962",
  "text" : "Can't make it to the @GeekDinnerClub tonight again :( Next month though... Next month....",
  "id" : 372692357235240962,
  "created_at" : "2013-08-28 12:09:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "indices" : [ 0, 10 ],
      "id_str" : "1248789104",
      "id" : 1248789104
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 11, 18 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372674468449366016",
  "geo" : { },
  "id_str" : "372674544789499904",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@hadooping @szlwzl he wont facetime with me - i've tried ;)",
  "id" : 372674544789499904,
  "in_reply_to_status_id" : 372674468449366016,
  "created_at" : "2013-08-28 10:58:30 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372673609564950528",
  "geo" : { },
  "id_str" : "372674262487678976",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl sniff\/lick my seat and it'll be like I was inside you... I mean with you.... :)",
  "id" : 372674262487678976,
  "in_reply_to_status_id" : 372673609564950528,
  "created_at" : "2013-08-28 10:57:22 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 12, 18 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372673733992792064",
  "text" : "RT @szlwzl: @swmcc If I change it, it's like you're not here any more and I don't want that to be the case...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "372673355838533632",
    "geo" : { },
    "id_str" : "372673609564950528",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc If I change it, it's like you're not here any more and I don't want that to be the case...",
    "id" : 372673609564950528,
    "in_reply_to_status_id" : 372673355838533632,
    "created_at" : "2013-08-28 10:54:47 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 372673733992792064,
  "created_at" : "2013-08-28 10:55:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372672958705451008",
  "geo" : { },
  "id_str" : "372673355838533632",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl how so? - you can change the 'alpha' to be anything you want - or is it cos it reminds you of my awesomeness? :)",
  "id" : 372673355838533632,
  "in_reply_to_status_id" : 372672958705451008,
  "created_at" : "2013-08-28 10:53:46 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 3, 10 ],
      "id_str" : "17843859",
      "id" : 17843859
    }, {
      "name" : "LNUG",
      "screen_name" : "LNUGorg",
      "indices" : [ 108, 116 ],
      "id_str" : "1354066866",
      "id" : 1354066866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372671496105107457",
  "text" : "RT @rtweed: Node.js developers: healthcare IT needs you - the subject of my 5 minute lightning talk tonight @LNUGorg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LNUG",
        "screen_name" : "LNUGorg",
        "indices" : [ 96, 104 ],
        "id_str" : "1354066866",
        "id" : 1354066866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372670419406716928",
    "text" : "Node.js developers: healthcare IT needs you - the subject of my 5 minute lightning talk tonight @LNUGorg",
    "id" : 372670419406716928,
    "created_at" : "2013-08-28 10:42:06 +0000",
    "user" : {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "protected" : false,
      "id_str" : "17843859",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1398354510\/me_normal.png",
      "id" : 17843859,
      "verified" : false
    }
  },
  "id" : 372671496105107457,
  "created_at" : "2013-08-28 10:46:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "belfast",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372669001228238848",
  "text" : "Logged onto ##belfast there seen a lot of trolling going on. Thought fuck that. I'll be back when it fucks up :)",
  "id" : 372669001228238848,
  "created_at" : "2013-08-28 10:36:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loveyoureally",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372663994814693379",
  "text" : "Oi @szlwzl see if you want to call me names and 'kick me when I am down' - have the balls to email yourself you twat! :) #loveyoureally",
  "id" : 372663994814693379,
  "created_at" : "2013-08-28 10:16:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 13, 22 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 23, 36 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372653643209924608",
  "geo" : { },
  "id_str" : "372654405138395136",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid @davehedo @stevebiscuit What can I say I am just so photogenic :)",
  "id" : 372654405138395136,
  "in_reply_to_status_id" : 372653643209924608,
  "created_at" : "2013-08-28 09:38:28 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 10, 22 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 23, 36 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372284788758953984",
  "geo" : { },
  "id_str" : "372653137057681408",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo @DebbieCReid @stevebiscuit right you lot - its a fuckin' tesco bag alright!!",
  "id" : 372653137057681408,
  "in_reply_to_status_id" : 372284788758953984,
  "created_at" : "2013-08-28 09:33:26 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Jaffrey",
      "screen_name" : "jaffs",
      "indices" : [ 3, 9 ],
      "id_str" : "14511835",
      "id" : 14511835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/1Cuj3CqEkG",
      "expanded_url" : "http:\/\/d.pr\/i\/HJen",
      "display_url" : "d.pr\/i\/HJen"
    } ]
  },
  "geo" : { },
  "id_str" : "372619276144099328",
  "text" : "RT @jaffs: A jolly nice cartoon strip on life and career choices - http:\/\/t.co\/1Cuj3CqEkG",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/1Cuj3CqEkG",
        "expanded_url" : "http:\/\/d.pr\/i\/HJen",
        "display_url" : "d.pr\/i\/HJen"
      } ]
    },
    "geo" : { },
    "id_str" : "372615656346099712",
    "text" : "A jolly nice cartoon strip on life and career choices - http:\/\/t.co\/1Cuj3CqEkG",
    "id" : 372615656346099712,
    "created_at" : "2013-08-28 07:04:29 +0000",
    "user" : {
      "name" : "Andy Jaffrey",
      "screen_name" : "jaffs",
      "protected" : false,
      "id_str" : "14511835",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1840978640\/380144_10150593042997564_916334703_n_normal.jpg",
      "id" : 14511835,
      "verified" : false
    }
  },
  "id" : 372619276144099328,
  "created_at" : "2013-08-28 07:18:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 3, 15 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372481231906406400",
  "text" : "RT @willemkokke: As a foreigner I can safely say that the NHS is something to be proud of. Don't dismantle it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372476742541516800",
    "text" : "As a foreigner I can safely say that the NHS is something to be proud of. Don't dismantle it!",
    "id" : 372476742541516800,
    "created_at" : "2013-08-27 21:52:30 +0000",
    "user" : {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "protected" : false,
      "id_str" : "78104215",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1738070632\/profile_normal.JPG",
      "id" : 78104215,
      "verified" : false
    }
  },
  "id" : 372481231906406400,
  "created_at" : "2013-08-27 22:10:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rumble Labs",
      "screen_name" : "rumblelabs",
      "indices" : [ 3, 14 ],
      "id_str" : "20454184",
      "id" : 20454184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/HNrbOLv8P9",
      "expanded_url" : "http:\/\/rumblelabs.com\/jobs\/senior-objective-c-developer",
      "display_url" : "rumblelabs.com\/jobs\/senior-ob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372404543130054656",
  "text" : "RT @rumblelabs: We\u2019re on the lookout for a new iOS\/Mac Developer. Fancy it, or know someone who would? http:\/\/t.co\/HNrbOLv8P9 Please RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/HNrbOLv8P9",
        "expanded_url" : "http:\/\/rumblelabs.com\/jobs\/senior-objective-c-developer",
        "display_url" : "rumblelabs.com\/jobs\/senior-ob\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372399450544959488",
    "text" : "We\u2019re on the lookout for a new iOS\/Mac Developer. Fancy it, or know someone who would? http:\/\/t.co\/HNrbOLv8P9 Please RT",
    "id" : 372399450544959488,
    "created_at" : "2013-08-27 16:45:22 +0000",
    "user" : {
      "name" : "Rumble Labs",
      "screen_name" : "rumblelabs",
      "protected" : false,
      "id_str" : "20454184",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3220068899\/9b4724a520f2eb9250c0fa57c4b6d700_normal.png",
      "id" : 20454184,
      "verified" : false
    }
  },
  "id" : 372404543130054656,
  "created_at" : "2013-08-27 17:05:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 3, 14 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372387184352849920",
  "text" : "So @davidjrice says you can eat 4 cheescakes and lose weight. I have proof that this doesn't work. He's a beardy fucking lair is what he is.",
  "id" : 372387184352849920,
  "created_at" : "2013-08-27 15:56:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 20, 29 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372289377524658176",
  "text" : "RT @jbrevel: @swmcc @davehedo Not the @ symbol again!! No need! Good luck in the new job!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "David Henderson",
        "screen_name" : "davehedo",
        "indices" : [ 7, 16 ],
        "id_str" : "50985598",
        "id" : 50985598
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "372285211288948736",
    "geo" : { },
    "id_str" : "372289208380952577",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @davehedo Not the @ symbol again!! No need! Good luck in the new job!",
    "id" : 372289208380952577,
    "in_reply_to_status_id" : 372285211288948736,
    "created_at" : "2013-08-27 09:27:18 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 372289377524658176,
  "created_at" : "2013-08-27 09:27:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beforeandafter",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372284788758953984",
  "geo" : { },
  "id_str" : "372285211288948736",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo wondered when this was gonna be used - you prick :) Miss you xxxxxxxxxxxxxxxxx 3========) (.) and 3=========) (@) #beforeandafter",
  "id" : 372285211288948736,
  "in_reply_to_status_id" : 372284788758953984,
  "created_at" : "2013-08-27 09:11:25 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372087608416817153",
  "geo" : { },
  "id_str" : "372093487706959872",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir first one is the best. :)",
  "id" : 372093487706959872,
  "in_reply_to_status_id" : 372087608416817153,
  "created_at" : "2013-08-26 20:29:35 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372084852084203520",
  "geo" : { },
  "id_str" : "372085248139735040",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir that\u2019s one of those good problems.",
  "id" : 372085248139735040,
  "in_reply_to_status_id" : 372084852084203520,
  "created_at" : "2013-08-26 19:56:50 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372077241255362560",
  "geo" : { },
  "id_str" : "372077444008009728",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo yes but original version is better. You finish GoT.",
  "id" : 372077444008009728,
  "in_reply_to_status_id" : 372077241255362560,
  "created_at" : "2013-08-26 19:25:50 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 10, 17 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372076801994272768",
  "geo" : { },
  "id_str" : "372077174221996032",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo @szlwzl you come down here David and I will show you.",
  "id" : 372077174221996032,
  "in_reply_to_status_id" : 372076801994272768,
  "created_at" : "2013-08-26 19:24:45 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sucklikefuckbutnotinagoodway",
      "indices" : [ 83, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372074931120390144",
  "text" : "New oil tank delivered... Now how to get the oil from the old tank to the new one. #sucklikefuckbutnotinagoodway",
  "id" : 372074931120390144,
  "created_at" : "2013-08-26 19:15:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372072184631808000",
  "geo" : { },
  "id_str" : "372072496356270082",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues not so much on SG: A.... I am gonna watch Newsroom now though..",
  "id" : 372072496356270082,
  "in_reply_to_status_id" : 372072184631808000,
  "created_at" : "2013-08-26 19:06:10 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby News",
      "screen_name" : "ruby_news",
      "indices" : [ 3, 13 ],
      "id_str" : "16903992",
      "id" : 16903992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/wwPJOMxjVi",
      "expanded_url" : "http:\/\/bit.ly\/16EdO2R",
      "display_url" : "bit.ly\/16EdO2R"
    } ]
  },
  "geo" : { },
  "id_str" : "372042819172438018",
  "text" : "RT @ruby_news: Writing Sensible Tests for Happiness http:\/\/t.co\/wwPJOMxjVi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/wwPJOMxjVi",
        "expanded_url" : "http:\/\/bit.ly\/16EdO2R",
        "display_url" : "bit.ly\/16EdO2R"
      } ]
    },
    "geo" : { },
    "id_str" : "372018632986857472",
    "text" : "Writing Sensible Tests for Happiness http:\/\/t.co\/wwPJOMxjVi",
    "id" : 372018632986857472,
    "created_at" : "2013-08-26 15:32:08 +0000",
    "user" : {
      "name" : "Ruby News",
      "screen_name" : "ruby_news",
      "protected" : false,
      "id_str" : "16903992",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1224369862\/Ruby-News-Logo_normal.png",
      "id" : 16903992,
      "verified" : false
    }
  },
  "id" : 372042819172438018,
  "created_at" : "2013-08-26 17:08:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371730192697659392",
  "geo" : { },
  "id_str" : "371730359689310208",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne ring away but my mobile isn't working anymore so you'll get through to voicemail :)",
  "id" : 371730359689310208,
  "in_reply_to_status_id" : 371730192697659392,
  "created_at" : "2013-08-25 20:26:38 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371727050375049217",
  "text" : "Ahhhh Bank Holiday Mondays...... You fucking star.",
  "id" : 371727050375049217,
  "created_at" : "2013-08-25 20:13:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 113, 119 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truefact",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371722335210192896",
  "geo" : { },
  "id_str" : "371722666673070080",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl small steps SiSi. We just stopped marrying our cousins two generations ago. #truefact Cousins marrying = @swmcc two generations down",
  "id" : 371722666673070080,
  "in_reply_to_status_id" : 371722335210192896,
  "created_at" : "2013-08-25 19:56:04 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371721290581016576",
  "geo" : { },
  "id_str" : "371721973463670784",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl That's just down the road from where my \"homeplace\" is. That's country for \"where my family comes from before we sold\". Small world",
  "id" : 371721973463670784,
  "in_reply_to_status_id" : 371721290581016576,
  "created_at" : "2013-08-25 19:53:19 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371721290581016576",
  "geo" : { },
  "id_str" : "371721456003973122",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl that narrows it down a bit.. You not got a road?",
  "id" : 371721456003973122,
  "in_reply_to_status_id" : 371721290581016576,
  "created_at" : "2013-08-25 19:51:16 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371720414143455232",
  "geo" : { },
  "id_str" : "371720843115515904",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl asshole... where abouts were ya?",
  "id" : 371720843115515904,
  "in_reply_to_status_id" : 371720414143455232,
  "created_at" : "2013-08-25 19:48:49 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371711609594724353",
  "geo" : { },
  "id_str" : "371720023158439936",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl the zoo?",
  "id" : 371720023158439936,
  "in_reply_to_status_id" : 371711609594724353,
  "created_at" : "2013-08-25 19:45:34 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371585133289435136",
  "geo" : { },
  "id_str" : "371604066746380288",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall Replacement sim I think :)",
  "id" : 371604066746380288,
  "in_reply_to_status_id" : 371585133289435136,
  "created_at" : "2013-08-25 12:04:48 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 14, 21 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371426095909724160",
  "geo" : { },
  "id_str" : "371579906229948419",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es @szlwzl idiots",
  "id" : 371579906229948419,
  "in_reply_to_status_id" : 371426095909724160,
  "created_at" : "2013-08-25 10:28:47 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371579743797116928",
  "text" : "Damaged my sim on my iPhone. If you want me you can still iMessage me I guess.",
  "id" : 371579743797116928,
  "created_at" : "2013-08-25 10:28:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371356080497897472",
  "text" : "How do parents mind their kids full time? Its fookin exhausting...",
  "id" : 371356080497897472,
  "created_at" : "2013-08-24 19:39:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370974376939646976",
  "text" : "Have to admit though... am wondering what the fuck will happen when I turn the oven on later....",
  "id" : 370974376939646976,
  "created_at" : "2013-08-23 18:22:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370974217258287105",
  "text" : "This smells expensive..... My Presbie powers sense such things..",
  "id" : 370974217258287105,
  "created_at" : "2013-08-23 18:22:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370973826072334337",
  "text" : "My house smells of heating oil..... Well downstairs at least. Either I'm having a stroke or something really fucked up has occurred.",
  "id" : 370973826072334337,
  "created_at" : "2013-08-23 18:20:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/370938333884473345\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/rpk3IzSdxS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSXWcwmCYAAvav4.jpg",
      "id_str" : "370938333897056256",
      "id" : 370938333897056256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSXWcwmCYAAvav4.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/rpk3IzSdxS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370938333884473345",
  "text" : "Last day at RepKnight.. JR said I can come back and molest the boys anytime. I have proof :) http:\/\/t.co\/rpk3IzSdxS",
  "id" : 370938333884473345,
  "created_at" : "2013-08-23 15:59:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gedeon Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 3, 10 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "developers",
      "indices" : [ 12, 23 ]
    }, {
      "text" : "developers",
      "indices" : [ 24, 35 ]
    }, {
      "text" : "developers",
      "indices" : [ 36, 47 ]
    }, {
      "text" : "developers",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "developers",
      "indices" : [ 61, 72 ]
    }, {
      "text" : "developers",
      "indices" : [ 73, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370913687193649153",
  "text" : "RT @gedeon: #developers #developers #developers\n\n#developers #developers #developers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "developers",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "developers",
        "indices" : [ 12, 23 ]
      }, {
        "text" : "developers",
        "indices" : [ 24, 35 ]
      }, {
        "text" : "developers",
        "indices" : [ 37, 48 ]
      }, {
        "text" : "developers",
        "indices" : [ 49, 60 ]
      }, {
        "text" : "developers",
        "indices" : [ 61, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370907806784045056",
    "text" : "#developers #developers #developers\n\n#developers #developers #developers",
    "id" : 370907806784045056,
    "created_at" : "2013-08-23 13:58:06 +0000",
    "user" : {
      "name" : "Gedeon Maheux",
      "screen_name" : "gedeon",
      "protected" : false,
      "id_str" : "38003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602254647\/2b10925e3c176b25cedef39d81793ae2_normal.png",
      "id" : 38003,
      "verified" : false
    }
  },
  "id" : 370913687193649153,
  "created_at" : "2013-08-23 14:21:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "presbiejokes",
      "indices" : [ 46, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370831469805334528",
  "geo" : { },
  "id_str" : "370831670900826112",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl so its a Reformed Presbyterian robot? #presbiejokes",
  "id" : 370831670900826112,
  "in_reply_to_status_id" : 370831469805334528,
  "created_at" : "2013-08-23 08:55:34 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370807722817896448",
  "geo" : { },
  "id_str" : "370827521270370304",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you rat bastard so I was tweeting a robot back? Well played Si Si...",
  "id" : 370827521270370304,
  "in_reply_to_status_id" : 370807722817896448,
  "created_at" : "2013-08-23 08:39:05 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/oSuWBn2gUM",
      "expanded_url" : "http:\/\/www.brainyquote.com\/quotes\/quotes\/a\/alberteins133991.html",
      "display_url" : "brainyquote.com\/quotes\/quotes\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370802761975095296",
  "text" : "Ben Affleck &amp; Zack Synder take note http:\/\/t.co\/oSuWBn2gUM",
  "id" : 370802761975095296,
  "created_at" : "2013-08-23 07:00:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370683660380274688",
  "geo" : { },
  "id_str" : "370683974005583872",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl dick",
  "id" : 370683974005583872,
  "in_reply_to_status_id" : 370683660380274688,
  "created_at" : "2013-08-22 23:08:41 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370683157000904705",
  "geo" : { },
  "id_str" : "370683225976635392",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you are a fucking knob",
  "id" : 370683225976635392,
  "in_reply_to_status_id" : 370683157000904705,
  "created_at" : "2013-08-22 23:05:42 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyra McKee",
      "screen_name" : "LyraMcKee",
      "indices" : [ 0, 10 ],
      "id_str" : "76377195",
      "id" : 76377195
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 11, 19 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370680220900413440",
  "geo" : { },
  "id_str" : "370683027804151808",
  "in_reply_to_user_id" : 76377195,
  "text" : "@LyraMcKee @HaVoCT5 cheers guys :)",
  "id" : 370683027804151808,
  "in_reply_to_status_id" : 370680220900413440,
  "created_at" : "2013-08-22 23:04:55 +0000",
  "in_reply_to_screen_name" : "LyraMcKee",
  "in_reply_to_user_id_str" : "76377195",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370637039970295809",
  "geo" : { },
  "id_str" : "370666073450094593",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl and heroku just went \u201Cshiiiiiiiiiiiiit\u201D",
  "id" : 370666073450094593,
  "in_reply_to_status_id" : 370637039970295809,
  "created_at" : "2013-08-22 21:57:33 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyra McKee",
      "screen_name" : "LyraMcKee",
      "indices" : [ 0, 10 ],
      "id_str" : "76377195",
      "id" : 76377195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370655721408720896",
  "geo" : { },
  "id_str" : "370665474675466240",
  "in_reply_to_user_id" : 76377195,
  "text" : "@LyraMcKee cheers :)",
  "id" : 370665474675466240,
  "in_reply_to_status_id" : 370655721408720896,
  "created_at" : "2013-08-22 21:55:10 +0000",
  "in_reply_to_screen_name" : "LyraMcKee",
  "in_reply_to_user_id_str" : "76377195",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyra McKee",
      "screen_name" : "LyraMcKee",
      "indices" : [ 3, 13 ],
      "id_str" : "76377195",
      "id" : 76377195
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 64, 70 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followfriday",
      "indices" : [ 24, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370665442798759936",
  "text" : "RT @LyraMcKee: It\u2019s not #followfriday but you should all follow @swmcc. The filth that comes from that Twitter account is disturbingly bril\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 49, 55 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "followfriday",
        "indices" : [ 9, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370655721408720896",
    "text" : "It\u2019s not #followfriday but you should all follow @swmcc. The filth that comes from that Twitter account is disturbingly brilliant.",
    "id" : 370655721408720896,
    "created_at" : "2013-08-22 21:16:25 +0000",
    "user" : {
      "name" : "Lyra McKee",
      "screen_name" : "LyraMcKee",
      "protected" : false,
      "id_str" : "76377195",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000447967102\/212828e6e9b76d758e645426b4b6064d_normal.jpeg",
      "id" : 76377195,
      "verified" : false
    }
  },
  "id" : 370665442798759936,
  "created_at" : "2013-08-22 21:55:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 3, 15 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 17, 23 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370632306941128704",
  "text" : "RT @ryancunning: @swmcc its beside the big ass Tesco at knockbreda. If u can fondle me ill make u a cuppa :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "370631058502348800",
    "geo" : { },
    "id_str" : "370631587026976768",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc its beside the big ass Tesco at knockbreda. If u can fondle me ill make u a cuppa :-)",
    "id" : 370631587026976768,
    "in_reply_to_status_id" : 370631058502348800,
    "created_at" : "2013-08-22 19:40:31 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "protected" : false,
      "id_str" : "226910307",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2967225463\/259afd99351fb98b5adbe39e09b9a681_normal.jpeg",
      "id" : 226910307,
      "verified" : false
    }
  },
  "id" : 370632306941128704,
  "created_at" : "2013-08-22 19:43:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 3, 15 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370632210593742848",
  "text" : "RT @ryancunning: Still, just a lil creeped out with how friendly all my new neighbours are! Gettin there tho.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370621516880576512",
    "text" : "Still, just a lil creeped out with how friendly all my new neighbours are! Gettin there tho.",
    "id" : 370621516880576512,
    "created_at" : "2013-08-22 19:00:30 +0000",
    "user" : {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "protected" : false,
      "id_str" : "226910307",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2967225463\/259afd99351fb98b5adbe39e09b9a681_normal.jpeg",
      "id" : 226910307,
      "verified" : false
    }
  },
  "id" : 370632210593742848,
  "created_at" : "2013-08-22 19:42:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370631587026976768",
  "geo" : { },
  "id_str" : "370632163227484160",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning I'm starting work near there on Monday - Beechill Business Park.. So game on bitch!! I is gonna get fondled :)",
  "id" : 370632163227484160,
  "in_reply_to_status_id" : 370631587026976768,
  "created_at" : "2013-08-22 19:42:48 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370630818378842112",
  "geo" : { },
  "id_str" : "370631058502348800",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning Hot as fuck :) I've just been working like blue fuck this summer so only slowing down now :) Is it near the Knock Carriageway?",
  "id" : 370631058502348800,
  "in_reply_to_status_id" : 370630818378842112,
  "created_at" : "2013-08-22 19:38:25 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370621516880576512",
  "geo" : { },
  "id_str" : "370630051546406912",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning and will you still have to ask me insulting \"token protestant\" friend questions on how we do stuff? :)",
  "id" : 370630051546406912,
  "in_reply_to_status_id" : 370621516880576512,
  "created_at" : "2013-08-22 19:34:24 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370621516880576512",
  "geo" : { },
  "id_str" : "370629914556235776",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning where did you move to?",
  "id" : 370629914556235776,
  "in_reply_to_status_id" : 370621516880576512,
  "created_at" : "2013-08-22 19:33:52 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370626640776556545",
  "geo" : { },
  "id_str" : "370629809488928768",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl :) But I'll miss ya regardless Si Si :)",
  "id" : 370629809488928768,
  "in_reply_to_status_id" : 370626640776556545,
  "created_at" : "2013-08-22 19:33:27 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyra McKee",
      "screen_name" : "LyraMcKee",
      "indices" : [ 0, 10 ],
      "id_str" : "76377195",
      "id" : 76377195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370574567896805376",
  "geo" : { },
  "id_str" : "370582649573613568",
  "in_reply_to_user_id" : 76377195,
  "text" : "@LyraMcKee you'll get up to 1200 by Friday no worries.",
  "id" : 370582649573613568,
  "in_reply_to_status_id" : 370574567896805376,
  "created_at" : "2013-08-22 16:26:03 +0000",
  "in_reply_to_screen_name" : "LyraMcKee",
  "in_reply_to_user_id_str" : "76377195",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 4, 11 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/oqL2w0Pc1Z",
      "expanded_url" : "https:\/\/vine.co\/v\/hebdnPVYZZl",
      "display_url" : "vine.co\/v\/hebdnPVYZZl"
    } ]
  },
  "geo" : { },
  "id_str" : "370534341299806208",
  "text" : "And @szlwzl caught singing to Rebecca Black :)  https:\/\/t.co\/oqL2w0Pc1Z",
  "id" : 370534341299806208,
  "created_at" : "2013-08-22 13:14:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/rXLRdLoFnH",
      "expanded_url" : "https:\/\/vine.co\/v\/hebdnPVYZZl",
      "display_url" : "vine.co\/v\/hebdnPVYZZl"
    } ]
  },
  "geo" : { },
  "id_str" : "370533872116989952",
  "text" : "Fucking torture https:\/\/t.co\/rXLRdLoFnH",
  "id" : 370533872116989952,
  "created_at" : "2013-08-22 13:12:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370527473873989632",
  "geo" : { },
  "id_str" : "370527685656580098",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl it's the little things you fucking twat.",
  "id" : 370527685656580098,
  "in_reply_to_status_id" : 370527473873989632,
  "created_at" : "2013-08-22 12:47:38 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 0, 9 ],
      "id_str" : "729883",
      "id" : 729883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370522424326246401",
  "geo" : { },
  "id_str" : "370522622095679490",
  "in_reply_to_user_id" : 729883,
  "text" : "@chrismcg anything i need to do will be safe enough - but the thoughts of having to go back to apache for work purposes :( yuck :(",
  "id" : 370522622095679490,
  "in_reply_to_status_id" : 370522424326246401,
  "created_at" : "2013-08-22 12:27:31 +0000",
  "in_reply_to_screen_name" : "chrismcg",
  "in_reply_to_user_id_str" : "729883",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370522244591521792",
  "text" : "Its the little things :)",
  "id" : 370522244591521792,
  "created_at" : "2013-08-22 12:26:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 46, 55 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 90, 98 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370522210554761216",
  "text" : "I'm gonna miss this place... For example when @davehedo is on the phone to his Mrs me and @jbrevel pretend to be girls and shout at him..",
  "id" : 370522210554761216,
  "created_at" : "2013-08-22 12:25:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 0, 9 ],
      "id_str" : "729883",
      "id" : 729883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/NJ3y9D6nBh",
      "expanded_url" : "http:\/\/nginx.com\/products\/",
      "display_url" : "nginx.com\/products\/"
    } ]
  },
  "in_reply_to_status_id_str" : "370521456805158912",
  "geo" : { },
  "id_str" : "370521701701799936",
  "in_reply_to_user_id" : 729883,
  "text" : "@chrismcg http:\/\/t.co\/NJ3y9D6nBh - unless I am reading it wrong.",
  "id" : 370521701701799936,
  "in_reply_to_status_id" : 370521456805158912,
  "created_at" : "2013-08-22 12:23:52 +0000",
  "in_reply_to_screen_name" : "chrismcg",
  "in_reply_to_user_id_str" : "729883",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nginx web server",
      "screen_name" : "nginx",
      "indices" : [ 19, 25 ],
      "id_str" : "995848285",
      "id" : 995848285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370515585370562560",
  "text" : "Not too happy with @nginx going closed source :(",
  "id" : 370515585370562560,
  "created_at" : "2013-08-22 11:59:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 12, 20 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 21, 28 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370502005917491200",
  "geo" : { },
  "id_str" : "370502293788971008",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne @jbrevel @szlwzl No worries Mark the hidden cams will take care of it.",
  "id" : 370502293788971008,
  "in_reply_to_status_id" : 370502005917491200,
  "created_at" : "2013-08-22 11:06:45 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 12, 20 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 25, 32 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370499314625171456",
  "text" : "Fuck sake.. @jbrevel and @szlwzl singing \"Its Friday\" song... I kid you fucking not.... And Simon just did a fist pump at the \"yeah\" part.",
  "id" : 370499314625171456,
  "created_at" : "2013-08-22 10:54:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Belles",
      "screen_name" : "bellesoutdoor",
      "indices" : [ 3, 17 ],
      "id_str" : "68695599",
      "id" : 68695599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/0KIg36zcAl",
      "expanded_url" : "https:\/\/www.arthurguinnessprojects.com\/sport\/belles-race-across-america",
      "display_url" : "arthurguinnessprojects.com\/sport\/belles-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370448250375258112",
  "text" : "RT @bellesoutdoor: 616 votes!!! SPRINT finish required today and tomorrow from everyone who knows us https:\/\/t.co\/0KIg36zcAl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/0KIg36zcAl",
        "expanded_url" : "https:\/\/www.arthurguinnessprojects.com\/sport\/belles-race-across-america",
        "display_url" : "arthurguinnessprojects.com\/sport\/belles-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370445371430141952",
    "text" : "616 votes!!! SPRINT finish required today and tomorrow from everyone who knows us https:\/\/t.co\/0KIg36zcAl",
    "id" : 370445371430141952,
    "created_at" : "2013-08-22 07:20:33 +0000",
    "user" : {
      "name" : "The Belles",
      "screen_name" : "bellesoutdoor",
      "protected" : false,
      "id_str" : "68695599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000428126601\/e7f1bca097197a6db189bd15cad0a39b_normal.jpeg",
      "id" : 68695599,
      "verified" : false
    }
  },
  "id" : 370448250375258112,
  "created_at" : "2013-08-22 07:32:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Simon McCartney",
      "screen_name" : "simonmcc",
      "indices" : [ 8, 17 ],
      "id_str" : "6776922",
      "id" : 6776922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370262162323034112",
  "geo" : { },
  "id_str" : "370299370186346496",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @simonmcc That'll do - let me know when and where :)",
  "id" : 370299370186346496,
  "in_reply_to_status_id" : 370262162323034112,
  "created_at" : "2013-08-21 21:40:24 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 18, 26 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/xiHt86Kjqd",
      "expanded_url" : "https:\/\/vine.co\/v\/heBVIurTPDO",
      "display_url" : "vine.co\/v\/heBVIurTPDO"
    } ]
  },
  "geo" : { },
  "id_str" : "370179318129106944",
  "text" : "This I won't miss @jbrevel https:\/\/t.co\/xiHt86Kjqd",
  "id" : 370179318129106944,
  "created_at" : "2013-08-21 13:43:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370178088723689473",
  "text" : "OH: \"You're a 32 year old white man from Ballycastle\" - \"Damn right I am!\"",
  "id" : 370178088723689473,
  "created_at" : "2013-08-21 13:38:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370119450185318400",
  "geo" : { },
  "id_str" : "370121734055157760",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir that'll save you \u00A3 in the long run. Company I used to work for took the penny wise and pound foolish approach - near killed them.",
  "id" : 370121734055157760,
  "in_reply_to_status_id" : 370119450185318400,
  "created_at" : "2013-08-21 09:54:32 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    }, {
      "name" : "Patrick Devine",
      "screen_name" : "podevine",
      "indices" : [ 8, 17 ],
      "id_str" : "43728873",
      "id" : 43728873
    }, {
      "name" : "ShiftDock",
      "screen_name" : "shiftdock",
      "indices" : [ 18, 28 ],
      "id_str" : "555532046",
      "id" : 555532046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370115440501993473",
  "geo" : { },
  "id_str" : "370118282847588352",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir @podevine @shiftdock brilliant :) Great to hear you've got a base now :) I'd prefer to save \u00A3 than have a loft though :)",
  "id" : 370118282847588352,
  "in_reply_to_status_id" : 370115440501993473,
  "created_at" : "2013-08-21 09:40:49 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    }, {
      "name" : "Patrick Devine",
      "screen_name" : "podevine",
      "indices" : [ 8, 17 ],
      "id_str" : "43728873",
      "id" : 43728873
    }, {
      "name" : "ShiftDock",
      "screen_name" : "shiftdock",
      "indices" : [ 18, 28 ],
      "id_str" : "555532046",
      "id" : 555532046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370111970709471232",
  "geo" : { },
  "id_str" : "370113251792531456",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir @podevine @shiftdock where is shiftdock HQ then? :)",
  "id" : 370113251792531456,
  "in_reply_to_status_id" : 370111970709471232,
  "created_at" : "2013-08-21 09:20:50 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/369886850208382976\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Lcs6PHRhfp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSIaIWMCYAA6T7G.jpg",
      "id_str" : "369886850095144960",
      "id" : 369886850095144960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSIaIWMCYAA6T7G.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/Lcs6PHRhfp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369886850208382976",
  "text" : "I know. In a coffee shop with a binder reading a kindle on my iPad mini. I hate me too. http:\/\/t.co\/Lcs6PHRhfp",
  "id" : 369886850208382976,
  "created_at" : "2013-08-20 18:21:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 60, 73 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/2Qb6bPqlvV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=RMw3DO7r4xI",
      "display_url" : "youtube.com\/watch?v=RMw3DO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369846038162456578",
  "text" : "Best video on the internet ever. http:\/\/t.co\/2Qb6bPqlvV \/cc @RickyHassard",
  "id" : 369846038162456578,
  "created_at" : "2013-08-20 15:39:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Andrew Ebling",
      "screen_name" : "andyeb",
      "indices" : [ 14, 21 ],
      "id_str" : "14872262",
      "id" : 14872262
    }, {
      "name" : "Maurice Kelly",
      "screen_name" : "mauricerkelly",
      "indices" : [ 22, 36 ],
      "id_str" : "26198408",
      "id" : 26198408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369792695717617664",
  "geo" : { },
  "id_str" : "369844459950723072",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @andyeb @mauricerkelly hang on... you're straight? :) So I've been wasting my time for the last two years?????",
  "id" : 369844459950723072,
  "in_reply_to_status_id" : 369792695717617664,
  "created_at" : "2013-08-20 15:32:45 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 75, 84 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 89, 97 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369794536328806401",
  "text" : "I'm sooooo roooonnnllleeeeee, soooo roooooonnnnllleeeeee.. Those two tards @davehedo and @jbrevel have fucked off leaving me alone. CANTS!",
  "id" : 369794536328806401,
  "created_at" : "2013-08-20 12:14:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369581712390758400",
  "geo" : { },
  "id_str" : "369587904097816576",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you knob",
  "id" : 369587904097816576,
  "in_reply_to_status_id" : 369581712390758400,
  "created_at" : "2013-08-19 22:33:17 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 16, 24 ],
      "id_str" : "15966431",
      "id" : 15966431
    }, {
      "name" : "Refresh Belfast",
      "screen_name" : "refreshbelfast",
      "indices" : [ 28, 43 ],
      "id_str" : "20080166",
      "id" : 20080166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369558853165133824",
  "text" : "Amazing talk by @cobyism at @refreshbelfast tonight. Design for Open Source. Great to listen to someone with so much passion. Loved it.",
  "id" : 369558853165133824,
  "created_at" : "2013-08-19 20:37:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Box Belfast",
      "screen_name" : "BlackBoxBelfast",
      "indices" : [ 88, 104 ],
      "id_str" : "19528103",
      "id" : 19528103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refreshbelfast",
      "indices" : [ 53, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/QJaTJuyX9T",
      "expanded_url" : "http:\/\/4sq.com\/1eXzHiu",
      "display_url" : "4sq.com\/1eXzHiu"
    } ]
  },
  "geo" : { },
  "id_str" : "369513418606133249",
  "text" : "First one here like the fanboy I am. &lt;3 GitHub :) #refreshbelfast (@ The Black Box - @blackboxbelfast) http:\/\/t.co\/QJaTJuyX9T",
  "id" : 369513418606133249,
  "created_at" : "2013-08-19 17:37:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marc dowie",
      "screen_name" : "marcdowie",
      "indices" : [ 0, 10 ],
      "id_str" : "58811666",
      "id" : 58811666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369466222489780224",
  "geo" : { },
  "id_str" : "369466669392883712",
  "in_reply_to_user_id" : 58811666,
  "text" : "@marcdowie :) Well then if you didn't have an account would you be finding it hard to get a copy also? ;)",
  "id" : 369466669392883712,
  "in_reply_to_status_id" : 369466222489780224,
  "created_at" : "2013-08-19 14:31:33 +0000",
  "in_reply_to_screen_name" : "marcdowie",
  "in_reply_to_user_id_str" : "58811666",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marc dowie",
      "screen_name" : "marcdowie",
      "indices" : [ 0, 10 ],
      "id_str" : "58811666",
      "id" : 58811666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369465728195231744",
  "geo" : { },
  "id_str" : "369466006013345794",
  "in_reply_to_user_id" : 58811666,
  "text" : "@marcdowie I use netflix you robbing fucker! ;) But if I didn't have an account with them I would probably find that I haven't been able.",
  "id" : 369466006013345794,
  "in_reply_to_status_id" : 369465728195231744,
  "created_at" : "2013-08-19 14:28:54 +0000",
  "in_reply_to_screen_name" : "marcdowie",
  "in_reply_to_user_id_str" : "58811666",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 3, 12 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 14, 22 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 23, 33 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 54, 60 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mostlikely",
      "indices" : [ 111, 122 ]
    }, {
      "text" : "hopefully",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369461439020281856",
  "text" : "RT @davehedo: @jbrevel @smccalden I'm going to report @swmcc to Twitter for the craic, see if he gets arrested #mostlikely #hopefully",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Loughrey",
        "screen_name" : "jbrevel",
        "indices" : [ 0, 8 ],
        "id_str" : "50685221",
        "id" : 50685221
      }, {
        "name" : "Stephen McCalden",
        "screen_name" : "smccalden",
        "indices" : [ 9, 19 ],
        "id_str" : "169048119",
        "id" : 169048119
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 40, 46 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mostlikely",
        "indices" : [ 97, 108 ]
      }, {
        "text" : "hopefully",
        "indices" : [ 109, 119 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "369461080235327488",
    "geo" : { },
    "id_str" : "369461301304520704",
    "in_reply_to_user_id" : 804717,
    "text" : "@jbrevel @smccalden I'm going to report @swmcc to Twitter for the craic, see if he gets arrested #mostlikely #hopefully",
    "id" : 369461301304520704,
    "in_reply_to_status_id" : 369461080235327488,
    "created_at" : "2013-08-19 14:10:13 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "protected" : false,
      "id_str" : "50985598",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000509606650\/9ac4420064b46da165a3e180e20ef133_normal.jpeg",
      "id" : 50985598,
      "verified" : false
    }
  },
  "id" : 369461439020281856,
  "created_at" : "2013-08-19 14:10:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 9, 19 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 20, 29 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369460842326020096",
  "geo" : { },
  "id_str" : "369461080235327488",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @smccalden @davehedo also - mirror ;)",
  "id" : 369461080235327488,
  "in_reply_to_status_id" : 369460842326020096,
  "created_at" : "2013-08-19 14:09:20 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 9, 19 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 20, 29 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itcouldbebradpitt",
      "indices" : [ 53, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369460842326020096",
  "geo" : { },
  "id_str" : "369460982243803137",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @smccalden @davehedo all back look the same #itcouldbebradpitt",
  "id" : 369460982243803137,
  "in_reply_to_status_id" : 369460842326020096,
  "created_at" : "2013-08-19 14:08:57 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 9, 19 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 20, 29 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369460120486309888",
  "geo" : { },
  "id_str" : "369460355837083649",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @smccalden @davehedo nothing wrong with being a homosexual Locko. I am not - but I'd ride Dave just to see that look on his face ;)",
  "id" : 369460355837083649,
  "in_reply_to_status_id" : 369460120486309888,
  "created_at" : "2013-08-19 14:06:27 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 11, 19 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 20, 29 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369458943652679681",
  "geo" : { },
  "id_str" : "369460049283780608",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @jbrevel @davehedo Fucking hate you three cunts though.",
  "id" : 369460049283780608,
  "in_reply_to_status_id" : 369458943652679681,
  "created_at" : "2013-08-19 14:05:14 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 11, 19 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 20, 29 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369458943652679681",
  "geo" : { },
  "id_str" : "369460003477786625",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @jbrevel @davehedo I like Take That.",
  "id" : 369460003477786625,
  "in_reply_to_status_id" : 369458943652679681,
  "created_at" : "2013-08-19 14:05:03 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369451256416186370",
  "text" : "I just did a conference call where I was helpful and talked.... Gotta put a stop to that..",
  "id" : 369451256416186370,
  "created_at" : "2013-08-19 13:30:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McClelland",
      "screen_name" : "chrismcclelland",
      "indices" : [ 3, 19 ],
      "id_str" : "12952252",
      "id" : 12952252
    }, {
      "name" : "Refresh Belfast",
      "screen_name" : "refreshbelfast",
      "indices" : [ 40, 55 ],
      "id_str" : "20080166",
      "id" : 20080166
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 69, 76 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 79, 87 ],
      "id_str" : "15966431",
      "id" : 15966431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369451118364860417",
  "text" : "RT @chrismcclelland: Going to be a good @refreshbelfast tonight with @github's @cobyism talking design and open source. Looking forward to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Refresh Belfast",
        "screen_name" : "refreshbelfast",
        "indices" : [ 19, 34 ],
        "id_str" : "20080166",
        "id" : 20080166
      }, {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 48, 55 ],
        "id_str" : "13334762",
        "id" : 13334762
      }, {
        "name" : "Coby Chapple",
        "screen_name" : "cobyism",
        "indices" : [ 58, 66 ],
        "id_str" : "15966431",
        "id" : 15966431
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369450076759810048",
    "text" : "Going to be a good @refreshbelfast tonight with @github's @cobyism talking design and open source. Looking forward to it.",
    "id" : 369450076759810048,
    "created_at" : "2013-08-19 13:25:37 +0000",
    "user" : {
      "name" : "Chris McClelland",
      "screen_name" : "chrismcclelland",
      "protected" : false,
      "id_str" : "12952252",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000411737143\/9dd59aa3ec33c2de2b06f504a96e6709_normal.jpeg",
      "id" : 12952252,
      "verified" : false
    }
  },
  "id" : 369451118364860417,
  "created_at" : "2013-08-19 13:29:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369433946209021952",
  "text" : "Is it OCD that my hash rockets have to line up in my code?",
  "id" : 369433946209021952,
  "created_at" : "2013-08-19 12:21:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 25, 32 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Tyra Banks",
      "screen_name" : "tyrabanks",
      "indices" : [ 76, 86 ],
      "id_str" : "53153263",
      "id" : 53153263
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 129, 137 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369403771677192192",
  "text" : "The world is ending..... @szlwzl just quoted (in a whisper with the accent) @tyrabanks... in fact he just did it again to me and @jbrevel",
  "id" : 369403771677192192,
  "created_at" : "2013-08-19 10:21:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 23, 32 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pophischerryiwill",
      "indices" : [ 44, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369383549738041344",
  "text" : "Also .... Mandate with @davehedo tonight ;) #pophischerryiwill",
  "id" : 369383549738041344,
  "created_at" : "2013-08-19 09:01:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369383290861400064",
  "text" : "And now to shut down my twitter client for 12 hours in case any of you tards ruin Breaking Bad for me. For that would not be good.",
  "id" : 369383290861400064,
  "created_at" : "2013-08-19 09:00:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369180304990154752",
  "geo" : { },
  "id_str" : "369195774376022016",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I\u2019ve got pro plus in my drawer at work - you are welcome to them :)",
  "id" : 369195774376022016,
  "in_reply_to_status_id" : 369180304990154752,
  "created_at" : "2013-08-18 20:35:06 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369194803285614593",
  "geo" : { },
  "id_str" : "369195066469793793",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo you will :)",
  "id" : 369195066469793793,
  "in_reply_to_status_id" : 369194803285614593,
  "created_at" : "2013-08-18 20:32:17 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 46, 55 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/evBzb6omPr",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=r9YETpQ1V74",
      "display_url" : "youtube.com\/watch?v=r9YETp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369176989799690240",
  "text" : "Yeah, this.... http:\/\/t.co\/evBzb6omPr - go on @davehedo shave your head for me!!!!! ;)",
  "id" : 369176989799690240,
  "created_at" : "2013-08-18 19:20:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 3, 16 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/ytrlPEMwGb",
      "expanded_url" : "http:\/\/sickbiscuit.com\/blog\/2013\/08\/18\/contracting-in-london\/",
      "display_url" : "sickbiscuit.com\/blog\/2013\/08\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369171273345011712",
  "text" : "RT @stevebiscuit: A few garbled sentences about my experience contracting in London: http:\/\/t.co\/ytrlPEMwGb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/ytrlPEMwGb",
        "expanded_url" : "http:\/\/sickbiscuit.com\/blog\/2013\/08\/18\/contracting-in-london\/",
        "display_url" : "sickbiscuit.com\/blog\/2013\/08\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369167348537651200",
    "text" : "A few garbled sentences about my experience contracting in London: http:\/\/t.co\/ytrlPEMwGb",
    "id" : 369167348537651200,
    "created_at" : "2013-08-18 18:42:09 +0000",
    "user" : {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "protected" : false,
      "id_str" : "14068466",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1929736578\/steve_normal.png",
      "id" : 14068466,
      "verified" : false
    }
  },
  "id" : 369171273345011712,
  "created_at" : "2013-08-18 18:57:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369142945837903872",
  "geo" : { },
  "id_str" : "369145903367458817",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit I will expect something soon then?",
  "id" : 369145903367458817,
  "in_reply_to_status_id" : 369142945837903872,
  "created_at" : "2013-08-18 17:16:56 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368771657030057985",
  "geo" : { },
  "id_str" : "368866515216392192",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid ahh right - I thought you were calling me a girlie man or something :)",
  "id" : 368866515216392192,
  "in_reply_to_status_id" : 368771657030057985,
  "created_at" : "2013-08-17 22:46:45 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368741282417364992",
  "geo" : { },
  "id_str" : "368742947782549505",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid What you trying to say Debbie? :)",
  "id" : 368742947782549505,
  "in_reply_to_status_id" : 368741282417364992,
  "created_at" : "2013-08-17 14:35:44 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Simpson",
      "screen_name" : "TaraSimpson",
      "indices" : [ 3, 15 ],
      "id_str" : "18995998",
      "id" : 18995998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368652330826076161",
  "text" : "RT @TaraSimpson: \"The programmer who refuses to keep exploring will surely stagnate, forget his joy, lose the will to program (and become a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367764534519267328",
    "text" : "\"The programmer who refuses to keep exploring will surely stagnate, forget his joy, lose the will to program (and become a manager).\"..",
    "id" : 367764534519267328,
    "created_at" : "2013-08-14 21:47:52 +0000",
    "user" : {
      "name" : "Tara Simpson",
      "screen_name" : "TaraSimpson",
      "protected" : false,
      "id_str" : "18995998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2166809144\/IMG_0755_normal.JPG",
      "id" : 18995998,
      "verified" : false
    }
  },
  "id" : 368652330826076161,
  "created_at" : "2013-08-17 08:35:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 14, 21 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368489817702559744",
  "geo" : { },
  "id_str" : "368490014402834432",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es @szlwzl FUCK SAKE CHRIS.. SEE WHAT HAPPENS WHEN YOU DON'T BREAKING BAD!!!!!",
  "id" : 368490014402834432,
  "in_reply_to_status_id" : 368489817702559744,
  "created_at" : "2013-08-16 21:50:40 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 8, 21 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368486644891930624",
  "geo" : { },
  "id_str" : "368488887540137985",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @chris_van_es You disgust me.",
  "id" : 368488887540137985,
  "in_reply_to_status_id" : 368486644891930624,
  "created_at" : "2013-08-16 21:46:11 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 14, 21 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "northdown",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368484489409736704",
  "geo" : { },
  "id_str" : "368484845506154496",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es @szlwzl That's a good shout.... He does drink de-caff coffee - which I don't get... So he could be a meth kingpin.. #northdown",
  "id" : 368484845506154496,
  "in_reply_to_status_id" : 368484489409736704,
  "created_at" : "2013-08-16 21:30:07 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 8, 21 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368482327019520001",
  "geo" : { },
  "id_str" : "368483092790394880",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @chris_van_es I wish I had powers to make people watch stuff.. You know Simon has never watched it... True Fact...",
  "id" : 368483092790394880,
  "in_reply_to_status_id" : 368482327019520001,
  "created_at" : "2013-08-16 21:23:10 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justwatchthefuckingthing",
      "indices" : [ 113, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368480524358021120",
  "geo" : { },
  "id_str" : "368480855678660610",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es I\u2019d never do that but to get to the and end and remain  spoiler free would be quite an achievement #justwatchthefuckingthing",
  "id" : 368480855678660610,
  "in_reply_to_status_id" : 368480524358021120,
  "created_at" : "2013-08-16 21:14:16 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368479989122887681",
  "geo" : { },
  "id_str" : "368480144052084737",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es I find fault with that formula",
  "id" : 368480144052084737,
  "in_reply_to_status_id" : 368479989122887681,
  "created_at" : "2013-08-16 21:11:27 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368478103145684992",
  "geo" : { },
  "id_str" : "368478450945777664",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es avoiding spoilers though\u2026. It\u2019s be way too hard and a show like this comes round once every 25years.",
  "id" : 368478450945777664,
  "in_reply_to_status_id" : 368478103145684992,
  "created_at" : "2013-08-16 21:04:43 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368471810847035392",
  "geo" : { },
  "id_str" : "368477471730982913",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es I understand why you want to do this. However it had to be most stupidest fucking idea ever!",
  "id" : 368477471730982913,
  "in_reply_to_status_id" : 368471810847035392,
  "created_at" : "2013-08-16 21:00:49 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368444619924963328",
  "geo" : { },
  "id_str" : "368465869577281536",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery I'll be on fing to tell ya sure :)",
  "id" : 368465869577281536,
  "in_reply_to_status_id" : 368444619924963328,
  "created_at" : "2013-08-16 20:14:43 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 63, 71 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 76, 85 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "probablydave",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368436799044984833",
  "text" : "Next week is my last week in Repknight... So just putting both @jbrevel and @davehedo - one of you two is gonna get ride ;) #probablydave",
  "id" : 368436799044984833,
  "created_at" : "2013-08-16 18:19:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368432303342899200",
  "geo" : { },
  "id_str" : "368436416092442624",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo think you can get s3 watched before I go?",
  "id" : 368436416092442624,
  "in_reply_to_status_id" : 368432303342899200,
  "created_at" : "2013-08-16 18:17:41 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 3, 12 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 95, 101 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cheerslad",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368386747287101440",
  "text" : "RT @davehedo: Just noticed that my last 4 (now 5) tweets have been goat related, all thanks to @swmcc #cheerslad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 81, 87 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cheerslad",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368385965683118080",
    "text" : "Just noticed that my last 4 (now 5) tweets have been goat related, all thanks to @swmcc #cheerslad",
    "id" : 368385965683118080,
    "created_at" : "2013-08-16 14:57:13 +0000",
    "user" : {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "protected" : false,
      "id_str" : "50985598",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000509606650\/9ac4420064b46da165a3e180e20ef133_normal.jpeg",
      "id" : 50985598,
      "verified" : false
    }
  },
  "id" : 368386747287101440,
  "created_at" : "2013-08-16 15:00:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 3, 12 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 14, 20 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368362592315527168",
  "text" : "RT @davehedo: @swmcc I hate you",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368362561261289472",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc I hate you",
    "id" : 368362561261289472,
    "created_at" : "2013-08-16 13:24:13 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "protected" : false,
      "id_str" : "50985598",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000509606650\/9ac4420064b46da165a3e180e20ef133_normal.jpeg",
      "id" : 50985598,
      "verified" : false
    }
  },
  "id" : 368362592315527168,
  "created_at" : "2013-08-16 13:24:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leanda",
      "screen_name" : "leanda",
      "indices" : [ 3, 10 ],
      "id_str" : "19903",
      "id" : 19903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/AjPP9zDGZI",
      "expanded_url" : "https:\/\/stripe.com\/gb",
      "display_url" : "stripe.com\/gb"
    } ]
  },
  "geo" : { },
  "id_str" : "368037260488216576",
  "text" : "RT @leanda: Bye bye PayPal, hello https:\/\/t.co\/AjPP9zDGZI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/AjPP9zDGZI",
        "expanded_url" : "https:\/\/stripe.com\/gb",
        "display_url" : "stripe.com\/gb"
      } ]
    },
    "geo" : { },
    "id_str" : "368036758048768000",
    "text" : "Bye bye PayPal, hello https:\/\/t.co\/AjPP9zDGZI",
    "id" : 368036758048768000,
    "created_at" : "2013-08-15 15:49:35 +0000",
    "user" : {
      "name" : "Leanda",
      "screen_name" : "leanda",
      "protected" : false,
      "id_str" : "19903",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/845614323\/P1020265_normal.jpg",
      "id" : 19903,
      "verified" : false
    }
  },
  "id" : 368037260488216576,
  "created_at" : "2013-08-15 15:51:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 0, 9 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368034079239061505",
  "geo" : { },
  "id_str" : "368035839978115072",
  "in_reply_to_user_id" : 223516339,
  "text" : "@vduglued you only getting to it now? Its been 3 days - how did you avoid spoilers?",
  "id" : 368035839978115072,
  "in_reply_to_status_id" : 368034079239061505,
  "created_at" : "2013-08-15 15:45:56 +0000",
  "in_reply_to_screen_name" : "vduglued",
  "in_reply_to_user_id_str" : "223516339",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368035554727698433",
  "text" : "OH: \".... and I'll be inside wanking, knowing that you are out in my driveway!\"",
  "id" : 368035554727698433,
  "created_at" : "2013-08-15 15:44:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dirt",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367988774333984768",
  "text" : "RT @jbrevel: @swmcc A gift that will probably get you arrested in the future #dirt",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dirt",
        "indices" : [ 64, 69 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "367988401082884097",
    "geo" : { },
    "id_str" : "367988731631783937",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc A gift that will probably get you arrested in the future #dirt",
    "id" : 367988731631783937,
    "in_reply_to_status_id" : 367988401082884097,
    "created_at" : "2013-08-15 12:38:45 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 367988774333984768,
  "created_at" : "2013-08-15 12:38:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 36, 44 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367988401082884097",
  "text" : "Using ascii porn i just freaked out @jbrevel using the &amp; and the % symbols... I have a gift ;)",
  "id" : 367988401082884097,
  "created_at" : "2013-08-15 12:37:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 104, 111 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367931909684215808",
  "text" : "I really do die every morning when I have to use google auth... Forget about it every fucking time! \/cc @szlwzl",
  "id" : 367931909684215808,
  "created_at" : "2013-08-15 08:52:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367769022575570944",
  "geo" : { },
  "id_str" : "367769734038560769",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir where's the office you are moving to - or can't ya say until you sign?",
  "id" : 367769734038560769,
  "in_reply_to_status_id" : 367769022575570944,
  "created_at" : "2013-08-14 22:08:32 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 61, 68 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youalwaysrememberyourfirst",
      "indices" : [ 72, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367569393246416897",
  "text" : "Achievement unlocked: Someone just forked one of my repos on @github :D #youalwaysrememberyourfirst",
  "id" : 367569393246416897,
  "created_at" : "2013-08-14 08:52:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367310531646222336",
  "geo" : { },
  "id_str" : "367311289376182273",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 trying to find the pic I took of you in a thong... I have it somewhere... Just in the middle of something here so stay tuned ;)",
  "id" : 367311289376182273,
  "in_reply_to_status_id" : 367310531646222336,
  "created_at" : "2013-08-13 15:46:50 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367309646572560385",
  "geo" : { },
  "id_str" : "367309850398568449",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 Still use it for the wankbank Michael... Still use it ;)",
  "id" : 367309850398568449,
  "in_reply_to_status_id" : 367309646572560385,
  "created_at" : "2013-08-13 15:41:07 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367309725219557376",
  "text" : "RT @HaVoCT5: @swmcc having a wee discussion here about my time at work, do u remember our lovebite? :D..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367309646572560385",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc having a wee discussion here about my time at work, do u remember our lovebite? :D..",
    "id" : 367309646572560385,
    "created_at" : "2013-08-13 15:40:18 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 367309725219557376,
  "created_at" : "2013-08-13 15:40:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367277930340036608",
  "geo" : { },
  "id_str" : "367283560320741376",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger vagrant is lovely - I &lt;3 it.",
  "id" : 367283560320741376,
  "in_reply_to_status_id" : 367277930340036608,
  "created_at" : "2013-08-13 13:56:39 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0Nqh7buRGU",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=duKlRvTx12c",
      "display_url" : "youtube.com\/watch?v=duKlRv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367276555753357312",
  "text" : "http:\/\/t.co\/0Nqh7buRGU",
  "id" : 367276555753357312,
  "created_at" : "2013-08-13 13:28:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/P4uFrhD2W9",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=KLVdsUwFVQI",
      "display_url" : "youtube.com\/watch?v=KLVdsU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367271844987928576",
  "text" : "http:\/\/t.co\/P4uFrhD2W9",
  "id" : 367271844987928576,
  "created_at" : "2013-08-13 13:10:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 65, 74 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367269271929225217",
  "text" : "OH: \"I don't want to picture you hanging out the back of me\" \/cc @davehedo",
  "id" : 367269271929225217,
  "created_at" : "2013-08-13 12:59:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 43, 52 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoodTimes",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367247055678226433",
  "text" : "Nothing like freaking the clean fuck outta @davehedo :) Think I actually made him scared for a few seconds there.... :) #GoodTimes",
  "id" : 367247055678226433,
  "created_at" : "2013-08-13 11:31:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367030191878860800",
  "geo" : { },
  "id_str" : "367030476588199936",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne just finished myself\u2026 thought it was great. Doesn\u2019t look like they\u2019ll drag things out. What you think?",
  "id" : 367030476588199936,
  "in_reply_to_status_id" : 367030191878860800,
  "created_at" : "2013-08-12 21:10:59 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visually",
      "screen_name" : "Visually",
      "indices" : [ 3, 12 ],
      "id_str" : "273197054",
      "id" : 273197054
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreakingBad",
      "indices" : [ 14, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/LI3I1VKsB3",
      "expanded_url" : "http:\/\/bit.ly\/17kk4yX",
      "display_url" : "bit.ly\/17kk4yX"
    } ]
  },
  "geo" : { },
  "id_str" : "367027518924394496",
  "text" : "RT @Visually: #BreakingBad: Twitter\u2019s deconstruction of Heisenberg http:\/\/t.co\/LI3I1VKsB3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BreakingBad",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/LI3I1VKsB3",
        "expanded_url" : "http:\/\/bit.ly\/17kk4yX",
        "display_url" : "bit.ly\/17kk4yX"
      } ]
    },
    "geo" : { },
    "id_str" : "367027035241455616",
    "text" : "#BreakingBad: Twitter\u2019s deconstruction of Heisenberg http:\/\/t.co\/LI3I1VKsB3",
    "id" : 367027035241455616,
    "created_at" : "2013-08-12 20:57:18 +0000",
    "user" : {
      "name" : "Visually",
      "screen_name" : "Visually",
      "protected" : false,
      "id_str" : "273197054",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1298335415\/logo_copy_normal.jpg",
      "id" : 273197054,
      "verified" : true
    }
  },
  "id" : 367027518924394496,
  "created_at" : "2013-08-12 20:59:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367020957606903808",
  "geo" : { },
  "id_str" : "367025958936514560",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 :) You did you legend :)",
  "id" : 367025958936514560,
  "in_reply_to_status_id" : 367020957606903808,
  "created_at" : "2013-08-12 20:53:02 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/367018542912126976\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/Pz5pPLWojh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRfpa5TCQAAdxQe.jpg",
      "id_str" : "367018542920515584",
      "id" : 367018542920515584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRfpa5TCQAAdxQe.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com\/Pz5pPLWojh"
    } ],
    "hashtags" : [ {
      "text" : "breakingbad",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367018542912126976",
  "text" : "For the next 47 minutes I am not to be disturbed. #breakingbad http:\/\/t.co\/Pz5pPLWojh",
  "id" : 367018542912126976,
  "created_at" : "2013-08-12 20:23:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366943176012988416",
  "geo" : { },
  "id_str" : "366949832633491456",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin Brilliant :)",
  "id" : 366949832633491456,
  "in_reply_to_status_id" : 366943176012988416,
  "created_at" : "2013-08-12 15:50:32 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/NpWnbWINHy",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eUFY8Zw0Bag",
      "display_url" : "youtube.com\/watch?v=eUFY8Z\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "366940619962191872",
  "geo" : { },
  "id_str" : "366940892071854081",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin http:\/\/t.co\/NpWnbWINHy - I always play that when I have to do such things :)",
  "id" : 366940892071854081,
  "in_reply_to_status_id" : 366940619962191872,
  "created_at" : "2013-08-12 15:15:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "speakingfromexperince",
      "indices" : [ 37, 59 ]
    }, {
      "text" : "amsureyouhavehadthisexperincebeforetoo",
      "indices" : [ 60, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366937315530113025",
  "geo" : { },
  "id_str" : "366938390123380736",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin run... run like fuck!!!! #speakingfromexperince #amsureyouhavehadthisexperincebeforetoo RUN!!!!",
  "id" : 366938390123380736,
  "in_reply_to_status_id" : 366937315530113025,
  "created_at" : "2013-08-12 15:05:04 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366934013237149698",
  "text" : "Trying to avoid breaking bad spoilers all day... Kinda hard but has to be done.",
  "id" : 366934013237149698,
  "created_at" : "2013-08-12 14:47:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    }, {
      "name" : "Jemma Simpson",
      "screen_name" : "JemmaSimpsonIT",
      "indices" : [ 8, 23 ],
      "id_str" : "491327765",
      "id" : 491327765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366933609015296001",
  "geo" : { },
  "id_str" : "366933869863243776",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir @JemmaSimpsonIT yeah I dig but still - when you move to actually needing to having a base is a good line in the sand moment.",
  "id" : 366933869863243776,
  "in_reply_to_status_id" : 366933609015296001,
  "created_at" : "2013-08-12 14:47:06 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    }, {
      "name" : "Jemma Simpson",
      "screen_name" : "JemmaSimpsonIT",
      "indices" : [ 8, 23 ],
      "id_str" : "491327765",
      "id" : 491327765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366930517850992640",
  "geo" : { },
  "id_str" : "366930829320003585",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir @JemmaSimpsonIT that's great news. Congrats in that case :) Great to hear that Jon. I &lt;3 hearing local startups doing well.",
  "id" : 366930829320003585,
  "in_reply_to_status_id" : 366930517850992640,
  "created_at" : "2013-08-12 14:35:01 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    }, {
      "name" : "Jemma Simpson",
      "screen_name" : "JemmaSimpsonIT",
      "indices" : [ 8, 23 ],
      "id_str" : "491327765",
      "id" : 491327765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366929134636634112",
  "geo" : { },
  "id_str" : "366929395065163779",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir @JemmaSimpsonIT remote working sure :) If you are starting from scratch I think that its a great culture to have.",
  "id" : 366929395065163779,
  "in_reply_to_status_id" : 366929134636634112,
  "created_at" : "2013-08-12 14:29:19 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jemma Simpson",
      "screen_name" : "JemmaSimpsonIT",
      "indices" : [ 0, 15 ],
      "id_str" : "491327765",
      "id" : 491327765
    }, {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 16, 23 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366927114429136896",
  "geo" : { },
  "id_str" : "366927286500466689",
  "in_reply_to_user_id" : 491327765,
  "text" : "@JemmaSimpsonIT @midhir Well I remember reading it - but could be making it up..",
  "id" : 366927286500466689,
  "in_reply_to_status_id" : 366927114429136896,
  "created_at" : "2013-08-12 14:20:56 +0000",
  "in_reply_to_screen_name" : "JemmaSimpsonIT",
  "in_reply_to_user_id_str" : "491327765",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    }, {
      "name" : "Jemma Simpson",
      "screen_name" : "JemmaSimpsonIT",
      "indices" : [ 8, 23 ],
      "id_str" : "491327765",
      "id" : 491327765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366914492493340672",
  "geo" : { },
  "id_str" : "366925643272818688",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir @JemmaSimpsonIT thinkg about the SPB is that its been sold to be a hotel. Don't think its for near a year but its happening.",
  "id" : 366925643272818688,
  "in_reply_to_status_id" : 366914492493340672,
  "created_at" : "2013-08-12 14:14:25 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 12, 19 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366844705075494913",
  "geo" : { },
  "id_str" : "366848558147710976",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne @szlwzl I love it :)",
  "id" : 366848558147710976,
  "in_reply_to_status_id" : 366844705075494913,
  "created_at" : "2013-08-12 09:08:06 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 25, 32 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/366836603181744129\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/81IJPNzssV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRdD8m_CQAAkdQQ.jpg",
      "id_str" : "366836603190132736",
      "id" : 366836603190132736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRdD8m_CQAAkdQQ.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/81IJPNzssV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366836603181744129",
  "text" : "Look at what the awesome @szlwzl got me as a leaving present. I love it. Thanks :) http:\/\/t.co\/81IJPNzssV",
  "id" : 366836603181744129,
  "created_at" : "2013-08-12 08:20:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366654783123234816",
  "geo" : { },
  "id_str" : "366665809096998914",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams yeah :)",
  "id" : 366665809096998914,
  "in_reply_to_status_id" : 366654783123234816,
  "created_at" : "2013-08-11 21:01:55 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366585185795452928",
  "geo" : { },
  "id_str" : "366622091384078336",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams tried using your cock?",
  "id" : 366622091384078336,
  "in_reply_to_status_id" : 366585185795452928,
  "created_at" : "2013-08-11 18:08:12 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 106, 113 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/366596892433469440\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/21hLct2d7a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRZp7m3CUAAsTeE.png",
      "id_str" : "366596892441858048",
      "id" : 366596892441858048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRZp7m3CUAAsTeE.png",
      "sizes" : [ {
        "h" : 152,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 294
      } ],
      "display_url" : "pic.twitter.com\/21hLct2d7a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366596892433469440",
  "text" : "This is even more insulting than the time he 'endorsed' me for 'showjumping' and 'sexual dysfunction' \/cc @szlwzl http:\/\/t.co\/21hLct2d7a",
  "id" : 366596892433469440,
  "created_at" : "2013-08-11 16:28:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366573417136267267",
  "text" : "Doing my first bit of HTML and CSS in ages... Can't say I am any better at it.. In fact I would go as far as to say I am shit at it.",
  "id" : 366573417136267267,
  "created_at" : "2013-08-11 14:54:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frocks for Freedom",
      "screen_name" : "frocks4freedom",
      "indices" : [ 3, 18 ],
      "id_str" : "1656264067",
      "id" : 1656264067
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "because",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "belfast",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "HumanTrafficking",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/XNollghqI1",
      "expanded_url" : "http:\/\/frocksforfreedom.org",
      "display_url" : "frocksforfreedom.org"
    } ]
  },
  "geo" : { },
  "id_str" : "366500609517559808",
  "text" : "RT @frocks4freedom: There's less than an hour to go before tickets go on sale... http:\/\/t.co\/XNollghqI1 #because #belfast #HumanTrafficking",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "because",
        "indices" : [ 84, 92 ]
      }, {
        "text" : "belfast",
        "indices" : [ 93, 101 ]
      }, {
        "text" : "HumanTrafficking",
        "indices" : [ 102, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/XNollghqI1",
        "expanded_url" : "http:\/\/frocksforfreedom.org",
        "display_url" : "frocksforfreedom.org"
      } ]
    },
    "geo" : { },
    "id_str" : "366459506160451585",
    "text" : "There's less than an hour to go before tickets go on sale... http:\/\/t.co\/XNollghqI1 #because #belfast #HumanTrafficking",
    "id" : 366459506160451585,
    "created_at" : "2013-08-11 07:22:09 +0000",
    "user" : {
      "name" : "Frocks for Freedom",
      "screen_name" : "frocks4freedom",
      "protected" : false,
      "id_str" : "1656264067",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000275999353\/3b83fa5c6a08de3b6d5178631c3e38f5_normal.jpeg",
      "id" : 1656264067,
      "verified" : false
    }
  },
  "id" : 366500609517559808,
  "created_at" : "2013-08-11 10:05:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366494903221501953",
  "geo" : { },
  "id_str" : "366499749987225602",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams :D Photos of the safari look fantastic.. And suck it up - a month off - no sympathy :)",
  "id" : 366499749987225602,
  "in_reply_to_status_id" : 366494903221501953,
  "created_at" : "2013-08-11 10:02:04 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 13, 28 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 29, 37 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366444154550616065",
  "geo" : { },
  "id_str" : "366487681372405762",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @annette_mccull @HaVoCT5 almost right... almost right... s\/ke\/ck\/",
  "id" : 366487681372405762,
  "in_reply_to_status_id" : 366444154550616065,
  "created_at" : "2013-08-11 09:14:06 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/eFgZdpPcqB",
      "expanded_url" : "http:\/\/4sq.com\/15YnLLm",
      "display_url" : "4sq.com\/15YnLLm"
    } ]
  },
  "geo" : { },
  "id_str" : "366272091902840832",
  "text" : "I'm at Edenmore Country Club (Magheralin, County Down) http:\/\/t.co\/eFgZdpPcqB",
  "id" : 366272091902840832,
  "created_at" : "2013-08-10 18:57:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366111196635594752",
  "text" : "Breaking Bad starts tomorrow.... This pleases me greatly.. You know.. If I actually lived in The States... Hopefully they show it soon here.",
  "id" : 366111196635594752,
  "created_at" : "2013-08-10 08:18:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truefact",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365918908806463488",
  "geo" : { },
  "id_str" : "365919314731212800",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl your culture is hunting pheasants and making badly behaved servants walk a cinder path like that book - Out of Africa. #truefact",
  "id" : 365919314731212800,
  "in_reply_to_status_id" : 365918908806463488,
  "created_at" : "2013-08-09 19:35:37 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365918663045423105",
  "geo" : { },
  "id_str" : "365918753181011969",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl then put the phone down now :)",
  "id" : 365918753181011969,
  "in_reply_to_status_id" : 365918663045423105,
  "created_at" : "2013-08-09 19:33:23 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365918263298883584",
  "geo" : { },
  "id_str" : "365918369062453249",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams :) I so want to retweet that :)",
  "id" : 365918369062453249,
  "in_reply_to_status_id" : 365918263298883584,
  "created_at" : "2013-08-09 19:31:52 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365918071371735040",
  "geo" : { },
  "id_str" : "365918262585868288",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl we both know what happens when you start talking about the hunger games ;)",
  "id" : 365918262585868288,
  "in_reply_to_status_id" : 365918071371735040,
  "created_at" : "2013-08-09 19:31:26 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365917107818467328",
  "geo" : { },
  "id_str" : "365917567518392320",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl just both sides wanting too nick the fuck out of each other. Shove em all on Rams Island and the last one standing wins.",
  "id" : 365917567518392320,
  "in_reply_to_status_id" : 365917107818467328,
  "created_at" : "2013-08-09 19:28:41 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365916954118193152",
  "text" : "Dear Belfast Inbreds,\n\nWell for you that has fuck all else to worry about.\n\nRegards,\n\nNormal people",
  "id" : 365916954118193152,
  "created_at" : "2013-08-09 19:26:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365755283437391872",
  "geo" : { },
  "id_str" : "365755616788103168",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell gonna blog about me workflow. Changed it back in May but have been working like fook ever since then. Might do it this weekend.",
  "id" : 365755616788103168,
  "in_reply_to_status_id" : 365755283437391872,
  "created_at" : "2013-08-09 08:45:09 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 0, 9 ],
      "id_str" : "729883",
      "id" : 729883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365754971817385986",
  "geo" : { },
  "id_str" : "365755405537787905",
  "in_reply_to_user_id" : 729883,
  "text" : "@chrismcg Nope - looking it up now. I've just learnt as I've went with the odd youtube tutorial.. Will give that book a wee read. Cheers :)",
  "id" : 365755405537787905,
  "in_reply_to_status_id" : 365754971817385986,
  "created_at" : "2013-08-09 08:44:18 +0000",
  "in_reply_to_screen_name" : "chrismcg",
  "in_reply_to_user_id_str" : "729883",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365754791005126656",
  "geo" : { },
  "id_str" : "365755009104748545",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell I'm just against any IDE to be fair. I know this is kinda impossible with big java projects though.",
  "id" : 365755009104748545,
  "in_reply_to_status_id" : 365754791005126656,
  "created_at" : "2013-08-09 08:42:44 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 0, 9 ],
      "id_str" : "729883",
      "id" : 729883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365754584704094208",
  "geo" : { },
  "id_str" : "365754838522396673",
  "in_reply_to_user_id" : 729883,
  "text" : "@chrismcg I don't know how I survived without tmux. I love vagrant - just makes stuff easier.",
  "id" : 365754838522396673,
  "in_reply_to_status_id" : 365754584704094208,
  "created_at" : "2013-08-09 08:42:03 +0000",
  "in_reply_to_screen_name" : "chrismcg",
  "in_reply_to_user_id_str" : "729883",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365754461714522112",
  "geo" : { },
  "id_str" : "365754663502495744",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell all good save eclipse.... :)",
  "id" : 365754663502495744,
  "in_reply_to_status_id" : 365754461714522112,
  "created_at" : "2013-08-09 08:41:21 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365754320513277954",
  "text" : "Wondering what others use for their workflow. Mine is vagrant, vim &amp; tmux with a load of wee handy utility scripts in between.",
  "id" : 365754320513277954,
  "created_at" : "2013-08-09 08:40:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/365493740946722817\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/6rH88ekkwv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRJ-nvUCEAIL5tq.png",
      "id_str" : "365493740950917122",
      "id" : 365493740950917122,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRJ-nvUCEAIL5tq.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/6rH88ekkwv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365493740946722817",
  "text" : "I\u2019m gonna miss him http:\/\/t.co\/6rH88ekkwv",
  "id" : 365493740946722817,
  "created_at" : "2013-08-08 15:24:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365493188569481219",
  "geo" : { },
  "id_str" : "365493589498798083",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 I say fuck the recruiters that think they know what they are talking about but know close to fuck all :) I miss you!",
  "id" : 365493589498798083,
  "in_reply_to_status_id" : 365493188569481219,
  "created_at" : "2013-08-08 15:23:56 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365492774616838144",
  "text" : "Not saying that they don't make 'em - but in my experience - no.. no they don't.",
  "id" : 365492774616838144,
  "created_at" : "2013-08-08 15:20:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365492644232704002",
  "text" : "Had a discussion with a recruiter that argued with me that IMD students make good back end devs.. I can count the # on one hand I've seen.",
  "id" : 365492644232704002,
  "created_at" : "2013-08-08 15:20:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 13, 24 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365475725995819009",
  "text" : "The peeps at @bigwetfish have given me a promo code for 15% off their services - just use - bwfstephenmc Great service...",
  "id" : 365475725995819009,
  "created_at" : "2013-08-08 14:12:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365470648849539073",
  "geo" : { },
  "id_str" : "365470880098287618",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne swearing, violence, bodily contact... throw in some jelly and mud and we have a party!!!! :)",
  "id" : 365470880098287618,
  "in_reply_to_status_id" : 365470648849539073,
  "created_at" : "2013-08-08 13:53:42 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365461294301712385",
  "geo" : { },
  "id_str" : "365468412278882305",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne when you next here? You can do it in person for me as a leaving present :)",
  "id" : 365468412278882305,
  "in_reply_to_status_id" : 365461294301712385,
  "created_at" : "2013-08-08 13:43:54 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365457078086680577",
  "geo" : { },
  "id_str" : "365458728834707456",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne fuckitibye - The best curse word ever.",
  "id" : 365458728834707456,
  "in_reply_to_status_id" : 365457078086680577,
  "created_at" : "2013-08-08 13:05:25 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365215818285453312",
  "geo" : { },
  "id_str" : "365217070847647744",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid it has to include steps :)",
  "id" : 365217070847647744,
  "in_reply_to_status_id" : 365215818285453312,
  "created_at" : "2013-08-07 21:05:09 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 104, 114 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365214896964648961",
  "geo" : { },
  "id_str" : "365215271054622720",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid tha it did. It\u2019s in my head now though. Still better than Rhinestone cowboy to be fair \/cc @smccalden",
  "id" : 365215271054622720,
  "in_reply_to_status_id" : 365214896964648961,
  "created_at" : "2013-08-07 20:58:00 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365191608045547521",
  "geo" : { },
  "id_str" : "365214740957503490",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid no need.",
  "id" : 365214740957503490,
  "in_reply_to_status_id" : 365191608045547521,
  "created_at" : "2013-08-07 20:55:54 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365137261827850242",
  "geo" : { },
  "id_str" : "365137708038881280",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery but off Friday as I planned that. Today was unplanned so it was a real day off. A real day off :)",
  "id" : 365137708038881280,
  "in_reply_to_status_id" : 365137261827850242,
  "created_at" : "2013-08-07 15:49:48 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bliss",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "impromptudayoff",
      "indices" : [ 94, 110 ]
    }, {
      "text" : "awesome",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365137131653447682",
  "text" : "I just strimmed my grass\u2026. Man points :) Nowhere near a laptop today expect this iPad. #bliss #impromptudayoff #awesome",
  "id" : 365137131653447682,
  "created_at" : "2013-08-07 15:47:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364851821140914177",
  "geo" : { },
  "id_str" : "364862634719313920",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl no spoilers until I watch it tomorrow",
  "id" : 364862634719313920,
  "in_reply_to_status_id" : 364851821140914177,
  "created_at" : "2013-08-06 21:36:45 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364834185866788864",
  "geo" : { },
  "id_str" : "364844836320313344",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I wish it was Si Si... I wish it was.",
  "id" : 364844836320313344,
  "in_reply_to_status_id" : 364834185866788864,
  "created_at" : "2013-08-06 20:26:02 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Carr",
      "screen_name" : "heatherjcarr",
      "indices" : [ 3, 16 ],
      "id_str" : "29664856",
      "id" : 29664856
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 18, 25 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 26, 32 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/heatherjcarr\/status\/364836463596158977\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/yIhXCcs31Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRAo1KYCQAAzBoL.jpg",
      "id_str" : "364836463600353280",
      "id" : 364836463600353280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRAo1KYCQAAzBoL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/yIhXCcs31Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364844781710491648",
  "text" : "RT @heatherjcarr: @szlwzl @swmcc http:\/\/t.co\/yIhXCcs31Q",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "szlwzl",
        "screen_name" : "szlwzl",
        "indices" : [ 0, 7 ],
        "id_str" : "3604141",
        "id" : 3604141
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 8, 14 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/heatherjcarr\/status\/364836463596158977\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/yIhXCcs31Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRAo1KYCQAAzBoL.jpg",
        "id_str" : "364836463600353280",
        "id" : 364836463600353280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRAo1KYCQAAzBoL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/yIhXCcs31Q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "364834185866788864",
    "geo" : { },
    "id_str" : "364836463596158977",
    "in_reply_to_user_id" : 3604141,
    "text" : "@szlwzl @swmcc http:\/\/t.co\/yIhXCcs31Q",
    "id" : 364836463596158977,
    "in_reply_to_status_id" : 364834185866788864,
    "created_at" : "2013-08-06 19:52:46 +0000",
    "in_reply_to_screen_name" : "szlwzl",
    "in_reply_to_user_id_str" : "3604141",
    "user" : {
      "name" : "Heather Carr",
      "screen_name" : "heatherjcarr",
      "protected" : false,
      "id_str" : "29664856",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2337248697\/bh36xyw206td8th87oku_normal.jpeg",
      "id" : 29664856,
      "verified" : false
    }
  },
  "id" : 364844781710491648,
  "created_at" : "2013-08-06 20:25:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364844570757955584",
  "geo" : { },
  "id_str" : "364844720825974784",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues agree with you on both counts :)",
  "id" : 364844720825974784,
  "in_reply_to_status_id" : 364844570757955584,
  "created_at" : "2013-08-06 20:25:34 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364843785739452418",
  "geo" : { },
  "id_str" : "364844075943342080",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues Yeah - I thought it was a bit simplistic too... And you loved Pacific Rim - its a great watch aint it :)",
  "id" : 364844075943342080,
  "in_reply_to_status_id" : 364843785739452418,
  "created_at" : "2013-08-06 20:23:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 22, 31 ],
      "id_str" : "729883",
      "id" : 729883
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 35, 47 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364843979637923841",
  "text" : "Really good talk from @chrismcg at @BelfastRuby today on Testing.",
  "id" : 364843979637923841,
  "created_at" : "2013-08-06 20:22:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlassian HipChat",
      "screen_name" : "HipChat",
      "indices" : [ 70, 78 ],
      "id_str" : "17810599",
      "id" : 17810599
    }, {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 87, 97 ],
      "id_str" : "240194412",
      "id" : 240194412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364785112027639808",
  "text" : "Achivement Unlocked - I've found a gif that fucks everyone off in our @hipchat room at @RepKnight - legacy now in tact :)",
  "id" : 364785112027639808,
  "created_at" : "2013-08-06 16:28:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364755141536129025",
  "text" : "but it is very common... Email when an account is created, email when an error is reported... Don't get it...",
  "id" : 364755141536129025,
  "created_at" : "2013-08-06 14:29:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364755007955935233",
  "text" : "I really don't get the culture of having email event triggers in apps. Not when there are much better methods avaiabe. Its not 2002 ya know!",
  "id" : 364755007955935233,
  "created_at" : "2013-08-06 14:29:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 23, 35 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364754365350813696",
  "text" : "Looking forward to the @BelfastRuby talk tonight....",
  "id" : 364754365350813696,
  "created_at" : "2013-08-06 14:26:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Taylor",
      "screen_name" : "Mark_Antony",
      "indices" : [ 3, 15 ],
      "id_str" : "23977676",
      "id" : 23977676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364734951943438336",
  "text" : "RT @Mark_Antony: NHS Hospital spends \u00A328,000,000 on Patient Record system theat doesn't work, over half on, ahem, 'expert help' http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/HwM3Nt72of",
        "expanded_url" : "http:\/\/bit.ly\/13CCex1",
        "display_url" : "bit.ly\/13CCex1"
      } ]
    },
    "geo" : { },
    "id_str" : "364696778257334272",
    "text" : "NHS Hospital spends \u00A328,000,000 on Patient Record system theat doesn't work, over half on, ahem, 'expert help' http:\/\/t.co\/HwM3Nt72of",
    "id" : 364696778257334272,
    "created_at" : "2013-08-06 10:37:42 +0000",
    "user" : {
      "name" : "Mark Taylor",
      "screen_name" : "Mark_Antony",
      "protected" : false,
      "id_str" : "23977676",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2248278921\/mt-bio-headshot_normal.jpg",
      "id" : 23977676,
      "verified" : false
    }
  },
  "id" : 364734951943438336,
  "created_at" : "2013-08-06 13:09:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364733209969295360",
  "geo" : { },
  "id_str" : "364734107315486722",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard you ever get that blog set up son? :)",
  "id" : 364734107315486722,
  "in_reply_to_status_id" : 364733209969295360,
  "created_at" : "2013-08-06 13:06:02 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364730029478916097",
  "geo" : { },
  "id_str" : "364730237038235650",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne as it should Mark.. as it should :)",
  "id" : 364730237038235650,
  "in_reply_to_status_id" : 364730029478916097,
  "created_at" : "2013-08-06 12:50:39 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyra McKee",
      "screen_name" : "LyraMcKee",
      "indices" : [ 3, 13 ],
      "id_str" : "76377195",
      "id" : 76377195
    }, {
      "name" : "The Muckraker",
      "screen_name" : "readmuck",
      "indices" : [ 23, 32 ],
      "id_str" : "462486440",
      "id" : 462486440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/xmkPPfmqUy",
      "expanded_url" : "https:\/\/www.arthurguinnessprojects.com\/arts\/murder-of-a-minister#_=_",
      "display_url" : "arthurguinnessprojects.com\/arts\/murder-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364729228874354689",
  "text" : "RT @LyraMcKee: To keep @readmuck going, though, I need to win this grant https:\/\/t.co\/xmkPPfmqUy. If you're a fan of my work, please vote a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Muckraker",
        "screen_name" : "readmuck",
        "indices" : [ 8, 17 ],
        "id_str" : "462486440",
        "id" : 462486440
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/xmkPPfmqUy",
        "expanded_url" : "https:\/\/www.arthurguinnessprojects.com\/arts\/murder-of-a-minister#_=_",
        "display_url" : "arthurguinnessprojects.com\/arts\/murder-of\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "364717388505153536",
    "text" : "To keep @readmuck going, though, I need to win this grant https:\/\/t.co\/xmkPPfmqUy. If you're a fan of my work, please vote and share!",
    "id" : 364717388505153536,
    "created_at" : "2013-08-06 11:59:36 +0000",
    "user" : {
      "name" : "Lyra McKee",
      "screen_name" : "LyraMcKee",
      "protected" : false,
      "id_str" : "76377195",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000447967102\/212828e6e9b76d758e645426b4b6064d_normal.jpeg",
      "id" : 76377195,
      "verified" : false
    }
  },
  "id" : 364729228874354689,
  "created_at" : "2013-08-06 12:46:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364726164008353793",
  "geo" : { },
  "id_str" : "364728915257868288",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne I like that :)",
  "id" : 364728915257868288,
  "in_reply_to_status_id" : 364726164008353793,
  "created_at" : "2013-08-06 12:45:24 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/tByloKNECp",
      "expanded_url" : "http:\/\/spots.io\/venue\/74981597",
      "display_url" : "spots.io\/venue\/74981597"
    } ]
  },
  "geo" : { },
  "id_str" : "364703788923232256",
  "text" : "&lt;3 just &lt;3 this company.... http:\/\/t.co\/tByloKNECp",
  "id" : 364703788923232256,
  "created_at" : "2013-08-06 11:05:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364697748500512769",
  "geo" : { },
  "id_str" : "364699944147369984",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir \"\u201CI\u2019m the accumulation of all my skills and talents. I\u2019m wisdom and creativity.\" - great line...",
  "id" : 364699944147369984,
  "in_reply_to_status_id" : 364697748500512769,
  "created_at" : "2013-08-06 10:50:17 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364697748500512769",
  "geo" : { },
  "id_str" : "364698123391602688",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir Contracting something I've always thought about - never really had the balls to do it. Good link - reading it now :)",
  "id" : 364698123391602688,
  "in_reply_to_status_id" : 364697748500512769,
  "created_at" : "2013-08-06 10:43:03 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364695704972697600",
  "geo" : { },
  "id_str" : "364696325226373120",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir what's the alternative though? By job\/task? Just wondering..",
  "id" : 364696325226373120,
  "in_reply_to_status_id" : 364695704972697600,
  "created_at" : "2013-08-06 10:35:54 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364439409921232896",
  "geo" : { },
  "id_str" : "364439491202646016",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 I want to be in yours ;)",
  "id" : 364439491202646016,
  "in_reply_to_status_id" : 364439409921232896,
  "created_at" : "2013-08-05 17:35:20 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364438150782791680",
  "geo" : { },
  "id_str" : "364438919460294657",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 I do :D",
  "id" : 364438919460294657,
  "in_reply_to_status_id" : 364438150782791680,
  "created_at" : "2013-08-05 17:33:04 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364419856726102016",
  "text" : "Started to get really cunty this last hour... Need to make a cup of tea :) Not good - am happy like - just a tad cunty...",
  "id" : 364419856726102016,
  "created_at" : "2013-08-05 16:17:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckitbye",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "drwho",
      "indices" : [ 46, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364104174096486400",
  "text" : "Malcom Tucker as the new Dr Who... #fuckitbye #drwho",
  "id" : 364104174096486400,
  "created_at" : "2013-08-04 19:22:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 7, 15 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 20, 27 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 32, 38 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364077951228186625",
  "text" : "I hate @jbrevel and @rejoco but @swmcc rocks... HE FUCKING ROCKS!!!!",
  "id" : 364077951228186625,
  "created_at" : "2013-08-04 17:38:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363994692645429248",
  "geo" : { },
  "id_str" : "363998996768886784",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl wet t-shirt comp?",
  "id" : 363998996768886784,
  "in_reply_to_status_id" : 363994692645429248,
  "created_at" : "2013-08-04 12:24:58 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363926981638758402",
  "geo" : { },
  "id_str" : "363927594837618688",
  "in_reply_to_user_id" : 804717,
  "text" : "@szlwzl \"Maybe because the headquarters are in Dublin\"... Oh I fucking love this. Lucky breathing comes natural or this lot would be fucked.",
  "id" : 363927594837618688,
  "in_reply_to_status_id" : 363926981638758402,
  "created_at" : "2013-08-04 07:41:14 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363921562769960960",
  "geo" : { },
  "id_str" : "363926981638758402",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl This cannot be fucking serious? Ohhh this is comedy gold... At least they can read now. \"FB banning protestant ppl\" - Awesome :)",
  "id" : 363926981638758402,
  "in_reply_to_status_id" : 363921562769960960,
  "created_at" : "2013-08-04 07:38:48 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/rCvJpkSlBZ",
      "expanded_url" : "http:\/\/4sq.com\/11BQvZx",
      "display_url" : "4sq.com\/11BQvZx"
    } ]
  },
  "geo" : { },
  "id_str" : "363590223352963074",
  "text" : "Getting a telling off :) (@ Whitemountain Garage) http:\/\/t.co\/rCvJpkSlBZ",
  "id" : 363590223352963074,
  "created_at" : "2013-08-03 09:20:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363426263132037120",
  "geo" : { },
  "id_str" : "363426450520940544",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl my new trick is to wait on my knees :)",
  "id" : 363426450520940544,
  "in_reply_to_status_id" : 363426263132037120,
  "created_at" : "2013-08-02 22:29:52 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 12, 25 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 26, 32 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363425869806960640",
  "text" : "RT @szlwzl: @nicholabates @swmcc there's grossly offensive and there's grossly offensive :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/getfalcon.pro\" rel=\"nofollow\"\u003EFalcon-Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nichola Bates",
        "screen_name" : "nicholabates",
        "indices" : [ 0, 13 ],
        "id_str" : "19125494",
        "id" : 19125494
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 14, 20 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "363422681317642242",
    "geo" : { },
    "id_str" : "363425458995470336",
    "in_reply_to_user_id" : 19125494,
    "text" : "@nicholabates @swmcc there's grossly offensive and there's grossly offensive :)",
    "id" : 363425458995470336,
    "in_reply_to_status_id" : 363422681317642242,
    "created_at" : "2013-08-02 22:25:56 +0000",
    "in_reply_to_screen_name" : "nicholabates",
    "in_reply_to_user_id_str" : "19125494",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 363425869806960640,
  "created_at" : "2013-08-02 22:27:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 8, 21 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363425458995470336",
  "geo" : { },
  "id_str" : "363425832070414336",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @nicholabates I think I out did myself today with my comment to Locko\u2026. And fuck you all - I am class and you tards will miss me :)",
  "id" : 363425832070414336,
  "in_reply_to_status_id" : 363425458995470336,
  "created_at" : "2013-08-02 22:27:25 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 12, 18 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "f",
      "indices" : [ 137, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363425501605789696",
  "text" : "RT @szlwzl: @swmcc we just switched on 300,mcnulty is the spartan councilman. Still giving a fuck when it isn't his turn to give a fuck. #f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/getfalcon.pro\" rel=\"nofollow\"\u003EFalcon-Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fuck",
        "indices" : [ 125, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363416565695254528",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc we just switched on 300,mcnulty is the spartan councilman. Still giving a fuck when it isn't his turn to give a fuck. #fuck",
    "id" : 363416565695254528,
    "created_at" : "2013-08-02 21:50:35 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 363425501605789696,
  "created_at" : "2013-08-02 22:26:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 64, 71 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363415768051884034",
  "text" : "The Wire is showing on Sky Atlantic. Awesome sauce as the great @szlwzl would say.",
  "id" : 363415768051884034,
  "created_at" : "2013-08-02 21:47:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 77, 85 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363303860959330304",
  "text" : "For the first time ever I just sickened myself with something I said.. Think @jbrevel is gonna be sick",
  "id" : 363303860959330304,
  "created_at" : "2013-08-02 14:22:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 13, 21 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363298805992538112",
  "geo" : { },
  "id_str" : "363299065670275075",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid @jbrevel live dangerously Debbie...",
  "id" : 363299065670275075,
  "in_reply_to_status_id" : 363298805992538112,
  "created_at" : "2013-08-02 14:03:41 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363289533401812992",
  "geo" : { },
  "id_str" : "363293306484047872",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues you cheered me up no end there :) Now and again I watch Foxnews for the craic. Ohhh it is funny :)",
  "id" : 363293306484047872,
  "in_reply_to_status_id" : 363289533401812992,
  "created_at" : "2013-08-02 13:40:48 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/wGU8ARYcSp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0VqTwnAuHws",
      "display_url" : "youtube.com\/watch?v=0VqTwn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363285307354923009",
  "text" : "These guys just knock me out.. Pure genius... http:\/\/t.co\/wGU8ARYcSp",
  "id" : 363285307354923009,
  "created_at" : "2013-08-02 13:09:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Neubauer",
      "screen_name" : "peterneubauer",
      "indices" : [ 3, 17 ],
      "id_str" : "14721805",
      "id" : 14721805
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "in",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/i5tW8vJsuF",
      "expanded_url" : "http:\/\/www.infoq.com\/research\/nosql-databases",
      "display_url" : "infoq.com\/research\/nosql\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363262277773836288",
  "text" : "RT @peterneubauer: Very cool and interesting voting on NOSQL adoption. Wanna check in for your opinion on Neo4j? http:\/\/t.co\/i5tW8vJsuF #in",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "in",
        "indices" : [ 117, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/i5tW8vJsuF",
        "expanded_url" : "http:\/\/www.infoq.com\/research\/nosql-databases",
        "display_url" : "infoq.com\/research\/nosql\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "363257994642849792",
    "text" : "Very cool and interesting voting on NOSQL adoption. Wanna check in for your opinion on Neo4j? http:\/\/t.co\/i5tW8vJsuF #in",
    "id" : 363257994642849792,
    "created_at" : "2013-08-02 11:20:29 +0000",
    "user" : {
      "name" : "Peter Neubauer",
      "screen_name" : "peterneubauer",
      "protected" : false,
      "id_str" : "14721805",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000529267759\/41cc29f7f7848ef5f452a43c7bd503b0_normal.png",
      "id" : 14721805,
      "verified" : false
    }
  },
  "id" : 363262277773836288,
  "created_at" : "2013-08-02 11:37:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lockosjukebox",
      "indices" : [ 36, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363259849078874112",
  "text" : "Will Smith - Getting Jiggy With It. #lockosjukebox",
  "id" : 363259849078874112,
  "created_at" : "2013-08-02 11:27:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363254093092880384",
  "geo" : { },
  "id_str" : "363254410488446976",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel I now have proof that Locko wants me in his room (the red room of passion on foursquare - I am Mayor) :) :) :)",
  "id" : 363254410488446976,
  "in_reply_to_status_id" : 363254093092880384,
  "created_at" : "2013-08-02 11:06:15 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363254276769853440",
  "text" : "RT @jbrevel: @swmcc .......and I'm not ashamed to do so :-) Boom boom boom boom, I want you in my room..........",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "363253752154701824",
    "geo" : { },
    "id_str" : "363254093092880384",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc .......and I'm not ashamed to do so :-) Boom boom boom boom, I want you in my room..........",
    "id" : 363254093092880384,
    "in_reply_to_status_id" : 363253752154701824,
    "created_at" : "2013-08-02 11:04:59 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 363254276769853440,
  "created_at" : "2013-08-02 11:05:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 12, 20 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363253752154701824",
  "text" : "Only me and @jbrevel in the office.... and someone (not me) just went \"YEESSSS\" when the Vengaboys came on and now they are singing along!",
  "id" : 363253752154701824,
  "created_at" : "2013-08-02 11:03:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363248024065015808",
  "text" : "swmcc_lisburn - just saying. :)",
  "id" : 363248024065015808,
  "created_at" : "2013-08-02 10:40:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363038676580069376",
  "geo" : { },
  "id_str" : "363041532569333760",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning that's the best way dude ;)",
  "id" : 363041532569333760,
  "in_reply_to_status_id" : 363038676580069376,
  "created_at" : "2013-08-01 21:00:21 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363030480397934593",
  "geo" : { },
  "id_str" : "363038177528774656",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning you mean you don't like exploding pussys? :)",
  "id" : 363038177528774656,
  "in_reply_to_status_id" : 363030480397934593,
  "created_at" : "2013-08-01 20:47:01 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/KXVIQYJyPL",
      "expanded_url" : "https:\/\/github.com\/iphoting\/heroku-buildpack-php-tyler",
      "display_url" : "github.com\/iphoting\/herok\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363029855857680386",
  "text" : "Very interesting PHP gubbins here.. Yeah - interesting and PHP.... Who'd have thought that ;) https:\/\/t.co\/KXVIQYJyPL",
  "id" : 363029855857680386,
  "created_at" : "2013-08-01 20:13:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363027413745143808",
  "geo" : { },
  "id_str" : "363028473947762688",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl well he does have a stupidly large head - kinda freaky.",
  "id" : 363028473947762688,
  "in_reply_to_status_id" : 363027413745143808,
  "created_at" : "2013-08-01 20:08:27 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 8, 17 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363024486976602112",
  "geo" : { },
  "id_str" : "363027288234803201",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @climagic I love that - will be giving that a go tomorrow :)",
  "id" : 363027288234803201,
  "in_reply_to_status_id" : 363024486976602112,
  "created_at" : "2013-08-01 20:03:44 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3asyHvHwe5",
      "expanded_url" : "http:\/\/blog.swm.cc\/2013\/08\/01\/moffett\/",
      "display_url" : "blog.swm.cc\/2013\/08\/01\/mof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362979420505509888",
  "text" : "http:\/\/t.co\/3asyHvHwe5 - working with friends",
  "id" : 362979420505509888,
  "created_at" : "2013-08-01 16:53:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362969531456565248",
  "geo" : { },
  "id_str" : "362969701141323776",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco no calls in the last 15mins... so lets hope it has stopped :)",
  "id" : 362969701141323776,
  "in_reply_to_status_id" : 362969531456565248,
  "created_at" : "2013-08-01 16:14:55 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 82, 90 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362967352763097088",
  "text" : "OH: \"I'm gonna wank myself off thinking about that\" - and yes - it is only me and @jbrevel in the office today!",
  "id" : 362967352763097088,
  "created_at" : "2013-08-01 16:05:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362936253433389058",
  "geo" : { },
  "id_str" : "362957601362821120",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco buy a fax machine JR... Its 1988 again :)",
  "id" : 362957601362821120,
  "in_reply_to_status_id" : 362936253433389058,
  "created_at" : "2013-08-01 15:26:50 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    }, {
      "name" : "Colin Mitchell",
      "screen_name" : "pixelpage",
      "indices" : [ 10, 20 ],
      "id_str" : "52710181",
      "id" : 52710181
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 21, 33 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362937046244925441",
  "geo" : { },
  "id_str" : "362940752990453762",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr @pixelpage @BelfastRuby It is coming on rightly :) Still on track for November, am serious like :)",
  "id" : 362940752990453762,
  "in_reply_to_status_id" : 362937046244925441,
  "created_at" : "2013-08-01 14:19:53 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    }, {
      "name" : "Colin Mitchell",
      "screen_name" : "pixelpage",
      "indices" : [ 10, 20 ],
      "id_str" : "52710181",
      "id" : 52710181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362929577376485376",
  "geo" : { },
  "id_str" : "362930170908250112",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr @pixelpage that reply is probably the most anal reply I have ever read... Also - The Wire - where are ya?",
  "id" : 362930170908250112,
  "in_reply_to_status_id" : 362929577376485376,
  "created_at" : "2013-08-01 13:37:50 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362929939428806658",
  "text" : "... spend a months wages on phonecalls to that company at every fucking opportunity.. Hard to get into any zone with that happening!!!",
  "id" : 362929939428806658,
  "created_at" : "2013-08-01 13:36:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362929796876996609",
  "text" : "It'd be worth actually going back in time and buying a fax machine and finding out what motherless fuck is doing this and then...",
  "id" : 362929796876996609,
  "created_at" : "2013-08-01 13:36:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362929627439697920",
  "text" : "It waits for exactly 7 seconds before the beep starts... It makes little difference whether I talk first or not. It has defeated me.",
  "id" : 362929627439697920,
  "created_at" : "2013-08-01 13:35:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andygough",
      "screen_name" : "andygough",
      "indices" : [ 0, 10 ],
      "id_str" : "16174070",
      "id" : 16174070
    }, {
      "name" : "GCD Technologies",
      "screen_name" : "gcdtechnologies",
      "indices" : [ 11, 27 ],
      "id_str" : "111012190",
      "id" : 111012190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350576864852578305",
  "geo" : { },
  "id_str" : "362928137916530688",
  "in_reply_to_user_id" : 16174070,
  "text" : "@andygough @gcdtechnologies :D Love this.....",
  "id" : 362928137916530688,
  "in_reply_to_status_id" : 350576864852578305,
  "created_at" : "2013-08-01 13:29:45 +0000",
  "in_reply_to_screen_name" : "andygough",
  "in_reply_to_user_id_str" : "16174070",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 0, 9 ],
      "id_str" : "729883",
      "id" : 729883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362926541585383426",
  "geo" : { },
  "id_str" : "362926841700425731",
  "in_reply_to_user_id" : 729883,
  "text" : "@chrismcg it just happened there again!! I am going crazy am here till 6. I was 10stone and had a full lot of flowing hair prior to all this",
  "id" : 362926841700425731,
  "in_reply_to_status_id" : 362926541585383426,
  "created_at" : "2013-08-01 13:24:36 +0000",
  "in_reply_to_screen_name" : "chrismcg",
  "in_reply_to_user_id_str" : "729883",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 0, 9 ],
      "id_str" : "729883",
      "id" : 729883
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 74, 81 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 112, 120 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362926038445080577",
  "geo" : { },
  "id_str" : "362926317739577344",
  "in_reply_to_user_id" : 729883,
  "text" : "@chrismcg its killing me. every 15mins since 9am. I answered the phone to @rejoco and could just about speak... @jbrevel is pissing himself",
  "id" : 362926317739577344,
  "in_reply_to_status_id" : 362926038445080577,
  "created_at" : "2013-08-01 13:22:31 +0000",
  "in_reply_to_screen_name" : "chrismcg",
  "in_reply_to_user_id_str" : "729883",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362924609823195137",
  "text" : "Some motherless twat keeps on phoning the office with a fax. Yes its probably a computer and knows no better but it is FUCKING killing me!!!",
  "id" : 362924609823195137,
  "created_at" : "2013-08-01 13:15:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362888856275656705",
  "text" : "OH: \"Yeah, being horny with other guys doesn't make you gay\"",
  "id" : 362888856275656705,
  "created_at" : "2013-08-01 10:53:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362831350711070721",
  "text" : "This year really needs to SLOW. THE. FUCK DOWN.",
  "id" : 362831350711070721,
  "created_at" : "2013-08-01 07:05:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]