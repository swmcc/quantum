Grailbird.data.tweets_2013_07 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 9, 23 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 24, 40 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362592007857766401",
  "geo" : { },
  "id_str" : "362592223096881152",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @peter_omalley @michaelnsimpson that was the best friday ever... I miss it... Only thing that shut us up :)",
  "id" : 362592223096881152,
  "in_reply_to_status_id" : 362592007857766401,
  "created_at" : "2013-07-31 15:14:57 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 9, 23 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 24, 40 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362590108882444290",
  "geo" : { },
  "id_str" : "362590202126012417",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @peter_omalley @michaelnsimpson there will be plenty of other times you drama queen!",
  "id" : 362590202126012417,
  "in_reply_to_status_id" : 362590108882444290,
  "created_at" : "2013-07-31 15:06:55 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 82, 96 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 101, 117 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362590014644813826",
  "text" : "Gonna have to make a quick trip home to see if my wallet is there as I am meeting @peter_omalley and @michaelnsimpson later.....",
  "id" : 362590014644813826,
  "created_at" : "2013-07-31 15:06:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 3, 15 ],
      "id_str" : "454835425",
      "id" : 454835425
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 44, 56 ],
      "id_str" : "454835425",
      "id" : 454835425
    }, {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 82, 91 ],
      "id_str" : "729883",
      "id" : 729883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362519400726798336",
  "text" : "RT @BelfastRuby: Don\u2019t forget, next Tuesday @belfastruby meetup will be a talk by @chrismcg: Let's Talk About Testing.  http:\/\/t.co\/Sq1n9x9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Belfast Ruby",
        "screen_name" : "BelfastRuby",
        "indices" : [ 27, 39 ],
        "id_str" : "454835425",
        "id" : 454835425
      }, {
        "name" : "Chris McGrath",
        "screen_name" : "chrismcg",
        "indices" : [ 65, 74 ],
        "id_str" : "729883",
        "id" : 729883
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Sq1n9x9nV9",
        "expanded_url" : "http:\/\/digitalcircle.org\/events\/479",
        "display_url" : "digitalcircle.org\/events\/479"
      } ]
    },
    "geo" : { },
    "id_str" : "362517238877659136",
    "text" : "Don\u2019t forget, next Tuesday @belfastruby meetup will be a talk by @chrismcg: Let's Talk About Testing.  http:\/\/t.co\/Sq1n9x9nV9",
    "id" : 362517238877659136,
    "created_at" : "2013-07-31 10:16:59 +0000",
    "user" : {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "protected" : false,
      "id_str" : "454835425",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1752070239\/belfastruby-twitter-icon-2_normal.png",
      "id" : 454835425,
      "verified" : false
    }
  },
  "id" : 362519400726798336,
  "created_at" : "2013-07-31 10:25:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362519352265814016",
  "text" : "Looked for my wallet this morning - couldn't find it. Thought it was in work. It is not in work. Think I've done it this time.",
  "id" : 362519352265814016,
  "created_at" : "2013-07-31 10:25:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    }, {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 13, 24 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362491242786988032",
  "geo" : { },
  "id_str" : "362491416108220417",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger @bigwetfish well just fucking do it. You carrick hoods can stick together. Can't recommend them highly enough :)",
  "id" : 362491416108220417,
  "in_reply_to_status_id" : 362491242786988032,
  "created_at" : "2013-07-31 08:34:23 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    }, {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 17, 28 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362489750705291265",
  "geo" : { },
  "id_str" : "362490197407039490",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger use @bigwetfish but be sensible and go debian.",
  "id" : 362490197407039490,
  "in_reply_to_status_id" : 362489750705291265,
  "created_at" : "2013-07-31 08:29:32 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ubdRE8MuDi",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=hnEST9Z_GP4",
      "display_url" : "youtube.com\/watch?v=hnEST9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "362331646072061955",
  "geo" : { },
  "id_str" : "362332041997582336",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I watch it every christmas.. Also the main elf is http:\/\/t.co\/ubdRE8MuDi - bestest christmas film ever.",
  "id" : 362332041997582336,
  "in_reply_to_status_id" : 362331646072061955,
  "created_at" : "2013-07-30 22:01:05 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/dBZ9T5ibjx",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9EUOzAuSkRA",
      "display_url" : "youtube.com\/watch?v=9EUOzA\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "362330234244177920",
  "geo" : { },
  "id_str" : "362331368493023232",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I stand corrected this is - http:\/\/t.co\/dBZ9T5ibjx",
  "id" : 362331368493023232,
  "in_reply_to_status_id" : 362330234244177920,
  "created_at" : "2013-07-30 21:58:24 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/m3vaeKCxxp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=DeDgIvlonhY",
      "display_url" : "youtube.com\/watch?v=DeDgIv\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "362330234244177920",
  "geo" : { },
  "id_str" : "362330842191757313",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl http:\/\/t.co\/m3vaeKCxxp This much scarier than Trinty to be fair...",
  "id" : 362330842191757313,
  "in_reply_to_status_id" : 362330234244177920,
  "created_at" : "2013-07-30 21:56:19 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362330234244177920",
  "geo" : { },
  "id_str" : "362330596980162560",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl this was 2003 - so was pre Dexter. To me he was B.Z. from Santa Clause: The Movie.. So I just wanted a lolly that would make me fly.",
  "id" : 362330596980162560,
  "in_reply_to_status_id" : 362330234244177920,
  "created_at" : "2013-07-30 21:55:20 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362329200436326400",
  "geo" : { },
  "id_str" : "362329622689497089",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I once saw Lithgow walking his dog in Central Park in New York.. True bill..",
  "id" : 362329622689497089,
  "in_reply_to_status_id" : 362329200436326400,
  "created_at" : "2013-07-30 21:51:28 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362329200436326400",
  "geo" : { },
  "id_str" : "362329447338221568",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I loved the first two seasons, third and fourth were good enough with Lithgow a seriously scary bastard.",
  "id" : 362329447338221568,
  "in_reply_to_status_id" : 362329200436326400,
  "created_at" : "2013-07-30 21:50:46 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362328518572523520",
  "geo" : { },
  "id_str" : "362328765377953793",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl that episode was much better than the previous ones.. Well so my counterpart in the states told me. Obv I wont know until next week",
  "id" : 362328765377953793,
  "in_reply_to_status_id" : 362328518572523520,
  "created_at" : "2013-07-30 21:48:04 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/GKxvtpZbXr",
      "expanded_url" : "http:\/\/instagram.com\/p\/cZ4DS7hX6_\/",
      "display_url" : "instagram.com\/p\/cZ4DS7hX6_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "362315912596037633",
  "text" : "Dexter http:\/\/t.co\/GKxvtpZbXr",
  "id" : 362315912596037633,
  "created_at" : "2013-07-30 20:56:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362293449896099840",
  "text" : "Just home and I\u2019m gonna make spuds, cabbage and bacon. Just try and stop me!!!!",
  "id" : 362293449896099840,
  "created_at" : "2013-07-30 19:27:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PvonSdsIr2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=HGZtaoWT96E",
      "display_url" : "youtube.com\/watch?v=HGZtao\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362231246794932225",
  "text" : "http:\/\/t.co\/PvonSdsIr2 even funnier :)",
  "id" : 362231246794932225,
  "created_at" : "2013-07-30 15:20:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NpWnbWINHy",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eUFY8Zw0Bag",
      "display_url" : "youtube.com\/watch?v=eUFY8Z\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362230586401763329",
  "text" : "http:\/\/t.co\/NpWnbWINHy",
  "id" : 362230586401763329,
  "created_at" : "2013-07-30 15:17:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 91, 99 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "git",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362213877628416001",
  "text" : "That moment you think you must have deleted code.... As I totally remember writing this... @jbrevel concurs... Time to go diggin #git",
  "id" : 362213877628416001,
  "created_at" : "2013-07-30 14:11:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SendGrid",
      "screen_name" : "SendGrid",
      "indices" : [ 3, 12 ],
      "id_str" : "42126617",
      "id" : 42126617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361899684333236224",
  "text" : "RT @SendGrid: Follow these 4 steps to calculate the true cost of building your own email infrastructure or outsourcing to the cloud http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Hev7hqLjLY",
        "expanded_url" : "http:\/\/bit.ly\/14sA1jS",
        "display_url" : "bit.ly\/14sA1jS"
      } ]
    },
    "geo" : { },
    "id_str" : "357923659144372224",
    "text" : "Follow these 4 steps to calculate the true cost of building your own email infrastructure or outsourcing to the cloud http:\/\/t.co\/Hev7hqLjLY",
    "id" : 357923659144372224,
    "created_at" : "2013-07-18 18:03:44 +0000",
    "user" : {
      "name" : "SendGrid",
      "screen_name" : "SendGrid",
      "protected" : false,
      "id_str" : "42126617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2945436773\/b94913c034ec51a0bf0ab403b1071f01_normal.jpeg",
      "id" : 42126617,
      "verified" : false
    }
  },
  "id" : 361899684333236224,
  "created_at" : "2013-07-29 17:23:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361840260189130753",
  "text" : "Gonna be big thunder in here in a bit... BIG THUNDER!!!!!! Grey as fook to the south - nice and blue to the north.",
  "id" : 361840260189130753,
  "created_at" : "2013-07-29 13:26:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 3, 12 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 21, 27 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361825497459593217",
  "text" : "RT @davehedo: I love @swmcc so so so much and goats.. I also love goats &lt;3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 7, 13 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361823910376910848",
    "text" : "I love @swmcc so so so much and goats.. I also love goats &lt;3",
    "id" : 361823910376910848,
    "created_at" : "2013-07-29 12:21:57 +0000",
    "user" : {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "protected" : false,
      "id_str" : "50985598",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000509606650\/9ac4420064b46da165a3e180e20ef133_normal.jpeg",
      "id" : 50985598,
      "verified" : false
    }
  },
  "id" : 361825497459593217,
  "created_at" : "2013-07-29 12:28:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 0, 11 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361568604417830914",
  "geo" : { },
  "id_str" : "361599261491732481",
  "in_reply_to_user_id" : 5932682,
  "text" : "@davidjrice knock the fuck out of the cunt!",
  "id" : 361599261491732481,
  "in_reply_to_status_id" : 361568604417830914,
  "created_at" : "2013-07-28 21:29:16 +0000",
  "in_reply_to_screen_name" : "davidjrice",
  "in_reply_to_user_id_str" : "5932682",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361090942620540930",
  "geo" : { },
  "id_str" : "361128494098432000",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl cos life isn't hard enough :)",
  "id" : 361128494098432000,
  "in_reply_to_status_id" : 361090942620540930,
  "created_at" : "2013-07-27 14:18:37 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/SkAcU3JinX",
      "expanded_url" : "http:\/\/jeffkreeftmeijer.com\/2012\/relative-line-numbers-in-vim-for-super-fast-movement\/",
      "display_url" : "jeffkreeftmeijer.com\/2012\/relative-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "361122337145360385",
  "text" : "Just switched this on in my .vimrc - http:\/\/t.co\/SkAcU3JinX - should improve my speed.",
  "id" : 361122337145360385,
  "created_at" : "2013-07-27 13:54:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 19, 26 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "marc dowie",
      "screen_name" : "marcdowie",
      "indices" : [ 31, 41 ],
      "id_str" : "58811666",
      "id" : 58811666
    }, {
      "name" : "Vertical Structure",
      "screen_name" : "vsltd",
      "indices" : [ 45, 51 ],
      "id_str" : "241078404",
      "id" : 241078404
    }, {
      "name" : "mourne seafood",
      "screen_name" : "mourneseafood",
      "indices" : [ 71, 85 ],
      "id_str" : "133738475",
      "id" : 133738475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361020314844532737",
  "text" : "Huge big thanks to @szlwzl and @marcdowie of @vsltd who took us out to @mourneseafood - fantastic food. Thanks guys :)",
  "id" : 361020314844532737,
  "created_at" : "2013-07-27 07:08:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mourne seafood",
      "screen_name" : "mourneseafood",
      "indices" : [ 7, 21 ],
      "id_str" : "133738475",
      "id" : 133738475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/T4yybM1LeF",
      "expanded_url" : "http:\/\/4sq.com\/15R5z52",
      "display_url" : "4sq.com\/15R5z52"
    } ]
  },
  "geo" : { },
  "id_str" : "360824529662124032",
  "text" : "I'm at @MourneSeafood Bar (Belfast) http:\/\/t.co\/T4yybM1LeF",
  "id" : 360824529662124032,
  "created_at" : "2013-07-26 18:10:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 3, 17 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Stephen Nolan",
      "screen_name" : "StephenNolan",
      "indices" : [ 19, 32 ],
      "id_str" : "36673147",
      "id" : 36673147
    }, {
      "name" : "The A21 Campaign",
      "screen_name" : "TheA21Campaign",
      "indices" : [ 102, 117 ],
      "id_str" : "23847000",
      "id" : 23847000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trafficked",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360702522635194368",
  "text" : "RT @jenporterhall: @StephenNolan Frocks for Freedom event October 5th Belfast City Hall in support of @TheA21Campaign helping #trafficked v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen Nolan",
        "screen_name" : "StephenNolan",
        "indices" : [ 0, 13 ],
        "id_str" : "36673147",
        "id" : 36673147
      }, {
        "name" : "The A21 Campaign",
        "screen_name" : "TheA21Campaign",
        "indices" : [ 83, 98 ],
        "id_str" : "23847000",
        "id" : 23847000
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "trafficked",
        "indices" : [ 107, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360695434315956224",
    "in_reply_to_user_id" : 36673147,
    "text" : "@StephenNolan Frocks for Freedom event October 5th Belfast City Hall in support of @TheA21Campaign helping #trafficked victims.",
    "id" : 360695434315956224,
    "created_at" : "2013-07-26 09:37:47 +0000",
    "in_reply_to_screen_name" : "StephenNolan",
    "in_reply_to_user_id_str" : "36673147",
    "user" : {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "protected" : false,
      "id_str" : "227493010",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2257082551\/DSCF9612_normal.jpg",
      "id" : 227493010,
      "verified" : false
    }
  },
  "id" : 360702522635194368,
  "created_at" : "2013-07-26 10:05:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 7, 19 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/360694076879826944\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/zTqipJuJIr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQFxWhWCcAAwJiX.jpg",
      "id_str" : "360694076888215552",
      "id" : 360694076888215552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQFxWhWCcAAwJiX.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/zTqipJuJIr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360694076879826944",
  "text" : "Cheers @DebbieCReid http:\/\/t.co\/zTqipJuJIr",
  "id" : 360694076879826944,
  "created_at" : "2013-07-26 09:32:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Open Source",
      "screen_name" : "TwitterOSS",
      "indices" : [ 3, 14 ],
      "id_str" : "376825877",
      "id" : 376825877
    }, {
      "name" : "Airbnb Engineering",
      "screen_name" : "AirbnbNerds",
      "indices" : [ 42, 54 ],
      "id_str" : "838673862",
      "id" : 838673862
    }, {
      "name" : "Apache Mesos",
      "screen_name" : "ApacheMesos",
      "indices" : [ 79, 91 ],
      "id_str" : "519262288",
      "id" : 519262288
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TwitterOSS\/status\/360595512744878084\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/yFzS7AP8jL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQEXtVVCIAAdJuH.jpg",
      "id_str" : "360595512753266688",
      "id" : 360595512753266688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQEXtVVCIAAdJuH.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yFzS7AP8jL"
    } ],
    "hashtags" : [ {
      "text" : "hadoop",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360660167634849793",
  "text" : "RT @TwitterOSS: now Brenden Matthews from @AirbnbNerds discussing how they use @ApacheMesos with #hadoop http:\/\/t.co\/yFzS7AP8jL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Airbnb Engineering",
        "screen_name" : "AirbnbNerds",
        "indices" : [ 26, 38 ],
        "id_str" : "838673862",
        "id" : 838673862
      }, {
        "name" : "Apache Mesos",
        "screen_name" : "ApacheMesos",
        "indices" : [ 63, 75 ],
        "id_str" : "519262288",
        "id" : 519262288
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TwitterOSS\/status\/360595512744878084\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/yFzS7AP8jL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQEXtVVCIAAdJuH.jpg",
        "id_str" : "360595512753266688",
        "id" : 360595512753266688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQEXtVVCIAAdJuH.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yFzS7AP8jL"
      } ],
      "hashtags" : [ {
        "text" : "hadoop",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7768244502, -122.417539498 ]
    },
    "id_str" : "360595512744878084",
    "text" : "now Brenden Matthews from @AirbnbNerds discussing how they use @ApacheMesos with #hadoop http:\/\/t.co\/yFzS7AP8jL",
    "id" : 360595512744878084,
    "created_at" : "2013-07-26 03:00:44 +0000",
    "user" : {
      "name" : "Twitter Open Source",
      "screen_name" : "TwitterOSS",
      "protected" : false,
      "id_str" : "376825877",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000416683223\/1bc995c5cfe98cb3c621f1ba0bf99223_normal.png",
      "id" : 376825877,
      "verified" : true
    }
  },
  "id" : 360660167634849793,
  "created_at" : "2013-07-26 07:17:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 13, 26 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360519259782258688",
  "geo" : { },
  "id_str" : "360655758741864448",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid @Paul_Moffett Hiding a desk in an open plan office takes skill.. But I has that skill :)",
  "id" : 360655758741864448,
  "in_reply_to_status_id" : 360519259782258688,
  "created_at" : "2013-07-26 07:00:08 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 3, 15 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 17, 23 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 30, 43 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wonderhowthathappened",
      "indices" : [ 116, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360655597273747456",
  "text" : "RT @DebbieCReid: @swmcc &amp; @Paul_Moffett arrived this AM to find his desk had mysteriously disappeared overnight!#wonderhowthathappened http\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Paul Moffett",
        "screen_name" : "Paul_Moffett",
        "indices" : [ 13, 26 ],
        "id_str" : "36913698",
        "id" : 36913698
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DebbieCReid\/status\/360519259782258688\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/TozmOsEkX9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQDSW05CIAEGLPp.jpg",
        "id_str" : "360519259786452993",
        "id" : 360519259786452993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQDSW05CIAEGLPp.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/TozmOsEkX9"
      } ],
      "hashtags" : [ {
        "text" : "wonderhowthathappened",
        "indices" : [ 99, 121 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "360333557543096320",
    "geo" : { },
    "id_str" : "360519259782258688",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc &amp; @Paul_Moffett arrived this AM to find his desk had mysteriously disappeared overnight!#wonderhowthathappened http:\/\/t.co\/TozmOsEkX9",
    "id" : 360519259782258688,
    "in_reply_to_status_id" : 360333557543096320,
    "created_at" : "2013-07-25 21:57:44 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "protected" : false,
      "id_str" : "53155256",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000402062796\/48362b18cdee598e45ee405286ad7442_normal.png",
      "id" : 53155256,
      "verified" : false
    }
  },
  "id" : 360655597273747456,
  "created_at" : "2013-07-26 06:59:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/360449658721550336\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/aV2OebBSey",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQCTDgvCQAEJkwn.png",
      "id_str" : "360449658725744641",
      "id" : 360449658725744641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQCTDgvCQAEJkwn.png",
      "sizes" : [ {
        "h" : 208,
        "resize" : "fit",
        "w" : 489
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 489
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 489
      } ],
      "display_url" : "pic.twitter.com\/aV2OebBSey"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360449658721550336",
  "text" : "Oh dear... not a good sign.... I am professional but also quite rough... http:\/\/t.co\/aV2OebBSey",
  "id" : 360449658721550336,
  "created_at" : "2013-07-25 17:21:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 73, 81 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hesaidthat",
      "indices" : [ 82, 93 ]
    }, {
      "text" : "oddfucker",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360445532004560897",
  "text" : "OH: \"I am gonna go and buy myself new clothes to cheer myself up\"... \/cc @jbrevel #hesaidthat #oddfucker",
  "id" : 360445532004560897,
  "created_at" : "2013-07-25 17:04:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 3, 15 ],
      "id_str" : "454835425",
      "id" : 454835425
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 22, 34 ],
      "id_str" : "454835425",
      "id" : 454835425
    }, {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 80, 89 ],
      "id_str" : "729883",
      "id" : 729883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Sq1n9x9nV9",
      "expanded_url" : "http:\/\/digitalcircle.org\/events\/479",
      "display_url" : "digitalcircle.org\/events\/479"
    } ]
  },
  "geo" : { },
  "id_str" : "360355652486430720",
  "text" : "RT @BelfastRuby: Next @belfastruby meetup will be Tue 6th August with a talk by @chrismcg: Let's Talk About Testing.  http:\/\/t.co\/Sq1n9x9nV9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Belfast Ruby",
        "screen_name" : "BelfastRuby",
        "indices" : [ 5, 17 ],
        "id_str" : "454835425",
        "id" : 454835425
      }, {
        "name" : "Chris McGrath",
        "screen_name" : "chrismcg",
        "indices" : [ 63, 72 ],
        "id_str" : "729883",
        "id" : 729883
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/Sq1n9x9nV9",
        "expanded_url" : "http:\/\/digitalcircle.org\/events\/479",
        "display_url" : "digitalcircle.org\/events\/479"
      } ]
    },
    "geo" : { },
    "id_str" : "359942953180999680",
    "text" : "Next @belfastruby meetup will be Tue 6th August with a talk by @chrismcg: Let's Talk About Testing.  http:\/\/t.co\/Sq1n9x9nV9",
    "id" : 359942953180999680,
    "created_at" : "2013-07-24 07:47:42 +0000",
    "user" : {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "protected" : false,
      "id_str" : "454835425",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1752070239\/belfastruby-twitter-icon-2_normal.png",
      "id" : 454835425,
      "verified" : false
    }
  },
  "id" : 360355652486430720,
  "created_at" : "2013-07-25 11:07:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 2, 15 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/360333557543096320\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/KDzY6VNoSu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQApdiJCUAAQEEM.jpg",
      "id_str" : "360333557547290624",
      "id" : 360333557547290624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQApdiJCUAAQEEM.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/KDzY6VNoSu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360333557543096320",
  "text" : "A @Paul_Moffett did this yesterday to me. Well played. http:\/\/t.co\/KDzY6VNoSu",
  "id" : 360333557543096320,
  "created_at" : "2013-07-25 09:39:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 36, 45 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360053078260580353",
  "text" : "OH: \"My arse is still wet Stevie\" - @davehedo just said to me.",
  "id" : 360053078260580353,
  "created_at" : "2013-07-24 15:05:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360046985602019329",
  "text" : "So @jbrevel just corrected me on Mylie Cyrus and Taylor Swift. I didn't know there really was a diff... Obv there is...",
  "id" : 360046985602019329,
  "created_at" : "2013-07-24 14:41:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/360035958785200128\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/FNIqAk4KAH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP8azAZCUAAReJ7.png",
      "id_str" : "360035958793588736",
      "id" : 360035958793588736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP8azAZCUAAReJ7.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 881
      }, {
        "h" : 104,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 183,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 881
      } ],
      "display_url" : "pic.twitter.com\/FNIqAk4KAH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360035958785200128",
  "text" : "Tales from hipchat.... http:\/\/t.co\/FNIqAk4KAH",
  "id" : 360035958785200128,
  "created_at" : "2013-07-24 13:57:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 56, 63 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360023643062939648",
  "text" : "Reading about the internals of highcharts now thanks to @szlwzl - he did however give me two tickets to go see TWW at Stormont so he lives",
  "id" : 360023643062939648,
  "created_at" : "2013-07-24 13:08:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 4, 11 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "vine",
      "screen_name" : "vine",
      "indices" : [ 50, 55 ],
      "id_str" : "5434942",
      "id" : 5434942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360019567805870081",
  "text" : "For @szlwzl - \"Arrrrrr. Arrrr. Arrrrr.\" - I would @vine me doing it but I can't really be arsed.",
  "id" : 360019567805870081,
  "created_at" : "2013-07-24 12:52:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    }, {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 20, 27 ],
      "id_str" : "285766850",
      "id" : 285766850
    }, {
      "name" : "The Ruby Show",
      "screen_name" : "therubyshow",
      "indices" : [ 29, 41 ],
      "id_str" : "106742110",
      "id" : 106742110
    }, {
      "name" : "Ruby Rogues",
      "screen_name" : "rubyrogues",
      "indices" : [ 43, 54 ],
      "id_str" : "284225770",
      "id" : 284225770
    }, {
      "name" : "TWiStartups",
      "screen_name" : "TWistartups",
      "indices" : [ 56, 68 ],
      "id_str" : "112880396",
      "id" : 112880396
    }, {
      "name" : "Code School",
      "screen_name" : "codeschool",
      "indices" : [ 86, 97 ],
      "id_str" : "240254617",
      "id" : 240254617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359721143122403328",
  "geo" : { },
  "id_str" : "359759085035454465",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir I listen to @NodeUp, @therubyshow, @rubyrogues, @TWistartups and subscribe to @codeschool. You got any good ones?",
  "id" : 359759085035454465,
  "in_reply_to_status_id" : 359721143122403328,
  "created_at" : "2013-07-23 19:37:04 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359662959913467904",
  "geo" : { },
  "id_str" : "359667453942431744",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir i've missed the last few weeks of those podcasts - need to play catchup. Weather has been too nice. I need to work play soon though.",
  "id" : 359667453942431744,
  "in_reply_to_status_id" : 359662959913467904,
  "created_at" : "2013-07-23 13:32:57 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359659772015943682",
  "geo" : { },
  "id_str" : "359660216456970241",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir :) Always good to see another developer do shit like this.... Blog about it - awwww go on!",
  "id" : 359660216456970241,
  "in_reply_to_status_id" : 359659772015943682,
  "created_at" : "2013-07-23 13:04:12 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359411906026553345",
  "text" : "Wonder how much different the world will be when that wee dude will be King... Gets ya thinking....",
  "id" : 359411906026553345,
  "created_at" : "2013-07-22 20:37:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359389453191622657",
  "text" : "Newsroom has found its feet without being sanctimonious. Easy to be a general after the war though. Still valid questions all the same.",
  "id" : 359389453191622657,
  "created_at" : "2013-07-22 19:08:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "royalbaby",
      "indices" : [ 7, 17 ]
    }, {
      "text" : "honouryuncle",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Trx4UOq1Va",
      "expanded_url" : "http:\/\/instagram.com\/p\/b_81_GJo_V\/",
      "display_url" : "instagram.com\/p\/b_81_GJo_V\/"
    } ]
  },
  "geo" : { },
  "id_str" : "359287053772529664",
  "text" : "Pfffft #royalbaby is nothing... First next generation McCullough male was born on Friday - http:\/\/t.co\/Trx4UOq1Va  - AWESOME. #honouryuncle",
  "id" : 359287053772529664,
  "created_at" : "2013-07-22 12:21:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShiftDock",
      "screen_name" : "shiftdock",
      "indices" : [ 3, 13 ],
      "id_str" : "555532046",
      "id" : 555532046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/0haI5hfBsN",
      "expanded_url" : "http:\/\/blog.shiftdock.com",
      "display_url" : "blog.shiftdock.com"
    } ]
  },
  "geo" : { },
  "id_str" : "359048218036142080",
  "text" : "RT @shiftdock: Our new blog is available now at http:\/\/t.co\/0haI5hfBsN! We'll be blogging on new features and news. Please help us spread t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/0haI5hfBsN",
        "expanded_url" : "http:\/\/blog.shiftdock.com",
        "display_url" : "blog.shiftdock.com"
      } ]
    },
    "geo" : { },
    "id_str" : "359040791219408896",
    "text" : "Our new blog is available now at http:\/\/t.co\/0haI5hfBsN! We'll be blogging on new features and news. Please help us spread the word!",
    "id" : 359040791219408896,
    "created_at" : "2013-07-21 20:02:49 +0000",
    "user" : {
      "name" : "ShiftDock",
      "screen_name" : "shiftdock",
      "protected" : false,
      "id_str" : "555532046",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3505651062\/95a88815488e69e405baf681a2814aee_normal.png",
      "id" : 555532046,
      "verified" : false
    }
  },
  "id" : 359048218036142080,
  "created_at" : "2013-07-21 20:32:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/359038945885057024\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/08D1I8DrHG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPuQBN5CcAAOdn4.jpg",
      "id_str" : "359038945889251328",
      "id" : 359038945889251328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPuQBN5CcAAOdn4.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/08D1I8DrHG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359038945885057024",
  "text" : "Way better and rewarding than a blog post I think. http:\/\/t.co\/08D1I8DrHG",
  "id" : 359038945885057024,
  "created_at" : "2013-07-21 19:55:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359028681244553216",
  "text" : "Hmmmm time for a technical blogpost on tmux... for it rocks.. but not now. the weather is too good - will keep until its raining and shity",
  "id" : 359028681244553216,
  "created_at" : "2013-07-21 19:14:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 12, 19 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 20, 28 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 29, 39 ],
      "id_str" : "240194412",
      "id" : 240194412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358350701723779074",
  "geo" : { },
  "id_str" : "358356476265365504",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne @szlwzl @jbrevel @RepKnight I'm pretty fucking drunk right now so I should really put. the. phone. down. cos this will end badly",
  "id" : 358356476265365504,
  "in_reply_to_status_id" : 358350701723779074,
  "created_at" : "2013-07-19 22:43:36 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 14, 20 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358282958848790529",
  "text" : "RT @jasebell: @swmcc Thought For The Day with Stephen McCullough :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "358163095891361792",
    "geo" : { },
    "id_str" : "358171307764363264",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Thought For The Day with Stephen McCullough :)",
    "id" : 358171307764363264,
    "in_reply_to_status_id" : 358163095891361792,
    "created_at" : "2013-07-19 10:27:48 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "protected" : false,
      "id_str" : "1248789104",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000600719719\/1f076e9f2650e4ea1930f33a7fbd28de_normal.jpeg",
      "id" : 1248789104,
      "verified" : false
    }
  },
  "id" : 358282958848790529,
  "created_at" : "2013-07-19 17:51:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 0, 9 ],
      "id_str" : "95932190",
      "id" : 95932190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358276954027335681",
  "geo" : { },
  "id_str" : "358282833078390784",
  "in_reply_to_user_id" : 95932190,
  "text" : "@brrygrdn where the fuck have you been? :D",
  "id" : 358282833078390784,
  "in_reply_to_status_id" : 358276954027335681,
  "created_at" : "2013-07-19 17:50:58 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358222612414996480",
  "text" : "RT @jbrevel: @swmcc Needless to say stevie put it in my head......no wait a minute.....",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "358220990381166593",
    "geo" : { },
    "id_str" : "358222503660892162",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Needless to say stevie put it in my head......no wait a minute.....",
    "id" : 358222503660892162,
    "in_reply_to_status_id" : 358220990381166593,
    "created_at" : "2013-07-19 13:51:14 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 358222612414996480,
  "created_at" : "2013-07-19 13:51:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 22, 30 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358220990381166593",
  "text" : "This just happened... @jbrevel coming in from the kitchen singing \"Sweaty ball sack\" over and over....",
  "id" : 358220990381166593,
  "created_at" : "2013-07-19 13:45:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358213920495898627",
  "text" : "What a scorcher of a day!",
  "id" : 358213920495898627,
  "created_at" : "2013-07-19 13:17:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358163095891361792",
  "text" : "Too many people wearing shorts and sandals in the office today..... Fucking rank...",
  "id" : 358163095891361792,
  "created_at" : "2013-07-19 09:55:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357606469056729089",
  "geo" : { },
  "id_str" : "357606963535806464",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall no it\u2019s not!!!!!",
  "id" : 357606963535806464,
  "in_reply_to_status_id" : 357606469056729089,
  "created_at" : "2013-07-17 21:05:18 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 40, 54 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/357605581890125824\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/9uQonU2V5D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPZ4Yc6CAAAlbH_.png",
      "id_str" : "357605581894320128",
      "id" : 357605581894320128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPZ4Yc6CAAAlbH_.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/9uQonU2V5D"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357605581890125824",
  "text" : "Friendship is effectively over now! \/cc @jenporterhall http:\/\/t.co\/9uQonU2V5D",
  "id" : 357605581890125824,
  "created_at" : "2013-07-17 20:59:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357517972979466240",
  "text" : "There is a few hours I wont get back... Json double encoding... Fun wee bug to find that....!!!",
  "id" : 357517972979466240,
  "created_at" : "2013-07-17 15:11:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357442243033972736",
  "text" : "Weekend in Dublin... can't fucking wait...",
  "id" : 357442243033972736,
  "created_at" : "2013-07-17 10:10:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 50, 62 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 76, 83 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357219034682507264",
  "text" : "Only person I've talked to the whole day has been @DebbieCReid .. hopefully @szlwzl will be on skype soon or i might start talking to myself",
  "id" : 357219034682507264,
  "created_at" : "2013-07-16 19:23:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/357202302211334147\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/yJTkk84Ree",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPUJmfDCIAA1Who.png",
      "id_str" : "357202302219722752",
      "id" : 357202302219722752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPUJmfDCIAA1Who.png",
      "sizes" : [ {
        "h" : 63,
        "resize" : "fit",
        "w" : 878
      }, {
        "h" : 43,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 63,
        "resize" : "fit",
        "w" : 878
      }, {
        "h" : 24,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 63,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/yJTkk84Ree"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357202302211334147",
  "text" : "The heart is pinning. http:\/\/t.co\/yJTkk84Ree",
  "id" : 357202302211334147,
  "created_at" : "2013-07-16 18:17:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357153226879016965",
  "text" : "Also pretty sure something flew out of my car when I braked... Think it was my testicals",
  "id" : 357153226879016965,
  "created_at" : "2013-07-16 15:02:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NotWorthIt",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357152928844365825",
  "text" : "I was *this* close to having a tractor run over me and my car there... Fucking kids.. Texting and driving at the same time! #NotWorthIt",
  "id" : 357152928844365825,
  "created_at" : "2013-07-16 15:01:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 13, 26 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357075259083587584",
  "geo" : { },
  "id_str" : "357076002217787392",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger @stevebiscuit use vim.... far far superior to any of that netbeans balls. Sublime is nice but you cannot beat VIM :)",
  "id" : 357076002217787392,
  "in_reply_to_status_id" : 357075259083587584,
  "created_at" : "2013-07-16 09:55:27 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356890581571608576",
  "text" : "In saying that I was running on pure fumes at that stage.... Roses tended - sunburnt got and my first time near a laptop in four days :)",
  "id" : 356890581571608576,
  "created_at" : "2013-07-15 21:38:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 56, 65 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 70, 78 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356890407419904000",
  "text" : "Back to work tomorrow. Great four days off... Hopefully @davehedo and @jbrevel wont be too hard on my diva fit that I had at 3:30 on Thur :)",
  "id" : 356890407419904000,
  "created_at" : "2013-07-15 21:37:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/AWRTOkzYpO",
      "expanded_url" : "http:\/\/instagram.com\/p\/buH0oghX7-\/",
      "display_url" : "instagram.com\/p\/buH0oghX7-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "356158156159725571",
  "text" : "Fire!!! :) http:\/\/t.co\/AWRTOkzYpO",
  "id" : 356158156159725571,
  "created_at" : "2013-07-13 21:08:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355993630953046016",
  "geo" : { },
  "id_str" : "356102047852019713",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit I like gardening :)",
  "id" : 356102047852019713,
  "in_reply_to_status_id" : 355993630953046016,
  "created_at" : "2013-07-13 17:25:18 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/355790154658615297\/photo\/1",
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/dKzHelpD8s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPAFQrdCEAA1EyJ.jpg",
      "id_str" : "355790154662809600",
      "id" : 355790154662809600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPAFQrdCEAA1EyJ.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/dKzHelpD8s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355790154658615297",
  "text" : ":) http:\/\/t.co\/dKzHelpD8s",
  "id" : 355790154658615297,
  "created_at" : "2013-07-12 20:45:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/355766737695801345\/photo\/1",
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/hGx5hl48L5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BO_v9oeCAAAqXMD.jpg",
      "id_str" : "355766737699995648",
      "id" : 355766737699995648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO_v9oeCAAAqXMD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com\/hGx5hl48L5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355766737695801345",
  "text" : ":) http:\/\/t.co\/hGx5hl48L5",
  "id" : 355766737695801345,
  "created_at" : "2013-07-12 19:12:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/355766665440542720\/photo\/1",
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/ia3EAwWtwa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BO_v5bTCQAMdixN.jpg",
      "id_str" : "355766665444737027",
      "id" : 355766665444737027,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO_v5bTCQAMdixN.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ia3EAwWtwa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355766665440542720",
  "text" : ":) http:\/\/t.co\/ia3EAwWtwa",
  "id" : 355766665440542720,
  "created_at" : "2013-07-12 19:12:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355654903059857408",
  "geo" : { },
  "id_str" : "355687839977046016",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne Oh I am - sometimes the iphone gets a net connection... Enjoying playing in me garden - roses look awesome!",
  "id" : 355687839977046016,
  "in_reply_to_status_id" : 355654903059857408,
  "created_at" : "2013-07-12 13:59:24 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/cEHaQtDa3a",
      "expanded_url" : "http:\/\/instagram.com\/p\/bqTPNABX3n\/",
      "display_url" : "instagram.com\/p\/bqTPNABX3n\/"
    } ]
  },
  "geo" : { },
  "id_str" : "355620582584352768",
  "text" : "Happy taig hunting day. Remember if you find one put it back or kill it humanely. This is what I am\u2026 http:\/\/t.co\/cEHaQtDa3a",
  "id" : 355620582584352768,
  "created_at" : "2013-07-12 09:32:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fourscore Food",
      "screen_name" : "fourscorefood",
      "indices" : [ 0, 14 ],
      "id_str" : "509057506",
      "id" : 509057506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355256054508040193",
  "geo" : { },
  "id_str" : "355256624862081026",
  "in_reply_to_user_id" : 509057506,
  "text" : "@fourscorefood will do :)",
  "id" : 355256624862081026,
  "in_reply_to_status_id" : 355256054508040193,
  "created_at" : "2013-07-11 09:25:54 +0000",
  "in_reply_to_screen_name" : "fourscorefood",
  "in_reply_to_user_id_str" : "509057506",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fourscore Food",
      "screen_name" : "fourscorefood",
      "indices" : [ 41, 55 ],
      "id_str" : "509057506",
      "id" : 509057506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355254729187672064",
  "text" : "Got 5 HUGE (ABS HUGE) sirlon steaks from @fourscorefood this morning for tomorrow for a BBQ.... Top quality...",
  "id" : 355254729187672064,
  "created_at" : "2013-07-11 09:18:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354947256207679491",
  "geo" : { },
  "id_str" : "354947608927666177",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates dunno - a bit of a coincidence that a connection dropped straight after I asked a \"what is your ip?\". Anyway.. happy thoughts.",
  "id" : 354947608927666177,
  "in_reply_to_status_id" : 354947256207679491,
  "created_at" : "2013-07-10 12:57:59 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354946521638244352",
  "text" : "Telling someone NOT to do something TWICE - then they end up doing it anyway and waste an hour of my time.. That is not how to make me happy",
  "id" : 354946521638244352,
  "created_at" : "2013-07-10 12:53:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbq",
      "indices" : [ 125, 129 ]
    }, {
      "text" : "beer",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354704542195134464",
  "text" : "I am not a mad prod but any stretch of the imagination but I am looking so forward to having a day off on Friday its unreal. #bbq and #beer",
  "id" : 354704542195134464,
  "created_at" : "2013-07-09 20:52:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 49, 62 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354258132584771584",
  "geo" : { },
  "id_str" : "354258812972183554",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid Why would I get the blame? They are @Paul_Moffett how they got there - I dunno....",
  "id" : 354258812972183554,
  "in_reply_to_status_id" : 354258132584771584,
  "created_at" : "2013-07-08 15:20:57 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354153069698756608",
  "text" : "People that wear sandals in work should be shot....",
  "id" : 354153069698756608,
  "created_at" : "2013-07-08 08:20:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353992527021477888",
  "geo" : { },
  "id_str" : "353992970531385346",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir never took to backbone but am loving angular, so far anyway.",
  "id" : 353992970531385346,
  "in_reply_to_status_id" : 353992527021477888,
  "created_at" : "2013-07-07 21:44:35 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353982134240817153",
  "geo" : { },
  "id_str" : "353991236144734210",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir several. Angular, node and rails. Just no time these last few weeks. Hopefully things clear this week though, I hope.",
  "id" : 353991236144734210,
  "in_reply_to_status_id" : 353982134240817153,
  "created_at" : "2013-07-07 21:37:42 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chloe Angyal",
      "screen_name" : "ChloeAngyal",
      "indices" : [ 3, 15 ],
      "id_str" : "51426896",
      "id" : 51426896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353976723571879937",
  "text" : "RT @ChloeAngyal: Murray is indeed the first Brit to win Wimbledon in 77 years unless you think women are people.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "353923409656291328",
    "text" : "Murray is indeed the first Brit to win Wimbledon in 77 years unless you think women are people.",
    "id" : 353923409656291328,
    "created_at" : "2013-07-07 17:08:11 +0000",
    "user" : {
      "name" : "Chloe Angyal",
      "screen_name" : "ChloeAngyal",
      "protected" : false,
      "id_str" : "51426896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000340428038\/3f2410f882967dee28c58778b69debf6_normal.jpeg",
      "id" : 51426896,
      "verified" : false
    }
  },
  "id" : 353976723571879937,
  "created_at" : "2013-07-07 20:40:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353971668173070336",
  "geo" : { },
  "id_str" : "353976253876928512",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir take a break and do it. I haven\u2019t in three weeks and I really need to. Working is great but you need to stretch the creative too.",
  "id" : 353976253876928512,
  "in_reply_to_status_id" : 353971668173070336,
  "created_at" : "2013-07-07 20:38:10 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yeah",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353963370648584193",
  "text" : "What can I say about this weekend??? Complete waste of fucking time... In saying that I am going to water my roses and go for a walk.. #yeah",
  "id" : 353963370648584193,
  "created_at" : "2013-07-07 19:46:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353935731258949634",
  "text" : "Venturing outside for the first time today\u2026. Fucking fuck fuck\u2026",
  "id" : 353935731258949634,
  "created_at" : "2013-07-07 17:57:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353834907421786113",
  "text" : "Right.... a few hours work then the Wimbeldon final I think... first - gotta go get me car! - now to remember where I left it!!!",
  "id" : 353834907421786113,
  "created_at" : "2013-07-07 11:16:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353347105001177092",
  "geo" : { },
  "id_str" : "353413196381569024",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl congrats :)",
  "id" : 353413196381569024,
  "in_reply_to_status_id" : 353347105001177092,
  "created_at" : "2013-07-06 07:20:46 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/353148938431385600\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/3lEksxEc41",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOajFqRCUAAzD5k.png",
      "id_str" : "353148938435579904",
      "id" : 353148938435579904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOajFqRCUAAzD5k.png",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 830
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 830
      }, {
        "h" : 289,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3lEksxEc41"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353148938431385600",
  "text" : "Just. Be. Fucking. Cause. http:\/\/t.co\/3lEksxEc41",
  "id" : 353148938431385600,
  "created_at" : "2013-07-05 13:50:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353101060413464577",
  "text" : "Fuck you Friday it is then.",
  "id" : 353101060413464577,
  "created_at" : "2013-07-05 10:40:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nocar",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352421098853380096",
  "text" : "Working from home isn't really the best thing to do - but an episode of \"Ron Swanson\" and a quick stir fry make up for it I guess. #nocar",
  "id" : 352421098853380096,
  "created_at" : "2013-07-03 13:38:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352132897706221568",
  "geo" : { },
  "id_str" : "352133006904930305",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe that repo was only created last Thursday ;)",
  "id" : 352133006904930305,
  "in_reply_to_status_id" : 352132897706221568,
  "created_at" : "2013-07-02 18:33:45 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/352130041947254784\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/PABRLkleJz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOMEaFGCcAAgDyH.png",
      "id_str" : "352130041955643392",
      "id" : 352130041955643392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOMEaFGCcAAgDyH.png",
      "sizes" : [ {
        "h" : 30,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 17,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 44,
        "resize" : "fit",
        "w" : 882
      }, {
        "h" : 44,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 44,
        "resize" : "fit",
        "w" : 882
      } ],
      "display_url" : "pic.twitter.com\/PABRLkleJz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352130041947254784",
  "text" : "Hmmmmmmmmm :) http:\/\/t.co\/PABRLkleJz",
  "id" : 352130041947254784,
  "created_at" : "2013-07-02 18:21:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susanna Reid",
      "screen_name" : "susannareid100",
      "indices" : [ 0, 15 ],
      "id_str" : "19477583",
      "id" : 19477583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351770773599436801",
  "geo" : { },
  "id_str" : "351773301565177856",
  "in_reply_to_user_id" : 19477583,
  "text" : "@susannareid100 was never the plan... It had fallen in the ratings too much and was too expensive to maintain.",
  "id" : 351773301565177856,
  "in_reply_to_status_id" : 351770773599436801,
  "created_at" : "2013-07-01 18:44:25 +0000",
  "in_reply_to_screen_name" : "susannareid100",
  "in_reply_to_user_id_str" : "19477583",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/351702417513009152\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/MurRQwNMuq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOF_fD8CUAAy5Cs.png",
      "id_str" : "351702417521397760",
      "id" : 351702417521397760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOF_fD8CUAAy5Cs.png",
      "sizes" : [ {
        "h" : 29,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 29,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 29,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 17,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 29,
        "resize" : "fit",
        "w" : 580
      } ],
      "display_url" : "pic.twitter.com\/MurRQwNMuq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351702417513009152",
  "text" : "Brilliant :) I can just about remember writing this :) http:\/\/t.co\/MurRQwNMuq",
  "id" : 351702417513009152,
  "created_at" : "2013-07-01 14:02:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351669610099113985",
  "geo" : { },
  "id_str" : "351673942676742144",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo :D :D :D Not even going to explain but that's *my* iPad and you can go fuck yourself for checking the app on it now :)",
  "id" : 351673942676742144,
  "in_reply_to_status_id" : 351669610099113985,
  "created_at" : "2013-07-01 12:09:36 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]