Grailbird.data.tweets_2013_10 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/zUNa3NIjal",
      "expanded_url" : "http:\/\/4sq.com\/15TzMTI",
      "display_url" : "4sq.com\/15TzMTI"
    } ]
  },
  "geo" : { },
  "id_str" : "391826841130237952",
  "text" : "I'm at Glenavy Village http:\/\/t.co\/zUNa3NIjal",
  "id" : 391826841130237952,
  "created_at" : "2013-10-20 07:22:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 8, 17 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391635175895216128",
  "geo" : { },
  "id_str" : "391636271413477376",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @vduglued will do - thanks sexy :D",
  "id" : 391636271413477376,
  "in_reply_to_status_id" : 391635175895216128,
  "created_at" : "2013-10-19 18:45:38 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 96, 105 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391629614327812096",
  "geo" : { },
  "id_str" : "391630339686137856",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl give me names and an address, I will do the needful. Also what is that channel you told @vduglued about - for tee-vee shows.",
  "id" : 391630339686137856,
  "in_reply_to_status_id" : 391629614327812096,
  "created_at" : "2013-10-19 18:22:03 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391623184896000001",
  "geo" : { },
  "id_str" : "391627637853941760",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl no no no..... you are doing it all wrong!!!",
  "id" : 391627637853941760,
  "in_reply_to_status_id" : 391623184896000001,
  "created_at" : "2013-10-19 18:11:19 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/QAlFoIdT10",
      "expanded_url" : "http:\/\/4sq.com\/18vgEMJ",
      "display_url" : "4sq.com\/18vgEMJ"
    } ]
  },
  "geo" : { },
  "id_str" : "391481375368679424",
  "text" : "I'm at Glenavy Village http:\/\/t.co\/QAlFoIdT10",
  "id" : 391481375368679424,
  "created_at" : "2013-10-19 08:30:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/6ZgVCJxfQa",
      "expanded_url" : "http:\/\/4sq.com\/1d2GuLv",
      "display_url" : "4sq.com\/1d2GuLv"
    } ]
  },
  "geo" : { },
  "id_str" : "391209643642748928",
  "text" : "I'm at Donegall Square West (Belfast, Antrim) http:\/\/t.co\/6ZgVCJxfQa",
  "id" : 391209643642748928,
  "created_at" : "2013-10-18 14:30:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391199163578609664",
  "geo" : { },
  "id_str" : "391201381542928385",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe did you finally upgrade it? :) I fought for a long while but had to give up after ios7.",
  "id" : 391201381542928385,
  "in_reply_to_status_id" : 391199163578609664,
  "created_at" : "2013-10-18 13:57:32 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391195837004394496",
  "text" : "Old 3gs phone is now a glorified iPod. Sad to see it go :( In other news upgrading a macbook in RAM is a balls. Need a small screw ;)",
  "id" : 391195837004394496,
  "created_at" : "2013-10-18 13:35:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390851868546433025",
  "text" : "Ringing up Lisburn City Council there to report a wasps nest - they put through to the marketing department... &lt;sigh&gt;",
  "id" : 390851868546433025,
  "created_at" : "2013-10-17 14:48:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Milne",
      "screen_name" : "_alexmilne",
      "indices" : [ 0, 11 ],
      "id_str" : "219325105",
      "id" : 219325105
    }, {
      "name" : "Aaron Gilmore",
      "screen_name" : "aarondgilmore",
      "indices" : [ 12, 26 ],
      "id_str" : "17119165",
      "id" : 17119165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390810395424063488",
  "geo" : { },
  "id_str" : "390811437792112640",
  "in_reply_to_user_id" : 219325105,
  "text" : "@_alexmilne @aarondgilmore it is a slow burner but keep with it.",
  "id" : 390811437792112640,
  "in_reply_to_status_id" : 390810395424063488,
  "created_at" : "2013-10-17 12:08:02 +0000",
  "in_reply_to_screen_name" : "_alexmilne",
  "in_reply_to_user_id_str" : "219325105",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Milne",
      "screen_name" : "_alexmilne",
      "indices" : [ 0, 11 ],
      "id_str" : "219325105",
      "id" : 219325105
    }, {
      "name" : "Netflix US",
      "screen_name" : "netflix",
      "indices" : [ 35, 43 ],
      "id_str" : "16573941",
      "id" : 16573941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390808399103135744",
  "geo" : { },
  "id_str" : "390809218896252929",
  "in_reply_to_user_id" : 219325105,
  "text" : "@_alexmilne it is all available on @netflix - you are in for a treat.",
  "id" : 390809218896252929,
  "in_reply_to_status_id" : 390808399103135744,
  "created_at" : "2013-10-17 11:59:13 +0000",
  "in_reply_to_screen_name" : "_alexmilne",
  "in_reply_to_user_id_str" : "219325105",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AngularJS",
      "screen_name" : "angularjs",
      "indices" : [ 4, 14 ],
      "id_str" : "202230373",
      "id" : 202230373
    }, {
      "name" : "Yeoman",
      "screen_name" : "yeoman",
      "indices" : [ 42, 49 ],
      "id_str" : "588938505",
      "id" : 588938505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Y4OpFplzT9",
      "expanded_url" : "https:\/\/github.com\/swmcc\/todo",
      "display_url" : "github.com\/swmcc\/todo"
    } ]
  },
  "geo" : { },
  "id_str" : "390807929311350785",
  "text" : "Wee @angularjs app written with help from @yeoman that I use for todo's - more work needed but a nice start - https:\/\/t.co\/Y4OpFplzT9",
  "id" : 390807929311350785,
  "created_at" : "2013-10-17 11:54:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 13, 20 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 22, 31 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 33, 41 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 46, 58 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 62, 72 ],
      "id_str" : "240194412",
      "id" : 240194412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurefifty",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390753069064929280",
  "text" : "Well done to @rejoco, @davehedo, @jbrevel and @DebbieCReid on @repknight getting into the #futurefifty",
  "id" : 390753069064929280,
  "created_at" : "2013-10-17 08:16:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 3, 13 ],
      "id_str" : "240194412",
      "id" : 240194412
    }, {
      "name" : "Financial Times",
      "screen_name" : "FT",
      "indices" : [ 59, 62 ],
      "id_str" : "18949452",
      "id" : 18949452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureFifty",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/z7V4KqHFeQ",
      "expanded_url" : "http:\/\/on.ft.com\/H2J7jx",
      "display_url" : "on.ft.com\/H2J7jx"
    } ]
  },
  "geo" : { },
  "id_str" : "390752507095683072",
  "text" : "RT @RepKnight: Flying the flag for Northern Ireland in the @FT this morning with a wee mention http:\/\/t.co\/z7V4KqHFeQ #FutureFifty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/app.repknight.com\" rel=\"nofollow\"\u003ERepKnight\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Financial Times",
        "screen_name" : "FT",
        "indices" : [ 44, 47 ],
        "id_str" : "18949452",
        "id" : 18949452
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FutureFifty",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/z7V4KqHFeQ",
        "expanded_url" : "http:\/\/on.ft.com\/H2J7jx",
        "display_url" : "on.ft.com\/H2J7jx"
      } ]
    },
    "geo" : { },
    "id_str" : "390751540048564224",
    "text" : "Flying the flag for Northern Ireland in the @FT this morning with a wee mention http:\/\/t.co\/z7V4KqHFeQ #FutureFifty",
    "id" : 390751540048564224,
    "created_at" : "2013-10-17 08:10:01 +0000",
    "user" : {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "protected" : false,
      "id_str" : "240194412",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1241221112\/repknight_avatar_twitter_normal.jpg",
      "id" : 240194412,
      "verified" : false
    }
  },
  "id" : 390752507095683072,
  "created_at" : "2013-10-17 08:13:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 0, 10 ],
      "id_str" : "7311162",
      "id" : 7311162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390540425267650560",
  "geo" : { },
  "id_str" : "390541512175779840",
  "in_reply_to_user_id" : 7311162,
  "text" : "@mharrigan nah not for me. I love it. Best thing I\u2019ve ever bought, ever!",
  "id" : 390541512175779840,
  "in_reply_to_status_id" : 390540425267650560,
  "created_at" : "2013-10-16 18:15:27 +0000",
  "in_reply_to_screen_name" : "mharrigan",
  "in_reply_to_user_id_str" : "7311162",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 38, 50 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/RVTBj698GV",
      "expanded_url" : "https:\/\/speakerdeck.com\/swmcc\/tmux-lightning-talk-at-belfastruby",
      "display_url" : "speakerdeck.com\/swmcc\/tmux-lig\u2026"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/kAjvOau0Ro",
      "expanded_url" : "http:\/\/tmux-lightning.talks.swm.cc\/",
      "display_url" : "tmux-lightning.talks.swm.cc"
    } ]
  },
  "geo" : { },
  "id_str" : "390460792203517952",
  "text" : "My lightning talk (such as it was) to @BelfastRuby on Tmux - https:\/\/t.co\/RVTBj698GV and http:\/\/t.co\/kAjvOau0Ro",
  "id" : 390460792203517952,
  "created_at" : "2013-10-16 12:54:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/390446317371006976\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/WciktT4vVW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWsk21iCEAE6j60.png",
      "id_str" : "390446317199036417",
      "id" : 390446317199036417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWsk21iCEAE6j60.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/WciktT4vVW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390446317371006976",
  "text" : "Sympathy! http:\/\/t.co\/WciktT4vVW",
  "id" : 390446317371006976,
  "created_at" : "2013-10-16 11:57:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/390445257860472833\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/TDtRNkEDjg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWsj5K7CMAAHa6x.jpg",
      "id_str" : "390445257789157376",
      "id" : 390445257789157376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWsj5K7CMAAHa6x.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/TDtRNkEDjg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390445257860472833",
  "text" : "Luck..... http:\/\/t.co\/TDtRNkEDjg",
  "id" : 390445257860472833,
  "created_at" : "2013-10-16 11:52:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390426818974457856",
  "text" : "So my iPhone 5S has arrived... Will be said to say goodbye to my 3S - it has served me well coming up on four years - it was retro!",
  "id" : 390426818974457856,
  "created_at" : "2013-10-16 10:39:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 0, 8 ],
      "id_str" : "15966431",
      "id" : 15966431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390425908479143936",
  "geo" : { },
  "id_str" : "390426269675843584",
  "in_reply_to_user_id" : 15966431,
  "text" : "@cobyism Oh I will. Hooked up two apps to it and hopefully hooking up a wee app this lunchtime. Thanks for this :)",
  "id" : 390426269675843584,
  "in_reply_to_status_id" : 390425908479143936,
  "created_at" : "2013-10-16 10:37:31 +0000",
  "in_reply_to_screen_name" : "cobyism",
  "in_reply_to_user_id_str" : "15966431",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 0, 8 ],
      "id_str" : "15966431",
      "id" : 15966431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390415708326481920",
  "geo" : { },
  "id_str" : "390425486502797312",
  "in_reply_to_user_id" : 15966431,
  "text" : "@cobyism I've started to use this for my own stuff. Been too busy to tweet\/blog about it. I like it :) Should contrib something to it soon.",
  "id" : 390425486502797312,
  "in_reply_to_status_id" : 390415708326481920,
  "created_at" : "2013-10-16 10:34:24 +0000",
  "in_reply_to_screen_name" : "cobyism",
  "in_reply_to_user_id_str" : "15966431",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 3, 11 ],
      "id_str" : "15966431",
      "id" : 15966431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/3Mn3IBcYvE",
      "expanded_url" : "https:\/\/github.com\/cobyism\/dciy",
      "display_url" : "github.com\/cobyism\/dciy"
    } ]
  },
  "geo" : { },
  "id_str" : "390425334321274880",
  "text" : "RT @cobyism: Just open sourced a side-project I\u2019ve been hacking on for fun. DCIY: Do Continuous Integration Yourself https:\/\/t.co\/3Mn3IBcYvE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/3Mn3IBcYvE",
        "expanded_url" : "https:\/\/github.com\/cobyism\/dciy",
        "display_url" : "github.com\/cobyism\/dciy"
      } ]
    },
    "geo" : { },
    "id_str" : "390415708326481920",
    "text" : "Just open sourced a side-project I\u2019ve been hacking on for fun. DCIY: Do Continuous Integration Yourself https:\/\/t.co\/3Mn3IBcYvE",
    "id" : 390415708326481920,
    "created_at" : "2013-10-16 09:55:33 +0000",
    "user" : {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "protected" : false,
      "id_str" : "15966431",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3123946980\/3cc09be313449aec5cd1f0eed2865cad_normal.jpeg",
      "id" : 15966431,
      "verified" : false
    }
  },
  "id" : 390425334321274880,
  "created_at" : "2013-10-16 10:33:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 0, 10 ],
      "id_str" : "7311162",
      "id" : 7311162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390397432804421632",
  "geo" : { },
  "id_str" : "390408975398617088",
  "in_reply_to_user_id" : 7311162,
  "text" : "@mharrigan but its just a phone. The iPad mini is an amazing device though - I love it.",
  "id" : 390408975398617088,
  "in_reply_to_status_id" : 390397432804421632,
  "created_at" : "2013-10-16 09:28:47 +0000",
  "in_reply_to_screen_name" : "mharrigan",
  "in_reply_to_user_id_str" : "7311162",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390394440679837697",
  "text" : "So I should be getting my iPhone 5S today or tomorrow. Feel dirty.... Am an apple slave this weather and it doesn't feel good.",
  "id" : 390394440679837697,
  "created_at" : "2013-10-16 08:31:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 3, 10 ],
      "id_str" : "17843859",
      "id" : 17843859
    }, {
      "name" : "InterSystems Corp",
      "screen_name" : "InterSystems",
      "indices" : [ 19, 32 ],
      "id_str" : "74499421",
      "id" : 74499421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390371396125462528",
  "text" : "RT @rtweed: At the @intersystems UK Symposium today. Setting up the M\/Gateway booth very soon. We're showing EWD Lite this year - 100% Java\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "InterSystems Corp",
        "screen_name" : "InterSystems",
        "indices" : [ 7, 20 ],
        "id_str" : "74499421",
        "id" : 74499421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "390370270177157120",
    "text" : "At the @intersystems UK Symposium today. Setting up the M\/Gateway booth very soon. We're showing EWD Lite this year - 100% JavaScript",
    "id" : 390370270177157120,
    "created_at" : "2013-10-16 06:54:59 +0000",
    "user" : {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "protected" : false,
      "id_str" : "17843859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1398354510\/me_normal.png",
      "id" : 17843859,
      "verified" : false
    }
  },
  "id" : 390371396125462528,
  "created_at" : "2013-10-16 06:59:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 1, 11 ],
      "id_str" : "74286565",
      "id" : 74286565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390135703721365504",
  "text" : ".@microsoft - you make everything difficult. You suck donkey dick... You really really really do. I hope you get herpes you fuck wanks!!!",
  "id" : 390135703721365504,
  "created_at" : "2013-10-15 15:22:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390123749464231937",
  "text" : "I never ever want to set up a windows vm machine again. How do people use this shit day to day? Why make life\/work more difficult?",
  "id" : 390123749464231937,
  "created_at" : "2013-10-15 14:35:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "indices" : [ 0, 10 ],
      "id_str" : "1248789104",
      "id" : 1248789104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389674361151823872",
  "geo" : { },
  "id_str" : "389853602816475139",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@hadooping I was one when that came out ;)",
  "id" : 389853602816475139,
  "in_reply_to_status_id" : 389674361151823872,
  "created_at" : "2013-10-14 20:41:56 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rumble Labs",
      "screen_name" : "rumblelabs",
      "indices" : [ 3, 14 ],
      "id_str" : "20454184",
      "id" : 20454184
    }, {
      "name" : "SquareVid",
      "screen_name" : "squarevid",
      "indices" : [ 70, 80 ],
      "id_str" : "1676295949",
      "id" : 1676295949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/4tP4sH4pN7",
      "expanded_url" : "http:\/\/rumblelabs.com\/blog\/squarevid-our-first-iphone-app",
      "display_url" : "rumblelabs.com\/blog\/squarevid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389748253673390080",
  "text" : "RT @rumblelabs: Today we officially launch our first iPhone app! Meet @squarevid. Read more about it on our blog - http:\/\/t.co\/4tP4sH4pN7",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SquareVid",
        "screen_name" : "squarevid",
        "indices" : [ 54, 64 ],
        "id_str" : "1676295949",
        "id" : 1676295949
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/4tP4sH4pN7",
        "expanded_url" : "http:\/\/rumblelabs.com\/blog\/squarevid-our-first-iphone-app",
        "display_url" : "rumblelabs.com\/blog\/squarevid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "389716325934694400",
    "text" : "Today we officially launch our first iPhone app! Meet @squarevid. Read more about it on our blog - http:\/\/t.co\/4tP4sH4pN7",
    "id" : 389716325934694400,
    "created_at" : "2013-10-14 11:36:27 +0000",
    "user" : {
      "name" : "Rumble Labs",
      "screen_name" : "rumblelabs",
      "protected" : false,
      "id_str" : "20454184",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3220068899\/9b4724a520f2eb9250c0fa57c4b6d700_normal.png",
      "id" : 20454184,
      "verified" : false
    }
  },
  "id" : 389748253673390080,
  "created_at" : "2013-10-14 13:43:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "indices" : [ 0, 10 ],
      "id_str" : "1248789104",
      "id" : 1248789104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389355863871606784",
  "geo" : { },
  "id_str" : "389673151027609600",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@hadooping I don't know what that means :)",
  "id" : 389673151027609600,
  "in_reply_to_status_id" : 389355863871606784,
  "created_at" : "2013-10-14 08:44:53 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389353831815200768",
  "text" : "I have no kitchen\u2026 It kinda sucks dick (if you don\u2019t like to suck dick). Off to Ballinderry it is\u2026.",
  "id" : 389353831815200768,
  "created_at" : "2013-10-13 11:36:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388823093277241344",
  "geo" : { },
  "id_str" : "389119681686413312",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist any news?",
  "id" : 389119681686413312,
  "in_reply_to_status_id" : 388823093277241344,
  "created_at" : "2013-10-12 20:05:36 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388822667677007872",
  "geo" : { },
  "id_str" : "388822891837415425",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist awww shit one dude. hope he turns up :( really do...",
  "id" : 388822891837415425,
  "in_reply_to_status_id" : 388822667677007872,
  "created_at" : "2013-10-12 00:26:16 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388720006202413056",
  "geo" : { },
  "id_str" : "388737521942683648",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl no sir :) Just moved offices from Bedford Street. In the last six weeks I've had five desks so just looking to settle :)",
  "id" : 388737521942683648,
  "in_reply_to_status_id" : 388720006202413056,
  "created_at" : "2013-10-11 18:47:02 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 3, 12 ],
      "id_str" : "223516339",
      "id" : 223516339
    }, {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 14, 26 ],
      "id_str" : "456868224",
      "id" : 456868224
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 35, 41 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388637960062902272",
  "text" : "RT @vduglued: @angryjogger We took @swmcc into M&amp;S and got him lost in the women\u2019s clothing department.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angry Jogger",
        "screen_name" : "angryjogger",
        "indices" : [ 0, 12 ],
        "id_str" : "456868224",
        "id" : 456868224
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 21, 27 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "388633834344169472",
    "geo" : { },
    "id_str" : "388635932137889792",
    "in_reply_to_user_id" : 456868224,
    "text" : "@angryjogger We took @swmcc into M&amp;S and got him lost in the women\u2019s clothing department.",
    "id" : 388635932137889792,
    "in_reply_to_status_id" : 388633834344169472,
    "created_at" : "2013-10-11 12:03:21 +0000",
    "in_reply_to_screen_name" : "angryjogger",
    "in_reply_to_user_id_str" : "456868224",
    "user" : {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "protected" : false,
      "id_str" : "223516339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2931351714\/6425a1a841a3325f3e832c228ad8ba1d_normal.jpeg",
      "id" : 223516339,
      "verified" : false
    }
  },
  "id" : 388637960062902272,
  "created_at" : "2013-10-11 12:11:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388598553368854528",
  "geo" : { },
  "id_str" : "388600557067202560",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit sure I'll buy you a coffee and a bun tomorrow so stop yapping :)",
  "id" : 388600557067202560,
  "in_reply_to_status_id" : 388598553368854528,
  "created_at" : "2013-10-11 09:42:47 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 36, 45 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388594546222723072",
  "text" : "Worst cup of tea maker ever goes to @vduglued but I wont give in.... I will drink it all.",
  "id" : 388594546222723072,
  "created_at" : "2013-10-11 09:18:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McClelland",
      "screen_name" : "chrismcclelland",
      "indices" : [ 3, 19 ],
      "id_str" : "12952252",
      "id" : 12952252
    }, {
      "name" : "Brewbot",
      "screen_name" : "brewbot",
      "indices" : [ 54, 62 ],
      "id_str" : "1510539890",
      "id" : 1510539890
    }, {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "indices" : [ 95, 108 ],
      "id_str" : "19658826",
      "id" : 19658826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388576229433303040",
  "text" : "RT @chrismcclelland: Not sure where else this can go! @brewbot will be featured in this week's @newscientist magazine. Page 21. Wow.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brewbot",
        "screen_name" : "brewbot",
        "indices" : [ 33, 41 ],
        "id_str" : "1510539890",
        "id" : 1510539890
      }, {
        "name" : "New Scientist",
        "screen_name" : "newscientist",
        "indices" : [ 74, 87 ],
        "id_str" : "19658826",
        "id" : 19658826
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388575079937744896",
    "text" : "Not sure where else this can go! @brewbot will be featured in this week's @newscientist magazine. Page 21. Wow.",
    "id" : 388575079937744896,
    "created_at" : "2013-10-11 08:01:33 +0000",
    "user" : {
      "name" : "Chris McClelland",
      "screen_name" : "chrismcclelland",
      "protected" : false,
      "id_str" : "12952252",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000411737143\/9dd59aa3ec33c2de2b06f504a96e6709_normal.jpeg",
      "id" : 12952252,
      "verified" : false
    }
  },
  "id" : 388576229433303040,
  "created_at" : "2013-10-11 08:06:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388574707433230336",
  "text" : "Finally at my new desk in the new office in Donegal House... After six weeks I finally have a desk again - I better not move again! :)",
  "id" : 388574707433230336,
  "created_at" : "2013-10-11 08:00:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 3, 12 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 14, 21 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 86, 92 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388316758454837249",
  "text" : "RT @davehedo: @rejoco You're a hallion JR! Would have expected the likes of that from @swmcc ;-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Reid",
        "screen_name" : "rejoco",
        "indices" : [ 0, 7 ],
        "id_str" : "53053999",
        "id" : 53053999
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 72, 78 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "388312337385787392",
    "geo" : { },
    "id_str" : "388313599330230272",
    "in_reply_to_user_id" : 53053999,
    "text" : "@rejoco You're a hallion JR! Would have expected the likes of that from @swmcc ;-)",
    "id" : 388313599330230272,
    "in_reply_to_status_id" : 388312337385787392,
    "created_at" : "2013-10-10 14:42:31 +0000",
    "in_reply_to_screen_name" : "rejoco",
    "in_reply_to_user_id_str" : "53053999",
    "user" : {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "protected" : false,
      "id_str" : "50985598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000509606650\/9ac4420064b46da165a3e180e20ef133_normal.jpeg",
      "id" : 50985598,
      "verified" : false
    }
  },
  "id" : 388316758454837249,
  "created_at" : "2013-10-10 14:55:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PierceCommunications",
      "screen_name" : "PierceComms",
      "indices" : [ 3, 15 ],
      "id_str" : "140049267",
      "id" : 140049267
    }, {
      "name" : "Barry Adams",
      "screen_name" : "badams",
      "indices" : [ 38, 45 ],
      "id_str" : "10704902",
      "id" : 10704902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/hR9vMPGHQp",
      "expanded_url" : "http:\/\/www.searchawards.co.uk\/content\/information\/shortlist",
      "display_url" : "searchawards.co.uk\/content\/inform\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388275352294150145",
  "text" : "RT @PierceComms: Our Digital Director @badams personal blog is shortlisted for UK Search Awards Best Blog - http:\/\/t.co\/hR9vMPGHQp Good luc\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barry Adams",
        "screen_name" : "badams",
        "indices" : [ 21, 28 ],
        "id_str" : "10704902",
        "id" : 10704902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/hR9vMPGHQp",
        "expanded_url" : "http:\/\/www.searchawards.co.uk\/content\/information\/shortlist",
        "display_url" : "searchawards.co.uk\/content\/inform\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388259471828320256",
    "text" : "Our Digital Director @badams personal blog is shortlisted for UK Search Awards Best Blog - http:\/\/t.co\/hR9vMPGHQp Good luck Barry :-)",
    "id" : 388259471828320256,
    "created_at" : "2013-10-10 11:07:26 +0000",
    "user" : {
      "name" : "PierceCommunications",
      "screen_name" : "PierceComms",
      "protected" : false,
      "id_str" : "140049267",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1650354632\/piercep_normal.gif",
      "id" : 140049267,
      "verified" : false
    }
  },
  "id" : 388275352294150145,
  "created_at" : "2013-10-10 12:10:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 8, 19 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388067965004169216",
  "geo" : { },
  "id_str" : "388069229347348480",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @johngirvin I lasted 2mins... I take this as a good thing.",
  "id" : 388069229347348480,
  "in_reply_to_status_id" : 388067965004169216,
  "created_at" : "2013-10-09 22:31:28 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ewing",
      "screen_name" : "brianjewing",
      "indices" : [ 0, 12 ],
      "id_str" : "328097214",
      "id" : 328097214
    }, {
      "name" : "Toby Osbourn",
      "screen_name" : "tosbourn",
      "indices" : [ 13, 22 ],
      "id_str" : "17601064",
      "id" : 17601064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387989113682796545",
  "geo" : { },
  "id_str" : "387992991597473792",
  "in_reply_to_user_id" : 328097214,
  "text" : "@brianjewing @tosbourn really is it not an xml editor IIRC? I am probably wrong.",
  "id" : 387992991597473792,
  "in_reply_to_status_id" : 387989113682796545,
  "created_at" : "2013-10-09 17:28:32 +0000",
  "in_reply_to_screen_name" : "brianjewing",
  "in_reply_to_user_id_str" : "328097214",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toby Osbourn",
      "screen_name" : "tosbourn",
      "indices" : [ 0, 9 ],
      "id_str" : "17601064",
      "id" : 17601064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387928655260700672",
  "geo" : { },
  "id_str" : "387987968134098944",
  "in_reply_to_user_id" : 17601064,
  "text" : "@tosbourn CONFESSION TIME: If you use an IDE then I just look down on you blatantly :)",
  "id" : 387987968134098944,
  "in_reply_to_status_id" : 387928655260700672,
  "created_at" : "2013-10-09 17:08:34 +0000",
  "in_reply_to_screen_name" : "tosbourn",
  "in_reply_to_user_id_str" : "17601064",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387518375775457280",
  "geo" : { },
  "id_str" : "387518818912047104",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo I\u2019ll shove a filth monitor on it then, just for you ya sexy fuck ye!!!!! Xxxxxxxxxxx",
  "id" : 387518818912047104,
  "in_reply_to_status_id" : 387518375775457280,
  "created_at" : "2013-10-08 10:04:20 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Keizer",
      "screen_name" : "KeizGoesBoom",
      "indices" : [ 0, 13 ],
      "id_str" : "81934123",
      "id" : 81934123
    }, {
      "name" : "Michael Bole",
      "screen_name" : "MichaelBole",
      "indices" : [ 14, 26 ],
      "id_str" : "197615538",
      "id" : 197615538
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wassogoingtodoit",
      "indices" : [ 98, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387517869648797696",
  "geo" : { },
  "id_str" : "387518153040728065",
  "in_reply_to_user_id" : 81934123,
  "text" : "@KeizGoesBoom @MichaelBole Nah I wouldn't want that... Michael you are lucky your Mrs said no! :) #wassogoingtodoit",
  "id" : 387518153040728065,
  "in_reply_to_status_id" : 387517869648797696,
  "created_at" : "2013-10-08 10:01:42 +0000",
  "in_reply_to_screen_name" : "KeizGoesBoom",
  "in_reply_to_user_id_str" : "81934123",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Keizer",
      "screen_name" : "KeizGoesBoom",
      "indices" : [ 0, 13 ],
      "id_str" : "81934123",
      "id" : 81934123
    }, {
      "name" : "Michael Bole",
      "screen_name" : "MichaelBole",
      "indices" : [ 14, 26 ],
      "id_str" : "197615538",
      "id" : 197615538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387516891574857729",
  "geo" : { },
  "id_str" : "387517124563841024",
  "in_reply_to_user_id" : 81934123,
  "text" : "@KeizGoesBoom @MichaelBole awwww dammit - so I can't change it then?",
  "id" : 387517124563841024,
  "in_reply_to_status_id" : 387516891574857729,
  "created_at" : "2013-10-08 09:57:36 +0000",
  "in_reply_to_screen_name" : "KeizGoesBoom",
  "in_reply_to_user_id_str" : "81934123",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Keizer",
      "screen_name" : "KeizGoesBoom",
      "indices" : [ 0, 13 ],
      "id_str" : "81934123",
      "id" : 81934123
    }, {
      "name" : "Michael Bole",
      "screen_name" : "MichaelBole",
      "indices" : [ 14, 26 ],
      "id_str" : "197615538",
      "id" : 197615538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387514532727640064",
  "geo" : { },
  "id_str" : "387516037148594176",
  "in_reply_to_user_id" : 81934123,
  "text" : "@KeizGoesBoom @MichaelBole He hasn't got it as I'm WFH. He's logged into FB, would u mind if he wasin a civil partnership with me for a day?",
  "id" : 387516037148594176,
  "in_reply_to_status_id" : 387514532727640064,
  "created_at" : "2013-10-08 09:53:17 +0000",
  "in_reply_to_screen_name" : "KeizGoesBoom",
  "in_reply_to_user_id_str" : "81934123",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toby Osbourn",
      "screen_name" : "tosbourn",
      "indices" : [ 0, 9 ],
      "id_str" : "17601064",
      "id" : 17601064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387515327514279936",
  "geo" : { },
  "id_str" : "387515399132020736",
  "in_reply_to_user_id" : 17601064,
  "text" : "@tosbourn I forget about it half time to be honest.",
  "id" : 387515399132020736,
  "in_reply_to_status_id" : 387515327514279936,
  "created_at" : "2013-10-08 09:50:45 +0000",
  "in_reply_to_screen_name" : "tosbourn",
  "in_reply_to_user_id_str" : "17601064",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blogpost",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387510042020151296",
  "text" : "My 10,000th tweet. Guess I better roll out that twitter history now and do some analytics with it. Will at the weekend. #blogpost",
  "id" : 387510042020151296,
  "created_at" : "2013-10-08 09:29:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "indices" : [ 3, 13 ],
      "id_str" : "1248789104",
      "id" : 1248789104
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigData",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/4HlqzUEDFS",
      "expanded_url" : "http:\/\/wp.me\/p3bKqw-c3",
      "display_url" : "wp.me\/p3bKqw-c3"
    } ]
  },
  "geo" : { },
  "id_str" : "386830681219006465",
  "text" : "RT @hadooping: So you want to be a data scientist? #BigData http:\/\/t.co\/4HlqzUEDFS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigData",
        "indices" : [ 36, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/4HlqzUEDFS",
        "expanded_url" : "http:\/\/wp.me\/p3bKqw-c3",
        "display_url" : "wp.me\/p3bKqw-c3"
      } ]
    },
    "geo" : { },
    "id_str" : "386798914047066112",
    "text" : "So you want to be a data scientist? #BigData http:\/\/t.co\/4HlqzUEDFS",
    "id" : 386798914047066112,
    "created_at" : "2013-10-06 10:23:42 +0000",
    "user" : {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "protected" : false,
      "id_str" : "1248789104",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000600719719\/1f076e9f2650e4ea1930f33a7fbd28de_normal.jpeg",
      "id" : 1248789104,
      "verified" : false
    }
  },
  "id" : 386830681219006465,
  "created_at" : "2013-10-06 12:29:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 0, 9 ],
      "id_str" : "223516339",
      "id" : 223516339
    }, {
      "name" : "Michael Bole",
      "screen_name" : "MichaelBole",
      "indices" : [ 10, 22 ],
      "id_str" : "197615538",
      "id" : 197615538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386503060056711168",
  "geo" : { },
  "id_str" : "386567195938922496",
  "in_reply_to_user_id" : 223516339,
  "text" : "@vduglued @MichaelBole &lt;Gollum&gt;You don't have any friends!&lt;\/Gollum&gt;",
  "id" : 386567195938922496,
  "in_reply_to_status_id" : 386503060056711168,
  "created_at" : "2013-10-05 19:02:56 +0000",
  "in_reply_to_screen_name" : "vduglued",
  "in_reply_to_user_id_str" : "223516339",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386030752556912641",
  "geo" : { },
  "id_str" : "386039021878521856",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger learn to drive you hippy",
  "id" : 386039021878521856,
  "in_reply_to_status_id" : 386030752556912641,
  "created_at" : "2013-10-04 08:04:09 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/385693964763820032\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/klx6vJAMoj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVpCnhICcAACv5u.png",
      "id_str" : "385693964768014336",
      "id" : 385693964768014336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVpCnhICcAACv5u.png",
      "sizes" : [ {
        "h" : 19,
        "resize" : "fit",
        "w" : 951
      }, {
        "h" : 12,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 7,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 19,
        "resize" : "fit",
        "w" : 951
      }, {
        "h" : 19,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/klx6vJAMoj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385693964763820032",
  "text" : "Achievement unlocked.... http:\/\/t.co\/klx6vJAMoj",
  "id" : 385693964763820032,
  "created_at" : "2013-10-03 09:13:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toby Osbourn",
      "screen_name" : "tosbourn",
      "indices" : [ 3, 12 ],
      "id_str" : "17601064",
      "id" : 17601064
    }, {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 42, 51 ],
      "id_str" : "729883",
      "id" : 729883
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 52, 58 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 63, 71 ],
      "id_str" : "15966431",
      "id" : 15966431
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 83, 95 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Jj3XSj5ock",
      "expanded_url" : "http:\/\/tosbourn.com\/2013\/10\/ruby\/belfast-ruby-talks-on-elixir-tmux-and-jekyll\/",
      "display_url" : "tosbourn.com\/2013\/10\/ruby\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385361495334211584",
  "text" : "RT @tosbourn: Some great talks tonight by @chrismcg @swmcc and @cobyism as part of @BelfastRuby - here is my writeup: http:\/\/t.co\/Jj3XSj5ock",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris McGrath",
        "screen_name" : "chrismcg",
        "indices" : [ 28, 37 ],
        "id_str" : "729883",
        "id" : 729883
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 38, 44 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Coby Chapple",
        "screen_name" : "cobyism",
        "indices" : [ 49, 57 ],
        "id_str" : "15966431",
        "id" : 15966431
      }, {
        "name" : "Belfast Ruby",
        "screen_name" : "BelfastRuby",
        "indices" : [ 69, 81 ],
        "id_str" : "454835425",
        "id" : 454835425
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/Jj3XSj5ock",
        "expanded_url" : "http:\/\/tosbourn.com\/2013\/10\/ruby\/belfast-ruby-talks-on-elixir-tmux-and-jekyll\/",
        "display_url" : "tosbourn.com\/2013\/10\/ruby\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385175654037069824",
    "text" : "Some great talks tonight by @chrismcg @swmcc and @cobyism as part of @BelfastRuby - here is my writeup: http:\/\/t.co\/Jj3XSj5ock",
    "id" : 385175654037069824,
    "created_at" : "2013-10-01 22:53:26 +0000",
    "user" : {
      "name" : "Toby Osbourn",
      "screen_name" : "tosbourn",
      "protected" : false,
      "id_str" : "17601064",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2168096713\/toby_osbourn_new_normal.jpg",
      "id" : 17601064,
      "verified" : false
    }
  },
  "id" : 385361495334211584,
  "created_at" : "2013-10-02 11:11:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toby Osbourn",
      "screen_name" : "tosbourn",
      "indices" : [ 0, 9 ],
      "id_str" : "17601064",
      "id" : 17601064
    }, {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 10, 19 ],
      "id_str" : "729883",
      "id" : 729883
    }, {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 20, 28 ],
      "id_str" : "15966431",
      "id" : 15966431
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 29, 41 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385175654037069824",
  "geo" : { },
  "id_str" : "385361457736454144",
  "in_reply_to_user_id" : 17601064,
  "text" : "@tosbourn @chrismcg @cobyism @BelfastRuby thanks for the writeup Toby :)",
  "id" : 385361457736454144,
  "in_reply_to_status_id" : 385175654037069824,
  "created_at" : "2013-10-02 11:11:45 +0000",
  "in_reply_to_screen_name" : "tosbourn",
  "in_reply_to_user_id_str" : "17601064",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Mitchell",
      "screen_name" : "pixelpage",
      "indices" : [ 0, 10 ],
      "id_str" : "52710181",
      "id" : 52710181
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 11, 23 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385086163855224833",
  "geo" : { },
  "id_str" : "385088527265824768",
  "in_reply_to_user_id" : 52710181,
  "text" : "@pixelpage @BelfastRuby better be. else me and a few others will be talking to an empty room :)",
  "id" : 385088527265824768,
  "in_reply_to_status_id" : 385086163855224833,
  "created_at" : "2013-10-01 17:07:14 +0000",
  "in_reply_to_screen_name" : "pixelpage",
  "in_reply_to_user_id_str" : "52710181",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Bole",
      "screen_name" : "MichaelBole",
      "indices" : [ 24, 36 ],
      "id_str" : "197615538",
      "id" : 197615538
    }, {
      "name" : "Aaron Pollock",
      "screen_name" : "vduglued",
      "indices" : [ 115, 124 ],
      "id_str" : "223516339",
      "id" : 223516339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385072327425142784",
  "text" : "Things I learnt today - @MichaelBole gets annoyed if you call him a hipster - but its okay to call him a 'c' &amp; @vduglued is a sneaky fuck!",
  "id" : 385072327425142784,
  "created_at" : "2013-10-01 16:02:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 3, 15 ],
      "id_str" : "454835425",
      "id" : 454835425
    }, {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 92, 101 ],
      "id_str" : "729883",
      "id" : 729883
    }, {
      "name" : "Coby Chapple",
      "screen_name" : "cobyism",
      "indices" : [ 114, 122 ],
      "id_str" : "15966431",
      "id" : 15966431
    }, {
      "name" : "Steve BALLmerING",
      "screen_name" : "swm",
      "indices" : [ 135, 139 ],
      "id_str" : "1716281",
      "id" : 1716281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385010492634198016",
  "text" : "RT @BelfastRuby: Belfast Ruby meetup tonight.  So far we have lightening talks on Elixir by @chrismcg, Jeckyll by @cobyism and tmux by @swm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris McGrath",
        "screen_name" : "chrismcg",
        "indices" : [ 75, 84 ],
        "id_str" : "729883",
        "id" : 729883
      }, {
        "name" : "Coby Chapple",
        "screen_name" : "cobyism",
        "indices" : [ 97, 105 ],
        "id_str" : "15966431",
        "id" : 15966431
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 118, 124 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384986448942088192",
    "text" : "Belfast Ruby meetup tonight.  So far we have lightening talks on Elixir by @chrismcg, Jeckyll by @cobyism and tmux by @swmcc.  We want more!",
    "id" : 384986448942088192,
    "created_at" : "2013-10-01 10:21:36 +0000",
    "user" : {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "protected" : false,
      "id_str" : "454835425",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1752070239\/belfastruby-twitter-icon-2_normal.png",
      "id" : 454835425,
      "verified" : false
    }
  },
  "id" : 385010492634198016,
  "created_at" : "2013-10-01 11:57:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]