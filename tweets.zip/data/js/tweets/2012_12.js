Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285780897960165377",
  "text" : "Bob Deniro wearing a corset!!! WTAF!!!",
  "id" : 285780897960165377,
  "created_at" : "2012-12-31 16:14:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science London",
      "screen_name" : "ds_ldn",
      "indices" : [ 3, 10 ],
      "id_str" : "476700973",
      "id" : 476700973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/oVcLDX9o",
      "expanded_url" : "http:\/\/graphics.cs.cmu.edu\/projects\/scene-completion\/",
      "display_url" : "graphics.cs.cmu.edu\/projects\/scene\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285768542165549056",
  "text" : "RT @ds_ldn: A data-driven algorithm that completes photographic scenes using millions of photos, no annotation needed http:\/\/t.co\/oVcLDX9o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/oVcLDX9o",
        "expanded_url" : "http:\/\/graphics.cs.cmu.edu\/projects\/scene-completion\/",
        "display_url" : "graphics.cs.cmu.edu\/projects\/scene\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "285367135126040576",
    "text" : "A data-driven algorithm that completes photographic scenes using millions of photos, no annotation needed http:\/\/t.co\/oVcLDX9o",
    "id" : 285367135126040576,
    "created_at" : "2012-12-30 12:50:01 +0000",
    "user" : {
      "name" : "Data Science London",
      "screen_name" : "ds_ldn",
      "protected" : false,
      "id_str" : "476700973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1787151199\/dsldn_normal.jpg",
      "id" : 476700973,
      "verified" : false
    }
  },
  "id" : 285768542165549056,
  "created_at" : "2012-12-31 15:25:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 43, 52 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/vRUckjmC",
      "expanded_url" : "http:\/\/gilesbowkett.blogspot.co.uk\/2012\/12\/rails-developers-should-take-dci.html",
      "display_url" : "gilesbowkett.blogspot.co.uk\/2012\/12\/rails-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285705372239548416",
  "text" : "Reading a Rails article and I see a pic of @hamstarr in there - awesome :) http:\/\/t.co\/vRUckjmC",
  "id" : 285705372239548416,
  "created_at" : "2012-12-31 11:14:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meteor",
      "screen_name" : "meteorjs",
      "indices" : [ 3, 12 ],
      "id_str" : "533884891",
      "id" : 533884891
    }, {
      "name" : "Meteor",
      "screen_name" : "meteorjs",
      "indices" : [ 35, 44 ],
      "id_str" : "533884891",
      "id" : 533884891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/7Z9UK5gg",
      "expanded_url" : "http:\/\/bit.ly\/VQi8qH",
      "display_url" : "bit.ly\/VQi8qH"
    } ]
  },
  "geo" : { },
  "id_str" : "285442749468127232",
  "text" : "RT @meteorjs: Github Blog mentions @meteorjs as #3 on list of Notable Open Source Software of 2012 http:\/\/t.co\/7Z9UK5gg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Meteor",
        "screen_name" : "meteorjs",
        "indices" : [ 21, 30 ],
        "id_str" : "533884891",
        "id" : 533884891
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/7Z9UK5gg",
        "expanded_url" : "http:\/\/bit.ly\/VQi8qH",
        "display_url" : "bit.ly\/VQi8qH"
      } ]
    },
    "geo" : { },
    "id_str" : "285432326559789056",
    "text" : "Github Blog mentions @meteorjs as #3 on list of Notable Open Source Software of 2012 http:\/\/t.co\/7Z9UK5gg",
    "id" : 285432326559789056,
    "created_at" : "2012-12-30 17:09:04 +0000",
    "user" : {
      "name" : "Meteor",
      "screen_name" : "meteorjs",
      "protected" : false,
      "id_str" : "533884891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2080420398\/twitter-rock128_normal.png",
      "id" : 533884891,
      "verified" : false
    }
  },
  "id" : 285442749468127232,
  "created_at" : "2012-12-30 17:50:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 3, 13 ],
      "id_str" : "609442047",
      "id" : 609442047
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 15, 21 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285187093880262656",
  "text" : "RT @Xtinamccu: @swmcc I did think about creating a Twitter account for her, then I thought she doesn't need to see the stuff you put up  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "285163603416457216",
    "geo" : { },
    "id_str" : "285185979420127232",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc I did think about creating a Twitter account for her, then I thought she doesn't need to see the stuff you put up on this!",
    "id" : 285185979420127232,
    "in_reply_to_status_id" : 285163603416457216,
    "created_at" : "2012-12-30 00:50:10 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "protected" : false,
      "id_str" : "609442047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2311243791\/JB4WrLMj_normal",
      "id" : 609442047,
      "verified" : false
    }
  },
  "id" : 285187093880262656,
  "created_at" : "2012-12-30 00:54:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 112, 122 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285163603416457216",
  "text" : "Shite... My Mum got a Nexus for christmas and she just found Facebook. If she finds twitter I am pretty fucked. @Xtinamccu fuck you!",
  "id" : 285163603416457216,
  "created_at" : "2012-12-29 23:21:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285090636317728769",
  "geo" : { },
  "id_str" : "285163348553768960",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda When you have your own star destroyer there will be payback. Can I apply for a position - non com is fine..",
  "id" : 285163348553768960,
  "in_reply_to_status_id" : 285090636317728769,
  "created_at" : "2012-12-29 23:20:15 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roadhouse",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285118932749266944",
  "geo" : { },
  "id_str" : "285162861880303616",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl Don't worry buddy.. It gets better I am at the other side of it. Just one more day and you'll be on the mend. Be strong! #roadhouse",
  "id" : 285162861880303616,
  "in_reply_to_status_id" : 285118932749266944,
  "created_at" : "2012-12-29 23:18:19 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/HivSzlkF",
      "expanded_url" : "http:\/\/foursquare.com",
      "display_url" : "foursquare.com"
    } ]
  },
  "in_reply_to_status_id_str" : "285134117153173504",
  "geo" : { },
  "id_str" : "285162602131230720",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight http:\/\/t.co\/HivSzlkF. Local checkins to places. Its just a bit of fun :) Also using it for a personal project of mine. :)",
  "id" : 285162602131230720,
  "in_reply_to_status_id" : 285134117153173504,
  "created_at" : "2012-12-29 23:17:17 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 46, 57 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/5SBx8fBe",
      "expanded_url" : "http:\/\/4sq.com\/ZH8m21",
      "display_url" : "4sq.com\/ZH8m21"
    } ]
  },
  "geo" : { },
  "id_str" : "285067631365603329",
  "text" : "I just became the mayor of Glenavy Village on @foursquare! http:\/\/t.co\/5SBx8fBe",
  "id" : 285067631365603329,
  "created_at" : "2012-12-29 16:59:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285055922332659712",
  "text" : "Car is now away in dry dock to (and I quote the mechanic) \"fix the brakes, handbrake and whatever else is wrong with this heap of shit\".",
  "id" : 285055922332659712,
  "created_at" : "2012-12-29 16:13:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284705985589829633",
  "geo" : { },
  "id_str" : "284713227357655041",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl that stage lasts a day and a bit. I think I am coming out the other side I'd it though. Wasn't much craic today though :(",
  "id" : 284713227357655041,
  "in_reply_to_status_id" : 284705985589829633,
  "created_at" : "2012-12-28 17:31:37 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284664271399419904",
  "geo" : { },
  "id_str" : "284665241835560961",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden moved my personal website to heroku. Got jekyll building the site on it - am happy enough with it :)",
  "id" : 284665241835560961,
  "in_reply_to_status_id" : 284664271399419904,
  "created_at" : "2012-12-28 14:20:57 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284658259208593411",
  "text" : "Productive lunch break there :) Will go into details in a bit.",
  "id" : 284658259208593411,
  "created_at" : "2012-12-28 13:53:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 45, 52 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284625933346959360",
  "text" : "This cold still has not left me.. Wonder how @szlwzl is getting on\u2026. Hopefully better than moi!",
  "id" : 284625933346959360,
  "created_at" : "2012-12-28 11:44:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 8, 15 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284428134399500289",
  "geo" : { },
  "id_str" : "284433325681164288",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @rejoco you too. Hope we both make it through the night.",
  "id" : 284433325681164288,
  "in_reply_to_status_id" : 284428134399500289,
  "created_at" : "2012-12-27 22:59:24 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284407139080998912",
  "geo" : { },
  "id_str" : "284408064214437888",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl *solidarity fist pump*",
  "id" : 284408064214437888,
  "in_reply_to_status_id" : 284407139080998912,
  "created_at" : "2012-12-27 21:19:01 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284404903470825473",
  "geo" : { },
  "id_str" : "284407002237657089",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you too my man...",
  "id" : 284407002237657089,
  "in_reply_to_status_id" : 284404903470825473,
  "created_at" : "2012-12-27 21:14:48 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284388322560843776",
  "geo" : { },
  "id_str" : "284390713955872768",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you too - we will get there.. we are strong grown up men :)",
  "id" : 284390713955872768,
  "in_reply_to_status_id" : 284388322560843776,
  "created_at" : "2012-12-27 20:10:04 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284377698535608320",
  "geo" : { },
  "id_str" : "284377815489585152",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight get the mrs to sort that out pronto!",
  "id" : 284377815489585152,
  "in_reply_to_status_id" : 284377698535608320,
  "created_at" : "2012-12-27 19:18:49 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284339520009289729",
  "geo" : { },
  "id_str" : "284376025775882240",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight not yet - might do so later when I get round to fixing it :) Was Santa good to you? :)",
  "id" : 284376025775882240,
  "in_reply_to_status_id" : 284339520009289729,
  "created_at" : "2012-12-27 19:11:42 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284356597889773568",
  "geo" : { },
  "id_str" : "284375873577164800",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I have it too. Had it over christmas. It sucks donkey dick :(",
  "id" : 284375873577164800,
  "in_reply_to_status_id" : 284356597889773568,
  "created_at" : "2012-12-27 19:11:06 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/3UjcBTRI",
      "expanded_url" : "http:\/\/david.heinemeierhansson.com\/2012\/rails-is-omakase.html",
      "display_url" : "david.heinemeierhansson.com\/2012\/rails-is-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284309264506437632",
  "text" : "Someone somewhere just got told to shut the fuck up, in a nice way! :D http:\/\/t.co\/3UjcBTRI",
  "id" : 284309264506437632,
  "created_at" : "2012-12-27 14:46:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284305931070758913",
  "text" : "I am back at work today and as such I expected my sore throat and shitness to go away and be well again. I was wrong. Very very wrong.",
  "id" : 284305931070758913,
  "created_at" : "2012-12-27 14:33:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 85, 98 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284252903739387904",
  "geo" : { },
  "id_str" : "284253232044339200",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull yuck :( You could also start to use git locally on top of your svn - @rickyhassard does it - its a good habit to get into",
  "id" : 284253232044339200,
  "in_reply_to_status_id" : 284252903739387904,
  "created_at" : "2012-12-27 11:03:46 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284252272156889088",
  "geo" : { },
  "id_str" : "284252537119453184",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull I don't like it - but then I hate all IDE's and I am following the herd on this one. So you moved away from Eclipse then?",
  "id" : 284252537119453184,
  "in_reply_to_status_id" : 284252272156889088,
  "created_at" : "2012-12-27 11:01:00 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 16, 29 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284251236566458368",
  "geo" : { },
  "id_str" : "284252110646804480",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @paul_moffett doesn't do IRC :) I have him on talk though but to be honest I don't really want to talk to the fuck :)",
  "id" : 284252110646804480,
  "in_reply_to_status_id" : 284251236566458368,
  "created_at" : "2012-12-27 10:59:18 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284251418129477632",
  "geo" : { },
  "id_str" : "284251970758377473",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull that is disgusting\u2026 you and your IDE's. I use netbeans now for Java :( How you finding RoR - its lurrrvely aint it? :)",
  "id" : 284251970758377473,
  "in_reply_to_status_id" : 284251418129477632,
  "created_at" : "2012-12-27 10:58:45 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 80, 93 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284249821412483072",
  "text" : "Feeling kinda guilty - my throat is screwed and I can't talk so its only me and @Paul_Moffett in the office and I can't talk to him :)",
  "id" : 284249821412483072,
  "created_at" : "2012-12-27 10:50:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284036555805429761",
  "geo" : { },
  "id_str" : "284036736043057152",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl You just might bring it back... Dunno.. We will see :)",
  "id" : 284036736043057152,
  "in_reply_to_status_id" : 284036555805429761,
  "created_at" : "2012-12-26 20:43:29 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284036129706082304",
  "geo" : { },
  "id_str" : "284036487719317504",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl A film that has Alan Rickman and Liam Neeson shouldn't be cool. Hugh Grant and Colin Firth and some bird from Eastenders. Terrible",
  "id" : 284036487719317504,
  "in_reply_to_status_id" : 284036129706082304,
  "created_at" : "2012-12-26 20:42:30 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284035953880879104",
  "geo" : { },
  "id_str" : "284036043571863552",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you need to stop talking now :)",
  "id" : 284036043571863552,
  "in_reply_to_status_id" : 284035953880879104,
  "created_at" : "2012-12-26 20:40:44 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 7, 14 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roadhouse",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284035876667920384",
  "text" : "Unlike @szlwzl I am extracting the final bit of christmas by watching LOTR: The Two Towers... You've let me down Simon... #roadhouse",
  "id" : 284035876667920384,
  "created_at" : "2012-12-26 20:40:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284031183619256320",
  "geo" : { },
  "id_str" : "284035421044891648",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl what in the what what? seriously wtf are you doing!",
  "id" : 284035421044891648,
  "in_reply_to_status_id" : 284031183619256320,
  "created_at" : "2012-12-26 20:38:16 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283913989300297729",
  "geo" : { },
  "id_str" : "283960305770459136",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden cheers - my Dad hasn't stopped looking at them since he got them. Over 300 of them. Never thought it would go down so well.",
  "id" : 283960305770459136,
  "in_reply_to_status_id" : 283913989300297729,
  "created_at" : "2012-12-26 15:39:47 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/283913682407280640\/photo\/1",
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/gciGJRUe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_Cp_WtCUAALkjD.jpg",
      "id_str" : "283913682415669248",
      "id" : 283913682415669248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_Cp_WtCUAALkjD.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/gciGJRUe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283913682407280640",
  "text" : "For Christmas this year I found old slides in my parents attic and digitised them as a present. http:\/\/t.co\/gciGJRUe",
  "id" : 283913682407280640,
  "created_at" : "2012-12-26 12:34:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/283903806444535808\/photo\/1",
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/IY0Uzf6V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_ChAf3CAAAhxuo.jpg",
      "id_str" : "283903806448730112",
      "id" : 283903806448730112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_ChAf3CAAAhxuo.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/IY0Uzf6V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283903806444535808",
  "text" : "Bajingo buns... http:\/\/t.co\/IY0Uzf6V",
  "id" : 283903806444535808,
  "created_at" : "2012-12-26 11:55:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283875367050166272",
  "text" : "Just up here and my first thought is that I have to race over to my folks to build my star wars lego.. I am 33! Fuck you all - I am happy :)",
  "id" : 283875367050166272,
  "created_at" : "2012-12-26 10:02:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 3, 13 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283711867292114944",
  "text" : "RT @smccalden: Playing 'who am I' with the family tonight &amp; nearly an hour later I've guessed right that I was Mr Hankey the Xmas po ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283710025489346560",
    "text" : "Playing 'who am I' with the family tonight &amp; nearly an hour later I've guessed right that I was Mr Hankey the Xmas poo from South Park. FFS!",
    "id" : 283710025489346560,
    "created_at" : "2012-12-25 23:05:15 +0000",
    "user" : {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "protected" : false,
      "id_str" : "169048119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1169599362\/5bccf87c-8216-4684-bad8-61ad974596df_normal.png",
      "id" : 169048119,
      "verified" : false
    }
  },
  "id" : 283711867292114944,
  "created_at" : "2012-12-25 23:12:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283711694209949696",
  "text" : "Christmas is now officially over Listening to the bro playing on YouTube seems redundant when the very piano he learnt with is here. FFS",
  "id" : 283711694209949696,
  "created_at" : "2012-12-25 23:11:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283681385804341248",
  "geo" : { },
  "id_str" : "283692814611673089",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl nice one :) It'll happen again next year :)",
  "id" : 283692814611673089,
  "in_reply_to_status_id" : 283681385804341248,
  "created_at" : "2012-12-25 21:56:52 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/283690469769244672\/photo\/1",
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/p0h4BODN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-_e-q9CcAAFO8y.jpg",
      "id_str" : "283690469811187712",
      "id" : 283690469811187712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-_e-q9CcAAFO8y.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/p0h4BODN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283690469769244672",
  "text" : "Cauliflower - again I kid you not. John is shite at this game. http:\/\/t.co\/p0h4BODN",
  "id" : 283690469769244672,
  "created_at" : "2012-12-25 21:47:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/283686575181791232\/photo\/1",
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/rkFdsZF6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-_bb-aCAAAqV2u.jpg",
      "id_str" : "283686575202762752",
      "id" : 283686575202762752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-_bb-aCAAAqV2u.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/rkFdsZF6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283686575181791232",
  "text" : "John trying to draw \"babysitter\". I kid you not. http:\/\/t.co\/rkFdsZF6",
  "id" : 283686575181791232,
  "created_at" : "2012-12-25 21:32:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "priorities",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283662985002643456",
  "text" : "Nothing outs me off a company more than them tweeting on Christmas Day. #priorities",
  "id" : 283662985002643456,
  "created_at" : "2012-12-25 19:58:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283587808327790592",
  "geo" : { },
  "id_str" : "283610322621825024",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid you too Debbie. Have a good one :)",
  "id" : 283610322621825024,
  "in_reply_to_status_id" : 283587808327790592,
  "created_at" : "2012-12-25 16:29:04 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283500417768378369",
  "text" : "Merry Christmas people :D",
  "id" : 283500417768378369,
  "created_at" : "2012-12-25 09:12:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quality",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283374707577876480",
  "text" : "Best quote from the oul man so far this festive season \"I'm so old that there's more of me in the fucking bedside cabinet at night\" #quality",
  "id" : 283374707577876480,
  "created_at" : "2012-12-25 00:52:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283303439776239616",
  "text" : "The Snowman and the Snowdog..... Can they not just leave it alone. The original was pretty shit, doubt a dog will fix it.",
  "id" : 283303439776239616,
  "created_at" : "2012-12-24 20:09:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/ETxkhWIG",
      "expanded_url" : "http:\/\/www.recruitni.com\/account-search\/?account=1172",
      "display_url" : "recruitni.com\/account-search\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "283184143225991169",
  "text" : "RepKnight are recruiting for JAVA developers so have a look, ask any questions and come join us! http:\/\/t.co\/ETxkhWIG",
  "id" : 283184143225991169,
  "created_at" : "2012-12-24 12:15:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283179427796508672",
  "text" : "One more hour then I am off for Christmas :)",
  "id" : 283179427796508672,
  "created_at" : "2012-12-24 11:56:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282984327908827136",
  "text" : "McLovin on channel 5 :)",
  "id" : 282984327908827136,
  "created_at" : "2012-12-23 23:01:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "indices" : [ 3, 19 ],
      "id_str" : "402824193",
      "id" : 402824193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/a9fUuhAg",
      "expanded_url" : "http:\/\/lnkd.in\/s3csbX",
      "display_url" : "lnkd.in\/s3csbX"
    }, {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/qABOrwtx",
      "expanded_url" : "http:\/\/bit.ly\/UUVs9H",
      "display_url" : "bit.ly\/UUVs9H"
    } ]
  },
  "geo" : { },
  "id_str" : "282980858149875712",
  "text" : "RT @NodeJsCommunity: More info on getting #nodejs running on your raspberry pi http:\/\/t.co\/a9fUuhAg http:\/\/t.co\/qABOrwtx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodejs",
        "indices" : [ 21, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/a9fUuhAg",
        "expanded_url" : "http:\/\/lnkd.in\/s3csbX",
        "display_url" : "lnkd.in\/s3csbX"
      }, {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/qABOrwtx",
        "expanded_url" : "http:\/\/bit.ly\/UUVs9H",
        "display_url" : "bit.ly\/UUVs9H"
      } ]
    },
    "geo" : { },
    "id_str" : "282978061727715328",
    "text" : "More info on getting #nodejs running on your raspberry pi http:\/\/t.co\/a9fUuhAg http:\/\/t.co\/qABOrwtx",
    "id" : 282978061727715328,
    "created_at" : "2012-12-23 22:36:42 +0000",
    "user" : {
      "name" : "NodeJS Community",
      "screen_name" : "NodeJsCommunity",
      "protected" : false,
      "id_str" : "402824193",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1627924583\/njscomm_normal.jpg",
      "id" : 402824193,
      "verified" : false
    }
  },
  "id" : 282980858149875712,
  "created_at" : "2012-12-23 22:47:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imscared",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282945989453676544",
  "geo" : { },
  "id_str" : "282946810891362304",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates Fuck. Right. Off. It hasn't been talked about. #imscared",
  "id" : 282946810891362304,
  "in_reply_to_status_id" : 282945989453676544,
  "created_at" : "2012-12-23 20:32:31 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodtimes",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282945804145152000",
  "text" : "OH: Are you deprived of having a dick?\". Ahhh pre Christmas conversation with my Dad. #goodtimes",
  "id" : 282945804145152000,
  "created_at" : "2012-12-23 20:28:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282845181772980224",
  "text" : "Shite :( Stupid wind kept me up all night so only up now. Gotta venture into Sprucefiled for a few last min things... Arse :(",
  "id" : 282845181772980224,
  "created_at" : "2012-12-23 13:48:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282738843214565376",
  "text" : "Feck off wind!!!!!",
  "id" : 282738843214565376,
  "created_at" : "2012-12-23 06:46:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282560072461201409",
  "geo" : { },
  "id_str" : "282560185204084737",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden deleted :)",
  "id" : 282560185204084737,
  "in_reply_to_status_id" : 282560072461201409,
  "created_at" : "2012-12-22 18:56:12 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 0, 10 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awewome",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282521110837346304",
  "geo" : { },
  "id_str" : "282529148939931648",
  "in_reply_to_user_id" : 609442047,
  "text" : "@Xtinamccu go fuck yourself! :) What you think of my cool Christmas decoration outside my front door. #awewome",
  "id" : 282529148939931648,
  "in_reply_to_status_id" : 282521110837346304,
  "created_at" : "2012-12-22 16:52:52 +0000",
  "in_reply_to_screen_name" : "Xtinamccu",
  "in_reply_to_user_id_str" : "609442047",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thisisgoingtogetmessy",
      "indices" : [ 74, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282518050912227328",
  "text" : "I'm just about to venture into Tescos in Crumlin just before Christmas... #thisisgoingtogetmessy",
  "id" : 282518050912227328,
  "created_at" : "2012-12-22 16:08:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 60, 71 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/COc04oL3",
      "expanded_url" : "http:\/\/4sq.com\/cQpvh2",
      "display_url" : "4sq.com\/cQpvh2"
    } ]
  },
  "geo" : { },
  "id_str" : "282302597703008256",
  "text" : "I just ousted Ashley K. as the mayor of Beersbridge road on @foursquare! http:\/\/t.co\/COc04oL3",
  "id" : 282302597703008256,
  "created_at" : "2012-12-22 01:52:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/282241179230285824\/photo\/1",
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/XTXdwTzb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-q4222CMAAWp9x.jpg",
      "id_str" : "282241179238674432",
      "id" : 282241179238674432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-q4222CMAAWp9x.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/XTXdwTzb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282241179230285824",
  "text" : "Ya that is a blow doll in deans at queens with a balaclava on :) Still before 10 ;) http:\/\/t.co\/XTXdwTzb",
  "id" : 282241179230285824,
  "created_at" : "2012-12-21 21:48:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/282240010336489473\/photo\/1",
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/4KYMFj2W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-q3y0YCUAAXDoe.jpg",
      "id_str" : "282240010344878080",
      "id" : 282240010344878080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-q3y0YCUAAXDoe.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/4KYMFj2W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282240010336489473",
  "text" : "Classy night :) It's not even 10 and there's a blow up sheep and a blow up doll :) http:\/\/t.co\/4KYMFj2W",
  "id" : 282240010336489473,
  "created_at" : "2012-12-21 21:43:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 3, 10 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 69, 82 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 83, 96 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 97, 103 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/7p6z6gtE",
      "expanded_url" : "http:\/\/4sq.com\/U2omEf",
      "display_url" : "4sq.com\/U2omEf"
    } ]
  },
  "geo" : { },
  "id_str" : "282217568398356480",
  "text" : "RT @rejoco: Chrimbo dinner. Carnage impending (@ Deanes at Queens w\/ @paul_moffett @nicholabates @swmcc) http:\/\/t.co\/7p6z6gtE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Moffett",
        "screen_name" : "Paul_Moffett",
        "indices" : [ 57, 70 ],
        "id_str" : "36913698",
        "id" : 36913698
      }, {
        "name" : "Nichola Bates",
        "screen_name" : "nicholabates",
        "indices" : [ 71, 84 ],
        "id_str" : "19125494",
        "id" : 19125494
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 85, 91 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/7p6z6gtE",
        "expanded_url" : "http:\/\/4sq.com\/U2omEf",
        "display_url" : "4sq.com\/U2omEf"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.5833539857, -5.9375997374 ]
    },
    "id_str" : "282216910366593024",
    "text" : "Chrimbo dinner. Carnage impending (@ Deanes at Queens w\/ @paul_moffett @nicholabates @swmcc) http:\/\/t.co\/7p6z6gtE",
    "id" : 282216910366593024,
    "created_at" : "2012-12-21 20:12:09 +0000",
    "user" : {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "protected" : false,
      "id_str" : "53053999",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000167317834\/6219cabb0a7785ac8acd656a39be2ab9_normal.jpeg",
      "id" : 53053999,
      "verified" : false
    }
  },
  "id" : 282217568398356480,
  "created_at" : "2012-12-21 20:14:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 10, 18 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 19, 32 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282169647929896961",
  "geo" : { },
  "id_str" : "282170583255482369",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo @jbrevel @nicholabates I'll be grand\u2026 :)",
  "id" : 282170583255482369,
  "in_reply_to_status_id" : 282169647929896961,
  "created_at" : "2012-12-21 17:08:04 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282063110473392128",
  "geo" : { },
  "id_str" : "282063724968288256",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe what be my username? :)",
  "id" : 282063724968288256,
  "in_reply_to_status_id" : 282063110473392128,
  "created_at" : "2012-12-21 10:03:27 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatstheworstthatcanhappen",
      "indices" : [ 42, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282062729840308224",
  "text" : "The Repknight secret santa is on today... #whatstheworstthatcanhappen",
  "id" : 282062729840308224,
  "created_at" : "2012-12-21 09:59:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 3, 13 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 83, 89 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281860252121591808",
  "text" : "RT @smccalden: Rocky 1&amp;2 back to back tonight on itv4 from 9. I know a certain @swmcc who will be pissing himself with excitement as ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 68, 74 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281849849622695936",
    "text" : "Rocky 1&amp;2 back to back tonight on itv4 from 9. I know a certain @swmcc who will be pissing himself with excitement as we speak.",
    "id" : 281849849622695936,
    "created_at" : "2012-12-20 19:53:35 +0000",
    "user" : {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "protected" : false,
      "id_str" : "169048119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1169599362\/5bccf87c-8216-4684-bad8-61ad974596df_normal.png",
      "id" : 169048119,
      "verified" : false
    }
  },
  "id" : 281860252121591808,
  "created_at" : "2012-12-20 20:34:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281851742080077826",
  "geo" : { },
  "id_str" : "281860206638534656",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl good man :)",
  "id" : 281860206638534656,
  "in_reply_to_status_id" : 281851742080077826,
  "created_at" : "2012-12-20 20:34:44 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281849849622695936",
  "geo" : { },
  "id_str" : "281860156764065792",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden awesome!!!! Just back from Lisburn and have the fire lit!",
  "id" : 281860156764065792,
  "in_reply_to_status_id" : 281849849622695936,
  "created_at" : "2012-12-20 20:34:32 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 40, 51 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/7OJq4wA2",
      "expanded_url" : "http:\/\/4sq.com\/U0Tyn2",
      "display_url" : "4sq.com\/U0Tyn2"
    } ]
  },
  "geo" : { },
  "id_str" : "281849323996721152",
  "text" : "I just unlocked the \u201CMall Rat\u201D badge on @foursquare for checking in at malls! Time for a fancy pretzel. http:\/\/t.co\/7OJq4wA2",
  "id" : 281849323996721152,
  "created_at" : "2012-12-20 19:51:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Simon Fraser",
      "screen_name" : "symatree",
      "indices" : [ 15, 24 ],
      "id_str" : "26981144",
      "id" : 26981144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281778547494899712",
  "geo" : { },
  "id_str" : "281779613938626561",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @symatree Sublime is lovely - I have pretty much moved over to it exclusively now. Vim now and again - dependent on my mood.",
  "id" : 281779613938626561,
  "in_reply_to_status_id" : 281778547494899712,
  "created_at" : "2012-12-20 15:14:29 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281735897022607360",
  "geo" : { },
  "id_str" : "281748852648841217",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor sublime and vim are my tools of choice this weather. Textmate the odd time.",
  "id" : 281748852648841217,
  "in_reply_to_status_id" : 281735897022607360,
  "created_at" : "2012-12-20 13:12:15 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathtoides",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281735328287567872",
  "text" : "I just edited a Java project without an IDE.. That's how I roll bitches!!! :D #deathtoides",
  "id" : 281735328287567872,
  "created_at" : "2012-12-20 12:18:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281722546225827840",
  "geo" : { },
  "id_str" : "281735231382355968",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco bah humbug! Spread the Christmas cheer and wait till your at your laptop to open emails ;) :)",
  "id" : 281735231382355968,
  "in_reply_to_status_id" : 281722546225827840,
  "created_at" : "2012-12-20 12:18:08 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian D. Quinn",
      "screen_name" : "briandq",
      "indices" : [ 3, 11 ],
      "id_str" : "17363843",
      "id" : 17363843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/0zTTV6MN",
      "expanded_url" : "http:\/\/spreecommerce.com\/blog\/spree-1-3-0-released",
      "display_url" : "spreecommerce.com\/blog\/spree-1-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281474294817636353",
  "text" : "RT @briandq: Spree 1.3 is released, just in time for Christmas! http:\/\/t.co\/0zTTV6MN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/0zTTV6MN",
        "expanded_url" : "http:\/\/spreecommerce.com\/blog\/spree-1-3-0-released",
        "display_url" : "spreecommerce.com\/blog\/spree-1-3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "281473363308867584",
    "text" : "Spree 1.3 is released, just in time for Christmas! http:\/\/t.co\/0zTTV6MN",
    "id" : 281473363308867584,
    "created_at" : "2012-12-19 18:57:33 +0000",
    "user" : {
      "name" : "Brian D. Quinn",
      "screen_name" : "briandq",
      "protected" : false,
      "id_str" : "17363843",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/202317522\/mask_normal.gif",
      "id" : 17363843,
      "verified" : false
    }
  },
  "id" : 281474294817636353,
  "created_at" : "2012-12-19 19:01:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 24, 32 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 37, 47 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281426718865113088",
  "text" : "I really hate IDEs\u2026 \/cc @jbrevel and @smccalden",
  "id" : 281426718865113088,
  "created_at" : "2012-12-19 15:52:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rumble Labs",
      "screen_name" : "rumblelabs",
      "indices" : [ 4, 15 ],
      "id_str" : "20454184",
      "id" : 20454184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/zGQ6w1kV",
      "expanded_url" : "http:\/\/xmas.rumblelabs.com\/",
      "display_url" : "xmas.rumblelabs.com"
    } ]
  },
  "geo" : { },
  "id_str" : "281394129596981248",
  "text" : "WOW @rumblelabs gave me the idea to make a Basecamp clone as a xmas gift! Thanks guys you\u2019re the best!! http:\/\/t.co\/zGQ6w1kV",
  "id" : 281394129596981248,
  "created_at" : "2012-12-19 13:42:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281394018108178432",
  "text" : "s\/awesome\/genericinsult\/ :)",
  "id" : 281394018108178432,
  "created_at" : "2012-12-19 13:42:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281392675888959489",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden is a awesome!",
  "id" : 281392675888959489,
  "created_at" : "2012-12-19 13:36:56 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281388342405394432",
  "geo" : { },
  "id_str" : "281388459942350848",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee morning and merry christmas :)",
  "id" : 281388459942350848,
  "in_reply_to_status_id" : 281388342405394432,
  "created_at" : "2012-12-19 13:20:11 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 3, 17 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "motivationalsong",
      "indices" : [ 49, 66 ]
    }, {
      "text" : "rocky4",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281338215468773376",
  "text" : "RT @peter_omalley: Hearts on Fire. What a tune!! #motivationalsong #rocky4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "motivationalsong",
        "indices" : [ 30, 47 ]
      }, {
        "text" : "rocky4",
        "indices" : [ 48, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281010245629771777",
    "text" : "Hearts on Fire. What a tune!! #motivationalsong #rocky4",
    "id" : 281010245629771777,
    "created_at" : "2012-12-18 12:17:18 +0000",
    "user" : {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "protected" : false,
      "id_str" : "437697624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1706604039\/eC7Ba2I7_normal",
      "id" : 437697624,
      "verified" : false
    }
  },
  "id" : 281338215468773376,
  "created_at" : "2012-12-19 10:00:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281327377005547520",
  "text" : "Something wrong with saying you are stuck in a traffic jam when you are in your way to Drumbo",
  "id" : 281327377005547520,
  "created_at" : "2012-12-19 09:17:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281115403789418496",
  "geo" : { },
  "id_str" : "281123856838701056",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I loved it. :) 10\/10",
  "id" : 281123856838701056,
  "in_reply_to_status_id" : 281115403789418496,
  "created_at" : "2012-12-18 19:48:45 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 39, 50 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/yc0nl1gD",
      "expanded_url" : "http:\/\/4sq.com\/R3FDjd",
      "display_url" : "4sq.com\/R3FDjd"
    } ]
  },
  "geo" : { },
  "id_str" : "281121181027950592",
  "text" : "I just unlocked the \"Crunked\" badge on @foursquare! http:\/\/t.co\/yc0nl1gD",
  "id" : 281121181027950592,
  "created_at" : "2012-12-18 19:38:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281113247019585539",
  "geo" : { },
  "id_str" : "281115080404393985",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore was a really good one I think.",
  "id" : 281115080404393985,
  "in_reply_to_status_id" : 281113247019585539,
  "created_at" : "2012-12-18 19:13:52 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flegs",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "TheHobbit",
      "indices" : [ 74, 84 ]
    }, {
      "text" : "odeon",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "ROADHOUSE",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280761887019376640",
  "text" : "I drove threw every republican stronghold to get to see this film! #flegs #TheHobbit #odeon #ROADHOUSE",
  "id" : 280761887019376640,
  "created_at" : "2012-12-17 19:50:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clock",
      "screen_name" : "clock",
      "indices" : [ 3, 9 ],
      "id_str" : "24866880",
      "id" : 24866880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/H4SgmKyJ",
      "expanded_url" : "http:\/\/bit.ly\/12vwAtM",
      "display_url" : "bit.ly\/12vwAtM"
    } ]
  },
  "geo" : { },
  "id_str" : "280682619899875328",
  "text" : "RT @clock: Raspberry Pi launches it's app store http:\/\/t.co\/H4SgmKyJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/H4SgmKyJ",
        "expanded_url" : "http:\/\/bit.ly\/12vwAtM",
        "display_url" : "bit.ly\/12vwAtM"
      } ]
    },
    "geo" : { },
    "id_str" : "280681621735211008",
    "text" : "Raspberry Pi launches it's app store http:\/\/t.co\/H4SgmKyJ",
    "id" : 280681621735211008,
    "created_at" : "2012-12-17 14:31:28 +0000",
    "user" : {
      "name" : "Clock",
      "screen_name" : "clock",
      "protected" : false,
      "id_str" : "24866880",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2169692317\/clock-profile-pic_normal.png",
      "id" : 24866880,
      "verified" : false
    }
  },
  "id" : 280682619899875328,
  "created_at" : "2012-12-17 14:35:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280669738206642177",
  "text" : "OH: \"We are perverts, you are pedophile\"",
  "id" : 280669738206642177,
  "created_at" : "2012-12-17 13:44:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Refresh Belfast",
      "screen_name" : "refreshbelfast",
      "indices" : [ 20, 35 ],
      "id_str" : "20080166",
      "id" : 20080166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280648278272532481",
  "text" : "Crap - forgot about @refreshbelfast tonight - going to see The Hobbit instead\u2026. Arse :(",
  "id" : 280648278272532481,
  "created_at" : "2012-12-17 12:18:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280642763563884545",
  "text" : "OH: \"It is socially acceptable people have good looking children\"",
  "id" : 280642763563884545,
  "created_at" : "2012-12-17 11:57:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280642450194853888",
  "text" : "OH: \"What is wrong with admiring that someone else has pretty kids!\"",
  "id" : 280642450194853888,
  "created_at" : "2012-12-17 11:55:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280450520865447936",
  "text" : "I just fell for the oul door bell rings on the tv and I went to the front door trick.",
  "id" : 280450520865447936,
  "created_at" : "2012-12-16 23:13:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280421906061078529",
  "geo" : { },
  "id_str" : "280430527067070464",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I love strictly :)",
  "id" : 280430527067070464,
  "in_reply_to_status_id" : 280421906061078529,
  "created_at" : "2012-12-16 21:53:42 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280417066199175169",
  "text" : "Die Hard is in Film4. That's all you need to know.",
  "id" : 280417066199175169,
  "created_at" : "2012-12-16 21:00:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 51, 62 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/xy7vHTl4",
      "expanded_url" : "http:\/\/4sq.com\/UIHaHu",
      "display_url" : "4sq.com\/UIHaHu"
    } ]
  },
  "geo" : { },
  "id_str" : "280007964964814849",
  "text" : "I just became the mayor of Topaz Garage Glenavy on @foursquare! http:\/\/t.co\/xy7vHTl4",
  "id" : 280007964964814849,
  "created_at" : "2012-12-15 17:54:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gnip, Inc.",
      "screen_name" : "gnip",
      "indices" : [ 3, 8 ],
      "id_str" : "16958875",
      "id" : 16958875
    }, {
      "name" : "Gnip, Inc.",
      "screen_name" : "gnip",
      "indices" : [ 40, 45 ],
      "id_str" : "16958875",
      "id" : 16958875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/6AJ5w7cW",
      "expanded_url" : "http:\/\/bit.ly\/SRCpxs",
      "display_url" : "bit.ly\/SRCpxs"
    } ]
  },
  "geo" : { },
  "id_str" : "280006619079770113",
  "text" : "RT @gnip: The year in review: a look at @Gnip's milestones in 2012! http:\/\/t.co\/6AJ5w7cW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gnip, Inc.",
        "screen_name" : "gnip",
        "indices" : [ 30, 35 ],
        "id_str" : "16958875",
        "id" : 16958875
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/6AJ5w7cW",
        "expanded_url" : "http:\/\/bit.ly\/SRCpxs",
        "display_url" : "bit.ly\/SRCpxs"
      } ]
    },
    "geo" : { },
    "id_str" : "279386078752944129",
    "text" : "The year in review: a look at @Gnip's milestones in 2012! http:\/\/t.co\/6AJ5w7cW",
    "id" : 279386078752944129,
    "created_at" : "2012-12-14 00:43:26 +0000",
    "user" : {
      "name" : "Gnip, Inc.",
      "screen_name" : "gnip",
      "protected" : false,
      "id_str" : "16958875",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2439636286\/xvakulxcrzzbl1cjtm6w_normal.jpeg",
      "id" : 16958875,
      "verified" : true
    }
  },
  "id" : 280006619079770113,
  "created_at" : "2012-12-15 17:49:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280006525135757312",
  "text" : "Now I know remember why the perl community is dying... Flame war on that poor stiff on London.pm is not justified. Sickens me.",
  "id" : 280006525135757312,
  "created_at" : "2012-12-15 17:48:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 116, 129 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279735286513147904",
  "geo" : { },
  "id_str" : "279735435977166848",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne in a friends car in the most awkward place imaginable. Fair play to him for checking this late. \/cc @Paul_Moffett",
  "id" : 279735435977166848,
  "in_reply_to_status_id" : 279735286513147904,
  "created_at" : "2012-12-14 23:51:39 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279735098117599232",
  "text" : "Keys found :) Brilliant.. As a set of new keys is around 150quid.. that's worth more than the car!",
  "id" : 279735098117599232,
  "created_at" : "2012-12-14 23:50:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Devlin",
      "screen_name" : "MDev247",
      "indices" : [ 0, 8 ],
      "id_str" : "46503614",
      "id" : 46503614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yousuck",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279653341473153024",
  "geo" : { },
  "id_str" : "279656058522324992",
  "in_reply_to_user_id" : 46503614,
  "text" : "@MDev247 its my house though - so that is no use to me at all. #yousuck",
  "id" : 279656058522324992,
  "in_reply_to_status_id" : 279653341473153024,
  "created_at" : "2012-12-14 18:36:14 +0000",
  "in_reply_to_screen_name" : "MDev247",
  "in_reply_to_user_id_str" : "46503614",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Devlin",
      "screen_name" : "MDev247",
      "indices" : [ 3, 11 ],
      "id_str" : "46503614",
      "id" : 46503614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279651691744329729",
  "text" : "Yo @MDev247 you are bound to know how to break into houses seeing you are from the west? Any tips would be appreciated ;)",
  "id" : 279651691744329729,
  "created_at" : "2012-12-14 18:18:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279650446249963521",
  "geo" : { },
  "id_str" : "279650627427127296",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid Nope - all keys are on this one. No spares for house or anything :) Sure, its a bit of craic :) They have to turn up :)",
  "id" : 279650627427127296,
  "in_reply_to_status_id" : 279650446249963521,
  "created_at" : "2012-12-14 18:14:39 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279649848590995456",
  "geo" : { },
  "id_str" : "279650236652199936",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid . and they said no. Or they are in Moffett's car (he says they aren't). So going key hunting tonight :) Here is hoping anyway.",
  "id" : 279650236652199936,
  "in_reply_to_status_id" : 279649848590995456,
  "created_at" : "2012-12-14 18:13:06 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279649848590995456",
  "geo" : { },
  "id_str" : "279650093576114176",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid don't be silly :) I have someone to come pick me up - they ail be a while though. They are either in Bob Stewarts (rung them).",
  "id" : 279650093576114176,
  "in_reply_to_status_id" : 279649848590995456,
  "created_at" : "2012-12-14 18:12:32 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279637942534811649",
  "text" : "Well I've well and truely lost my car keys this time.. No sign of them.. Phoned Bob Stewarts and nothing.. Last hope is Moffett's car :(",
  "id" : 279637942534811649,
  "created_at" : "2012-12-14 17:24:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 11, 18 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279580801346199552",
  "geo" : { },
  "id_str" : "279593660079812608",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @rejoco not yet, but it'll happen.",
  "id" : 279593660079812608,
  "in_reply_to_status_id" : 279580801346199552,
  "created_at" : "2012-12-14 14:28:17 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 14, 21 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 54, 65 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/KrWZeXD7",
      "expanded_url" : "http:\/\/4sq.com\/90DkyZ",
      "display_url" : "4sq.com\/90DkyZ"
    } ]
  },
  "geo" : { },
  "id_str" : "279576602432659457",
  "text" : "I just ousted @rejoco as the mayor of Bob Stewarts on @foursquare! http:\/\/t.co\/KrWZeXD7",
  "id" : 279576602432659457,
  "created_at" : "2012-12-14 13:20:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    }, {
      "name" : "Rumble Labs",
      "screen_name" : "rumblelabs",
      "indices" : [ 10, 21 ],
      "id_str" : "20454184",
      "id" : 20454184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279536742321754114",
  "geo" : { },
  "id_str" : "279537638694871041",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr @rumblelabs great news, enjoy :)",
  "id" : 279537638694871041,
  "in_reply_to_status_id" : 279536742321754114,
  "created_at" : "2012-12-14 10:45:41 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279526339785134081",
  "geo" : { },
  "id_str" : "279528493342142464",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist Repating something != understanding.. I have now gained knowledge.",
  "id" : 279528493342142464,
  "in_reply_to_status_id" : 279526339785134081,
  "created_at" : "2012-12-14 10:09:20 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279525194765328386",
  "geo" : { },
  "id_str" : "279527892826861568",
  "in_reply_to_user_id" : 26985337,
  "text" : "@PGregg dude with no handbrake and I park on a sort of a hill ;)",
  "id" : 279527892826861568,
  "in_reply_to_status_id" : 279525194765328386,
  "created_at" : "2012-12-14 10:06:57 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279523897735512064",
  "text" : "Work people laughing at my parking skills this morning - bastards\u2026 :)",
  "id" : 279523897735512064,
  "created_at" : "2012-12-14 09:51:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 3, 16 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldbastatd",
      "indices" : [ 64, 75 ]
    }, {
      "text" : "stillyounger",
      "indices" : [ 76, 89 ]
    }, {
      "text" : "happybirthday",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279507736004263936",
  "text" : "So @Paul_Moffett is 34 today... Fuck I'd hate to be that age ;) #oldbastatd #stillyounger #happybirthday",
  "id" : 279507736004263936,
  "created_at" : "2012-12-14 08:46:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "indices" : [ 0, 7 ],
      "id_str" : "14060295",
      "id" : 14060295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279359558005166082",
  "geo" : { },
  "id_str" : "279377638886354945",
  "in_reply_to_user_id" : 14060295,
  "text" : "@cimota just to be annoying - but it's not Mr Jackson - it's Sir Peter ;)",
  "id" : 279377638886354945,
  "in_reply_to_status_id" : 279359558005166082,
  "created_at" : "2012-12-14 00:09:54 +0000",
  "in_reply_to_screen_name" : "cimota",
  "in_reply_to_user_id_str" : "14060295",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279354882400604160",
  "text" : "I am finding it impossible to watch Predator and not quote the lines as they say them. Get to the chapua! Ain't got time to bleed! Anytime!",
  "id" : 279354882400604160,
  "created_at" : "2012-12-13 22:39:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "node js",
      "screen_name" : "nodejs",
      "indices" : [ 3, 10 ],
      "id_str" : "91985735",
      "id" : 91985735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/e1V78Dte",
      "expanded_url" : "http:\/\/code.flickr.net\/2012\/12\/12\/highly-available-real-time-notifications\/",
      "display_url" : "code.flickr.net\/2012\/12\/12\/hig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279343208104853505",
  "text" : "RT @nodejs: Flickr is using Node and Redis to deliver real-time notifications\nhttp:\/\/t.co\/e1V78Dte",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/e1V78Dte",
        "expanded_url" : "http:\/\/code.flickr.net\/2012\/12\/12\/highly-available-real-time-notifications\/",
        "display_url" : "code.flickr.net\/2012\/12\/12\/hig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "279332869787222017",
    "text" : "Flickr is using Node and Redis to deliver real-time notifications\nhttp:\/\/t.co\/e1V78Dte",
    "id" : 279332869787222017,
    "created_at" : "2012-12-13 21:12:00 +0000",
    "user" : {
      "name" : "node js",
      "screen_name" : "nodejs",
      "protected" : false,
      "id_str" : "91985735",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1437021459\/nodejs-dark_normal.png",
      "id" : 91985735,
      "verified" : false
    }
  },
  "id" : 279343208104853505,
  "created_at" : "2012-12-13 21:53:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279157572127297536",
  "geo" : { },
  "id_str" : "279159057242263552",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I do not know of this show - will look it up in a bit. Saw you on the tee-bee on Sunday evening btw :)",
  "id" : 279159057242263552,
  "in_reply_to_status_id" : 279157572127297536,
  "created_at" : "2012-12-13 09:41:20 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278973263231725568",
  "text" : "Number of slides scanned this evening. 83.",
  "id" : 278973263231725568,
  "created_at" : "2012-12-12 21:23:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278944417136668674",
  "geo" : { },
  "id_str" : "278949339802513408",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll nope.",
  "id" : 278949339802513408,
  "in_reply_to_status_id" : 278944417136668674,
  "created_at" : "2012-12-12 19:47:59 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "londonpm",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278930366247612416",
  "text" : "Forgotten what it was like to witness a flame war on a mailing list.. Can't say I've missed it. #londonpm",
  "id" : 278930366247612416,
  "created_at" : "2012-12-12 18:32:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 21, 29 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROADHOUSE",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278928702962810881",
  "text" : "I'm leaving work now @jbrevel - I don't want to talk to you tomorrow unless you have watched sons. #ROADHOUSE",
  "id" : 278928702962810881,
  "created_at" : "2012-12-12 18:25:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 14, 22 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 23, 30 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278919860635967488",
  "geo" : { },
  "id_str" : "278920087178731520",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates @jbrevel @rejoco You mean you plugged it in at the back? ;)",
  "id" : 278920087178731520,
  "in_reply_to_status_id" : 278919860635967488,
  "created_at" : "2012-12-12 17:51:45 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 24, 34 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278875214773886977",
  "text" : "New low in the office.. @smccalden singing along to Wham! :(",
  "id" : 278875214773886977,
  "created_at" : "2012-12-12 14:53:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278595503900471296",
  "text" : "Lovely day in Belfast. 17th year I've taken my Mum for her lunch and shopping. Hopefully another 20+ left to go as well.",
  "id" : 278595503900471296,
  "created_at" : "2012-12-11 20:21:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 42, 53 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/ysoDA6wk",
      "expanded_url" : "http:\/\/4sq.com\/YXiOSP",
      "display_url" : "4sq.com\/YXiOSP"
    } ]
  },
  "geo" : { },
  "id_str" : "278570216638799872",
  "text" : "I just unlocked the \"Fresh Brew\" badge on @foursquare for checking in at coffee shops! http:\/\/t.co\/ysoDA6wk",
  "id" : 278570216638799872,
  "created_at" : "2012-12-11 18:41:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Design",
      "screen_name" : "design",
      "indices" : [ 3, 10 ],
      "id_str" : "87532773",
      "id" : 87532773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/F0lZFf9t",
      "expanded_url" : "http:\/\/2012.twitter.com\/",
      "display_url" : "2012.twitter.com"
    } ]
  },
  "geo" : { },
  "id_str" : "278533497000452098",
  "text" : "RT @design: Excited to announce the launch of \"2012: The Year on Twitter\" http:\/\/t.co\/F0lZFf9t",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/F0lZFf9t",
        "expanded_url" : "http:\/\/2012.twitter.com\/",
        "display_url" : "2012.twitter.com"
      } ]
    },
    "geo" : { },
    "id_str" : "278529862413742081",
    "text" : "Excited to announce the launch of \"2012: The Year on Twitter\" http:\/\/t.co\/F0lZFf9t",
    "id" : 278529862413742081,
    "created_at" : "2012-12-11 16:01:08 +0000",
    "user" : {
      "name" : "Twitter Design",
      "screen_name" : "design",
      "protected" : false,
      "id_str" : "87532773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2587092969\/cge4oxfj2i3pihdwgw9u_normal.png",
      "id" : 87532773,
      "verified" : true
    }
  },
  "id" : 278533497000452098,
  "created_at" : "2012-12-11 16:15:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/278479482296340480\/photo\/1",
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/HMtIRHdY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A91bnRvCEAEQ5rh.jpg",
      "id_str" : "278479482300534785",
      "id" : 278479482300534785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A91bnRvCEAEQ5rh.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/HMtIRHdY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278479482296340480",
  "text" : "Nostalgia http:\/\/t.co\/HMtIRHdY",
  "id" : 278479482296340480,
  "created_at" : "2012-12-11 12:40:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/278472704569520128\/photo\/1",
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/jq16z5sY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A91VcwvCMAAMhN7.jpg",
      "id_str" : "278472704573714432",
      "id" : 278472704573714432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A91VcwvCMAAMhN7.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/jq16z5sY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278472704569520128",
  "text" : "Christmas Nun!!!! :) http:\/\/t.co\/jq16z5sY",
  "id" : 278472704569520128,
  "created_at" : "2012-12-11 12:14:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 15, 25 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278431456148201472",
  "text" : "Happy Birthday @Xtinamccu - 28... This time two years bitcho.",
  "id" : 278431456148201472,
  "created_at" : "2012-12-11 09:30:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278425815442657280",
  "text" : "Christmas shopping day in Belfast - its zoo cold.. At least it will be christmasy!",
  "id" : 278425815442657280,
  "created_at" : "2012-12-11 09:07:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/278247063391707137\/photo\/1",
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/cfhtZ4JR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9yIOt3CIAAXnT1.jpg",
      "id_str" : "278247063400095744",
      "id" : 278247063400095744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9yIOt3CIAAXnT1.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/cfhtZ4JR"
    } ],
    "hashtags" : [ {
      "text" : "diehard",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "christmas",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "takomiplaza",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278247063391707137",
  "text" : "Yippie Kai Yat Motherfucker #diehard #christmas #takomiplaza http:\/\/t.co\/cfhtZ4JR",
  "id" : 278247063391707137,
  "created_at" : "2012-12-10 21:17:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278244565452984320",
  "geo" : { },
  "id_str" : "278245922624921600",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl she's a female - they aren't meant to like such a film :)",
  "id" : 278245922624921600,
  "in_reply_to_status_id" : 278244565452984320,
  "created_at" : "2012-12-10 21:12:52 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278242341477838849",
  "geo" : { },
  "id_str" : "278242811499925504",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl scrooges yes - but Die Hard is the second best christmas movie ever. With Santa Claus: The Movie (first half) the bestest! :)",
  "id" : 278242811499925504,
  "in_reply_to_status_id" : 278242341477838849,
  "created_at" : "2012-12-10 21:00:30 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278242128570757120",
  "text" : "Yesterday there was Elf - now Die Hard and in Belfast all day tomorrow Christmas Shopping with me Mum (yearly tradition). I &lt;3 Christmas.",
  "id" : 278242128570757120,
  "created_at" : "2012-12-10 20:57:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278236165381967872",
  "geo" : { },
  "id_str" : "278236453098643457",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco No dice.. I go - you go! :)",
  "id" : 278236453098643457,
  "in_reply_to_status_id" : 278236165381967872,
  "created_at" : "2012-12-10 20:35:14 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278228588355002368",
  "text" : "Yeah - first the kitchen now my chimney... I'm going to be on fire soon at this rate..",
  "id" : 278228588355002368,
  "created_at" : "2012-12-10 20:03:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "glenavy",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 102 ],
      "url" : "https:\/\/t.co\/7eE7lbot",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=10151192121087690&set=a.10150343905912690.355847.205782262689&type=1&theater",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278186936491991040",
  "text" : "Sammy Bickerstaff is a 80+ year old shop keeper. Lovely man. Cowards and scum :( https:\/\/t.co\/7eE7lbot #glenavy",
  "id" : 278186936491991040,
  "created_at" : "2012-12-10 17:18:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kj wojciechowski",
      "screen_name" : "kjfxmonk",
      "indices" : [ 3, 12 ],
      "id_str" : "68755388",
      "id" : 68755388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278186384144089088",
  "text" : "RT @kjfxmonk: Google products down accross the board... Chrome, Gmail, Drive, all taking a crap at once. Skynet is awake and self-aware. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278182365677903872",
    "text" : "Google products down accross the board... Chrome, Gmail, Drive, all taking a crap at once. Skynet is awake and self-aware. The end is near.",
    "id" : 278182365677903872,
    "created_at" : "2012-12-10 17:00:19 +0000",
    "user" : {
      "name" : "kj wojciechowski",
      "screen_name" : "kjfxmonk",
      "protected" : false,
      "id_str" : "68755388",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3428201261\/d12abd8979a2e73bb3a9a99536cec0cf_normal.jpeg",
      "id" : 68755388,
      "verified" : false
    }
  },
  "id" : 278186384144089088,
  "created_at" : "2012-12-10 17:16:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278185153812127745",
  "geo" : { },
  "id_str" : "278185352722800641",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop Aye - probably some infrastructure issue or summit - I am on 23.0.1271.95",
  "id" : 278185352722800641,
  "in_reply_to_status_id" : 278185153812127745,
  "created_at" : "2012-12-10 17:12:11 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 103, 109 ],
      "id_str" : "38679388",
      "id" : 38679388
    }, {
      "name" : "Google Chrome",
      "screen_name" : "googlechrome",
      "indices" : [ 113, 126 ],
      "id_str" : "56505125",
      "id" : 56505125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278185077958127617",
  "text" : "Just a quick look through twitter there and people going nuts.. Calm down - you pay nothing for either @gmail or @googlechrome",
  "id" : 278185077958127617,
  "created_at" : "2012-12-10 17:11:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278184369053650944",
  "geo" : { },
  "id_str" : "278184820838907904",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop seems a common complaint at the mo. Grrrrrrr :) But what you want for free :)",
  "id" : 278184820838907904,
  "in_reply_to_status_id" : 278184369053650944,
  "created_at" : "2012-12-10 17:10:04 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278184655235211264",
  "text" : "So its not just me then - plus gmail is down... Think this means Monday is officially over - still owe a few hours but will do that after 8.",
  "id" : 278184655235211264,
  "created_at" : "2012-12-10 17:09:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    }, {
      "name" : "Firefox",
      "screen_name" : "firefox",
      "indices" : [ 10, 18 ],
      "id_str" : "2142731",
      "id" : 2142731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278184276346953728",
  "geo" : { },
  "id_str" : "278184503057477632",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr @firefox ah right so its just not me then... cheers :)",
  "id" : 278184503057477632,
  "in_reply_to_status_id" : 278184276346953728,
  "created_at" : "2012-12-10 17:08:48 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278183884598951936",
  "geo" : { },
  "id_str" : "278184103688425473",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight :) Sssssssshhhhhhhhhh",
  "id" : 278184103688425473,
  "in_reply_to_status_id" : 278183884598951936,
  "created_at" : "2012-12-10 17:07:13 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278184006653206528",
  "text" : "Anyone else on a Mac (Mountain Lion) that is getting Chrome quitting on them reguarly. Seems to have started today only.",
  "id" : 278184006653206528,
  "created_at" : "2012-12-10 17:06:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278167403882491904",
  "geo" : { },
  "id_str" : "278178247496318976",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 Getting the battery is the hard part as no car :) Battery is now fitted - car going again :)",
  "id" : 278178247496318976,
  "in_reply_to_status_id" : 278167403882491904,
  "created_at" : "2012-12-10 16:43:57 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278178133688082433",
  "text" : "Battery fitted - hands now frozen... It is cold outside!",
  "id" : 278178133688082433,
  "created_at" : "2012-12-10 16:43:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278160538087858178",
  "text" : "Hmmm still waiting on the dude coming down to fit this battery... Well I am not going anywhere like but still he said 30mins!",
  "id" : 278160538087858178,
  "created_at" : "2012-12-10 15:33:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278148827473661952",
  "geo" : { },
  "id_str" : "278158672721485824",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin no no no no no no no no :)",
  "id" : 278158672721485824,
  "in_reply_to_status_id" : 278148827473661952,
  "created_at" : "2012-12-10 15:26:10 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278147918165327872",
  "geo" : { },
  "id_str" : "278156225013743616",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 apparently this is a heavy hitting one again. So it should do me - this one seen through the last three winters so meh..",
  "id" : 278156225013743616,
  "in_reply_to_status_id" : 278147918165327872,
  "created_at" : "2012-12-10 15:16:26 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278142556888518656",
  "geo" : { },
  "id_str" : "278143098054402048",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel this car works - it was the battery.... I hope so anyway - dude is coming to fix it now. Then I am mobile again! :)",
  "id" : 278143098054402048,
  "in_reply_to_status_id" : 278142556888518656,
  "created_at" : "2012-12-10 14:24:16 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278140320720494592",
  "text" : "Number of times I fell.. 0 - still took out 100quid that I didn't know about for a fucking battery so not happy.",
  "id" : 278140320720494592,
  "created_at" : "2012-12-10 14:13:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278134732334710784",
  "text" : "Fuck sake\u2026 60quid for a car batter + call + fitting\u2026 Add this to the walk to the ATM machine :( Grrrrrrr\u2026..",
  "id" : 278134732334710784,
  "created_at" : "2012-12-10 13:51:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drivingmenuts",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 116 ],
      "url" : "https:\/\/t.co\/WChHiiUL",
      "expanded_url" : "https:\/\/answers.atlassian.com\/questions\/48140\/disable-emoticons",
      "display_url" : "answers.atlassian.com\/questions\/4814\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278118217984126977",
  "text" : "This is how you stop emoticons coming up on the confluence header. Might be off use to others. https:\/\/t.co\/WChHiiUL #drivingmenuts",
  "id" : 278118217984126977,
  "created_at" : "2012-12-10 12:45:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278099038665072640",
  "text" : "Listening to podcasts and writing documentation from home isn't too bad\u2026 Just hope it is the battery on that car :(",
  "id" : 278099038665072640,
  "created_at" : "2012-12-10 11:29:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277878125319319552",
  "geo" : { },
  "id_str" : "277883857884286976",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin I agree. They could have done more with it.",
  "id" : 277883857884286976,
  "in_reply_to_status_id" : 277878125319319552,
  "created_at" : "2012-12-09 21:14:09 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 89, 102 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277872253054627840",
  "text" : "I'm old. Watched One Direction there and thought they had way too many tattoos. Ahh well @Paul_Moffett is 34 in a few days so he's older",
  "id" : 277872253054627840,
  "created_at" : "2012-12-09 20:28:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277770867084259329",
  "text" : "Just booked my car in to get fixed the week after Christmas. Got a bollocking from the fella that fixes her.",
  "id" : 277770867084259329,
  "created_at" : "2012-12-09 13:45:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277729917066698752",
  "geo" : { },
  "id_str" : "277735792238022656",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid Aye that's another one... Pissing me off.. Who to use now....",
  "id" : 277735792238022656,
  "in_reply_to_status_id" : 277729917066698752,
  "created_at" : "2012-12-09 11:25:47 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/LTDQnnQA",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=L6Z0cd70_gA",
      "display_url" : "youtube.com\/watch?v=L6Z0cd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277734689417068546",
  "text" : "Fuck. Right. Off. http:\/\/t.co\/LTDQnnQA",
  "id" : 277734689417068546,
  "created_at" : "2012-12-09 11:21:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277379762719166464",
  "geo" : { },
  "id_str" : "277380677069066240",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore it is pathetic. On the busiest day of the year for retailers too.",
  "id" : 277380677069066240,
  "in_reply_to_status_id" : 277379762719166464,
  "created_at" : "2012-12-08 11:54:41 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277247990379454464",
  "text" : "religion. It's just scum wanting to riot cos they have nothing else better to do.",
  "id" : 277247990379454464,
  "created_at" : "2012-12-08 03:07:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "couldcareless",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277247743808909312",
  "text" : "I consider myself a pro-union person. But I've more important things to worry about than a flag :) #couldcareless And it's not about..",
  "id" : 277247743808909312,
  "created_at" : "2012-12-08 03:06:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277247357731610624",
  "text" : "Number of idiot (fuckwits) I just unfollowed cos they are saying stupid things about flag protests - 3. Zero tolerance for fuckwittery.",
  "id" : 277247357731610624,
  "created_at" : "2012-12-08 03:04:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 1, 8 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 10, 16 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 21, 28 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277197233353539584",
  "text" : "\u201C@srushe: @swmcc and @github sitting in a tree, F-O-R-K-I-N-G...\u201D Awesome, awesome :D I've got a huge company crush on them, I admit it :)",
  "id" : 277197233353539584,
  "created_at" : "2012-12-07 23:45:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 1, 8 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277196020755083264",
  "text" : "\u201C@github: Oh, and if you're using Chrome, you can now paste an image into the comment box to upload it!\u201D I really &lt;3 this company.",
  "id" : 277196020755083264,
  "created_at" : "2012-12-07 23:40:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277191957535678464",
  "geo" : { },
  "id_str" : "277195602864001024",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore wanna get my Dad started on it. Does my nut in. We really a country equivalent of Red Dwarf.",
  "id" : 277195602864001024,
  "in_reply_to_status_id" : 277191957535678464,
  "created_at" : "2012-12-07 23:39:16 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Northern Ireland",
      "screen_name" : "BBCnireland",
      "indices" : [ 6, 18 ],
      "id_str" : "1451312228",
      "id" : 1451312228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277156049771974656",
  "text" : "Hmmmm @bbcnireland news just refered to Hilary Clinton as \"Former First Lady\" - she's the current Sec of State. That trumps FFL.",
  "id" : 277156049771974656,
  "created_at" : "2012-12-07 21:02:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277107813673734144",
  "text" : "Just home from a few days in London there with work. Fire just lit and ignoring any voicemails left on the house phone.",
  "id" : 277107813673734144,
  "created_at" : "2012-12-07 17:50:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 40, 51 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/TCFAzXeK",
      "expanded_url" : "http:\/\/4sq.com\/RH0wlA",
      "display_url" : "4sq.com\/RH0wlA"
    } ]
  },
  "geo" : { },
  "id_str" : "277051669852852225",
  "text" : "I just unlocked the \"Explorer\" badge on @foursquare for checking in to twenty-five different places! http:\/\/t.co\/TCFAzXeK",
  "id" : 277051669852852225,
  "created_at" : "2012-12-07 14:07:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276755699885801474",
  "geo" : { },
  "id_str" : "276796567535632384",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates where are you idiots? Just back at the hotel.",
  "id" : 276796567535632384,
  "in_reply_to_status_id" : 276755699885801474,
  "created_at" : "2012-12-06 21:13:38 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276752876502646784",
  "geo" : { },
  "id_str" : "276753421871218688",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates with some nerds here. So will catchup then. Don't be drinking too much in my absence :)",
  "id" : 276753421871218688,
  "in_reply_to_status_id" : 276752876502646784,
  "created_at" : "2012-12-06 18:22:12 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276752876502646784",
  "geo" : { },
  "id_str" : "276753167205675008",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates nice one. My 'art deco' 3GS ran out of juice so will have to charge it up at the hotel etc. Heading out for a bite to eat..",
  "id" : 276753167205675008,
  "in_reply_to_status_id" : 276752876502646784,
  "created_at" : "2012-12-06 18:21:11 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Kenny",
      "screen_name" : "bkenny",
      "indices" : [ 0, 7 ],
      "id_str" : "12585212",
      "id" : 12585212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276751480726380544",
  "geo" : { },
  "id_str" : "276751787887845376",
  "in_reply_to_user_id" : 12585212,
  "text" : "@bkenny wrong :) Dead wrong :) Just a different way of doing things. I would much prefer Ubuntu over Windows. YYMV though :)",
  "id" : 276751787887845376,
  "in_reply_to_status_id" : 276751480726380544,
  "created_at" : "2012-12-06 18:15:42 +0000",
  "in_reply_to_screen_name" : "bkenny",
  "in_reply_to_user_id_str" : "12585212",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 14, 22 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 23, 36 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 37, 46 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276750770802671616",
  "geo" : { },
  "id_str" : "276751141759500288",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates @jbrevel @Paul_Moffett @davehedo I'll be a while yet I would say - so will catch up with you lot laters..",
  "id" : 276751141759500288,
  "in_reply_to_status_id" : 276750770802671616,
  "created_at" : "2012-12-06 18:13:08 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Wilkie",
      "screen_name" : "tom_wilkie",
      "indices" : [ 0, 11 ],
      "id_str" : "21584407",
      "id" : 21584407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276744890761764867",
  "geo" : { },
  "id_str" : "276745370959220736",
  "in_reply_to_user_id" : 21584407,
  "text" : "@tom_wilkie Your welcome. If you are about after the RIak talk I'd like to ask you some questions, if not no worries :)",
  "id" : 276745370959220736,
  "in_reply_to_status_id" : 276744890761764867,
  "created_at" : "2012-12-06 17:50:12 +0000",
  "in_reply_to_screen_name" : "tom_wilkie",
  "in_reply_to_user_id_str" : "21584407",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Wilkie",
      "screen_name" : "tom_wilkie",
      "indices" : [ 14, 25 ],
      "id_str" : "21584407",
      "id" : 21584407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nosqlroadshow",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276740618133327872",
  "text" : "Great talk by @tom_wilkie about Cassandra... #nosqlroadshow",
  "id" : 276740618133327872,
  "created_at" : "2012-12-06 17:31:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nosqlroadshow",
      "indices" : [ 52, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276734462665031680",
  "text" : "Realtime Analytics with Apache Cassandra :D Awesome #nosqlroadshow",
  "id" : 276734462665031680,
  "created_at" : "2012-12-06 17:06:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 74, 82 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276667410545770497",
  "text" : "Battery going on phone. If anyone at Repknight want to get in contact use @jbrevel phone",
  "id" : 276667410545770497,
  "created_at" : "2012-12-06 12:40:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nosqlroadshow",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "noselling",
      "indices" : [ 74, 84 ]
    }, {
      "text" : "brilliant",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276663897291898881",
  "text" : "#nosqlroadshow Choosing the right database to move big data in real time. #noselling #brilliant",
  "id" : 276663897291898881,
  "created_at" : "2012-12-06 12:26:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Webber",
      "screen_name" : "jimwebber",
      "indices" : [ 20, 30 ],
      "id_str" : "13521812",
      "id" : 13521812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nosqlroadshow",
      "indices" : [ 31, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276652267149611008",
  "text" : "Really good talk by @jimwebber #nosqlroadshow",
  "id" : 276652267149611008,
  "created_at" : "2012-12-06 11:40:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276641110934319104",
  "geo" : { },
  "id_str" : "276641395127750656",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden interesting though very interesting",
  "id" : 276641395127750656,
  "in_reply_to_status_id" : 276641110934319104,
  "created_at" : "2012-12-06 10:57:03 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nosqlroadshow",
      "indices" : [ 40, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276640120130654208",
  "text" : "Looking forward to the Jim Webber talk. #nosqlroadshow",
  "id" : 276640120130654208,
  "created_at" : "2012-12-06 10:51:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276616791101423616",
  "geo" : { },
  "id_str" : "276631432246472704",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid :) Yup :)",
  "id" : 276631432246472704,
  "in_reply_to_status_id" : 276616791101423616,
  "created_at" : "2012-12-06 10:17:27 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nosqlroadshow",
      "indices" : [ 42, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276616021618618368",
  "text" : "Geeking it up at the NOSQL Roadshow Conf. #nosqlroadshow.",
  "id" : 276616021618618368,
  "created_at" : "2012-12-06 09:16:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 9, 22 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 23, 30 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "surething",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276391800036536322",
  "geo" : { },
  "id_str" : "276393925223256064",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @nicholabates @rejoco I was right beside you! #surething",
  "id" : 276393925223256064,
  "in_reply_to_status_id" : 276391800036536322,
  "created_at" : "2012-12-05 18:33:41 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 9, 16 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 17, 30 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276388169488953344",
  "geo" : { },
  "id_str" : "276390196088553473",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @rejoco @nicholabates no mile high club points either :(",
  "id" : 276390196088553473,
  "in_reply_to_status_id" : 276388169488953344,
  "created_at" : "2012-12-05 18:18:52 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 41, 52 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/HoJLRsyc",
      "expanded_url" : "http:\/\/4sq.com\/XqX0NR",
      "display_url" : "4sq.com\/XqX0NR"
    } ]
  },
  "geo" : { },
  "id_str" : "276388087158947841",
  "text" : "I just unlocked the \"JetSetter\" badge on @foursquare for checking in at airports! Bon Voyage! http:\/\/t.co\/HoJLRsyc",
  "id" : 276388087158947841,
  "created_at" : "2012-12-05 18:10:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gnip, Inc.",
      "screen_name" : "gnip",
      "indices" : [ 3, 8 ],
      "id_str" : "16958875",
      "id" : 16958875
    }, {
      "name" : "Gnip, Inc.",
      "screen_name" : "gnip",
      "indices" : [ 42, 47 ],
      "id_str" : "16958875",
      "id" : 16958875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialdata",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276069858758778880",
  "text" : "RT @gnip: Today we launched Plugged In To @Gnip with 13 partners. We believe this will shine a much needed light on #socialdata http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gnip, Inc.",
        "screen_name" : "gnip",
        "indices" : [ 32, 37 ],
        "id_str" : "16958875",
        "id" : 16958875
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socialdata",
        "indices" : [ 106, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/tawqdqvH",
        "expanded_url" : "http:\/\/bit.ly\/Vu683M",
        "display_url" : "bit.ly\/Vu683M"
      } ]
    },
    "geo" : { },
    "id_str" : "276061764792242176",
    "text" : "Today we launched Plugged In To @Gnip with 13 partners. We believe this will shine a much needed light on #socialdata http:\/\/t.co\/tawqdqvH",
    "id" : 276061764792242176,
    "created_at" : "2012-12-04 20:33:48 +0000",
    "user" : {
      "name" : "Gnip, Inc.",
      "screen_name" : "gnip",
      "protected" : false,
      "id_str" : "16958875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2439636286\/xvakulxcrzzbl1cjtm6w_normal.jpeg",
      "id" : 16958875,
      "verified" : true
    }
  },
  "id" : 276069858758778880,
  "created_at" : "2012-12-04 21:05:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276063461140738049",
  "geo" : { },
  "id_str" : "276069741758672896",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl it's probably just that. But on the off chance it might be something good ill spam myself :)",
  "id" : 276069741758672896,
  "in_reply_to_status_id" : 276063461140738049,
  "created_at" : "2012-12-04 21:05:30 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlassian HipChat",
      "screen_name" : "HipChat",
      "indices" : [ 46, 54 ],
      "id_str" : "17810599",
      "id" : 17810599
    }, {
      "name" : "Atlassian HipChat",
      "screen_name" : "HipChat",
      "indices" : [ 124, 132 ],
      "id_str" : "17810599",
      "id" : 17810599
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipchatbeta",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/0GB3Gpoa",
      "expanded_url" : "http:\/\/lnc.hr\/jF8G",
      "display_url" : "lnc.hr\/jF8G"
    } ]
  },
  "geo" : { },
  "id_str" : "276058229136584704",
  "text" : "There's something in the AIR. Sign up for the @HipChat private beta to find out more. #hipchatbeta http:\/\/t.co\/0GB3Gpoa via @hipchat",
  "id" : 276058229136584704,
  "created_at" : "2012-12-04 20:19:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 4, 11 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "policeacademy",
      "indices" : [ 58, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276012926186446848",
  "text" : "And @szlwzl starts a rumour about the rioting in belfast\u2026 #policeacademy",
  "id" : 276012926186446848,
  "created_at" : "2012-12-04 17:19:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276009299866685443",
  "geo" : { },
  "id_str" : "276010432081321984",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl *FISTPUMP*",
  "id" : 276010432081321984,
  "in_reply_to_status_id" : 276009299866685443,
  "created_at" : "2012-12-04 17:09:49 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276010336690257920",
  "text" : "RT @szlwzl: Here, you ignorant rioting fuckwits, my wife wants to get home from East Belfast and you're being dicks. Please stop it imme ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "276009299866685443",
    "text" : "Here, you ignorant rioting fuckwits, my wife wants to get home from East Belfast and you're being dicks. Please stop it immediately.",
    "id" : 276009299866685443,
    "created_at" : "2012-12-04 17:05:19 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 276010336690257920,
  "created_at" : "2012-12-04 17:09:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275947957940019203",
  "text" : "Jira isn't allowing me to close an issue and its pissed me off\u2026",
  "id" : 275947957940019203,
  "created_at" : "2012-12-04 13:01:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 42, 53 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/PVJLjZ7H",
      "expanded_url" : "http:\/\/4sq.com\/VvgfBG",
      "display_url" : "4sq.com\/VvgfBG"
    } ]
  },
  "geo" : { },
  "id_str" : "275907167503122432",
  "text" : "I just unlocked the \"Super User\" badge on @foursquare for checking in thirty times in a month! http:\/\/t.co\/PVJLjZ7H",
  "id" : 275907167503122432,
  "created_at" : "2012-12-04 10:19:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275717791120760832",
  "geo" : { },
  "id_str" : "275718507113623552",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore fair play to them I say. I wish I had fuck all else to worry about than what flag flies above a building..",
  "id" : 275718507113623552,
  "in_reply_to_status_id" : 275717791120760832,
  "created_at" : "2012-12-03 21:49:49 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaryMcCall",
      "screen_name" : "MaryTreatTicket",
      "indices" : [ 3, 19 ],
      "id_str" : "512178113",
      "id" : 512178113
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TreatTicketMobile",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275717050125660160",
  "text" : "RT @MaryTreatTicket: Big push on at TT HQ tonight loading on all the great discounts from onto #TreatTicketMobile.  Local businesses can ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TreatTicketMobile",
        "indices" : [ 74, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275708516319244289",
    "text" : "Big push on at TT HQ tonight loading on all the great discounts from onto #TreatTicketMobile.  Local businesses can go live from Thursday!",
    "id" : 275708516319244289,
    "created_at" : "2012-12-03 21:10:07 +0000",
    "user" : {
      "name" : "MaryMcCall",
      "screen_name" : "MaryTreatTicket",
      "protected" : false,
      "id_str" : "512178113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3148644315\/8ada3385a4d205a8df2416d56b1b6687_normal.jpeg",
      "id" : 512178113,
      "verified" : false
    }
  },
  "id" : 275717050125660160,
  "created_at" : "2012-12-03 21:44:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275716687721033729",
  "text" : "Fucking hell - Cutty (from the wire) is on The Walking Dead.. Those zombies be fucked now!!! :D :D :D The Walking Dead just got better!",
  "id" : 275716687721033729,
  "created_at" : "2012-12-03 21:42:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/275685837293895680\/photo\/1",
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/7xwyQgHU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9NuzvICQAAgBZK.jpg",
      "id_str" : "275685837302284288",
      "id" : 275685837302284288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9NuzvICQAAgBZK.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/7xwyQgHU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275685837293895680",
  "text" : "The sisters presbyterian genes are failing her. http:\/\/t.co\/7xwyQgHU",
  "id" : 275685837293895680,
  "created_at" : "2012-12-03 19:40:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275668476981563392",
  "text" : "\/me downs tools for the day (3 to go before 8000 tweets) ;)",
  "id" : 275668476981563392,
  "created_at" : "2012-12-03 18:31:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slim PHP Framework",
      "screen_name" : "slimphp",
      "indices" : [ 9, 17 ],
      "id_str" : "210700684",
      "id" : 210700684
    }, {
      "name" : "Sinatra",
      "screen_name" : "sinatra",
      "indices" : [ 89, 97 ],
      "id_str" : "19694454",
      "id" : 19694454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275664234879258624",
  "text" : "You know @slimphp isn't half bad you know.. I quite like it. Then anything that emulates @sinatra is always going to be good.",
  "id" : 275664234879258624,
  "created_at" : "2012-12-03 18:14:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 11, 24 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 25, 33 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 34, 41 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 42, 51 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 52, 65 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275643580238950400",
  "geo" : { },
  "id_str" : "275643816860590081",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @nicholabates @jbrevel @rejoco @davehedo @paul_moffett no, its cos you are a cock! ;)",
  "id" : 275643816860590081,
  "in_reply_to_status_id" : 275643580238950400,
  "created_at" : "2012-12-03 16:53:01 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 10, 23 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 24, 32 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 33, 43 ],
      "id_str" : "240194412",
      "id" : 240194412
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 44, 51 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 52, 65 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275637405241978880",
  "geo" : { },
  "id_str" : "275637635823828992",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo @nicholabates @jbrevel @RepKnight @rejoco @Paul_Moffett  you lot are fucking nuts... I aint going anywhere with you lot again! :)",
  "id" : 275637635823828992,
  "in_reply_to_status_id" : 275637405241978880,
  "created_at" : "2012-12-03 16:28:28 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275634313641467904",
  "text" : "Oul William knocked one out of the boat! :)",
  "id" : 275634313641467904,
  "created_at" : "2012-12-03 16:15:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 3, 10 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 22, 28 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rejoco\/status\/275542774357569536\/photo\/1",
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/BVwTKpye",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9LssYJCMAE7Qtx.jpg",
      "id_str" : "275542774361763841",
      "id" : 275542774361763841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9LssYJCMAE7Qtx.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BVwTKpye"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275543044391059456",
  "text" : "RT @rejoco: Never get @swmcc to cut your hair, unless you want a big bit missed http:\/\/t.co\/BVwTKpye",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 10, 16 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rejoco\/status\/275542774357569536\/photo\/1",
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/BVwTKpye",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A9LssYJCMAE7Qtx.jpg",
        "id_str" : "275542774361763841",
        "id" : 275542774361763841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9LssYJCMAE7Qtx.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BVwTKpye"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275542774357569536",
    "text" : "Never get @swmcc to cut your hair, unless you want a big bit missed http:\/\/t.co\/BVwTKpye",
    "id" : 275542774357569536,
    "created_at" : "2012-12-03 10:11:31 +0000",
    "user" : {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "protected" : false,
      "id_str" : "53053999",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000167317834\/6219cabb0a7785ac8acd656a39be2ab9_normal.jpeg",
      "id" : 53053999,
      "verified" : false
    }
  },
  "id" : 275543044391059456,
  "created_at" : "2012-12-03 10:12:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275362839563231232",
  "geo" : { },
  "id_str" : "275362959788748800",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard I'm just putting it on now... looking forward to it.",
  "id" : 275362959788748800,
  "in_reply_to_status_id" : 275362839563231232,
  "created_at" : "2012-12-02 22:17:00 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275361299184095232",
  "geo" : { },
  "id_str" : "275362545899012096",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin that was it - amazing screen. The size of it is a bit of a worry but in an office enviro is welcome. But you WFH so again YMMV",
  "id" : 275362545899012096,
  "in_reply_to_status_id" : 275361299184095232,
  "created_at" : "2012-12-02 22:15:21 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275359905630806016",
  "geo" : { },
  "id_str" : "275360526882713600",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin mainly cos I am anal and can't go beyond 80 characters a line though. YMMV",
  "id" : 275360526882713600,
  "in_reply_to_status_id" : 275359905630806016,
  "created_at" : "2012-12-02 22:07:20 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275359905630806016",
  "geo" : { },
  "id_str" : "275360381436850176",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin I had a 27\" in my last place - was awesome. I personally wouldn't spend my money on it though - 13\" does me quite nicely.",
  "id" : 275360381436850176,
  "in_reply_to_status_id" : 275359905630806016,
  "created_at" : "2012-12-02 22:06:45 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275356550049181696",
  "geo" : { },
  "id_str" : "275357072089026560",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll on a Sunday night? cheeky! But I like :)",
  "id" : 275357072089026560,
  "in_reply_to_status_id" : 275356550049181696,
  "created_at" : "2012-12-02 21:53:36 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275248226133737472",
  "geo" : { },
  "id_str" : "275257910387425280",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 sounds like dedication. I am impressed.",
  "id" : 275257910387425280,
  "in_reply_to_status_id" : 275248226133737472,
  "created_at" : "2012-12-02 15:19:34 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/pEU4K0ZQ",
      "expanded_url" : "http:\/\/yfrog.com\/h2eitmp",
      "display_url" : "yfrog.com\/h2eitmp"
    } ]
  },
  "geo" : { },
  "id_str" : "275256914277969923",
  "text" : "I am reading this book. And every time I see the word 'schemaless' I read it as 'she males'\u2026 I have issues... http:\/\/t.co\/pEU4K0ZQ",
  "id" : 275256914277969923,
  "created_at" : "2012-12-02 15:15:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/d5QjwxIE",
      "expanded_url" : "http:\/\/s3-ec.buzzfed.com\/static\/enhanced\/terminal05\/2012\/5\/3\/22\/enhanced-buzz-21487-1336099394-0.jpg",
      "display_url" : "s3-ec.buzzfed.com\/static\/enhance\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "275008441406353408",
  "geo" : { },
  "id_str" : "275009257101996032",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl http:\/\/t.co\/d5QjwxIE",
  "id" : 275009257101996032,
  "in_reply_to_status_id" : 275008441406353408,
  "created_at" : "2012-12-01 22:51:30 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275006859482636288",
  "geo" : { },
  "id_str" : "275007756556185600",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl perl -MCPAN -e \"install ''\" Awwww I miss it :) npm search is my friend now though. Yup a bit hipsterish but sure :)",
  "id" : 275007756556185600,
  "in_reply_to_status_id" : 275006859482636288,
  "created_at" : "2012-12-01 22:45:33 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275005519574495232",
  "geo" : { },
  "id_str" : "275006519056158720",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett don't worry Moffett - it'll be okay :)",
  "id" : 275006519056158720,
  "in_reply_to_status_id" : 275005519574495232,
  "created_at" : "2012-12-01 22:40:38 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 8, 21 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldskoolprogrammer",
      "indices" : [ 108, 127 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275005694070108160",
  "geo" : { },
  "id_str" : "275006134207778817",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @paul_moffett Python it would still be booting up.. If it was PERL it'd have been done yesterday :) #oldskoolprogrammer :)",
  "id" : 275006134207778817,
  "in_reply_to_status_id" : 275005694070108160,
  "created_at" : "2012-12-01 22:39:06 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itisokkatedoesnotchecktwitter",
      "indices" : [ 105, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275004632433057792",
  "geo" : { },
  "id_str" : "275005045848805376",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett I remember when Paul was 15 at badminton club and he \u2026. or one time at Mairi Law's house \u2026 #itisokkatedoesnotchecktwitter ;)",
  "id" : 275005045848805376,
  "in_reply_to_status_id" : 275004632433057792,
  "created_at" : "2012-12-01 22:34:46 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Golden",
      "screen_name" : "nancygolden572",
      "indices" : [ 0, 15 ],
      "id_str" : "72498429",
      "id" : 72498429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275004524882718721",
  "geo" : { },
  "id_str" : "275004723600441344",
  "in_reply_to_user_id" : 72498429,
  "text" : "@nancygolden572 thanks :D",
  "id" : 275004723600441344,
  "in_reply_to_status_id" : 275004524882718721,
  "created_at" : "2012-12-01 22:33:30 +0000",
  "in_reply_to_screen_name" : "nancygolden572",
  "in_reply_to_user_id_str" : "72498429",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 50, 63 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codingismucheasier",
      "indices" : [ 116, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275004279205531648",
  "text" : "Was trying to write the best man speech there for @paul_moffett - proving too hard so just spun up a new rails app. #codingismucheasier",
  "id" : 275004279205531648,
  "created_at" : "2012-12-01 22:31:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/274948217320386561\/photo\/1",
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/EO9BGxQU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9DP8mmCMAAD0Yd.jpg",
      "id_str" : "274948217328775168",
      "id" : 274948217328775168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9DP8mmCMAAD0Yd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/EO9BGxQU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274948217320386561",
  "text" : "Merry first day of Christmas - now to light the fire and watch strictly :) http:\/\/t.co\/EO9BGxQU",
  "id" : 274948217320386561,
  "created_at" : "2012-12-01 18:48:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274912001015308288",
  "geo" : { },
  "id_str" : "274941778438811648",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit your air gave up the ghost?",
  "id" : 274941778438811648,
  "in_reply_to_status_id" : 274912001015308288,
  "created_at" : "2012-12-01 18:23:22 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274937974347669504",
  "geo" : { },
  "id_str" : "274941378503524352",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings Nope they wont allow you. They want you to use the app for that. Which is fair enough I suppose. Odd though.",
  "id" : 274941378503524352,
  "in_reply_to_status_id" : 274937974347669504,
  "created_at" : "2012-12-01 18:21:47 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debenhams",
      "screen_name" : "Debenhams",
      "indices" : [ 3, 13 ],
      "id_str" : "296196029",
      "id" : 296196029
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 15, 21 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274820084323737601",
  "text" : "RT @Debenhams: @swmcc Hi Stephen, do you require any assistance? If so contact heretohelp@debenhams.com and we can assist. Many thanks.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.conversocial.com\" rel=\"nofollow\"\u003EConversocial\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "274570511458107392",
    "geo" : { },
    "id_str" : "274791541862699008",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Hi Stephen, do you require any assistance? If so contact heretohelp@debenhams.com and we can assist. Many thanks.",
    "id" : 274791541862699008,
    "in_reply_to_status_id" : 274570511458107392,
    "created_at" : "2012-12-01 08:26:23 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Debenhams",
      "screen_name" : "Debenhams",
      "protected" : false,
      "id_str" : "296196029",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000532729659\/c8f5beb056f34702a34add3943dae3c3_normal.jpeg",
      "id" : 296196029,
      "verified" : true
    }
  },
  "id" : 274820084323737601,
  "created_at" : "2012-12-01 10:19:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]