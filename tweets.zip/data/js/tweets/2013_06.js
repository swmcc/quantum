Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351372724368707584",
  "text" : "\"Steps\" just came on our spotify playlist in the office.. This makes me happy! :D",
  "id" : 351372724368707584,
  "created_at" : "2013-06-30 16:12:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 103, 111 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 116, 125 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351372094321344512",
  "text" : "OH: \"You are crushing my cock!\" - I don't name my OH's. On an unrelated note. I spent all weekend with @jbrevel and @davehedo #justsayin",
  "id" : 351372094321344512,
  "created_at" : "2013-06-30 16:10:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351344077633097728",
  "text" : "Head busted - gonna clean the kitchen to see if that helps.",
  "id" : 351344077633097728,
  "created_at" : "2013-06-30 14:18:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 38, 46 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 72, 81 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icantthinkofagoodhash",
      "indices" : [ 117, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351314866344173571",
  "text" : "OH: \"The results page is 366GB?!?!?!\" @jbrevel starting to go nuts when @davehedo said about backing his machine up! #icantthinkofagoodhash",
  "id" : 351314866344173571,
  "created_at" : "2013-06-30 12:22:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/351300050774814720\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/f1nLyQq8K5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOARiPCCcAA8jOZ.jpg",
      "id_str" : "351300050783203328",
      "id" : 351300050783203328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOARiPCCcAA8jOZ.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/f1nLyQq8K5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351300050774814720",
  "text" : "RepKnight Sunday brunch http:\/\/t.co\/f1nLyQq8K5",
  "id" : 351300050774814720,
  "created_at" : "2013-06-30 11:23:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlassian HipChat",
      "screen_name" : "HipChat",
      "indices" : [ 11, 19 ],
      "id_str" : "17810599",
      "id" : 17810599
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/351098966424834048\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/9UcuEkzQGt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN9apleCUAAy4dn.png",
      "id_str" : "351098966437416960",
      "id" : 351098966437416960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN9apleCUAAy4dn.png",
      "sizes" : [ {
        "h" : 93,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 1149
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 53,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9UcuEkzQGt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351098966424834048",
  "text" : "Late night @hipchat conversations from the office :) http:\/\/t.co\/9UcuEkzQGt",
  "id" : 351098966424834048,
  "created_at" : "2013-06-29 22:04:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351005795233693697",
  "text" : "Fucking cunting internet just fucking work!!!!!!",
  "id" : 351005795233693697,
  "created_at" : "2013-06-29 15:54:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 13, 26 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350624865641967617",
  "geo" : { },
  "id_str" : "350625533723287553",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid @Paul_Moffett :D Next Friday :)",
  "id" : 350625533723287553,
  "in_reply_to_status_id" : 350624865641967617,
  "created_at" : "2013-06-28 14:43:36 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 31, 44 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/350624017213952000\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/RvbeNbjIjW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN2qr5wCEAAI0OC.png",
      "id_str" : "350624017218146304",
      "id" : 350624017218146304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN2qr5wCEAAI0OC.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 132,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 829
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 829
      } ],
      "display_url" : "pic.twitter.com\/RvbeNbjIjW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350624017213952000",
  "text" : "Friday afternoon imessage with @Paul_Moffett always ends up like this... http:\/\/t.co\/RvbeNbjIjW",
  "id" : 350624017213952000,
  "created_at" : "2013-06-28 14:37:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "falseeconomy",
      "indices" : [ 103, 116 ]
    }, {
      "text" : "hadtobedonethough",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350610227877527552",
  "text" : "Well.... 30 hours in and my brain has now decided to fuck off for the day :) Wasn't a bad wee stretch. #falseeconomy #hadtobedonethough",
  "id" : 350610227877527552,
  "created_at" : "2013-06-28 13:42:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 18, 28 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 29, 37 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 38, 47 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350376845788717057",
  "geo" : { },
  "id_str" : "350378338931585024",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @jasebell @smccalden @jbrevel @davehedo will all you lot fuck off - i have work to do! :)",
  "id" : 350378338931585024,
  "in_reply_to_status_id" : 350376845788717057,
  "created_at" : "2013-06-27 22:21:20 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 8, 18 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 19, 27 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 28, 37 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350375377056694272",
  "geo" : { },
  "id_str" : "350375627146276865",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @smccalden @jbrevel @davehedo to be fair Simon that's cos you are a cock.. Nothing to do with a football shirt ;)",
  "id" : 350375627146276865,
  "in_reply_to_status_id" : 350375377056694272,
  "created_at" : "2013-06-27 22:10:33 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 9, 19 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 20, 29 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350366930684739585",
  "geo" : { },
  "id_str" : "350369234951487489",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @smccalden @davehedo I'm working.. Don't understand football... Shite sport.",
  "id" : 350369234951487489,
  "in_reply_to_status_id" : 350366930684739585,
  "created_at" : "2013-06-27 21:45:09 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 54, 66 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thanksdebbie",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350360871207321601",
  "text" : "Coming up for air for a few mins to thank the amazing @DebbieCReid for bringing us beer.... And back to it :) #thanksdebbie",
  "id" : 350360871207321601,
  "created_at" : "2013-06-27 21:11:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350011364061872129",
  "geo" : { },
  "id_str" : "350014126367571969",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin annoyed I couldn\u2019t mark it. Am interested in seeing how its used in the wild. Ahh we\u2019ll YouTube it is :)",
  "id" : 350014126367571969,
  "in_reply_to_status_id" : 350011364061872129,
  "created_at" : "2013-06-26 22:14:05 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 10, 18 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 19, 32 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 33, 44 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350008262579589121",
  "geo" : { },
  "id_str" : "350010964281802755",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo @jbrevel @nicholabates @_MarkByrne stop teasing Dave - you face timed me this morning, don\u2019t lie :)",
  "id" : 350010964281802755,
  "in_reply_to_status_id" : 350008262579589121,
  "created_at" : "2013-06-26 22:01:31 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 14, 23 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 24, 35 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 36, 44 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349995755622240257",
  "geo" : { },
  "id_str" : "349998216726581249",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates @davehedo @_MarkByrne @jbrevel I sung to him as I was leaving for my lift home an hour ago :)",
  "id" : 349998216726581249,
  "in_reply_to_status_id" : 349995755622240257,
  "created_at" : "2013-06-26 21:10:52 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 12, 20 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nextweek",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349986361627000833",
  "geo" : { },
  "id_str" : "349986684785537025",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne @jbrevel don't get cunty :) your honeymoon period ends soon then you'll be fair game like the rest of us... #nextweek :)",
  "id" : 349986684785537025,
  "in_reply_to_status_id" : 349986361627000833,
  "created_at" : "2013-06-26 20:25:02 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349985788076896259",
  "text" : "Hope he's cut my grass also - doubt it like but you never know :)",
  "id" : 349985788076896259,
  "created_at" : "2013-06-26 20:21:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349985729809625088",
  "text" : "It is an odd feeling being in my mid thirties waiting for my Dad to come pick me up... One of the good things about living so close to them.",
  "id" : 349985729809625088,
  "created_at" : "2013-06-26 20:21:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 12, 20 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349985297578201088",
  "geo" : { },
  "id_str" : "349985563669037056",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne @jbrevel cheers Mark. Think me and Locko have it sorted though. Will be WFH in the morning then getting a 9am bus into Lisburn.",
  "id" : 349985563669037056,
  "in_reply_to_status_id" : 349985297578201088,
  "created_at" : "2013-06-26 20:20:35 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 3, 15 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/chCMNgFXcG",
      "expanded_url" : "http:\/\/digitalcircle.org\/events\/belfast-ruby-rails-400-whats-new",
      "display_url" : "digitalcircle.org\/events\/belfast\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349982405744013312",
  "text" : "RT @BelfastRuby: Want to find out more about Rails 4? Come to the meetup next Tuesday! http:\/\/t.co\/chCMNgFXcG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/chCMNgFXcG",
        "expanded_url" : "http:\/\/digitalcircle.org\/events\/belfast-ruby-rails-400-whats-new",
        "display_url" : "digitalcircle.org\/events\/belfast\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "349881423420858369",
    "text" : "Want to find out more about Rails 4? Come to the meetup next Tuesday! http:\/\/t.co\/chCMNgFXcG",
    "id" : 349881423420858369,
    "created_at" : "2013-06-26 13:26:46 +0000",
    "user" : {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "protected" : false,
      "id_str" : "454835425",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1752070239\/belfastruby-twitter-icon-2_normal.png",
      "id" : 454835425,
      "verified" : false
    }
  },
  "id" : 349982405744013312,
  "created_at" : "2013-06-26 20:08:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 86, 94 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349982295853236226",
  "text" : "My car picks a great time to fuck up.... Now looking at bus time tables and getting a @jbrevel taxi tomorrow from Lisburn..... :D",
  "id" : 349982295853236226,
  "created_at" : "2013-06-26 20:07:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Bee",
      "screen_name" : "iamsambee",
      "indices" : [ 3, 13 ],
      "id_str" : "271725689",
      "id" : 271725689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349916719608901632",
  "text" : "RT @iamsambee: Idea: let's just call it marriage now!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349901096241733632",
    "text" : "Idea: let's just call it marriage now!",
    "id" : 349901096241733632,
    "created_at" : "2013-06-26 14:44:56 +0000",
    "user" : {
      "name" : "Samantha Bee",
      "screen_name" : "iamsambee",
      "protected" : false,
      "id_str" : "271725689",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1286116233\/huntersam_normal.jpg",
      "id" : 271725689,
      "verified" : true
    }
  },
  "id" : 349916719608901632,
  "created_at" : "2013-06-26 15:47:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 25, 32 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodbosssesfeedtheirtroops",
      "indices" : [ 33, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349628035462479872",
  "text" : "Also thanks for the feed @rejoco #goodbosssesfeedtheirtroops",
  "id" : 349628035462479872,
  "created_at" : "2013-06-25 20:39:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349627813466341376",
  "text" : "Laptop left in the office - shower and sleep I think :)",
  "id" : 349627813466341376,
  "created_at" : "2013-06-25 20:39:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349627669807247363",
  "text" : "I am not committing it until tomorrow morning either - so then I start tomorrow on a 'win' :) Sure we all get days like this now and again.",
  "id" : 349627669807247363,
  "created_at" : "2013-06-25 20:38:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oneofthosedays",
      "indices" : [ 83, 98 ]
    }, {
      "text" : "timetogohomeandendonawin",
      "indices" : [ 99, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349627475229282304",
  "text" : "After being booted in the nuts this afternoon and evening I finally got a 'win' :) #oneofthosedays #timetogohomeandendonawin",
  "id" : 349627475229282304,
  "created_at" : "2013-06-25 20:37:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349449552778117120",
  "text" : "I wrote a helper script (and put it in \/tmp) and my laptop battery failed last night... Fuck sake....",
  "id" : 349449552778117120,
  "created_at" : "2013-06-25 08:50:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 12, 21 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349267154346053633",
  "geo" : { },
  "id_str" : "349267380691681280",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne @davehedo sounds good to me.. Too much talking on those things for my liking... A quick facetime will thin out the ranks a bit.",
  "id" : 349267380691681280,
  "in_reply_to_status_id" : 349267154346053633,
  "created_at" : "2013-06-24 20:46:47 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 27, 36 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AWESOME",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349265643062837255",
  "text" : "My new hobby - face timing @davehedo - I was in my wee work room when I first phoned him - then ended up in the bog. #AWESOME",
  "id" : 349265643062837255,
  "created_at" : "2013-06-24 20:39:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349236183517249537",
  "text" : "Ending the work day on a massive win :) Early start tomorrow :)",
  "id" : 349236183517249537,
  "created_at" : "2013-06-24 18:42:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349169719825276928",
  "text" : "Just back from a break there... If I don't solve this problem that has been plaguing me for the last hour - I'm jumping out the window!",
  "id" : 349169719825276928,
  "created_at" : "2013-06-24 14:18:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349136008580841472",
  "geo" : { },
  "id_str" : "349145190650490880",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues A double entrendre? I would have been classy and ignored it :)",
  "id" : 349145190650490880,
  "in_reply_to_status_id" : 349136008580841472,
  "created_at" : "2013-06-24 12:41:14 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349118440902107137",
  "text" : "I'm bouncing between groovy and sinatra today... My head will be well and truly fucked later.... Yup :) Parks and Rec for me later!",
  "id" : 349118440902107137,
  "created_at" : "2013-06-24 10:54:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 11, 20 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348919012765356032",
  "geo" : { },
  "id_str" : "348921098202660865",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @davehedo pair of wankers",
  "id" : 348921098202660865,
  "in_reply_to_status_id" : 348919012765356032,
  "created_at" : "2013-06-23 21:50:47 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imadick",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "alsomissyourhusband",
      "indices" : [ 104, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348908573062991872",
  "geo" : { },
  "id_str" : "348908938453987328",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues sorry - I've been snowed under lately - will send that email soon - lots to discuss. #imadick #alsomissyourhusband",
  "id" : 348908938453987328,
  "in_reply_to_status_id" : 348908573062991872,
  "created_at" : "2013-06-23 21:02:28 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 117, 126 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348908795126231041",
  "text" : "According to interwebs I am doing some beer and bazaar weekend in Manchester!!! Awesome.. All my friends (apart from @davehedo) are invited.",
  "id" : 348908795126231041,
  "created_at" : "2013-06-23 21:01:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The List",
      "screen_name" : "TheListMCR",
      "indices" : [ 3, 14 ],
      "id_str" : "1259490860",
      "id" : 1259490860
    }, {
      "name" : "Chorlton Bazaar",
      "screen_name" : "chorlton_bazaar",
      "indices" : [ 17, 33 ],
      "id_str" : "603964453",
      "id" : 603964453
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 38, 44 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeerAndBazaar",
      "indices" : [ 79, 93 ]
    }, {
      "text" : "Manchester",
      "indices" : [ 105, 116 ]
    }, {
      "text" : "IdealAfternoon",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348908517010313216",
  "text" : "RT @TheListMCR: .@Chorlton_Bazaar and @SWMCC have joined forces to present the #BeerAndBazaar weekend in #Manchester! #IdealAfternoon http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chorlton Bazaar",
        "screen_name" : "chorlton_bazaar",
        "indices" : [ 1, 17 ],
        "id_str" : "603964453",
        "id" : 603964453
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 22, 28 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeerAndBazaar",
        "indices" : [ 63, 77 ]
      }, {
        "text" : "Manchester",
        "indices" : [ 89, 100 ]
      }, {
        "text" : "IdealAfternoon",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/J8dOTtW9RM",
        "expanded_url" : "http:\/\/ow.ly\/mfUBR",
        "display_url" : "ow.ly\/mfUBR"
      } ]
    },
    "geo" : { },
    "id_str" : "348821825331003393",
    "text" : ".@Chorlton_Bazaar and @SWMCC have joined forces to present the #BeerAndBazaar weekend in #Manchester! #IdealAfternoon http:\/\/t.co\/J8dOTtW9RM",
    "id" : 348821825331003393,
    "created_at" : "2013-06-23 15:16:18 +0000",
    "user" : {
      "name" : "The List",
      "screen_name" : "TheListMCR",
      "protected" : false,
      "id_str" : "1259490860",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3467331035\/fbad6d2734dc5815fa886d41b4be3032_normal.jpeg",
      "id" : 1259490860,
      "verified" : false
    }
  },
  "id" : 348908517010313216,
  "created_at" : "2013-06-23 21:00:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 86, 93 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/348908374760505347\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/LYSjMuUzNy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNeSUXmCQAAlC0z.png",
      "id_str" : "348908374773088256",
      "id" : 348908374773088256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNeSUXmCQAAlC0z.png",
      "sizes" : [ {
        "h" : 43,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 19,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 43,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 33,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 43,
        "resize" : "fit",
        "w" : 780
      } ],
      "display_url" : "pic.twitter.com\/LYSjMuUzNy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348908374760505347",
  "text" : "Hopefully I'll dream about him. Last commit of this weekend - the way it should be ;) @szlwzl http:\/\/t.co\/LYSjMuUzNy",
  "id" : 348908374760505347,
  "created_at" : "2013-06-23 21:00:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348748107313451008",
  "text" : "So China\/HK just told the US to go fuck itself.... Interesting times.",
  "id" : 348748107313451008,
  "created_at" : "2013-06-23 10:23:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S Wait For It J. ",
      "screen_name" : "SUPERxSJ",
      "indices" : [ 0, 9 ],
      "id_str" : "42853823",
      "id" : 42853823
    }, {
      "name" : "Niall :)",
      "screen_name" : "Niall_182",
      "indices" : [ 10, 20 ],
      "id_str" : "246594172",
      "id" : 246594172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348561674451685377",
  "geo" : { },
  "id_str" : "348562260031057922",
  "in_reply_to_user_id" : 42853823,
  "text" : "@SUPERxSJ @Niall_182 mine wont either and I'm in Glenavy... So guess the network is down - thought my phone finally bought it :)",
  "id" : 348562260031057922,
  "in_reply_to_status_id" : 348561674451685377,
  "created_at" : "2013-06-22 22:04:53 +0000",
  "in_reply_to_screen_name" : "SUPERxSJ",
  "in_reply_to_user_id_str" : "42853823",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348447985975312386",
  "text" : "That moment you found out your back door was unlocked for seven straight days... again.... Yeah - that....",
  "id" : 348447985975312386,
  "created_at" : "2013-06-22 14:30:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348147217506381824",
  "geo" : { },
  "id_str" : "348196835657121792",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne no bother :)",
  "id" : 348196835657121792,
  "in_reply_to_status_id" : 348147217506381824,
  "created_at" : "2013-06-21 21:52:49 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Brona Whittaker",
      "screen_name" : "Bzlwzl",
      "indices" : [ 8, 15 ],
      "id_str" : "30839162",
      "id" : 30839162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brainisfried",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348123051579305984",
  "geo" : { },
  "id_str" : "348128247889920000",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @Bzlwzl am going home soon to watch a marathon of P&amp;R then bed :) #brainisfried",
  "id" : 348128247889920000,
  "in_reply_to_status_id" : 348123051579305984,
  "created_at" : "2013-06-21 17:20:16 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348100570822893568",
  "geo" : { },
  "id_str" : "348100658123141120",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel can\u2019t it won\u2019t work",
  "id" : 348100658123141120,
  "in_reply_to_status_id" : 348100570822893568,
  "created_at" : "2013-06-21 15:30:38 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348082813851009024",
  "geo" : { },
  "id_str" : "348092091655655425",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl sweet ass fuck...",
  "id" : 348092091655655425,
  "in_reply_to_status_id" : 348082813851009024,
  "created_at" : "2013-06-21 14:56:36 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "missplaytimewithwhitaker",
      "indices" : [ 63, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348080128166879232",
  "geo" : { },
  "id_str" : "348082588755308544",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you aren't available to play today - this annoys me :( #missplaytimewithwhitaker - you about Monday? :)",
  "id" : 348082588755308544,
  "in_reply_to_status_id" : 348080128166879232,
  "created_at" : "2013-06-21 14:18:50 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348042720801083392",
  "text" : "Just noticed my head is bopping like a mofo here - and am listening to the Bee Gees - class :D",
  "id" : 348042720801083392,
  "created_at" : "2013-06-21 11:40:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 0, 10 ],
      "id_str" : "7311162",
      "id" : 7311162
    }, {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 11, 18 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348011042879713281",
  "geo" : { },
  "id_str" : "348011262816423936",
  "in_reply_to_user_id" : 7311162,
  "text" : "@mharrigan @padzor smart way to be. Its kinda fucked up somethings but am willing to put up with it. Too late to remap it now :(",
  "id" : 348011262816423936,
  "in_reply_to_status_id" : 348011042879713281,
  "created_at" : "2013-06-21 09:35:25 +0000",
  "in_reply_to_screen_name" : "mharrigan",
  "in_reply_to_user_id_str" : "7311162",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348010016076357633",
  "geo" : { },
  "id_str" : "348010500300349441",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor me too - but I remapped that ctrl+b bollocks to ctrl+a - this has kinda fucked up various other shortcuts though - but sure ;)",
  "id" : 348010500300349441,
  "in_reply_to_status_id" : 348010016076357633,
  "created_at" : "2013-06-21 09:32:23 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348009338901770240",
  "geo" : { },
  "id_str" : "348009787096711168",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor also added a VIM cheat sheet to my desk so learning new VIM tricks every few days too that aids me :)",
  "id" : 348009787096711168,
  "in_reply_to_status_id" : 348009338901770240,
  "created_at" : "2013-06-21 09:29:33 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348009533542658049",
  "geo" : { },
  "id_str" : "348009674785828864",
  "in_reply_to_user_id" : 804717,
  "text" : "@padzor the amount of time it saves. every project I have has a tmux enviro.. So I can switch between enviros and\/or projects. I &lt;3 it.",
  "id" : 348009674785828864,
  "in_reply_to_status_id" : 348009533542658049,
  "created_at" : "2013-06-21 09:29:06 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amahipster",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348009338901770240",
  "geo" : { },
  "id_str" : "348009533542658049",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor switched back to VIM and added tmux. However got it bootstraping my test enviro as I edit code. Gonna blog about it :) #amahipster",
  "id" : 348009533542658049,
  "in_reply_to_status_id" : 348009338901770240,
  "created_at" : "2013-06-21 09:28:33 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348009160555778048",
  "text" : "Am so glad I decided to change my workflow a month ago.... Saving me lots of headaches now.. IDE's are for wankers :)",
  "id" : 348009160555778048,
  "created_at" : "2013-06-21 09:27:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 10, 18 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348001317588963328",
  "geo" : { },
  "id_str" : "348001496845123584",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell @jbrevel I love Jamie - was even saying to Locko how much I like him this week :)",
  "id" : 348001496845123584,
  "in_reply_to_status_id" : 348001317588963328,
  "created_at" : "2013-06-21 08:56:37 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348001034339229696",
  "geo" : { },
  "id_str" : "348001269559988224",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb miss me? :D I miss you... go take a pic of my old desk (or where it was) for old times... Six years this Sept since I left :(",
  "id" : 348001269559988224,
  "in_reply_to_status_id" : 348001034339229696,
  "created_at" : "2013-06-21 08:55:42 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 10, 18 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348000934682574848",
  "geo" : { },
  "id_str" : "348001120284733441",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell @jbrevel hell no - you need to have a wee blowout during times like this.. So that'll be at around 6pm tonight I think :)",
  "id" : 348001120284733441,
  "in_reply_to_status_id" : 348000934682574848,
  "created_at" : "2013-06-21 08:55:07 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348000608499941376",
  "geo" : { },
  "id_str" : "348000842785378304",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @jasebell Am working like a mofo here at the mo Jase and you've given me a good idea for a chillout mini project - awesome :D",
  "id" : 348000842785378304,
  "in_reply_to_status_id" : 348000608499941376,
  "created_at" : "2013-06-21 08:54:01 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/347999324631883776\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/DoRcjp9u0w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNRXir8CYAAr_Gv.png",
      "id_str" : "347999324636078080",
      "id" : 347999324636078080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNRXir8CYAAr_Gv.png",
      "sizes" : [ {
        "h" : 284,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 899
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 899
      } ],
      "display_url" : "pic.twitter.com\/DoRcjp9u0w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347999324631883776",
  "text" : "How to say goodbye to your work colleagues the swmcc way... http:\/\/t.co\/DoRcjp9u0w",
  "id" : 347999324631883776,
  "created_at" : "2013-06-21 08:47:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Stirling",
      "screen_name" : "AlanStirling",
      "indices" : [ 0, 13 ],
      "id_str" : "126106464",
      "id" : 126106464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347826732931354625",
  "geo" : { },
  "id_str" : "347826910719537152",
  "in_reply_to_user_id" : 126106464,
  "text" : "@AlanStirling good luck - hope it goes through.",
  "id" : 347826910719537152,
  "in_reply_to_status_id" : 347826732931354625,
  "created_at" : "2013-06-20 21:22:52 +0000",
  "in_reply_to_screen_name" : "AlanStirling",
  "in_reply_to_user_id_str" : "126106464",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ronbible",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347826803873832960",
  "text" : "Gonna sit down and watch three episodes of Parks n Recreation after staring at a computer screen for more hours than I care to :) #ronbible",
  "id" : 347826803873832960,
  "created_at" : "2013-06-20 21:22:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 12, 20 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347824434872213505",
  "geo" : { },
  "id_str" : "347826432883429377",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne @jbrevel Yup - I am equal opportunities pervert :)",
  "id" : 347826432883429377,
  "in_reply_to_status_id" : 347824434872213505,
  "created_at" : "2013-06-20 21:20:58 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bow Street Mall",
      "screen_name" : "bowstreetmall",
      "indices" : [ 1, 15 ],
      "id_str" : "313861329",
      "id" : 313861329
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/347817410482536448\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/KuEwQ6IUyv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNOyF48CAAAS6OU.jpg",
      "id_str" : "347817410490925056",
      "id" : 347817410490925056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNOyF48CAAAS6OU.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/KuEwQ6IUyv"
    } ],
    "hashtags" : [ {
      "text" : "fuckwits",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347817410482536448",
  "text" : ".@bowstreetmall it is 2013 - just sayin. Much love - Stephen. #fuckwits http:\/\/t.co\/KuEwQ6IUyv",
  "id" : 347817410482536448,
  "created_at" : "2013-06-20 20:45:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 11, 19 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347777856958500864",
  "geo" : { },
  "id_str" : "347814346564448257",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @jbrevel housekeeping??? Me come in now? Housekeeping?",
  "id" : 347814346564448257,
  "in_reply_to_status_id" : 347777856958500864,
  "created_at" : "2013-06-20 20:32:56 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susanna Reid",
      "screen_name" : "susannareid100",
      "indices" : [ 0, 15 ],
      "id_str" : "19477583",
      "id" : 19477583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347808055339151360",
  "geo" : { },
  "id_str" : "347814231166562305",
  "in_reply_to_user_id" : 19477583,
  "text" : "@susannareid100 well at least I'll think its mid week now - so the Friday feeling will be nice come about noon :)",
  "id" : 347814231166562305,
  "in_reply_to_status_id" : 347808055339151360,
  "created_at" : "2013-06-20 20:32:29 +0000",
  "in_reply_to_screen_name" : "susannareid100",
  "in_reply_to_user_id_str" : "19477583",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 3, 16 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "Atlassian HipChat",
      "screen_name" : "HipChat",
      "indices" : [ 72, 80 ],
      "id_str" : "17810599",
      "id" : 17810599
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 84, 91 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 92, 100 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 101, 110 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 111, 117 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 118, 131 ],
      "id_str" : "162449244",
      "id" : 162449244
    }, {
      "name" : "paul_m",
      "screen_name" : "paul_m",
      "indices" : [ 132, 139 ],
      "id_str" : "10602712",
      "id" : 10602712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347768308545757185",
  "text" : "RT @nicholabates: I\u2019m pretty sure people would pay good money to read r @hipchat cc @rejoco @jbrevel @davehedo @swmcc @justinMleary @Paul_M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Atlassian HipChat",
        "screen_name" : "HipChat",
        "indices" : [ 54, 62 ],
        "id_str" : "17810599",
        "id" : 17810599
      }, {
        "name" : "John Reid",
        "screen_name" : "rejoco",
        "indices" : [ 66, 73 ],
        "id_str" : "53053999",
        "id" : 53053999
      }, {
        "name" : "John Loughrey",
        "screen_name" : "jbrevel",
        "indices" : [ 74, 82 ],
        "id_str" : "50685221",
        "id" : 50685221
      }, {
        "name" : "David Henderson",
        "screen_name" : "davehedo",
        "indices" : [ 83, 92 ],
        "id_str" : "50985598",
        "id" : 50985598
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 93, 99 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Justin Leary",
        "screen_name" : "justinMleary",
        "indices" : [ 100, 113 ],
        "id_str" : "162449244",
        "id" : 162449244
      }, {
        "name" : "Paul Moffett",
        "screen_name" : "Paul_Moffett",
        "indices" : [ 114, 127 ],
        "id_str" : "36913698",
        "id" : 36913698
      }, {
        "name" : "Mark",
        "screen_name" : "_MarkByrne",
        "indices" : [ 128, 139 ],
        "id_str" : "300112124",
        "id" : 300112124
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347768076864995328",
    "text" : "I\u2019m pretty sure people would pay good money to read r @hipchat cc @rejoco @jbrevel @davehedo @swmcc @justinMleary @Paul_Moffett @_MarkByrne",
    "id" : 347768076864995328,
    "created_at" : "2013-06-20 17:29:05 +0000",
    "user" : {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "protected" : false,
      "id_str" : "19125494",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2947508512\/c9075236946505819826a2f275f50186_normal.jpeg",
      "id" : 19125494,
      "verified" : false
    }
  },
  "id" : 347768308545757185,
  "created_at" : "2013-06-20 17:30:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 31, 37 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jbrevel\/status\/347764999239892992\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/RKDcDuIC96",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNOCbJ1CAAEFpvk.jpg",
      "id_str" : "347764999244087297",
      "id" : 347764999244087297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNOCbJ1CAAEFpvk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/RKDcDuIC96"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347765088725377025",
  "text" : "RT @jbrevel: This ones for you @swmcc http:\/\/t.co\/RKDcDuIC96",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 18, 24 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jbrevel\/status\/347764999239892992\/photo\/1",
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/RKDcDuIC96",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNOCbJ1CAAEFpvk.jpg",
        "id_str" : "347764999244087297",
        "id" : 347764999244087297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNOCbJ1CAAEFpvk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/RKDcDuIC96"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347764999239892992",
    "text" : "This ones for you @swmcc http:\/\/t.co\/RKDcDuIC96",
    "id" : 347764999239892992,
    "created_at" : "2013-06-20 17:16:51 +0000",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 347765088725377025,
  "created_at" : "2013-06-20 17:17:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Haines",
      "screen_name" : "coreyhaines",
      "indices" : [ 3, 15 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wedontneednostinkingfacts",
      "indices" : [ 80, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347751462882918400",
  "text" : "RT @coreyhaines: Do you realize that today is exactly halfway through the year? #wedontneednostinkingfacts",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wedontneednostinkingfacts",
        "indices" : [ 63, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347748011813765122",
    "text" : "Do you realize that today is exactly halfway through the year? #wedontneednostinkingfacts",
    "id" : 347748011813765122,
    "created_at" : "2013-06-20 16:09:21 +0000",
    "user" : {
      "name" : "Corey Haines",
      "screen_name" : "coreyhaines",
      "protected" : false,
      "id_str" : "11458102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000433931843\/7f48108ec85876486c8e1b6fecdf15f2_normal.jpeg",
      "id" : 11458102,
      "verified" : false
    }
  },
  "id" : 347751462882918400,
  "created_at" : "2013-06-20 16:23:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347721472883716096",
  "geo" : { },
  "id_str" : "347725026906234880",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel want a massage? :)",
  "id" : 347725026906234880,
  "in_reply_to_status_id" : 347721472883716096,
  "created_at" : "2013-06-20 14:38:01 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bash!",
      "screen_name" : "devbash",
      "indices" : [ 3, 11 ],
      "id_str" : "454193975",
      "id" : 454193975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347704068120117248",
  "text" : "RT @devbash: Was hoping to get a Game of Thrones producer to speak at Autumn Bash! Unfortunately NIScreen just blank refused on their behal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347651617090306048",
    "text" : "Was hoping to get a Game of Thrones producer to speak at Autumn Bash! Unfortunately NIScreen just blank refused on their behalf :(",
    "id" : 347651617090306048,
    "created_at" : "2013-06-20 09:46:19 +0000",
    "user" : {
      "name" : "Bash!",
      "screen_name" : "devbash",
      "protected" : false,
      "id_str" : "454193975",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1732404718\/bash_normal.png",
      "id" : 454193975,
      "verified" : false
    }
  },
  "id" : 347704068120117248,
  "created_at" : "2013-06-20 13:14:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 0, 8 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347642511600271361",
  "geo" : { },
  "id_str" : "347651154743791616",
  "in_reply_to_user_id" : 120378343,
  "text" : "@kouphax it really is... Wouldn't be that bad if I could remember that I need to get a verification code...",
  "id" : 347651154743791616,
  "in_reply_to_status_id" : 347642511600271361,
  "created_at" : "2013-06-20 09:44:28 +0000",
  "in_reply_to_screen_name" : "kouphax",
  "in_reply_to_user_id_str" : "120378343",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 29, 36 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Atlassian HipChat",
      "screen_name" : "HipChat",
      "indices" : [ 40, 48 ],
      "id_str" : "17810599",
      "id" : 17810599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347645700517003264",
  "text" : "I love my conversations with @szlwzl on @hipchat - makes me warm and fuzzy inside :)",
  "id" : 347645700517003264,
  "created_at" : "2013-06-20 09:22:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347622984980234241",
  "text" : "\"That sugarless motherfucker, it's the last fuckking drink you're ever gonna have.\" - RIP James Gandolfini",
  "id" : 347622984980234241,
  "created_at" : "2013-06-20 07:52:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347487540976164865",
  "geo" : { },
  "id_str" : "347487863744643072",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull nope. And there\u2019s more chance of me being an Olympic gymnast than there is of you watching Star Wars.",
  "id" : 347487863744643072,
  "in_reply_to_status_id" : 347487540976164865,
  "created_at" : "2013-06-19 22:55:37 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347485188554625025",
  "geo" : { },
  "id_str" : "347486686151839744",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull alderran is a planet that Grand Moff Tarikin blew up using the Death Star in episode 4 :) not a bad joke.",
  "id" : 347486686151839744,
  "in_reply_to_status_id" : 347485188554625025,
  "created_at" : "2013-06-19 22:50:56 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347462901445050368",
  "geo" : { },
  "id_str" : "347476441769844736",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl :) Jerry gets mugged - class episode.",
  "id" : 347476441769844736,
  "in_reply_to_status_id" : 347462901445050368,
  "created_at" : "2013-06-19 22:10:14 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347368964390789120",
  "geo" : { },
  "id_str" : "347369659873513473",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir Yeah - tech debt can sink a co just as much as fiscal debt &amp; goes ignored in most companies. Anyway have fun with yer new feature :)",
  "id" : 347369659873513473,
  "in_reply_to_status_id" : 347368964390789120,
  "created_at" : "2013-06-19 15:05:55 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347367264485511169",
  "geo" : { },
  "id_str" : "347367677339267072",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir feels good to feature branch when you get to do something like that :)",
  "id" : 347367677339267072,
  "in_reply_to_status_id" : 347367264485511169,
  "created_at" : "2013-06-19 14:58:02 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 128, 135 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347363492866691074",
  "text" : "I just died.. Google Auth needed - but phone is dead... FUCK FUCK FUCK FUCK FUCK FUCK... \/me goes to get it charged - screw you @szlwzl :)",
  "id" : 347363492866691074,
  "created_at" : "2013-06-19 14:41:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347342675604799488",
  "text" : "Working from home is alright sometimes... however the bestest thing is I get to spend my lunch break watching Ron..... \/me goes to do it",
  "id" : 347342675604799488,
  "created_at" : "2013-06-19 13:18:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "martymc",
      "screen_name" : "martymc",
      "indices" : [ 0, 8 ],
      "id_str" : "15136295",
      "id" : 15136295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347328909001490432",
  "geo" : { },
  "id_str" : "347337360415019011",
  "in_reply_to_user_id" : 15136295,
  "text" : "@martymc Impressive :) But no star wars toys..",
  "id" : 347337360415019011,
  "in_reply_to_status_id" : 347328909001490432,
  "created_at" : "2013-06-19 12:57:34 +0000",
  "in_reply_to_screen_name" : "martymc",
  "in_reply_to_user_id_str" : "15136295",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homeoffice",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "ilikestarwarsabit",
      "indices" : [ 53, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/W7wN8mPMMx",
      "expanded_url" : "http:\/\/instagram.com\/p\/avXHfXBX53\/",
      "display_url" : "instagram.com\/p\/avXHfXBX53\/"
    } ]
  },
  "geo" : { },
  "id_str" : "347325394766139392",
  "text" : "I am 34. This is where I work from home. #homeoffice #ilikestarwarsabit http:\/\/t.co\/W7wN8mPMMx",
  "id" : 347325394766139392,
  "created_at" : "2013-06-19 12:10:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346975808587460608",
  "geo" : { },
  "id_str" : "346976005421948929",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo It was awesome :) Going to the cinema on your own is great. I don't need anyone holding my cock to do anything. Go fuck yourself!",
  "id" : 346976005421948929,
  "in_reply_to_status_id" : 346975808587460608,
  "created_at" : "2013-06-18 13:01:40 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 3, 12 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346975582631907328",
  "text" : "So @davehedo is being dead cute on the phone - pretending he has friends... called someone \"mate\" he has no mates. Everyone hates him! :)",
  "id" : 346975582631907328,
  "created_at" : "2013-06-18 13:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 15, 23 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346658054441431040",
  "geo" : { },
  "id_str" : "346701940580810752",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ @jbrevel yeah it wasn\u2019t that comprehensive if I am honest. Think 20mins and we were done.",
  "id" : 346701940580810752,
  "in_reply_to_status_id" : 346658054441431040,
  "created_at" : "2013-06-17 18:52:38 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 38, 46 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346656310164586497",
  "text" : "Heading on an impromptu man date with @jbrevel to go see GoT stuffs :D :D :D :D :D :D :D :D",
  "id" : 346656310164586497,
  "created_at" : "2013-06-17 15:51:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346639201237872640",
  "text" : "Building a war file - sounds much cooler than it really is.. Though gradle is nice...",
  "id" : 346639201237872640,
  "created_at" : "2013-06-17 14:43:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 12, 24 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346607816766808064",
  "geo" : { },
  "id_str" : "346612314725834752",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne @DebbieCReid if I wanted them found they'd be found believe me :) Right I can't play with you two anymore - got to work :)",
  "id" : 346612314725834752,
  "in_reply_to_status_id" : 346607816766808064,
  "created_at" : "2013-06-17 12:56:30 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 13, 20 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346596899547144192",
  "geo" : { },
  "id_str" : "346597294017245184",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid @szlwzl What's with all the Stevie hate today Debbie? You move to the geek side, say I smell ask about the eggs now this! :)",
  "id" : 346597294017245184,
  "in_reply_to_status_id" : 346596899547144192,
  "created_at" : "2013-06-17 11:56:49 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 3, 15 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346555818705043456",
  "text" : "So @DebbieCReid has moved to the geek side of the office.",
  "id" : 346555818705043456,
  "created_at" : "2013-06-17 09:12:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 8, 19 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346380943361187842",
  "geo" : { },
  "id_str" : "346382153854111744",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco @_MarkByrne and soft.. you forgot soft.",
  "id" : 346382153854111744,
  "in_reply_to_status_id" : 346380943361187842,
  "created_at" : "2013-06-16 21:41:55 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346377911344975872",
  "geo" : { },
  "id_str" : "346378102584270850",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco \/me takes a bow... I knew they were somewhere - technically they were misplaced... Not lost :)",
  "id" : 346378102584270850,
  "in_reply_to_status_id" : 346377911344975872,
  "created_at" : "2013-06-16 21:25:49 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "orsomethinglikethat",
      "indices" : [ 114, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346377404211675136",
  "geo" : { },
  "id_str" : "346377678699515906",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl That's right.. Ahhh shit one. I am WFH on Wednesday... Ahhh well - absence makes the cock grow founder ;) #orsomethinglikethat",
  "id" : 346377678699515906,
  "in_reply_to_status_id" : 346377404211675136,
  "created_at" : "2013-06-16 21:24:08 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346376555053842433",
  "geo" : { },
  "id_str" : "346377177379532801",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl If you've got something to say just say it you English twat... Don't beat around the bush? Can I play with you tomorrow?",
  "id" : 346377177379532801,
  "in_reply_to_status_id" : 346376555053842433,
  "created_at" : "2013-06-16 21:22:09 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346376345393197057",
  "text" : "Found my work keys!! :) They were in the fridge behind the eggs. They are now attached to my car keys so ill only lose them once a month now",
  "id" : 346376345393197057,
  "created_at" : "2013-06-16 21:18:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346336360078131200",
  "text" : "Shit load of police outside Glenavy. The 14 year old in me wants to moon them from the metal bridge... Local knowedge says it can be done.",
  "id" : 346336360078131200,
  "created_at" : "2013-06-16 18:39:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346289530153869312",
  "geo" : { },
  "id_str" : "346299309882478593",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl going over to see my folks in a bit. Ill bring it in tomorrow for a nipple slip. Deal?",
  "id" : 346299309882478593,
  "in_reply_to_status_id" : 346289530153869312,
  "created_at" : "2013-06-16 16:12:44 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maks Surguy",
      "screen_name" : "msurguy",
      "indices" : [ 3, 11 ],
      "id_str" : "13033742",
      "id" : 13033742
    }, {
      "name" : "PubNub",
      "screen_name" : "PubNub",
      "indices" : [ 54, 61 ],
      "id_str" : "152773076",
      "id" : 152773076
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/qTjN2ukExH",
      "expanded_url" : "https:\/\/github.com\/pubnub\/real-time-stocks",
      "display_url" : "github.com\/pubnub\/real-ti\u2026"
    }, {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/SIZoaQybxA",
      "expanded_url" : "http:\/\/rtstock.co\/",
      "display_url" : "rtstock.co"
    } ]
  },
  "geo" : { },
  "id_str" : "346248216204951552",
  "text" : "RT @msurguy: Very cool real time PHP socket usage via @pubnub : https:\/\/t.co\/qTjN2ukExH , demo at http:\/\/t.co\/SIZoaQybxA #opensource",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PubNub",
        "screen_name" : "PubNub",
        "indices" : [ 41, 48 ],
        "id_str" : "152773076",
        "id" : 152773076
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 108, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/qTjN2ukExH",
        "expanded_url" : "https:\/\/github.com\/pubnub\/real-time-stocks",
        "display_url" : "github.com\/pubnub\/real-ti\u2026"
      }, {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/SIZoaQybxA",
        "expanded_url" : "http:\/\/rtstock.co\/",
        "display_url" : "rtstock.co"
      } ]
    },
    "geo" : { },
    "id_str" : "346082551808524288",
    "text" : "Very cool real time PHP socket usage via @pubnub : https:\/\/t.co\/qTjN2ukExH , demo at http:\/\/t.co\/SIZoaQybxA #opensource",
    "id" : 346082551808524288,
    "created_at" : "2013-06-16 01:51:24 +0000",
    "user" : {
      "name" : "Maks Surguy",
      "screen_name" : "msurguy",
      "protected" : false,
      "id_str" : "13033742",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000261187987\/2266fe969528c4640eb099ec2cb1877b_normal.jpeg",
      "id" : 13033742,
      "verified" : false
    }
  },
  "id" : 346248216204951552,
  "created_at" : "2013-06-16 12:49:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Paul",
      "screen_name" : "Mad",
      "indices" : [ 3, 7 ],
      "id_str" : "38639821",
      "id" : 38639821
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Mad\/status\/344424278239875072\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/RNJTBQ0ZpJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMekDmTCEAAdOhW.jpg",
      "id_str" : "344424278244069376",
      "id" : 344424278244069376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMekDmTCEAAdOhW.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/RNJTBQ0ZpJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345812130697711618",
  "text" : "RT @Mad: Funniest company name EVER is made even funnier by the guy's name who is being interviewed http:\/\/t.co\/RNJTBQ0ZpJ",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Mad\/status\/344424278239875072\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/RNJTBQ0ZpJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMekDmTCEAAdOhW.jpg",
        "id_str" : "344424278244069376",
        "id" : 344424278244069376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMekDmTCEAAdOhW.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/RNJTBQ0ZpJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344424278239875072",
    "text" : "Funniest company name EVER is made even funnier by the guy's name who is being interviewed http:\/\/t.co\/RNJTBQ0ZpJ",
    "id" : 344424278239875072,
    "created_at" : "2013-06-11 12:02:01 +0000",
    "user" : {
      "name" : "Frank Paul",
      "screen_name" : "Mad",
      "protected" : false,
      "id_str" : "38639821",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000229812553\/96a8c09e30085f292681809e01cd278b_normal.jpeg",
      "id" : 38639821,
      "verified" : false
    }
  },
  "id" : 345812130697711618,
  "created_at" : "2013-06-15 07:56:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 17, 30 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 31, 38 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345638807321845762",
  "geo" : { },
  "id_str" : "345809288167579648",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 @stevebiscuit @szlwzl thanks :)",
  "id" : 345809288167579648,
  "in_reply_to_status_id" : 345638807321845762,
  "created_at" : "2013-06-15 07:45:33 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345808778375073793",
  "text" : "So.. Breakfast and Parks n Recreation - then some work for a few hours.... Then more Parks n Recreation...",
  "id" : 345808778375073793,
  "created_at" : "2013-06-15 07:43:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 8, 17 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345562828842881024",
  "geo" : { },
  "id_str" : "345565321261875200",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe @ManyHues talent",
  "id" : 345565321261875200,
  "in_reply_to_status_id" : 345562828842881024,
  "created_at" : "2013-06-14 15:36:07 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "destroyed",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345523787351064576",
  "text" : "RT @jbrevel: @swmcc Hows your kidneys now ballbag? I thought you were going to spit them out half way to the office #destroyed",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "destroyed",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "345522956191031296",
    "geo" : { },
    "id_str" : "345523716156973057",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Hows your kidneys now ballbag? I thought you were going to spit them out half way to the office #destroyed",
    "id" : 345523716156973057,
    "in_reply_to_status_id" : 345522956191031296,
    "created_at" : "2013-06-14 12:50:48 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 345523787351064576,
  "created_at" : "2013-06-14 12:51:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "Mark Devlin",
      "screen_name" : "MDev247",
      "indices" : [ 12, 20 ],
      "id_str" : "46503614",
      "id" : 46503614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345502700156354561",
  "geo" : { },
  "id_str" : "345523613593661440",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne @MDev247 Sorry about that :D",
  "id" : 345523613593661440,
  "in_reply_to_status_id" : 345502700156354561,
  "created_at" : "2013-06-14 12:50:23 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 20, 28 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cock",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345522956191031296",
  "text" : "That pure bred cunt @jbrevel near fucking killed me there.. FUCKING WANKER! He spent about 15quid in petrol doing it though! #cock",
  "id" : 345522956191031296,
  "created_at" : "2013-06-14 12:47:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 40, 47 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345489836041445377",
  "text" : "When rvm makes you wanna cry here comes @szlwzl to the rescue :) Like mighty mouse only English and likes wine gums.",
  "id" : 345489836041445377,
  "created_at" : "2013-06-14 10:36:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oisin",
      "screen_name" : "oisin",
      "indices" : [ 0, 6 ],
      "id_str" : "8446902",
      "id" : 8446902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345476976775163904",
  "geo" : { },
  "id_str" : "345487865779740673",
  "in_reply_to_user_id" : 8446902,
  "text" : "@oisin shit one. as long as you are ok though that's the main thing - things can be replaced.",
  "id" : 345487865779740673,
  "in_reply_to_status_id" : 345476976775163904,
  "created_at" : "2013-06-14 10:28:20 +0000",
  "in_reply_to_screen_name" : "oisin",
  "in_reply_to_user_id_str" : "8446902",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 9, 18 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/345481990755201024\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/28vvEvTfkN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMtmCkeCMAAL2K-.jpg",
      "id_str" : "345481990759395328",
      "id" : 345481990759395328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMtmCkeCMAAL2K-.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/28vvEvTfkN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345481990755201024",
  "text" : "Awesome. @davehedo in a  onsie. http:\/\/t.co\/28vvEvTfkN",
  "id" : 345481990755201024,
  "created_at" : "2013-06-14 10:05:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    }, {
      "name" : "Mark Devlin",
      "screen_name" : "MDev247",
      "indices" : [ 47, 55 ],
      "id_str" : "46503614",
      "id" : 46503614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345450828674523136",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne ignore my voicemail. I got you and @MDev247 mixed up on my phone... :)",
  "id" : 345450828674523136,
  "created_at" : "2013-06-14 08:01:10 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345311069343977472",
  "geo" : { },
  "id_str" : "345444660837232640",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams I had other things to watch back then. But you remind me so much of Chris it hurts - I see Mike everytime :)",
  "id" : 345444660837232640,
  "in_reply_to_status_id" : 345311069343977472,
  "created_at" : "2013-06-14 07:36:39 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345281443980783617",
  "geo" : { },
  "id_str" : "345282118471016448",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I have a sharp stabbing pain in my right kidney (I think its my kideny) but I am LITERALLY LOL'ing at it.",
  "id" : 345282118471016448,
  "in_reply_to_status_id" : 345281443980783617,
  "created_at" : "2013-06-13 20:50:46 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 53, 60 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345279469797376001",
  "text" : "If you don't already you should listen to everything @szlwzl says....",
  "id" : 345279469797376001,
  "created_at" : "2013-06-13 20:40:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345232635003535360",
  "text" : "You know its time to go home when you are fighting with a SQL INSERT statement to work properly!",
  "id" : 345232635003535360,
  "created_at" : "2013-06-13 17:34:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noisyfuckers",
      "indices" : [ 67, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345217753558429697",
  "text" : "I like it when everyone else fucks off home. I get some work done. #noisyfuckers So starting tomorrow I will be in early :)",
  "id" : 345217753558429697,
  "created_at" : "2013-06-13 16:35:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 5, 12 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/oCBJqLnRj6",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=6OkcucXIuVI",
      "display_url" : "youtube.com\/watch?v=6Okcuc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345177698018136065",
  "text" : "Poor @szlwzl just got a version of this about 2mins ago... http:\/\/t.co\/oCBJqLnRj6",
  "id" : 345177698018136065,
  "created_at" : "2013-06-13 13:55:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 5, 12 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/DHxVyHtnFs",
      "expanded_url" : "https:\/\/github.com\/swmcc\/swanson",
      "display_url" : "github.com\/swmcc\/swanson"
    } ]
  },
  "geo" : { },
  "id_str" : "344829296491253761",
  "text" : "Well @szlwzl I said I would do it and I did - just need to find a use for the name - https:\/\/t.co\/DHxVyHtnFs",
  "id" : 344829296491253761,
  "created_at" : "2013-06-12 14:51:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344820647291138049",
  "text" : "My kidneys are sore\u2026. The pain will stop when I die.",
  "id" : 344820647291138049,
  "created_at" : "2013-06-12 14:17:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Swanson",
      "screen_name" : "RonUSwanson",
      "indices" : [ 3, 15 ],
      "id_str" : "201394905",
      "id" : 201394905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344820562671050752",
  "text" : "RT @RonUSwanson: If your diet requires that you also take 17 vitamins, you're doing it wrong. Cavemen didn't have Centrum. End of story.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344568235808669696",
    "text" : "If your diet requires that you also take 17 vitamins, you're doing it wrong. Cavemen didn't have Centrum. End of story.",
    "id" : 344568235808669696,
    "created_at" : "2013-06-11 21:34:03 +0000",
    "user" : {
      "name" : "Ron Swanson",
      "screen_name" : "RonUSwanson",
      "protected" : false,
      "id_str" : "201394905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3442697998\/175698aaa30451a7e50f5fd60683db18_normal.jpeg",
      "id" : 201394905,
      "verified" : false
    }
  },
  "id" : 344820562671050752,
  "created_at" : "2013-06-12 14:16:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344729814642589696",
  "text" : "Going to tax my car now\u2026.. This will be fun.",
  "id" : 344729814642589696,
  "created_at" : "2013-06-12 08:16:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344565935090327554",
  "geo" : { },
  "id_str" : "344566306709843969",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl on my next GitHub repo I\u2019m using the gif of him dancing as the image.",
  "id" : 344566306709843969,
  "in_reply_to_status_id" : 344565935090327554,
  "created_at" : "2013-06-11 21:26:23 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344537231974871041",
  "geo" : { },
  "id_str" : "344565503840366592",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl the big block of cheese day? Wolfie?? Really? Madness\u2026",
  "id" : 344565503840366592,
  "in_reply_to_status_id" : 344537231974871041,
  "created_at" : "2013-06-11 21:23:12 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/dropbox\/id327630330?mt=8&uo=4\" rel=\"nofollow\"\u003EDropbox on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "starwars",
      "indices" : [ 42, 51 ]
    }, {
      "text" : "ifonly",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/HffEmMfrlI",
      "expanded_url" : "http:\/\/db.tt\/1KtszrmX",
      "display_url" : "db.tt\/1KtszrmX"
    } ]
  },
  "geo" : { },
  "id_str" : "344526669991780352",
  "text" : "Found this on my Dropbox from years back. #starwars #ifonly http:\/\/t.co\/HffEmMfrlI",
  "id" : 344526669991780352,
  "created_at" : "2013-06-11 18:48:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344456132271669250",
  "geo" : { },
  "id_str" : "344456672502243328",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I concur.... I will be him.",
  "id" : 344456672502243328,
  "in_reply_to_status_id" : 344456132271669250,
  "created_at" : "2013-06-11 14:10:45 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 19, 27 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344452681743626241",
  "text" : "I put \"Queen\" into @Spotify and I got \"Queen &amp; Five\". I think I speak for all humanity when I shout and say. FUCK. RIGHT. OFF. AND. DIE.",
  "id" : 344452681743626241,
  "created_at" : "2013-06-11 13:54:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344446160330702849",
  "geo" : { },
  "id_str" : "344448797344161792",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher yeah I get that. But they are good products all the same.",
  "id" : 344448797344161792,
  "in_reply_to_status_id" : 344446160330702849,
  "created_at" : "2013-06-11 13:39:27 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344441932971380737",
  "geo" : { },
  "id_str" : "344443317322383360",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher You that down on apple? :)",
  "id" : 344443317322383360,
  "in_reply_to_status_id" : 344441932971380737,
  "created_at" : "2013-06-11 13:17:40 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Buchanan",
      "screen_name" : "jbscript",
      "indices" : [ 0, 9 ],
      "id_str" : "770264707",
      "id" : 770264707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344442699165888512",
  "geo" : { },
  "id_str" : "344443019765882880",
  "in_reply_to_user_id" : 770264707,
  "text" : "@jbscript Be a shit load of people on for it if that was the case\u2026 However I think it might be a fabrication or a stretch at least ;)",
  "id" : 344443019765882880,
  "in_reply_to_status_id" : 344442699165888512,
  "created_at" : "2013-06-11 13:16:30 +0000",
  "in_reply_to_screen_name" : "jbscript",
  "in_reply_to_user_id_str" : "770264707",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 11, 24 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344422688816775169",
  "geo" : { },
  "id_str" : "344422875727552512",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @Paul_Moffett I miss you\u2026.",
  "id" : 344422875727552512,
  "in_reply_to_status_id" : 344422688816775169,
  "created_at" : "2013-06-11 11:56:27 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 31, 44 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thoughtsthatlinger",
      "indices" : [ 120, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344419556904804352",
  "text" : "On the way back to the office  @Paul_Moffett said I might be getting \"kidney stones\" as I have a sharp in pain my back. #thoughtsthatlinger",
  "id" : 344419556904804352,
  "created_at" : "2013-06-11 11:43:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344370489722036225",
  "geo" : { },
  "id_str" : "344375300563546112",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne in this you are. dead wrong.",
  "id" : 344375300563546112,
  "in_reply_to_status_id" : 344370489722036225,
  "created_at" : "2013-06-11 08:47:24 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344237412563681280",
  "geo" : { },
  "id_str" : "344375265167802369",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es I have read up until the last 1 and the second half of book 4. The second half of book 4 is a hard read.",
  "id" : 344375265167802369,
  "in_reply_to_status_id" : 344237412563681280,
  "created_at" : "2013-06-11 08:47:16 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344361031788802049",
  "geo" : { },
  "id_str" : "344361415303393281",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne wrong",
  "id" : 344361415303393281,
  "in_reply_to_status_id" : 344361031788802049,
  "created_at" : "2013-06-11 07:52:13 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Push Technology",
      "screen_name" : "push_technology",
      "indices" : [ 3, 19 ],
      "id_str" : "262711334",
      "id" : 262711334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/PjlItyGJeB",
      "expanded_url" : "http:\/\/hub.am\/11xmgm6",
      "display_url" : "hub.am\/11xmgm6"
    } ]
  },
  "geo" : { },
  "id_str" : "344202909392715777",
  "text" : "RT @push_technology: How we simplify testing Diffusion with Node.js http:\/\/t.co\/PjlItyGJeB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/PjlItyGJeB",
        "expanded_url" : "http:\/\/hub.am\/11xmgm6",
        "display_url" : "hub.am\/11xmgm6"
      } ]
    },
    "geo" : { },
    "id_str" : "344196034257354752",
    "text" : "How we simplify testing Diffusion with Node.js http:\/\/t.co\/PjlItyGJeB",
    "id" : 344196034257354752,
    "created_at" : "2013-06-10 20:55:04 +0000",
    "user" : {
      "name" : "Push Technology",
      "screen_name" : "push_technology",
      "protected" : false,
      "id_str" : "262711334",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2165535851\/Push-Square_normal.jpg",
      "id" : 262711334,
      "verified" : false
    }
  },
  "id" : 344202909392715777,
  "created_at" : "2013-06-10 21:22:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344202466486804481",
  "text" : "Hats off to the crew behind Game of Thrones. Best adaption of a book to screen yet. Three consistent seasons.",
  "id" : 344202466486804481,
  "created_at" : "2013-06-10 21:20:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wwdc",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344169080309284864",
  "text" : "I\u2019ve spent the whole evening so far in the garden. I come back on twitter to see a load of stuff on #wwdc - it\u2019s sunny outside people!!!!!!!",
  "id" : 344169080309284864,
  "created_at" : "2013-06-10 19:07:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344166850143342592",
  "geo" : { },
  "id_str" : "344168369198600192",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid I now have this in writing :)",
  "id" : 344168369198600192,
  "in_reply_to_status_id" : 344166850143342592,
  "created_at" : "2013-06-10 19:05:08 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344115891191033856",
  "text" : "Last good day for the summer probably... Heading home at 5 on the [dot] to make the most of it. It'll piss the rest of the summer no doubt!",
  "id" : 344115891191033856,
  "created_at" : "2013-06-10 15:36:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "personalgrowth",
      "indices" : [ 46, 61 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344083864966275074",
  "geo" : { },
  "id_str" : "344085374718582786",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda no dead\/hidden bodies? No rampage? #personalgrowth",
  "id" : 344085374718582786,
  "in_reply_to_status_id" : 344083864966275074,
  "created_at" : "2013-06-10 13:35:20 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344082144261451776",
  "text" : "If I wish hard enough will my Dad have cut my grass for me?\u2026\u2026\u2026..",
  "id" : 344082144261451776,
  "created_at" : "2013-06-10 13:22:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 25, 31 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344007486015143937",
  "text" : "Need to make Google Auth @swmcc proof. I left my mobile in the car :(",
  "id" : 344007486015143937,
  "created_at" : "2013-06-10 08:25:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "garden",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/wkv99hB3VI",
      "expanded_url" : "http:\/\/instagram.com\/p\/aWlEznhXyl\/",
      "display_url" : "instagram.com\/p\/aWlEznhXyl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "343837641281794048",
  "text" : "I spent my weekend well. #garden http:\/\/t.co\/wkv99hB3VI",
  "id" : 343837641281794048,
  "created_at" : "2013-06-09 21:10:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Jaffrey",
      "screen_name" : "jaffs",
      "indices" : [ 0, 6 ],
      "id_str" : "14511835",
      "id" : 14511835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343817386589315072",
  "geo" : { },
  "id_str" : "343822207841079296",
  "in_reply_to_user_id" : 14511835,
  "text" : "@jaffs don\u2019t hate the playa hate the game yo!",
  "id" : 343822207841079296,
  "in_reply_to_status_id" : 343817386589315072,
  "created_at" : "2013-06-09 20:09:36 +0000",
  "in_reply_to_screen_name" : "jaffs",
  "in_reply_to_user_id_str" : "14511835",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Jaffrey",
      "screen_name" : "jaffs",
      "indices" : [ 0, 6 ],
      "id_str" : "14511835",
      "id" : 14511835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343816903057371136",
  "geo" : { },
  "id_str" : "343817053834186752",
  "in_reply_to_user_id" : 14511835,
  "text" : "@jaffs thought that\u2019d rile you :)",
  "id" : 343817053834186752,
  "in_reply_to_status_id" : 343816903057371136,
  "created_at" : "2013-06-09 19:49:08 +0000",
  "in_reply_to_screen_name" : "jaffs",
  "in_reply_to_user_id_str" : "14511835",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "properdev",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343815548024545280",
  "text" : "Thinking about work tomorrow - had a Friday afternoon meeting so no sure where I was. A quick regression test now tells me :) #properdev",
  "id" : 343815548024545280,
  "created_at" : "2013-06-09 19:43:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 8, 24 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343695901975511043",
  "geo" : { },
  "id_str" : "343696163104501760",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @michaelnsimpson he is my idol.",
  "id" : 343696163104501760,
  "in_reply_to_status_id" : 343695901975511043,
  "created_at" : "2013-06-09 11:48:45 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 17, 24 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343513843714113536",
  "geo" : { },
  "id_str" : "343695302601097216",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @szlwzl I\u2019m watching it now. Love it. Dunno who\u2019s a cooler character April or Ron.",
  "id" : 343695302601097216,
  "in_reply_to_status_id" : 343513843714113536,
  "created_at" : "2013-06-09 11:45:20 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343695111353421824",
  "text" : "Yup - I have sun burnt my head again\u2026. Sunburnt scalp hurts\u2026..",
  "id" : 343695111353421824,
  "created_at" : "2013-06-09 11:44:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343566937277734914",
  "geo" : { },
  "id_str" : "343567093951774720",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 what channel? :) And thanks - that was the beer talking :)",
  "id" : 343567093951774720,
  "in_reply_to_status_id" : 343566937277734914,
  "created_at" : "2013-06-09 03:15:53 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343562182614740992",
  "geo" : { },
  "id_str" : "343566634402852864",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 what you doing up son? I can't get to sleep... entertain me :)",
  "id" : 343566634402852864,
  "in_reply_to_status_id" : 343562182614740992,
  "created_at" : "2013-06-09 03:14:03 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343494025938075648",
  "text" : "I need to write or find an app that integrates with the twitter API and identifies all the ginger people that I follow and block the fuckers",
  "id" : 343494025938075648,
  "created_at" : "2013-06-08 22:25:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343492951470661632",
  "text" : "I\u2019m quite fucking drunk but sober enough to get on twitter\u2026. This could be bad\u2026 let\u2019s see what happens\u2026..",
  "id" : 343492951470661632,
  "created_at" : "2013-06-08 22:21:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 3, 10 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343492507251908609",
  "text" : "RT @wycats: PRISM is not a new data collection program. It is operational details of an existing, well-known program.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/getfalcon.pro\" rel=\"nofollow\"\u003EFalcon-Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343470239855558656",
    "text" : "PRISM is not a new data collection program. It is operational details of an existing, well-known program.",
    "id" : 343470239855558656,
    "created_at" : "2013-06-08 20:51:01 +0000",
    "user" : {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "protected" : false,
      "id_str" : "8526432",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3250074047\/46d910af94e25187832cb4a3bc84b2b5_normal.jpeg",
      "id" : 8526432,
      "verified" : false
    }
  },
  "id" : 343492507251908609,
  "created_at" : "2013-06-08 22:19:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 3, 16 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 55, 61 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343492302506962947",
  "text" : "RT @Paul_Moffett: the only way is shoreditch featuring @swmcc I think it might work",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 37, 43 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "343455249413046272",
    "geo" : { },
    "id_str" : "343475871274913792",
    "in_reply_to_user_id" : 804717,
    "text" : "the only way is shoreditch featuring @swmcc I think it might work",
    "id" : 343475871274913792,
    "in_reply_to_status_id" : 343455249413046272,
    "created_at" : "2013-06-08 21:13:23 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "protected" : false,
      "id_str" : "36913698",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1175980356\/92313091_N00_normal.jpg",
      "id" : 36913698,
      "verified" : false
    }
  },
  "id" : 343492302506962947,
  "created_at" : "2013-06-08 22:18:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343445481671770112",
  "geo" : { },
  "id_str" : "343455249413046272",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett Id last about twenty seconds there - be a good tv show though",
  "id" : 343455249413046272,
  "in_reply_to_status_id" : 343445481671770112,
  "created_at" : "2013-06-08 19:51:27 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/343451782787248129\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/kzsMqhdTQc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMQvk6bCMAAS1FQ.jpg",
      "id_str" : "343451782791442432",
      "id" : 343451782791442432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMQvk6bCMAAS1FQ.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/kzsMqhdTQc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343451782787248129",
  "text" : "Parentals at BBQ 3.0 http:\/\/t.co\/kzsMqhdTQc",
  "id" : 343451782787248129,
  "created_at" : "2013-06-08 19:37:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/343431081288151040\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/kMFxaNgvjF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMQcv7VCMAAjAIm.jpg",
      "id_str" : "343431081292345344",
      "id" : 343431081292345344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMQcv7VCMAAjAIm.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/kMFxaNgvjF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343431081288151040",
  "text" : "BBQ 3.0 so far http:\/\/t.co\/kMFxaNgvjF",
  "id" : 343431081288151040,
  "created_at" : "2013-06-08 18:15:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/FStoRP79KA",
      "expanded_url" : "http:\/\/instagram.com\/p\/aTo5b1BX8L\/",
      "display_url" : "instagram.com\/p\/aTo5b1BX8L\/"
    } ]
  },
  "geo" : { },
  "id_str" : "343423831786004480",
  "text" : "Bootstrapping BBQ 3.0 http:\/\/t.co\/FStoRP79KA",
  "id" : 343423831786004480,
  "created_at" : "2013-06-08 17:46:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/343298344518574080\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/GmHfVbCSAe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMOkBoVCYAELagM.jpg",
      "id_str" : "343298344522768385",
      "id" : 343298344522768385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMOkBoVCYAELagM.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GmHfVbCSAe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343298344518574080",
  "text" : "Steaks for BBQ 3.0 from @foursquarefood http:\/\/t.co\/GmHfVbCSAe",
  "id" : 343298344518574080,
  "created_at" : "2013-06-08 09:27:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/AR5wENtpOa",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ysmN0pBKxbw",
      "display_url" : "youtube.com\/watch?v=ysmN0p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343287037849395200",
  "text" : "BBQ 3.0 - Getting the meat now... Making it Ron Swanson (my idol) style. http:\/\/t.co\/AR5wENtpOa",
  "id" : 343287037849395200,
  "created_at" : "2013-06-08 08:43:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truebill",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343097146230325248",
  "geo" : { },
  "id_str" : "343100621408321537",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I can do the same with a tennis ball. #truebill",
  "id" : 343100621408321537,
  "in_reply_to_status_id" : 343097146230325248,
  "created_at" : "2013-06-07 20:22:17 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343093278742294529",
  "geo" : { },
  "id_str" : "343095927139082240",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl no retort means I win :) Beer might have played a part on my retort. :)",
  "id" : 343095927139082240,
  "in_reply_to_status_id" : 343093278742294529,
  "created_at" : "2013-06-07 20:03:38 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "speakingwithhermouthfull",
      "indices" : [ 112, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343093278742294529",
  "geo" : { },
  "id_str" : "343093918486900736",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I will once your sister lets go off my cock she said she will be a while - I think that\u2019s what she said #speakingwithhermouthfull",
  "id" : 343093918486900736,
  "in_reply_to_status_id" : 343093278742294529,
  "created_at" : "2013-06-07 19:55:39 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343087304207892480",
  "geo" : { },
  "id_str" : "343093055039078401",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I\u2019m at my parents having BBQ 2.0",
  "id" : 343093055039078401,
  "in_reply_to_status_id" : 343087304207892480,
  "created_at" : "2013-06-07 19:52:13 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343040065297059843",
  "geo" : { },
  "id_str" : "343040192472555522",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo you\u2019re a cheeky rat ass bastard.",
  "id" : 343040192472555522,
  "in_reply_to_status_id" : 343040065297059843,
  "created_at" : "2013-06-07 16:22:09 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343032703324659712",
  "geo" : { },
  "id_str" : "343037927716167681",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo oh and fuck you",
  "id" : 343037927716167681,
  "in_reply_to_status_id" : 343032703324659712,
  "created_at" : "2013-06-07 16:13:09 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343032703324659712",
  "geo" : { },
  "id_str" : "343037876092674048",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo dude\u2026 on reflection that was not a good idea in Belfast rush hour Friday traffic\u2026 In this heat\u2026. With the milk seat\u2026\u2026",
  "id" : 343037876092674048,
  "in_reply_to_status_id" : 343032703324659712,
  "created_at" : "2013-06-07 16:12:57 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shitidontsayoften",
      "indices" : [ 48, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343031597475450881",
  "text" : "I just turned my air conditioning on in my car. #shitidontsayoften",
  "id" : 343031597475450881,
  "created_at" : "2013-06-07 15:48:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 17, 27 ],
      "id_str" : "240194412",
      "id" : 240194412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342981325625626624",
  "geo" : { },
  "id_str" : "343017098546647041",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @RepKnight No Mike, shorts and sandals are wrong!!!!!!",
  "id" : 343017098546647041,
  "in_reply_to_status_id" : 342981325625626624,
  "created_at" : "2013-06-07 14:50:23 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 3, 19 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 21, 27 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 28, 38 ],
      "id_str" : "240194412",
      "id" : 240194412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343016996188856320",
  "text" : "RT @michaelnsimpson: @swmcc @RepKnight I see a lack of shorts and sandals in that picture Stevie... You're doing it all wrong!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "RepKnight",
        "screen_name" : "RepKnight",
        "indices" : [ 7, 17 ],
        "id_str" : "240194412",
        "id" : 240194412
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342981325625626624",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @RepKnight I see a lack of shorts and sandals in that picture Stevie... You're doing it all wrong!",
    "id" : 342981325625626624,
    "created_at" : "2013-06-07 12:28:14 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "protected" : false,
      "id_str" : "311597138",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2333500505\/4800E726-34AE-4733-936C-8546E112D838_normal",
      "id" : 311597138,
      "verified" : false
    }
  },
  "id" : 343016996188856320,
  "created_at" : "2013-06-07 14:49:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 3, 15 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 22, 32 ],
      "id_str" : "240194412",
      "id" : 240194412
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 47, 55 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 56, 65 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 66, 72 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Mark Devlin",
      "screen_name" : "MDev247",
      "indices" : [ 73, 81 ],
      "id_str" : "46503614",
      "id" : 46503614
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DebbieCReid\/status\/342973720979206144\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/YR6UoMM0N1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMJ8yDbCcAEXP3B.jpg",
      "id_str" : "342973720987594753",
      "id" : 342973720987594753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMJ8yDbCcAEXP3B.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YR6UoMM0N1"
    } ],
    "hashtags" : [ {
      "text" : "sunshine",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342973873186287616",
  "text" : "RT @DebbieCReid: Team @RepKnight  BBQ lunch cc @jbrevel @davehedo @swmcc @MDev247 #sunshine:-) http:\/\/t.co\/YR6UoMM0N1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RepKnight",
        "screen_name" : "RepKnight",
        "indices" : [ 5, 15 ],
        "id_str" : "240194412",
        "id" : 240194412
      }, {
        "name" : "John Loughrey",
        "screen_name" : "jbrevel",
        "indices" : [ 30, 38 ],
        "id_str" : "50685221",
        "id" : 50685221
      }, {
        "name" : "David Henderson",
        "screen_name" : "davehedo",
        "indices" : [ 39, 48 ],
        "id_str" : "50985598",
        "id" : 50985598
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 49, 55 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Mark Devlin",
        "screen_name" : "MDev247",
        "indices" : [ 56, 64 ],
        "id_str" : "46503614",
        "id" : 46503614
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DebbieCReid\/status\/342973720979206144\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/YR6UoMM0N1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMJ8yDbCcAEXP3B.jpg",
        "id_str" : "342973720987594753",
        "id" : 342973720987594753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMJ8yDbCcAEXP3B.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/YR6UoMM0N1"
      } ],
      "hashtags" : [ {
        "text" : "sunshine",
        "indices" : [ 65, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342973720979206144",
    "text" : "Team @RepKnight  BBQ lunch cc @jbrevel @davehedo @swmcc @MDev247 #sunshine:-) http:\/\/t.co\/YR6UoMM0N1",
    "id" : 342973720979206144,
    "created_at" : "2013-06-07 11:58:02 +0000",
    "user" : {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "protected" : false,
      "id_str" : "53155256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000402062796\/48362b18cdee598e45ee405286ad7442_normal.png",
      "id" : 53155256,
      "verified" : false
    }
  },
  "id" : 342973873186287616,
  "created_at" : "2013-06-07 11:58:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 34, 43 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "topman",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342960847750037504",
  "text" : "Rumour round the campfire is that @davehedo is gonna BBQ me a burger before I go to my meeting. #topman",
  "id" : 342960847750037504,
  "created_at" : "2013-06-07 11:06:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 30, 40 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/342944307667410944\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/dJ8EOepTbB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMJiB-SCIAAzG9J.png",
      "id_str" : "342944307671605248",
      "id" : 342944307671605248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMJiB-SCIAAzG9J.png",
      "sizes" : [ {
        "h" : 40,
        "resize" : "fit",
        "w" : 727
      }, {
        "h" : 40,
        "resize" : "fit",
        "w" : 727
      }, {
        "h" : 40,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 19,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 33,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/dJ8EOepTbB"
    } ],
    "hashtags" : [ {
      "text" : "cabal",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342944307667410944",
  "text" : "Rumblings from the #cabal and @carisenda hits it in the head with this quote. http:\/\/t.co\/dJ8EOepTbB",
  "id" : 342944307667410944,
  "created_at" : "2013-06-07 10:01:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instil",
      "screen_name" : "instil",
      "indices" : [ 110, 117 ],
      "id_str" : "804212370",
      "id" : 804212370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342938313654669312",
  "text" : "I am really regretting agreeing to a meeting in Belfast this afternoon\u2026. Look at that day\u2026. But gotta talk to @instil peeps instead ;)",
  "id" : 342938313654669312,
  "created_at" : "2013-06-07 09:37:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342665243761197056",
  "geo" : { },
  "id_str" : "342665479632060416",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams cheeky.... tascomi made or bought?",
  "id" : 342665479632060416,
  "in_reply_to_status_id" : 342665243761197056,
  "created_at" : "2013-06-06 15:33:11 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342661175793823744",
  "geo" : { },
  "id_str" : "342664969508253697",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams nice.... What is in it?",
  "id" : 342664969508253697,
  "in_reply_to_status_id" : 342661175793823744,
  "created_at" : "2013-06-06 15:31:09 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Growl",
      "screen_name" : "GrowlMac",
      "indices" : [ 51, 60 ],
      "id_str" : "73403755",
      "id" : 73403755
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/342656320060657665\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/60hKZqFnf9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMFcG42CEAEkee5.png",
      "id_str" : "342656320064851969",
      "id" : 342656320064851969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMFcG42CEAEkee5.png",
      "sizes" : [ {
        "h" : 283,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 494
      } ],
      "display_url" : "pic.twitter.com\/60hKZqFnf9"
    } ],
    "hashtags" : [ {
      "text" : "properdevelopment",
      "indices" : [ 90, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342656320060657665",
  "text" : "Ron Burgundy makes tests failing  icer :) Just got @GrowlMac to annoy me when tests fail. #properdevelopment http:\/\/t.co\/60hKZqFnf9",
  "id" : 342656320060657665,
  "created_at" : "2013-06-06 14:56:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raspberry Pi",
      "screen_name" : "Raspberry_Pi",
      "indices" : [ 10, 23 ],
      "id_str" : "302666251",
      "id" : 302666251
    }, {
      "name" : "The Pi Hut",
      "screen_name" : "ThePiHut",
      "indices" : [ 39, 48 ],
      "id_str" : "761589870",
      "id" : 761589870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342614008710459392",
  "text" : "I hope my @Raspberry_Pi comes from the @ThePiHut today as I am in Belfast tomorrow afternoon so if doesn't come today I'll have to wait...",
  "id" : 342614008710459392,
  "created_at" : "2013-06-06 12:08:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drumbomadness",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342566651910307840",
  "geo" : { },
  "id_str" : "342585757585776640",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne tops on so far - but the day is young... #drumbomadness",
  "id" : 342585757585776640,
  "in_reply_to_status_id" : 342566651910307840,
  "created_at" : "2013-06-06 10:16:24 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342585630770987009",
  "text" : "I also spelt steak wrongly...... Pffffttttt - \/me gets back to rspec",
  "id" : 342585630770987009,
  "created_at" : "2013-06-06 10:15:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 23, 31 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342585509224263680",
  "text" : "No geek\/nerd date with @jbrevel this evening... BBQ at the McCullough senior house... so I shall be eating a stake instead of eating John ;)",
  "id" : 342585509224263680,
  "created_at" : "2013-06-06 10:15:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342566026963218432",
  "text" : "People are wearing shorts and sandals to the office today... Not good. I wanna go home.",
  "id" : 342566026963218432,
  "created_at" : "2013-06-06 08:58:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/kJcESA3hqw",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=78juOpTM3tE#",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342375348652081152",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel http:\/\/t.co\/kJcESA3hqw! - awesome!!!",
  "id" : 342375348652081152,
  "created_at" : "2013-06-05 20:20:18 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/p8cH6dqGf0",
      "expanded_url" : "http:\/\/instagram.com\/p\/aL56QQBXxz\/",
      "display_url" : "instagram.com\/p\/aL56QQBXxz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "342335292759490560",
  "text" : "Choc pop http:\/\/t.co\/p8cH6dqGf0",
  "id" : 342335292759490560,
  "created_at" : "2013-06-05 17:41:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342305666330947585",
  "geo" : { },
  "id_str" : "342308561101127682",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell nope not yet. I will put this in my list though. Thanks :)",
  "id" : 342308561101127682,
  "in_reply_to_status_id" : 342305666330947585,
  "created_at" : "2013-06-05 15:54:55 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/342305358653579264\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/j9oQv2213P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMAc6PvCYAAi9kk.png",
      "id_str" : "342305358661967872",
      "id" : 342305358661967872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMAc6PvCYAAi9kk.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/j9oQv2213P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342305358653579264",
  "text" : "Oh yeah :) http:\/\/t.co\/j9oQv2213P",
  "id" : 342305358653579264,
  "created_at" : "2013-06-05 15:42:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342304109933768704",
  "text" : "Too good a day to be banging on the command line\u2026. Going home to cut the grass in 20. It\u2019ll soon pish and things will be back to normal.",
  "id" : 342304109933768704,
  "created_at" : "2013-06-05 15:37:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342291802071633920",
  "text" : "\u007B\u201Cresult\u201D: \u201CYes, yes you do!\u201D\u007D",
  "id" : 342291802071633920,
  "created_at" : "2013-06-05 14:48:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342291571737251841",
  "text" : "curl -H \u201CContent-Type: application\/json\u201D -X POST -d \u2018\u007B\u201Cweather\u201D:[\u201CFucking Great\u201D],\u201Dgrass\u201D:[\u201Cneeds cut\u201D]\u007D\u2019 http:\/\/swmcc:1337\/todo",
  "id" : 342291571737251841,
  "created_at" : "2013-06-05 14:47:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kdYDNYakqB",
      "expanded_url" : "http:\/\/cdn.memegenerator.net\/instances\/400x\/23928246.jpg",
      "display_url" : "cdn.memegenerator.net\/instances\/400x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342289531099291648",
  "text" : "http:\/\/t.co\/kdYDNYakqB",
  "id" : 342289531099291648,
  "created_at" : "2013-06-05 14:39:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Geusebroek",
      "screen_name" : "krisgeus",
      "indices" : [ 3, 12 ],
      "id_str" : "66676432",
      "id" : 66676432
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neo4j",
      "indices" : [ 48, 54 ]
    }, {
      "text" : "hadoop",
      "indices" : [ 69, 76 ]
    }, {
      "text" : "nosqlmatters",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/94KFYmMiXZ",
      "expanded_url" : "http:\/\/vimeo.com\/67131459",
      "display_url" : "vimeo.com\/67131459"
    } ]
  },
  "geo" : { },
  "id_str" : "342273022058708993",
  "text" : "RT @krisgeus: Video of my talk about creating a #neo4j database with #hadoop is online http:\/\/t.co\/94KFYmMiXZ #nosqlmatters",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "neo4j",
        "indices" : [ 34, 40 ]
      }, {
        "text" : "hadoop",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "nosqlmatters",
        "indices" : [ 96, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/94KFYmMiXZ",
        "expanded_url" : "http:\/\/vimeo.com\/67131459",
        "display_url" : "vimeo.com\/67131459"
      } ]
    },
    "geo" : { },
    "id_str" : "342272265586626560",
    "text" : "Video of my talk about creating a #neo4j database with #hadoop is online http:\/\/t.co\/94KFYmMiXZ #nosqlmatters",
    "id" : 342272265586626560,
    "created_at" : "2013-06-05 13:30:41 +0000",
    "user" : {
      "name" : "Kris Geusebroek",
      "screen_name" : "krisgeus",
      "protected" : false,
      "id_str" : "66676432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/375736736\/213850155_2_vG-N_normal.jpg",
      "id" : 66676432,
      "verified" : false
    }
  },
  "id" : 342273022058708993,
  "created_at" : "2013-06-05 13:33:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/342270045155622912\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/grBIDEwLT2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL_8yusCAAABKxk.png",
      "id_str" : "342270045159817216",
      "id" : 342270045159817216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL_8yusCAAABKxk.png",
      "sizes" : [ {
        "h" : 151,
        "resize" : "fit",
        "w" : 823
      }, {
        "h" : 151,
        "resize" : "fit",
        "w" : 823
      }, {
        "h" : 110,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 62,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/grBIDEwLT2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342270045155622912",
  "text" : "I am going to have to stop talking to this man on ichat..... http:\/\/t.co\/grBIDEwLT2",
  "id" : 342270045155622912,
  "created_at" : "2013-06-05 13:21:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Webber",
      "screen_name" : "jimwebber",
      "indices" : [ 0, 10 ],
      "id_str" : "13521812",
      "id" : 13521812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342237079205457920",
  "geo" : { },
  "id_str" : "342238464391139328",
  "in_reply_to_user_id" : 13521812,
  "text" : "@jimwebber thanks, wanted to do more - so am doing a followup in a few months.",
  "id" : 342238464391139328,
  "in_reply_to_status_id" : 342237079205457920,
  "created_at" : "2013-06-05 11:16:23 +0000",
  "in_reply_to_screen_name" : "jimwebber",
  "in_reply_to_user_id_str" : "13521812",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 1, 11 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342230705876643840",
  "text" : "\u201C@carisenda: So far today: forgot to wish wife happy birthday, broke trunk, broke staging, broke production, forgot to .\u201D #FUCKYOUWEDNESDAY",
  "id" : 342230705876643840,
  "created_at" : "2013-06-05 10:45:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Block",
      "screen_name" : "ryan",
      "indices" : [ 3, 8 ],
      "id_str" : "862681",
      "id" : 862681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/8PuIRxOOyE",
      "expanded_url" : "http:\/\/i.imgur.com\/KnRqnE8.gif",
      "display_url" : "i.imgur.com\/KnRqnE8.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "342230128367108097",
  "text" : "RT @ryan: The folks who\u2019ve read the Game of Thrones books, on TV viewers\u2019 reactions to the red wedding (in gif form): http:\/\/t.co\/8PuIRxOOyE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/8PuIRxOOyE",
        "expanded_url" : "http:\/\/i.imgur.com\/KnRqnE8.gif",
        "display_url" : "i.imgur.com\/KnRqnE8.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "342082360436723715",
    "text" : "The folks who\u2019ve read the Game of Thrones books, on TV viewers\u2019 reactions to the red wedding (in gif form): http:\/\/t.co\/8PuIRxOOyE",
    "id" : 342082360436723715,
    "created_at" : "2013-06-05 00:56:04 +0000",
    "user" : {
      "name" : "Ryan Block",
      "screen_name" : "ryan",
      "protected" : false,
      "id_str" : "862681",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3279804601\/dd6c3a124f4fbf8f88aaee46cea7e3ad_normal.jpeg",
      "id" : 862681,
      "verified" : true
    }
  },
  "id" : 342230128367108097,
  "created_at" : "2013-06-05 10:43:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 3, 10 ],
      "id_str" : "60141834",
      "id" : 60141834
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 12, 18 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342222347044003840",
  "text" : "RT @padzor: @swmcc I hear your ruby talk was very successful, but apparently you need to swear more often.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342222096916676608",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc I hear your ruby talk was very successful, but apparently you need to swear more often.",
    "id" : 342222096916676608,
    "created_at" : "2013-06-05 10:11:20 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "padzor",
      "screen_name" : "padzor",
      "protected" : false,
      "id_str" : "60141834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1820502056\/me_normal.jpg",
      "id" : 60141834,
      "verified" : false
    }
  },
  "id" : 342222347044003840,
  "created_at" : "2013-06-05 10:12:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Devlin",
      "screen_name" : "MDev247",
      "indices" : [ 1, 9 ],
      "id_str" : "46503614",
      "id" : 46503614
    }, {
      "name" : "Perch",
      "screen_name" : "grabaperch",
      "indices" : [ 48, 59 ],
      "id_str" : "24390745",
      "id" : 24390745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "welldone",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342221373302792192",
  "text" : ".@MDev247 done me a mini site for work and used @grabaperch - very very impressed in both the work and the wee app... #welldone",
  "id" : 342221373302792192,
  "created_at" : "2013-06-05 10:08:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil McClure",
      "screen_name" : "overture8",
      "indices" : [ 0, 10 ],
      "id_str" : "19857364",
      "id" : 19857364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342021411520524288",
  "geo" : { },
  "id_str" : "342205475821080576",
  "in_reply_to_user_id" : 19857364,
  "text" : "@overture8 Thanks Phil. Get your talk ready :)",
  "id" : 342205475821080576,
  "in_reply_to_status_id" : 342021411520524288,
  "created_at" : "2013-06-05 09:05:17 +0000",
  "in_reply_to_screen_name" : "overture8",
  "in_reply_to_user_id_str" : "19857364",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342023968640888832",
  "geo" : { },
  "id_str" : "342205397349842944",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden :D Awesome.",
  "id" : 342205397349842944,
  "in_reply_to_status_id" : 342023968640888832,
  "created_at" : "2013-06-05 09:04:59 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris McGrath",
      "screen_name" : "chrismcg",
      "indices" : [ 0, 9 ],
      "id_str" : "729883",
      "id" : 729883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342027451041460226",
  "geo" : { },
  "id_str" : "342205367981318144",
  "in_reply_to_user_id" : 729883,
  "text" : "@chrismcg cheers Chris",
  "id" : 342205367981318144,
  "in_reply_to_status_id" : 342027451041460226,
  "created_at" : "2013-06-05 09:04:52 +0000",
  "in_reply_to_screen_name" : "chrismcg",
  "in_reply_to_user_id_str" : "729883",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ewing",
      "screen_name" : "brianjewing",
      "indices" : [ 0, 12 ],
      "id_str" : "328097214",
      "id" : 328097214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342190885624229888",
  "geo" : { },
  "id_str" : "342205320384372736",
  "in_reply_to_user_id" : 328097214,
  "text" : "@brianjewing cheers brian",
  "id" : 342205320384372736,
  "in_reply_to_status_id" : 342190885624229888,
  "created_at" : "2013-06-05 09:04:40 +0000",
  "in_reply_to_screen_name" : "brianjewing",
  "in_reply_to_user_id_str" : "328097214",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Holdsworth",
      "screen_name" : "holsee",
      "indices" : [ 0, 7 ],
      "id_str" : "17806780",
      "id" : 17806780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342202034826649600",
  "geo" : { },
  "id_str" : "342205287547150336",
  "in_reply_to_user_id" : 17806780,
  "text" : "@holsee Cheers. Will start working on version 2.0 this month at some stage.",
  "id" : 342205287547150336,
  "in_reply_to_status_id" : 342202034826649600,
  "created_at" : "2013-06-05 09:04:33 +0000",
  "in_reply_to_screen_name" : "holsee",
  "in_reply_to_user_id_str" : "17806780",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyouwesnesday",
      "indices" : [ 57, 74 ]
    }, {
      "text" : "fuckyouwednesday",
      "indices" : [ 103, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342176136681361408",
  "text" : "So last Wednesday fucked me over. Lets hope this isn\u2019t a #fuckyouwesnesday - it\u2019s too nice a day for a #fuckyouwednesday",
  "id" : 342176136681361408,
  "created_at" : "2013-06-05 07:08:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342013987531132928",
  "geo" : { },
  "id_str" : "342014207908278272",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl alright i think. Popped my technical talk cherry (kinda) - so not too bad. Hopefully gets more people up to talk.",
  "id" : 342014207908278272,
  "in_reply_to_status_id" : 342013987531132928,
  "created_at" : "2013-06-04 20:25:16 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 41, 50 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/UDDhniQ8mZ",
      "expanded_url" : "http:\/\/swm.cc\/#talks",
      "display_url" : "swm.cc\/#talks"
    } ]
  },
  "geo" : { },
  "id_str" : "342013895264833536",
  "text" : "Slides are up. Version 2.0 will be after @hamstarr watches at least one season of The Wire. http:\/\/t.co\/UDDhniQ8mZ and scroll down.",
  "id" : 342013895264833536,
  "created_at" : "2013-06-04 20:24:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342012397281759232",
  "geo" : { },
  "id_str" : "342012553389543424",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl do I get to play with you tomorrow? :)",
  "id" : 342012553389543424,
  "in_reply_to_status_id" : 342012397281759232,
  "created_at" : "2013-06-04 20:18:41 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Mitchell",
      "screen_name" : "pixelpage",
      "indices" : [ 0, 10 ],
      "id_str" : "52710181",
      "id" : 52710181
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 11, 23 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342007005877268480",
  "geo" : { },
  "id_str" : "342012228872056832",
  "in_reply_to_user_id" : 52710181,
  "text" : "@pixelpage @BelfastRuby cheers colin :)",
  "id" : 342012228872056832,
  "in_reply_to_status_id" : 342007005877268480,
  "created_at" : "2013-06-04 20:17:24 +0000",
  "in_reply_to_screen_name" : "pixelpage",
  "in_reply_to_user_id_str" : "52710181",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Mitchell",
      "screen_name" : "pixelpage",
      "indices" : [ 3, 13 ],
      "id_str" : "52710181",
      "id" : 52710181
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 31, 43 ],
      "id_str" : "454835425",
      "id" : 454835425
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 71, 77 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342012189093277698",
  "text" : "RT @pixelpage: Good meeting at @BelfastRuby this evening, well done to @swmcc for getting up &amp; breaking the Neo4j ice",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Belfast Ruby",
        "screen_name" : "BelfastRuby",
        "indices" : [ 16, 28 ],
        "id_str" : "454835425",
        "id" : 454835425
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 56, 62 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342007005877268480",
    "text" : "Good meeting at @BelfastRuby this evening, well done to @swmcc for getting up &amp; breaking the Neo4j ice",
    "id" : 342007005877268480,
    "created_at" : "2013-06-04 19:56:39 +0000",
    "user" : {
      "name" : "Colin Mitchell",
      "screen_name" : "pixelpage",
      "protected" : false,
      "id_str" : "52710181",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/300081701\/cm_portrait_150x183_normal.jpg",
      "id" : 52710181,
      "verified" : false
    }
  },
  "id" : 342012189093277698,
  "created_at" : "2013-06-04 20:17:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disgruntled Mage",
      "screen_name" : "tyndyll",
      "indices" : [ 3, 11 ],
      "id_str" : "19344990",
      "id" : 19344990
    }, {
      "name" : "Colin Mitchell",
      "screen_name" : "pixelpage",
      "indices" : [ 13, 23 ],
      "id_str" : "52710181",
      "id" : 52710181
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 24, 36 ],
      "id_str" : "454835425",
      "id" : 454835425
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 37, 43 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Neo4j",
      "screen_name" : "neo4j",
      "indices" : [ 70, 76 ],
      "id_str" : "22467617",
      "id" : 22467617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342012160848826368",
  "text" : "RT @tyndyll: @pixelpage @BelfastRuby @swmcc 2ed. Feel obliged to code @neo4j &amp; watch The Wire in parallel.May start w\/ Breaking Bad as a sm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Colin Mitchell",
        "screen_name" : "pixelpage",
        "indices" : [ 0, 10 ],
        "id_str" : "52710181",
        "id" : 52710181
      }, {
        "name" : "Belfast Ruby",
        "screen_name" : "BelfastRuby",
        "indices" : [ 11, 23 ],
        "id_str" : "454835425",
        "id" : 454835425
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 24, 30 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Neo4j",
        "screen_name" : "neo4j",
        "indices" : [ 57, 63 ],
        "id_str" : "22467617",
        "id" : 22467617
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "342007005877268480",
    "geo" : { },
    "id_str" : "342011196444139521",
    "in_reply_to_user_id" : 52710181,
    "text" : "@pixelpage @BelfastRuby @swmcc 2ed. Feel obliged to code @neo4j &amp; watch The Wire in parallel.May start w\/ Breaking Bad as a smaller data set",
    "id" : 342011196444139521,
    "in_reply_to_status_id" : 342007005877268480,
    "created_at" : "2013-06-04 20:13:18 +0000",
    "in_reply_to_screen_name" : "pixelpage",
    "in_reply_to_user_id_str" : "52710181",
    "user" : {
      "name" : "Disgruntled Mage",
      "screen_name" : "tyndyll",
      "protected" : false,
      "id_str" : "19344990",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/347504464\/blackmage_normal.png",
      "id" : 19344990,
      "verified" : false
    }
  },
  "id" : 342012160848826368,
  "created_at" : "2013-06-04 20:17:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edan Hewitt",
      "screen_name" : "EdanHewitt",
      "indices" : [ 3, 14 ],
      "id_str" : "464887553",
      "id" : 464887553
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialmedia",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/KZW2gjANU3",
      "expanded_url" : "http:\/\/ednh.ca\/Z0toTT",
      "display_url" : "ednh.ca\/Z0toTT"
    } ]
  },
  "geo" : { },
  "id_str" : "341941591277187072",
  "text" : "RT @EdanHewitt: How Oreo Culture-Jacked The Super Bowl http:\/\/t.co\/KZW2gjANU3 authentic #socialmedia is important for your brand",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socialmedia",
        "indices" : [ 72, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/KZW2gjANU3",
        "expanded_url" : "http:\/\/ednh.ca\/Z0toTT",
        "display_url" : "ednh.ca\/Z0toTT"
      } ]
    },
    "geo" : { },
    "id_str" : "341940427735330816",
    "text" : "How Oreo Culture-Jacked The Super Bowl http:\/\/t.co\/KZW2gjANU3 authentic #socialmedia is important for your brand",
    "id" : 341940427735330816,
    "created_at" : "2013-06-04 15:32:05 +0000",
    "user" : {
      "name" : "Edan Hewitt",
      "screen_name" : "EdanHewitt",
      "protected" : false,
      "id_str" : "464887553",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000601423588\/dc6f07015e9fc235c3f753448235466e_normal.png",
      "id" : 464887553,
      "verified" : false
    }
  },
  "id" : 341941591277187072,
  "created_at" : "2013-06-04 15:36:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 8, 21 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "danceforme",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341937767007268865",
  "geo" : { },
  "id_str" : "341937910062383105",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @stevebiscuit I always do\u2026 you hear tomorrow on an unrelated note ;) #danceforme",
  "id" : 341937910062383105,
  "in_reply_to_status_id" : 341937767007268865,
  "created_at" : "2013-06-04 15:22:05 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 8, 21 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341916966904279040",
  "geo" : { },
  "id_str" : "341937603618172929",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @stevebiscuit cheers fellas :)",
  "id" : 341937603618172929,
  "in_reply_to_status_id" : 341916966904279040,
  "created_at" : "2013-06-04 15:20:52 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "happygeek",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341862701410185216",
  "text" : "Coding away in here in a load of tmux sessions and Master of Puppets comes on. Sun outside\u2026 #happygeek",
  "id" : 341862701410185216,
  "created_at" : "2013-06-04 10:23:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GameOfThrones",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341676472223793152",
  "text" : "Brilliantly done. A bit different in the book but brilliantly done. #GameOfThrones",
  "id" : 341676472223793152,
  "created_at" : "2013-06-03 22:03:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341673687579242496",
  "text" : "Right\u2026. Here we go\u2026. The scene has started :)",
  "id" : 341673687579242496,
  "created_at" : "2013-06-03 21:52:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 0, 10 ],
      "id_str" : "7311162",
      "id" : 7311162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341664489453809664",
  "geo" : { },
  "id_str" : "341664840777093122",
  "in_reply_to_user_id" : 7311162,
  "text" : "@mharrigan yup if its done right.",
  "id" : 341664840777093122,
  "in_reply_to_status_id" : 341664489453809664,
  "created_at" : "2013-06-03 21:17:00 +0000",
  "in_reply_to_screen_name" : "mharrigan",
  "in_reply_to_user_id_str" : "7311162",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341664077124366336",
  "text" : "Sitting down now to watch Game of Thrones. I know what\u2019s coming. Awesome\u2026. Wonder how they\u2019ll do it.",
  "id" : 341664077124366336,
  "created_at" : "2013-06-03 21:13:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341643396454170624",
  "geo" : { },
  "id_str" : "341659011671810048",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden cheers :)",
  "id" : 341659011671810048,
  "in_reply_to_status_id" : 341643396454170624,
  "created_at" : "2013-06-03 20:53:50 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341579466570604545",
  "text" : "Going home at five to practise my talk, watch game of thrones and sleep. In that order...",
  "id" : 341579466570604545,
  "created_at" : "2013-06-03 15:37:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 1, 12 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341492631202848768",
  "text" : ".@bigwetfish are a class act. My debit card expired on Friday and payment was due on Saturday. They kept my server up regardless. Nice ppl!",
  "id" : 341492631202848768,
  "created_at" : "2013-06-03 09:52:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341464349673660416",
  "geo" : { },
  "id_str" : "341467559847133185",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates Only way I will learn to bring my keys in I guess :)",
  "id" : 341467559847133185,
  "in_reply_to_status_id" : 341464349673660416,
  "created_at" : "2013-06-03 08:13:05 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 0, 13 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/341462604524437504\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/HjeIF9yCeg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL0ebf9CQAAl2Qt.jpg",
      "id_str" : "341462604532826112",
      "id" : 341462604532826112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL0ebf9CQAAl2Qt.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/HjeIF9yCeg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341461881694855169",
  "geo" : { },
  "id_str" : "341462604524437504",
  "in_reply_to_user_id" : 19125494,
  "text" : "@nicholabates still able to \u201Cget shit done\u201D though :) http:\/\/t.co\/HjeIF9yCeg",
  "id" : 341462604524437504,
  "in_reply_to_status_id" : 341461881694855169,
  "created_at" : "2013-06-03 07:53:23 +0000",
  "in_reply_to_screen_name" : "nicholabates",
  "in_reply_to_user_id_str" : "19125494",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amanidiot",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341459195775832064",
  "text" : "To everyone I work with. I early and I\u2019ve forgotten my work keys. Hurry up ppl :) #amanidiot",
  "id" : 341459195775832064,
  "created_at" : "2013-06-03 07:39:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341290553813643264",
  "text" : "Only thing productive this weekend. Moved my front room furniture round and I think the milk smell is gone from my car - maybe.",
  "id" : 341290553813643264,
  "created_at" : "2013-06-02 20:29:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341289335364132864",
  "geo" : { },
  "id_str" : "341289860436475904",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl but after my talk on Tuesday ill be back on it again. Just hate chasing my tail is all. But I ordered the pi at last :)",
  "id" : 341289860436475904,
  "in_reply_to_status_id" : 341289335364132864,
  "created_at" : "2013-06-02 20:26:58 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341289335364132864",
  "geo" : { },
  "id_str" : "341289639509901314",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl had a load of stuff to get done and missing Saturday morning\/afternoon has just fucked it in the ass his weekend.",
  "id" : 341289639509901314,
  "in_reply_to_status_id" : 341289335364132864,
  "created_at" : "2013-06-02 20:26:05 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341289001321377792",
  "text" : "This weekend never recovered from no sleep on Friday night. Useless - wasted - weekends.",
  "id" : 341289001321377792,
  "created_at" : "2013-06-02 20:23:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340910649452412928",
  "geo" : { },
  "id_str" : "340912943334055937",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl sexy Englishman link of that raspberry pi media thing old sir ;)",
  "id" : 340912943334055937,
  "in_reply_to_status_id" : 340910649452412928,
  "created_at" : "2013-06-01 19:29:14 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comicbookgirl19",
      "screen_name" : "cbgirl19",
      "indices" : [ 3, 12 ],
      "id_str" : "547289837",
      "id" : 547289837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/bAftktk9I7",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=8hVrlvRXGxg",
      "display_url" : "youtube.com\/watch?v=8hVrlv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340897855709523968",
  "text" : "RT @cbgirl19: Winter is HERE! It's Game of Thrones, Epic History: House Stark. \n  http:\/\/t.co\/bAftktk9I7",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/bAftktk9I7",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=8hVrlvRXGxg",
        "display_url" : "youtube.com\/watch?v=8hVrlv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "340896163974742017",
    "text" : "Winter is HERE! It's Game of Thrones, Epic History: House Stark. \n  http:\/\/t.co\/bAftktk9I7",
    "id" : 340896163974742017,
    "created_at" : "2013-06-01 18:22:33 +0000",
    "user" : {
      "name" : "Comicbookgirl19",
      "screen_name" : "cbgirl19",
      "protected" : false,
      "id_str" : "547289837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2393024767\/i88yfdx96g2kgivn7mww_normal.jpeg",
      "id" : 547289837,
      "verified" : false
    }
  },
  "id" : 340897855709523968,
  "created_at" : "2013-06-01 18:29:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ihaveethics",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340887950671888384",
  "text" : "It is also loud enough to be annoying to her parents but not noisy enough to annoy the heavily pregnant mother. #ihaveethics",
  "id" : 340887950671888384,
  "created_at" : "2013-06-01 17:49:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/340887548740112384\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/xX21VKxzNH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLsTa2PCEAASbay.jpg",
      "id_str" : "340887548752695296",
      "id" : 340887548752695296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLsTa2PCEAASbay.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/xX21VKxzNH"
    } ],
    "hashtags" : [ {
      "text" : "teachthemyoung",
      "indices" : [ 87, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340887548740112384",
  "text" : "Bought the wee woman her first laptop. Will be happy as long as she never uses an IDE. #teachthemyoung http:\/\/t.co\/xX21VKxzNH",
  "id" : 340887548740112384,
  "created_at" : "2013-06-01 17:48:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340799245214953474",
  "geo" : { },
  "id_str" : "340800860550488064",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor a bad fail or a good one?",
  "id" : 340800860550488064,
  "in_reply_to_status_id" : 340799245214953474,
  "created_at" : "2013-06-01 12:03:51 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 3, 16 ],
      "id_str" : "157198909",
      "id" : 157198909
    }, {
      "name" : "Boojum Belfast",
      "screen_name" : "boojum_belfast",
      "indices" : [ 18, 33 ],
      "id_str" : "281123406",
      "id" : 281123406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340791552802701314",
  "text" : "RT @chris_van_es: @boojum_belfast any plans to start doing breakfast burritos?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boojum Belfast",
        "screen_name" : "boojum_belfast",
        "indices" : [ 0, 15 ],
        "id_str" : "281123406",
        "id" : 281123406
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340782640774909952",
    "in_reply_to_user_id" : 281123406,
    "text" : "@boojum_belfast any plans to start doing breakfast burritos?",
    "id" : 340782640774909952,
    "created_at" : "2013-06-01 10:51:27 +0000",
    "in_reply_to_screen_name" : "boojum_belfast",
    "in_reply_to_user_id_str" : "281123406",
    "user" : {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "protected" : false,
      "id_str" : "157198909",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1268355537\/Photo_on_2011-03-11_at_01.03_normal.jpg",
      "id" : 157198909,
      "verified" : false
    }
  },
  "id" : 340791552802701314,
  "created_at" : "2013-06-01 11:26:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340785850751254528",
  "text" : "What a waste of a morning. Didn\u2019t get to sleep until 4 only up! Attending a two year olds birthday party later\u2026",
  "id" : 340785850751254528,
  "created_at" : "2013-06-01 11:04:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340639980886056960",
  "geo" : { },
  "id_str" : "340662174336827393",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl saves having that shite you have at our place. I can\u2019t get to asleep\u2026. Probably the coffee at 11pm too ;)",
  "id" : 340662174336827393,
  "in_reply_to_status_id" : 340639980886056960,
  "created_at" : "2013-06-01 02:52:46 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]