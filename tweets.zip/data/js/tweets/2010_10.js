Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29269207274",
  "text" : "Hello World... Again.. http:\/\/swm.cc\/blog\/",
  "id" : 29269207274,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29309354026",
  "text" : "Watching Jaime Oliver with the blonde one asleep on my shoulder.. Yup doesn't get much better than this...",
  "id" : 29309354026,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29215365041",
  "text" : "I fucking hate halloween....",
  "id" : 29215365041,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt James Campbell",
      "screen_name" : "mjc2112",
      "indices" : [ 3, 11 ],
      "id_str" : "150247453",
      "id" : 150247453
    }, {
      "name" : "BBC This Week",
      "screen_name" : "bbcthisweek",
      "indices" : [ 31, 43 ],
      "id_str" : "78602972",
      "id" : 78602972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29062563340",
  "text" : "RT @mjc2112: Katie Price is on @bbcthisweek  .  The entire rationale for the licence fee has just gone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC This Week",
        "screen_name" : "bbcthisweek",
        "indices" : [ 18, 30 ],
        "id_str" : "78602972",
        "id" : 78602972
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.8985515, -1.3979275 ]
    },
    "id_str" : "29031559538",
    "text" : "Katie Price is on @bbcthisweek  .  The entire rationale for the licence fee has just gone.",
    "id" : 29031559538,
    "created_at" : "2010-10-28 23:01:44 +0000",
    "user" : {
      "name" : "Matt James Campbell",
      "screen_name" : "mjc2112",
      "protected" : false,
      "id_str" : "150247453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000549280491\/a49741635f9f9865cf1f672a8cc2c3a7_normal.jpeg",
      "id" : 150247453,
      "verified" : false
    }
  },
  "id" : 29062563340,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29094598520",
  "geo" : { },
  "id_str" : "29095447281",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes is it gone? Feck they aren't even going to show the rest of this season... Hardly suprising though. It didn't know what it was.",
  "id" : 29095447281,
  "in_reply_to_status_id" : 29094598520,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29096609216",
  "text" : "Deleting around 11Gb of data of a server is a nice way to end a Friday..",
  "id" : 29096609216,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geekheaven",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29096924290",
  "geo" : { },
  "id_str" : "29098092281",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne much much better :D Porting applications from an old crusty server to a new cloud based server.. #geekheaven",
  "id" : 29098092281,
  "in_reply_to_status_id" : 29096924290,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29131347270",
  "geo" : { },
  "id_str" : "29133223373",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you can't say that and give no pic. Or at least tell us shat you were\/are.",
  "id" : 29133223373,
  "in_reply_to_status_id" : 29131347270,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28970026497",
  "geo" : { },
  "id_str" : "28970587690",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin only way to do it :)",
  "id" : 28970587690,
  "in_reply_to_status_id" : 28970026497,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28971343407",
  "text" : "I am in a terrible mood today.. Should come with a health warning.. Talking to SWM will lead to a boot in the balls\/bajingo..",
  "id" : 28971343407,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil McClure",
      "screen_name" : "overture8",
      "indices" : [ 0, 10 ],
      "id_str" : "19857364",
      "id" : 19857364
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 11, 22 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28971215988",
  "geo" : { },
  "id_str" : "28971395052",
  "in_reply_to_user_id" : 19857364,
  "text" : "@overture8 @johngirvin @stevebiscut - totally. its the only way to do admin I think. In fact anything db'ish should be done on CLI.",
  "id" : 28971395052,
  "in_reply_to_status_id" : 28971215988,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "overture8",
  "in_reply_to_user_id_str" : "19857364",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28973965820",
  "geo" : { },
  "id_str" : "28974260336",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Ohhhh did you get the job? :) Congrats congrats congrats :) Bet you handing in your notice is going to feel good..",
  "id" : 28974260336,
  "in_reply_to_status_id" : 28973965820,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28977541104",
  "geo" : { },
  "id_str" : "28978538101",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin I use openoffice. I find it clunky just like steve does.",
  "id" : 28978538101,
  "in_reply_to_status_id" : 28977541104,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 104, 111 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28987162900",
  "text" : "I have upgraded my SONOS client in work.. Time to do a cleansing on that fucking woeful playlist. Think @srushe will agree with me on that!",
  "id" : 28987162900,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28988552337",
  "geo" : { },
  "id_str" : "28989303667",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne once you hand in your notice.. Believe me.. You don't have to love your job, you just don't have to hate it.",
  "id" : 28989303667,
  "in_reply_to_status_id" : 28988552337,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28990540282",
  "text" : "Found this on my old DNS records for the ttl - 86400.. Why in earth did I do that???? Idiot..",
  "id" : 28990540282,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28877413200",
  "geo" : { },
  "id_str" : "28877904371",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes he's already got them.. Re-doing Star Wars in 3d.. LIKE WTF!!!!!!! GRRRRRRRR!!!!!",
  "id" : 28877904371,
  "in_reply_to_status_id" : 28877413200,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28879078368",
  "geo" : { },
  "id_str" : "28880101620",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe its one of those things.. Everyone gets it wrong.. Just like adduser v useradd.",
  "id" : 28880101620,
  "in_reply_to_status_id" : 28879078368,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28880412879",
  "text" : "I wish IRC had a \"like\" button",
  "id" : 28880412879,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28882006437",
  "geo" : { },
  "id_str" : "28882233940",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne but that's cool!!! Idiots - how about we do an ethnic cleansing of people like that :)",
  "id" : 28882233940,
  "in_reply_to_status_id" : 28882006437,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28900804378",
  "text" : "Going to PEECEE world to help the sis get a laptop. Hope no 'sales' ppl try and baffle me with science.. Funny to trip them up though.",
  "id" : 28900804378,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28800438380",
  "text" : "I have spent the last three hours having the same exact meeting I had two months ago! No joke. Grrrrrrrrr...",
  "id" : 28800438380,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28803279540",
  "text" : "Middle mgmt means that you have just enough power to listen when peeps talk, but not so much you can't tell anybody to go fuck themselves.",
  "id" : 28803279540,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28804787923",
  "geo" : { },
  "id_str" : "28805668889",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne excellent. \/me crosses fingers for Milne!",
  "id" : 28805668889,
  "in_reply_to_status_id" : 28804787923,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC This Week",
      "screen_name" : "bbcthisweek",
      "indices" : [ 22, 34 ],
      "id_str" : "78602972",
      "id" : 78602972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28830190518",
  "text" : "Katie Fuckin Price on @bbcthisweek. Haven't a clue what she is talking about. Don't. Care. Either.",
  "id" : 28830190518,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28687018493",
  "text" : "I. Want. This. Now. http:\/\/tinyurl.com\/37boy38",
  "id" : 28687018493,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28450748100",
  "geo" : { },
  "id_str" : "28483580187",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes I did that this year. Story is still good. Effects & makeup not so much. Last season & story after the first goes is still keek.",
  "id" : 28483580187,
  "in_reply_to_status_id" : 28450748100,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28532834320",
  "text" : "Xfactor a bottle of merlot, six bottles of becks and a fish supper.. Yup. Must be Saturday... Rock n fucking roll...",
  "id" : 28532834320,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28382089279",
  "geo" : { },
  "id_str" : "28382599083",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne kick em in the nuts...",
  "id" : 28382599083,
  "in_reply_to_status_id" : 28382089279,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28389850813",
  "text" : "Translink didn't deserve that award - in the same token they didn't deserve what happened when their site launched either.",
  "id" : 28389850813,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28403439984",
  "text" : "lunchover with the cousin... family politics is fucking weird..",
  "id" : 28403439984,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28415818754",
  "text" : "have a good weekend folks",
  "id" : 28415818754,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "joinedthe21stcentury",
      "indices" : [ 107, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28040494039",
  "text" : "First full day of Textmate and I *heart* it already. Moving from VM devel to Mac was a bit painful though. #joinedthe21stcentury",
  "id" : 28040494039,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28068026488",
  "text" : "Andrew Neil just slapped Limpit for being cheeky! Class. Your no longer an MP Limpit.. Behave and be humble you prick..",
  "id" : 28068026488,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbcthisweek",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28068378572",
  "text" : "Ye Godz.. Portillo is giving Darling no room on yon sofa! Andrew Neil while slimey is an excellent interviewer. #bbcthisweek",
  "id" : 28068378572,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbcthisweek",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28068555525",
  "text" : "Petson on bbcthisweek. Let's count the big words. The man writes well but he confuses me on the tee vee. #bbcthisweek",
  "id" : 28068555525,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbcthisweek",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28069140993",
  "text" : "Seriously Michael.. Shifty to he left son. Darling is an excellent politician he won't be put off by you sitting on his knee.. #bbcthisweek",
  "id" : 28069140993,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27911815451",
  "text" : "I just explained something in an email for the 100th time...",
  "id" : 27911815451,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27915342936",
  "text" : "installing capistrano onto my VM... Installing is boring.",
  "id" : 27915342936,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27961190179",
  "text" : "Ohhhhh... The Apprentice.. What a bunch of self loving idiots...",
  "id" : 27961190179,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27961587431",
  "text" : "I have to watch this programme through my fingers it is so cringie...",
  "id" : 27961587431,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27970150094",
  "geo" : { },
  "id_str" : "28002248625",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg nope.. Its a white label now. All sendit.com employees were made redundant in July 08. Sad to see it go :(",
  "id" : 28002248625,
  "in_reply_to_status_id" : 27970150094,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27814869208",
  "geo" : { },
  "id_str" : "27815024277",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin 1991 old skool.. When I was but a 12 year old... almost 30 years ago :(.... WTF",
  "id" : 27815024277,
  "in_reply_to_status_id" : 27814869208,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27815080992",
  "geo" : { },
  "id_str" : "27815358501",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin eugggh... brain hasn't engaged yet :)",
  "id" : 27815358501,
  "in_reply_to_status_id" : 27815080992,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27861615122",
  "geo" : { },
  "id_str" : "27862377597",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop geek",
  "id" : 27862377597,
  "in_reply_to_status_id" : 27861615122,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27863348641",
  "text" : "Good to see the TV Licence has frozen for six years.. While our economy goes down the shitter.. Come on Cameron. Must. Try. Harder.",
  "id" : 27863348641,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 95, 110 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27863391277",
  "text" : "But believe me. I would rather have who is in government now than those idiots before... I say @Georgina_Milne for PM!!",
  "id" : 27863391277,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27863589994",
  "geo" : { },
  "id_str" : "27864873629",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop screw that. You for pm!! You'd sort it out :)",
  "id" : 27864873629,
  "in_reply_to_status_id" : 27863589994,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27865635346",
  "geo" : { },
  "id_str" : "27866747422",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit google apps. I just moved one of my old domains to it, and its great.. Hosting on your own is too much bother I think.",
  "id" : 27866747422,
  "in_reply_to_status_id" : 27865635346,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27866897256",
  "geo" : { },
  "id_str" : "27867805018",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne excellent idea.",
  "id" : 27867805018,
  "in_reply_to_status_id" : 27866897256,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27716041993",
  "geo" : { },
  "id_str" : "27717536965",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit something else will come up :)",
  "id" : 27717536965,
  "in_reply_to_status_id" : 27716041993,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27718216331",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop - did I hear it right that Haye is gonna fight Jones Jnr when he beats Harrison? I better have got that wrong.",
  "id" : 27718216331,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27722236377",
  "text" : "rebooting my mac is always painful.. The amount of stuff I have running...",
  "id" : 27722236377,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27742400094",
  "geo" : { },
  "id_str" : "27742990889",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg :) Just FYI... It isn't a local company anymore.. They were sold to another group in 2008...",
  "id" : 27742990889,
  "in_reply_to_status_id" : 27742400094,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27743567877",
  "text" : "I am defeated by a bit of code I have just come across. Completely drained me.....",
  "id" : 27743567877,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 12, 18 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 19, 31 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27743787917",
  "geo" : { },
  "id_str" : "27745405903",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin @swmcc @rickydunlop I did not write it. If I did I would not call myself a developer... Its horrid.",
  "id" : 27745405903,
  "in_reply_to_status_id" : 27743787917,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27745519525",
  "geo" : { },
  "id_str" : "27747618045",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop Not a chance.. this stays here... :) I can't do that - wouldn't be nice :)",
  "id" : 27747618045,
  "in_reply_to_status_id" : 27745519525,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27758633130",
  "text" : "Over at the parents...",
  "id" : 27758633130,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27644270388",
  "geo" : { },
  "id_str" : "27663878809",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin same here.. got a letter in from the powers that be about it on Friday. Can't find me feckin cheque book to do it...",
  "id" : 27663878809,
  "in_reply_to_status_id" : 27644270388,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27665336429",
  "geo" : { },
  "id_str" : "27667803411",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin nooo.. continue.. its fun to read how crap your music tastes were.. I might do it sometime :)",
  "id" : 27667803411,
  "in_reply_to_status_id" : 27665336429,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27425926212",
  "geo" : { },
  "id_str" : "27426256467",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg aye - its law.. Kinda anal for them to go on about it though.. Thought it was even worth bothering with.",
  "id" : 27426256467,
  "in_reply_to_status_id" : 27425926212,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27470786558",
  "geo" : { },
  "id_str" : "27471106250",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit sleep sleep sleep",
  "id" : 27471106250,
  "in_reply_to_status_id" : 27470786558,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27472651015",
  "text" : "Euugh Halloween is coming up.... I hate that non holiday!!!",
  "id" : 27472651015,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27331362180",
  "text" : "Just had a \"fuck it\" moment there. And now setting up RSA Auth for all the VM's I now have..",
  "id" : 27331362180,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27350007493",
  "text" : "SSL + Squid as a reverse proxy = SWM head *boom*",
  "id" : 27350007493,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27350552050",
  "geo" : { },
  "id_str" : "27351644427",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit shit one :(",
  "id" : 27351644427,
  "in_reply_to_status_id" : 27350552050,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27329160732",
  "text" : "Just lost all bluetooth connectivity on my mac... Arse..",
  "id" : 27329160732,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 52, 59 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27329498614",
  "text" : "after 2 months of hard training.. I just challenged @srushe to a chess game... This is my time...",
  "id" : 27329498614,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27330793306",
  "text" : "well after 6 upgrades of software I can now scroll using my mighty mouse.. Yaaaaay...",
  "id" : 27330793306,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil McClure",
      "screen_name" : "overture8",
      "indices" : [ 0, 10 ],
      "id_str" : "19857364",
      "id" : 19857364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27239940482",
  "geo" : { },
  "id_str" : "27240543150",
  "in_reply_to_user_id" : 19857364,
  "text" : "@overture8 congrats, she looks lovely :)",
  "id" : 27240543150,
  "in_reply_to_status_id" : 27239940482,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "overture8",
  "in_reply_to_user_id_str" : "19857364",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27157662136",
  "geo" : { },
  "id_str" : "27164430688",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin That enterance.... for the general public is it? :)",
  "id" : 27164430688,
  "in_reply_to_status_id" : 27157662136,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26923476847",
  "text" : "So Labour is truly fucked.. Abbott gets a shadow minister role... Wonder how long it will take her to fall out with oul Ed....",
  "id" : 26923476847,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26749511457",
  "geo" : { },
  "id_str" : "26847928991",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit am in turkey bodrum, gumbit. It's class weather. Back to home on Tuesday Mornin though..",
  "id" : 26847928991,
  "in_reply_to_status_id" : 26749511457,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26848395847",
  "text" : "Also of note is that the English don't help themselves here.. Lucky me being Irish helps.. *hides British Passport and buys a pig*",
  "id" : 26848395847,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26741605187",
  "text" : "Suck it bitches!!!  http:\/\/yfrog.com\/evcyvcj",
  "id" : 26741605187,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26351271137",
  "text" : "Money sorted. Post Office....",
  "id" : 26351271137,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26380647186",
  "text" : "Flight delayed... To the bar....",
  "id" : 26380647186,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "spacerevolver",
      "indices" : [ 0, 14 ],
      "id_str" : "252505225",
      "id" : 252505225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26284161865",
  "geo" : { },
  "id_str" : "26289098807",
  "in_reply_to_user_id" : 49953918,
  "text" : "@spacerevolver what!!!!!!!! I missed it?!?!?!? Fucking fuck fuck",
  "id" : 26289098807,
  "in_reply_to_status_id" : 26284161865,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26294388682",
  "text" : "Case packed.., everything done thus early. Leave tomorrow at 6:45pm. What have I forgotten???",
  "id" : 26294388682,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26298642295",
  "geo" : { },
  "id_str" : "26303543014",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne I wouldn't do that. Hope your job hunting goes well :)",
  "id" : 26303543014,
  "in_reply_to_status_id" : 26298642295,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26091650797",
  "geo" : { },
  "id_str" : "26166420507",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes thanks very much. Hope you both get settled in soon too :)",
  "id" : 26166420507,
  "in_reply_to_status_id" : 26091650797,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26192550397",
  "geo" : { },
  "id_str" : "26193980717",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Bodrum :)",
  "id" : 26193980717,
  "in_reply_to_status_id" : 26192550397,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26068023693",
  "text" : "squid, rsync and postgres 9 replication... I used to be cool... Turkey on Monday with the lovely blonde one though - so fuck it I say :)",
  "id" : 26068023693,
  "created_at" : "2010-10-01 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26068241704",
  "geo" : { },
  "id_str" : "26070031931",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop I have it... I think its trying to tell you that you suck.. I agree.. You suck.",
  "id" : 26070031931,
  "in_reply_to_status_id" : 26068241704,
  "created_at" : "2010-10-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]