Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340504881699885056",
  "text" : "RT @szlwzl: Just saw this fly through and didn't catch who it was from but it is ace. If carpenters were hired like programmers http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/eA6RWjq0Cy",
        "expanded_url" : "http:\/\/bit.ly\/1aIhG5O",
        "display_url" : "bit.ly\/1aIhG5O"
      } ]
    },
    "geo" : { },
    "id_str" : "340479241730809859",
    "text" : "Just saw this fly through and didn't catch who it was from but it is ace. If carpenters were hired like programmers http:\/\/t.co\/eA6RWjq0Cy",
    "id" : 340479241730809859,
    "created_at" : "2013-05-31 14:45:51 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 340504881699885056,
  "created_at" : "2013-05-31 16:27:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/340470697111482368\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/pEX45mJFuW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLmYS45CcAAOtNY.png",
      "id_str" : "340470697119870976",
      "id" : 340470697119870976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLmYS45CcAAOtNY.png",
      "sizes" : [ {
        "h" : 422,
        "resize" : "fit",
        "w" : 826
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 826
      } ],
      "display_url" : "pic.twitter.com\/pEX45mJFuW"
    } ],
    "hashtags" : [ {
      "text" : "oddichatconvos",
      "indices" : [ 14, 29 ]
    }, {
      "text" : "thinksiambeautiful",
      "indices" : [ 30, 49 ]
    }, {
      "text" : "purejohn",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340470697111482368",
  "text" : "He said it... #oddichatconvos #thinksiambeautiful #purejohn http:\/\/t.co\/pEX45mJFuW",
  "id" : 340470697111482368,
  "created_at" : "2013-05-31 14:11:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340413144369360896",
  "text" : "A little part of my dies every time I miss the GA Auth code window between typing it in and having to enter my password\u2026.",
  "id" : 340413144369360896,
  "created_at" : "2013-05-31 10:23:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Myers",
      "screen_name" : "imderek",
      "indices" : [ 3, 11 ],
      "id_str" : "221216197",
      "id" : 221216197
    }, {
      "name" : "Register.com",
      "screen_name" : "Register_com",
      "indices" : [ 54, 67 ],
      "id_str" : "15359241",
      "id" : 15359241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340408928879906816",
  "text" : "RT @imderek: If you value your credit card do not use @Register_com. I believe they violate most PCI compliance standards. Won't remove my \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Register.com",
        "screen_name" : "Register_com",
        "indices" : [ 41, 54 ],
        "id_str" : "15359241",
        "id" : 15359241
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340406465149956097",
    "text" : "If you value your credit card do not use @Register_com. I believe they violate most PCI compliance standards. Won't remove my cc number.",
    "id" : 340406465149956097,
    "created_at" : "2013-05-31 09:56:40 +0000",
    "user" : {
      "name" : "Derek Myers",
      "screen_name" : "imderek",
      "protected" : false,
      "id_str" : "221216197",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000099230762\/326b0b8ecce3876f98c79d5606f34b40_normal.jpeg",
      "id" : 221216197,
      "verified" : false
    }
  },
  "id" : 340408928879906816,
  "created_at" : "2013-05-31 10:06:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sinatra",
      "screen_name" : "sinatra",
      "indices" : [ 15, 23 ],
      "id_str" : "19694454",
      "id" : 19694454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340407588803993600",
  "text" : "The more I use @sinatra the more I love it. &lt;3 &lt;3 &lt;3 &lt;3",
  "id" : 340407588803993600,
  "created_at" : "2013-05-31 10:01:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340364321957769216",
  "geo" : { },
  "id_str" : "340364767598354432",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp its how much? You get that train and I will kick your ass on general principle... Walk ffs.. WALK!!!!",
  "id" : 340364767598354432,
  "in_reply_to_status_id" : 340364321957769216,
  "created_at" : "2013-05-31 07:10:58 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Jaffrey",
      "screen_name" : "jaffs",
      "indices" : [ 44, 50 ],
      "id_str" : "14511835",
      "id" : 14511835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340361168378003456",
  "text" : "And twitter just got interesting again with @jaffs now tweeting :)",
  "id" : 340361168378003456,
  "created_at" : "2013-05-31 06:56:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 81, 95 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340359047301701632",
  "text" : "Weird.... Seems last night I dreamt I was on a bus to Lisburn and was talking to @madebyrichard on the phone.......",
  "id" : 340359047301701632,
  "created_at" : "2013-05-31 06:48:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Jaffrey",
      "screen_name" : "jaffs",
      "indices" : [ 0, 6 ],
      "id_str" : "14511835",
      "id" : 14511835
    }, {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 7, 19 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loverslane",
      "indices" : [ 20, 31 ]
    }, {
      "text" : "reallyoldjokes",
      "indices" : [ 32, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340207192487636992",
  "geo" : { },
  "id_str" : "340208475961425921",
  "in_reply_to_user_id" : 14511835,
  "text" : "@jaffs @StrayTaoist #loverslane #reallyoldjokes",
  "id" : 340208475961425921,
  "in_reply_to_status_id" : 340207192487636992,
  "created_at" : "2013-05-30 20:49:56 +0000",
  "in_reply_to_screen_name" : "jaffs",
  "in_reply_to_user_id_str" : "14511835",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Jaffrey",
      "screen_name" : "jaffs",
      "indices" : [ 0, 6 ],
      "id_str" : "14511835",
      "id" : 14511835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340207192487636992",
  "geo" : { },
  "id_str" : "340207778314461185",
  "in_reply_to_user_id" : 14511835,
  "text" : "@jaffs mega drive for me",
  "id" : 340207778314461185,
  "in_reply_to_status_id" : 340207192487636992,
  "created_at" : "2013-05-30 20:47:09 +0000",
  "in_reply_to_screen_name" : "jaffs",
  "in_reply_to_user_id_str" : "14511835",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/UDDhniQ8mZ",
      "expanded_url" : "http:\/\/swm.cc\/#talks",
      "display_url" : "swm.cc\/#talks"
    } ]
  },
  "in_reply_to_status_id_str" : "340206300430495745",
  "geo" : { },
  "id_str" : "340207673767231489",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I happened to be over in London last time and gave one to a wee user group while there- lightning talk\u2026 http:\/\/t.co\/UDDhniQ8mZ",
  "id" : 340207673767231489,
  "in_reply_to_status_id" : 340206300430495745,
  "created_at" : "2013-05-30 20:46:44 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    }, {
      "name" : "Andy Jaffrey",
      "screen_name" : "jaffs",
      "indices" : [ 13, 19 ],
      "id_str" : "14511835",
      "id" : 14511835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cabalcomestotwitter",
      "indices" : [ 96, 116 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340203812008636416",
  "geo" : { },
  "id_str" : "340205676158668801",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist @jaffs career progression folks. Kerr is there and Jaffs you public sector twat ;) #cabalcomestotwitter",
  "id" : 340205676158668801,
  "in_reply_to_status_id" : 340203812008636416,
  "created_at" : "2013-05-30 20:38:48 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Jaffrey",
      "screen_name" : "jaffs",
      "indices" : [ 3, 9 ],
      "id_str" : "14511835",
      "id" : 14511835
    }, {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 11, 23 ],
      "id_str" : "760043",
      "id" : 760043
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 57, 63 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340205382167310336",
  "text" : "RT @jaffs: @StrayTaoist The other place has gone hipster @swmcc is presenting on pulling Wires on a Neo Geo or something next week.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "StrayTaoist",
        "screen_name" : "StrayTaoist",
        "indices" : [ 0, 12 ],
        "id_str" : "760043",
        "id" : 760043
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 46, 52 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "340203070036267009",
    "geo" : { },
    "id_str" : "340203602322784256",
    "in_reply_to_user_id" : 760043,
    "text" : "@StrayTaoist The other place has gone hipster @swmcc is presenting on pulling Wires on a Neo Geo or something next week.",
    "id" : 340203602322784256,
    "in_reply_to_status_id" : 340203070036267009,
    "created_at" : "2013-05-30 20:30:34 +0000",
    "in_reply_to_screen_name" : "StrayTaoist",
    "in_reply_to_user_id_str" : "760043",
    "user" : {
      "name" : "Andy Jaffrey",
      "screen_name" : "jaffs",
      "protected" : false,
      "id_str" : "14511835",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1840978640\/380144_10150593042997564_916334703_n_normal.jpg",
      "id" : 14511835,
      "verified" : false
    }
  },
  "id" : 340205382167310336,
  "created_at" : "2013-05-30 20:37:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Latest@SYNCNI.com",
      "screen_name" : "syncni",
      "indices" : [ 23, 30 ],
      "id_str" : "19767792",
      "id" : 19767792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340180204154679297",
  "geo" : { },
  "id_str" : "340180715486449664",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @jasebell @syncni just depends on the company I guess.",
  "id" : 340180715486449664,
  "in_reply_to_status_id" : 340180204154679297,
  "created_at" : "2013-05-30 18:59:37 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Latest@SYNCNI.com",
      "screen_name" : "syncni",
      "indices" : [ 15, 22 ],
      "id_str" : "19767792",
      "id" : 19767792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebncongress",
      "indices" : [ 72, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340160598673326080",
  "text" : "RT @jasebell: \u201C@syncni:  gates, jobs, Wozniak are all college drop outs #ebncongress\u201D Interesting as NI, rec firms are hell bent on degrees\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Latest@SYNCNI.com",
        "screen_name" : "syncni",
        "indices" : [ 1, 8 ],
        "id_str" : "19767792",
        "id" : 19767792
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ebncongress",
        "indices" : [ 58, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340141368481574913",
    "text" : "\u201C@syncni:  gates, jobs, Wozniak are all college drop outs #ebncongress\u201D Interesting as NI, rec firms are hell bent on degrees and masters.",
    "id" : 340141368481574913,
    "created_at" : "2013-05-30 16:23:16 +0000",
    "user" : {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "protected" : false,
      "id_str" : "1248789104",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000600719719\/1f076e9f2650e4ea1930f33a7fbd28de_normal.jpeg",
      "id" : 1248789104,
      "verified" : false
    }
  },
  "id" : 340160598673326080,
  "created_at" : "2013-05-30 17:39:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yeahisaidit",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340129991897513984",
  "geo" : { },
  "id_str" : "340131803920756737",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell depends on the company. I know that Randox do it frequently. However now the wicked witch has left who knows. #yeahisaidit",
  "id" : 340131803920756737,
  "in_reply_to_status_id" : 340129991897513984,
  "created_at" : "2013-05-30 15:45:16 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340131417558224896",
  "text" : "In 18mins I'm gonna forget I am a developer for 15 hours. Just you fucking watch me! :)",
  "id" : 340131417558224896,
  "created_at" : "2013-05-30 15:43:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340131153925246977",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues well he pretty much beat the crap out of your franchise.. now its my turn.. In saying that - he couldn't do any worse than GL.",
  "id" : 340131153925246977,
  "created_at" : "2013-05-30 15:42:41 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340125212685258752",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues good luck... just want you know my thoughts on the latest JJ Abrahams classic ;)",
  "id" : 340125212685258752,
  "created_at" : "2013-05-30 15:19:04 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340120423494717440",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues When you finish your studies? I have a \"draft\" email to send ya ;)",
  "id" : 340120423494717440,
  "created_at" : "2013-05-30 15:00:02 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340120098037706752",
  "text" : "Too good an evening to be stuck in front of a computer... Will go home and do some gardening.. Probably bury myself whilst doing it mind!",
  "id" : 340120098037706752,
  "created_at" : "2013-05-30 14:58:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340085811225698305",
  "geo" : { },
  "id_str" : "340086049646727171",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 fantastic. I\u2019ve started to use vim again and with tmux it is amazing.",
  "id" : 340086049646727171,
  "in_reply_to_status_id" : 340085811225698305,
  "created_at" : "2013-05-30 12:43:27 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 1, 9 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 11, 17 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HaVoCT5\/status\/340068209266941952\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/8EEeQLVqZT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLgqPA0CYAA31mt.png",
      "id_str" : "340068209271136256",
      "id" : 340068209271136256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLgqPA0CYAA31mt.png",
      "sizes" : [ {
        "h" : 32,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 46,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 46,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 46,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 18,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8EEeQLVqZT"
    } ],
    "hashtags" : [ {
      "text" : "baddeveloper",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340082499596201985",
  "text" : "\u201C@HaVoCT5: @swmcc Found another one http:\/\/t.co\/8EEeQLVqZT\u201D Not proud of this but it is a fair cop\u2026. #baddeveloper",
  "id" : 340082499596201985,
  "created_at" : "2013-05-30 12:29:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340081093292199936",
  "geo" : { },
  "id_str" : "340082360525651968",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 :) I don't think others would see that... Embarrassed and apologetic that is in there to be honest. You using an IDE you pleb? :)",
  "id" : 340082360525651968,
  "in_reply_to_status_id" : 340081093292199936,
  "created_at" : "2013-05-30 12:28:47 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 0, 8 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340078882365521921",
  "geo" : { },
  "id_str" : "340081464093847552",
  "in_reply_to_user_id" : 120378343,
  "text" : "@kouphax impressive though :)",
  "id" : 340081464093847552,
  "in_reply_to_status_id" : 340078882365521921,
  "created_at" : "2013-05-30 12:25:14 +0000",
  "in_reply_to_screen_name" : "kouphax",
  "in_reply_to_user_id_str" : "120378343",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Steve Wozniak",
      "screen_name" : "stevewoz",
      "indices" : [ 53, 62 ],
      "id_str" : "22938914",
      "id" : 22938914
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arleneholdingthings",
      "indices" : [ 75, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/obnYxrnZ7C",
      "expanded_url" : "http:\/\/zpr.io\/PPEs",
      "display_url" : "zpr.io\/PPEs"
    } ]
  },
  "geo" : { },
  "id_str" : "340075838529748992",
  "text" : "RT @szlwzl: Breaking: Arlene holding a leaflet and a @stevewoz.\n\nThanks... #arleneholdingthings  http:\/\/t.co\/obnYxrnZ7C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/zapier.com\/\" rel=\"nofollow\"\u003EZapier.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Wozniak",
        "screen_name" : "stevewoz",
        "indices" : [ 41, 50 ],
        "id_str" : "22938914",
        "id" : 22938914
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "arleneholdingthings",
        "indices" : [ 63, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/obnYxrnZ7C",
        "expanded_url" : "http:\/\/zpr.io\/PPEs",
        "display_url" : "zpr.io\/PPEs"
      } ]
    },
    "geo" : { },
    "id_str" : "340073227680358401",
    "text" : "Breaking: Arlene holding a leaflet and a @stevewoz.\n\nThanks... #arleneholdingthings  http:\/\/t.co\/obnYxrnZ7C",
    "id" : 340073227680358401,
    "created_at" : "2013-05-30 11:52:30 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 340075838529748992,
  "created_at" : "2013-05-30 12:02:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340068209266941952",
  "geo" : { },
  "id_str" : "340074968979218433",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 really? Feck lol.. Apologies - find lots of those do ya?",
  "id" : 340074968979218433,
  "in_reply_to_status_id" : 340068209266941952,
  "created_at" : "2013-05-30 11:59:25 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/odN07EaTFe",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=n4j_oSeWZyU",
      "display_url" : "youtube.com\/watch?v=n4j_oS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340057559476084736",
  "text" : "http:\/\/t.co\/odN07EaTFe - yup yup yup.........",
  "id" : 340057559476084736,
  "created_at" : "2013-05-30 10:50:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340019484091904000",
  "text" : "Fuck you Thursday has just begun.",
  "id" : 340019484091904000,
  "created_at" : "2013-05-30 08:18:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339849300093837312",
  "geo" : { },
  "id_str" : "339849633448734721",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco that\u2019s jetlag talking :)",
  "id" : 339849633448734721,
  "in_reply_to_status_id" : 339849300093837312,
  "created_at" : "2013-05-29 21:04:01 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Shaw",
      "screen_name" : "dshaw",
      "indices" : [ 3, 9 ],
      "id_str" : "806757",
      "id" : 806757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339849531887845376",
  "text" : "RT @dshaw: Dev Happiness (cont.):\n* document all the things\n* keep docs as close to the code as possible\n* listen to people (worth repeatin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jsconf",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339848885944057857",
    "text" : "Dev Happiness (cont.):\n* document all the things\n* keep docs as close to the code as possible\n* listen to people (worth repeating)\n\n#jsconf",
    "id" : 339848885944057857,
    "created_at" : "2013-05-29 21:01:03 +0000",
    "user" : {
      "name" : "Daniel Shaw",
      "screen_name" : "dshaw",
      "protected" : false,
      "id_str" : "806757",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1552591406\/angry_unicorn_normal.png",
      "id" : 806757,
      "verified" : false
    }
  },
  "id" : 339849531887845376,
  "created_at" : "2013-05-29 21:03:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339817850141294593",
  "geo" : { },
  "id_str" : "339827182014722049",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco almost home JR\u2026 keep it between the hedges.",
  "id" : 339827182014722049,
  "in_reply_to_status_id" : 339817850141294593,
  "created_at" : "2013-05-29 19:34:48 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Keizer",
      "screen_name" : "KeizGoesBoom",
      "indices" : [ 0, 13 ],
      "id_str" : "81934123",
      "id" : 81934123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339813391457738752",
  "geo" : { },
  "id_str" : "339813750326575105",
  "in_reply_to_user_id" : 81934123,
  "text" : "@KeizGoesBoom you need to look at your error log and see what\u2019s happening. Feel free to mail me more info at me@swm.cc if you need help",
  "id" : 339813750326575105,
  "in_reply_to_status_id" : 339813391457738752,
  "created_at" : "2013-05-29 18:41:26 +0000",
  "in_reply_to_screen_name" : "KeizGoesBoom",
  "in_reply_to_user_id_str" : "81934123",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339793323546013696",
  "geo" : { },
  "id_str" : "339813276072423424",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es grrrrrr yeah.",
  "id" : 339813276072423424,
  "in_reply_to_status_id" : 339793323546013696,
  "created_at" : "2013-05-29 18:39:33 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 47, 60 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339791263027064833",
  "text" : "Heading home now after a hard day working with @chris_van_es on some stuffs. Head hurts. Time to zone out!",
  "id" : 339791263027064833,
  "created_at" : "2013-05-29 17:12:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339770494846910465",
  "text" : "I\u2019ve spent too long using curl today\u2026 My head is friend.",
  "id" : 339770494846910465,
  "created_at" : "2013-05-29 15:49:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 47, 55 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339752520727535616",
  "geo" : { },
  "id_str" : "339753284011184128",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard fuck sake you are just as bad as @jbrevel - It is a NO at all times\u2026 A NO!!!!!!!",
  "id" : 339753284011184128,
  "in_reply_to_status_id" : 339752520727535616,
  "created_at" : "2013-05-29 14:41:09 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339750537920671745",
  "geo" : { },
  "id_str" : "339751260196585474",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @niall_adams what did he say Rick - I can't see his feed :)",
  "id" : 339751260196585474,
  "in_reply_to_status_id" : 339750537920671745,
  "created_at" : "2013-05-29 14:33:07 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339749651496452096",
  "text" : "Uploading a logfile is killing my bandwidth... Grrrrrrrrr not helping me today...........",
  "id" : 339749651496452096,
  "created_at" : "2013-05-29 14:26:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 82, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339714124638453760",
  "text" : "One shouldn\u2019t be fucked off on a day like this. But one is\u2026 Yes one very much is. #FUCKYOUWEDNESDAY and Thursday aint looking like good!",
  "id" : 339714124638453760,
  "created_at" : "2013-05-29 12:05:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCKYOUWEDNESDAY",
      "indices" : [ 73, 90 ]
    }, {
      "text" : "possibly",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339658366387367936",
  "text" : "I\u2019ve a feeling today is gonna fuck me in someway. And not in a good way. #FUCKYOUWEDNESDAY #possibly",
  "id" : 339658366387367936,
  "created_at" : "2013-05-29 08:23:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdgasm",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/yRpWrepEI3",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=l_T3XEgXl14",
      "display_url" : "youtube.com\/watch?v=l_T3XE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339657347561558016",
  "text" : "&lt;3 &lt;3 &lt;3 http:\/\/t.co\/yRpWrepEI3 &lt;3 &lt;3 &lt;3 #nerdgasm",
  "id" : 339657347561558016,
  "created_at" : "2013-05-29 08:19:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339477425593384960",
  "text" : "Thank fuck there\u2019s n more birthdays in my immediate family until October. :)",
  "id" : 339477425593384960,
  "created_at" : "2013-05-28 20:25:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/WzlZ94LF6z",
      "expanded_url" : "https:\/\/github.com\/blog\/1513-introducing-github-sudo-mode",
      "display_url" : "github.com\/blog\/1513-intr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339414490535821313",
  "text" : "I want to marry this company - https:\/\/t.co\/WzlZ94LF6z",
  "id" : 339414490535821313,
  "created_at" : "2013-05-28 16:14:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/iDhgPWM5CG",
      "expanded_url" : "https:\/\/github.com\/swmcc\/dotfiles\/blob\/master\/tmux\/create_tmux_skeleton",
      "display_url" : "github.com\/swmcc\/dotfiles\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "339401020968939520",
  "geo" : { },
  "id_str" : "339404687692423168",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es https:\/\/t.co\/iDhgPWM5CG - cheers - this should help me out\u2026",
  "id" : 339404687692423168,
  "in_reply_to_status_id" : 339401020968939520,
  "created_at" : "2013-05-28 15:35:58 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339402216437854210",
  "geo" : { },
  "id_str" : "339403054233317376",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel also - all backs look the same ;)",
  "id" : 339403054233317376,
  "in_reply_to_status_id" : 339402216437854210,
  "created_at" : "2013-05-28 15:29:28 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339402216437854210",
  "geo" : { },
  "id_str" : "339403005071880192",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel you love me!",
  "id" : 339403005071880192,
  "in_reply_to_status_id" : 339402216437854210,
  "created_at" : "2013-05-28 15:29:16 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Buchanan",
      "screen_name" : "jbscript",
      "indices" : [ 0, 9 ],
      "id_str" : "770264707",
      "id" : 770264707
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 10, 17 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 18, 25 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339399658889682944",
  "geo" : { },
  "id_str" : "339400790340947968",
  "in_reply_to_user_id" : 770264707,
  "text" : "@jbscript @github @holman fantastic :) thanks :)",
  "id" : 339400790340947968,
  "in_reply_to_status_id" : 339399658889682944,
  "created_at" : "2013-05-28 15:20:28 +0000",
  "in_reply_to_screen_name" : "jbscript",
  "in_reply_to_user_id_str" : "770264707",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notpretty",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339399558058627072",
  "text" : "I really regret not getting the anti glare screen on my laptop. Keep getting reminded of what I look like in the summer. #notpretty",
  "id" : 339399558058627072,
  "created_at" : "2013-05-28 15:15:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 95, 102 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 103, 110 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "possiblestupidquestion",
      "indices" : [ 63, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339399331427807232",
  "text" : "Is there a handy way to download a gist from the command line? #possiblestupidquestion anyone? @github @holman :)",
  "id" : 339399331427807232,
  "created_at" : "2013-05-28 15:14:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc DeTellis",
      "screen_name" : "lucdetellis",
      "indices" : [ 3, 15 ],
      "id_str" : "618106201",
      "id" : 618106201
    }, {
      "name" : "node js",
      "screen_name" : "nodejs",
      "indices" : [ 119, 126 ],
      "id_str" : "91985735",
      "id" : 91985735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339392925718941697",
  "text" : "RT @lucdetellis: How many Node.js programmers does it take to change a light bulb? None, that's a client side problem. @nodejs #nodejs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "node js",
        "screen_name" : "nodejs",
        "indices" : [ 102, 109 ],
        "id_str" : "91985735",
        "id" : 91985735
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodejs",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339390556612460544",
    "text" : "How many Node.js programmers does it take to change a light bulb? None, that's a client side problem. @nodejs #nodejs",
    "id" : 339390556612460544,
    "created_at" : "2013-05-28 14:39:48 +0000",
    "user" : {
      "name" : "Luc DeTellis",
      "screen_name" : "lucdetellis",
      "protected" : false,
      "id_str" : "618106201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000298489883\/18c8ce57f1c433a0811eeb7cc808c8d0_normal.jpeg",
      "id" : 618106201,
      "verified" : false
    }
  },
  "id" : 339392925718941697,
  "created_at" : "2013-05-28 14:49:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339385055350759424",
  "geo" : { },
  "id_str" : "339389405049520128",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 you wanna say something Murphy? Just come out and say it ;)",
  "id" : 339389405049520128,
  "in_reply_to_status_id" : 339385055350759424,
  "created_at" : "2013-05-28 14:35:14 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bash!",
      "screen_name" : "devbash",
      "indices" : [ 89, 97 ],
      "id_str" : "454193975",
      "id" : 454193975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339381033717870593",
  "text" : "Brothers birthday dinner tonight.. Actual birthday was yesterday. As a result can\u2019t make @devbash tonight - gutted.. Ahh well..",
  "id" : 339381033717870593,
  "created_at" : "2013-05-28 14:01:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bash!",
      "screen_name" : "devbash",
      "indices" : [ 0, 8 ],
      "id_str" : "454193975",
      "id" : 454193975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339379452503015425",
  "geo" : { },
  "id_str" : "339380771984924673",
  "in_reply_to_user_id" : 454193975,
  "text" : "@devbash crap - I can\u2019t make it tonight - brothers birthday moved - apologies :(",
  "id" : 339380771984924673,
  "in_reply_to_status_id" : 339379452503015425,
  "created_at" : "2013-05-28 14:00:56 +0000",
  "in_reply_to_screen_name" : "devbash",
  "in_reply_to_user_id_str" : "454193975",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339378926356934656",
  "text" : "Moving the whiteboard to right beside me wasn\u2019t one of the better ideas this place has ever had..",
  "id" : 339378926356934656,
  "created_at" : "2013-05-28 13:53:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Official Charts",
      "screen_name" : "officialcharts",
      "indices" : [ 3, 18 ],
      "id_str" : "18937505",
      "id" : 18937505
    }, {
      "name" : "graham norton",
      "screen_name" : "grahnort",
      "indices" : [ 119, 128 ],
      "id_str" : "49585215",
      "id" : 49585215
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreshPrinceOfBelAir",
      "indices" : [ 31, 51 ]
    }, {
      "text" : "OfficialChart",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339349833586458624",
  "text" : "RT @officialcharts: The former #FreshPrinceOfBelAir is climbing up the #OfficialChart following his performance on The @grahnort Show: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "graham norton",
        "screen_name" : "grahnort",
        "indices" : [ 99, 108 ],
        "id_str" : "49585215",
        "id" : 49585215
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreshPrinceOfBelAir",
        "indices" : [ 11, 31 ]
      }, {
        "text" : "OfficialChart",
        "indices" : [ 51, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/wLBNcssUpz",
        "expanded_url" : "http:\/\/goo.gl\/Oglim",
        "display_url" : "goo.gl\/Oglim"
      } ]
    },
    "geo" : { },
    "id_str" : "339344090686713857",
    "text" : "The former #FreshPrinceOfBelAir is climbing up the #OfficialChart following his performance on The @grahnort Show: http:\/\/t.co\/wLBNcssUpz",
    "id" : 339344090686713857,
    "created_at" : "2013-05-28 11:35:10 +0000",
    "user" : {
      "name" : "Official Charts",
      "screen_name" : "officialcharts",
      "protected" : false,
      "id_str" : "18937505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1583060590\/OCC_Twitter_Icon_normal.jpg",
      "id" : 18937505,
      "verified" : true
    }
  },
  "id" : 339349833586458624,
  "created_at" : "2013-05-28 11:57:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nat Torkington",
      "screen_name" : "gnat",
      "indices" : [ 10, 15 ],
      "id_str" : "898691",
      "id" : 898691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339335133398192128",
  "geo" : { },
  "id_str" : "339336641741201409",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell @gnat great stuff :D Congrats.",
  "id" : 339336641741201409,
  "in_reply_to_status_id" : 339335133398192128,
  "created_at" : "2013-05-28 11:05:34 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339316055673552896",
  "geo" : { },
  "id_str" : "339319966308376576",
  "in_reply_to_user_id" : 26985337,
  "text" : "@PGregg congratulations :)",
  "id" : 339319966308376576,
  "in_reply_to_status_id" : 339316055673552896,
  "created_at" : "2013-05-28 09:59:18 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 3, 15 ],
      "id_str" : "454835425",
      "id" : 454835425
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 90, 96 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "digitalcircle",
      "screen_name" : "digitalcircle",
      "indices" : [ 124, 138 ],
      "id_str" : "15902682",
      "id" : 15902682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/IlYHiyoHQY",
      "expanded_url" : "http:\/\/digitalcircle.org\/events\/belfast-ruby-a-brief-intro-to-neo4j",
      "display_url" : "digitalcircle.org\/events\/belfast\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339312392871743488",
  "text" : "RT @BelfastRuby: Go register for Belfast Ruby Meetup - 4 June - A brief intro to Neo4j by @swmcc http:\/\/t.co\/IlYHiyoHQY via @digitalcircle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 73, 79 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "digitalcircle",
        "screen_name" : "digitalcircle",
        "indices" : [ 107, 121 ],
        "id_str" : "15902682",
        "id" : 15902682
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/IlYHiyoHQY",
        "expanded_url" : "http:\/\/digitalcircle.org\/events\/belfast-ruby-a-brief-intro-to-neo4j",
        "display_url" : "digitalcircle.org\/events\/belfast\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "339312193793310720",
    "text" : "Go register for Belfast Ruby Meetup - 4 June - A brief intro to Neo4j by @swmcc http:\/\/t.co\/IlYHiyoHQY via @digitalcircle",
    "id" : 339312193793310720,
    "created_at" : "2013-05-28 09:28:25 +0000",
    "user" : {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "protected" : false,
      "id_str" : "454835425",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1752070239\/belfastruby-twitter-icon-2_normal.png",
      "id" : 454835425,
      "verified" : false
    }
  },
  "id" : 339312392871743488,
  "created_at" : "2013-05-28 09:29:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339300233626398723",
  "text" : "Earphones [in]... Hipchat [off].. Email [off]... Now to knock the crap out of this day :)",
  "id" : 339300233626398723,
  "created_at" : "2013-05-28 08:40:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 0, 6 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arresteddevelopment",
      "indices" : [ 83, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339181878689021953",
  "geo" : { },
  "id_str" : "339271222409957376",
  "in_reply_to_user_id" : 3840,
  "text" : "@Jason watch one in the morning before getting out of bed in the iPad. Sets me up. #arresteddevelopment",
  "id" : 339271222409957376,
  "in_reply_to_status_id" : 339181878689021953,
  "created_at" : "2013-05-28 06:45:37 +0000",
  "in_reply_to_screen_name" : "Jason",
  "in_reply_to_user_id_str" : "3840",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/EcrNH5ggFI",
      "expanded_url" : "http:\/\/wp.me\/p3bKqw-a8",
      "display_url" : "wp.me\/p3bKqw-a8"
    } ]
  },
  "geo" : { },
  "id_str" : "339092691944095744",
  "text" : "RT @jasebell: Raspberry Pi Twitter Sentiment Server - Github Repo http:\/\/t.co\/EcrNH5ggFI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/EcrNH5ggFI",
        "expanded_url" : "http:\/\/wp.me\/p3bKqw-a8",
        "display_url" : "wp.me\/p3bKqw-a8"
      } ]
    },
    "geo" : { },
    "id_str" : "339086197743820800",
    "text" : "Raspberry Pi Twitter Sentiment Server - Github Repo http:\/\/t.co\/EcrNH5ggFI",
    "id" : 339086197743820800,
    "created_at" : "2013-05-27 18:30:24 +0000",
    "user" : {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "protected" : false,
      "id_str" : "1248789104",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000600719719\/1f076e9f2650e4ea1930f33a7fbd28de_normal.jpeg",
      "id" : 1248789104,
      "verified" : false
    }
  },
  "id" : 339092691944095744,
  "created_at" : "2013-05-27 18:56:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/nzxHOKSdPT",
      "expanded_url" : "http:\/\/www.inc.com\/magazine\/201306\/jason-fried\/letting-go-is-hard-but-best.html",
      "display_url" : "inc.com\/magazine\/20130\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339061290058276864",
  "text" : "Brilliant advice. http:\/\/t.co\/nzxHOKSdPT",
  "id" : 339061290058276864,
  "created_at" : "2013-05-27 16:51:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339020838756032513",
  "text" : "Binding my tmux session to CTRL+a was probably the dumbest thing I've done in a long time. It is driving me mad but cba changing it.",
  "id" : 339020838756032513,
  "created_at" : "2013-05-27 14:10:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neo4j",
      "screen_name" : "neo4j",
      "indices" : [ 7, 13 ],
      "id_str" : "22467617",
      "id" : 22467617
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 22, 34 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "havetoisagoodmaster",
      "indices" : [ 52, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339010894971416576",
  "text" : "So\u2026 my @neo4j talk to @BelfastRuby is next Tuesday\u2026 #havetoisagoodmaster",
  "id" : 339010894971416576,
  "created_at" : "2013-05-27 13:31:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallwins",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338988544653672448",
  "text" : "Game of Thrones isn\u2019t on tonight. This Monday now officially sucks donkey dick\u2026 I am gonna have toasted soda for lunch though. #smallwins",
  "id" : 338988544653672448,
  "created_at" : "2013-05-27 12:02:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "parttimebastard",
      "indices" : [ 51, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338933952779792384",
  "geo" : { },
  "id_str" : "338934326232236032",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I'm heading in after I get some breakfast. #parttimebastard :)",
  "id" : 338934326232236032,
  "in_reply_to_status_id" : 338933952779792384,
  "created_at" : "2013-05-27 08:26:55 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arleneholdingthings",
      "indices" : [ 73, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/nhlfRtsfgR",
      "expanded_url" : "http:\/\/zpr.io\/PUux",
      "display_url" : "zpr.io\/PUux"
    } ]
  },
  "geo" : { },
  "id_str" : "338591836069310465",
  "text" : "RT @szlwzl: Arlene in a hairnet holding some bread\n\n(by special request) #arleneholdingthings  http:\/\/t.co\/nhlfRtsfgR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/zapier.com\/\" rel=\"nofollow\"\u003EZapier.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "arleneholdingthings",
        "indices" : [ 61, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/nhlfRtsfgR",
        "expanded_url" : "http:\/\/zpr.io\/PUux",
        "display_url" : "zpr.io\/PUux"
      } ]
    },
    "geo" : { },
    "id_str" : "338583027510820866",
    "text" : "Arlene in a hairnet holding some bread\n\n(by special request) #arleneholdingthings  http:\/\/t.co\/nhlfRtsfgR",
    "id" : 338583027510820866,
    "created_at" : "2013-05-26 09:10:58 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 338591836069310465,
  "created_at" : "2013-05-26 09:45:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 11, 18 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 19, 30 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bossesworkethic",
      "indices" : [ 61, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338580970510893057",
  "text" : "Looking at @rejoco @foursquare checkins just makes me tired. #bossesworkethic",
  "id" : 338580970510893057,
  "created_at" : "2013-05-26 09:02:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/2rKD7Z2FUz",
      "expanded_url" : "http:\/\/on.wsj.com\/16f39Sp",
      "display_url" : "on.wsj.com\/16f39Sp"
    } ]
  },
  "geo" : { },
  "id_str" : "338578807420239872",
  "text" : "RT @WSJ: \"The onus of personal and professional development is on the individual, not on the company.\" http:\/\/t.co\/2rKD7Z2FUz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/2rKD7Z2FUz",
        "expanded_url" : "http:\/\/on.wsj.com\/16f39Sp",
        "display_url" : "on.wsj.com\/16f39Sp"
      } ]
    },
    "geo" : { },
    "id_str" : "338556986310406145",
    "text" : "\"The onus of personal and professional development is on the individual, not on the company.\" http:\/\/t.co\/2rKD7Z2FUz",
    "id" : 338556986310406145,
    "created_at" : "2013-05-26 07:27:30 +0000",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1702671908\/WSJ-twitter-logo_normal",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 338578807420239872,
  "created_at" : "2013-05-26 08:54:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "_MarkByrne",
      "indices" : [ 0, 11 ],
      "id_str" : "300112124",
      "id" : 300112124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338314450639654912",
  "geo" : { },
  "id_str" : "338387034429333504",
  "in_reply_to_user_id" : 300112124,
  "text" : "@_MarkByrne its a great show. I love it.",
  "id" : 338387034429333504,
  "in_reply_to_status_id" : 338314450639654912,
  "created_at" : "2013-05-25 20:12:10 +0000",
  "in_reply_to_screen_name" : "_MarkByrne",
  "in_reply_to_user_id_str" : "300112124",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338330659401650178",
  "text" : "Only bad part was the lawnmower refused to start for 10mins... In that 10mins I uttered the word \"fuck\" approximately 600times. 1fps",
  "id" : 338330659401650178,
  "created_at" : "2013-05-25 16:28:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338329900232605696",
  "text" : "Lovely day spent in the garden - nice to get away from the computer for a day...",
  "id" : 338329900232605696,
  "created_at" : "2013-05-25 16:25:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338269126516670464",
  "geo" : { },
  "id_str" : "338271338504548352",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell More than likely horribly broken with the current version of node. Doesn't save to a db or anything.. Inspiring me to do it though",
  "id" : 338271338504548352,
  "in_reply_to_status_id" : 338269126516670464,
  "created_at" : "2013-05-25 12:32:26 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ABdYJCHitm",
      "expanded_url" : "https:\/\/github.com\/swmcc\/twitter-sentiment",
      "display_url" : "github.com\/swmcc\/twitter-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "338269126516670464",
  "geo" : { },
  "id_str" : "338271110246309888",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell I need an excuse to buy one though that isn't tv related ;) I tried a while back to do something in node - https:\/\/t.co\/ABdYJCHitm",
  "id" : 338271110246309888,
  "in_reply_to_status_id" : 338269126516670464,
  "created_at" : "2013-05-25 12:31:32 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338227151587389440",
  "geo" : { },
  "id_str" : "338261707178799105",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell loving this new sentiment stuff btw - keep it up :) Making me wanna by a Raspberry Pi",
  "id" : 338261707178799105,
  "in_reply_to_status_id" : 338227151587389440,
  "created_at" : "2013-05-25 11:54:10 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/eNbOOoP3v4",
      "expanded_url" : "https:\/\/www.youtube.com\/embed\/ZwS14TiO7Pk",
      "display_url" : "youtube.com\/embed\/ZwS14TiO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338215730896056320",
  "text" : "Was brilliant last night \u2026 And it gets better and better -https:\/\/t.co\/eNbOOoP3v4",
  "id" : 338215730896056320,
  "created_at" : "2013-05-25 08:51:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338192120768757760",
  "text" : "RT @szlwzl: Replacing Britain's got talent with a game of football is like replacing genital warts with anal fissures.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/getfalcon.pro\" rel=\"nofollow\"\u003EFalcon-Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338185978642579456",
    "text" : "Replacing Britain's got talent with a game of football is like replacing genital warts with anal fissures.",
    "id" : 338185978642579456,
    "created_at" : "2013-05-25 06:53:15 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 338192120768757760,
  "created_at" : "2013-05-25 07:17:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pn5MezoK6n",
      "expanded_url" : "http:\/\/www.farnamstreetblog.com\/2013\/05\/the-buffett-formula-how-to-get-smarter",
      "display_url" : "farnamstreetblog.com\/2013\/05\/the-bu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338185580963831808",
  "text" : "http:\/\/t.co\/pn5MezoK6n - \u201CGo to bed smarter than when you woke up\u201D Charlie Mugner",
  "id" : 338185580963831808,
  "created_at" : "2013-05-25 06:51:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/syaloR2gCw",
      "expanded_url" : "http:\/\/pandodaily.com\/2013\/04\/06\/the-tax-of-new\/",
      "display_url" : "pandodaily.com\/2013\/04\/06\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338184493955440640",
  "text" : "Interesting  http:\/\/t.co\/syaloR2gCw",
  "id" : 338184493955440640,
  "created_at" : "2013-05-25 06:47:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy ~\u2665~",
      "screen_name" : "amypeppercorn",
      "indices" : [ 3, 17 ],
      "id_str" : "254617897",
      "id" : 254617897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338054166683455489",
  "text" : "RT @amypeppercorn: GRAHAM NORTON IS FUCKING SICK AS FUCK TONIGHT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338053556361912320",
    "text" : "GRAHAM NORTON IS FUCKING SICK AS FUCK TONIGHT",
    "id" : 338053556361912320,
    "created_at" : "2013-05-24 22:07:03 +0000",
    "user" : {
      "name" : "Amy ~\u2665~",
      "screen_name" : "amypeppercorn",
      "protected" : true,
      "id_str" : "254617897",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000430208470\/18d2787624590468e75b48849e63b559_normal.jpeg",
      "id" : 254617897,
      "verified" : false
    }
  },
  "id" : 338054166683455489,
  "created_at" : "2013-05-24 22:09:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338042782272851968",
  "geo" : { },
  "id_str" : "338043267071479808",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall shaddaaaaap - also - cinema trip - pick a non girly film please :D",
  "id" : 338043267071479808,
  "in_reply_to_status_id" : 338042782272851968,
  "created_at" : "2013-05-24 21:26:10 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338041786075340800",
  "text" : "Just gave Google authorship a go on me oil blog there Probably wont do much but can\u2019t hurt. I know how to rock it on a Friday night bitches!",
  "id" : 338041786075340800,
  "created_at" : "2013-05-24 21:20:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337931879820955648",
  "text" : "RT @climagic: If running a command twice destroys all your data, try it a third time to really screw shit up.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/suso.suso.org\/xulu\/Command_Line_Magic\" rel=\"nofollow\"\u003ECLI Magic poster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337927887556583424",
    "text" : "If running a command twice destroys all your data, try it a third time to really screw shit up.",
    "id" : 337927887556583424,
    "created_at" : "2013-05-24 13:47:41 +0000",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535876218\/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 337931879820955648,
  "created_at" : "2013-05-24 14:03:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 3, 16 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337911199607955457",
  "text" : "RT @stevebiscuit: @swmcc &lt;3 you too big lawd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "337907130025799681",
    "geo" : { },
    "id_str" : "337910984524066817",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc &lt;3 you too big lawd",
    "id" : 337910984524066817,
    "in_reply_to_status_id" : 337907130025799681,
    "created_at" : "2013-05-24 12:40:31 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "protected" : false,
      "id_str" : "14068466",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1929736578\/steve_normal.png",
      "id" : 14068466,
      "verified" : false
    }
  },
  "id" : 337911199607955457,
  "created_at" : "2013-05-24 12:41:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337885995468992513",
  "geo" : { },
  "id_str" : "337907179711524864",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard get it done son :)",
  "id" : 337907179711524864,
  "in_reply_to_status_id" : 337885995468992513,
  "created_at" : "2013-05-24 12:25:24 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337890720692183041",
  "geo" : { },
  "id_str" : "337907130025799681",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit apart from you ;) I &lt;3 you.",
  "id" : 337907130025799681,
  "in_reply_to_status_id" : 337890720692183041,
  "created_at" : "2013-05-24 12:25:12 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 20, 30 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "miraclesdohappen",
      "indices" : [ 83, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337906153814114304",
  "text" : "RT @jbrevel: @swmcc @smccalden Amazingly he stayed professional the whole time :-) #miraclesdohappen",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Stephen McCalden",
        "screen_name" : "smccalden",
        "indices" : [ 7, 17 ],
        "id_str" : "169048119",
        "id" : 169048119
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "miraclesdohappen",
        "indices" : [ 70, 87 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "337904441992814592",
    "geo" : { },
    "id_str" : "337904948476006403",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @smccalden Amazingly he stayed professional the whole time :-) #miraclesdohappen",
    "id" : 337904948476006403,
    "in_reply_to_status_id" : 337904441992814592,
    "created_at" : "2013-05-24 12:16:32 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 337906153814114304,
  "created_at" : "2013-05-24 12:21:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337890911516250112",
  "geo" : { },
  "id_str" : "337904441992814592",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden Nope was all above board. :)",
  "id" : 337904441992814592,
  "in_reply_to_status_id" : 337890911516250112,
  "created_at" : "2013-05-24 12:14:31 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337885180549271554",
  "geo" : { },
  "id_str" : "337885757853294593",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard I don't mind them when they are informative and I don't have work coming out of my ass... Where is your crossfit blog btw? ;)",
  "id" : 337885757853294593,
  "in_reply_to_status_id" : 337885180549271554,
  "created_at" : "2013-05-24 11:00:16 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337884475201576960",
  "text" : "Had a meeting with two other people this morn for 1.5hrs. Said about 9 words the whole time. New record for me. I hate meetings and talking.",
  "id" : 337884475201576960,
  "created_at" : "2013-05-24 10:55:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 3, 10 ],
      "id_str" : "17843859",
      "id" : 17843859
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "node",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/U4gowuqPu9",
      "expanded_url" : "http:\/\/robtweed.wordpress.com\/2013\/05\/24\/making-mumps-acceptable-to-the-mainstream\/",
      "display_url" : "robtweed.wordpress.com\/2013\/05\/24\/mak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337879021205454848",
  "text" : "RT @rtweed: Node.js and JavaScript: their importance and relevance in advancing and modernising Healthcare IT: http:\/\/t.co\/U4gowuqPu9 #node\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodejs",
        "indices" : [ 122, 129 ]
      }, {
        "text" : "HealthIT",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/U4gowuqPu9",
        "expanded_url" : "http:\/\/robtweed.wordpress.com\/2013\/05\/24\/making-mumps-acceptable-to-the-mainstream\/",
        "display_url" : "robtweed.wordpress.com\/2013\/05\/24\/mak\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "337864607974707200",
    "text" : "Node.js and JavaScript: their importance and relevance in advancing and modernising Healthcare IT: http:\/\/t.co\/U4gowuqPu9 #nodejs #HealthIT",
    "id" : 337864607974707200,
    "created_at" : "2013-05-24 09:36:14 +0000",
    "user" : {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "protected" : false,
      "id_str" : "17843859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1398354510\/me_normal.png",
      "id" : 17843859,
      "verified" : false
    }
  },
  "id" : 337879021205454848,
  "created_at" : "2013-05-24 10:33:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337690143244840961",
  "geo" : { },
  "id_str" : "337690603246718977",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl jnr is on about same sex marriage\u2026 Had to turn off - cant listen to that vile man",
  "id" : 337690603246718977,
  "in_reply_to_status_id" : 337690143244840961,
  "created_at" : "2013-05-23 22:04:48 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337690328901492736",
  "text" : "Ian Paisley jnr.. Question time.. Same sex marriage.. Time to turn off the tv. What a fucking backward knob\u2026",
  "id" : 337690328901492736,
  "created_at" : "2013-05-23 22:03:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 14, 21 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337687744518160384",
  "text" : "Looking for a @szlwzl on question time",
  "id" : 337687744518160384,
  "created_at" : "2013-05-23 21:53:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 15, 22 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337655417360486400",
  "geo" : { },
  "id_str" : "337657299441180672",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @szlwzl  rumour round the campfire it is.",
  "id" : 337657299441180672,
  "in_reply_to_status_id" : 337655417360486400,
  "created_at" : "2013-05-23 19:52:28 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 20, 27 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337646985257566208",
  "text" : "Deploying stuff and @szlwzl is on question time\u2026 awesome. The handsome Englishman is gonna ask some twatish questions tonight :)",
  "id" : 337646985257566208,
  "created_at" : "2013-05-23 19:11:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikolas Demiridis",
      "screen_name" : "nikolasd",
      "indices" : [ 3, 12 ],
      "id_str" : "14689462",
      "id" : 14689462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ubuntu",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "howto",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "neo4j",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/R6VAVyVSvm",
      "expanded_url" : "http:\/\/dlvr.it\/3Q46ct",
      "display_url" : "dlvr.it\/3Q46ct"
    } ]
  },
  "geo" : { },
  "id_str" : "337645890422587392",
  "text" : "RT @nikolasd: neo4j install on ubunutu (lazy admin way) http:\/\/t.co\/R6VAVyVSvm #ubuntu #howto #neo4j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/identi.ca\" rel=\"nofollow\"\u003Eidentica\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ubuntu",
        "indices" : [ 65, 72 ]
      }, {
        "text" : "howto",
        "indices" : [ 73, 79 ]
      }, {
        "text" : "neo4j",
        "indices" : [ 80, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/R6VAVyVSvm",
        "expanded_url" : "http:\/\/dlvr.it\/3Q46ct",
        "display_url" : "dlvr.it\/3Q46ct"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 39.36667, 22.94583 ]
    },
    "id_str" : "337589947647275008",
    "text" : "neo4j install on ubunutu (lazy admin way) http:\/\/t.co\/R6VAVyVSvm #ubuntu #howto #neo4j",
    "id" : 337589947647275008,
    "created_at" : "2013-05-23 15:24:50 +0000",
    "user" : {
      "name" : "Nikolas Demiridis",
      "screen_name" : "nikolasd",
      "protected" : false,
      "id_str" : "14689462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/307166650\/avatar_normal.png",
      "id" : 14689462,
      "verified" : false
    }
  },
  "id" : 337645890422587392,
  "created_at" : "2013-05-23 19:07:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 1, 11 ],
      "id_str" : "240194412",
      "id" : 240194412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/VyjTs3M2Tw",
      "expanded_url" : "http:\/\/www.itnews.com.au\/News\/344319,police-tap-social-media-in-wake-of-london-attack.aspx",
      "display_url" : "itnews.com.au\/News\/344319,po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337594587361193985",
  "text" : "\u201C@RepKnight: Always great to see a happy customer, and them spreading the news across the world http:\/\/t.co\/VyjTs3M2Tw\u201D Proud as punch :)",
  "id" : 337594587361193985,
  "created_at" : "2013-05-23 15:43:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337594349321846784",
  "text" : "RT @jasonfried: \"REMOTE: Office Not Required\", our new book on making remote working work, is now available for pre-order: http:\/\/t.co\/sSaO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/sSaO6jXiYs",
        "expanded_url" : "http:\/\/www.amazon.com\/Remote-Office-Required-Jason-Fried\/dp\/0804137501",
        "display_url" : "amazon.com\/Remote-Office-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "337576577225342976",
    "text" : "\"REMOTE: Office Not Required\", our new book on making remote working work, is now available for pre-order: http:\/\/t.co\/sSaO6jXiYs",
    "id" : 337576577225342976,
    "created_at" : "2013-05-23 14:31:42 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 337594349321846784,
  "created_at" : "2013-05-23 15:42:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "indices" : [ 3, 13 ],
      "id_str" : "3452911",
      "id" : 3452911
    }, {
      "name" : "B. Bonin Bough",
      "screen_name" : "boughb",
      "indices" : [ 119, 126 ],
      "id_str" : "457313",
      "id" : 457313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Twitter4",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337594314681090048",
  "text" : "RT @kevinweil: \"When we combine Twitter with our advertising on TV, we see twice the effectiveness. This stuff works.\" @boughb at #Twitter4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "B. Bonin Bough",
        "screen_name" : "boughb",
        "indices" : [ 104, 111 ],
        "id_str" : "457313",
        "id" : 457313
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Twitter4Brands",
        "indices" : [ 115, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337572987681255426",
    "text" : "\"When we combine Twitter with our advertising on TV, we see twice the effectiveness. This stuff works.\" @boughb at #Twitter4Brands",
    "id" : 337572987681255426,
    "created_at" : "2013-05-23 14:17:26 +0000",
    "user" : {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "protected" : false,
      "id_str" : "3452911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/220257539\/n206489_34325699_8572_normal.jpg",
      "id" : 3452911,
      "verified" : false
    }
  },
  "id" : 337594314681090048,
  "created_at" : "2013-05-23 15:42:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "regretsihaveafew",
      "indices" : [ 108, 125 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337323202583855106",
  "geo" : { },
  "id_str" : "337323766252195840",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard yeah. Was just wondering. Will have this mac for another few years anyway so it\u2019s moot point. #regretsihaveafew",
  "id" : 337323766252195840,
  "in_reply_to_status_id" : 337323202583855106,
  "created_at" : "2013-05-22 21:47:07 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337308162057195520",
  "geo" : { },
  "id_str" : "337323029010972675",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard does it run VMware ok then?",
  "id" : 337323029010972675,
  "in_reply_to_status_id" : 337308162057195520,
  "created_at" : "2013-05-22 21:44:11 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337308162057195520",
  "geo" : { },
  "id_str" : "337322904180097024",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard with the docking stuff you have it\u2019s perfect. If I had it do again the air would be bought for sure.",
  "id" : 337322904180097024,
  "in_reply_to_status_id" : 337308162057195520,
  "created_at" : "2013-05-22 21:43:42 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337274946759843840",
  "geo" : { },
  "id_str" : "337275525569605632",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard 11 might have been a bit small for my fat thumbs but yeah a 13\" would have been good. I got an iPad mini and in &lt;3 with it.",
  "id" : 337275525569605632,
  "in_reply_to_status_id" : 337274946759843840,
  "created_at" : "2013-05-22 18:35:26 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337269683017367552",
  "geo" : { },
  "id_str" : "337274521289621504",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard Did you get it because your disk finally gave up? I think it used to make the odd crunch noise. I regret not going for the air",
  "id" : 337274521289621504,
  "in_reply_to_status_id" : 337269683017367552,
  "created_at" : "2013-05-22 18:31:26 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TripNI",
      "screen_name" : "TripNIApp",
      "indices" : [ 43, 53 ],
      "id_str" : "844353205",
      "id" : 844353205
    }, {
      "name" : "Translink",
      "screen_name" : "Translink_NI",
      "indices" : [ 81, 94 ],
      "id_str" : "118677636",
      "id" : 118677636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337235311455244289",
  "text" : "In belfast tomorrow and used the excellent @TripNIApp to find out the dep times. @Translink_NI make sure your drivers have change pls :)",
  "id" : 337235311455244289,
  "created_at" : "2013-05-22 15:55:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCK",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336880247360348161",
  "text" : "That moment you remember that you came into work with the fuel light on 20seconds into your morning commute... #FUCK",
  "id" : 336880247360348161,
  "created_at" : "2013-05-21 16:24:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336834434546413570",
  "geo" : { },
  "id_str" : "336834796531630080",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher Pfffffft your taste in computer hardware is only second to your taste in women ;)",
  "id" : 336834796531630080,
  "in_reply_to_status_id" : 336834434546413570,
  "created_at" : "2013-05-21 13:24:08 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336832533377454080",
  "geo" : { },
  "id_str" : "336833984849903617",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher once you try mac you never go back :)",
  "id" : 336833984849903617,
  "in_reply_to_status_id" : 336832533377454080,
  "created_at" : "2013-05-21 13:20:54 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instareel",
      "screen_name" : "instareel",
      "indices" : [ 10, 20 ],
      "id_str" : "914802482",
      "id" : 914802482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336795549145632769",
  "text" : "Just used @instareel for the first time! Great app and well executed. This is the sort of stuff that we (NI) should be producing!",
  "id" : 336795549145632769,
  "created_at" : "2013-05-21 10:48:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Keizer",
      "screen_name" : "KeizGoesBoom",
      "indices" : [ 0, 13 ],
      "id_str" : "81934123",
      "id" : 81934123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336795193288314880",
  "in_reply_to_user_id" : 81934123,
  "text" : "@KeizGoesBoom utterly fantastic wee app - I love it! Congratulations :)",
  "id" : 336795193288314880,
  "created_at" : "2013-05-21 10:46:46 +0000",
  "in_reply_to_screen_name" : "KeizGoesBoom",
  "in_reply_to_user_id_str" : "81934123",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leavinglaptopatmydesk",
      "indices" : [ 94, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336532503324135426",
  "text" : "Good bit of solid work done today\u2026 Will knock it out tomorrow and then onwards and upwards :) #leavinglaptopatmydesk",
  "id" : 336532503324135426,
  "created_at" : "2013-05-20 17:22:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336495507092418560",
  "text" : "Dear recruiter who rang my work no to offer me \u201Ca new opportunity\u201D 1. I am not interested 2. Sorry for being ignorant 3. YOU ARE A FUCKWIT!!",
  "id" : 336495507092418560,
  "created_at" : "2013-05-20 14:55:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    }, {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 13, 23 ],
      "id_str" : "212603717",
      "id" : 212603717
    }, {
      "name" : "martymc",
      "screen_name" : "martymc",
      "indices" : [ 24, 32 ],
      "id_str" : "15136295",
      "id" : 15136295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335856242482352129",
  "geo" : { },
  "id_str" : "335865584866705408",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist @carisenda @martymc I'm sick - leave me the fuck alone pair of fuckers.....",
  "id" : 335865584866705408,
  "in_reply_to_status_id" : 335856242482352129,
  "created_at" : "2013-05-18 21:12:50 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 3, 12 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 96, 102 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmccproday",
      "indices" : [ 103, 115 ]
    }, {
      "text" : "retribution",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335317118843236352",
  "text" : "RT @davehedo: Working from home today and slightly nervous to what awaits me on Monday morning! @swmcc #swmccproday #retribution",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 82, 88 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "swmccproday",
        "indices" : [ 89, 101 ]
      }, {
        "text" : "retribution",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335316946427969536",
    "text" : "Working from home today and slightly nervous to what awaits me on Monday morning! @swmcc #swmccproday #retribution",
    "id" : 335316946427969536,
    "created_at" : "2013-05-17 08:52:44 +0000",
    "user" : {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "protected" : false,
      "id_str" : "50985598",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000509606650\/9ac4420064b46da165a3e180e20ef133_normal.jpeg",
      "id" : 50985598,
      "verified" : false
    }
  },
  "id" : 335317118843236352,
  "created_at" : "2013-05-17 08:53:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 3, 15 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "Belfast Telegraph",
      "screen_name" : "BelTel",
      "indices" : [ 58, 65 ],
      "id_str" : "20687723",
      "id" : 20687723
    }, {
      "name" : "Balmoral Show",
      "screen_name" : "balmoralshow",
      "indices" : [ 76, 89 ],
      "id_str" : "263566871",
      "id" : 263566871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335132122828386304",
  "text" : "RT @DebbieCReid: Sad to see such a negative front page on @BelTel to-day re @balmoralshow. Promote NI's brill agri-food industry don't whin\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Belfast Telegraph",
        "screen_name" : "BelTel",
        "indices" : [ 41, 48 ],
        "id_str" : "20687723",
        "id" : 20687723
      }, {
        "name" : "Balmoral Show",
        "screen_name" : "balmoralshow",
        "indices" : [ 59, 72 ],
        "id_str" : "263566871",
        "id" : 263566871
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335129182667419650",
    "text" : "Sad to see such a negative front page on @BelTel to-day re @balmoralshow. Promote NI's brill agri-food industry don't whinge about traffic!!",
    "id" : 335129182667419650,
    "created_at" : "2013-05-16 20:26:38 +0000",
    "user" : {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "protected" : false,
      "id_str" : "53155256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000402062796\/48362b18cdee598e45ee405286ad7442_normal.png",
      "id" : 53155256,
      "verified" : false
    }
  },
  "id" : 335132122828386304,
  "created_at" : "2013-05-16 20:38:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335066212524490752",
  "geo" : { },
  "id_str" : "335098894587400192",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard good bit faster is it? I regret not going for a MacBook Air a while back.",
  "id" : 335098894587400192,
  "in_reply_to_status_id" : 335066212524490752,
  "created_at" : "2013-05-16 18:26:16 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 3, 12 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 24, 30 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmccproday",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335063376126410752",
  "text" : "RT @davehedo: Good show @swmcc, now we are all screwed! #swmccproday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 10, 16 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "swmccproday",
        "indices" : [ 42, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335063208593354752",
    "text" : "Good show @swmcc, now we are all screwed! #swmccproday",
    "id" : 335063208593354752,
    "created_at" : "2013-05-16 16:04:28 +0000",
    "user" : {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "protected" : false,
      "id_str" : "50985598",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000509606650\/9ac4420064b46da165a3e180e20ef133_normal.jpeg",
      "id" : 50985598,
      "verified" : false
    }
  },
  "id" : 335063376126410752,
  "created_at" : "2013-05-16 16:05:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335063128465342464",
  "geo" : { },
  "id_str" : "335063242097446912",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel I will\u2026 You are all cunts and I am gonna ass fuck everyone of you hures - with my cock - sideways!",
  "id" : 335063242097446912,
  "in_reply_to_status_id" : 335063128465342464,
  "created_at" : "2013-05-16 16:04:36 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 17, 30 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335058170307280896",
  "geo" : { },
  "id_str" : "335063136744919041",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @Paul_Moffett It is Rawls giving the fingers and it says \u201CThese are for you McCullough\u201D",
  "id" : 335063136744919041,
  "in_reply_to_status_id" : 335058170307280896,
  "created_at" : "2013-05-16 16:04:11 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 13, 26 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 69, 75 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335061738821128192",
  "text" : "RT @HaVoCT5: @Paul_Moffett  Dirty riding bastards, cud of waited for @swmcc at least, tho dont kno weather he'd b bhind the man, or in fron\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Moffett",
        "screen_name" : "Paul_Moffett",
        "indices" : [ 0, 13 ],
        "id_str" : "36913698",
        "id" : 36913698
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 56, 62 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "335056270845431808",
    "geo" : { },
    "id_str" : "335059022745047040",
    "in_reply_to_user_id" : 36913698,
    "text" : "@Paul_Moffett  Dirty riding bastards, cud of waited for @swmcc at least, tho dont kno weather he'd b bhind the man, or in front of the sheep",
    "id" : 335059022745047040,
    "in_reply_to_status_id" : 335056270845431808,
    "created_at" : "2013-05-16 15:47:50 +0000",
    "in_reply_to_screen_name" : "Paul_Moffett",
    "in_reply_to_user_id_str" : "36913698",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 335061738821128192,
  "created_at" : "2013-05-16 15:58:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335048904242524160",
  "geo" : { },
  "id_str" : "335050030438285312",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 love it - on my old desk too :)",
  "id" : 335050030438285312,
  "in_reply_to_status_id" : 335048904242524160,
  "created_at" : "2013-05-16 15:12:06 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmccproday",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335049650493067265",
  "text" : "They have now stolen my car #swmccproday I will remain professional.",
  "id" : 335049650493067265,
  "created_at" : "2013-05-16 15:10:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmccproday",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335047882090627072",
  "text" : "1 hour to go for  #swmccproday - I've took my laptop being covered in sellotape and clingfilm and countless baiting...",
  "id" : 335047882090627072,
  "created_at" : "2013-05-16 15:03:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334953443674443776",
  "geo" : { },
  "id_str" : "334969371552280576",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin I had to wait until my 'break time' to send this. Just a trail to see if I don't curse and\/or get on like I am 12. I can do it.",
  "id" : 334969371552280576,
  "in_reply_to_status_id" : 334953443674443776,
  "created_at" : "2013-05-16 09:51:36 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmccproday",
      "indices" : [ 35, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334951507789217792",
  "text" : "My \u201Cprofessional day\u201D starts now\u2026. #swmccproday",
  "id" : 334951507789217792,
  "created_at" : "2013-05-16 08:40:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/zJf1qUzFhN",
      "expanded_url" : "http:\/\/blog.swm.cc\/2013\/05\/15\/pushing-myself\/",
      "display_url" : "blog.swm.cc\/2013\/05\/15\/pus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334740198355243009",
  "text" : "Pushing yourself\u2026. http:\/\/t.co\/zJf1qUzFhN",
  "id" : 334740198355243009,
  "created_at" : "2013-05-15 18:40:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334725823435251713",
  "text" : "Listening to \u201CDuel of Fates\u201D is rather apt at the minute\u2026",
  "id" : 334725823435251713,
  "created_at" : "2013-05-15 17:43:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/334698880627253249\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/QMdPFhNTDI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKUW288CIAEpZiK.jpg",
      "id_str" : "334698880635641857",
      "id" : 334698880635641857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKUW288CIAEpZiK.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/QMdPFhNTDI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334698880627253249",
  "text" : "Assholes in here don't think I can be \"professional\" for a whole work day.... Challenge accepted fuckos!!! http:\/\/t.co\/QMdPFhNTDI",
  "id" : 334698880627253249,
  "created_at" : "2013-05-15 15:56:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 95, 105 ],
      "id_str" : "240194412",
      "id" : 240194412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovethework",
      "indices" : [ 109, 121 ]
    }, {
      "text" : "nerdtastic",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334307278637375489",
  "text" : "I am doing regular expressions inside Java\u2026 My working life has changed somewhat since joining @RepKnight :) #lovethework #nerdtastic",
  "id" : 334307278637375489,
  "created_at" : "2013-05-14 14:00:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 1, 15 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 17, 23 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 34, 41 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haveyettobeatsteveinchessafter13years",
      "indices" : [ 82, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334066735827259392",
  "text" : "\u201C@jenporterhall: @swmcc I am your @srushe to cards\u201D ill beat you I have no doubt. #haveyettobeatsteveinchessafter13years",
  "id" : 334066735827259392,
  "created_at" : "2013-05-13 22:04:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 1, 15 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 48, 54 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unbeatable",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334056899160965120",
  "text" : "\u201C@jenporterhall: Was very pleasing to slaughter @swmcc at cards :) #unbeatable\u201D Got lucky!",
  "id" : 334056899160965120,
  "created_at" : "2013-05-13 21:25:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333990372390871043",
  "text" : "Also this weather is fucking with my head\u2026 One second windy, next raining, next hailstones and now sunny\u2026 Bi-polar weather...",
  "id" : 333990372390871043,
  "created_at" : "2013-05-13 17:01:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333990179503222785",
  "text" : "Not done for the day yet, but have to say I am very VERY impressed with tmux so far.",
  "id" : 333990179503222785,
  "created_at" : "2013-05-13 17:00:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333942087789723649",
  "text" : "Having a big dump",
  "id" : 333942087789723649,
  "created_at" : "2013-05-13 13:49:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Freyfogle",
      "screen_name" : "freyfogle",
      "indices" : [ 1, 11 ],
      "id_str" : "2822431",
      "id" : 2822431
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justwantmyfuckingavatar",
      "indices" : [ 100, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333897177782943744",
  "text" : "\u201C@freyfogle: For github avatar need gravatar account. For gravatar account need wordpress account.  #justwantmyfuckingavatar\u201D  VERY TRUE",
  "id" : 333897177782943744,
  "created_at" : "2013-05-13 10:51:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333890897005662209",
  "text" : "A few hours on production working with tmux - like it more than screen but could just be new fangled\u2026 Will give it another wee while yet...",
  "id" : 333890897005662209,
  "created_at" : "2013-05-13 10:26:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wisethefuckup",
      "indices" : [ 51, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333874582031302657",
  "text" : "Fuck. Off. Rain. It. Is. Supposed. To. Be. Summer. #wisethefuckup",
  "id" : 333874582031302657,
  "created_at" : "2013-05-13 09:21:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333660686846660610",
  "geo" : { },
  "id_str" : "333678168957407235",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings I\u2019d stick with mocha - seems to be the must wildly used. Not saying it\u2019s the best though.",
  "id" : 333678168957407235,
  "in_reply_to_status_id" : 333660686846660610,
  "created_at" : "2013-05-12 20:20:49 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theyllsoonlean",
      "indices" : [ 61, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333556904280326144",
  "geo" : { },
  "id_str" : "333615588532436993",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit all promised \u2018stock\u2019 and free coffee no doubt. #theyllsoonlean",
  "id" : 333615588532436993,
  "in_reply_to_status_id" : 333556904280326144,
  "created_at" : "2013-05-12 16:12:09 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333295347373842432",
  "text" : "I love my iPad mini\u2026\u2026.",
  "id" : 333295347373842432,
  "created_at" : "2013-05-11 18:59:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333246175153098754",
  "text" : "Toying with the idea of heading to the cinema after a few hours playing with indexes and fuzzy searches\u2026\u2026.",
  "id" : 333246175153098754,
  "created_at" : "2013-05-11 15:44:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bastard",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "loveyoureally",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333219198983622656",
  "geo" : { },
  "id_str" : "333219376281042946",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl You know you owe me a new iPhone - fucking battery on this lasts half the time since Google Auth :) #bastard #loveyoureally",
  "id" : 333219376281042946,
  "in_reply_to_status_id" : 333219198983622656,
  "created_at" : "2013-05-11 13:57:44 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333215246741274624",
  "geo" : { },
  "id_str" : "333219123033157634",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl voice authentication?",
  "id" : 333219123033157634,
  "in_reply_to_status_id" : 333215246741274624,
  "created_at" : "2013-05-11 13:56:44 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333212448683335681",
  "geo" : { },
  "id_str" : "333214601426640896",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl millions in the bank\u2026 I\u2019d like to think so :) You in on Monday? :)",
  "id" : 333214601426640896,
  "in_reply_to_status_id" : 333212448683335681,
  "created_at" : "2013-05-11 13:38:46 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Mone OBE",
      "screen_name" : "MichelleMone",
      "indices" : [ 0, 13 ],
      "id_str" : "58432995",
      "id" : 58432995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "impressive",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333203149450010624",
  "geo" : { },
  "id_str" : "333204400845762560",
  "in_reply_to_user_id" : 58432995,
  "text" : "@MichelleMone your work ethic is amazing - you never seem to stop. #impressive",
  "id" : 333204400845762560,
  "in_reply_to_status_id" : 333203149450010624,
  "created_at" : "2013-05-11 12:58:14 +0000",
  "in_reply_to_screen_name" : "MichelleMone",
  "in_reply_to_user_id_str" : "58432995",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saturdays",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333142293634752513",
  "text" : "One more episode of the west wing then a jaunt into the office\u2026 #saturdays",
  "id" : 333142293634752513,
  "created_at" : "2013-05-11 08:51:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontmentionthecword",
      "indices" : [ 58, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332924873586380800",
  "geo" : { },
  "id_str" : "332945622774738946",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl it\u2019ll hopefully mean more people adopt Debian. :) #dontmentionthecword",
  "id" : 332945622774738946,
  "in_reply_to_status_id" : 332924873586380800,
  "created_at" : "2013-05-10 19:49:56 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/332837941980307457\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/156M4c3cDb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ56WEQCIAEoAFn.jpg",
      "id_str" : "332837941988696065",
      "id" : 332837941988696065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ56WEQCIAEoAFn.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/156M4c3cDb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332837941980307457",
  "text" : "Came back from a quick trip to the shop to see this! Classy fellas :) http:\/\/t.co\/156M4c3cDb",
  "id" : 332837941980307457,
  "created_at" : "2013-05-10 12:42:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 3, 10 ],
      "id_str" : "285766850",
      "id" : 285766850
    }, {
      "name" : "Daniel Shaw",
      "screen_name" : "dshaw",
      "indices" : [ 68, 74 ],
      "id_str" : "806757",
      "id" : 806757
    }, {
      "name" : "James Halliday",
      "screen_name" : "substack",
      "indices" : [ 75, 84 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Andrew Sliwinski",
      "screen_name" : "thisandagain",
      "indices" : [ 85, 98 ],
      "id_str" : "10658042",
      "id" : 10658042
    }, {
      "name" : "Mark Cavage",
      "screen_name" : "mcavage",
      "indices" : [ 103, 111 ],
      "id_str" : "17684601",
      "id" : 17684601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/RfOwQdP4wj",
      "expanded_url" : "http:\/\/nodeup.com\/fortyfour",
      "display_url" : "nodeup.com\/fortyfour"
    } ]
  },
  "geo" : { },
  "id_str" : "332618311223353344",
  "text" : "RT @NodeUp: New episode! http:\/\/t.co\/RfOwQdP4wj\n\nCreating APIs with @dshaw @substack @thisandagain and @mcavage!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Shaw",
        "screen_name" : "dshaw",
        "indices" : [ 56, 62 ],
        "id_str" : "806757",
        "id" : 806757
      }, {
        "name" : "James Halliday",
        "screen_name" : "substack",
        "indices" : [ 63, 72 ],
        "id_str" : "125027291",
        "id" : 125027291
      }, {
        "name" : "Andrew Sliwinski",
        "screen_name" : "thisandagain",
        "indices" : [ 73, 86 ],
        "id_str" : "10658042",
        "id" : 10658042
      }, {
        "name" : "Mark Cavage",
        "screen_name" : "mcavage",
        "indices" : [ 91, 99 ],
        "id_str" : "17684601",
        "id" : 17684601
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/RfOwQdP4wj",
        "expanded_url" : "http:\/\/nodeup.com\/fortyfour",
        "display_url" : "nodeup.com\/fortyfour"
      } ]
    },
    "geo" : { },
    "id_str" : "332618103320088577",
    "text" : "New episode! http:\/\/t.co\/RfOwQdP4wj\n\nCreating APIs with @dshaw @substack @thisandagain and @mcavage!",
    "id" : 332618103320088577,
    "created_at" : "2013-05-09 22:08:30 +0000",
    "user" : {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "protected" : false,
      "id_str" : "285766850",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1675860861\/logo2_normal.jpg",
      "id" : 285766850,
      "verified" : false
    }
  },
  "id" : 332618311223353344,
  "created_at" : "2013-05-09 22:09:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris van Es",
      "screen_name" : "chris_van_es",
      "indices" : [ 0, 13 ],
      "id_str" : "157198909",
      "id" : 157198909
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "diehard",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332601871078412288",
  "geo" : { },
  "id_str" : "332603722293182464",
  "in_reply_to_user_id" : 157198909,
  "text" : "@chris_van_es welcome to the party pal! (tries to find a dead mercenary out the window). #diehard",
  "id" : 332603722293182464,
  "in_reply_to_status_id" : 332601871078412288,
  "created_at" : "2013-05-09 21:11:21 +0000",
  "in_reply_to_screen_name" : "chris_van_es",
  "in_reply_to_user_id_str" : "157198909",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332599897796800512",
  "geo" : { },
  "id_str" : "332600096074125315",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl yeah - binary files have fucked me :) So just creating something to bridge the gap. Nothing big- just a wee tiny ickle one :)",
  "id" : 332600096074125315,
  "in_reply_to_status_id" : 332599897796800512,
  "created_at" : "2013-05-09 20:56:56 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332598743327191041",
  "geo" : { },
  "id_str" : "332599466236448771",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl I\u2019m writing a wee tiny API on the JVM. I am using way too many acronyms\u2026 Time for bed soon and an early wake up :)",
  "id" : 332599466236448771,
  "in_reply_to_status_id" : 332598743327191041,
  "created_at" : "2013-05-09 20:54:26 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332593213191897088",
  "text" : "The more time I spend and work with it - the more time I like the JVM",
  "id" : 332593213191897088,
  "created_at" : "2013-05-09 20:29:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jbrevel\/status\/332446679028625408\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/34bDAUJ2gw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ0WfkKCcAAjBB1.png",
      "id_str" : "332446679032819712",
      "id" : 332446679032819712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ0WfkKCcAAjBB1.png",
      "sizes" : [ {
        "h" : 31,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 31,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 31,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 31,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 18,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/34bDAUJ2gw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332447035993239552",
  "text" : "RT @jbrevel: last thing I ever wanted to see on hipchat :-( http:\/\/t.co\/34bDAUJ2gw",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jbrevel\/status\/332446679028625408\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/34bDAUJ2gw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ0WfkKCcAAjBB1.png",
        "id_str" : "332446679032819712",
        "id" : 332446679032819712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ0WfkKCcAAjBB1.png",
        "sizes" : [ {
          "h" : 31,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 31,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 31,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 31,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 18,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/34bDAUJ2gw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332446679028625408",
    "text" : "last thing I ever wanted to see on hipchat :-( http:\/\/t.co\/34bDAUJ2gw",
    "id" : 332446679028625408,
    "created_at" : "2013-05-09 10:47:19 +0000",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 332447035993239552,
  "created_at" : "2013-05-09 10:48:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wishicansaybutcant",
      "indices" : [ 62, 81 ]
    }, {
      "text" : "bigdatamyass",
      "indices" : [ 82, 95 ]
    }, {
      "text" : "thisisproperbigdata",
      "indices" : [ 96, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332234426077556737",
  "text" : "Metrics in this job just scare the shit out of me sometimes\u2026. #wishicansaybutcant #bigdatamyass #thisisproperbigdata",
  "id" : 332234426077556737,
  "created_at" : "2013-05-08 20:43:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Groove",
      "screen_name" : "GrooveHQ",
      "indices" : [ 3, 12 ],
      "id_str" : "274643893",
      "id" : 274643893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/dVTT0EDPqo",
      "expanded_url" : "http:\/\/blog.groovehq.com\/post\/49851105329\/3-reasons-why-our-startup-embraces-remote-working",
      "display_url" : "blog.groovehq.com\/post\/498511053\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332191548282372097",
  "text" : "RT @GrooveHQ: 3 Reasons Why Our Startup Embraces Remote Working: http:\/\/t.co\/dVTT0EDPqo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/dVTT0EDPqo",
        "expanded_url" : "http:\/\/blog.groovehq.com\/post\/49851105329\/3-reasons-why-our-startup-embraces-remote-working",
        "display_url" : "blog.groovehq.com\/post\/498511053\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "331763170806996993",
    "text" : "3 Reasons Why Our Startup Embraces Remote Working: http:\/\/t.co\/dVTT0EDPqo",
    "id" : 331763170806996993,
    "created_at" : "2013-05-07 13:31:18 +0000",
    "user" : {
      "name" : "Groove",
      "screen_name" : "GrooveHQ",
      "protected" : false,
      "id_str" : "274643893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2875288887\/3851bf22d066a7c49828fd1e663a4142_normal.png",
      "id" : 274643893,
      "verified" : false
    }
  },
  "id" : 332191548282372097,
  "created_at" : "2013-05-08 17:53:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian D. Quinn",
      "screen_name" : "briandq",
      "indices" : [ 0, 8 ],
      "id_str" : "17363843",
      "id" : 17363843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331873149413109761",
  "geo" : { },
  "id_str" : "331873440900460544",
  "in_reply_to_user_id" : 17363843,
  "text" : "@briandq no. No respect. Pity, plenty of pity.",
  "id" : 331873440900460544,
  "in_reply_to_status_id" : 331873149413109761,
  "created_at" : "2013-05-07 20:49:28 +0000",
  "in_reply_to_screen_name" : "briandq",
  "in_reply_to_user_id_str" : "17363843",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 34, 46 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331784572901666818",
  "text" : "Thought I heard something outside @DebbieCReid cutting the grass on only what can be described as the Death Star of lawnmowers\u2026.",
  "id" : 331784572901666818,
  "created_at" : "2013-05-07 14:56:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oisin",
      "screen_name" : "oisin",
      "indices" : [ 0, 6 ],
      "id_str" : "8446902",
      "id" : 8446902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331769107793989634",
  "geo" : { },
  "id_str" : "331770319012507649",
  "in_reply_to_user_id" : 8446902,
  "text" : "@oisin just installed this - it is awesome! :)",
  "id" : 331770319012507649,
  "in_reply_to_status_id" : 331769107793989634,
  "created_at" : "2013-05-07 13:59:42 +0000",
  "in_reply_to_screen_name" : "oisin",
  "in_reply_to_user_id_str" : "8446902",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oisin",
      "screen_name" : "oisin",
      "indices" : [ 3, 9 ],
      "id_str" : "8446902",
      "id" : 8446902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/sfE36yluit",
      "expanded_url" : "http:\/\/blogs.atlassian.com\/2013\/05\/git-tig\/",
      "display_url" : "blogs.atlassian.com\/2013\/05\/git-ti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331770274754199556",
  "text" : "RT @oisin: tig - for command line git users http:\/\/t.co\/sfE36yluit",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/sfE36yluit",
        "expanded_url" : "http:\/\/blogs.atlassian.com\/2013\/05\/git-tig\/",
        "display_url" : "blogs.atlassian.com\/2013\/05\/git-ti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "331769107793989634",
    "text" : "tig - for command line git users http:\/\/t.co\/sfE36yluit",
    "id" : 331769107793989634,
    "created_at" : "2013-05-07 13:54:53 +0000",
    "user" : {
      "name" : "oisin",
      "screen_name" : "oisin",
      "protected" : false,
      "id_str" : "8446902",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000483810361\/d965a36e535aa4b015b9180d427cab46_normal.jpeg",
      "id" : 8446902,
      "verified" : false
    }
  },
  "id" : 331770274754199556,
  "created_at" : "2013-05-07 13:59:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331763147255996416",
  "text" : "So Deloitte are creating 177 new jobs - fair play.. But they aren\u2019t \u2018Northern Irish\u2019 jobs\u2026 Doing nothing to promote innovation here :(",
  "id" : 331763147255996416,
  "created_at" : "2013-05-07 13:31:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/SHcTyK2Nsy",
      "expanded_url" : "http:\/\/instagram.com\/p\/ZAd1uKBXxv\/",
      "display_url" : "instagram.com\/p\/ZAd1uKBXxv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "331718414185947136",
  "text" : "Getting an \"Application Error\" in the login model. So am taking this pic to stop me killing myself :) http:\/\/t.co\/SHcTyK2Nsy",
  "id" : 331718414185947136,
  "created_at" : "2013-05-07 10:33:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CambridgeWeatherUK",
      "screen_name" : "CamWeatherUK",
      "indices" : [ 1, 14 ],
      "id_str" : "1053431814",
      "id" : 1053431814
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CambridgeWeather",
      "indices" : [ 108, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331435018591301633",
  "text" : "\u201C@CamWeatherUK: UPDATE: At 16:00 the temperature reached 23.0C, the hottest day since September last year. \n#CambridgeWeather\u201D FUCK YOU LOT!",
  "id" : 331435018591301633,
  "created_at" : "2013-05-06 15:47:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "digitalcircle",
      "screen_name" : "digitalcircle",
      "indices" : [ 41, 55 ],
      "id_str" : "15902682",
      "id" : 15902682
    }, {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "indices" : [ 57, 64 ],
      "id_str" : "14060295",
      "id" : 14060295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/jXSXifmuW9",
      "expanded_url" : "http:\/\/wp.me\/p3bKqw-8P",
      "display_url" : "wp.me\/p3bKqw-8P"
    } ]
  },
  "geo" : { },
  "id_str" : "331006822108499968",
  "text" : "RT @jasebell: Open Source Collaboration (@digitalcircle, @cimota) http:\/\/t.co\/jXSXifmuW9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "digitalcircle",
        "screen_name" : "digitalcircle",
        "indices" : [ 27, 41 ],
        "id_str" : "15902682",
        "id" : 15902682
      }, {
        "name" : "Matt Johnston",
        "screen_name" : "cimota",
        "indices" : [ 43, 50 ],
        "id_str" : "14060295",
        "id" : 14060295
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/jXSXifmuW9",
        "expanded_url" : "http:\/\/wp.me\/p3bKqw-8P",
        "display_url" : "wp.me\/p3bKqw-8P"
      } ]
    },
    "geo" : { },
    "id_str" : "330958623465406465",
    "text" : "Open Source Collaboration (@digitalcircle, @cimota) http:\/\/t.co\/jXSXifmuW9",
    "id" : 330958623465406465,
    "created_at" : "2013-05-05 08:14:19 +0000",
    "user" : {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "protected" : false,
      "id_str" : "1248789104",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000600719719\/1f076e9f2650e4ea1930f33a7fbd28de_normal.jpeg",
      "id" : 1248789104,
      "verified" : false
    }
  },
  "id" : 331006822108499968,
  "created_at" : "2013-05-05 11:25:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/OTca2xq9SX",
      "expanded_url" : "http:\/\/blog.swm.cc\/2013\/05\/04\/fulid-working-works-for-work\/",
      "display_url" : "blog.swm.cc\/2013\/05\/04\/ful\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "330754260516098049",
  "text" : "Fluid working word for work - http:\/\/t.co\/OTca2xq9SX",
  "id" : 330754260516098049,
  "created_at" : "2013-05-04 18:42:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330750850643394560",
  "geo" : { },
  "id_str" : "330754178811043841",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr better be the original :)",
  "id" : 330754178811043841,
  "in_reply_to_status_id" : 330750850643394560,
  "created_at" : "2013-05-04 18:41:56 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 16, 29 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 30, 46 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330743453384331264",
  "geo" : { },
  "id_str" : "330744117522997248",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @RickyHassard @michaelnsimpson don't fall for it.. Rick will get four episodes in then just stop....",
  "id" : 330744117522997248,
  "in_reply_to_status_id" : 330743453384331264,
  "created_at" : "2013-05-04 18:01:57 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 1, 14 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 40, 46 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cheapdate",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330722177919893505",
  "text" : "\u201C@stevebiscuit: Out for a man-date with @swmcc\u201D and he even paid :) #cheapdate",
  "id" : 330722177919893505,
  "created_at" : "2013-05-04 16:34:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330645830245683200",
  "geo" : { },
  "id_str" : "330710133862715393",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll :) Coolest person ever :)",
  "id" : 330710133862715393,
  "in_reply_to_status_id" : 330645830245683200,
  "created_at" : "2013-05-04 15:46:54 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 14, 26 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330335056545579010",
  "geo" : { },
  "id_str" : "330335296526884867",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @StrayTaoist coffee with you on Saturday Steve\u2026 Could care less about Kerr.. Just remember you are from Portglenone :)",
  "id" : 330335296526884867,
  "in_reply_to_status_id" : 330335056545579010,
  "created_at" : "2013-05-03 14:57:26 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 13, 26 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330334307912654849",
  "geo" : { },
  "id_str" : "330334526884679683",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist @stevebiscuit :) I was with me bro so didn\u2019t have time to arrange a meet. Will be again no doubt and will arrange for then.",
  "id" : 330334526884679683,
  "in_reply_to_status_id" : 330334307912654849,
  "created_at" : "2013-05-03 14:54:23 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 13, 26 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330333781095485442",
  "geo" : { },
  "id_str" : "330333932040114176",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist @stevebiscuit Pretty much. Was over in London on Wednesday but only had time to meet one cabal fella for coffee.. I hate you.",
  "id" : 330333932040114176,
  "in_reply_to_status_id" : 330333781095485442,
  "created_at" : "2013-05-03 14:52:01 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Neubauer",
      "screen_name" : "peterneubauer",
      "indices" : [ 3, 17 ],
      "id_str" : "14721805",
      "id" : 14721805
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "in",
      "indices" : [ 103, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/71eZYgVcAC",
      "expanded_url" : "http:\/\/vimeo.com\/64827612",
      "display_url" : "vimeo.com\/64827612"
    } ]
  },
  "geo" : { },
  "id_str" : "330330281330487296",
  "text" : "RT @peterneubauer: Visualizing Fraud Data with Cambridge Intelligence and Neo4j http:\/\/t.co\/71eZYgVcAC #in",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "in",
        "indices" : [ 84, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/71eZYgVcAC",
        "expanded_url" : "http:\/\/vimeo.com\/64827612",
        "display_url" : "vimeo.com\/64827612"
      } ]
    },
    "geo" : { },
    "id_str" : "330306688764739585",
    "text" : "Visualizing Fraud Data with Cambridge Intelligence and Neo4j http:\/\/t.co\/71eZYgVcAC #in",
    "id" : 330306688764739585,
    "created_at" : "2013-05-03 13:03:46 +0000",
    "user" : {
      "name" : "Peter Neubauer",
      "screen_name" : "peterneubauer",
      "protected" : false,
      "id_str" : "14721805",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000529267759\/41cc29f7f7848ef5f452a43c7bd503b0_normal.png",
      "id" : 14721805,
      "verified" : false
    }
  },
  "id" : 330330281330487296,
  "created_at" : "2013-05-03 14:37:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 14, 26 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330306498460782592",
  "geo" : { },
  "id_str" : "330329566759505920",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @StrayTaoist Really wish you two would stop discussing clothes\u2026.",
  "id" : 330329566759505920,
  "in_reply_to_status_id" : 330306498460782592,
  "created_at" : "2013-05-03 14:34:40 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 30, 44 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329903165166215168",
  "geo" : { },
  "id_str" : "330318108734664704",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams @peter_omalley what you doing with my country?",
  "id" : 330318108734664704,
  "in_reply_to_status_id" : 329903165166215168,
  "created_at" : "2013-05-03 13:49:08 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Jogger",
      "screen_name" : "angryjogger",
      "indices" : [ 0, 12 ],
      "id_str" : "456868224",
      "id" : 456868224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330274409770270720",
  "geo" : { },
  "id_str" : "330281232342585344",
  "in_reply_to_user_id" : 456868224,
  "text" : "@angryjogger I dunno how you can use that stuff and still be sane\u2026 Wrecks my head\u2026.",
  "id" : 330281232342585344,
  "in_reply_to_status_id" : 330274409770270720,
  "created_at" : "2013-05-03 11:22:36 +0000",
  "in_reply_to_screen_name" : "angryjogger",
  "in_reply_to_user_id_str" : "456868224",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330233664011128832",
  "geo" : { },
  "id_str" : "330234739762012160",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard do it - it'd be interesting to read... do it :) NOW!",
  "id" : 330234739762012160,
  "in_reply_to_status_id" : 330233664011128832,
  "created_at" : "2013-05-03 08:17:52 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciara Bryans",
      "screen_name" : "himynameisciara",
      "indices" : [ 3, 19 ],
      "id_str" : "14377865",
      "id" : 14377865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329728162596536321",
  "text" : "RT @himynameisciara: So far it looks like Belfast is doing nothing for Star Wars day on Saturday. If I had the force, I'd stick it up your \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329679364126044160",
    "text" : "So far it looks like Belfast is doing nothing for Star Wars day on Saturday. If I had the force, I'd stick it up your arse, Belfast.",
    "id" : 329679364126044160,
    "created_at" : "2013-05-01 19:31:00 +0000",
    "user" : {
      "name" : "Ciara Bryans",
      "screen_name" : "himynameisciara",
      "protected" : false,
      "id_str" : "14377865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3536096387\/8c0504d7865af4d34f38575ef0729c77_normal.jpeg",
      "id" : 14377865,
      "verified" : false
    }
  },
  "id" : 329728162596536321,
  "created_at" : "2013-05-01 22:44:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 9, 22 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329558563703898112",
  "geo" : { },
  "id_str" : "329564717381210113",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @Paul_Moffett what the fuck you two on about\u2026. cocks.",
  "id" : 329564717381210113,
  "in_reply_to_status_id" : 329558563703898112,
  "created_at" : "2013-05-01 11:55:26 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]