Grailbird.data.tweets_2010_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15093842499",
  "geo" : { },
  "id_str" : "15093938119",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Not me. Am thinking about going in for a few hours though.. But look at the sun!!! Dunno.",
  "id" : 15093938119,
  "in_reply_to_status_id" : 15093842499,
  "created_at" : "2010-05-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15034398185",
  "text" : "Basil McCrea on the politics show... He could have done with leaving at least one button buttoned up.. Yup.. He really could...",
  "id" : 15034398185,
  "created_at" : "2010-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14987989533",
  "text" : "Fucking fuck fuck.",
  "id" : 14987989533,
  "created_at" : "2010-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Fabric",
      "screen_name" : "Digital_Fabric",
      "indices" : [ 0, 15 ],
      "id_str" : "462787016",
      "id" : 462787016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14901457969",
  "text" : "@digital_fabric you are an ugly cunt ;)",
  "id" : 14901457969,
  "created_at" : "2010-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14830694636",
  "geo" : { },
  "id_str" : "14831025077",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings kick their asses.",
  "id" : 14831025077,
  "in_reply_to_status_id" : 14830694636,
  "created_at" : "2010-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14829306177",
  "geo" : { },
  "id_str" : "14831325145",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop 2:30 :( Shit one... zzzzz zzzzz zzzzz",
  "id" : 14831325145,
  "in_reply_to_status_id" : 14829306177,
  "created_at" : "2010-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC This Week",
      "screen_name" : "bbcthisweek",
      "indices" : [ 12, 24 ],
      "id_str" : "78602972",
      "id" : 78602972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14835511595",
  "text" : "Galloway on @bbcthisweek .. Be interesting to hear what he has to say",
  "id" : 14835511595,
  "created_at" : "2010-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14849753473",
  "text" : "Going to Made In Belfast for the bros birthday. Thirty today!!!",
  "id" : 14849753473,
  "created_at" : "2010-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wankers",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14857640701",
  "text" : "Made In Belfast ran out of gas or something. Grrrr. Now in Apartment. Nice meal. #wankers",
  "id" : 14857640701,
  "created_at" : "2010-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14757019785",
  "text" : "Loose Women on the tee vee. Vile vile vile.",
  "id" : 14757019785,
  "created_at" : "2010-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14759240015",
  "geo" : { },
  "id_str" : "14787358381",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne last day of my hold. Was in Salou. Loved it. How is Miss G?",
  "id" : 14787358381,
  "in_reply_to_status_id" : 14759240015,
  "created_at" : "2010-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14757092259",
  "geo" : { },
  "id_str" : "14787378388",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop was on hold in Salou. Back tomorrow. How is you?",
  "id" : 14787378388,
  "in_reply_to_status_id" : 14757092259,
  "created_at" : "2010-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14169156485",
  "geo" : { },
  "id_str" : "14787426439",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes am only back. Will watch them in the next few days. Coursework finished? You ready fir your hols? If not I can go in ur place :)",
  "id" : 14787426439,
  "in_reply_to_status_id" : 14169156485,
  "created_at" : "2010-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14151732265",
  "text" : "Fucking ash cloud. Just clear tomorrow for an ickle while tomorrow.... After two pm it can erupt as much as it likes.",
  "id" : 14151732265,
  "created_at" : "2010-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Fabric",
      "screen_name" : "Digital_Fabric",
      "indices" : [ 0, 15 ],
      "id_str" : "462787016",
      "id" : 462787016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13981617394",
  "text" : "@digital_fabric where you heading this weather?",
  "id" : 13981617394,
  "created_at" : "2010-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Fabric",
      "screen_name" : "Digital_Fabric",
      "indices" : [ 0, 15 ],
      "id_str" : "462787016",
      "id" : 462787016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13982294435",
  "text" : "@digital_fabric still got the big jeep?",
  "id" : 13982294435,
  "created_at" : "2010-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13982327239",
  "text" : "I am taking some Korean cinema home with me tonight to watch over the weekend thanks to @mnehughes  :)",
  "id" : 13982327239,
  "created_at" : "2010-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13902954470",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe is in a suit! :)",
  "id" : 13902954470,
  "created_at" : "2010-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13926086394",
  "text" : "Listening to Sarah Palin on Fox News. Comedy value is great.",
  "id" : 13926086394,
  "created_at" : "2010-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13930612389",
  "geo" : { },
  "id_str" : "13931363824",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne how do they expect you to have a life with all this travelling?",
  "id" : 13931363824,
  "in_reply_to_status_id" : 13930612389,
  "created_at" : "2010-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13931383799",
  "text" : "Soaked. Damn rain...",
  "id" : 13931383799,
  "created_at" : "2010-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13939278119",
  "text" : "Dianne Abbot. How annoying. Portilo, even morse so. Interseting people though...",
  "id" : 13939278119,
  "created_at" : "2010-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13939933995",
  "text" : "Andrew Rawnley on This Week. Excellent.",
  "id" : 13939933995,
  "created_at" : "2010-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC This Week",
      "screen_name" : "bbcthisweek",
      "indices" : [ 0, 12 ],
      "id_str" : "78602972",
      "id" : 78602972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13939693840",
  "geo" : { },
  "id_str" : "13940165140",
  "in_reply_to_user_id" : 78602972,
  "text" : "@bbcthisweek welcome :)",
  "id" : 13940165140,
  "in_reply_to_status_id" : 13939693840,
  "created_at" : "2010-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "bbcthisweek",
  "in_reply_to_user_id_str" : "78602972",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13848212881",
  "text" : "I can think of worse views to be eating my lunch to.  http:\/\/twitpic.com\/1n5ixq",
  "id" : 13848212881,
  "created_at" : "2010-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13848247021",
  "geo" : { },
  "id_str" : "13848697325",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings that I am. It's a lovely day for it.",
  "id" : 13848697325,
  "in_reply_to_status_id" : 13848247021,
  "created_at" : "2010-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13848788010",
  "geo" : { },
  "id_str" : "13850518844",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings I was looking at that and wondering how in the name o fuck you get there",
  "id" : 13850518844,
  "in_reply_to_status_id" : 13848788010,
  "created_at" : "2010-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13875231277",
  "text" : "Ahhhhhhhh. The Apprentice is back. But this time with kids..... Car crash teeee veeeee... Awesome.",
  "id" : 13875231277,
  "created_at" : "2010-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13777231980",
  "geo" : { },
  "id_str" : "13777383377",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne a pull another unpaid all nighter? :( :( :( :(",
  "id" : 13777383377,
  "in_reply_to_status_id" : 13777231980,
  "created_at" : "2010-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13779650730",
  "geo" : { },
  "id_str" : "13779746313",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe :D",
  "id" : 13779746313,
  "in_reply_to_status_id" : 13779650730,
  "created_at" : "2010-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13786540522",
  "text" : "This might be corrected in a few mins.. But its class http:\/\/bit.ly\/90HV1p",
  "id" : 13786540522,
  "created_at" : "2010-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13804760000",
  "text" : "Welcomes his new overlords. Now everyone bend over :)",
  "id" : 13804760000,
  "created_at" : "2010-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13804785516",
  "geo" : { },
  "id_str" : "13805140560",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne use your femine charm to get the evil one swimming and then drown him\/her :)",
  "id" : 13805140560,
  "in_reply_to_status_id" : 13804785516,
  "created_at" : "2010-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Fabric",
      "screen_name" : "Digital_Fabric",
      "indices" : [ 0, 15 ],
      "id_str" : "462787016",
      "id" : 462787016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13714129766",
  "text" : "@digital_fabric where you working now?",
  "id" : 13714129766,
  "created_at" : "2010-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Fabric",
      "screen_name" : "Digital_Fabric",
      "indices" : [ 0, 15 ],
      "id_str" : "462787016",
      "id" : 462787016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13714951284",
  "text" : "@digital_fabric sweet. and going the opposite way of the traffic.. nice :)",
  "id" : 13714951284,
  "created_at" : "2010-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Fabric",
      "screen_name" : "Digital_Fabric",
      "indices" : [ 0, 15 ],
      "id_str" : "462787016",
      "id" : 462787016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13715178161",
  "text" : "@digital_fabric instead of 9:30pm finishes.. sweet :)",
  "id" : 13715178161,
  "created_at" : "2010-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13734655063",
  "geo" : { },
  "id_str" : "13734873644",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bk_gordon good man :)",
  "id" : 13734873644,
  "in_reply_to_status_id" : 13734655063,
  "created_at" : "2010-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greasy Fringe",
      "screen_name" : "GreasyFringe",
      "indices" : [ 11, 24 ],
      "id_str" : "1222903783",
      "id" : 1222903783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13735148020",
  "geo" : { },
  "id_str" : "13735811867",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bk_gordon @GreasyFringe I think I hit a raw nerve there ;)",
  "id" : 13735811867,
  "in_reply_to_status_id" : 13735148020,
  "created_at" : "2010-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Murray",
      "screen_name" : "akaihane",
      "indices" : [ 0, 9 ],
      "id_str" : "14961440",
      "id" : 14961440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13747042135",
  "in_reply_to_user_id" : 14961440,
  "text" : "@akaihane @bk_gordon gerrrrrrr kazza. Grrrrrrrrrrrr",
  "id" : 13747042135,
  "created_at" : "2010-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "akaihane",
  "in_reply_to_user_id_str" : "14961440",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13536780188",
  "geo" : { },
  "id_str" : "13536876628",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings would you? ;)",
  "id" : 13536876628,
  "in_reply_to_status_id" : 13536780188,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13536927841",
  "geo" : { },
  "id_str" : "13536936512",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings cunt",
  "id" : 13536936512,
  "in_reply_to_status_id" : 13536927841,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13538014526",
  "text" : "Its now a hung government.. Lets cue the credit rating of the UK getting slashed in June.. bend over now folks :)",
  "id" : 13538014526,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13539749122",
  "text" : "\"A discretionary service of 10% will be added to the final bills of tables of 6 or more.\" Well you are gonna earn your tip then fuckwad!!",
  "id" : 13539749122,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13543186303",
  "text" : "Boss brought in three Nerf guns today..  Me and Pete are getting bombarded at our cool desks.. http:\/\/bit.ly\/o8fRV - ITS HAMMER TIME.",
  "id" : 13543186303,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13543095730",
  "geo" : { },
  "id_str" : "13543332685",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Pass em onto ma mobile. I'll deal with them :)",
  "id" : 13543332685,
  "in_reply_to_status_id" : 13543095730,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13543862100",
  "geo" : { },
  "id_str" : "13543898369",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe too late. you started it. Prepare for invasion, then a really badly planned occupation. Sure what's the worst that could happen :)",
  "id" : 13543898369,
  "in_reply_to_status_id" : 13543862100,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13544113419",
  "geo" : { },
  "id_str" : "13544651645",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes hmmmmmm.. email coming to you soon as soon as i come back from getting ma sandwich :)",
  "id" : 13544651645,
  "in_reply_to_status_id" : 13544113419,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13547175378",
  "geo" : { },
  "id_str" : "13547636808",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne do it :)",
  "id" : 13547636808,
  "in_reply_to_status_id" : 13547175378,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13550675390",
  "geo" : { },
  "id_str" : "13550695130",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes Noooooooo.. The other way...the other way.. the other way... :)",
  "id" : 13550695130,
  "in_reply_to_status_id" : 13550675390,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13551384408",
  "text" : "Every employee in this place just took a pot luck shot at me.. Well almost.. :)",
  "id" : 13551384408,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13567117140",
  "text" : "At the Barking Dog in Belfast. My Dad just said \"Fuck me, I could buy a cow for that\" to the waiter re: the price of the sirloin",
  "id" : 13567117140,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13513608165",
  "text" : "Mick Fleatley aka Slugger. Still an ass five years on. Amazing.",
  "id" : 13513608165,
  "created_at" : "2010-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13513958092",
  "text" : "Night night. Will see who wins tomorrow.  http:\/\/twitpic.com\/1lm9kd",
  "id" : 13513958092,
  "created_at" : "2010-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wankeroftheyeargoesto",
      "indices" : [ 115, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13514738743",
  "text" : "Jim Allister just corrected Noel Thompson on Noel sting Derry. Well for him that has fuck all else to worry about. #wankeroftheyeargoesto",
  "id" : 13514738743,
  "created_at" : "2010-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ukvote",
      "indices" : [ 7, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13476124860",
  "text" : "Voted. #ukvote BT29",
  "id" : 13476124860,
  "created_at" : "2010-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13492644389",
  "geo" : { },
  "id_str" : "13492702986",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings ha ha ha. Is that what happened.. Thought you took it bad that I quit our video chat ;)",
  "id" : 13492702986,
  "in_reply_to_status_id" : 13492644389,
  "created_at" : "2010-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gay",
      "indices" : [ 38, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13508887153",
  "text" : "I want to start watching Howards Way. #gay",
  "id" : 13508887153,
  "created_at" : "2010-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Gorman",
      "screen_name" : "DaveGorman",
      "indices" : [ 0, 11 ],
      "id_str" : "19095849",
      "id" : 19095849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13510950453",
  "geo" : { },
  "id_str" : "13511176266",
  "in_reply_to_user_id" : 19095849,
  "text" : "@DaveGorman it's the annoying bit now for a few hours.",
  "id" : 13511176266,
  "in_reply_to_status_id" : 13510950453,
  "created_at" : "2010-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "DaveGorman",
  "in_reply_to_user_id_str" : "19095849",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13511225902",
  "text" : "Get rid of Dimbleby and put on Nick Robinson",
  "id" : 13511225902,
  "created_at" : "2010-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13512909217",
  "text" : "It looks like David Milliband has grown a moustache.",
  "id" : 13512909217,
  "created_at" : "2010-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13421738893",
  "geo" : { },
  "id_str" : "13422423305",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes there is nothing wrong with the tories :)",
  "id" : 13422423305,
  "in_reply_to_status_id" : 13421738893,
  "created_at" : "2010-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13422960204",
  "text" : "Hopefully finished with EMS and Access for a wee while now.. Now to find ma lovely terminal again. How I missed ye! :)",
  "id" : 13422960204,
  "created_at" : "2010-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13425560919",
  "geo" : { },
  "id_str" : "13425823858",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit  Nope. EMS - SQL Manager. Was  porting stuff from one source to another. Its a nice enough tool - I suppose.",
  "id" : 13425823858,
  "in_reply_to_status_id" : 13425560919,
  "created_at" : "2010-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "spacerevolver",
      "indices" : [ 0, 14 ],
      "id_str" : "252505225",
      "id" : 252505225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13426799275",
  "geo" : { },
  "id_str" : "13427170989",
  "in_reply_to_user_id" : 49953918,
  "text" : "@spacerevolver what is it?",
  "id" : 13427170989,
  "in_reply_to_status_id" : 13426799275,
  "created_at" : "2010-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "spacerevolver",
      "indices" : [ 0, 14 ],
      "id_str" : "252505225",
      "id" : 252505225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13428047364",
  "geo" : { },
  "id_str" : "13428218086",
  "in_reply_to_user_id" : 49953918,
  "text" : "@spacerevolver BNC something isn't it? Co-axial shiz.. iI am old",
  "id" : 13428218086,
  "in_reply_to_status_id" : 13428047364,
  "created_at" : "2010-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "spacerevolver",
      "indices" : [ 0, 14 ],
      "id_str" : "252505225",
      "id" : 252505225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13428625854",
  "geo" : { },
  "id_str" : "13428794563",
  "in_reply_to_user_id" : 49953918,
  "text" : "@spacerevolver that's the first time that i have ever had to use the knowledge that i got from 95-99.. Awesome :)",
  "id" : 13428794563,
  "in_reply_to_status_id" : 13428625854,
  "created_at" : "2010-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13356531813",
  "geo" : { },
  "id_str" : "13358004767",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes I was around there last night - only seen one poster with your current MP. I didn't notice any others.",
  "id" : 13358004767,
  "in_reply_to_status_id" : 13356531813,
  "created_at" : "2010-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13358030866",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes see - your area is mostly students which would be reg'd elsewhere to vote etc. So they don't waste the money. Its pathetic. Grr",
  "id" : 13358030866,
  "created_at" : "2010-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13358555244",
  "geo" : { },
  "id_str" : "13358585176",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne No!!!! Cos this programmer needs to go on holiday this time two weeks - so Thor or similar Norse fire god should behave :)",
  "id" : 13358585176,
  "in_reply_to_status_id" : 13358555244,
  "created_at" : "2010-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13361359793",
  "geo" : { },
  "id_str" : "13361770187",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes be funny to see them put those posters up around that area though.. And then when the natives see it - start the benny hill music",
  "id" : 13361770187,
  "in_reply_to_status_id" : 13361359793,
  "created_at" : "2010-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13361905522",
  "geo" : { },
  "id_str" : "13361986148",
  "in_reply_to_user_id" : 17864413,
  "text" : "@mnehughes politics is so bad here and tribal that I think it should all be set to Benny Hill Music. We need more Seamus Mallons about.",
  "id" : 13361986148,
  "in_reply_to_status_id" : 13361905522,
  "created_at" : "2010-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13365881740",
  "text" : "is slowly losing his patience with access, ems and windoze today. I need a fuckin terminal!",
  "id" : 13365881740,
  "created_at" : "2010-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13372502535",
  "geo" : { },
  "id_str" : "13373624039",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Salou with the mrs.. for a week. Can't wait. Just hold off for another two weeks! :)",
  "id" : 13373624039,
  "in_reply_to_status_id" : 13372502535,
  "created_at" : "2010-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13268290230",
  "geo" : { },
  "id_str" : "13292306936",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe the man is an ass. A windbag of the worst kind.",
  "id" : 13292306936,
  "in_reply_to_status_id" : 13268290230,
  "created_at" : "2010-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13239749740",
  "text" : "Jim Allister needs slapped.",
  "id" : 13239749740,
  "created_at" : "2010-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13239813641",
  "text" : "When did Parsley jump to the Unionists and Cons???",
  "id" : 13239813641,
  "created_at" : "2010-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13253533200",
  "text" : "Another dick head on Deal Or No Deal. I see a pattern emerging.",
  "id" : 13253533200,
  "created_at" : "2010-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]