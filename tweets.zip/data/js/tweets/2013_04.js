Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 3, 16 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/329235102720749569\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/xnsl9xveAL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJGtlOHCcAApQXf.png",
      "id_str" : "329235102729138176",
      "id" : 329235102729138176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJGtlOHCcAApQXf.png",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 860
      } ],
      "display_url" : "pic.twitter.com\/xnsl9xveAL"
    } ],
    "hashtags" : [ {
      "text" : "pulpfiction",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329235102720749569",
  "text" : "So @Paul_Moffett asked me what colour a parsnip was on iMessage - our version of Royale with Cheese #pulpfiction http:\/\/t.co\/xnsl9xveAL",
  "id" : 329235102720749569,
  "created_at" : "2013-04-30 14:05:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McGilloway",
      "screen_name" : "smg_3D",
      "indices" : [ 3, 10 ],
      "id_str" : "189154382",
      "id" : 189154382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329124485762519040",
  "text" : "RT @smg_3D: In our new all encompassing N.Ireland you can be whatever you want to be...unless of course it's that, we can't be having that.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dinosaurs",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328990371117924352",
    "text" : "In our new all encompassing N.Ireland you can be whatever you want to be...unless of course it's that, we can't be having that... #dinosaurs",
    "id" : 328990371117924352,
    "created_at" : "2013-04-29 21:53:11 +0000",
    "user" : {
      "name" : "Stephen McGilloway",
      "screen_name" : "smg_3D",
      "protected" : false,
      "id_str" : "189154382",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1738959960\/image_normal.jpg",
      "id" : 189154382,
      "verified" : false
    }
  },
  "id" : 329124485762519040,
  "created_at" : "2013-04-30 06:46:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328809685232807936",
  "text" : "Started using TomDoc for my documentation today - kinda nice\u2026 Miss pod though :(",
  "id" : 328809685232807936,
  "created_at" : "2013-04-29 09:55:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328511688573853696",
  "geo" : { },
  "id_str" : "328562801931083776",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl is that the on with Frank Sinatra at the end or is that the sequel?",
  "id" : 328562801931083776,
  "in_reply_to_status_id" : 328511688573853696,
  "created_at" : "2013-04-28 17:34:11 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Gilfelt",
      "screen_name" : "readyState",
      "indices" : [ 3, 14 ],
      "id_str" : "18104218",
      "id" : 18104218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328424978976473088",
  "text" : "RT @readyState: Developer job title cheat sheet: \n\nSenior = Old\nManager = Expendable\nArchitect = Can't code\nEvangelist = Can't ship",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327406604997758976",
    "text" : "Developer job title cheat sheet: \n\nSenior = Old\nManager = Expendable\nArchitect = Can't code\nEvangelist = Can't ship",
    "id" : 327406604997758976,
    "created_at" : "2013-04-25 12:59:52 +0000",
    "user" : {
      "name" : "Jeff Gilfelt",
      "screen_name" : "readyState",
      "protected" : false,
      "id_str" : "18104218",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3051505509\/7df76688bcfbe60726622d35d5313bd2_normal.jpeg",
      "id" : 18104218,
      "verified" : false
    }
  },
  "id" : 328424978976473088,
  "created_at" : "2013-04-28 08:26:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Neubauer",
      "screen_name" : "peterneubauer",
      "indices" : [ 3, 17 ],
      "id_str" : "14721805",
      "id" : 14721805
    }, {
      "name" : "alexey",
      "screen_name" : "sqlcook",
      "indices" : [ 44, 52 ],
      "id_str" : "90956869",
      "id" : 90956869
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "in",
      "indices" : [ 129, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/THMYxPxBX4",
      "expanded_url" : "https:\/\/github.com\/sqlcook\/Sublime-Neo4j",
      "display_url" : "github.com\/sqlcook\/Sublim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327813319127867393",
  "text" : "RT @peterneubauer: Now we are talking. With @sqlcook Sublime Cypher execution plugin, things get smooth! https:\/\/t.co\/THMYxPxBX4 #in http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "alexey",
        "screen_name" : "sqlcook",
        "indices" : [ 25, 33 ],
        "id_str" : "90956869",
        "id" : 90956869
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/peterneubauer\/status\/327755975622811649\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/kZLBqv0bX4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BIxsUsSCYAAgQJn.png",
        "id_str" : "327755975631200256",
        "id" : 327755975631200256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIxsUsSCYAAgQJn.png",
        "sizes" : [ {
          "h" : 911,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1274,
          "resize" : "fit",
          "w" : 1432
        } ],
        "display_url" : "pic.twitter.com\/kZLBqv0bX4"
      } ],
      "hashtags" : [ {
        "text" : "in",
        "indices" : [ 110, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/THMYxPxBX4",
        "expanded_url" : "https:\/\/github.com\/sqlcook\/Sublime-Neo4j",
        "display_url" : "github.com\/sqlcook\/Sublim\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "327755975622811649",
    "text" : "Now we are talking. With @sqlcook Sublime Cypher execution plugin, things get smooth! https:\/\/t.co\/THMYxPxBX4 #in http:\/\/t.co\/kZLBqv0bX4",
    "id" : 327755975622811649,
    "created_at" : "2013-04-26 12:08:08 +0000",
    "user" : {
      "name" : "Peter Neubauer",
      "screen_name" : "peterneubauer",
      "protected" : false,
      "id_str" : "14721805",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000529267759\/41cc29f7f7848ef5f452a43c7bd503b0_normal.png",
      "id" : 14721805,
      "verified" : false
    }
  },
  "id" : 327813319127867393,
  "created_at" : "2013-04-26 15:56:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notthatyouneeditcosyouarefuckingawesome",
      "indices" : [ 31, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327795393121366017",
  "geo" : { },
  "id_str" : "327802770142932994",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne good luck G :) #notthatyouneeditcosyouarefuckingawesome",
  "id" : 327802770142932994,
  "in_reply_to_status_id" : 327795393121366017,
  "created_at" : "2013-04-26 15:14:05 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327778392005029888",
  "text" : "I think I speak for the whole of Northern Ireland when I say this\u2026. \u201CWhat the fuck is up with that weather, was so nice this morning!\u201D",
  "id" : 327778392005029888,
  "created_at" : "2013-04-26 13:37:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 15, 28 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327715123475148800",
  "text" : "Taking note... @Paul_Moffett is only going to talk to me in one word answers\/questions now.. Sounds mature, wonder how long it will last ;)",
  "id" : 327715123475148800,
  "created_at" : "2013-04-26 09:25:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 51, 58 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327705127026839552",
  "text" : "And my work keys were on my desk as pointed out by @rejoco - yup - yesterday was a good productive work day - today might not be ;)",
  "id" : 327705127026839552,
  "created_at" : "2013-04-26 08:46:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327702710801547264",
  "text" : "So found my phone but also forgot my work keys and laptop charger\u2026 Lucky it is Friday.",
  "id" : 327702710801547264,
  "created_at" : "2013-04-26 08:36:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327543979828723714",
  "text" : "You know you've had a good day in the coal mines when you are lookin forward to work the next morning to build on what you've ben working on",
  "id" : 327543979828723714,
  "created_at" : "2013-04-25 22:05:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kate matsudaira",
      "screen_name" : "katemats",
      "indices" : [ 3, 12 ],
      "id_str" : "17173207",
      "id" : 17173207
    }, {
      "name" : "ian kennedy",
      "screen_name" : "iankennedy",
      "indices" : [ 124, 135 ],
      "id_str" : "12350",
      "id" : 12350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/0boFHXIGLC",
      "expanded_url" : "http:\/\/ow.ly\/kchUw",
      "display_url" : "ow.ly\/kchUw"
    } ]
  },
  "geo" : { },
  "id_str" : "327514611135946753",
  "text" : "RT @katemats: \"Every 90 days, wipe your roadmap clean.\" Lots of great Product Mgmt advice http:\/\/t.co\/0boFHXIGLC great post @iankennedy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ian kennedy",
        "screen_name" : "iankennedy",
        "indices" : [ 110, 121 ],
        "id_str" : "12350",
        "id" : 12350
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/0boFHXIGLC",
        "expanded_url" : "http:\/\/ow.ly\/kchUw",
        "display_url" : "ow.ly\/kchUw"
      } ]
    },
    "geo" : { },
    "id_str" : "327513780995100672",
    "text" : "\"Every 90 days, wipe your roadmap clean.\" Lots of great Product Mgmt advice http:\/\/t.co\/0boFHXIGLC great post @iankennedy",
    "id" : 327513780995100672,
    "created_at" : "2013-04-25 20:05:44 +0000",
    "user" : {
      "name" : "kate matsudaira",
      "screen_name" : "katemats",
      "protected" : false,
      "id_str" : "17173207",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1768986828\/image1327082013_normal.png",
      "id" : 17173207,
      "verified" : false
    }
  },
  "id" : 327514611135946753,
  "created_at" : "2013-04-25 20:09:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neverthoughtiwouldhearthatinasentence",
      "indices" : [ 51, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327499139912957952",
  "text" : "OH: \u201Cit's folklore with panda, ask him sometime\u201D - #neverthoughtiwouldhearthatinasentence",
  "id" : 327499139912957952,
  "created_at" : "2013-04-25 19:07:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Zimdars",
      "screen_name" : "JZ",
      "indices" : [ 3, 6 ],
      "id_str" : "896641",
      "id" : 896641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327480888726274048",
  "text" : "RT @JZ: Hacking debt: Without some time spent exploring and having fun, people become less effective and eventually burn out. http:\/\/t.co\/S\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/SMiIybzXMm",
        "expanded_url" : "http:\/\/www.johndcook.com\/blog\/2013\/04\/24\/hacking-debt\/",
        "display_url" : "johndcook.com\/blog\/2013\/04\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "327130649934848000",
    "text" : "Hacking debt: Without some time spent exploring and having fun, people become less effective and eventually burn out. http:\/\/t.co\/SMiIybzXMm",
    "id" : 327130649934848000,
    "created_at" : "2013-04-24 18:43:19 +0000",
    "user" : {
      "name" : "Jason Zimdars",
      "screen_name" : "JZ",
      "protected" : false,
      "id_str" : "896641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1849219872\/jz_monogram_blue_normal.png",
      "id" : 896641,
      "verified" : false
    }
  },
  "id" : 327480888726274048,
  "created_at" : "2013-04-25 17:55:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327470570096713728",
  "geo" : { },
  "id_str" : "327479529931145217",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I am a changed man Mike.. I know - it\u2019ll be good\u2026 Wear something slutty :)",
  "id" : 327479529931145217,
  "in_reply_to_status_id" : 327470570096713728,
  "created_at" : "2013-04-25 17:49:38 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/327453446905163776\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/vP4htKSSTt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BItZLM-CcAA27rx.png",
      "id_str" : "327453446909358080",
      "id" : 327453446909358080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BItZLM-CcAA27rx.png",
      "sizes" : [ {
        "h" : 15,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 20,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 9,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 20,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 20,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/vP4htKSSTt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327453446905163776",
  "text" : "Really good productive day and then this happens, think i'll head at 1730hrs cos this day can only get worse now. http:\/\/t.co\/vP4htKSSTt",
  "id" : 327453446905163776,
  "created_at" : "2013-04-25 16:06:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327438346370576384",
  "text" : "That warm fuzzy feeling when you see a system you are building starting to come together\u2026 Yeah.. That &lt;3",
  "id" : 327438346370576384,
  "created_at" : "2013-04-25 15:05:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327376388237697024",
  "geo" : { },
  "id_str" : "327378029900886016",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir I like it - you put it up without a README though so I went back this morning and was happy to see one. I think I'll start using it.",
  "id" : 327378029900886016,
  "in_reply_to_status_id" : 327376388237697024,
  "created_at" : "2013-04-25 11:06:19 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 9, 17 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 35, 49 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327355905270235139",
  "geo" : { },
  "id_str" : "327356234325954561",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @jbrevel I was talking to @jenporterhall about you last night and how much I missed ya ;) Ironman 3 soon sure ;)",
  "id" : 327356234325954561,
  "in_reply_to_status_id" : 327355905270235139,
  "created_at" : "2013-04-25 09:39:42 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 28, 36 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/327353610893656064\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/kCiC7BN6f8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIr-X-3CAAAfAZs.png",
      "id_str" : "327353610902044672",
      "id" : 327353610902044672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIr-X-3CAAAfAZs.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 926
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 926
      } ],
      "display_url" : "pic.twitter.com\/kCiC7BN6f8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327353610893656064",
  "text" : "Awwww the compassion I show @jbrevel.. Something beyond simple colleagues I think ;) http:\/\/t.co\/kCiC7BN6f8",
  "id" : 327353610893656064,
  "created_at" : "2013-04-25 09:29:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 4, 13 ],
      "id_str" : "95932190",
      "id" : 95932190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327085379817713664",
  "text" : "So\u2026 @brrygrdn just used this acronym to me in a talk session in all seriousness - USP\u2026 One more and he\u2019s getting blocked.",
  "id" : 327085379817713664,
  "created_at" : "2013-04-24 15:43:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 11, 19 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327076622861754371",
  "geo" : { },
  "id_str" : "327077162068885504",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @jbrevel just happy for the girl Stephen.. That\u2019s your mind! :)",
  "id" : 327077162068885504,
  "in_reply_to_status_id" : 327076622861754371,
  "created_at" : "2013-04-24 15:10:46 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 0, 9 ],
      "id_str" : "95932190",
      "id" : 95932190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327073423757045761",
  "geo" : { },
  "id_str" : "327073780348375041",
  "in_reply_to_user_id" : 95932190,
  "text" : "@brrygrdn lefty gets killed in that film\u2026 just saying ;)",
  "id" : 327073780348375041,
  "in_reply_to_status_id" : 327073423757045761,
  "created_at" : "2013-04-24 14:57:20 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 100, 109 ],
      "id_str" : "95932190",
      "id" : 95932190
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/327071115350528002\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/INzmi8Awj3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIn9ck9CUAMXur3.png",
      "id_str" : "327071115358916611",
      "id" : 327071115358916611,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIn9ck9CUAMXur3.png",
      "sizes" : [ {
        "h" : 223,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/INzmi8Awj3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327071115350528002",
  "text" : "FFS I was looking through Datamapper tweets and I see this sexy fuck in the mix.... Small world \/cc @brrygrdn http:\/\/t.co\/INzmi8Awj3",
  "id" : 327071115350528002,
  "created_at" : "2013-04-24 14:46:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327057403847778304",
  "text" : "\/me steps away from the keyboard for 10mins - hopefully the solution to the problem will become evident when I look at it again\u2026.",
  "id" : 327057403847778304,
  "created_at" : "2013-04-24 13:52:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Datamapper",
      "screen_name" : "datamapper",
      "indices" : [ 5, 16 ],
      "id_str" : "14695193",
      "id" : 14695193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327057170136956928",
  "text" : "Ahhh @datamapper you are really hurting my head today\u2026 Maybe its just one of those days and I am unfair\u2026 Probably am being unfair...",
  "id" : 327057170136956928,
  "created_at" : "2013-04-24 13:51:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Marshall",
      "screen_name" : "flowchainsensei",
      "indices" : [ 3, 19 ],
      "id_str" : "42469463",
      "id" : 42469463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/3Q6pDz1rSD",
      "expanded_url" : "http:\/\/www.leanblog.org\/2011\/04\/podcast-117-samuel-a-culbert-get-rid-of-the-performance-review\/",
      "display_url" : "leanblog.org\/2011\/04\/podcas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327056762882621441",
  "text" : "RT @flowchainsensei: \u201CPerformance reviews are the biggest load of bullshit in management today.\u201D http:\/\/t.co\/3Q6pDz1rSD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/3Q6pDz1rSD",
        "expanded_url" : "http:\/\/www.leanblog.org\/2011\/04\/podcast-117-samuel-a-culbert-get-rid-of-the-performance-review\/",
        "display_url" : "leanblog.org\/2011\/04\/podcas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "326939992763015168",
    "text" : "\u201CPerformance reviews are the biggest load of bullshit in management today.\u201D http:\/\/t.co\/3Q6pDz1rSD",
    "id" : 326939992763015168,
    "created_at" : "2013-04-24 06:05:43 +0000",
    "user" : {
      "name" : "Bob Marshall",
      "screen_name" : "flowchainsensei",
      "protected" : false,
      "id_str" : "42469463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1900744429\/_U7S3252-2_normal.jpg",
      "id" : 42469463,
      "verified" : false
    }
  },
  "id" : 327056762882621441,
  "created_at" : "2013-04-24 13:49:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 0, 8 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327055015015510016",
  "geo" : { },
  "id_str" : "327056718955683840",
  "in_reply_to_user_id" : 120378343,
  "text" : "@kouphax I really enjoyed the last few\u2026 so get to it ;)",
  "id" : 327056718955683840,
  "in_reply_to_status_id" : 327055015015510016,
  "created_at" : "2013-04-24 13:49:32 +0000",
  "in_reply_to_screen_name" : "kouphax",
  "in_reply_to_user_id_str" : "120378343",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Binary Dad",
      "screen_name" : "BinaryDad",
      "indices" : [ 3, 13 ],
      "id_str" : "1464028430",
      "id" : 1464028430
    }, {
      "name" : "Rex Hammock",
      "screen_name" : "R",
      "indices" : [ 137, 139 ],
      "id_str" : "146733",
      "id" : 146733
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AngryShopMan\/status\/326989098659233794\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/KEoBDnWznx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BImy2k9CQAA9fIP.jpg",
      "id_str" : "326989098663428096",
      "id" : 326989098663428096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BImy2k9CQAA9fIP.jpg",
      "sizes" : [ {
        "h" : 527,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 304,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 590
      } ],
      "display_url" : "pic.twitter.com\/KEoBDnWznx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327007503021912064",
  "text" : "RT @BinaryDad: We\u2019ve managed to get a robot to draw a cock on Mars. Possibly mankind\u2019s greatest achievement. http:\/\/t.co\/KEoBDnWznx (via @r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "the reddit alien",
        "screen_name" : "reddit",
        "indices" : [ 122, 129 ],
        "id_str" : "811377",
        "id" : 811377
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AngryShopMan\/status\/326989098659233794\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/KEoBDnWznx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BImy2k9CQAA9fIP.jpg",
        "id_str" : "326989098663428096",
        "id" : 326989098663428096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BImy2k9CQAA9fIP.jpg",
        "sizes" : [ {
          "h" : 527,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 304,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 590
        } ],
        "display_url" : "pic.twitter.com\/KEoBDnWznx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327004875256909824",
    "text" : "We\u2019ve managed to get a robot to draw a cock on Mars. Possibly mankind\u2019s greatest achievement. http:\/\/t.co\/KEoBDnWznx (via @reddit)",
    "id" : 327004875256909824,
    "created_at" : "2013-04-24 10:23:32 +0000",
    "user" : {
      "name" : "BinaryBad",
      "screen_name" : "BinaryBad",
      "protected" : false,
      "id_str" : "16849521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000461069889\/27caf38a0935f6c6df24b0810abddfb2_normal.jpeg",
      "id" : 16849521,
      "verified" : false
    }
  },
  "id" : 327007503021912064,
  "created_at" : "2013-04-24 10:33:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pigsflying",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "firsttimeever",
      "indices" : [ 57, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326969382402154496",
  "text" : "Holy feck - I'm in (just) *before* nine!!!!! #pigsflying #firsttimeever",
  "id" : 326969382402154496,
  "created_at" : "2013-04-24 08:02:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326766793437888512",
  "text" : "Calling it a night and leaving my laptop on my desk - cos I'm a rebel :)",
  "id" : 326766793437888512,
  "created_at" : "2013-04-23 18:37:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326753296427646976",
  "geo" : { },
  "id_str" : "326753678998523904",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell same here - but sometimes it\u2019d make sense. If I was starting my own startup I\u2019d def go PaaS. But it does make you lazy :(",
  "id" : 326753678998523904,
  "in_reply_to_status_id" : 326753296427646976,
  "created_at" : "2013-04-23 17:45:22 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326752737792512000",
  "geo" : { },
  "id_str" : "326753157822689281",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell cheers just me blabbing on about stuffs...",
  "id" : 326753157822689281,
  "in_reply_to_status_id" : 326752737792512000,
  "created_at" : "2013-04-23 17:43:18 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/wG1nQ174Xx",
      "expanded_url" : "http:\/\/blog.swm.cc\/2013\/04\/23\/below-your-feet\/",
      "display_url" : "blog.swm.cc\/2013\/04\/23\/bel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326751786968944641",
  "text" : "Developers should know what\u2019s beneath their feet\u2026 http:\/\/t.co\/wG1nQ174Xx",
  "id" : 326751786968944641,
  "created_at" : "2013-04-23 17:37:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 11, 19 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326747863243702272",
  "geo" : { },
  "id_str" : "326748336159850496",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @kouphax you get \u201Cnothing\u201D for effort in this world..",
  "id" : 326748336159850496,
  "in_reply_to_status_id" : 326747863243702272,
  "created_at" : "2013-04-23 17:24:08 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 11, 19 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326747863243702272",
  "geo" : { },
  "id_str" : "326748274583289856",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @kouphax you reward kids for doing something right or good. This is real work - where results are the only thing that matters.",
  "id" : 326748274583289856,
  "in_reply_to_status_id" : 326747863243702272,
  "created_at" : "2013-04-23 17:23:54 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 11, 19 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326747863243702272",
  "geo" : { },
  "id_str" : "326748189157912576",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @kouphax but not at the expense of actual experince. Just shows you can pass exams. And rewarded would be the  wrong word\u2026",
  "id" : 326748189157912576,
  "in_reply_to_status_id" : 326747863243702272,
  "created_at" : "2013-04-23 17:23:33 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 0, 8 ],
      "id_str" : "120378343",
      "id" : 120378343
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 9, 19 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/xrYtKmEylH",
      "expanded_url" : "http:\/\/blog.swm.cc\/2013\/04\/02\/qualifications\/",
      "display_url" : "blog.swm.cc\/2013\/04\/02\/qua\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "326747089872752641",
  "geo" : { },
  "id_str" : "326747317443104768",
  "in_reply_to_user_id" : 120378343,
  "text" : "@kouphax @smccalden My thoughts on it are pretty clear - http:\/\/t.co\/xrYtKmEylH :)",
  "id" : 326747317443104768,
  "in_reply_to_status_id" : 326747089872752641,
  "created_at" : "2013-04-23 17:20:05 +0000",
  "in_reply_to_screen_name" : "kouphax",
  "in_reply_to_user_id_str" : "120378343",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 11, 19 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326746827523239936",
  "geo" : { },
  "id_str" : "326747114208120832",
  "in_reply_to_user_id" : 804717,
  "text" : "@smccalden @kouphax very much depends on the person and the company culture. Every situation is different.",
  "id" : 326747114208120832,
  "in_reply_to_status_id" : 326746827523239936,
  "created_at" : "2013-04-23 17:19:17 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 11, 19 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326746468968968192",
  "geo" : { },
  "id_str" : "326746827523239936",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @kouphax \u2026in IT without having to get to degree level.",
  "id" : 326746827523239936,
  "in_reply_to_status_id" : 326746468968968192,
  "created_at" : "2013-04-23 17:18:09 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 11, 19 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326746468968968192",
  "geo" : { },
  "id_str" : "326746772775006209",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @kouphax blindly saying that a degree gives an edge is not very fair - as is disregarding it. However you can be educated...",
  "id" : 326746772775006209,
  "in_reply_to_status_id" : 326746468968968192,
  "created_at" : "2013-04-23 17:17:55 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 0, 8 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326742825033138177",
  "geo" : { },
  "id_str" : "326743205842391040",
  "in_reply_to_user_id" : 120378343,
  "text" : "@kouphax for me anyway\u2026",
  "id" : 326743205842391040,
  "in_reply_to_status_id" : 326742825033138177,
  "created_at" : "2013-04-23 17:03:45 +0000",
  "in_reply_to_screen_name" : "kouphax",
  "in_reply_to_user_id_str" : "120378343",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 0, 8 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326742825033138177",
  "geo" : { },
  "id_str" : "326743117321621504",
  "in_reply_to_user_id" : 120378343,
  "text" : "@kouphax Depends on the company in question and the dev I suppose. I don\u2019t rate degrees though, they are useful but not really a barometer",
  "id" : 326743117321621504,
  "in_reply_to_status_id" : 326742825033138177,
  "created_at" : "2013-04-23 17:03:24 +0000",
  "in_reply_to_screen_name" : "kouphax",
  "in_reply_to_user_id_str" : "120378343",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 0, 8 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326742262639915010",
  "geo" : { },
  "id_str" : "326742469532332032",
  "in_reply_to_user_id" : 120378343,
  "text" : "@kouphax then it depends on company culture and who is the better fit I suppose. YMMV on that though.",
  "id" : 326742469532332032,
  "in_reply_to_status_id" : 326742262639915010,
  "created_at" : "2013-04-23 17:00:49 +0000",
  "in_reply_to_screen_name" : "kouphax",
  "in_reply_to_user_id_str" : "120378343",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hughes",
      "screen_name" : "kouphax",
      "indices" : [ 0, 8 ],
      "id_str" : "120378343",
      "id" : 120378343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326740706725089281",
  "geo" : { },
  "id_str" : "326741998868500485",
  "in_reply_to_user_id" : 120378343,
  "text" : "@kouphax would depend on the experience IMO. You can have 5 years doing the same thing v 5 years doing different things. No real yard stick.",
  "id" : 326741998868500485,
  "in_reply_to_status_id" : 326740706725089281,
  "created_at" : "2013-04-23 16:58:57 +0000",
  "in_reply_to_screen_name" : "kouphax",
  "in_reply_to_user_id_str" : "120378343",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 61, 69 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wankers",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326725627946356737",
  "text" : "Well me going off Facebook lasted all of an hour.. I need my @spotify account and its too much hassle to move\u2026 FB 1 - swmcc 0 #wankers",
  "id" : 326725627946356737,
  "created_at" : "2013-04-23 15:53:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 3, 16 ],
      "id_str" : "162449244",
      "id" : 162449244
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 25, 33 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326711945753403392",
  "text" : "RT @justinMleary: @swmcc @jbrevel Stevie you're very special.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "John Loughrey",
        "screen_name" : "jbrevel",
        "indices" : [ 7, 15 ],
        "id_str" : "50685221",
        "id" : 50685221
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "326711279681163264",
    "geo" : { },
    "id_str" : "326711740081520642",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @jbrevel Stevie you're very special.",
    "id" : 326711740081520642,
    "in_reply_to_status_id" : 326711279681163264,
    "created_at" : "2013-04-23 14:58:43 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "protected" : false,
      "id_str" : "162449244",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3067943105\/193e650a1585564fabb5fd9982852d33_normal.jpeg",
      "id" : 162449244,
      "verified" : false
    }
  },
  "id" : 326711945753403392,
  "created_at" : "2013-04-23 14:59:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 9, 22 ],
      "id_str" : "162449244",
      "id" : 162449244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326710553928142849",
  "geo" : { },
  "id_str" : "326711279681163264",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @justinMleary You think I am a specialist? Really? :D :D :D Awesome.. I want a badge!",
  "id" : 326711279681163264,
  "in_reply_to_status_id" : 326710553928142849,
  "created_at" : "2013-04-23 14:56:53 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Leary",
      "screen_name" : "justinMleary",
      "indices" : [ 0, 13 ],
      "id_str" : "162449244",
      "id" : 162449244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326708646346117120",
  "geo" : { },
  "id_str" : "326708994477539328",
  "in_reply_to_user_id" : 162449244,
  "text" : "@justinMleary I found myself during my mini breaks faffing about on it. So got rid - feels good man - DO IT DO IT DO IT :)",
  "id" : 326708994477539328,
  "in_reply_to_status_id" : 326708646346117120,
  "created_at" : "2013-04-23 14:47:48 +0000",
  "in_reply_to_screen_name" : "justinMleary",
  "in_reply_to_user_id_str" : "162449244",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/326708257144049664\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/6UgXzv2lcj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIizbcyCEAAWFWg.png",
      "id_str" : "326708257148243968",
      "id" : 326708257148243968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIizbcyCEAAWFWg.png",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 775
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 775
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6UgXzv2lcj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326708257144049664",
  "text" : "Wonder how long it will last this time? :) http:\/\/t.co\/6UgXzv2lcj",
  "id" : 326708257144049664,
  "created_at" : "2013-04-23 14:44:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/JWfFqMW1PB",
      "expanded_url" : "http:\/\/nic.ferrier.me.uk\/blog\/2013_04\/swearing-at-work",
      "display_url" : "nic.ferrier.me.uk\/blog\/2013_04\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326676680800346113",
  "text" : "Swearing at work.. http:\/\/t.co\/JWfFqMW1PB - I swear all the time, it is bad - but I couldn't really give a fuck - my work is good so fuck it",
  "id" : 326676680800346113,
  "created_at" : "2013-04-23 12:39:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 0, 9 ],
      "id_str" : "95932190",
      "id" : 95932190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326437374445899776",
  "geo" : { },
  "id_str" : "326444622610038784",
  "in_reply_to_user_id" : 95932190,
  "text" : "@brrygrdn fuck me, you aren't half clearing out old shit today :)",
  "id" : 326444622610038784,
  "in_reply_to_status_id" : 326437374445899776,
  "created_at" : "2013-04-22 21:17:17 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CambridgeIntel",
      "screen_name" : "CambridgeIntel",
      "indices" : [ 76, 91 ],
      "id_str" : "284043659",
      "id" : 284043659
    }, {
      "name" : "Neo4j",
      "screen_name" : "neo4j",
      "indices" : [ 119, 125 ],
      "id_str" : "22467617",
      "id" : 22467617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/2q2xpu0OOz",
      "expanded_url" : "http:\/\/info.neotechnology.com\/0425-register.html",
      "display_url" : "info.neotechnology.com\/0425-register.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326412240234360832",
  "text" : "Just registered for Visualizing Fraud Data with Cambridge Intelligence with @CambridgeIntel http:\/\/t.co\/2q2xpu0OOz via @neo4j",
  "id" : 326412240234360832,
  "created_at" : "2013-04-22 19:08:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 14, 22 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326341638542733313",
  "geo" : { },
  "id_str" : "326345317807185920",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @HaVoCT5 hang on - both? I thought it was only once?",
  "id" : 326345317807185920,
  "in_reply_to_status_id" : 326341638542733313,
  "created_at" : "2013-04-22 14:42:41 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/F4lO3ZEcls",
      "expanded_url" : "http:\/\/www.investni.com\/about-news.htm?newsid=18009",
      "display_url" : "investni.com\/about-news.htm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326344712975949824",
  "text" : "http:\/\/t.co\/F4lO3ZEcls where I work... That be Repknight not INI.",
  "id" : 326344712975949824,
  "created_at" : "2013-04-22 14:40:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 14, 22 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326341638542733313",
  "geo" : { },
  "id_str" : "326342095768014848",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @HaVoCT5 still hurts you bastard.",
  "id" : 326342095768014848,
  "in_reply_to_status_id" : 326341638542733313,
  "created_at" : "2013-04-22 14:29:53 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326321445963710464",
  "geo" : { },
  "id_str" : "326322119451504640",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin recursive loop found\u2026 ctrl + c\u2026 ctrl +c...",
  "id" : 326322119451504640,
  "in_reply_to_status_id" : 326321445963710464,
  "created_at" : "2013-04-22 13:10:30 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Refresh Belfast",
      "screen_name" : "refreshbelfast",
      "indices" : [ 25, 40 ],
      "id_str" : "20080166",
      "id" : 20080166
    }, {
      "name" : "Neo4j",
      "screen_name" : "neo4j",
      "indices" : [ 59, 65 ],
      "id_str" : "22467617",
      "id" : 22467617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326311708450762752",
  "text" : "Hmmmm dunno what to do.. @refreshbelfast or the webinar on @neo4j - hmmmmmm\u2026\u2026..",
  "id" : 326311708450762752,
  "created_at" : "2013-04-22 12:29:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 14, 22 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326299826499252224",
  "geo" : { },
  "id_str" : "326305287374004224",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @HaVoCT5 I guess that is worse than going to \u2018build a burger\u2019 - that still hurts after all this time.. bastard!",
  "id" : 326305287374004224,
  "in_reply_to_status_id" : 326299826499252224,
  "created_at" : "2013-04-22 12:03:37 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipsters",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/CyIhkWrphY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0X6APGN1cAs",
      "display_url" : "youtube.com\/watch?v=0X6APG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326304003442999298",
  "text" : "http:\/\/t.co\/CyIhkWrphY - #hipsters",
  "id" : 326304003442999298,
  "created_at" : "2013-04-22 11:58:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iA Writer",
      "screen_name" : "iAWriter",
      "indices" : [ 14, 23 ],
      "id_str" : "203008363",
      "id" : 203008363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326265691181293568",
  "text" : "Started using @iawriter today for my TODO\u2019s and stuff\u2026 Have to say - am loving it so far.",
  "id" : 326265691181293568,
  "created_at" : "2013-04-22 09:26:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neo4j",
      "screen_name" : "neo4j",
      "indices" : [ 74, 80 ],
      "id_str" : "22467617",
      "id" : 22467617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/fSdDch0rfe",
      "expanded_url" : "http:\/\/docs.neo4j.org\/chunked\/milestone\/cypher-query-lang.html",
      "display_url" : "docs.neo4j.org\/chunked\/milest\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "325925633681133568",
  "text" : "RT @ST2PkgControl: New in Package Control: Cypher adds syntax support for @neo4j\u2019s Cypher query language (http:\/\/t.co\/fSdDch0rfe). https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neo4j",
        "screen_name" : "neo4j",
        "indices" : [ 55, 61 ],
        "id_str" : "22467617",
        "id" : 22467617
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/fSdDch0rfe",
        "expanded_url" : "http:\/\/docs.neo4j.org\/chunked\/milestone\/cypher-query-lang.html",
        "display_url" : "docs.neo4j.org\/chunked\/milest\u2026"
      }, {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/AHqni9Q8O9",
        "expanded_url" : "https:\/\/github.com\/kollhof\/sublime-cypher",
        "display_url" : "github.com\/kollhof\/sublim\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "325789361574649858",
    "text" : "New in Package Control: Cypher adds syntax support for @neo4j\u2019s Cypher query language (http:\/\/t.co\/fSdDch0rfe). https:\/\/t.co\/AHqni9Q8O9",
    "id" : 325789361574649858,
    "created_at" : "2013-04-21 01:53:31 +0000",
    "user" : {
      "name" : "Package Control",
      "screen_name" : "Package_Control",
      "protected" : false,
      "id_str" : "916716914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2788600590\/e99d6e85dacb9d873937ac80c1cb13aa_normal.png",
      "id" : 916716914,
      "verified" : false
    }
  },
  "id" : 325925633681133568,
  "created_at" : "2013-04-21 10:55:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/325894276250746880\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/LXdgRRTaSK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIXPHhrCQAAiy0J.jpg",
      "id_str" : "325894276259135488",
      "id" : 325894276259135488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIXPHhrCQAAiy0J.jpg",
      "sizes" : [ {
        "h" : 444,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LXdgRRTaSK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325894276250746880",
  "text" : "\u2026.. and now I\u2019m back up to date\u2026 Managing your own server is a pain.. http:\/\/t.co\/LXdgRRTaSK",
  "id" : 325894276250746880,
  "created_at" : "2013-04-21 08:50:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/325893941385900033\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/509l79u3c8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIXO0CMCMAEtRrN.jpg",
      "id_str" : "325893941390094337",
      "id" : 325893941390094337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIXO0CMCMAEtRrN.jpg",
      "sizes" : [ {
        "h" : 51,
        "resize" : "fit",
        "w" : 154
      }, {
        "h" : 51,
        "resize" : "fit",
        "w" : 154
      }, {
        "h" : 51,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 51,
        "resize" : "fit",
        "w" : 154
      }, {
        "h" : 51,
        "resize" : "fit",
        "w" : 154
      } ],
      "display_url" : "pic.twitter.com\/509l79u3c8"
    } ],
    "hashtags" : [ {
      "text" : "node",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325893941385900033",
  "text" : "You wouldn\u2019t half know I\u2019ve been using PaaS a good bit recently\u2026. #node.js http:\/\/t.co\/509l79u3c8",
  "id" : 325893941385900033,
  "created_at" : "2013-04-21 08:49:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325715778873720832",
  "geo" : { },
  "id_str" : "325731437372387328",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl it\u2019s now official. You sir\u2026 you are a knob :)",
  "id" : 325731437372387328,
  "in_reply_to_status_id" : 325715778873720832,
  "created_at" : "2013-04-20 22:03:21 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bearealman",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325698389373251584",
  "geo" : { },
  "id_str" : "325715337188356096",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl cheers. Lets stop this \u201Cmoving forward\u201D talk :) And while we are at it lets get rid of that decaf shite you drink. #bearealman",
  "id" : 325715337188356096,
  "in_reply_to_status_id" : 325698389373251584,
  "created_at" : "2013-04-20 20:59:22 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saturdayeveningshizness",
      "indices" : [ 75, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325658549554384896",
  "text" : "Dr Who and some of spaghetti bolognese - awwwwwww fuck it - if you insist! #saturdayeveningshizness",
  "id" : 325658549554384896,
  "created_at" : "2013-04-20 17:13:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 3, 10 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 12, 18 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 62, 75 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rejoco\/status\/325592078996340737\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/W7bKKRpRPG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIS8RVKCAAAymee.jpg",
      "id_str" : "325592079000535040",
      "id" : 325592079000535040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIS8RVKCAAAymee.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/W7bKKRpRPG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325595667621883904",
  "text" : "RT @rejoco: @swmcc different shoes you reckon? do it right cc @nicholabates http:\/\/t.co\/W7bKKRpRPG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "Nichola Bates",
        "screen_name" : "nicholabates",
        "indices" : [ 50, 63 ],
        "id_str" : "19125494",
        "id" : 19125494
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rejoco\/status\/325592078996340737\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/W7bKKRpRPG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BIS8RVKCAAAymee.jpg",
        "id_str" : "325592079000535040",
        "id" : 325592079000535040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIS8RVKCAAAymee.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/W7bKKRpRPG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325592078996340737",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc different shoes you reckon? do it right cc @nicholabates http:\/\/t.co\/W7bKKRpRPG",
    "id" : 325592078996340737,
    "created_at" : "2013-04-20 12:49:35 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "protected" : false,
      "id_str" : "53053999",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000167317834\/6219cabb0a7785ac8acd656a39be2ab9_normal.jpeg",
      "id" : 53053999,
      "verified" : false
    }
  },
  "id" : 325595667621883904,
  "created_at" : "2013-04-20 13:03:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 8, 21 ],
      "id_str" : "19125494",
      "id" : 19125494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325592078996340737",
  "geo" : { },
  "id_str" : "325592610674712576",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco @nicholabates Told ya.. I AM A TREND. SETTER. :D :D Good work JR :)",
  "id" : 325592610674712576,
  "in_reply_to_status_id" : 325592078996340737,
  "created_at" : "2013-04-20 12:51:42 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/325542730497413120\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/U6A52QooMP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BISPY3sCUAApWvL.png",
      "id_str" : "325542730505801728",
      "id" : 325542730505801728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BISPY3sCUAApWvL.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/U6A52QooMP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325542730497413120",
  "text" : "See I can be the good son now and again. Mum is now out of hospital and I'm being nice! :) http:\/\/t.co\/U6A52QooMP",
  "id" : 325542730497413120,
  "created_at" : "2013-04-20 09:33:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 0, 7 ],
      "id_str" : "17843859",
      "id" : 17843859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325525102877884416",
  "geo" : { },
  "id_str" : "325540282026315777",
  "in_reply_to_user_id" : 17843859,
  "text" : "@rtweed thanks for this link :)",
  "id" : 325540282026315777,
  "in_reply_to_status_id" : 325525102877884416,
  "created_at" : "2013-04-20 09:23:46 +0000",
  "in_reply_to_screen_name" : "rtweed",
  "in_reply_to_user_id_str" : "17843859",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325186077780492288",
  "text" : "I just used the words \u201Cmoving forward\u201D in an email. I feel sick.",
  "id" : 325186077780492288,
  "created_at" : "2013-04-19 09:56:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324527968149979136",
  "text" : "New personal low\u2026 I came into work with two different pairs of shoes on\u2026 Seriously - I dunno how the fuck I function sometimes!",
  "id" : 324527968149979136,
  "created_at" : "2013-04-17 14:21:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AirPOS",
      "screen_name" : "AirPOS",
      "indices" : [ 32, 39 ],
      "id_str" : "53896598",
      "id" : 53896598
    }, {
      "name" : "Learning Pool",
      "screen_name" : "LearningPool",
      "indices" : [ 42, 55 ],
      "id_str" : "20369549",
      "id" : 20369549
    }, {
      "name" : "Hubb.it",
      "screen_name" : "didyouhubbit",
      "indices" : [ 58, 71 ],
      "id_str" : "388854961",
      "id" : 388854961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/aq99PaahEa",
      "expanded_url" : "http:\/\/wp.me\/p3bKqw-84",
      "display_url" : "wp.me\/p3bKqw-84"
    } ]
  },
  "geo" : { },
  "id_str" : "324514886778494977",
  "text" : "RT @jasebell: Be the ecosystem (@airpos \/ @learningpool \/ @didyouhubbit) http:\/\/t.co\/aq99PaahEa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AirPOS",
        "screen_name" : "AirPOS",
        "indices" : [ 18, 25 ],
        "id_str" : "53896598",
        "id" : 53896598
      }, {
        "name" : "Learning Pool",
        "screen_name" : "LearningPool",
        "indices" : [ 28, 41 ],
        "id_str" : "20369549",
        "id" : 20369549
      }, {
        "name" : "Hubb.it",
        "screen_name" : "didyouhubbit",
        "indices" : [ 44, 57 ],
        "id_str" : "388854961",
        "id" : 388854961
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/aq99PaahEa",
        "expanded_url" : "http:\/\/wp.me\/p3bKqw-84",
        "display_url" : "wp.me\/p3bKqw-84"
      } ]
    },
    "geo" : { },
    "id_str" : "324506176081506305",
    "text" : "Be the ecosystem (@airpos \/ @learningpool \/ @didyouhubbit) http:\/\/t.co\/aq99PaahEa",
    "id" : 324506176081506305,
    "created_at" : "2013-04-17 12:54:36 +0000",
    "user" : {
      "name" : "Jase Bell",
      "screen_name" : "hadooping",
      "protected" : false,
      "id_str" : "1248789104",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000600719719\/1f076e9f2650e4ea1930f33a7fbd28de_normal.jpeg",
      "id" : 1248789104,
      "verified" : false
    }
  },
  "id" : 324514886778494977,
  "created_at" : "2013-04-17 13:29:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AirPOS",
      "screen_name" : "AirPOS",
      "indices" : [ 10, 17 ],
      "id_str" : "53896598",
      "id" : 53896598
    }, {
      "name" : "Learning Pool",
      "screen_name" : "LearningPool",
      "indices" : [ 18, 31 ],
      "id_str" : "20369549",
      "id" : 20369549
    }, {
      "name" : "Hubb.it",
      "screen_name" : "didyouhubbit",
      "indices" : [ 32, 45 ],
      "id_str" : "388854961",
      "id" : 388854961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324506176081506305",
  "geo" : { },
  "id_str" : "324514873444823041",
  "in_reply_to_user_id" : 1248789104,
  "text" : "@jasebell @AirPOS @LearningPool @didyouhubbit like that blog post :)",
  "id" : 324514873444823041,
  "in_reply_to_status_id" : 324506176081506305,
  "created_at" : "2013-04-17 13:29:09 +0000",
  "in_reply_to_screen_name" : "hadooping",
  "in_reply_to_user_id_str" : "1248789104",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Translink",
      "screen_name" : "Translink_NI",
      "indices" : [ 0, 13 ],
      "id_str" : "118677636",
      "id" : 118677636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324483243732779008",
  "geo" : { },
  "id_str" : "324491499637202945",
  "in_reply_to_user_id" : 118677636,
  "text" : "@Translink_NI thanks very much. Much appreciated.",
  "id" : 324491499637202945,
  "in_reply_to_status_id" : 324483243732779008,
  "created_at" : "2013-04-17 11:56:16 +0000",
  "in_reply_to_screen_name" : "Translink_NI",
  "in_reply_to_user_id_str" : "118677636",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Translink",
      "screen_name" : "Translink_NI",
      "indices" : [ 3, 16 ],
      "id_str" : "118677636",
      "id" : 118677636
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324491455219515393",
  "text" : "RT @Translink_NI: @swmcc Ulsterbus service 106 departs Glenavy at 0735hrs arriving in Belfast at 0820hrs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "324482153008209920",
    "geo" : { },
    "id_str" : "324483243732779008",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Ulsterbus service 106 departs Glenavy at 0735hrs arriving in Belfast at 0820hrs",
    "id" : 324483243732779008,
    "in_reply_to_status_id" : 324482153008209920,
    "created_at" : "2013-04-17 11:23:28 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Translink",
      "screen_name" : "Translink_NI",
      "protected" : false,
      "id_str" : "118677636",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3287287840\/784ad387ced7c2047e44cf87351743ac_normal.png",
      "id" : 118677636,
      "verified" : false
    }
  },
  "id" : 324491455219515393,
  "created_at" : "2013-04-17 11:56:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Translink",
      "screen_name" : "Translink_NI",
      "indices" : [ 0, 13 ],
      "id_str" : "118677636",
      "id" : 118677636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324481348595224576",
  "geo" : { },
  "id_str" : "324482153008209920",
  "in_reply_to_user_id" : 118677636,
  "text" : "@Translink_NI Glenavy to Belfast - have to be in Belfast by 8:30am. Thanks for getting back to me.",
  "id" : 324482153008209920,
  "in_reply_to_status_id" : 324481348595224576,
  "created_at" : "2013-04-17 11:19:08 +0000",
  "in_reply_to_screen_name" : "Translink_NI",
  "in_reply_to_user_id_str" : "118677636",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324472659977064448",
  "geo" : { },
  "id_str" : "324473018069966848",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin new toys mean nothing if its not a pole position desk. I never sacrifice toys for actual position. Am sure you don\u2019t either.",
  "id" : 324473018069966848,
  "in_reply_to_status_id" : 324472659977064448,
  "created_at" : "2013-04-17 10:42:50 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 3, 13 ],
      "id_str" : "7311162",
      "id" : 7311162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324471493121699841",
  "text" : "RT @mharrigan: Mental note: When surrounded by Linux fanatics bitching about Windows throw in Centos vs Debian and watch the fireworks. :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "324470947069440000",
    "text" : "Mental note: When surrounded by Linux fanatics bitching about Windows throw in Centos vs Debian and watch the fireworks. :)",
    "id" : 324470947069440000,
    "created_at" : "2013-04-17 10:34:36 +0000",
    "user" : {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "protected" : false,
      "id_str" : "7311162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1244027252\/49305_703667370_6415415_q_normal.jpg",
      "id" : 7311162,
      "verified" : false
    }
  },
  "id" : 324471493121699841,
  "created_at" : "2013-04-17 10:36:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 0, 9 ],
      "id_str" : "20543444",
      "id" : 20543444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324468244868116480",
  "geo" : { },
  "id_str" : "324471401803292672",
  "in_reply_to_user_id" : 20543444,
  "text" : "@HerrWulf good call I will do that. However i think if I get the 7:30am one I'll get in on time. Still mad though! :)",
  "id" : 324471401803292672,
  "in_reply_to_status_id" : 324468244868116480,
  "created_at" : "2013-04-17 10:36:25 +0000",
  "in_reply_to_screen_name" : "HerrWulf",
  "in_reply_to_user_id_str" : "20543444",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Translink",
      "screen_name" : "Translink_NI",
      "indices" : [ 1, 14 ],
      "id_str" : "118677636",
      "id" : 118677636
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/324460897152147456\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/XJ5ahMAR27",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIC3d4bCIAAk84n.png",
      "id_str" : "324460897160536064",
      "id" : 324460897160536064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIC3d4bCIAAk84n.png",
      "sizes" : [ {
        "h" : 860,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 528,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 860,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 860,
        "resize" : "fit",
        "w" : 554
      } ],
      "display_url" : "pic.twitter.com\/XJ5ahMAR27"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324460897152147456",
  "text" : ".@Translink_NI I have to be in Belfast 2moro for 8:30am. I've tried using your site but it makes no sense. Pls help! http:\/\/t.co\/XJ5ahMAR27",
  "id" : 324460897152147456,
  "created_at" : "2013-04-17 09:54:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Translink",
      "screen_name" : "Translink_NI",
      "indices" : [ 104, 117 ],
      "id_str" : "118677636",
      "id" : 118677636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324460291024904192",
  "text" : "Working in Belfast tomorrow to save any hassle I'm gonna bus it. I consider myself educated but by fuck @Translink_NI your site isn't easy!",
  "id" : 324460291024904192,
  "created_at" : "2013-04-17 09:52:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/324439864189784064\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/lCpGNKKLpA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BICkVmhCEAEodEL.jpg",
      "id_str" : "324439864193978369",
      "id" : 324439864193978369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BICkVmhCEAEodEL.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/lCpGNKKLpA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324439864189784064",
  "text" : "Getting our Maggie on. http:\/\/t.co\/lCpGNKKLpA",
  "id" : 324439864189784064,
  "created_at" : "2013-04-17 08:31:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neo4j",
      "screen_name" : "neo4j",
      "indices" : [ 50, 56 ],
      "id_str" : "22467617",
      "id" : 22467617
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 60, 72 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324439410177355776",
  "text" : "At some point in the future I am giving a talk on @neo4j at @BelfastRuby - there I've told the interweb so I have to do it now :)",
  "id" : 324439410177355776,
  "created_at" : "2013-04-17 08:29:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324429730419974144",
  "text" : "So this is Wednesday\u2026\u2026.",
  "id" : 324429730419974144,
  "created_at" : "2013-04-17 07:50:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 13, 20 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324298823029649408",
  "geo" : { },
  "id_str" : "324301019800551426",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning @srushe I'll take that bet sir :)",
  "id" : 324301019800551426,
  "in_reply_to_status_id" : 324298823029649408,
  "created_at" : "2013-04-16 23:19:23 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324294660145172480",
  "geo" : { },
  "id_str" : "324295959154655234",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning :D PHP hures....",
  "id" : 324295959154655234,
  "in_reply_to_status_id" : 324294660145172480,
  "created_at" : "2013-04-16 22:59:16 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 13, 25 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 26, 32 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324295854028644354",
  "text" : "RT @HaVoCT5: @ryancunning @swmcc Fuck ye both, VB for the win! \\o\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan Cunning",
        "screen_name" : "ryancunning",
        "indices" : [ 0, 12 ],
        "id_str" : "226910307",
        "id" : 226910307
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 13, 19 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "324294660145172480",
    "geo" : { },
    "id_str" : "324295184231833600",
    "in_reply_to_user_id" : 226910307,
    "text" : "@ryancunning @swmcc Fuck ye both, VB for the win! \\o\/",
    "id" : 324295184231833600,
    "in_reply_to_status_id" : 324294660145172480,
    "created_at" : "2013-04-16 22:56:11 +0000",
    "in_reply_to_screen_name" : "ryancunning",
    "in_reply_to_user_id_str" : "226910307",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 324295854028644354,
  "created_at" : "2013-04-16 22:58:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 0, 12 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Eric A. Meyer",
      "screen_name" : "meyerweb",
      "indices" : [ 13, 22 ],
      "id_str" : "646533",
      "id" : 646533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324285952329670656",
  "geo" : { },
  "id_str" : "324293706796658689",
  "in_reply_to_user_id" : 226910307,
  "text" : "@ryancunning @meyerweb bullshit. Perl is way more powerful, no fuck up and just get on with it!",
  "id" : 324293706796658689,
  "in_reply_to_status_id" : 324285952329670656,
  "created_at" : "2013-04-16 22:50:19 +0000",
  "in_reply_to_screen_name" : "ryancunning",
  "in_reply_to_user_id_str" : "226910307",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324128064416120834",
  "text" : "Am getting close to my 9,000 tweet.. Guess now I have twitter history I can give some 'interesting' stats on the guff I talk in here.",
  "id" : 324128064416120834,
  "created_at" : "2013-04-16 11:52:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/bUVbfHXpS6",
      "expanded_url" : "https:\/\/getinvited.to\/refreshbelfast\/refresh-with-atto-partners",
      "display_url" : "getinvited.to\/refreshbelfast\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324127866382073858",
  "text" : "Get Invited to Refresh with Atto Partners:  https:\/\/t.co\/bUVbfHXpS6",
  "id" : 324127866382073858,
  "created_at" : "2013-04-16 11:51:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324112913432449025",
  "geo" : { },
  "id_str" : "324122100048732160",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke :D",
  "id" : 324122100048732160,
  "in_reply_to_status_id" : 324112913432449025,
  "created_at" : "2013-04-16 11:28:25 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Push Technology",
      "screen_name" : "push_technology",
      "indices" : [ 3, 19 ],
      "id_str" : "262711334",
      "id" : 262711334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/bP4vkyKHAa",
      "expanded_url" : "http:\/\/fb.me\/2ho1emW0g",
      "display_url" : "fb.me\/2ho1emW0g"
    } ]
  },
  "geo" : { },
  "id_str" : "324111854194540545",
  "text" : "RT @push_technology: BigData start-ups are interesting investors as they come to market [Video] http:\/\/t.co\/bP4vkyKHAa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/bP4vkyKHAa",
        "expanded_url" : "http:\/\/fb.me\/2ho1emW0g",
        "display_url" : "fb.me\/2ho1emW0g"
      } ]
    },
    "geo" : { },
    "id_str" : "324109723794280448",
    "text" : "BigData start-ups are interesting investors as they come to market [Video] http:\/\/t.co\/bP4vkyKHAa",
    "id" : 324109723794280448,
    "created_at" : "2013-04-16 10:39:14 +0000",
    "user" : {
      "name" : "Push Technology",
      "screen_name" : "push_technology",
      "protected" : false,
      "id_str" : "262711334",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2165535851\/Push-Square_normal.jpg",
      "id" : 262711334,
      "verified" : false
    }
  },
  "id" : 324111854194540545,
  "created_at" : "2013-04-16 10:47:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324100123569291264",
  "text" : "Just seen a tweet for bit coins and node.js inside a npm package. Somewhere a hipster just came\u2026.",
  "id" : 324100123569291264,
  "created_at" : "2013-04-16 10:01:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324093248459141120",
  "geo" : { },
  "id_str" : "324096526165094400",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco kid gloves JR.. kid gloves :)",
  "id" : 324096526165094400,
  "in_reply_to_status_id" : 324093248459141120,
  "created_at" : "2013-04-16 09:46:47 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 3, 15 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323852202957488129",
  "text" : "RT @BelfastRuby: We're meeting up tomorrow in the Duke of York at 6:30pm to plan out future talks &amp; events. Hoping to see you all there!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323848909476753409",
    "text" : "We're meeting up tomorrow in the Duke of York at 6:30pm to plan out future talks &amp; events. Hoping to see you all there!",
    "id" : 323848909476753409,
    "created_at" : "2013-04-15 17:22:51 +0000",
    "user" : {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "protected" : false,
      "id_str" : "454835425",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1752070239\/belfastruby-twitter-icon-2_normal.png",
      "id" : 454835425,
      "verified" : false
    }
  },
  "id" : 323852202957488129,
  "created_at" : "2013-04-15 17:35:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gonnasayournameoutloudnow",
      "indices" : [ 54, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323815648960606208",
  "geo" : { },
  "id_str" : "323816399082496001",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel 46 so far... going for the 47th right now ;) #gonnasayournameoutloudnow",
  "id" : 323816399082496001,
  "in_reply_to_status_id" : 323815648960606208,
  "created_at" : "2013-04-15 15:13:40 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Zak",
      "screen_name" : "ZakGrant",
      "indices" : [ 8, 17 ],
      "id_str" : "23845168",
      "id" : 23845168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323544616324460545",
  "geo" : { },
  "id_str" : "323815232885637122",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @ZakGrant It'd be handy if it stopped me commiting dependent on how many buns I have eat though ;)",
  "id" : 323815232885637122,
  "in_reply_to_status_id" : 323544616324460545,
  "created_at" : "2013-04-15 15:09:02 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323814448731156480",
  "geo" : { },
  "id_str" : "323814881226801152",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel I don't get what you are saying Locko :) Sometimes your wit is above my bald head :) Wear something slutty tomorrow will ya ;)",
  "id" : 323814881226801152,
  "in_reply_to_status_id" : 323814448731156480,
  "created_at" : "2013-04-15 15:07:38 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323813895141720065",
  "text" : "Lovely four days off there not going near a computer... REALLY needed that... Now back to serious work starting tomorrow... In a good way :)",
  "id" : 323813895141720065,
  "created_at" : "2013-04-15 15:03:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 3, 12 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/wFwm8C0n3q",
      "expanded_url" : "http:\/\/GitHub.com",
      "display_url" : "GitHub.com"
    } ]
  },
  "geo" : { },
  "id_str" : "323765211897135105",
  "text" : "RT @rtomayko: http:\/\/t.co\/wFwm8C0n3q The Website's push =&gt; CI =&gt; deploy process just went from about 8 minutes to under 2 thanks t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aman Gupta",
        "screen_name" : "tmm1",
        "indices" : [ 124, 129 ],
        "id_str" : "15591045",
        "id" : 15591045
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/wFwm8C0n3q",
        "expanded_url" : "http:\/\/GitHub.com",
        "display_url" : "GitHub.com"
      } ]
    },
    "geo" : { },
    "id_str" : "323757182174773248",
    "text" : "http:\/\/t.co\/wFwm8C0n3q The Website's push =&gt; CI =&gt; deploy process just went from about 8 minutes to under 2 thanks to @tmm1 and 64 cores.",
    "id" : 323757182174773248,
    "created_at" : "2013-04-15 11:18:22 +0000",
    "user" : {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "protected" : false,
      "id_str" : "9267332",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3109364645\/f89b77ce2f3afa72fdc3ca7e08f3c4f9_normal.png",
      "id" : 9267332,
      "verified" : false
    }
  },
  "id" : 323765211897135105,
  "created_at" : "2013-04-15 11:50:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bash!",
      "screen_name" : "devbash",
      "indices" : [ 3, 11 ],
      "id_str" : "454193975",
      "id" : 454193975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323765174098067456",
  "text" : "RT @devbash: Keep Tuesday May 28th free.  We're hoping to announce **MAJOR** speaker for Bash event in next few days.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323747701458083840",
    "text" : "Keep Tuesday May 28th free.  We're hoping to announce **MAJOR** speaker for Bash event in next few days.",
    "id" : 323747701458083840,
    "created_at" : "2013-04-15 10:40:41 +0000",
    "user" : {
      "name" : "Bash!",
      "screen_name" : "devbash",
      "protected" : false,
      "id_str" : "454193975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1732404718\/bash_normal.png",
      "id" : 454193975,
      "verified" : false
    }
  },
  "id" : 323765174098067456,
  "created_at" : "2013-04-15 11:50:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Hope",
      "screen_name" : "midhir",
      "indices" : [ 0, 7 ],
      "id_str" : "14599184",
      "id" : 14599184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323494885149794305",
  "geo" : { },
  "id_str" : "323500218194731008",
  "in_reply_to_user_id" : 14599184,
  "text" : "@midhir it is crap..... not scary at all... that is if it is the one with catherine zeta jones in it.",
  "id" : 323500218194731008,
  "in_reply_to_status_id" : 323494885149794305,
  "created_at" : "2013-04-14 18:17:17 +0000",
  "in_reply_to_screen_name" : "midhir",
  "in_reply_to_user_id_str" : "14599184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323478782600159232",
  "text" : "I've been off twitter really since Thursday night. Long break is really recharging the oul batteries.. One more day offski :) :)",
  "id" : 323478782600159232,
  "created_at" : "2013-04-14 16:52:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322996188917940224",
  "text" : "OH: \u201CNo one likes a mock multiple choice!\u201D",
  "id" : 322996188917940224,
  "created_at" : "2013-04-13 08:54:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 3, 13 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/ERIk4mlPDf",
      "expanded_url" : "http:\/\/zachholman.com\/talk\/keeping-people\/",
      "display_url" : "zachholman.com\/talk\/keeping-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322994196325728256",
  "text" : "RT @carisenda: http:\/\/t.co\/ERIk4mlPDf # Github on keeping\/hiring people, I agree",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/ERIk4mlPDf",
        "expanded_url" : "http:\/\/zachholman.com\/talk\/keeping-people\/",
        "display_url" : "zachholman.com\/talk\/keeping-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "322982111046942721",
    "text" : "http:\/\/t.co\/ERIk4mlPDf # Github on keeping\/hiring people, I agree",
    "id" : 322982111046942721,
    "created_at" : "2013-04-13 07:58:30 +0000",
    "user" : {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "protected" : false,
      "id_str" : "212603717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1513037620\/avatar_normal.png",
      "id" : 212603717,
      "verified" : false
    }
  },
  "id" : 322994196325728256,
  "created_at" : "2013-04-13 08:46:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    }, {
      "name" : "Mark Kermode",
      "screen_name" : "KermodeMovie",
      "indices" : [ 8, 21 ],
      "id_str" : "111323990",
      "id" : 111323990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322821691413778432",
  "geo" : { },
  "id_str" : "322829686751232000",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl @KermodeMovie you need to watch sons of anarchy for dodgy NI accents. Granted that is a tee-vee show and not filumn.",
  "id" : 322829686751232000,
  "in_reply_to_status_id" : 322821691413778432,
  "created_at" : "2013-04-12 21:52:49 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 3, 15 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322690878827266048",
  "text" : "RT @BelfastRuby: We\u2019re doing a meetup next Tuesday in the Duke of York @ 18:30 to talk Ruby &amp; help plan the next few talks. Do come  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322624622791102465",
    "text" : "We\u2019re doing a meetup next Tuesday in the Duke of York @ 18:30 to talk Ruby &amp; help plan the next few talks. Do come along!",
    "id" : 322624622791102465,
    "created_at" : "2013-04-12 08:17:58 +0000",
    "user" : {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "protected" : false,
      "id_str" : "454835425",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1752070239\/belfastruby-twitter-icon-2_normal.png",
      "id" : 454835425,
      "verified" : false
    }
  },
  "id" : 322690878827266048,
  "created_at" : "2013-04-12 12:41:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 0, 9 ],
      "id_str" : "9488072",
      "id" : 9488072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322622130745401345",
  "geo" : { },
  "id_str" : "322623835742556161",
  "in_reply_to_user_id" : 9488072,
  "text" : "@shylands HIPPIE!!!!!!!!",
  "id" : 322623835742556161,
  "in_reply_to_status_id" : 322622130745401345,
  "created_at" : "2013-04-12 08:14:51 +0000",
  "in_reply_to_screen_name" : "shylands",
  "in_reply_to_user_id_str" : "9488072",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 9, 19 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322614769632825344",
  "geo" : { },
  "id_str" : "322621470197035008",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @smccalden You two gentleman are stars :D",
  "id" : 322621470197035008,
  "in_reply_to_status_id" : 322614769632825344,
  "created_at" : "2013-04-12 08:05:27 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322419500593053696",
  "geo" : { },
  "id_str" : "322464075202326528",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl it was freaky as fuck! You are a scary man Simon....",
  "id" : 322464075202326528,
  "in_reply_to_status_id" : 322419500593053696,
  "created_at" : "2013-04-11 21:40:01 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Scott",
      "screen_name" : "paulscott56",
      "indices" : [ 3, 15 ],
      "id_str" : "15775653",
      "id" : 15775653
    }, {
      "name" : "MongoDB",
      "screen_name" : "MongoDB",
      "indices" : [ 43, 51 ],
      "id_str" : "18080585",
      "id" : 18080585
    }, {
      "name" : "Neo4j",
      "screen_name" : "neo4j",
      "indices" : [ 56, 62 ],
      "id_str" : "22467617",
      "id" : 22467617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322374642713100288",
  "text" : "RT @paulscott56: Grails -&gt; Spring -&gt; @MongoDB and @Neo4j is a match made in heaven. Really, this stuff is pretty sweet!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MongoDB",
        "screen_name" : "MongoDB",
        "indices" : [ 26, 34 ],
        "id_str" : "18080585",
        "id" : 18080585
      }, {
        "name" : "Neo4j",
        "screen_name" : "neo4j",
        "indices" : [ 39, 45 ],
        "id_str" : "22467617",
        "id" : 22467617
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322340862602387457",
    "text" : "Grails -&gt; Spring -&gt; @MongoDB and @Neo4j is a match made in heaven. Really, this stuff is pretty sweet!",
    "id" : 322340862602387457,
    "created_at" : "2013-04-11 13:30:25 +0000",
    "user" : {
      "name" : "Paul Scott",
      "screen_name" : "paulscott56",
      "protected" : false,
      "id_str" : "15775653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3675300843\/2f2ec65bcd2fcbf8bdaf192ac95e4a55_normal.jpeg",
      "id" : 15775653,
      "verified" : false
    }
  },
  "id" : 322374642713100288,
  "created_at" : "2013-04-11 15:44:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samir mezrahi",
      "screen_name" : "samir",
      "indices" : [ 0, 6 ],
      "id_str" : "115396965",
      "id" : 115396965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322344807378874368",
  "geo" : { },
  "id_str" : "322345097205256192",
  "in_reply_to_user_id" : 115396965,
  "text" : "@samir yup it be down.",
  "id" : 322345097205256192,
  "in_reply_to_status_id" : 322344807378874368,
  "created_at" : "2013-04-11 13:47:14 +0000",
  "in_reply_to_screen_name" : "samir",
  "in_reply_to_user_id_str" : "115396965",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 11, 19 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322294847446843392",
  "geo" : { },
  "id_str" : "322327223388475392",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @jbrevel I know :D",
  "id" : 322327223388475392,
  "in_reply_to_status_id" : 322294847446843392,
  "created_at" : "2013-04-11 12:36:13 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 11, 19 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322294847446843392",
  "geo" : { },
  "id_str" : "322327171492364289",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden @jbrevel hell ya",
  "id" : 322327171492364289,
  "in_reply_to_status_id" : 322294847446843392,
  "created_at" : "2013-04-11 12:36:00 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 20, 32 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/322327107902513153\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/8XRf3sPDAU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHkizABCIAEBKMx.jpg",
      "id_str" : "322327107906707457",
      "id" : 322327107906707457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHkizABCIAEBKMx.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/8XRf3sPDAU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322327107902513153",
  "text" : "Cheers for the cake @DebbieCReid http:\/\/t.co\/8XRf3sPDAU",
  "id" : 322327107902513153,
  "created_at" : "2013-04-11 12:35:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosie",
      "screen_name" : "RosieLondoner",
      "indices" : [ 0, 14 ],
      "id_str" : "22646133",
      "id" : 22646133
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 15, 23 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322280323478061056",
  "geo" : { },
  "id_str" : "322291396876832768",
  "in_reply_to_user_id" : 22646133,
  "text" : "@RosieLondoner @jbrevel thanks :)",
  "id" : 322291396876832768,
  "in_reply_to_status_id" : 322280323478061056,
  "created_at" : "2013-04-11 10:13:51 +0000",
  "in_reply_to_screen_name" : "RosieLondoner",
  "in_reply_to_user_id_str" : "22646133",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 18, 26 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322291371841056768",
  "text" : "Has to be said :) @jbrevel is a legend :)",
  "id" : 322291371841056768,
  "created_at" : "2013-04-11 10:13:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosie",
      "screen_name" : "RosieLondoner",
      "indices" : [ 3, 17 ],
      "id_str" : "22646133",
      "id" : 22646133
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 19, 27 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 28, 34 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322291210255491072",
  "text" : "RT @RosieLondoner: @jbrevel @swmcc happy birthday!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Loughrey",
        "screen_name" : "jbrevel",
        "indices" : [ 0, 8 ],
        "id_str" : "50685221",
        "id" : 50685221
      }, {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 9, 15 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "322255040230354945",
    "geo" : { },
    "id_str" : "322280323478061056",
    "in_reply_to_user_id" : 50685221,
    "text" : "@jbrevel @swmcc happy birthday!!",
    "id" : 322280323478061056,
    "in_reply_to_status_id" : 322255040230354945,
    "created_at" : "2013-04-11 09:29:51 +0000",
    "in_reply_to_screen_name" : "jbrevel",
    "in_reply_to_user_id_str" : "50685221",
    "user" : {
      "name" : "Rosie",
      "screen_name" : "RosieLondoner",
      "protected" : false,
      "id_str" : "22646133",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000053105744\/b199e602ed7e1c9b56a88104dd73901c_normal.jpeg",
      "id" : 22646133,
      "verified" : false
    }
  },
  "id" : 322291210255491072,
  "created_at" : "2013-04-11 10:13:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322264361794162689",
  "geo" : { },
  "id_str" : "322264708109463553",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden legend :)",
  "id" : 322264708109463553,
  "in_reply_to_status_id" : 322264361794162689,
  "created_at" : "2013-04-11 08:27:48 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322261878405484544",
  "geo" : { },
  "id_str" : "322262579399507968",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit also drink the kool aid bitch. You are working in london now - just give in ffs\u2026.",
  "id" : 322262579399507968,
  "in_reply_to_status_id" : 322261878405484544,
  "created_at" : "2013-04-11 08:19:20 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322261878405484544",
  "geo" : { },
  "id_str" : "322262464047751170",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit drink the koolaid. Am telling ya not having to worry about upgrading stuff - one of the best decisions I\u2019ve made tech wise.",
  "id" : 322262464047751170,
  "in_reply_to_status_id" : 322261878405484544,
  "created_at" : "2013-04-11 08:18:53 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322049192774209536",
  "geo" : { },
  "id_str" : "322250281494667264",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit time to move away from Wordpress maybe? I moved to GitHub pages a while back. No more upgrades etc.",
  "id" : 322250281494667264,
  "in_reply_to_status_id" : 322049192774209536,
  "created_at" : "2013-04-11 07:30:28 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "madmen",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322100475791015938",
  "text" : "Mad Men in 1968 - side burns all over the place. #madmen",
  "id" : 322100475791015938,
  "created_at" : "2013-04-10 21:35:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 16, 28 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Tracy Adams",
      "screen_name" : "tracy2710",
      "indices" : [ 29, 39 ],
      "id_str" : "241879307",
      "id" : 241879307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322085679507066881",
  "geo" : { },
  "id_str" : "322090031596568576",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull @niall_adams @tracy2710 awesome :)",
  "id" : 322090031596568576,
  "in_reply_to_status_id" : 322085679507066881,
  "created_at" : "2013-04-10 20:53:42 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fourdayweekend",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322047269656489985",
  "text" : "Time to go home :) \/me swipes his cape and exits stage left\u2026 Oh yeah - tomorrow is my Friday and next Tuesday is my Monday! #fourdayweekend",
  "id" : 322047269656489985,
  "created_at" : "2013-04-10 18:03:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iwillgetoverit",
      "indices" : [ 73, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321982608160456707",
  "text" : "Using Thor to create my controllers is pretty cool - feels dirty though\u2026 #iwillgetoverit",
  "id" : 321982608160456707,
  "created_at" : "2013-04-10 13:46:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "indices" : [ 3, 10 ],
      "id_str" : "17843859",
      "id" : 17843859
    }, {
      "name" : "InterSystems Corp",
      "screen_name" : "InterSystems",
      "indices" : [ 118, 131 ],
      "id_str" : "74499421",
      "id" : 74499421
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Glo",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321953778637090816",
  "text" : "RT @rtweed: See the realtime, event-driven, JavaScript future of Cache at the M\/Gateway table in the Partner Pavilion @InterSystems #Glo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "InterSystems Corp",
        "screen_name" : "InterSystems",
        "indices" : [ 106, 119 ],
        "id_str" : "74499421",
        "id" : 74499421
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GlobalSummit",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321953503956312064",
    "text" : "See the realtime, event-driven, JavaScript future of Cache at the M\/Gateway table in the Partner Pavilion @InterSystems #GlobalSummit",
    "id" : 321953503956312064,
    "created_at" : "2013-04-10 11:51:11 +0000",
    "user" : {
      "name" : "Rob Tweed",
      "screen_name" : "rtweed",
      "protected" : false,
      "id_str" : "17843859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1398354510\/me_normal.png",
      "id" : 17843859,
      "verified" : false
    }
  },
  "id" : 321953778637090816,
  "created_at" : "2013-04-10 11:52:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosie",
      "screen_name" : "RosieLondoner",
      "indices" : [ 0, 14 ],
      "id_str" : "22646133",
      "id" : 22646133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321952286068862976",
  "geo" : { },
  "id_str" : "321952742585282561",
  "in_reply_to_user_id" : 22646133,
  "text" : "@RosieLondoner tell him I have a pair of size 11's - 400 quid ono :)",
  "id" : 321952742585282561,
  "in_reply_to_status_id" : 321952286068862976,
  "created_at" : "2013-04-10 11:48:10 +0000",
  "in_reply_to_screen_name" : "RosieLondoner",
  "in_reply_to_user_id_str" : "22646133",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 16, 29 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321946969901764608",
  "text" : "Whatever coffee @Paul_Moffett  put in the coffee machine today is working\u2026",
  "id" : 321946969901764608,
  "created_at" : "2013-04-10 11:25:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321731983392776192",
  "geo" : { },
  "id_str" : "321732472016625664",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl yeah :) I *really* want this - spose we have some of it there already - but we need doug up and running I think :)",
  "id" : 321732472016625664,
  "in_reply_to_status_id" : 321731983392776192,
  "created_at" : "2013-04-09 21:12:53 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Newland",
      "screen_name" : "jnewland",
      "indices" : [ 98, 107 ],
      "id_str" : "13518",
      "id" : 13518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321732248388902912",
  "text" : "\"By placing tools directly in the middle of the conversation everyone is pairing all the time\" :D @jnewland great quote....",
  "id" : 321732248388902912,
  "created_at" : "2013-04-09 21:12:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DOUGTHEDOG",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/OmXIyI1sI4",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=NST3u-GjjFw",
      "display_url" : "youtube.com\/watch?v=NST3u-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "321731552096686080",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl we need to put our heads together for an hour on Thursday and start this - http:\/\/t.co\/OmXIyI1sI4 #DOUGTHEDOG",
  "id" : 321731552096686080,
  "created_at" : "2013-04-09 21:09:14 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldschool",
      "indices" : [ 62, 72 ]
    }, {
      "text" : "donotchangetheurlofsomethingimportantlikethatever",
      "indices" : [ 73, 123 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321603260135907328",
  "geo" : { },
  "id_str" : "321605773945872384",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco Amazing :) Yeah - I sent a congrats email instead.... #oldschool #donotchangetheurlofsomethingimportantlikethatever",
  "id" : 321605773945872384,
  "in_reply_to_status_id" : 321603260135907328,
  "created_at" : "2013-04-09 12:49:26 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/xWPLvyX4yA",
      "expanded_url" : "http:\/\/www.maildistiller.com\/proofpoint-acquires-maildistiller",
      "display_url" : "maildistiller.com\/proofpoint-acq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "321599235378278400",
  "text" : "Congrats to Colm and the team, couldn't happen to a nicer man.  http:\/\/t.co\/xWPLvyX4yA",
  "id" : 321599235378278400,
  "created_at" : "2013-04-09 12:23:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321235272455041024",
  "geo" : { },
  "id_str" : "321235801767817216",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden I agree but she was ginger so it is fair play :)",
  "id" : 321235801767817216,
  "in_reply_to_status_id" : 321235272455041024,
  "created_at" : "2013-04-08 12:19:18 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321233157099773952",
  "text" : "Time to turn off twitter for the next day or two I think.... \/me finds the switch and hits \"off\"",
  "id" : 321233157099773952,
  "created_at" : "2013-04-08 12:08:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/spotify.com\" rel=\"nofollow\"\u003ESpotify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Spotify",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/4bIQySLxUj",
      "expanded_url" : "http:\/\/spoti.fi\/Q2JM60",
      "display_url" : "spoti.fi\/Q2JM60"
    } ]
  },
  "geo" : { },
  "id_str" : "321196728466407424",
  "text" : "\u266B World Classical Concert \u2013 Mozart | Beethoven | Chopin | Bach http:\/\/t.co\/4bIQySLxUj #Spotify",
  "id" : 321196728466407424,
  "created_at" : "2013-04-08 09:44:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320844873374773249",
  "geo" : { },
  "id_str" : "320849466649350145",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden I always thought Gladiator was over rated.. But still not a bad watch.",
  "id" : 320849466649350145,
  "in_reply_to_status_id" : 320844873374773249,
  "created_at" : "2013-04-07 10:44:08 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Snow",
      "screen_name" : "AppleStoreSean",
      "indices" : [ 3, 18 ],
      "id_str" : "635543703",
      "id" : 635543703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320659414254235648",
  "text" : "RT @AppleStoreSean: First Taken now Pulp Fiction this couldn't get any better, oh wait I can watch Game of Thrones after. It just got better",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "320653535735865344",
    "text" : "First Taken now Pulp Fiction this couldn't get any better, oh wait I can watch Game of Thrones after. It just got better",
    "id" : 320653535735865344,
    "created_at" : "2013-04-06 21:45:35 +0000",
    "user" : {
      "name" : "Sean Snow",
      "screen_name" : "AppleStoreSean",
      "protected" : false,
      "id_str" : "635543703",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000534216454\/2ee313e5c53c2aa8c18b40d6b884d60f_normal.jpeg",
      "id" : 635543703,
      "verified" : false
    }
  },
  "id" : 320659414254235648,
  "created_at" : "2013-04-06 22:08:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320658406954377216",
  "text" : "Pulp Fiction has to be the best film ever made... Gets better and better every time I see it.",
  "id" : 320658406954377216,
  "created_at" : "2013-04-06 22:04:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/n3dSsz1WnV",
      "expanded_url" : "https:\/\/github.com\/swmcc\/cookbook\/blob\/master\/food\/chicken%20and%20chorizo%20jambalaya.md",
      "display_url" : "github.com\/swmcc\/cookbook\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320593308168626176",
  "text" : "Chicken and Chorizo jambalya and Doctor Who! https:\/\/t.co\/n3dSsz1WnV I think that'll do nicely!",
  "id" : 320593308168626176,
  "created_at" : "2013-04-06 17:46:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320587050787143682",
  "geo" : { },
  "id_str" : "320592658307371008",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall glory hunter! :)",
  "id" : 320592658307371008,
  "in_reply_to_status_id" : 320587050787143682,
  "created_at" : "2013-04-06 17:43:40 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 10, 20 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320260052210561024",
  "geo" : { },
  "id_str" : "320260392251183104",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo @smccalden pride? I do not recognise that word.",
  "id" : 320260392251183104,
  "in_reply_to_status_id" : 320260052210561024,
  "created_at" : "2013-04-05 19:43:22 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320255809747554304",
  "geo" : { },
  "id_str" : "320260175426617344",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard let\u2019s hope no one bears you in three moves or you\u2019ll huff and never play again :) #justsayin",
  "id" : 320260175426617344,
  "in_reply_to_status_id" : 320255809747554304,
  "created_at" : "2013-04-05 19:42:30 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 15, 24 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320235589301587968",
  "geo" : { },
  "id_str" : "320259228671565824",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @davehedo pfffffftttttt",
  "id" : 320259228671565824,
  "in_reply_to_status_id" : 320235589301587968,
  "created_at" : "2013-04-05 19:38:44 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 9, 21 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 22, 36 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 37, 51 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320189395204440064",
  "geo" : { },
  "id_str" : "320192558074564611",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 @ryancunning @peter_omalley @ChrisKnowles_  s\/head\/skin\/",
  "id" : 320192558074564611,
  "in_reply_to_status_id" : 320189395204440064,
  "created_at" : "2013-04-05 15:13:49 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 0, 9 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 38, 52 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320183303883878402",
  "geo" : { },
  "id_str" : "320185917254029315",
  "in_reply_to_user_id" : 50985598,
  "text" : "@davehedo nothing wrong with Steps as @jenporterhall will confess to as well! :)",
  "id" : 320185917254029315,
  "in_reply_to_status_id" : 320183303883878402,
  "created_at" : "2013-04-05 14:47:26 +0000",
  "in_reply_to_screen_name" : "davehedo",
  "in_reply_to_user_id_str" : "50985598",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shoulddothismoreoften",
      "indices" : [ 107, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320162076737810432",
  "text" : "You know you are having a productive day when you don\u2019t think about twitter and what you lot are saying :) #shoulddothismoreoften :)",
  "id" : 320162076737810432,
  "created_at" : "2013-04-05 13:12:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beryl Moffett",
      "screen_name" : "berylmoffett",
      "indices" : [ 0, 13 ],
      "id_str" : "113491691",
      "id" : 113491691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319878173925990402",
  "geo" : { },
  "id_str" : "319902328075460608",
  "in_reply_to_user_id" : 113491691,
  "text" : "@berylmoffett cheers Beryl :)",
  "id" : 319902328075460608,
  "in_reply_to_status_id" : 319878173925990402,
  "created_at" : "2013-04-04 20:00:33 +0000",
  "in_reply_to_screen_name" : "berylmoffett",
  "in_reply_to_user_id_str" : "113491691",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319900888519020544",
  "geo" : { },
  "id_str" : "319901298638069760",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish that's what I was thinking - and why I asked for clarification. Thanks.",
  "id" : 319901298638069760,
  "in_reply_to_status_id" : 319900888519020544,
  "created_at" : "2013-04-04 19:56:27 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319900487182860288",
  "geo" : { },
  "id_str" : "319900613766946818",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish no need - just needed a bit of clarification. Thanks.",
  "id" : 319900613766946818,
  "in_reply_to_status_id" : 319900487182860288,
  "created_at" : "2013-04-04 19:53:44 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319900057908432896",
  "geo" : { },
  "id_str" : "319900331687436288",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish brilliant :) Thanks very much.",
  "id" : 319900331687436288,
  "in_reply_to_status_id" : 319900057908432896,
  "created_at" : "2013-04-04 19:52:37 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/kbDBcgW9pR",
      "expanded_url" : "http:\/\/gandalf.swm.cc",
      "display_url" : "gandalf.swm.cc"
    } ]
  },
  "in_reply_to_status_id_str" : "319899611907125249",
  "geo" : { },
  "id_str" : "319900155509866496",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish the only time I have asked 4 support is for one of my IPs to resolve to http:\/\/t.co\/kbDBcgW9pR - but in future that would be 20?",
  "id" : 319900155509866496,
  "in_reply_to_status_id" : 319899611907125249,
  "created_at" : "2013-04-04 19:51:55 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319899611907125249",
  "geo" : { },
  "id_str" : "319899924818964482",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish Nope, well not yet anyway. I was just wondering in re: to your new ticket cost tariff for unmanaged ppl.",
  "id" : 319899924818964482,
  "in_reply_to_status_id" : 319899611907125249,
  "created_at" : "2013-04-04 19:51:00 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BWF Hosting",
      "screen_name" : "bigwetfish",
      "indices" : [ 0, 11 ],
      "id_str" : "21522311",
      "id" : 21522311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319899022431240192",
  "in_reply_to_user_id" : 21522311,
  "text" : "@bigwetfish - I am on an unmanaged plan. So with the new ticket cost - I would have to pay for you to do a reverse DNS change?",
  "id" : 319899022431240192,
  "created_at" : "2013-04-04 19:47:25 +0000",
  "in_reply_to_screen_name" : "bigwetfish",
  "in_reply_to_user_id_str" : "21522311",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 3, 16 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 18, 24 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319839571993042946",
  "text" : "RT @Paul_Moffett: @swmcc Paul Moffett",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319758960234217472",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc Paul Moffett",
    "id" : 319758960234217472,
    "created_at" : "2013-04-04 10:30:51 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "protected" : false,
      "id_str" : "36913698",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1175980356\/92313091_N00_normal.jpg",
      "id" : 36913698,
      "verified" : false
    }
  },
  "id" : 319839571993042946,
  "created_at" : "2013-04-04 15:51:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319771002445893632",
  "text" : "OH: \"I tend to disagree.....\"",
  "id" : 319771002445893632,
  "created_at" : "2013-04-04 11:18:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 39, 46 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319747062604386305",
  "text" : "Hipchat is a more lonely place without @szlwzl to play with\u2026\u2026 :(",
  "id" : 319747062604386305,
  "created_at" : "2013-04-04 09:43:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FUCK",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319539543801995265",
  "text" : "What a day.... I am gonna go to Germany and be all negative - for a change.... Happy thoughts tho :) Happy happy thoughts :) #FUCK!!!! :)",
  "id" : 319539543801995265,
  "created_at" : "2013-04-03 19:58:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 3, 12 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319538886206443520",
  "text" : "RT @hamstarr: Juicer arrived today and within 10 minutes I juiced the fuck out of all the fruit. Need more fruit!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319535171705663488",
    "text" : "Juicer arrived today and within 10 minutes I juiced the fuck out of all the fruit. Need more fruit!",
    "id" : 319535171705663488,
    "created_at" : "2013-04-03 19:41:36 +0000",
    "user" : {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "protected" : false,
      "id_str" : "8388092",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1117686760\/avatar-480x480_normal.jpg",
      "id" : 8388092,
      "verified" : false
    }
  },
  "id" : 319538886206443520,
  "created_at" : "2013-04-03 19:56:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319479016396578816",
  "text" : "Way too much coffee today\u2026. Either that or I finally having that heart attack\u2026. Could be both\u2026",
  "id" : 319479016396578816,
  "created_at" : "2013-04-03 15:58:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. Cox",
      "screen_name" : "Melissa_Maria",
      "indices" : [ 3, 17 ],
      "id_str" : "20463255",
      "id" : 20463255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319474786361307136",
  "text" : "RT @Melissa_Maria: Dear Daily Mail, \n\nWhen will you be running your front page about JK Rowling: Super Awesome Product of Welfare UK? \n\n ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319431795164721152",
    "text" : "Dear Daily Mail, \n\nWhen will you be running your front page about JK Rowling: Super Awesome Product of Welfare UK? \n\nRegards, \n\nM. Cox",
    "id" : 319431795164721152,
    "created_at" : "2013-04-03 12:50:49 +0000",
    "user" : {
      "name" : "M. Cox",
      "screen_name" : "Melissa_Maria",
      "protected" : false,
      "id_str" : "20463255",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000601153480\/757a6884b503ea493664a055d65a024c_normal.jpeg",
      "id" : 20463255,
      "verified" : false
    }
  },
  "id" : 319474786361307136,
  "created_at" : "2013-04-03 15:41:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319450563920158720",
  "geo" : { },
  "id_str" : "319451766452256770",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley am on spotify - add me bitch!!! :D",
  "id" : 319451766452256770,
  "in_reply_to_status_id" : 319450563920158720,
  "created_at" : "2013-04-03 14:10:10 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319448432001552384",
  "text" : "Coding and listening to 80's power rock anthems.... It is one of those days.",
  "id" : 319448432001552384,
  "created_at" : "2013-04-03 13:56:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 11, 24 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 29, 36 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319425371768512513",
  "text" : "New low... @Paul_Moffett and @rejoco discussing shoes.... Yes shoes.... I dunno.....",
  "id" : 319425371768512513,
  "created_at" : "2013-04-03 12:25:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319404686992080898",
  "text" : "RT @MiriamKerbache: Diamond IT are giving away an IPAD MINI to 1 lucky follower on the 30th of April!To enter, all you have to do is RET ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319404446297776128",
    "text" : "Diamond IT are giving away an IPAD MINI to 1 lucky follower on the 30th of April!To enter, all you have to do is RETWEET this and follow me!",
    "id" : 319404446297776128,
    "created_at" : "2013-04-03 11:02:08 +0000",
    "user" : {
      "name" : "Miriam Kerbache",
      "screen_name" : "MiriamDiamondrg",
      "protected" : false,
      "id_str" : "172736413",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3502664762\/085747fe56b08dbf6b611845377f593b_normal.jpeg",
      "id" : 172736413,
      "verified" : false
    }
  },
  "id" : 319404686992080898,
  "created_at" : "2013-04-03 11:03:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319081091522756608",
  "geo" : { },
  "id_str" : "319393832657637377",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit ya wha! CF! Thought you moved to London to get away from stuffs like that :)",
  "id" : 319393832657637377,
  "in_reply_to_status_id" : 319081091522756608,
  "created_at" : "2013-04-03 10:19:58 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319384607705419776",
  "text" : "Fuck I forgot my earphones today too........ Shitfire......",
  "id" : 319384607705419776,
  "created_at" : "2013-04-03 09:43:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 83, 91 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 96, 109 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "likeaboss",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319382241061007360",
  "text" : "I kinda just walked off a meeting there.. Did my bit and getting on with it.. Poor @jbrevel and @Paul_Moffett didn't escape :) #likeaboss",
  "id" : 319382241061007360,
  "created_at" : "2013-04-03 09:33:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/xrYtKmEylH",
      "expanded_url" : "http:\/\/blog.swm.cc\/2013\/04\/02\/qualifications\/",
      "display_url" : "blog.swm.cc\/2013\/04\/02\/qua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319109317716500481",
  "text" : "Good amount of work done this afternoon - plus I wrote a wee blog post too - http:\/\/t.co\/xrYtKmEylH - Productive day. Now for the cinema! :)",
  "id" : 319109317716500481,
  "created_at" : "2013-04-02 15:29:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Frost",
      "screen_name" : "nicholasfrost",
      "indices" : [ 3, 17 ],
      "id_str" : "27498623",
      "id" : 27498623
    }, {
      "name" : "5News",
      "screen_name" : "5_News",
      "indices" : [ 104, 111 ],
      "id_str" : "354267800",
      "id" : 354267800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319095531156697089",
  "text" : "RT @nicholasfrost: Former Tory MP Edwina Currie says SHE could live on \u00A353 a week. Asked her to talk to @5_News about it, she wanted 500 ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "5News",
        "screen_name" : "5_News",
        "indices" : [ 85, 92 ],
        "id_str" : "354267800",
        "id" : 354267800
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319091050172002305",
    "text" : "Former Tory MP Edwina Currie says SHE could live on \u00A353 a week. Asked her to talk to @5_News about it, she wanted 500 quid",
    "id" : 319091050172002305,
    "created_at" : "2013-04-02 14:16:49 +0000",
    "user" : {
      "name" : "Nick Frost",
      "screen_name" : "nicholasfrost",
      "protected" : false,
      "id_str" : "27498623",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3671138649\/e7dfc854d026800db754cffd7ff9ca83_normal.png",
      "id" : 27498623,
      "verified" : false
    }
  },
  "id" : 319095531156697089,
  "created_at" : "2013-04-02 14:34:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319077479593689089",
  "text" : "That moment you wish the coffee machine was at your desk to top up your coffee so as not to fuck up your workflow But since i am on twitter!",
  "id" : 319077479593689089,
  "created_at" : "2013-04-02 13:22:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319040381054509056",
  "text" : "\/me gets ready to go into work for a few hours to get shit done without distractions :)",
  "id" : 319040381054509056,
  "created_at" : "2013-04-02 10:55:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Gordon",
      "screen_name" : "brrygrdn",
      "indices" : [ 35, 44 ],
      "id_str" : "95932190",
      "id" : 95932190
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 62, 69 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318845446657286144",
  "text" : "That moment you login and see that @brrygrdn has been busy on @github and makes you feel like a lazy fuck!!!",
  "id" : 318845446657286144,
  "created_at" : "2013-04-01 22:00:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3JztHm3aWW",
      "expanded_url" : "http:\/\/gopivotal.com\/",
      "display_url" : "gopivotal.com"
    } ]
  },
  "geo" : { },
  "id_str" : "318845172131721216",
  "text" : "http:\/\/t.co\/3JztHm3aWW - cool :)",
  "id" : 318845172131721216,
  "created_at" : "2013-04-01 21:59:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318841305872617472",
  "geo" : { },
  "id_str" : "318843401602756609",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit Good luck. Will you be on the cabal tomorrow. I'll be in work for a wee while the marra so you can talk dirty to me :)",
  "id" : 318843401602756609,
  "in_reply_to_status_id" : 318841305872617472,
  "created_at" : "2013-04-01 21:52:45 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 3, 11 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/FujRQqWva7",
      "expanded_url" : "http:\/\/blog.gaslight.co\/post\/46505332649\/gaslight-podcast-14-github-culture-with-chris",
      "display_url" : "blog.gaslight.co\/post\/465053326\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318838906881716225",
  "text" : "RT @defunkt: Me on the Gaslight Podcast: http:\/\/t.co\/FujRQqWva7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/FujRQqWva7",
        "expanded_url" : "http:\/\/blog.gaslight.co\/post\/46505332649\/gaslight-podcast-14-github-culture-with-chris",
        "display_url" : "blog.gaslight.co\/post\/465053326\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "318837745780920320",
    "text" : "Me on the Gaslight Podcast: http:\/\/t.co\/FujRQqWva7",
    "id" : 318837745780920320,
    "created_at" : "2013-04-01 21:30:16 +0000",
    "user" : {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "protected" : false,
      "id_str" : "713263",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1245949369\/b8dbb1987e8e5318584865f880036796_normal.jpeg",
      "id" : 713263,
      "verified" : false
    }
  },
  "id" : 318838906881716225,
  "created_at" : "2013-04-01 21:34:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beryl Moffett",
      "screen_name" : "berylmoffett",
      "indices" : [ 0, 13 ],
      "id_str" : "113491691",
      "id" : 113491691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318779830785175552",
  "geo" : { },
  "id_str" : "318808051048144897",
  "in_reply_to_user_id" : 113491691,
  "text" : "@berylmoffett There is a happy medium all the same :)",
  "id" : 318808051048144897,
  "in_reply_to_status_id" : 318779830785175552,
  "created_at" : "2013-04-01 19:32:17 +0000",
  "in_reply_to_screen_name" : "berylmoffett",
  "in_reply_to_user_id_str" : "113491691",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318800906713972736",
  "geo" : { },
  "id_str" : "318807310006898688",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings His book NoSQL Distilled is brilliant.",
  "id" : 318807310006898688,
  "in_reply_to_status_id" : 318800906713972736,
  "created_at" : "2013-04-01 19:29:20 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Kenny",
      "screen_name" : "bkenny",
      "indices" : [ 0, 7 ],
      "id_str" : "12585212",
      "id" : 12585212
    }, {
      "name" : "Stripe",
      "screen_name" : "stripe",
      "indices" : [ 8, 15 ],
      "id_str" : "102812444",
      "id" : 102812444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318790632632119296",
  "geo" : { },
  "id_str" : "318791410860040192",
  "in_reply_to_user_id" : 12585212,
  "text" : "@bkenny @stripe that better be an April fools....",
  "id" : 318791410860040192,
  "in_reply_to_status_id" : 318790632632119296,
  "created_at" : "2013-04-01 18:26:09 +0000",
  "in_reply_to_screen_name" : "bkenny",
  "in_reply_to_user_id_str" : "12585212",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318739146069901313",
  "geo" : { },
  "id_str" : "318765227460149248",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden I dunno. Will see.",
  "id" : 318765227460149248,
  "in_reply_to_status_id" : 318739146069901313,
  "created_at" : "2013-04-01 16:42:07 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318739824192405504",
  "geo" : { },
  "id_str" : "318764627846651904",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 she\u2019s a lovely woman\u2026",
  "id" : 318764627846651904,
  "in_reply_to_status_id" : 318739824192405504,
  "created_at" : "2013-04-01 16:39:44 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318739824192405504",
  "geo" : { },
  "id_str" : "318764554651840512",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 nooooooo not nice!!!!!!! I disapprove of what you said in the strongest terms.",
  "id" : 318764554651840512,
  "in_reply_to_status_id" : 318739824192405504,
  "created_at" : "2013-04-01 16:39:26 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beryl Moffett",
      "screen_name" : "berylmoffett",
      "indices" : [ 3, 16 ],
      "id_str" : "113491691",
      "id" : 113491691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318738027964948480",
  "text" : "So @berylmoffett is now on the twitters and following me. My old way of being VERY inappropriate will have to stop. Beryl wont stand for it.",
  "id" : 318738027964948480,
  "created_at" : "2013-04-01 14:54:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318681120025767936",
  "text" : "RT @HaVoCT5: @swmcc one reason why Stevie, one! No one in this world have minds like we do! Personally I think we're genius!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "318513701927919616",
    "geo" : { },
    "id_str" : "318514026843881472",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc one reason why Stevie, one! No one in this world have minds like we do! Personally I think we're genius!",
    "id" : 318514026843881472,
    "in_reply_to_status_id" : 318513701927919616,
    "created_at" : "2013-04-01 00:03:56 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 318681120025767936,
  "created_at" : "2013-04-01 11:07:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus Christ",
      "screen_name" : "jesus",
      "indices" : [ 3, 9 ],
      "id_str" : "8943",
      "id" : 8943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318659665208688640",
  "text" : "RT @jesus: Hi.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318363395906744320",
    "text" : "Hi.",
    "id" : 318363395906744320,
    "created_at" : "2013-03-31 14:05:23 +0000",
    "user" : {
      "name" : "Jesus Christ",
      "screen_name" : "jesus",
      "protected" : false,
      "id_str" : "8943",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000436609149\/959a9ed0624216336e8d253aceb89e2b_normal.jpeg",
      "id" : 8943,
      "verified" : false
    }
  },
  "id" : 318659665208688640,
  "created_at" : "2013-04-01 09:42:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318513333261172736",
  "geo" : { },
  "id_str" : "318513701927919616",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 I miss you so much. No one goes toe to toe with me in my new place.",
  "id" : 318513701927919616,
  "in_reply_to_status_id" : 318513333261172736,
  "created_at" : "2013-04-01 00:02:38 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318513592129429504",
  "text" : "RT @HaVoCT5: @swmcc ai Geraldine loves her ring being filled with man gravy ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "318513094894682116",
    "geo" : { },
    "id_str" : "318513333261172736",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc ai Geraldine loves her ring being filled with man gravy ;)",
    "id" : 318513333261172736,
    "in_reply_to_status_id" : 318513094894682116,
    "created_at" : "2013-04-01 00:01:10 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 318513592129429504,
  "created_at" : "2013-04-01 00:02:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 3, 11 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HaVoCT5\/status\/318509897308315649\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/HM0JUQU95S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGuTEGcCIAATYxU.jpg",
      "id_str" : "318509897316704256",
      "id" : 318509897316704256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGuTEGcCIAATYxU.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HM0JUQU95S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318513563134218241",
  "text" : "RT @HaVoCT5: Reasons why I love my mother http:\/\/t.co\/HM0JUQU95S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HaVoCT5\/status\/318509897308315649\/photo\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/HM0JUQU95S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BGuTEGcCIAATYxU.jpg",
        "id_str" : "318509897316704256",
        "id" : 318509897316704256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGuTEGcCIAATYxU.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HM0JUQU95S"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318509897308315649",
    "text" : "Reasons why I love my mother http:\/\/t.co\/HM0JUQU95S",
    "id" : 318509897308315649,
    "created_at" : "2013-03-31 23:47:32 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "protected" : false,
      "id_str" : "152381157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2186760665\/1nYAcanB_normal",
      "id" : 152381157,
      "verified" : false
    }
  },
  "id" : 318513563134218241,
  "created_at" : "2013-04-01 00:02:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "HaVoCT5",
      "indices" : [ 0, 8 ],
      "id_str" : "152381157",
      "id" : 152381157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318509897308315649",
  "geo" : { },
  "id_str" : "318513094894682116",
  "in_reply_to_user_id" : 152381157,
  "text" : "@HaVoCT5 i love your mother too and it involves gravy rings as well",
  "id" : 318513094894682116,
  "in_reply_to_status_id" : 318509897308315649,
  "created_at" : "2013-04-01 00:00:14 +0000",
  "in_reply_to_screen_name" : "HaVoCT5",
  "in_reply_to_user_id_str" : "152381157",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]