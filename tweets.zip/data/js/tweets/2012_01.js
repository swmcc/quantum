Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 0, 9 ],
      "id_str" : "20543444",
      "id" : 20543444
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 10, 24 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164435370069606400",
  "geo" : { },
  "id_str" : "164436538447511552",
  "in_reply_to_user_id" : 20543444,
  "text" : "@HerrWulf @no_underscore I stand by it :)",
  "id" : 164436538447511552,
  "in_reply_to_status_id" : 164435370069606400,
  "created_at" : "2012-01-31 19:55:00 +0000",
  "in_reply_to_screen_name" : "HerrWulf",
  "in_reply_to_user_id_str" : "20543444",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 99, 111 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164430411836043265",
  "geo" : { },
  "id_str" : "164435105237041152",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore fine your loss. My mateship comes with benefits ;) Guess I'll find someone else \/cc @stimpled0rf",
  "id" : 164435105237041152,
  "in_reply_to_status_id" : 164430411836043265,
  "created_at" : "2012-01-31 19:49:18 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164420392692363264",
  "text" : "So Fred Godwin lost his knighthood but retains his 700k a year pension. I know which one I would care about more ;)",
  "id" : 164420392692363264,
  "created_at" : "2012-01-31 18:50:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164382209405493249",
  "geo" : { },
  "id_str" : "164382399621373952",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Not. Fucking. Fair.",
  "id" : 164382399621373952,
  "in_reply_to_status_id" : 164382209405493249,
  "created_at" : "2012-01-31 16:19:52 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164359887177003008",
  "geo" : { },
  "id_str" : "164381877468278784",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll unfair good looking female advantage... Not fair - equal rights.. If that'd been me he would have charged me full whack!",
  "id" : 164381877468278784,
  "in_reply_to_status_id" : 164359887177003008,
  "created_at" : "2012-01-31 16:17:48 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164096668428533760",
  "text" : "I then turn into a pig and she kills me... Fin... Now that wasn't as odd as the time I dreamt I was a drug mule for Prospect Joe...",
  "id" : 164096668428533760,
  "created_at" : "2012-01-30 21:24:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164096420159291392",
  "text" : "And they refuse... The young woman says she won't wash them for me as I am a racist cos I don't like Lucy Lui...",
  "id" : 164096420159291392,
  "created_at" : "2012-01-30 21:23:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164096196741304320",
  "text" : "Anyway I let them stay there for free on the condition that they do the odd bit if laundry for me.. I try and get a few suits cleaned...",
  "id" : 164096196741304320,
  "created_at" : "2012-01-30 21:22:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164095982798249984",
  "text" : "Lo and behold an Asian family has moved in.. They are opening up a Chinese laundry (tad racist - but it was a dream)....",
  "id" : 164095982798249984,
  "created_at" : "2012-01-30 21:21:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164095764136595457",
  "text" : "Dreamt that I heard noise coming from the back room downstairs that I am currently doing up... I go downstairs to investigate...",
  "id" : 164095764136595457,
  "created_at" : "2012-01-30 21:20:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164095550709436416",
  "text" : "So every time I get this leg thing I get really weird dreams with the fever. This time was especially weird....",
  "id" : 164095550709436416,
  "created_at" : "2012-01-30 21:20:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Phil McClure",
      "screen_name" : "overture8",
      "indices" : [ 14, 24 ],
      "id_str" : "19857364",
      "id" : 19857364
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 25, 37 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164068572858040320",
  "geo" : { },
  "id_str" : "164069623103369217",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @overture8 @belfastruby sky+ it. Am sick. Blame Steve - his fault - he took me up cave hill on Sunday :)",
  "id" : 164069623103369217,
  "in_reply_to_status_id" : 164068572858040320,
  "created_at" : "2012-01-30 19:37:01 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163302293725388801",
  "geo" : { },
  "id_str" : "163341570471501825",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne brilliant on your gold :) Congrats.",
  "id" : 163341570471501825,
  "in_reply_to_status_id" : 163302293725388801,
  "created_at" : "2012-01-28 19:23:59 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 13, 28 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163326194698305536",
  "geo" : { },
  "id_str" : "163341242141384704",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @georgina_milne pineapple :(",
  "id" : 163341242141384704,
  "in_reply_to_status_id" : 163326194698305536,
  "created_at" : "2012-01-28 19:22:41 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 13, 28 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163288371895083008",
  "geo" : { },
  "id_str" : "163289609638391808",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @georgina_milne pineapple has no use. Just give in and accept it.",
  "id" : 163289609638391808,
  "in_reply_to_status_id" : 163288371895083008,
  "created_at" : "2012-01-28 15:57:31 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163276126981074944",
  "geo" : { },
  "id_str" : "163289301675819008",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I don't like football... Does that scupper my chances? ;)",
  "id" : 163289301675819008,
  "in_reply_to_status_id" : 163276126981074944,
  "created_at" : "2012-01-28 15:56:17 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kurt sutter",
      "screen_name" : "sutterink",
      "indices" : [ 3, 13 ],
      "id_str" : "21741551",
      "id" : 21741551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163289139326889984",
  "text" : "RT @sutterink: closed my deal for 3 more years on SOA. no headlines, no pushed schedule, no stealing from paul. thank you FX and 20th fo ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "163275286480306176",
    "text" : "closed my deal for 3 more years on SOA. no headlines, no pushed schedule, no stealing from paul. thank you FX and 20th for your generosity.",
    "id" : 163275286480306176,
    "created_at" : "2012-01-28 15:00:36 +0000",
    "user" : {
      "name" : "kurt sutter",
      "screen_name" : "sutterink",
      "protected" : false,
      "id_str" : "21741551",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1501459089\/index_normal.jpg",
      "id" : 21741551,
      "verified" : true
    }
  },
  "id" : 163289139326889984,
  "created_at" : "2012-01-28 15:55:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Harrison",
      "screen_name" : "chrisjharrison",
      "indices" : [ 3, 18 ],
      "id_str" : "21396852",
      "id" : 21396852
    }, {
      "name" : "Basil McCrea",
      "screen_name" : "basilmccrea",
      "indices" : [ 20, 32 ],
      "id_str" : "42041977",
      "id" : 42041977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163288861085151232",
  "text" : "RT @chrisjharrison: @basilmccrea Yep. NI has an effective fiscal deficit much bigger than Greece's. In fact, about 2.5 times Greece's wh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basil McCrea",
        "screen_name" : "basilmccrea",
        "indices" : [ 0, 12 ],
        "id_str" : "42041977",
        "id" : 42041977
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "163268535303413760",
    "geo" : { },
    "id_str" : "163270330658467840",
    "in_reply_to_user_id" : 42041977,
    "text" : "@basilmccrea Yep. NI has an effective fiscal deficit much bigger than Greece's. In fact, about 2.5 times Greece's when it sought IMF bailout",
    "id" : 163270330658467840,
    "in_reply_to_status_id" : 163268535303413760,
    "created_at" : "2012-01-28 14:40:54 +0000",
    "in_reply_to_screen_name" : "basilmccrea",
    "in_reply_to_user_id_str" : "42041977",
    "user" : {
      "name" : "Chris Harrison",
      "screen_name" : "chrisjharrison",
      "protected" : false,
      "id_str" : "21396852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000555804657\/f56676ed513f506d8940a9b8529eb32c_normal.jpeg",
      "id" : 21396852,
      "verified" : false
    }
  },
  "id" : 163288861085151232,
  "created_at" : "2012-01-28 15:54:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163288807733604353",
  "text" : "\"In 09 NI spent \u00A321b but only raised \u00A312b in tax revenue meaning a huge subventions from Westminster govt.\" We be fucked is the tech term.",
  "id" : 163288807733604353,
  "created_at" : "2012-01-28 15:54:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 13, 28 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163267329910779905",
  "geo" : { },
  "id_str" : "163287942457077760",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @georgina_milne you are wrong on both counts you beautiful Dutch bastard! What is this a citi gang up? Pineapple is wrong. Fact",
  "id" : 163287942457077760,
  "in_reply_to_status_id" : 163267329910779905,
  "created_at" : "2012-01-28 15:50:53 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 16, 28 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163258630731345920",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @willemkokke pineapple has no place on anything ever! Fact. You get over it!",
  "id" : 163258630731345920,
  "created_at" : "2012-01-28 13:54:25 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163177931831652352",
  "geo" : { },
  "id_str" : "163257345391067136",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit yup yup. What time?",
  "id" : 163257345391067136,
  "in_reply_to_status_id" : 163177931831652352,
  "created_at" : "2012-01-28 13:49:18 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163032611336359938",
  "text" : "Why in the name of blue mercy fuck is their pineapple in this fruit salad....",
  "id" : 163032611336359938,
  "created_at" : "2012-01-27 22:56:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162981312930660353",
  "geo" : { },
  "id_str" : "162984480364171264",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues am gonna book move now....",
  "id" : 162984480364171264,
  "in_reply_to_status_id" : 162981312930660353,
  "created_at" : "2012-01-27 19:45:02 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162858763651522561",
  "text" : "I hate using Excel...",
  "id" : 162858763651522561,
  "created_at" : "2012-01-27 11:25:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162686589154246657",
  "text" : "The bald dude on This Week is freaking me out.",
  "id" : 162686589154246657,
  "created_at" : "2012-01-27 00:01:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162669601187049473",
  "geo" : { },
  "id_str" : "162680312361533441",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley of course not. I just had way too many cups of coffee today.",
  "id" : 162680312361533441,
  "in_reply_to_status_id" : 162669601187049473,
  "created_at" : "2012-01-26 23:36:23 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Croft",
      "screen_name" : "jcroft",
      "indices" : [ 3, 10 ],
      "id_str" : "25993",
      "id" : 25993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/h5yvCCRP",
      "expanded_url" : "http:\/\/j.mp\/y2JKc0",
      "display_url" : "j.mp\/y2JKc0"
    } ]
  },
  "geo" : { },
  "id_str" : "162649216102055936",
  "text" : "RT @jcroft: Matt Drance succinctly nails the bottom line on piracy: http:\/\/t.co\/h5yvCCRP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/h5yvCCRP",
        "expanded_url" : "http:\/\/j.mp\/y2JKc0",
        "display_url" : "j.mp\/y2JKc0"
      } ]
    },
    "geo" : { },
    "id_str" : "162644715395756033",
    "text" : "Matt Drance succinctly nails the bottom line on piracy: http:\/\/t.co\/h5yvCCRP",
    "id" : 162644715395756033,
    "created_at" : "2012-01-26 21:14:56 +0000",
    "user" : {
      "name" : "Jeff Croft",
      "screen_name" : "jcroft",
      "protected" : false,
      "id_str" : "25993",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1316515953\/twitter_profile_normal.jpg",
      "id" : 25993,
      "verified" : false
    }
  },
  "id" : 162649216102055936,
  "created_at" : "2012-01-26 21:32:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162644923315781632",
  "geo" : { },
  "id_str" : "162645446421004288",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley still going strong..",
  "id" : 162645446421004288,
  "in_reply_to_status_id" : 162644923315781632,
  "created_at" : "2012-01-26 21:17:50 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162640543451578368",
  "text" : "Three loads of washing done so far. My feral streak has now come to an end. Hell I might even shower and shave later!",
  "id" : 162640543451578368,
  "created_at" : "2012-01-26 20:58:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "NicolaGrahamPlunkett",
      "screen_name" : "Nikkinoodles99",
      "indices" : [ 10, 25 ],
      "id_str" : "389093092",
      "id" : 389093092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162629883271462912",
  "geo" : { },
  "id_str" : "162630211769352192",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @nikkinoodles99 dunno if the mrs will see this so tell her I'll accept her when I get near a computer. iPhone won't let me do it.",
  "id" : 162630211769352192,
  "in_reply_to_status_id" : 162629883271462912,
  "created_at" : "2012-01-26 20:17:18 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162608568506392576",
  "geo" : { },
  "id_str" : "162626635470876672",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley Dunno. No coke ya see....",
  "id" : 162626635470876672,
  "in_reply_to_status_id" : 162608568506392576,
  "created_at" : "2012-01-26 20:03:06 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162587275887255552",
  "geo" : { },
  "id_str" : "162607999318372352",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues your tax on a rolling monthly debit as they know you are taxed and insured. Just winds me up!",
  "id" : 162607999318372352,
  "in_reply_to_status_id" : 162587275887255552,
  "created_at" : "2012-01-26 18:49:02 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162587275887255552",
  "geo" : { },
  "id_str" : "162607783634681856",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues I hate the tax hassle. Car test is fine as they need to inspect it. But there is no earthly reason that they can't take...",
  "id" : 162607783634681856,
  "in_reply_to_status_id" : 162587275887255552,
  "created_at" : "2012-01-26 18:48:11 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162604001496547328",
  "geo" : { },
  "id_str" : "162607279412232193",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @peter_omalley nope. But my mum and sis were watching Bridesmaids when I was over so I watched that fit a bit.",
  "id" : 162607279412232193,
  "in_reply_to_status_id" : 162604001496547328,
  "created_at" : "2012-01-26 18:46:11 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "caffeine",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162600458232406017",
  "geo" : { },
  "id_str" : "162607073698390016",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley I've fed my patents dog, made my dad his tea, put on a wash at mine and my dinner is in the oven. #caffeine rush",
  "id" : 162607073698390016,
  "in_reply_to_status_id" : 162600458232406017,
  "created_at" : "2012-01-26 18:45:22 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162578247970856960",
  "text" : "I've given up coke... But you should see the amount of coffee\/tea I drink now....",
  "id" : 162578247970856960,
  "created_at" : "2012-01-26 16:50:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162550222818525184",
  "geo" : { },
  "id_str" : "162550322588430336",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues FUCK!!!! I should get that MOT test date!!!!!! AHHHHHH!!!!!!",
  "id" : 162550322588430336,
  "in_reply_to_status_id" : 162550222818525184,
  "created_at" : "2012-01-26 14:59:51 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 15, 27 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162244662143356928",
  "geo" : { },
  "id_str" : "162263979538907136",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @stimpled0rf Think he gets a pass today.",
  "id" : 162263979538907136,
  "in_reply_to_status_id" : 162244662143356928,
  "created_at" : "2012-01-25 20:02:02 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162235196022865920",
  "text" : "Just came up for a short breath of fresh air... \/me gets down to it again... Ohhh happy fucking days.....",
  "id" : 162235196022865920,
  "created_at" : "2012-01-25 18:07:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161771458937364480",
  "text" : "Think the way things have been the past few weeks I've reverted to a feral state... Need to get shit back in order :)",
  "id" : 161771458937364480,
  "created_at" : "2012-01-24 11:24:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161550844737761281",
  "text" : "Turning my back room into a media room aka big fuck off cinema room. Sometimes being single is fucking sweet :)",
  "id" : 161550844737761281,
  "created_at" : "2012-01-23 20:48:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161550357338669056",
  "text" : "Am supposed to be asleep. Forgot that council coming to lift two armchairs, a two seated and a three sestet sofa and a fridge.",
  "id" : 161550357338669056,
  "created_at" : "2012-01-23 20:46:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 5, 18 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161388142291722240",
  "text" : "When @RickyHassard messages you on a Monday morning with the words \"balls...\" you just know your morning is gonna be crap :( Grrrrr :)",
  "id" : 161388142291722240,
  "created_at" : "2012-01-23 10:01:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161258491120590849",
  "geo" : { },
  "id_str" : "161271357299109888",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne :( I've had a crappy weekhend so am heading into work now to get caught up in a few things - beat that ;)",
  "id" : 161271357299109888,
  "in_reply_to_status_id" : 161258491120590849,
  "created_at" : "2012-01-23 02:17:42 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161174842098454529",
  "text" : "I hate Sunday evenings.",
  "id" : 161174842098454529,
  "created_at" : "2012-01-22 19:54:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161160722955513856",
  "geo" : { },
  "id_str" : "161161896840531969",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight was just on the tv and i recognised the dude in it. :)",
  "id" : 161161896840531969,
  "in_reply_to_status_id" : 161160722955513856,
  "created_at" : "2012-01-22 19:02:45 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "odd",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161131087672786944",
  "text" : "Only noticing now that Harry Conick jnr was in Independence Day. #odd",
  "id" : 161131087672786944,
  "created_at" : "2012-01-22 17:00:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161047894600859648",
  "geo" : { },
  "id_str" : "161067127770587136",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne I is in :)",
  "id" : 161067127770587136,
  "in_reply_to_status_id" : 161047894600859648,
  "created_at" : "2012-01-22 12:46:10 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 12, 27 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 47 ],
      "url" : "http:\/\/t.co\/Mwte4jR",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ViftZTfRSt8",
      "display_url" : "youtube.com\/watch?v=ViftZT\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "161048332763017217",
  "geo" : { },
  "id_str" : "161067101254205440",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin @Georgina_Milne http:\/\/t.co\/Mwte4jR - awesome.",
  "id" : 161067101254205440,
  "in_reply_to_status_id" : 161048332763017217,
  "created_at" : "2012-01-22 12:46:04 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160839246834442240",
  "geo" : { },
  "id_str" : "161035360988696576",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne Wow - you remember the film of the labyrinth? I haven't met anyone that has ever seen that film too! It was class!",
  "id" : 161035360988696576,
  "in_reply_to_status_id" : 160839246834442240,
  "created_at" : "2012-01-22 10:39:56 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160828663615598593",
  "text" : "...... Labyrinth come in.......",
  "id" : 160828663615598593,
  "created_at" : "2012-01-21 20:58:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160823118695370752",
  "geo" : { },
  "id_str" : "160823961519783936",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke BDB - Beautiful Dutch Bastard :)",
  "id" : 160823961519783936,
  "in_reply_to_status_id" : 160823118695370752,
  "created_at" : "2012-01-21 20:39:55 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160813958633238529",
  "text" : "Epic afternoon nap there... Awesome. Four hours :) Zzzzzz",
  "id" : 160813958633238529,
  "created_at" : "2012-01-21 20:00:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160673665476853760",
  "text" : "...and just downloaded the latest clone wars cartoon to watch while having ma breakfast :)",
  "id" : 160673665476853760,
  "created_at" : "2012-01-21 10:42:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160672583606468608",
  "text" : "Have to go fridge hunting today... But all I've done so far is watch 5 episodes of Cougar Town.. It is funny dammit!!!!",
  "id" : 160672583606468608,
  "created_at" : "2012-01-21 10:38:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160651960419237888",
  "geo" : { },
  "id_str" : "160671054312914944",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll You might want help maintaining the biological diversity of tropical ecosystems? Dunno if Tesco do them though....",
  "id" : 160671054312914944,
  "in_reply_to_status_id" : 160651960419237888,
  "created_at" : "2012-01-21 10:32:19 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160508557551349760",
  "text" : "Just watched J. Edgar... A bit messy I think. Hopefully the Underworld film will be as bad-good as I think it will be :)",
  "id" : 160508557551349760,
  "created_at" : "2012-01-20 23:46:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160494749827076096",
  "geo" : { },
  "id_str" : "160508032999100416",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp awesome :D",
  "id" : 160508032999100416,
  "in_reply_to_status_id" : 160494749827076096,
  "created_at" : "2012-01-20 23:44:31 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160470106785320960",
  "geo" : { },
  "id_str" : "160488783379304448",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley :) Fat bastard :)",
  "id" : 160488783379304448,
  "in_reply_to_status_id" : 160470106785320960,
  "created_at" : "2012-01-20 22:28:02 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160442960889126912",
  "geo" : { },
  "id_str" : "160480243222720512",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight him and as long as we say \"On your head son\" he has to head butt it. If he loses his cards during a working week he buys",
  "id" : 160480243222720512,
  "in_reply_to_status_id" : 160442960889126912,
  "created_at" : "2012-01-20 21:54:06 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160442960889126912",
  "geo" : { },
  "id_str" : "160480025383157760",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight man challenge. If he fulfils this challenge he gets a man card back. Next weeks one is that we can throw something at..",
  "id" : 160480025383157760,
  "in_reply_to_status_id" : 160442960889126912,
  "created_at" : "2012-01-20 21:53:14 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160442960889126912",
  "geo" : { },
  "id_str" : "160479347713646593",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight we gave a fella in work 4 man cards. He loses one everytime he does or says something unmanly. He also has a weekly...",
  "id" : 160479347713646593,
  "in_reply_to_status_id" : 160442960889126912,
  "created_at" : "2012-01-20 21:50:32 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 25, 37 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160417442592600065",
  "text" : "Feel guilty for breaking @stimpled0rf today. But he started by showing contempt for the Friday karma gods.... Idiot :)",
  "id" : 160417442592600065,
  "created_at" : "2012-01-20 17:44:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 33, 45 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 78, 91 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160393035795021825",
  "text" : "And with 30mins left in the week @stimpled0rf loses his last man card.... \/cc @RickyHassard - he almost wept as I took it away too! :)",
  "id" : 160393035795021825,
  "created_at" : "2012-01-20 16:07:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 5, 17 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 22, 34 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160390077325914112",
  "text" : "Both @niall_adams and @stimpled0rf have destroyed my friday afternoon buzz... Fucking idiots!!",
  "id" : 160390077325914112,
  "created_at" : "2012-01-20 15:55:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160381324929150976",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf today has been a good day - working like a boss as the kidz would say! :D",
  "id" : 160381324929150976,
  "created_at" : "2012-01-20 15:21:02 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160360089579032576",
  "geo" : { },
  "id_str" : "160361080089096192",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll nerd-tastic :)",
  "id" : 160361080089096192,
  "in_reply_to_status_id" : 160360089579032576,
  "created_at" : "2012-01-20 14:00:35 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 106 ],
      "url" : "http:\/\/t.co\/IlMfNdd",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-northern-ireland-16645597",
      "display_url" : "bbc.co.uk\/news\/uk-northe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "160325554854313984",
  "text" : "This is heart breaking. You think you have problems in your life until you read this - http:\/\/t.co\/IlMfNdd :(",
  "id" : 160325554854313984,
  "created_at" : "2012-01-20 11:39:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160323261257879552",
  "text" : "That feeling you get when someone uses a big word in work to describe someone - and you can't use google define as you can't even spell it!",
  "id" : 160323261257879552,
  "created_at" : "2012-01-20 11:30:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sneakyweebitch",
      "indices" : [ 80, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160317880230092802",
  "text" : "extension=\/usr\/local\/php5\/lib\/php\/extensions\/no-debug-non-zts-20090626\/pgsql.so #sneakyweebitch",
  "id" : 160317880230092802,
  "created_at" : "2012-01-20 11:08:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 15, 27 ],
      "id_str" : "226910307",
      "id" : 226910307
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 28, 42 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160133331659407360",
  "geo" : { },
  "id_str" : "160133985807253504",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @ryancunning @peter_omalley well thats good. Hopefully drugs clear it up. Get well soon nerdo :)",
  "id" : 160133985807253504,
  "in_reply_to_status_id" : 160133331659407360,
  "created_at" : "2012-01-19 22:58:12 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 30, 42 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160126257072316418",
  "geo" : { },
  "id_str" : "160128051970195457",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley @ryancunning oh dear :( I wouldn't wish that on anyone... Made an emergency appointment tomorrow?",
  "id" : 160128051970195457,
  "in_reply_to_status_id" : 160126257072316418,
  "created_at" : "2012-01-19 22:34:37 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160099567914852352",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg at gays was supposed to \"that's why\". I give up. You win. Bastard :)",
  "id" : 160099567914852352,
  "created_at" : "2012-01-19 20:41:26 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160096924115017728",
  "geo" : { },
  "id_str" : "160098892313133057",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg at gays why you get paid the big bucks. I like being refreshed and sober in work ;)",
  "id" : 160098892313133057,
  "in_reply_to_status_id" : 160096924115017728,
  "created_at" : "2012-01-19 20:38:45 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 31 ],
      "url" : "http:\/\/t.co\/T1nuqxk",
      "expanded_url" : "http:\/\/www.troublefixers.com\/apple-mobile-device-service-not-started\/",
      "display_url" : "troublefixers.com\/apple-mobile-d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "160023874782769154",
  "geo" : { },
  "id_str" : "160024176227385344",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa http:\/\/t.co\/T1nuqxk",
  "id" : 160024176227385344,
  "in_reply_to_status_id" : 160023874782769154,
  "created_at" : "2012-01-19 15:41:51 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160023708520546305",
  "geo" : { },
  "id_str" : "160023815307534336",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa what version of windaes?",
  "id" : 160023815307534336,
  "in_reply_to_status_id" : 160023708520546305,
  "created_at" : "2012-01-19 15:40:25 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160023422695514112",
  "geo" : { },
  "id_str" : "160023633669001218",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa you need admin privs on your machine first, you got 'em?",
  "id" : 160023633669001218,
  "in_reply_to_status_id" : 160023422695514112,
  "created_at" : "2012-01-19 15:39:42 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 15, 27 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 28, 40 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160016963572215808",
  "geo" : { },
  "id_str" : "160018906197655552",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @niall_adams @stimpled0rf what the fuck is all this badge talk. I am working dammit!",
  "id" : 160018906197655552,
  "in_reply_to_status_id" : 160016963572215808,
  "created_at" : "2012-01-19 15:20:54 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 1, 13 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 37, 49 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160009044973727744",
  "text" : "\u201C@stimpled0rf: We've managed to make @niall_adams into our smoothie making bitch. This pleases me greatly.\u201D Awesome smoothie....",
  "id" : 160009044973727744,
  "created_at" : "2012-01-19 14:41:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160006956487159811",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg will hit it out of the park tomorrow. have to.",
  "id" : 160006956487159811,
  "created_at" : "2012-01-19 14:33:25 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160004625565614081",
  "geo" : { },
  "id_str" : "160006875113459712",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg aye.. well with only 3hrs sleep I wouldn't trust my judgement on anything major today so am doing some housekeeping stuffs.",
  "id" : 160006875113459712,
  "in_reply_to_status_id" : 160004625565614081,
  "created_at" : "2012-01-19 14:33:06 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159997345197592576",
  "geo" : { },
  "id_str" : "159997736962371586",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg very funny dickhead :) 3hrs sleep last night and I aint a kid anymore... Most. Unproductive. Day. Ever. And that's saying something!",
  "id" : 159997736962371586,
  "in_reply_to_status_id" : 159997345197592576,
  "created_at" : "2012-01-19 13:56:47 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159988561079320576",
  "text" : "It is offical. I be fucked.",
  "id" : 159988561079320576,
  "created_at" : "2012-01-19 13:20:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159976491294269440",
  "geo" : { },
  "id_str" : "159984532437741568",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @niall_adams he hasn't done it yet. I think he lied to me... The heartless bastard!",
  "id" : 159984532437741568,
  "in_reply_to_status_id" : 159976491294269440,
  "created_at" : "2012-01-19 13:04:19 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 3, 10 ],
      "id_str" : "60141834",
      "id" : 60141834
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 29, 41 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159972288572301312",
  "text" : "Yo @padzor was explaining to @stimpled0rf when we first met. Damian Conway talk - you were behind me - fucking me off - remember? ;)",
  "id" : 159972288572301312,
  "created_at" : "2012-01-19 12:15:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 1, 13 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 15, 21 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159971050799636481",
  "text" : "\u201C@stimpled0rf: @swmcc whilst it made me feel good when you said that you'd 'do me' that does knock down your class by another 5%\u2026\u201D",
  "id" : 159971050799636481,
  "created_at" : "2012-01-19 12:10:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 20, 32 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159966268269670400",
  "text" : "Just found out that @stimpled0rf is about 5% classier than me...",
  "id" : 159966268269670400,
  "created_at" : "2012-01-19 11:51:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159950323862077440",
  "text" : "Getting a segmentation fault on my apache build.... This is not good :(",
  "id" : 159950323862077440,
  "created_at" : "2012-01-19 10:48:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 9, 21 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159944937679491073",
  "text" : "Awesome. @niall_adams is gonna sing me 'Soft Kitty' - cos i only got 3 hours sleep last night and am technically a zombie right now!",
  "id" : 159944937679491073,
  "created_at" : "2012-01-19 10:26:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 101, 113 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159913384983269377",
  "geo" : { },
  "id_str" : "159915810587021313",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley I've seen Casino... You'll end up getting beat to death in a corn field. Bit like how @stimpled0rf fucked himself re: 2moro!",
  "id" : 159915810587021313,
  "in_reply_to_status_id" : 159913384983269377,
  "created_at" : "2012-01-19 08:31:14 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 1, 15 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159912946628173824",
  "text" : "\u201C@peter_omalley: Peter 1 Care 0. Yes!!\u201D This will not do... The house always wins.. Always...",
  "id" : 159912946628173824,
  "created_at" : "2012-01-19 08:19:52 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159911515707813888",
  "geo" : { },
  "id_str" : "159912735268802560",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley explain. And be gentle. I couldn't get to sleep last night so am on three hours sleep :(",
  "id" : 159912735268802560,
  "in_reply_to_status_id" : 159911515707813888,
  "created_at" : "2012-01-19 08:19:01 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 114, 128 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159760028969086976",
  "text" : "Banana on toast with milk will have to do then :) Made it through my first day without any coke! I can do it! \/cc @jenporterhall",
  "id" : 159760028969086976,
  "created_at" : "2012-01-18 22:12:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159759840485449730",
  "text" : "Forgot to leave my dinner out of the freezer (it works) to thaw.. Back about an hour now only realised there now. Fuck!",
  "id" : 159759840485449730,
  "created_at" : "2012-01-18 22:11:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159758432407261184",
  "text" : "Newzbin went black today I found... At least I am up front about  my lack of ethics. What you see is what you get ;)",
  "id" : 159758432407261184,
  "created_at" : "2012-01-18 22:05:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159708743641210880",
  "text" : "Didn't know it was insult till then....",
  "id" : 159708743641210880,
  "created_at" : "2012-01-18 18:48:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159708695696121856",
  "text" : "I explained that it has its mot next month and then was asked in a semi question\/statement \"So it can do over 40?\".",
  "id" : 159708695696121856,
  "created_at" : "2012-01-18 18:48:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159707469000617985",
  "text" : "\"Is your car okay?\" Cheekiest insult ever!",
  "id" : 159707469000617985,
  "created_at" : "2012-01-18 18:43:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft Encarta",
      "screen_name" : "Encarta95",
      "indices" : [ 3, 13 ],
      "id_str" : "403901932",
      "id" : 403901932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159686743019360256",
  "text" : "RT @Encarta95: It's my time! Finally, my shot at the spotlight! It's only taken me seventeen years! Wikipedia? Who needs it! Encarta '95 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159526112563695616",
    "text" : "It's my time! Finally, my shot at the spotlight! It's only taken me seventeen years! Wikipedia? Who needs it! Encarta '95 is here to stay.",
    "id" : 159526112563695616,
    "created_at" : "2012-01-18 06:42:43 +0000",
    "user" : {
      "name" : "Microsoft Encarta",
      "screen_name" : "Encarta95",
      "protected" : false,
      "id_str" : "403901932",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1619984023\/PC_Encarta95_normal.jpg",
      "id" : 403901932,
      "verified" : false
    }
  },
  "id" : 159686743019360256,
  "created_at" : "2012-01-18 17:21:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159665441881587712",
  "geo" : { },
  "id_str" : "159668718434127872",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb alright liverpool fan",
  "id" : 159668718434127872,
  "in_reply_to_status_id" : 159665441881587712,
  "created_at" : "2012-01-18 16:09:23 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159663117540917249",
  "text" : "Things that wind me up #1 People assuming I like Star Trek just cos I am a programmer.",
  "id" : 159663117540917249,
  "created_at" : "2012-01-18 15:47:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159662444963303424",
  "geo" : { },
  "id_str" : "159662782487330816",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus that was for the star trek reference... Its now personal - see at the Ruby meet up - its you and me... No need..",
  "id" : 159662782487330816,
  "in_reply_to_status_id" : 159662444963303424,
  "created_at" : "2012-01-18 15:45:48 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159662444963303424",
  "geo" : { },
  "id_str" : "159662556217212928",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus cunt.",
  "id" : 159662556217212928,
  "in_reply_to_status_id" : 159662444963303424,
  "created_at" : "2012-01-18 15:44:54 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "suckitbitch",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159661924118839297",
  "text" : "Things that wind me up #456 - Arse wipes aka (@bkgStatus) that think I am ancient cos I like shell access for db admin and use. #suckitbitch",
  "id" : 159661924118839297,
  "created_at" : "2012-01-18 15:42:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 11, 22 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Stuart Gibson",
      "screen_name" : "stuartgibson",
      "indices" : [ 23, 36 ],
      "id_str" : "6806292",
      "id" : 6806292
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 37, 50 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159661449445244928",
  "geo" : { },
  "id_str" : "159661611739656192",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus @johngirvin @stuartgibson @stevebiscuit fucking. wusses. fact. Nothing wrong with just shell access.. It works just as well.",
  "id" : 159661611739656192,
  "in_reply_to_status_id" : 159661449445244928,
  "created_at" : "2012-01-18 15:41:09 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 11, 22 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Stuart Gibson",
      "screen_name" : "stuartgibson",
      "indices" : [ 23, 36 ],
      "id_str" : "6806292",
      "id" : 6806292
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 37, 50 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159660557060943872",
  "geo" : { },
  "id_str" : "159661110100901888",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus @johngirvin @stuartgibson @stevebiscuit not punchcards... You lot are just fucking wusses.",
  "id" : 159661110100901888,
  "in_reply_to_status_id" : 159660557060943872,
  "created_at" : "2012-01-18 15:39:09 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159660996452024322",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin You probably know this but Textmate is lovely.",
  "id" : 159660996452024322,
  "created_at" : "2012-01-18 15:38:42 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159659689083289601",
  "geo" : { },
  "id_str" : "159659890250493952",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin I still use shell for all that stuffs. I might be old fashioned though. I don't mind GUI's but for db stuff I still &lt;3 shell.",
  "id" : 159659890250493952,
  "in_reply_to_status_id" : 159659689083289601,
  "created_at" : "2012-01-18 15:34:18 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159659061699297281",
  "geo" : { },
  "id_str" : "159659253773254656",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin MySQL GUI????? dude....... :D If its phpmyadmin i am gonna start crying.",
  "id" : 159659253773254656,
  "in_reply_to_status_id" : 159659061699297281,
  "created_at" : "2012-01-18 15:31:47 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159657427678150656",
  "geo" : { },
  "id_str" : "159658304056995844",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke details you beautiful dutch bastard... details....",
  "id" : 159658304056995844,
  "in_reply_to_status_id" : 159657427678150656,
  "created_at" : "2012-01-18 15:28:00 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159641296204595201",
  "text" : "You know you've got stupid internet bandwidth at home when you have to 'wait' for a download at work. 115mb zip - 12mins... WTF!",
  "id" : 159641296204595201,
  "created_at" : "2012-01-18 14:20:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wikipediablackout",
      "indices" : [ 10, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/cdQCTu4",
      "expanded_url" : "http:\/\/tinyurl.com\/7vq4o8g",
      "display_url" : "tinyurl.com\/7vq4o8g"
    } ]
  },
  "geo" : { },
  "id_str" : "159633830116982784",
  "text" : "I support #wikipediablackout! Show your support here http:\/\/t.co\/cdQCTu4",
  "id" : 159633830116982784,
  "created_at" : "2012-01-18 13:50:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darren Clarke",
      "screen_name" : "DarrenClarke60",
      "indices" : [ 1, 16 ],
      "id_str" : "249154446",
      "id" : 249154446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159618309057294336",
  "text" : "\u201C@DarrenClarke60: Wow....what a golf course!!! First time I've ever played a course that the standard scratch for me is 79!! ;-)\u201D",
  "id" : 159618309057294336,
  "created_at" : "2012-01-18 12:49:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mar\u00EDa Basia ",
      "screen_name" : "maria_basia",
      "indices" : [ 0, 12 ],
      "id_str" : "235508724",
      "id" : 235508724
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 35, 49 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159591955104411648",
  "geo" : { },
  "id_str" : "159592933933326336",
  "in_reply_to_user_id" : 235508724,
  "text" : "@maria_basia we will see... I have @jenporterhall to stop me doing it during work hours... Big test will be Fri and weekend.",
  "id" : 159592933933326336,
  "in_reply_to_status_id" : 159591955104411648,
  "created_at" : "2012-01-18 11:08:15 +0000",
  "in_reply_to_screen_name" : "maria_basia",
  "in_reply_to_user_id_str" : "235508724",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mar\u00EDa Basia ",
      "screen_name" : "maria_basia",
      "indices" : [ 0, 12 ],
      "id_str" : "235508724",
      "id" : 235508724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159590684276424704",
  "geo" : { },
  "id_str" : "159591333428862976",
  "in_reply_to_user_id" : 235508724,
  "text" : "@maria_basia Fat coke of course :)",
  "id" : 159591333428862976,
  "in_reply_to_status_id" : 159590684276424704,
  "created_at" : "2012-01-18 11:01:53 +0000",
  "in_reply_to_screen_name" : "maria_basia",
  "in_reply_to_user_id_str" : "235508724",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swmccnomorecoke",
      "indices" : [ 62, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159589812771364864",
  "text" : "Day 1 of no coke... Its 10:55 and its already fucking shit... #swmccnomorecoke",
  "id" : 159589812771364864,
  "created_at" : "2012-01-18 10:55:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 0, 10 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159578409553502208",
  "geo" : { },
  "id_str" : "159579033519132673",
  "in_reply_to_user_id" : 9713742,
  "text" : "@Burkazoid I can't wait until someone else bald starts here - then I have a fellow baldy to take the discrimination.",
  "id" : 159579033519132673,
  "in_reply_to_status_id" : 159578409553502208,
  "created_at" : "2012-01-18 10:13:01 +0000",
  "in_reply_to_screen_name" : "Burkazoid",
  "in_reply_to_user_id_str" : "9713742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159551596747964416",
  "geo" : { },
  "id_str" : "159578779528859648",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight :D I love the man - huge man crush on him.",
  "id" : 159578779528859648,
  "in_reply_to_status_id" : 159551596747964416,
  "created_at" : "2012-01-18 10:12:00 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159533357926064129",
  "geo" : { },
  "id_str" : "159550991744778240",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight was his 70th birthday yesterday.",
  "id" : 159550991744778240,
  "in_reply_to_status_id" : 159533357926064129,
  "created_at" : "2012-01-18 08:21:35 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159401441440698370",
  "text" : "... he is still a brilliant human being though. Easily the best champion in history. His politics is irrelevant to me. Best champion.",
  "id" : 159401441440698370,
  "created_at" : "2012-01-17 22:27:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159400851318902784",
  "text" : "It's breaking my heart to see Ali like he is now. I know there are worse things out there like. Best champion ever...",
  "id" : 159400851318902784,
  "created_at" : "2012-01-17 22:24:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/159367451723837441\/photo\/1",
      "indices" : [ 39, 58 ],
      "url" : "http:\/\/t.co\/zsfWph7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjYv2l0CMAAhJpe.jpg",
      "id_str" : "159367451728031744",
      "id" : 159367451728031744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjYv2l0CMAAhJpe.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zsfWph7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159367451723837441",
  "text" : "Everyone looking at assholes phone.... http:\/\/t.co\/zsfWph7",
  "id" : 159367451723837441,
  "created_at" : "2012-01-17 20:12:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 108, 121 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159227965228584960",
  "geo" : { },
  "id_str" : "159231070414438400",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus my old xbox is just too loud (1st gen 360) - don't have a PS3. Thinking of media pc on advice of @RickyHassard",
  "id" : 159231070414438400,
  "in_reply_to_status_id" : 159227965228584960,
  "created_at" : "2012-01-17 11:10:20 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159227432681996289",
  "geo" : { },
  "id_str" : "159227660743098368",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit yes! :) We are sick and aren't afraid to admit it!! *CRACK*",
  "id" : 159227660743098368,
  "in_reply_to_status_id" : 159227432681996289,
  "created_at" : "2012-01-17 10:56:47 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 32, 42 ],
      "id_str" : "212603717",
      "id" : 212603717
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 43, 57 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159220594490097664",
  "text" : "Right so for the kicking i have @carisenda @No_Underscore and me... I think the three of us could take those free loading hippies! :D",
  "id" : 159220594490097664,
  "created_at" : "2012-01-17 10:28:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159219988341850112",
  "geo" : { },
  "id_str" : "159220248313217024",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore so its you and me then? :)",
  "id" : 159220248313217024,
  "in_reply_to_status_id" : 159219988341850112,
  "created_at" : "2012-01-17 10:27:20 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 0, 14 ],
      "id_str" : "49953918",
      "id" : 49953918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159218488920125442",
  "geo" : { },
  "id_str" : "159219957991870465",
  "in_reply_to_user_id" : 49953918,
  "text" : "@RickTheJackal think that mightbe your best bet. There was one down the lisburn rd... Think its gone now though",
  "id" : 159219957991870465,
  "in_reply_to_status_id" : 159218488920125442,
  "created_at" : "2012-01-17 10:26:10 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159219039271530496",
  "text" : "Is it just me or is anyone else getting the urge to go down to Belfast and batter those twats at Occupy Belfast?? Just me then..... okers :)",
  "id" : 159219039271530496,
  "created_at" : "2012-01-17 10:22:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 14, 29 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159211162339258368",
  "geo" : { },
  "id_str" : "159218368791064577",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @georgina_milne its not about you stephen :)",
  "id" : 159218368791064577,
  "in_reply_to_status_id" : 159211162339258368,
  "created_at" : "2012-01-17 10:19:51 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 0, 14 ],
      "id_str" : "49953918",
      "id" : 49953918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http:\/\/t.co\/lom47vh",
      "expanded_url" : "http:\/\/blickstudios.org\/",
      "display_url" : "blickstudios.org"
    } ]
  },
  "in_reply_to_status_id_str" : "159217873863192576",
  "geo" : { },
  "id_str" : "159218236297195520",
  "in_reply_to_user_id" : 49953918,
  "text" : "@RickTheJackal I think blickstudios offer such a thing. Their site seems to be fucked though http:\/\/t.co\/lom47vh",
  "id" : 159218236297195520,
  "in_reply_to_status_id" : 159217873863192576,
  "created_at" : "2012-01-17 10:19:20 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Craig",
      "screen_name" : "RickTheJackal",
      "indices" : [ 0, 14 ],
      "id_str" : "49953918",
      "id" : 49953918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159216461070606336",
  "geo" : { },
  "id_str" : "159217550125838336",
  "in_reply_to_user_id" : 49953918,
  "text" : "@RickTheJackal you going freelance again?",
  "id" : 159217550125838336,
  "in_reply_to_status_id" : 159216461070606336,
  "created_at" : "2012-01-17 10:16:36 +0000",
  "in_reply_to_screen_name" : "RickTheJackal",
  "in_reply_to_user_id_str" : "49953918",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Reich",
      "screen_name" : "i2pi",
      "indices" : [ 3, 8 ],
      "id_str" : "18246193",
      "id" : 18246193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/RcMZyLh8",
      "expanded_url" : "http:\/\/stopsoap.com\/",
      "display_url" : "stopsoap.com"
    } ]
  },
  "geo" : { },
  "id_str" : "159211961995894785",
  "text" : "RT @i2pi: It is about time that this issue is getting the attention it deserves. http:\/\/t.co\/RcMZyLh8",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/RcMZyLh8",
        "expanded_url" : "http:\/\/stopsoap.com\/",
        "display_url" : "stopsoap.com"
      } ]
    },
    "geo" : { },
    "id_str" : "159064989867585537",
    "text" : "It is about time that this issue is getting the attention it deserves. http:\/\/t.co\/RcMZyLh8",
    "id" : 159064989867585537,
    "created_at" : "2012-01-17 00:10:23 +0000",
    "user" : {
      "name" : "Josh Reich",
      "screen_name" : "i2pi",
      "protected" : false,
      "id_str" : "18246193",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000443896369\/d799421f94ba56ccaecf9e0f10e8daaa_normal.jpeg",
      "id" : 18246193,
      "verified" : false
    }
  },
  "id" : 159211961995894785,
  "created_at" : "2012-01-17 09:54:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159202184133754880",
  "text" : "Disappointed in boxee.... Anyone know of a good meida player than can stream local and internet (iplayer, lovelfilm, netflix, 4OD, 5later)?",
  "id" : 159202184133754880,
  "created_at" : "2012-01-17 09:15:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159196495646703616",
  "text" : "No milk in the fridge... It is going to be a bad day...",
  "id" : 159196495646703616,
  "created_at" : "2012-01-17 08:52:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159195761140170752",
  "text" : "OK. Today will either be a good day or a bad day if there is milk in the fridge.... Time will tell.....",
  "id" : 159195761140170752,
  "created_at" : "2012-01-17 08:50:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159176258738065410",
  "geo" : { },
  "id_str" : "159182487556329474",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery noooo. Remember the steps up to the changing rooms? Well I could just about make those. Can't feel anything at the mo all numb :)",
  "id" : 159182487556329474,
  "in_reply_to_status_id" : 159176258738065410,
  "created_at" : "2012-01-17 07:57:17 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159175940147130369",
  "text" : "\/me cries like a baby. Weirdly though am starting to enjoy thus shut, again.",
  "id" : 159175940147130369,
  "created_at" : "2012-01-17 07:31:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Crawford",
      "screen_name" : "Kitty_Crawford",
      "indices" : [ 0, 15 ],
      "id_str" : "21756710",
      "id" : 21756710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159053486410043393",
  "geo" : { },
  "id_str" : "159054084266143744",
  "in_reply_to_user_id" : 21756710,
  "text" : "@Kitty_Crawford cos its great. I loved it.",
  "id" : 159054084266143744,
  "in_reply_to_status_id" : 159053486410043393,
  "created_at" : "2012-01-16 23:27:03 +0000",
  "in_reply_to_screen_name" : "Kitty_Crawford",
  "in_reply_to_user_id_str" : "21756710",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159051625409937409",
  "geo" : { },
  "id_str" : "159051781140250626",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit think they'll let us watch? I'll bring the popcorn.",
  "id" : 159051781140250626,
  "in_reply_to_status_id" : 159051625409937409,
  "created_at" : "2012-01-16 23:17:54 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 45, 58 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159051143056592897",
  "geo" : { },
  "id_str" : "159051402495266817",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne chiropractor - been annoying @stevebiscuit about his back experiences - but don't want to come across creepy :)",
  "id" : 159051402495266817,
  "in_reply_to_status_id" : 159051143056592897,
  "created_at" : "2012-01-16 23:16:24 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159050361703895043",
  "geo" : { },
  "id_str" : "159051073561178113",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll *PAIN* :) Excellent. Well done.",
  "id" : 159051073561178113,
  "in_reply_to_status_id" : 159050361703895043,
  "created_at" : "2012-01-16 23:15:05 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159050253604098048",
  "geo" : { },
  "id_str" : "159050490527748096",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne :D Your tweets make me :D",
  "id" : 159050490527748096,
  "in_reply_to_status_id" : 159050253604098048,
  "created_at" : "2012-01-16 23:12:46 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159038820522786817",
  "geo" : { },
  "id_str" : "159050075551707136",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll excellent. you'll be feeling that tomorrow when you get up!",
  "id" : 159050075551707136,
  "in_reply_to_status_id" : 159038820522786817,
  "created_at" : "2012-01-16 23:11:07 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159005561353027584",
  "geo" : { },
  "id_str" : "159006059304988672",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery does it not drive you nuts too?",
  "id" : 159006059304988672,
  "in_reply_to_status_id" : 159005561353027584,
  "created_at" : "2012-01-16 20:16:13 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 1, 10 ],
      "id_str" : "168142553",
      "id" : 168142553
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 12, 18 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159006000882528256",
  "text" : "\u201C@slabbery: @swmcc love you too honey bunny xxx :D\u201D I kinda asked for this.",
  "id" : 159006000882528256,
  "created_at" : "2012-01-16 20:15:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159001563787042816",
  "text" : "Pet hates #950 - Girls on FB that always end their messages with x's to each other. You've got bajingos we fucking get it!!!!",
  "id" : 159001563787042816,
  "created_at" : "2012-01-16 19:58:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 115, 129 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158844488746405888",
  "text" : "I got stuck behind a bin lorry on the way to work and all I can smell is garbage.. Dunno if its just in my head or @peter_omalley stinks.",
  "id" : 158844488746405888,
  "created_at" : "2012-01-16 09:34:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158673040585146369",
  "text" : "Dear Mr Lucas. No one wants to see Episodes I-3 in 3D. Seeing them in 2D was bad enough. Stop fucking my childhood up you beardy bastard!",
  "id" : 158673040585146369,
  "created_at" : "2012-01-15 22:12:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158611348761219072",
  "geo" : { },
  "id_str" : "158650382678097920",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I am loving it so far..... *heart* it in fact...",
  "id" : 158650382678097920,
  "in_reply_to_status_id" : 158611348761219072,
  "created_at" : "2012-01-15 20:42:53 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158604526377631744",
  "geo" : { },
  "id_str" : "158606605947121664",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll meh - I just left the house. I don't have to look at myself so its not my problem :) Good weekend?",
  "id" : 158606605947121664,
  "in_reply_to_status_id" : 158604526377631744,
  "created_at" : "2012-01-15 17:48:56 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "niftynosh",
      "screen_name" : "niftynosh",
      "indices" : [ 12, 22 ],
      "id_str" : "23422949",
      "id" : 23422949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158596394750443520",
  "geo" : { },
  "id_str" : "158604039200849920",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @niftynosh they don't come out to Glenavy. But fuel got and foods in cupboard now. Hoven is on - so its done now :)",
  "id" : 158604039200849920,
  "in_reply_to_status_id" : 158596394750443520,
  "created_at" : "2012-01-15 17:38:44 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158601115737407488",
  "geo" : { },
  "id_str" : "158603821550010369",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall its not the words... its the look.",
  "id" : 158603821550010369,
  "in_reply_to_status_id" : 158601115737407488,
  "created_at" : "2012-01-15 17:37:52 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158577047717941248",
  "text" : "Right - time to stop waffling here... Tesco time...",
  "id" : 158577047717941248,
  "created_at" : "2012-01-15 15:51:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158576913693159424",
  "text" : "He said \"Yeah, the blonde girl give it to me and said to keep it\"... Cheating on me - fair enough. Giving my keys to other ppl - uncalled 4",
  "id" : 158576913693159424,
  "created_at" : "2012-01-15 15:50:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158576570146095104",
  "text" : "Also rang boiler man yesterday to come look at ma boiler.. Apparently I don't have to be there cos he has my key from last time...",
  "id" : 158576570146095104,
  "created_at" : "2012-01-15 15:49:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sendsmybloodpressurethroughtheroof",
      "indices" : [ 66, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158575500078493696",
  "geo" : { },
  "id_str" : "158576105559826432",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall You are banned from muttering \"eh\" in your tweets. #sendsmybloodpressurethroughtheroof",
  "id" : 158576105559826432,
  "in_reply_to_status_id" : 158575500078493696,
  "created_at" : "2012-01-15 15:47:44 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158575497180225536",
  "geo" : { },
  "id_str" : "158575698536185856",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke I fucking love you :)",
  "id" : 158575698536185856,
  "in_reply_to_status_id" : 158575497180225536,
  "created_at" : "2012-01-15 15:46:07 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    }, {
      "name" : "niftynosh",
      "screen_name" : "niftynosh",
      "indices" : [ 14, 24 ],
      "id_str" : "23422949",
      "id" : 23422949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158574983377977345",
  "geo" : { },
  "id_str" : "158575166941708288",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop @niftynosh Too expensive :) Also they don't have a service to fill my car with diesel, do they? :)",
  "id" : 158575166941708288,
  "in_reply_to_status_id" : 158574983377977345,
  "created_at" : "2012-01-15 15:44:00 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158574810849488898",
  "text" : "I am learning Ruby at the mo, that's more interesting.. However I need to fill cupboards and need fuel to get to work tomorrow.",
  "id" : 158574810849488898,
  "created_at" : "2012-01-15 15:42:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158574601499181056",
  "text" : "OK. Dilema! Am hungry. No food in house at all. Car low on diesel. Can't be fucked shopping or putting fuel in car....",
  "id" : 158574601499181056,
  "created_at" : "2012-01-15 15:41:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 7, 23 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158331699640532992",
  "geo" : { },
  "id_str" : "158332346486095874",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @eight_one_eight @beka_bee I think she is - not sure if she uses it or not though.. You Beka - hubby just called you a name ;)",
  "id" : 158332346486095874,
  "in_reply_to_status_id" : 158331699640532992,
  "created_at" : "2012-01-14 23:39:07 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 16, 32 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158331699640532992",
  "text" : "Introducing Ray @eight_one_eight one half of a crime fighting duo and their cool side kick OB! :)",
  "id" : 158331699640532992,
  "created_at" : "2012-01-14 23:36:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158331139273142272",
  "geo" : { },
  "id_str" : "158331247708475392",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight about fuckin time :D",
  "id" : 158331247708475392,
  "in_reply_to_status_id" : 158331139273142272,
  "created_at" : "2012-01-14 23:34:45 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158309974320218113",
  "text" : "Watching Limitless - fantastic film so far. Interesting.",
  "id" : 158309974320218113,
  "created_at" : "2012-01-14 22:10:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 11, 24 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 37, 49 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/iyYmmRY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aOjfVkeOUG0",
      "display_url" : "youtube.com\/watch?v=aOjfVk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "158291695342071808",
  "text" : "Seems that @stevebiscuit is going to @BelfastRuby...Hope they have good insurance - http:\/\/t.co\/iyYmmRY",
  "id" : 158291695342071808,
  "created_at" : "2012-01-14 20:57:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158288213931331584",
  "text" : "I've also ran out of heating oil... Either that or the boiler has bust... So fridge gone now this.. Fucking fuck fuck I say :)",
  "id" : 158288213931331584,
  "created_at" : "2012-01-14 20:43:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOVEFiLM",
      "screen_name" : "LOVEFiLM",
      "indices" : [ 21, 30 ],
      "id_str" : "19338359",
      "id" : 19338359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158283748260052992",
  "text" : "Lost is now avail on @LOVEFiLM instant... Wasted five years of that show only to be fucked in the ass by it... Grrrrrrrr",
  "id" : 158283748260052992,
  "created_at" : "2012-01-14 20:26:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/KbEq3uY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=bcKhpBPFPoU",
      "display_url" : "youtube.com\/watch?v=bcKhpB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "158161503982333952",
  "text" : "Love this. Difference in the two styles is amazing. Dr John kicked his ass :D Jools wasn't relaxed. http:\/\/t.co\/KbEq3uY",
  "id" : 158161503982333952,
  "created_at" : "2012-01-14 12:20:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157946417946701824",
  "geo" : { },
  "id_str" : "157948695361490944",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll yeah. I liked the first one after that they just got silly. This one is just plain daft.",
  "id" : 157948695361490944,
  "in_reply_to_status_id" : 157946417946701824,
  "created_at" : "2012-01-13 22:14:38 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157946274589577216",
  "geo" : { },
  "id_str" : "157948142233464832",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe pffffft",
  "id" : 157948142233464832,
  "in_reply_to_status_id" : 157946274589577216,
  "created_at" : "2012-01-13 22:12:26 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/157945743146098689\/photo\/1",
      "indices" : [ 83, 102 ],
      "url" : "http:\/\/t.co\/VYlfZuH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjEi0QpCIAEWcTr.jpg",
      "id_str" : "157945743150292993",
      "id" : 157945743150292993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjEi0QpCIAEWcTr.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/VYlfZuH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157945743146098689",
  "text" : "Am watching Final Destination 5. Utter tripe but entertaining tripe none the less. http:\/\/t.co\/VYlfZuH",
  "id" : 157945743146098689,
  "created_at" : "2012-01-13 22:02:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157943099119763456",
  "geo" : { },
  "id_str" : "157943904216428545",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe running hug on Monday??",
  "id" : 157943904216428545,
  "in_reply_to_status_id" : 157943099119763456,
  "created_at" : "2012-01-13 21:55:35 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157943221203374080",
  "geo" : { },
  "id_str" : "157943545645371394",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll same here. I'll stick with my 3GS for now. Won't upgrade till shit stops working.",
  "id" : 157943545645371394,
  "in_reply_to_status_id" : 157943221203374080,
  "created_at" : "2012-01-13 21:54:10 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157940864142934017",
  "geo" : { },
  "id_str" : "157942369252163584",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll you not tempted by an Android?",
  "id" : 157942369252163584,
  "in_reply_to_status_id" : 157940864142934017,
  "created_at" : "2012-01-13 21:49:29 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157937076581576704",
  "geo" : { },
  "id_str" : "157939458468102144",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll what you get?",
  "id" : 157939458468102144,
  "in_reply_to_status_id" : 157937076581576704,
  "created_at" : "2012-01-13 21:37:55 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157848742232457216",
  "geo" : { },
  "id_str" : "157858273377267713",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard I do :)",
  "id" : 157858273377267713,
  "in_reply_to_status_id" : 157848742232457216,
  "created_at" : "2012-01-13 16:15:19 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157845338814816257",
  "text" : "Had to restart my mac there.. Hate doing that. I also hate using ATM's.. Both give me an uneasy feeling.",
  "id" : 157845338814816257,
  "created_at" : "2012-01-13 15:23:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 1, 13 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 23, 29 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http:\/\/t.co\/NmxZKmi",
      "expanded_url" : "http:\/\/twitter.com\/stimpled0rf\/status\/157819483359158273\/photo\/1",
      "display_url" : "pic.twitter.com\/NmxZKmi"
    } ]
  },
  "geo" : { },
  "id_str" : "157820300875137024",
  "text" : "\u201C@stimpled0rf: If only @swmcc was this productive with his developing. http:\/\/t.co\/NmxZKmi\u201D Mike now has offical man cards to lose :)",
  "id" : 157820300875137024,
  "created_at" : "2012-01-13 13:44:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 92, 104 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157807108497223680",
  "geo" : { },
  "id_str" : "157809453373198336",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall who needs an atlas.. All you need is an Indian takeaway menu apparently. \/cc @ryancunning",
  "id" : 157809453373198336,
  "in_reply_to_status_id" : 157807108497223680,
  "created_at" : "2012-01-13 13:01:20 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 49, 63 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157804754154700800",
  "text" : "Good pubquiz with work folk last night. I kicked @jenporterhall ass as well so its all good :)",
  "id" : 157804754154700800,
  "created_at" : "2012-01-13 12:42:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157772740898725889",
  "geo" : { },
  "id_str" : "157773539590672384",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin i had to battle with that just after christmas.. Not good shit... Hurt my bald head.",
  "id" : 157773539590672384,
  "in_reply_to_status_id" : 157772740898725889,
  "created_at" : "2012-01-13 10:38:37 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157595617160470528",
  "geo" : { },
  "id_str" : "157620153075499008",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore amazing",
  "id" : 157620153075499008,
  "in_reply_to_status_id" : 157595617160470528,
  "created_at" : "2012-01-13 00:29:07 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 3, 18 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157520986202320896",
  "text" : "RT @Georgina_Milne: Aw!@swmcc is lovely!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "157457891140440064",
    "geo" : { },
    "id_str" : "157494217827037184",
    "in_reply_to_user_id" : 804717,
    "text" : "Aw!@swmcc is lovely!",
    "id" : 157494217827037184,
    "in_reply_to_status_id" : 157457891140440064,
    "created_at" : "2012-01-12 16:08:42 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "protected" : false,
      "id_str" : "15344533",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1562857707\/meee_normal.jpg",
      "id" : 15344533,
      "verified" : false
    }
  },
  "id" : 157520986202320896,
  "created_at" : "2012-01-12 17:55:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 4, 16 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157507572058955776",
  "text" : "And @stimpled0rf loses two man cards... Just cos...",
  "id" : 157507572058955776,
  "created_at" : "2012-01-12 17:01:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Braziel",
      "screen_name" : "Braziel",
      "indices" : [ 0, 8 ],
      "id_str" : "776654",
      "id" : 776654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157484999162081282",
  "geo" : { },
  "id_str" : "157487238542921728",
  "in_reply_to_user_id" : 776654,
  "text" : "@Braziel Tibus - not sure of their cost... I know they try and get a co-loc going on. New place in Carrick started too.",
  "id" : 157487238542921728,
  "in_reply_to_status_id" : 157484999162081282,
  "created_at" : "2012-01-12 15:40:58 +0000",
  "in_reply_to_screen_name" : "Braziel",
  "in_reply_to_user_id_str" : "776654",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 17, 31 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157470493312679936",
  "text" : "Awsome - hearing @jenporterhall talking posh on the phone.. Oh and I kicked her ass in 2\/3 general knowledge quiz :)",
  "id" : 157470493312679936,
  "created_at" : "2012-01-12 14:34:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 38, 45 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157464785359872001",
  "geo" : { },
  "id_str" : "157467583224872960",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb that's probably true... But @srushe did teach my how to scive :D",
  "id" : 157467583224872960,
  "in_reply_to_status_id" : 157464785359872001,
  "created_at" : "2012-01-12 14:22:52 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157466107769393152",
  "geo" : { },
  "id_str" : "157467477373231104",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop we should rectify that soon :)",
  "id" : 157467477373231104,
  "in_reply_to_status_id" : 157466107769393152,
  "created_at" : "2012-01-12 14:22:26 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157463432881381376",
  "geo" : { },
  "id_str" : "157463594584383488",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @srushe bull shit.... You and I scived in the warehouse towards the end something awful :) Good times.",
  "id" : 157463594584383488,
  "in_reply_to_status_id" : 157463432881381376,
  "created_at" : "2012-01-12 14:07:01 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157460861819158530",
  "geo" : { },
  "id_str" : "157461474149797888",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @srushe True... Plus you probably did some work. Lets face it like.. I didn't really bust my nut there ;)",
  "id" : 157461474149797888,
  "in_reply_to_status_id" : 157460861819158530,
  "created_at" : "2012-01-12 13:58:35 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157459703151079424",
  "geo" : { },
  "id_str" : "157459890158313472",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb @srushe I started on a Monday... Hang on....",
  "id" : 157459890158313472,
  "in_reply_to_status_id" : 157459703151079424,
  "created_at" : "2012-01-12 13:52:17 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 74, 81 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157458712934625281",
  "text" : "12 years ago I started working for BlackStar.co.uk - madness!! Also I met @srushe for the first time.. Still yet to beat him in chess :)",
  "id" : 157458712934625281,
  "created_at" : "2012-01-12 13:47:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157451802063802368",
  "geo" : { },
  "id_str" : "157457891140440064",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne what? self loathing - you? Why.. You is the awesome!",
  "id" : 157457891140440064,
  "in_reply_to_status_id" : 157451802063802368,
  "created_at" : "2012-01-12 13:44:21 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne E. Dunlop",
      "screen_name" : "joannedunlop",
      "indices" : [ 0, 13 ],
      "id_str" : "19316715",
      "id" : 19316715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157447068246487040",
  "geo" : { },
  "id_str" : "157447922672353280",
  "in_reply_to_user_id" : 19316715,
  "text" : "@joannedunlop brilliant :)",
  "id" : 157447922672353280,
  "in_reply_to_status_id" : 157447068246487040,
  "created_at" : "2012-01-12 13:04:44 +0000",
  "in_reply_to_screen_name" : "joannedunlop",
  "in_reply_to_user_id_str" : "19316715",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 1, 13 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157447865214582784",
  "text" : "\u201C@stimpled0rf: One 'man card' down already.\u201D You got it back for writing the nicest \"FUCK YOU\" letter ever :)",
  "id" : 157447865214582784,
  "created_at" : "2012-01-12 13:04:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157434613717934080",
  "geo" : { },
  "id_str" : "157447672838623232",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley you are knocking them out of the park today :)",
  "id" : 157447672838623232,
  "in_reply_to_status_id" : 157434613717934080,
  "created_at" : "2012-01-12 13:03:45 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 14, 23 ],
      "id_str" : "8388092",
      "id" : 8388092
    }, {
      "name" : "Colin Masters",
      "screen_name" : "colinpmasters",
      "indices" : [ 24, 38 ],
      "id_str" : "95940408",
      "id" : 95940408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157421141823205376",
  "geo" : { },
  "id_str" : "157432193218650112",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @hamstarr @colinpmasters share you tight fisted bastard :)",
  "id" : 157432193218650112,
  "in_reply_to_status_id" : 157421141823205376,
  "created_at" : "2012-01-12 12:02:14 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157380796892721152",
  "geo" : { },
  "id_str" : "157382075132030976",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Friends quote?",
  "id" : 157382075132030976,
  "in_reply_to_status_id" : 157380796892721152,
  "created_at" : "2012-01-12 08:43:05 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157250794754805761",
  "text" : "Being bald is cool!",
  "id" : 157250794754805761,
  "created_at" : "2012-01-12 00:01:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157239375980269568",
  "geo" : { },
  "id_str" : "157239504393084928",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley freakin awsome dude :)",
  "id" : 157239504393084928,
  "in_reply_to_status_id" : 157239375980269568,
  "created_at" : "2012-01-11 23:16:33 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157236464856473600",
  "text" : "Hacked my first Perl Dancer script... nice wee framework",
  "id" : 157236464856473600,
  "created_at" : "2012-01-11 23:04:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157235934352506880",
  "text" : "Gotta say the latest episode of Sherlock was utter shite.",
  "id" : 157235934352506880,
  "created_at" : "2012-01-11 23:02:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157235634010992641",
  "geo" : { },
  "id_str" : "157235861652639744",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne POLE",
  "id" : 157235861652639744,
  "in_reply_to_status_id" : 157235634010992641,
  "created_at" : "2012-01-11 23:02:05 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157232234556948480",
  "geo" : { },
  "id_str" : "157235622715731969",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit only for comission",
  "id" : 157235622715731969,
  "in_reply_to_status_id" : 157232234556948480,
  "created_at" : "2012-01-11 23:01:08 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 1, 10 ],
      "id_str" : "168142553",
      "id" : 168142553
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 12, 18 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157204657524064256",
  "text" : "\u201C@slabbery: @swmcc maybe you wouldn't be so reflective if you didn't polish that big bald head of yours.\u201D Fuck all wrong with being bald.",
  "id" : 157204657524064256,
  "created_at" : "2012-01-11 20:58:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157200840984236032",
  "text" : "Amazing how much my email habit has changed in the last 12 years. Most coms now done on twitter, fb or IM. Being reflective :)",
  "id" : 157200840984236032,
  "created_at" : "2012-01-11 20:42:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 3, 17 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 19, 25 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/peter_omalley\/status\/157172480560214016\/photo\/1",
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/uYCYP58P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai5jidBCMAEr8ou.jpg",
      "id_str" : "157172480560214017",
      "id" : 157172480560214017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai5jidBCMAEr8ou.jpg",
      "sizes" : [ {
        "h" : 389,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1686,
        "resize" : "fit",
        "w" : 2602
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uYCYP58P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157194018143469568",
  "text" : "RT @peter_omalley: @swmcc off to the theatre... http:\/\/t.co\/uYCYP58P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/peter_omalley\/status\/157172480560214016\/photo\/1",
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/uYCYP58P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai5jidBCMAEr8ou.jpg",
        "id_str" : "157172480560214017",
        "id" : 157172480560214017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai5jidBCMAEr8ou.jpg",
        "sizes" : [ {
          "h" : 389,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1686,
          "resize" : "fit",
          "w" : 2602
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 664,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uYCYP58P"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157172480560214016",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc off to the theatre... http:\/\/t.co\/uYCYP58P",
    "id" : 157172480560214016,
    "created_at" : "2012-01-11 18:50:15 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "protected" : false,
      "id_str" : "437697624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1706604039\/eC7Ba2I7_normal",
      "id" : 437697624,
      "verified" : false
    }
  },
  "id" : 157194018143469568,
  "created_at" : "2012-01-11 20:15:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157172480560214016",
  "geo" : { },
  "id_str" : "157193999503990784",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley fucking awesome :D",
  "id" : 157193999503990784,
  "in_reply_to_status_id" : 157172480560214016,
  "created_at" : "2012-01-11 20:15:44 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157143627603255296",
  "geo" : { },
  "id_str" : "157146025449099264",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley awesome... I better get a gift too :D",
  "id" : 157146025449099264,
  "in_reply_to_status_id" : 157143627603255296,
  "created_at" : "2012-01-11 17:05:06 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157106268132212736",
  "geo" : { },
  "id_str" : "157111258099879936",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne POLE :)",
  "id" : 157111258099879936,
  "in_reply_to_status_id" : 157106268132212736,
  "created_at" : "2012-01-11 14:46:57 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157075536840105985",
  "geo" : { },
  "id_str" : "157080261996199937",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne I did :) So anytime I use bald in a sentence you will repeat... I'll do the same but with 'pole' :)",
  "id" : 157080261996199937,
  "in_reply_to_status_id" : 157075536840105985,
  "created_at" : "2012-01-11 12:43:47 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157074962417594370",
  "text" : "I hate Hillsborough some times. Some twat started talking to me in Mace who was wearing shorts.. In January.. Fucking toffs.",
  "id" : 157074962417594370,
  "created_at" : "2012-01-11 12:22:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157015241518096384",
  "geo" : { },
  "id_str" : "157017031240196096",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne ??",
  "id" : 157017031240196096,
  "in_reply_to_status_id" : 157015241518096384,
  "created_at" : "2012-01-11 08:32:32 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157007673441779712",
  "text" : "Picking up a work dude at the hairport this morning. So working from home right now.... Feels like a data port day :(",
  "id" : 157007673441779712,
  "created_at" : "2012-01-11 07:55:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156997768257351680",
  "text" : "Wow.. EPIC sleep.. As soon as my bald head hit the pillow I was out like a light! Awesome :)",
  "id" : 156997768257351680,
  "created_at" : "2012-01-11 07:15:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156863039549882368",
  "geo" : { },
  "id_str" : "156864401809485825",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa Thats a really good price - but I couldn't survive without a freezer though - sorry :(",
  "id" : 156864401809485825,
  "in_reply_to_status_id" : 156863039549882368,
  "created_at" : "2012-01-10 22:26:02 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156860972726886400",
  "geo" : { },
  "id_str" : "156862692408303616",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Will have a proper look now I have the laptop open :)",
  "id" : 156862692408303616,
  "in_reply_to_status_id" : 156860972726886400,
  "created_at" : "2012-01-10 22:19:14 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156861894664261632",
  "geo" : { },
  "id_str" : "156862607561723905",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa Ohhh how much - and don't forget to add the local stalker discount please :D",
  "id" : 156862607561723905,
  "in_reply_to_status_id" : 156861894664261632,
  "created_at" : "2012-01-10 22:18:54 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156859740100640768",
  "geo" : { },
  "id_str" : "156860211443924992",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll expensive though.... But they are class!",
  "id" : 156860211443924992,
  "in_reply_to_status_id" : 156859740100640768,
  "created_at" : "2012-01-10 22:09:23 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156859929293111296",
  "geo" : { },
  "id_str" : "156860129776648192",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit for a few months anyway :) Same age as me.... Suck it bitch! :)",
  "id" : 156860129776648192,
  "in_reply_to_status_id" : 156859929293111296,
  "created_at" : "2012-01-10 22:09:03 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156857002650378244",
  "text" : "New fridges are expensive...",
  "id" : 156857002650378244,
  "created_at" : "2012-01-10 21:56:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156855916296290305",
  "geo" : { },
  "id_str" : "156856610470379520",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll I can't be assed looking for one though... It's just tooo boring :(",
  "id" : 156856610470379520,
  "in_reply_to_status_id" : 156855916296290305,
  "created_at" : "2012-01-10 21:55:04 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156854591886077952",
  "text" : "New fridge needed it seems.... Fuck I do hate Jan.. Now to find a fridge that goes with my kitchen... Being 32 sucks fucking donkey cock!",
  "id" : 156854591886077952,
  "created_at" : "2012-01-10 21:47:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156770620561035264",
  "text" : "OH: \"Its a weird feeling when your brain tells you to fuck off\"... Pity it was me that said it :)",
  "id" : 156770620561035264,
  "created_at" : "2012-01-10 16:13:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156752739613941761",
  "geo" : { },
  "id_str" : "156752870652383232",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley PERFECT :D",
  "id" : 156752870652383232,
  "in_reply_to_status_id" : 156752739613941761,
  "created_at" : "2012-01-10 15:02:51 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156752794588692480",
  "text" : "Brain has stopped working.",
  "id" : 156752794588692480,
  "created_at" : "2012-01-10 15:02:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156719104538054656",
  "text" : "Gotta love Twitter for news! Got more details on here re: Seann Quinn than news.bbc.co.uk. News - the killer app for twitter.",
  "id" : 156719104538054656,
  "created_at" : "2012-01-10 12:48:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156688305046568960",
  "geo" : { },
  "id_str" : "156701031064027137",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll oh I do that all the time ;) I am bald see..... I joke about it to hide the tears :D",
  "id" : 156701031064027137,
  "in_reply_to_status_id" : 156688305046568960,
  "created_at" : "2012-01-10 11:36:51 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156668080196554754",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop They are losing out in the long run. However they will learn at some stage. Stupid TV execs.",
  "id" : 156668080196554754,
  "created_at" : "2012-01-10 09:25:55 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156665098914639872",
  "geo" : { },
  "id_str" : "156667886528770048",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop I agree totally. I would stop downloading stuff if I could get it for 5.99 and as soon as the states gets it.. Iditos.",
  "id" : 156667886528770048,
  "in_reply_to_status_id" : 156665098914639872,
  "created_at" : "2012-01-10 09:25:09 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156663554982952961",
  "geo" : { },
  "id_str" : "156663794947473408",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop that is irritating :( I am past season 2 of Breaking Bad as well :( Maybe their library will get up to date quick.... I hope.",
  "id" : 156663794947473408,
  "in_reply_to_status_id" : 156663554982952961,
  "created_at" : "2012-01-10 09:08:54 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156658122042245120",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery not for any other reason than my facebook is full of crap as it is. Plus I don't want peeps knowing my viewing habits :)",
  "id" : 156658122042245120,
  "created_at" : "2012-01-10 08:46:21 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    }, {
      "name" : "BBC Breakfast",
      "screen_name" : "BBCBreakfast",
      "indices" : [ 31, 44 ],
      "id_str" : "143415291",
      "id" : 143415291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156655282401980418",
  "geo" : { },
  "id_str" : "156657522852380672",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery the head dude was on @bbcbreakfast yesterday saying you can now sign up. I don't want to give them my FB details though.",
  "id" : 156657522852380672,
  "in_reply_to_status_id" : 156655282401980418,
  "created_at" : "2012-01-10 08:43:58 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156653622883655680",
  "text" : "Seems I have to give them my facebook account details to even see the actual list. Think I'll hold off for a while.",
  "id" : 156653622883655680,
  "created_at" : "2012-01-10 08:28:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156653122163445760",
  "text" : "Anyone using netflix - what you think? It can't be much worse than lovefilms free streaming channel.... can it?",
  "id" : 156653122163445760,
  "created_at" : "2012-01-10 08:26:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156338614329028608",
  "geo" : { },
  "id_str" : "156478177173184512",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley that is my snoop!!! You better look after him!",
  "id" : 156478177173184512,
  "in_reply_to_status_id" : 156338614329028608,
  "created_at" : "2012-01-09 20:51:19 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156455809440694273",
  "geo" : { },
  "id_str" : "156456786029842432",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley still fucking genius though :)",
  "id" : 156456786029842432,
  "in_reply_to_status_id" : 156455809440694273,
  "created_at" : "2012-01-09 19:26:19 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156455809440694273",
  "geo" : { },
  "id_str" : "156456754035691520",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley you should get him standing in the middle of something looking :) With no human interaction he would enjoy that more :)",
  "id" : 156456754035691520,
  "in_reply_to_status_id" : 156455809440694273,
  "created_at" : "2012-01-09 19:26:11 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 34, 48 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156370600074543104",
  "text" : "So almost had a heart attack with @jenporterhall and a walk around Hillsborough lake... That woman walks tooooooo fast :)",
  "id" : 156370600074543104,
  "created_at" : "2012-01-09 13:43:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 1, 15 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 17, 23 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/peter_omalley\/status\/156331495416537089\/photo\/1",
      "indices" : [ 72, 91 ],
      "url" : "http:\/\/t.co\/0B6kBd2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AitmqrPCIAET4nP.jpg",
      "id_str" : "156331495420731393",
      "id" : 156331495420731393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AitmqrPCIAET4nP.jpg",
      "sizes" : [ {
        "h" : 3264,
        "resize" : "fit",
        "w" : 1840
      }, {
        "h" : 1816,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0B6kBd2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156335783563902977",
  "text" : "\u201C@peter_omalley: @swmcc just checking out the view of the Olympic site. http:\/\/t.co\/0B6kBd2\u201D Fucking genius :D",
  "id" : 156335783563902977,
  "created_at" : "2012-01-09 11:25:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156280896834646016",
  "geo" : { },
  "id_str" : "156308921777266689",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @peter_omalley Fucking genius Pete - make sure he sees the sights.. Bastard. Excellent :)",
  "id" : 156308921777266689,
  "in_reply_to_status_id" : 156280896834646016,
  "created_at" : "2012-01-09 09:38:45 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Robinson",
      "screen_name" : "gazrobot",
      "indices" : [ 1, 10 ],
      "id_str" : "1477065343",
      "id" : 1477065343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156154983505592321",
  "text" : "\u201C@gazrobot: This whole going back to work thing.... no craic at all\u201D Rhus man speaks the truth!",
  "id" : 156154983505592321,
  "created_at" : "2012-01-08 23:27:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156144132249747458",
  "geo" : { },
  "id_str" : "156152722767355904",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne well done :) Looks impressive.",
  "id" : 156152722767355904,
  "in_reply_to_status_id" : 156144132249747458,
  "created_at" : "2012-01-08 23:18:04 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156132766487031808",
  "geo" : { },
  "id_str" : "156152524074782720",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams yeah it does... However your the closest one to hand...",
  "id" : 156152524074782720,
  "in_reply_to_status_id" : 156132766487031808,
  "created_at" : "2012-01-08 23:17:17 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 86, 98 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coveringallbases",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156127913249480704",
  "text" : "...wand pass MOT next month!! \/me crosses himself \/me prays to allah \/me sacrifices a @niall_adams \/me fasts for 20 days #coveringallbases",
  "id" : 156127913249480704,
  "created_at" : "2012-01-08 21:39:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 92, 106 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156127390144270336",
  "text" : "...just need to renew my driving licence and its all good. Don't ask when it expired... \/cc @jenporterhall I know!!!!! :D",
  "id" : 156127390144270336,
  "created_at" : "2012-01-08 21:37:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156127260162793472",
  "text" : "Also - I can go the airport now and not worry about a checkpoint now that I am taxed and my car doesn't make noises and shake when I brake..",
  "id" : 156127260162793472,
  "created_at" : "2012-01-08 21:36:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156126385423908864",
  "geo" : { },
  "id_str" : "156127005052637184",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa more than welcome :)",
  "id" : 156127005052637184,
  "in_reply_to_status_id" : 156126385423908864,
  "created_at" : "2012-01-08 21:35:53 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/156126725867180033\/photo\/1",
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/HooluuX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AiqsbhOCEAEDASb.jpg",
      "id_str" : "156126725871374337",
      "id" : 156126725871374337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiqsbhOCEAEDASb.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/HooluuX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156126725867180033",
  "text" : "Picking up the sister... We have an odd way of talking to each other! http:\/\/t.co\/HooluuX",
  "id" : 156126725867180033,
  "created_at" : "2012-01-08 21:34:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "magic8lisa",
      "indices" : [ 0, 11 ],
      "id_str" : "210949996",
      "id" : 210949996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156124799905710081",
  "geo" : { },
  "id_str" : "156126149397843968",
  "in_reply_to_user_id" : 210949996,
  "text" : "@magic8lisa you just keep on getting cooler and cooler in my eyes :)",
  "id" : 156126149397843968,
  "in_reply_to_status_id" : 156124799905710081,
  "created_at" : "2012-01-08 21:32:29 +0000",
  "in_reply_to_screen_name" : "magic8lisa",
  "in_reply_to_user_id_str" : "210949996",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156015463216840704",
  "text" : "I don't get it. Every time it shows you a player near the crowd he's getting wanker signs made to him... Regardless of who it is.",
  "id" : 156015463216840704,
  "created_at" : "2012-01-08 14:12:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/156011883843944448\/photo\/1",
      "indices" : [ 62, 81 ],
      "url" : "http:\/\/t.co\/RExPNT3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AipD-1WCAAIz_xp.jpg",
      "id_str" : "156011883848138754",
      "id" : 156011883848138754,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AipD-1WCAAIz_xp.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/RExPNT3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156011883843944448",
  "text" : "I be watching football... Might as well join everyone else... http:\/\/t.co\/RExPNT3",
  "id" : 156011883843944448,
  "created_at" : "2012-01-08 13:58:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 3, 12 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156003506204057600",
  "text" : "RT @slabbery: Blah blah blah footballer.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155998193807654912",
    "text" : "Blah blah blah footballer.",
    "id" : 155998193807654912,
    "created_at" : "2012-01-08 13:04:02 +0000",
    "user" : {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "protected" : false,
      "id_str" : "168142553",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1182531309\/connor_af_normal.jpg",
      "id" : 168142553,
      "verified" : false
    }
  },
  "id" : 156003506204057600,
  "created_at" : "2012-01-08 13:25:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155992208019959808",
  "text" : "Too many ppl going on about some footballer on my twitter feed....",
  "id" : 155992208019959808,
  "created_at" : "2012-01-08 12:40:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155968979398168576",
  "text" : "People that talk with an inflection at the end of their sentences need to be kicked... Seriously - there is no need for it :(",
  "id" : 155968979398168576,
  "created_at" : "2012-01-08 11:07:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155787114636775424",
  "text" : "Due Hard... Has the two best actors to be bad guts. Alan Rickman and Jeremy Irons.... Awesome :)",
  "id" : 155787114636775424,
  "created_at" : "2012-01-07 23:05:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "laybybuddiesagain",
      "indices" : [ 112, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155755845588754432",
  "geo" : { },
  "id_str" : "155756238112698369",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf it is funny. The Coach character is replaced though :( I did - I taxed it - am legal on the roads. #laybybuddiesagain",
  "id" : 155756238112698369,
  "in_reply_to_status_id" : 155755845588754432,
  "created_at" : "2012-01-07 21:02:35 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155753345146032128",
  "geo" : { },
  "id_str" : "155754511812673536",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf She's lovely no doubt about that.... I am almost done with Season 1 :) Yeah lots of files... Gonna move I think.",
  "id" : 155754511812673536,
  "in_reply_to_status_id" : 155753345146032128,
  "created_at" : "2012-01-07 20:55:44 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155661635686645761",
  "geo" : { },
  "id_str" : "155663280491335680",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery All very confusing... In good news though I made the most awesome carrot & parsnip soup today.....",
  "id" : 155663280491335680,
  "in_reply_to_status_id" : 155661635686645761,
  "created_at" : "2012-01-07 14:53:12 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 127, 139 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155661159788331009",
  "text" : "I have 15 big bin bags to take to the dump.. Its only to Crumlin.. Might just flytip it and make 'Cleansing' pick em up ;) \/cc @stimpled0rf",
  "id" : 155661159788331009,
  "created_at" : "2012-01-07 14:44:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 14, 28 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155433936674230272",
  "geo" : { },
  "id_str" : "155659904223416320",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @peter_omalley I am on the fence. It'd be nice to go - but its bound to be bunged. Dunno - my sofa is awesome for such things.",
  "id" : 155659904223416320,
  "in_reply_to_status_id" : 155433936674230272,
  "created_at" : "2012-01-07 14:39:47 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155658871103426561",
  "text" : "\"Unpacking failed, CRC error\" On another file....",
  "id" : 155658871103426561,
  "created_at" : "2012-01-07 14:35:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155658480525639681",
  "text" : "\"Repair failed, not enough repair blocks (433 short)\" On a file that is 20 odd days old...",
  "id" : 155658480525639681,
  "created_at" : "2012-01-07 14:34:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155658360497258499",
  "text" : "Am trying to download episodes of the New Girl - it is funny dammit!!",
  "id" : 155658360497258499,
  "created_at" : "2012-01-07 14:33:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 49, 61 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 62, 74 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155657252764782592",
  "text" : "Anyone else exp this problem that uses newzbin2? @stimpled0rf @ryancunning ??",
  "id" : 155657252764782592,
  "created_at" : "2012-01-07 14:29:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155657099093872643",
  "text" : "Newzbin was down last night. But any files I try and get are now failing. All too common this weather - gonna move I think :(",
  "id" : 155657099093872643,
  "created_at" : "2012-01-07 14:28:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155424161412554752",
  "geo" : { },
  "id_str" : "155424922955546624",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley it does - but still only one road in and out. With that infrastructure the carpark will be in Glenavy :)",
  "id" : 155424922955546624,
  "in_reply_to_status_id" : 155424161412554752,
  "created_at" : "2012-01-06 23:06:03 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155420854505840641",
  "geo" : { },
  "id_str" : "155423486498717696",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley that's true... getting there would be a real whore though. But deffo interested in a project.group.b road trip :)",
  "id" : 155423486498717696,
  "in_reply_to_status_id" : 155420854505840641,
  "created_at" : "2012-01-06 23:00:21 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 1, 15 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 17, 23 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 109, 122 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155421097158905856",
  "text" : "\u201C@peter_omalley: @swmcc Irish open tickets. 26 quid for one day. 61 for all 4 days. Not bad.\u201D You interested @RickyHassard",
  "id" : 155421097158905856,
  "created_at" : "2012-01-06 22:50:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155420032896217089",
  "geo" : { },
  "id_str" : "155420254460313602",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley that's pretty good.. Interested?",
  "id" : 155420254460313602,
  "in_reply_to_status_id" : 155420032896217089,
  "created_at" : "2012-01-06 22:47:30 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connor McLaughlin",
      "screen_name" : "slabbery",
      "indices" : [ 0, 9 ],
      "id_str" : "168142553",
      "id" : 168142553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155242802203201536",
  "geo" : { },
  "id_str" : "155382537173221376",
  "in_reply_to_user_id" : 168142553,
  "text" : "@slabbery that's brilliant. 5k every morning?",
  "id" : 155382537173221376,
  "in_reply_to_status_id" : 155242802203201536,
  "created_at" : "2012-01-06 20:17:38 +0000",
  "in_reply_to_screen_name" : "slabbery",
  "in_reply_to_user_id_str" : "168142553",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155381185965592576",
  "geo" : { },
  "id_str" : "155382447377362944",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke wig you used newzbin2 it allowed you through.",
  "id" : 155382447377362944,
  "in_reply_to_status_id" : 155381185965592576,
  "created_at" : "2012-01-06 20:17:16 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155366293166489600",
  "text" : "Anyone else getting an error when they use newzbin2?",
  "id" : 155366293166489600,
  "created_at" : "2012-01-06 19:13:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155232265134280705",
  "geo" : { },
  "id_str" : "155232618986749953",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley did you note that I got fucked off eating them and threw them away from arms reach? :) I just grazed :( No more though ;)",
  "id" : 155232618986749953,
  "in_reply_to_status_id" : 155232265134280705,
  "created_at" : "2012-01-06 10:21:55 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Hurley",
      "screen_name" : "PapaHurley",
      "indices" : [ 0, 11 ],
      "id_str" : "19614568",
      "id" : 19614568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155230743486939136",
  "geo" : { },
  "id_str" : "155232323397353474",
  "in_reply_to_user_id" : 19614568,
  "text" : "@PapaHurley you join civilisation and got yourself a mac? About fucking time son!",
  "id" : 155232323397353474,
  "in_reply_to_status_id" : 155230743486939136,
  "created_at" : "2012-01-06 10:20:44 +0000",
  "in_reply_to_screen_name" : "PapaHurley",
  "in_reply_to_user_id_str" : "19614568",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155231533580558336",
  "geo" : { },
  "id_str" : "155231871595327488",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf can just about type this tweet lol.... *virtual high five*",
  "id" : 155231871595327488,
  "in_reply_to_status_id" : 155231533580558336,
  "created_at" : "2012-01-06 10:18:56 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155230677833486336",
  "text" : "I never lock my doors when in the car. Will do from now on.",
  "id" : 155230677833486336,
  "created_at" : "2012-01-06 10:14:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "https:\/\/t.co\/ZwO6sY5",
      "expanded_url" : "https:\/\/twitter.com\/worldinaglass\/status\/154911133046804481",
      "display_url" : "twitter.com\/worldinaglass\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155230215818321921",
  "text" : "https:\/\/t.co\/ZwO6sY5 - plslock your doors when travelling. Scummers.",
  "id" : 155230215818321921,
  "created_at" : "2012-01-06 10:12:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea McVeigh",
      "screen_name" : "worldinaglass",
      "indices" : [ 3, 17 ],
      "id_str" : "366115249",
      "id" : 366115249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155229876385890304",
  "text" : "RT @worldinaglass: My stolen car V V distinctive, some1 might spot it abandoned. 1999 silver Renault Megane. Lots of travel stickers at  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154931425450266625",
    "text" : "My stolen car V V distinctive, some1 might spot it abandoned. 1999 silver Renault Megane. Lots of travel stickers at back\/tailgate BCZ 2170",
    "id" : 154931425450266625,
    "created_at" : "2012-01-05 14:25:04 +0000",
    "user" : {
      "name" : "Andrea McVeigh",
      "screen_name" : "worldinaglass",
      "protected" : false,
      "id_str" : "366115249",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2125788138\/Twitter_daffs_normal.jpg",
      "id" : 366115249,
      "verified" : false
    }
  },
  "id" : 155229876385890304,
  "created_at" : "2012-01-06 10:11:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155228107526250497",
  "geo" : { },
  "id_str" : "155228499953725440",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall thanks. My run is equal to 50% of your walking though. Trainers Monday. No excuses :)",
  "id" : 155228499953725440,
  "in_reply_to_status_id" : 155228107526250497,
  "created_at" : "2012-01-06 10:05:33 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155227375121076224",
  "text" : "... I think I'll go tax my car now :)",
  "id" : 155227375121076224,
  "created_at" : "2012-01-06 10:01:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155227236218314753",
  "text" : "I just ran two mile! While not a big distance is a big step :) haven't ran in over three years! Various other things done too...",
  "id" : 155227236218314753,
  "created_at" : "2012-01-06 10:00:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155207364922970112",
  "text" : "Behind four cars and a black taxi on the way to Belfast this morning. Taxi was in front and only did 30mph the whole way. Hate black taxis.",
  "id" : 155207364922970112,
  "created_at" : "2012-01-06 08:41:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155069906549878784",
  "geo" : { },
  "id_str" : "155072780801548290",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit as does my bro. I think you are awesome - so its no reflection on you :) I just don't like conswater, sorry :)",
  "id" : 155072780801548290,
  "in_reply_to_status_id" : 155069906549878784,
  "created_at" : "2012-01-05 23:46:46 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 14, 29 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155063141187846145",
  "geo" : { },
  "id_str" : "155065709410533376",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @georgina_milne I am not scared... It is a dive...",
  "id" : 155065709410533376,
  "in_reply_to_status_id" : 155063141187846145,
  "created_at" : "2012-01-05 23:18:40 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155048791370760192",
  "text" : "At the folks. My Dad is asking about who the celebs are in big bro... I know Michael Madsen. The rest??? Who cares...",
  "id" : 155048791370760192,
  "created_at" : "2012-01-05 22:11:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 3, 17 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Stephen Kelly",
      "screen_name" : "Big_Kells",
      "indices" : [ 20, 30 ],
      "id_str" : "266254297",
      "id" : 266254297
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 32, 46 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155048451116249088",
  "text" : "RT @No_Underscore: \u201C@Big_Kells: @No_Underscore as a single man, 3 words might convince you otherwise. Playboy - Mansion - Twins\u201D Nope, j ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen Kelly",
        "screen_name" : "Big_Kells",
        "indices" : [ 1, 11 ],
        "id_str" : "266254297",
        "id" : 266254297
      }, {
        "name" : "Ciaran Murray",
        "screen_name" : "No_Underscore",
        "indices" : [ 13, 27 ],
        "id_str" : "33658328",
        "id" : 33658328
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155047404041809920",
    "text" : "\u201C@Big_Kells: @No_Underscore as a single man, 3 words might convince you otherwise. Playboy - Mansion - Twins\u201D Nope, just 4 more boring tits",
    "id" : 155047404041809920,
    "created_at" : "2012-01-05 22:05:56 +0000",
    "user" : {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "protected" : false,
      "id_str" : "33658328",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2818844110\/4cf5aaa10af39b21679e9a66ba737adf_normal.png",
      "id" : 33658328,
      "verified" : false
    }
  },
  "id" : 155048451116249088,
  "created_at" : "2012-01-05 22:10:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "result",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155022493382483968",
  "text" : "Called in with the brother there as I was in the East... Getting fed. #result",
  "id" : 155022493382483968,
  "created_at" : "2012-01-05 20:26:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155013960939216896",
  "geo" : { },
  "id_str" : "155022352982355968",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda I any scared of the Internet giant!",
  "id" : 155022352982355968,
  "in_reply_to_status_id" : 155013960939216896,
  "created_at" : "2012-01-05 20:26:23 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155013491684675584",
  "text" : "Fuck me but Connswater is a dive....",
  "id" : 155013491684675584,
  "created_at" : "2012-01-05 19:51:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154957040731701248",
  "geo" : { },
  "id_str" : "154957226082185217",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf I'd do anything or anyone (exc family) for 10k. That's my limit.. Well that was my limit 10 years ago - inflation so say 20k",
  "id" : 154957226082185217,
  "in_reply_to_status_id" : 154957040731701248,
  "created_at" : "2012-01-05 16:07:36 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154950860751896576",
  "text" : "Just freaked out a customer there by still having my out of office on even though I am in. It says I return on the 9th.",
  "id" : 154950860751896576,
  "created_at" : "2012-01-05 15:42:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 1, 16 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "James Burke",
      "screen_name" : "Burkazoid",
      "indices" : [ 18, 28 ],
      "id_str" : "9713742",
      "id" : 9713742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154944512760885248",
  "text" : "\u201C@Georgina_Milne: @Burkazoid pic!also,bald is cool.\u201D Ha - tis official :)",
  "id" : 154944512760885248,
  "created_at" : "2012-01-05 15:17:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 50, 64 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 69, 82 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsthatshouldntgotogether",
      "indices" : [ 84, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154707935061221378",
  "text" : "Just heard \"Ho Ho Ho, green giant\" and thought of @peter_omalley and @RickyHassard. #thingsthatshouldntgotogether",
  "id" : 154707935061221378,
  "created_at" : "2012-01-04 23:37:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Paul Cupples",
      "screen_name" : "PaulCupples",
      "indices" : [ 15, 27 ],
      "id_str" : "151577473",
      "id" : 151577473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154645879863775232",
  "geo" : { },
  "id_str" : "154646315274469377",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @paulcupples :) :) :) Biiiiiiiiiiiiimbbbbbbbbo (said in the same style as tiiiimmmmbbbbeeeeerrr)",
  "id" : 154646315274469377,
  "in_reply_to_status_id" : 154645879863775232,
  "created_at" : "2012-01-04 19:32:09 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154644798681251840",
  "geo" : { },
  "id_str" : "154645144346439680",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf me either... Could have been a lot worse!!!",
  "id" : 154645144346439680,
  "in_reply_to_status_id" : 154644798681251840,
  "created_at" : "2012-01-04 19:27:30 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Paul Cupples",
      "screen_name" : "PaulCupples",
      "indices" : [ 15, 27 ],
      "id_str" : "151577473",
      "id" : 151577473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154644600437485569",
  "geo" : { },
  "id_str" : "154644984153378816",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @paulcupples Way to go Paul!!!!! I don't know you, but I like you :)",
  "id" : 154644984153378816,
  "in_reply_to_status_id" : 154644600437485569,
  "created_at" : "2012-01-04 19:26:52 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 3, 17 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "paul cummings",
      "screen_name" : "paulcu",
      "indices" : [ 129, 136 ],
      "id_str" : "24350953",
      "id" : 24350953
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getstuffed",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154644850220875777",
  "text" : "RT @jenporterhall: Just asked family if i should go brunette again.. 'no stay blonde,  once a bimbo always a bimbo'. #getstuffed @PaulCu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Cupples",
        "screen_name" : "PaulCupples",
        "indices" : [ 110, 122 ],
        "id_str" : "151577473",
        "id" : 151577473
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getstuffed",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154644600437485569",
    "text" : "Just asked family if i should go brunette again.. 'no stay blonde,  once a bimbo always a bimbo'. #getstuffed @PaulCupples",
    "id" : 154644600437485569,
    "created_at" : "2012-01-04 19:25:20 +0000",
    "user" : {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "protected" : false,
      "id_str" : "227493010",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2257082551\/DSCF9612_normal.jpg",
      "id" : 227493010,
      "verified" : false
    }
  },
  "id" : 154644850220875777,
  "created_at" : "2012-01-04 19:26:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154644396778852353",
  "geo" : { },
  "id_str" : "154644798668673024",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams well maybe if you'd just have romanced me once in a while... I am just more than a sex object you know!!! I have feelings!!!",
  "id" : 154644798668673024,
  "in_reply_to_status_id" : 154644396778852353,
  "created_at" : "2012-01-04 19:26:07 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 105, 117 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154643247363403776",
  "text" : "Also..... Never search for torrents on your work laptop... They provide rather inappropriate popups. \/cc @stimpled0rf",
  "id" : 154643247363403776,
  "created_at" : "2012-01-04 19:19:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/154643024826204160\/photo\/1",
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/vEcxEKH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AiVnAwICAAA75ND.jpg",
      "id_str" : "154643024830398464",
      "id" : 154643024830398464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiVnAwICAAA75ND.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/vEcxEKH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154643024826204160",
  "text" : "He does love me. @niall_adams you have been replaced. http:\/\/t.co\/vEcxEKH",
  "id" : 154643024826204160,
  "created_at" : "2012-01-04 19:19:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 13, 25 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154550943038443523",
  "geo" : { },
  "id_str" : "154551286417723392",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @niall_adams grrrrrrrr.......",
  "id" : 154551286417723392,
  "in_reply_to_status_id" : 154550943038443523,
  "created_at" : "2012-01-04 13:14:32 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 40 ],
      "url" : "http:\/\/t.co\/aHHtsNq",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/tvshowbiz\/article-2081486\/Lara-Pulver-naked-Sherlock-Holmes-BBC-raunchy-pre-watershed-scenes.html",
      "display_url" : "dailymail.co.uk\/tvshowbiz\/arti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154326275811577858",
  "text" : "Stupid Daily Mail... http:\/\/t.co\/aHHtsNq - wasn't sexual was a reason behind it..",
  "id" : 154326275811577858,
  "created_at" : "2012-01-03 22:20:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 3, 13 ],
      "id_str" : "212603717",
      "id" : 212603717
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 118, 124 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154253921672630275",
  "text" : "RT @carisenda: If ever I wonder why Twitter is recommending me some Z list celeb in a short skirt I just need look at @swmcc and the ans ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 103, 109 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154251096557228032",
    "text" : "If ever I wonder why Twitter is recommending me some Z list celeb in a short skirt I just need look at @swmcc and the answer presents itself",
    "id" : 154251096557228032,
    "created_at" : "2012-01-03 17:21:41 +0000",
    "user" : {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "protected" : false,
      "id_str" : "212603717",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1513037620\/avatar_normal.png",
      "id" : 212603717,
      "verified" : false
    }
  },
  "id" : 154253921672630275,
  "created_at" : "2012-01-03 17:32:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 11, 24 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154200549070356480",
  "geo" : { },
  "id_str" : "154201133513048064",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus @stevebiscuit I'm not working at all...... Cos I am off :)",
  "id" : 154201133513048064,
  "in_reply_to_status_id" : 154200549070356480,
  "created_at" : "2012-01-03 14:03:09 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154190936056922112",
  "geo" : { },
  "id_str" : "154194538460758016",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit fuck knows.... Dread to think :)",
  "id" : 154194538460758016,
  "in_reply_to_status_id" : 154190936056922112,
  "created_at" : "2012-01-03 13:36:57 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154190375609835521",
  "text" : "I just spent close to a 100 quid on a pair of fucking curtains!!!",
  "id" : 154190375609835521,
  "created_at" : "2012-01-03 13:20:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154165773739376641",
  "geo" : { },
  "id_str" : "154166932248068096",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall shut it lady!!!! :)",
  "id" : 154166932248068096,
  "in_reply_to_status_id" : 154165773739376641,
  "created_at" : "2012-01-03 11:47:15 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154163227213828096",
  "geo" : { },
  "id_str" : "154164105379454976",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall full on one - can't really tell the difference between my goatee and beard now.. But its too ithcy. I am gonna shave it off.",
  "id" : 154164105379454976,
  "in_reply_to_status_id" : 154163227213828096,
  "created_at" : "2012-01-03 11:36:01 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154161972299042817",
  "text" : "I haven't shaved since the 23rd...... Its now got the itchy stage... If I can get past this I will keep it. If not - it comes off this avo!",
  "id" : 154161972299042817,
  "created_at" : "2012-01-03 11:27:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154148474919731201",
  "geo" : { },
  "id_str" : "154148665693450240",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit happy birthday dude :)",
  "id" : 154148665693450240,
  "in_reply_to_status_id" : 154148474919731201,
  "created_at" : "2012-01-03 10:34:40 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153944933882015744",
  "text" : "Its kinda wrong that when you email something work related that you get your own out of office :(",
  "id" : 153944933882015744,
  "created_at" : "2012-01-02 21:05:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153883307648618497",
  "geo" : { },
  "id_str" : "153897542998949888",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne can we see? :)",
  "id" : 153897542998949888,
  "in_reply_to_status_id" : 153883307648618497,
  "created_at" : "2012-01-02 17:56:48 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153588646681915392",
  "text" : "Am watching Harry Potter.... Excellent :)",
  "id" : 153588646681915392,
  "created_at" : "2012-01-01 21:29:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153448104098660352",
  "text" : "So this is 2012.... feels just like 2011 to be perfectly honest.",
  "id" : 153448104098660352,
  "created_at" : "2012-01-01 12:10:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]