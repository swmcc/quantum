Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186180492410896385",
  "geo" : { },
  "id_str" : "186184988272766977",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Ironman",
  "id" : 186184988272766977,
  "in_reply_to_status_id" : 186180492410896385,
  "created_at" : "2012-03-31 20:15:35 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 10, 24 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 38, 54 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bunchoffuckingwankersthepairofthem",
      "indices" : [ 56, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186169117097734144",
  "geo" : { },
  "id_str" : "186170007074521089",
  "in_reply_to_user_id" : 437697624,
  "text" : "Fuck you. @peter_omalley And fuck you @michaelnsimpson. #bunchoffuckingwankersthepairofthem",
  "id" : 186170007074521089,
  "in_reply_to_status_id" : 186169117097734144,
  "created_at" : "2012-03-31 19:16:03 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 13, 29 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186166701207977984",
  "geo" : { },
  "id_str" : "186169778967289856",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @michaelnsimpson Kirsty you are now my enemy..... This was no your fight but you are now involved...",
  "id" : 186169778967289856,
  "in_reply_to_status_id" : 186166701207977984,
  "created_at" : "2012-03-31 19:15:08 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 120, 133 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 115 ],
      "url" : "https:\/\/t.co\/liKdy7qK",
      "expanded_url" : "https:\/\/is0.4sqi.net\/pix\/oxG4nsn6GoDg4Brhw-zbmwy-R2bqjo0OhxrMpD6NUl0.jpg",
      "display_url" : "is0.4sqi.net\/pix\/oxG4nsn6Go\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186161731192619009",
  "text" : "Any pyschos out there?!? If you want to kill someone look for this tent at Castleward camp :) https:\/\/t.co\/liKdy7qK \/cc @Paul_Moffett",
  "id" : 186161731192619009,
  "created_at" : "2012-03-31 18:43:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsthatpissmichaeloff",
      "indices" : [ 110, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186143817395736577",
  "geo" : { },
  "id_str" : "186144197588418560",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson Just for that I am gonna drive into work now and re-order the dishes in the washing machine. #thingsthatpissmichaeloff",
  "id" : 186144197588418560,
  "in_reply_to_status_id" : 186143817395736577,
  "created_at" : "2012-03-31 17:33:29 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186109035974639616",
  "geo" : { },
  "id_str" : "186143601137434624",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson fucking racist! :)",
  "id" : 186143601137434624,
  "in_reply_to_status_id" : 186109035974639616,
  "created_at" : "2012-03-31 17:31:07 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Gibson",
      "screen_name" : "stuartgibson",
      "indices" : [ 3, 16 ],
      "id_str" : "6806292",
      "id" : 6806292
    }, {
      "name" : "Chris Armstrong",
      "screen_name" : "Armstrong",
      "indices" : [ 86, 96 ],
      "id_str" : "20555046",
      "id" : 20555046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186087476660682754",
  "text" : "RT @stuartgibson: DeLorean, there's another total disaster we are oddly proud of. \/cc @Armstrong",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Armstrong",
        "screen_name" : "Armstrong",
        "indices" : [ 68, 78 ],
        "id_str" : "20555046",
        "id" : 20555046
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "186077841513910272",
    "text" : "DeLorean, there's another total disaster we are oddly proud of. \/cc @Armstrong",
    "id" : 186077841513910272,
    "created_at" : "2012-03-31 13:09:49 +0000",
    "user" : {
      "name" : "Stuart Gibson",
      "screen_name" : "stuartgibson",
      "protected" : false,
      "id_str" : "6806292",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000478281384\/bf42b345b5e83f0ecb8e748040d185b6_normal.jpeg",
      "id" : 6806292,
      "verified" : false
    }
  },
  "id" : 186087476660682754,
  "created_at" : "2012-03-31 13:48:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ian Jamison",
      "screen_name" : "IanJamison86",
      "indices" : [ 15, 28 ],
      "id_str" : "105243055",
      "id" : 105243055
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 29, 41 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baconfridays",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186034892579160064",
  "geo" : { },
  "id_str" : "186070736195162112",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @ianjamison86 @kirstylvssp he speaks true! He's a culinary god with that thing! #baconfridays",
  "id" : 186070736195162112,
  "in_reply_to_status_id" : 186034892579160064,
  "created_at" : "2012-03-31 12:41:35 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186016022799716353",
  "geo" : { },
  "id_str" : "186018846119952384",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson yup. The business seems to be just surviving and your sneaky dude is the only person wanting it to be bigger atm.",
  "id" : 186018846119952384,
  "in_reply_to_status_id" : 186016022799716353,
  "created_at" : "2012-03-31 09:15:23 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185988456739119104",
  "geo" : { },
  "id_str" : "186012628915720193",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist yeah - xcode is a real pain in the ass isn't it. Only thing missing from the mac - a good package manager.",
  "id" : 186012628915720193,
  "in_reply_to_status_id" : 185988456739119104,
  "created_at" : "2012-03-31 08:50:41 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186009466452451328",
  "geo" : { },
  "id_str" : "186012075997401088",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson brilliant :) It is such a cool show...",
  "id" : 186012075997401088,
  "in_reply_to_status_id" : 186009466452451328,
  "created_at" : "2012-03-31 08:48:29 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185843913460957184",
  "geo" : { },
  "id_str" : "185846497366114305",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall how so?",
  "id" : 185846497366114305,
  "in_reply_to_status_id" : 185843913460957184,
  "created_at" : "2012-03-30 21:50:32 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/185841344336506881\/photo\/1",
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/Sh6mkXDo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApQ9t9ICMAABadg.jpg",
      "id_str" : "185841344340701184",
      "id" : 185841344340701184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApQ9t9ICMAABadg.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Sh6mkXDo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185841344336506881",
  "text" : "Hmmmmmm... Didn't turn out as well as I hoped. http:\/\/t.co\/Sh6mkXDo",
  "id" : 185841344336506881,
  "created_at" : "2012-03-30 21:30:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "canyouguesswhatidid",
      "indices" : [ 72, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185835651361542145",
  "text" : "I am making a savoury mince pie. I even added decorations on top of it. #canyouguesswhatidid?",
  "id" : 185835651361542145,
  "created_at" : "2012-03-30 21:07:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185814284205441024",
  "geo" : { },
  "id_str" : "185835193985286144",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll those that unfollow for that pic need to get a sense of humour. Sure it's a laugh.",
  "id" : 185835193985286144,
  "in_reply_to_status_id" : 185814284205441024,
  "created_at" : "2012-03-30 21:05:37 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew ",
      "screen_name" : "AGRMoore",
      "indices" : [ 0, 9 ],
      "id_str" : "20197876",
      "id" : 20197876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185806185134440449",
  "geo" : { },
  "id_str" : "185820424595181569",
  "in_reply_to_user_id" : 20197876,
  "text" : "@AGRMoore brilliant news about big bang....",
  "id" : 185820424595181569,
  "in_reply_to_status_id" : 185806185134440449,
  "created_at" : "2012-03-30 20:06:56 +0000",
  "in_reply_to_screen_name" : "AGRMoore",
  "in_reply_to_user_id_str" : "20197876",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185819388140716033",
  "text" : "I just filled up mr car in diesel. 59.20 I kid you not!",
  "id" : 185819388140716033,
  "created_at" : "2012-03-30 20:02:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roubdofapplause",
      "indices" : [ 23, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185807016080584704",
  "geo" : { },
  "id_str" : "185818392161300480",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll awesome :) #roubdofapplause",
  "id" : 185818392161300480,
  "in_reply_to_status_id" : 185807016080584704,
  "created_at" : "2012-03-30 19:58:51 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185728091073687553",
  "text" : "I &lt;3 node.js",
  "id" : 185728091073687553,
  "created_at" : "2012-03-30 14:00:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 80, 96 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185715302514962432",
  "text" : "New hobby for the day.... Screwing up the dishes inside the dishwasher.. Drives @michaelnsimpson nuts :D :D",
  "id" : 185715302514962432,
  "created_at" : "2012-03-30 13:09:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185700836838608897",
  "text" : "Just cancelled my netflix account. Wasn't their fault - studios just need to wise the fuck up really :\/",
  "id" : 185700836838608897,
  "created_at" : "2012-03-30 12:11:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185681306754105345",
  "geo" : { },
  "id_str" : "185682782855503872",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore log cabin in siberia.... Only way to go :) I am playing with node.js today for something cool - so am happy :)",
  "id" : 185682782855503872,
  "in_reply_to_status_id" : 185681306754105345,
  "created_at" : "2012-03-30 10:59:59 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 28, 44 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185675718338945024",
  "geo" : { },
  "id_str" : "185675895166611456",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @peter_omalley @michaelnsimpson you can join in - but you gotta make me a cup of coffee by 12. :D",
  "id" : 185675895166611456,
  "in_reply_to_status_id" : 185675718338945024,
  "created_at" : "2012-03-30 10:32:37 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185675581151645696",
  "text" : "Four day week next week then off for 10 days on the trot... Words cannot describe my joy :)",
  "id" : 185675581151645696,
  "created_at" : "2012-03-30 10:31:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185674752168431616",
  "geo" : { },
  "id_str" : "185675421076045824",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall good call on BT9... As for QFT.. ppfffffffttttttttttttttt. Enjoy your day :D",
  "id" : 185675421076045824,
  "in_reply_to_status_id" : 185674752168431616,
  "created_at" : "2012-03-30 10:30:44 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185673083238096896",
  "geo" : { },
  "id_str" : "185673863529635840",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall where are ya brunching?",
  "id" : 185673863529635840,
  "in_reply_to_status_id" : 185673083238096896,
  "created_at" : "2012-03-30 10:24:33 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 32, 44 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185672960844120064",
  "geo" : { },
  "id_str" : "185673177781899265",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson @niall_adams no he fucking can't. I just blackballed him - and not in the good way! :)",
  "id" : 185673177781899265,
  "in_reply_to_status_id" : 185672960844120064,
  "created_at" : "2012-03-30 10:21:49 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185667417421254657",
  "geo" : { },
  "id_str" : "185673089626017792",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett semantics - still not on though.",
  "id" : 185673089626017792,
  "in_reply_to_status_id" : 185667417421254657,
  "created_at" : "2012-03-30 10:21:28 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baconfridays",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185636308775997440",
  "text" : "I am a failure for everything I stand for. Get the pig on - am leaving now. I'll get the baps. How many? #baconfridays",
  "id" : 185636308775997440,
  "created_at" : "2012-03-30 07:55:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185631136058314752",
  "geo" : { },
  "id_str" : "185634596145209344",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley fuck... slept in. Go on without me - will be too long getting in :)",
  "id" : 185634596145209344,
  "in_reply_to_status_id" : 185631136058314752,
  "created_at" : "2012-03-30 07:48:31 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 81, 94 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 95, 107 ],
      "id_str" : "454835425",
      "id" : 454835425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185455415579000832",
  "text" : "Just wrote my first wee sinatra app... Nice. Doesn't do much but it is nice. \/cc @stevebiscuit @BelfastRuby",
  "id" : 185455415579000832,
  "created_at" : "2012-03-29 19:56:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 124, 137 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185428901433049088",
  "text" : "Ringing me up and getting me angry by using the words \"shoreditch\" and \"hipsters\" in a positive way should be illegal!! \/cc @Paul_Moffett",
  "id" : 185428901433049088,
  "created_at" : "2012-03-29 18:11:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/185428259515805696\/photo\/1",
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/vugP4xVZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApLGBQQCMAASIEL.jpg",
      "id_str" : "185428259520000000",
      "id" : 185428259520000000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApLGBQQCMAASIEL.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/vugP4xVZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185428259515805696",
  "text" : "While waiting for a server to resize I did this.... http:\/\/t.co\/vugP4xVZ",
  "id" : 185428259515805696,
  "created_at" : "2012-03-29 18:08:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 41, 57 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter",
      "screen_name" : "PeterOMalley",
      "indices" : [ 64, 77 ],
      "id_str" : "45685217",
      "id" : 45685217
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 78, 92 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185351788751372288",
  "text" : "Hmmmm... WTF are these fabled sandwiches @michaelnsimpson?? \/cc @peteromalley @jenporterhall",
  "id" : 185351788751372288,
  "created_at" : "2012-03-29 13:04:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185315256753602560",
  "geo" : { },
  "id_str" : "185315508848046080",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist i keep meaning too - just too busy this weather.. I'll be back in a bit though.. Think i should go back to irssi and screen :)",
  "id" : 185315508848046080,
  "in_reply_to_status_id" : 185315256753602560,
  "created_at" : "2012-03-29 10:40:34 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185313814286303233",
  "geo" : { },
  "id_str" : "185314845388840960",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist i've found ubuntu server a tad nicer lately. Seems to have nicer updated shiz re: that kinda stuffs.",
  "id" : 185314845388840960,
  "in_reply_to_status_id" : 185313814286303233,
  "created_at" : "2012-03-29 10:37:56 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185264867463278592",
  "text" : "Clouds :( I hate clouds... Was nice while it lasted I guess.",
  "id" : 185264867463278592,
  "created_at" : "2012-03-29 07:19:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185079319247327235",
  "geo" : { },
  "id_str" : "185080761781723136",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley morning and thought he'd turn off the petrol connection to the motor in the mower. He just rang me.",
  "id" : 185080761781723136,
  "in_reply_to_status_id" : 185079319247327235,
  "created_at" : "2012-03-28 19:07:46 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185079319247327235",
  "geo" : { },
  "id_str" : "185080610287656960",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley apparently the lawnmower didn't work cos my dad smelt petrol when he was in my garage this...",
  "id" : 185080610287656960,
  "in_reply_to_status_id" : 185079319247327235,
  "created_at" : "2012-03-28 19:07:10 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185076873766764545",
  "geo" : { },
  "id_str" : "185077243901509632",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley FFS. You don't get it. Kissing another man and wearing pink has nothing to do with manliness!!!",
  "id" : 185077243901509632,
  "in_reply_to_status_id" : 185076873766764545,
  "created_at" : "2012-03-28 18:53:48 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185075635453042690",
  "geo" : { },
  "id_str" : "185076694804201472",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley you",
  "id" : 185076694804201472,
  "in_reply_to_status_id" : 185075635453042690,
  "created_at" : "2012-03-28 18:51:37 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185075635453042690",
  "geo" : { },
  "id_str" : "185076676143747072",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley fuck",
  "id" : 185076676143747072,
  "in_reply_to_status_id" : 185075635453042690,
  "created_at" : "2012-03-28 18:51:32 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185075094975029248",
  "geo" : { },
  "id_str" : "185075500295786498",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson I finished two bastard tickets. No infrastructure broke.. So in relation to how it has been it was a win.",
  "id" : 185075500295786498,
  "in_reply_to_status_id" : 185075094975029248,
  "created_at" : "2012-03-28 18:46:52 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185074237818683394",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley Forgot that I wasn't on IRC there so :x was supposed to be angry. Now it looks like I kissed. Ya. Damage is done so.... XXXXX",
  "id" : 185074237818683394,
  "created_at" : "2012-03-28 18:41:51 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185073207194304513",
  "geo" : { },
  "id_str" : "185074015583473664",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley fucking thing wouldn't start.... Nothing as annoying as that fucking fucker not fucking starting. I fucking hate it!!!!!! :x",
  "id" : 185074015583473664,
  "in_reply_to_status_id" : 185073207194304513,
  "created_at" : "2012-03-28 18:40:58 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185069520849874945",
  "geo" : { },
  "id_str" : "185069732255371265",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus was close though - *very close*.... You know what you have to do to keep it during the next cull :D",
  "id" : 185069732255371265,
  "in_reply_to_status_id" : 185069520849874945,
  "created_at" : "2012-03-28 18:23:57 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185067734160244736",
  "geo" : { },
  "id_str" : "185068325489999874",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson Feel bad - promised my folks I'd do theirs for them but the fucker just wouldn't start.. Am stripping wallpaper again :)",
  "id" : 185068325489999874,
  "in_reply_to_status_id" : 185067734160244736,
  "created_at" : "2012-03-28 18:18:21 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185067996161642496",
  "text" : "Just unfollowed some people - they ranged from twats to people I shouldn't have followed in the first place to randomers. Feels good :)",
  "id" : 185067996161642496,
  "created_at" : "2012-03-28 18:17:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185065902696443904",
  "text" : "Lawnmower 1 - me 1.",
  "id" : 185065902696443904,
  "created_at" : "2012-03-28 18:08:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185017137771970560",
  "geo" : { },
  "id_str" : "185042902030888961",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM that's what I am using twitter for. Keeping up to date with new developing streams. I'll whack onto g+ later to see wh",
  "id" : 185042902030888961,
  "in_reply_to_status_id" : 185017137771970560,
  "created_at" : "2012-03-28 16:37:20 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185001728947658753",
  "geo" : { },
  "id_str" : "185014914904100864",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM I haven't found any use for it yet. Twitter is good for news\/work and general chit chat. Will give it another go sure.",
  "id" : 185014914904100864,
  "in_reply_to_status_id" : 185001728947658753,
  "created_at" : "2012-03-28 14:46:07 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184995279337033728",
  "geo" : { },
  "id_str" : "184995576532840449",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM can't seem to get into it. Maybe I should give it another go. Go on a circle cull etc... Same with FB. Only have twitter now.",
  "id" : 184995576532840449,
  "in_reply_to_status_id" : 184995279337033728,
  "created_at" : "2012-03-28 13:29:17 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Palmer",
      "screen_name" : "tommypalm",
      "indices" : [ 0, 10 ],
      "id_str" : "949101",
      "id" : 949101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184993733824098304",
  "geo" : { },
  "id_str" : "184995321988907008",
  "in_reply_to_user_id" : 949101,
  "text" : "@tommypalm you aren't a proper developer until you can type one handed ;)",
  "id" : 184995321988907008,
  "in_reply_to_status_id" : 184993733824098304,
  "created_at" : "2012-03-28 13:28:16 +0000",
  "in_reply_to_screen_name" : "tommypalm",
  "in_reply_to_user_id_str" : "949101",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184994248586829826",
  "geo" : { },
  "id_str" : "184994822417952768",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM yeah - seems to be the best so far I think. I much prefer this twitter lark to g+ to be honest.",
  "id" : 184994822417952768,
  "in_reply_to_status_id" : 184994248586829826,
  "created_at" : "2012-03-28 13:26:17 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184992999531495426",
  "geo" : { },
  "id_str" : "184993949008658434",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM its quite good. I still think the native twitter app is the best though. What you go with in the end?",
  "id" : 184993949008658434,
  "in_reply_to_status_id" : 184992999531495426,
  "created_at" : "2012-03-28 13:22:49 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184989719271190529",
  "text" : "This weather is so nice that I am looking forward to cutting my grass later...",
  "id" : 184989719271190529,
  "created_at" : "2012-03-28 13:06:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184988661677436928",
  "geo" : { },
  "id_str" : "184988892548706306",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams the priority board does seem to work though.",
  "id" : 184988892548706306,
  "in_reply_to_status_id" : 184988661677436928,
  "created_at" : "2012-03-28 13:02:43 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184987774426943488",
  "geo" : { },
  "id_str" : "184988364867510272",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams stick it on trac... then it wil be done.... circa 2078",
  "id" : 184988364867510272,
  "in_reply_to_status_id" : 184987774426943488,
  "created_at" : "2012-03-28 13:00:37 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184987341767716864",
  "geo" : { },
  "id_str" : "184987583414153216",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I ventured outside or half an hour.",
  "id" : 184987583414153216,
  "in_reply_to_status_id" : 184987341767716864,
  "created_at" : "2012-03-28 12:57:31 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184980769108803585",
  "text" : "I am loving this weather!!!!!!!!!",
  "id" : 184980769108803585,
  "created_at" : "2012-03-28 12:30:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184975036522827778",
  "geo" : { },
  "id_str" : "184980488581165057",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne look at this lovely weather... It is brilliant :D",
  "id" : 184980488581165057,
  "in_reply_to_status_id" : 184975036522827778,
  "created_at" : "2012-03-28 12:29:19 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belfast Ruby",
      "screen_name" : "BelfastRuby",
      "indices" : [ 14, 26 ],
      "id_str" : "454835425",
      "id" : 454835425
    }, {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 42, 53 ],
      "id_str" : "5932682",
      "id" : 5932682
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 58, 71 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Rumble Labs",
      "screen_name" : "rumblelabs",
      "indices" : [ 77, 88 ],
      "id_str" : "20454184",
      "id" : 20454184
    }, {
      "name" : "ExamTime",
      "screen_name" : "ExamTime",
      "indices" : [ 93, 102 ],
      "id_str" : "101378478",
      "id" : 101378478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184922692141596672",
  "text" : "Big thanks to @BelfastRuby. Good talks by @davidjrice and @stevebiscuit. \/cc @rumblelabs and @examtime",
  "id" : 184922692141596672,
  "created_at" : "2012-03-28 08:39:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184915461526392833",
  "text" : "Stupid neighbours got a puppy... Thing started barking at 4am... I am a zombie today and its only just past 9:10 :D Plus I am on support :)",
  "id" : 184915461526392833,
  "created_at" : "2012-03-28 08:10:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Mann",
      "screen_name" : "PeeweeM",
      "indices" : [ 0, 8 ],
      "id_str" : "20186115",
      "id" : 20186115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184719010221408257",
  "geo" : { },
  "id_str" : "184740241838587904",
  "in_reply_to_user_id" : 20186115,
  "text" : "@PeeweeM tweetdeck or just the official twitter app is good. I use the official one on my iPhone and tweetdeck app on chrome for pc.",
  "id" : 184740241838587904,
  "in_reply_to_status_id" : 184719010221408257,
  "created_at" : "2012-03-27 20:34:40 +0000",
  "in_reply_to_screen_name" : "PeeweeM",
  "in_reply_to_user_id_str" : "20186115",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184718921499295746",
  "geo" : { },
  "id_str" : "184731231810887680",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll yes.. cheese & onion and tuna.... Tis fucking awesome!!!",
  "id" : 184731231810887680,
  "in_reply_to_status_id" : 184718921499295746,
  "created_at" : "2012-03-27 19:58:52 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Latest@SYNCNI.com",
      "screen_name" : "syncni",
      "indices" : [ 3, 10 ],
      "id_str" : "19767792",
      "id" : 19767792
    }, {
      "name" : "WorldDesk",
      "screen_name" : "MyWorldDesk",
      "indices" : [ 23, 35 ],
      "id_str" : "188630815",
      "id" : 188630815
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Microsoft",
      "indices" : [ 71, 81 ]
    }, {
      "text" : "Windows",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184642668754780161",
  "text" : "RT @syncni: WorldDesk (@MyWorldDesk) launches 64-bit platform, beating #Microsoft in the race to make #Windows \u2018To Go\u2019 http:\/\/t.co\/ZnleW ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WorldDesk",
        "screen_name" : "MyWorldDesk",
        "indices" : [ 11, 23 ],
        "id_str" : "188630815",
        "id" : 188630815
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Microsoft",
        "indices" : [ 59, 69 ]
      }, {
        "text" : "Windows",
        "indices" : [ 90, 98 ]
      }, {
        "text" : "cloud",
        "indices" : [ 128, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/ZnleWbIZ",
        "expanded_url" : "http:\/\/syncni.com\/news\/6246",
        "display_url" : "syncni.com\/news\/6246"
      } ]
    },
    "geo" : { },
    "id_str" : "184641160889905153",
    "text" : "WorldDesk (@MyWorldDesk) launches 64-bit platform, beating #Microsoft in the race to make #Windows \u2018To Go\u2019 http:\/\/t.co\/ZnleWbIZ #cloud",
    "id" : 184641160889905153,
    "created_at" : "2012-03-27 14:00:57 +0000",
    "user" : {
      "name" : "Latest@SYNCNI.com",
      "screen_name" : "syncni",
      "protected" : false,
      "id_str" : "19767792",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000156051254\/6dbf15e2a603028fa73d1343d23d0c62_normal.jpeg",
      "id" : 19767792,
      "verified" : false
    }
  },
  "id" : 184642668754780161,
  "created_at" : "2012-03-27 14:06:57 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/184642326059159552\/photo\/1",
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/fAf46OuU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ao_7N5-CEAEHyw4.jpg",
      "id_str" : "184642326063353857",
      "id" : 184642326063353857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ao_7N5-CEAEHyw4.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fAf46OuU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184642326059159552",
  "text" : "Big thanks to @michaelnsimpson for this :) http:\/\/t.co\/fAf46OuU",
  "id" : 184642326059159552,
  "created_at" : "2012-03-27 14:05:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 16, 29 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184377360290816000",
  "geo" : { },
  "id_str" : "184377998659698688",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne @stevebiscuit nice :) You plant them in your back garden?",
  "id" : 184377998659698688,
  "in_reply_to_status_id" : 184377360290816000,
  "created_at" : "2012-03-26 20:35:15 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184366445742927872",
  "geo" : { },
  "id_str" : "184377813351137280",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 that was fucking awesome :) I want one. I want one. :)",
  "id" : 184377813351137280,
  "in_reply_to_status_id" : 184366445742927872,
  "created_at" : "2012-03-26 20:34:30 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 61, 70 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184361620590436353",
  "text" : "Forgot the sweet potato for the butternut squash soup recipe @ManyHues gave me (which was excellent). Ah well tomorrow then :)",
  "id" : 184361620590436353,
  "created_at" : "2012-03-26 19:30:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 14, 29 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184360879284944896",
  "geo" : { },
  "id_str" : "184361230415302656",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit @georgina_milne Hippies :(",
  "id" : 184361230415302656,
  "in_reply_to_status_id" : 184360879284944896,
  "created_at" : "2012-03-26 19:28:37 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 1, 14 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 62, 68 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infairnessiwoulddotheexactsamething",
      "indices" : [ 100, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184301603841507329",
  "text" : "\u201C@RickyHassard: I'll never learn.  Apology number 2 issued to @swmcc\u201D Hitting me when I am down.... #infairnessiwoulddotheexactsamething :)",
  "id" : 184301603841507329,
  "created_at" : "2012-03-26 15:31:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 37, 50 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184287870243184640",
  "text" : "It has taken three years.. But today @RickyHassard destroyed me.. At 14:47 he said \"ppl are lying on the grass in the park\". \"we are here\".",
  "id" : 184287870243184640,
  "created_at" : "2012-03-26 14:37:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184276227828350977",
  "text" : "It is way toooo nice to be working today..... Look @ that weather...",
  "id" : 184276227828350977,
  "created_at" : "2012-03-26 13:50:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 91, 104 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184265604608442368",
  "text" : "Some spyde on the street in hillsborough outside the bank. Lets hope he knocks the shit of @RickyHassard... Oh please oh please oh please :)",
  "id" : 184265604608442368,
  "created_at" : "2012-03-26 13:08:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184258655854661632",
  "text" : "What a day :D hamazing weather outside....",
  "id" : 184258655854661632,
  "created_at" : "2012-03-26 12:41:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/xq9peyoI",
      "expanded_url" : "http:\/\/www.titmonday.com\/",
      "display_url" : "titmonday.com"
    } ]
  },
  "in_reply_to_status_id_str" : "184250213630869504",
  "geo" : { },
  "id_str" : "184253807457353728",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne http:\/\/t.co\/xq9peyoI - yes it is sexist. But its a bit of fun :)",
  "id" : 184253807457353728,
  "in_reply_to_status_id" : 184250213630869504,
  "created_at" : "2012-03-26 12:21:45 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/zt4Eipkj",
      "expanded_url" : "http:\/\/www.bikeradar.com\/forums\/viewtopic.php?p=16056369",
      "display_url" : "bikeradar.com\/forums\/viewtop\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "184246658295533568",
  "geo" : { },
  "id_str" : "184247547492184064",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams http:\/\/t.co\/zt4Eipkj - fucking idiot.",
  "id" : 184247547492184064,
  "in_reply_to_status_id" : 184246658295533568,
  "created_at" : "2012-03-26 11:56:53 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "titmonday",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184245884006055937",
  "text" : "Right.. Lets get one things straight.. Today is not tit monday for NI... Wednesday maybe. #titmonday",
  "id" : 184245884006055937,
  "created_at" : "2012-03-26 11:50:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184018945928466433",
  "geo" : { },
  "id_str" : "184019096923406336",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Hmmmmm..... Since its you then you will survive for being class and awesome etc.. Still - no need on a Sunday :)",
  "id" : 184019096923406336,
  "in_reply_to_status_id" : 184018945928466433,
  "created_at" : "2012-03-25 20:49:06 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bastards",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184018008832876544",
  "text" : "Ok.. I went through my twitter feed there a few mins. What dick went and put \"Its got to be perfect\" in my head? Come on - own up! #bastards",
  "id" : 184018008832876544,
  "created_at" : "2012-03-25 20:44:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183992762809589760",
  "geo" : { },
  "id_str" : "184017765861031936",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley I fucking hate Sunday nights.. They suck ass :( And Kirsty do not tempt the Monday\/Tuesday karma weather gods like that.",
  "id" : 184017765861031936,
  "in_reply_to_status_id" : 183992762809589760,
  "created_at" : "2012-03-25 20:43:48 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 115, 128 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184016615980007424",
  "text" : "Lovely evening BBQ tonight @ Paul n Kate's. Did not appreciate the white hair\/beard jokes though - bastards :) \/cc @Paul_Moffett",
  "id" : 184016615980007424,
  "created_at" : "2012-03-25 20:39:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183718323039633408",
  "text" : "I've had an extra day at work so far this year - now am losing an hour of my weekend. Not on...",
  "id" : 183718323039633408,
  "created_at" : "2012-03-25 00:53:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rocknroll",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183686303337021441",
  "geo" : { },
  "id_str" : "183687386562179072",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson ya wha???? You better be doing something cool tonight! Am now at my parents #rocknroll",
  "id" : 183687386562179072,
  "in_reply_to_status_id" : 183686303337021441,
  "created_at" : "2012-03-24 22:51:00 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/183680435035979777\/photo\/1",
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/mKlQvZdJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoyQYerCQAIHUAw.jpg",
      "id_str" : "183680435040174082",
      "id" : 183680435040174082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoyQYerCQAIHUAw.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/mKlQvZdJ"
    } ],
    "hashtags" : [ {
      "text" : "lazyassparents",
      "indices" : [ 9, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183680435035979777",
  "text" : "Done! :) #lazyassparents http:\/\/t.co\/mKlQvZdJ",
  "id" : 183680435035979777,
  "created_at" : "2012-03-24 22:23:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/183679991077277698\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/4GikWR7F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoyP-ozCEAAGYkv.jpg",
      "id_str" : "183679991081472000",
      "id" : 183679991081472000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoyP-ozCEAAGYkv.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/4GikWR7F"
    } ],
    "hashtags" : [ {
      "text" : "lazyassparents",
      "indices" : [ 83, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183679991077277698",
  "text" : "Does it make me a bad son if I text back and say \"Is it your fucking legs!!!!\". :) #lazyassparents http:\/\/t.co\/4GikWR7F",
  "id" : 183679991077277698,
  "created_at" : "2012-03-24 22:21:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 32, 46 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183670708562440193",
  "geo" : { },
  "id_str" : "183679274342039552",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @michaelnsimpson @peter_omalley :) Awww. That's lovely of her! :)",
  "id" : 183679274342039552,
  "in_reply_to_status_id" : 183670708562440193,
  "created_at" : "2012-03-24 22:18:46 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 32, 46 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183664848910041088",
  "geo" : { },
  "id_str" : "183679059925020674",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley @berryblonde84 Nice. But still no build a burger!",
  "id" : 183679059925020674,
  "in_reply_to_status_id" : 183664848910041088,
  "created_at" : "2012-03-24 22:17:55 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/183678729141235714\/photo\/1",
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/DBKfpNAL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoyO1LxCMAAXon6.jpg",
      "id_str" : "183678729158012928",
      "id" : 183678729158012928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoyO1LxCMAAXon6.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DBKfpNAL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183678729141235714",
  "text" : "Mojo huffing with me while I watch BGT. Wee rat bastard! Us McCulloughs can huff, even the dogs! http:\/\/t.co\/DBKfpNAL",
  "id" : 183678729141235714,
  "created_at" : "2012-03-24 22:16:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183584940456292352",
  "text" : "Lawnmover 0 - swmcc 1 :D",
  "id" : 183584940456292352,
  "created_at" : "2012-03-24 16:03:55 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icurse",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183507027593662464",
  "text" : "That time of the year again... Me 'v' The Lawnmower.. Time for the neighbours to lock up their kids cos its usually a messy affair! #icurse",
  "id" : 183507027593662464,
  "created_at" : "2012-03-24 10:54:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Braziel",
      "screen_name" : "Braziel",
      "indices" : [ 0, 8 ],
      "id_str" : "776654",
      "id" : 776654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183320443720187907",
  "geo" : { },
  "id_str" : "183462778588241920",
  "in_reply_to_user_id" : 776654,
  "text" : "@Braziel hope your son is ok. Kids bounce back so quick.",
  "id" : 183462778588241920,
  "in_reply_to_status_id" : 183320443720187907,
  "created_at" : "2012-03-24 07:58:29 +0000",
  "in_reply_to_screen_name" : "Braziel",
  "in_reply_to_user_id_str" : "776654",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183277302770171904",
  "geo" : { },
  "id_str" : "183278925013729280",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley bacon baps... it was bacon baps.. Gotta make that clear now. Bacon baps..",
  "id" : 183278925013729280,
  "in_reply_to_status_id" : 183277302770171904,
  "created_at" : "2012-03-23 19:47:55 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183274838994067458",
  "text" : "Margin Call - hope its good.... No Star Wars to watch tomorrow morning either...",
  "id" : 183274838994067458,
  "created_at" : "2012-03-23 19:31:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183270001191555073",
  "geo" : { },
  "id_str" : "183274568390152195",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley Yup.. We played 'killer' - I killed myself twice... I think we should play this along with bacon fridays!",
  "id" : 183274568390152195,
  "in_reply_to_status_id" : 183270001191555073,
  "created_at" : "2012-03-23 19:30:36 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183270309909110786",
  "geo" : { },
  "id_str" : "183274356498112512",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson and I am telling you to look out for someone that looks like me but with more facial hair ;)",
  "id" : 183274356498112512,
  "in_reply_to_status_id" : 183270309909110786,
  "created_at" : "2012-03-23 19:29:46 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183270309909110786",
  "geo" : { },
  "id_str" : "183274267738259458",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I think my sister is on the same plane as you - but I can't be sure. I told her to look out for a sxc dude with an ipad ;)",
  "id" : 183274267738259458,
  "in_reply_to_status_id" : 183270309909110786,
  "created_at" : "2012-03-23 19:29:25 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 80, 94 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183226888066580480",
  "geo" : { },
  "id_str" : "183227188567490560",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson Don't worry Mike if she throws you out seek out @philipbelcher &amp; my sis. They'll put you up :)",
  "id" : 183227188567490560,
  "in_reply_to_status_id" : 183226888066580480,
  "created_at" : "2012-03-23 16:22:20 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183226056495468545",
  "geo" : { },
  "id_str" : "183226973500358657",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett what about me you heartless bastard - I want something :D",
  "id" : 183226973500358657,
  "in_reply_to_status_id" : 183226056495468545,
  "created_at" : "2012-03-23 16:21:29 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183224702045655040",
  "geo" : { },
  "id_str" : "183224920283680768",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson You are thinking vertically - not horizontally :D :D",
  "id" : 183224920283680768,
  "in_reply_to_status_id" : 183224702045655040,
  "created_at" : "2012-03-23 16:13:19 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183206252535484417",
  "text" : "Boss comes in with a drill... We now have a dart board in the office :D",
  "id" : 183206252535484417,
  "created_at" : "2012-03-23 14:59:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Palmer",
      "screen_name" : "tommypalm",
      "indices" : [ 0, 10 ],
      "id_str" : "949101",
      "id" : 949101
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 35, 44 ],
      "id_str" : "148198686",
      "id" : 148198686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183193672039403520",
  "geo" : { },
  "id_str" : "183197091252813824",
  "in_reply_to_user_id" : 949101,
  "text" : "@tommypalm thanks for saying about @dnsimple - was thinking of moving nameservers - might give them a go.",
  "id" : 183197091252813824,
  "in_reply_to_status_id" : 183193672039403520,
  "created_at" : "2012-03-23 14:22:44 +0000",
  "in_reply_to_screen_name" : "tommypalm",
  "in_reply_to_user_id_str" : "949101",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 12, 26 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183189217952800768",
  "geo" : { },
  "id_str" : "183191280573087745",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @no_underscore Don't call me a ginger! :)",
  "id" : 183191280573087745,
  "in_reply_to_status_id" : 183189217952800768,
  "created_at" : "2012-03-23 13:59:39 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doesmyfuckingheadin",
      "indices" : [ 62, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183186507882958849",
  "text" : "I really loathe my current desk - too much traffic behind me. #doesmyfuckingheadin",
  "id" : 183186507882958849,
  "created_at" : "2012-03-23 13:40:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxine Cassidy",
      "screen_name" : "maxinecassidy",
      "indices" : [ 0, 14 ],
      "id_str" : "24679127",
      "id" : 24679127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183172993147609088",
  "geo" : { },
  "id_str" : "183174418187563008",
  "in_reply_to_user_id" : 24679127,
  "text" : "@maxinecassidy sorry - I hit the wrong thing and fav'd a tweet of yours. Was the pic one and now I look like a perv :( Am not. Stupid macs!",
  "id" : 183174418187563008,
  "in_reply_to_status_id" : 183172993147609088,
  "created_at" : "2012-03-23 12:52:39 +0000",
  "in_reply_to_screen_name" : "maxinecassidy",
  "in_reply_to_user_id_str" : "24679127",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 15, 26 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "takemeoutwitterstyle",
      "indices" : [ 80, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183165762893123584",
  "geo" : { },
  "id_str" : "183171492736020480",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @alana_doll - Awesome pairing :D You really should!!! Go for it! #takemeoutwitterstyle",
  "id" : 183171492736020480,
  "in_reply_to_status_id" : 183165762893123584,
  "created_at" : "2012-03-23 12:41:01 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 22, 36 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 37, 53 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 54, 67 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/183110768462544896\/photo\/1",
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/sdIJMyLM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoqKRhUCQAAmc1N.jpg",
      "id_str" : "183110768466739200",
      "id" : 183110768466739200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoqKRhUCQAAmc1N.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sdIJMyLM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183110768462544896",
  "text" : "Best. Idea. Ever. \/cc @peter_omalley @michaelnsimpson @RickyHassard http:\/\/t.co\/sdIJMyLM",
  "id" : 183110768462544896,
  "created_at" : "2012-03-23 08:39:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 56, 69 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182937812390256640",
  "geo" : { },
  "id_str" : "182939498487889920",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson More than welcome as is @RickyHassard but Chris aint. He shit on it and as a result is excluded forever!",
  "id" : 182939498487889920,
  "in_reply_to_status_id" : 182937812390256640,
  "created_at" : "2012-03-22 21:19:09 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182934754847494144",
  "geo" : { },
  "id_str" : "182935931672739842",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley I know... Epic failure on our part.... Epic :(",
  "id" : 182935931672739842,
  "in_reply_to_status_id" : 182934754847494144,
  "created_at" : "2012-03-22 21:04:59 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182914459759681536",
  "geo" : { },
  "id_str" : "182916913259745280",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I got pig for tomorrow morning. 16 slices to be exact. Smoke backed bacon. Hope the Friday gods are kind to us changing.",
  "id" : 182916913259745280,
  "in_reply_to_status_id" : 182914459759681536,
  "created_at" : "2012-03-22 19:49:25 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182901329973350400",
  "geo" : { },
  "id_str" : "182901705174827008",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I know... Ethics... You have them! Who'da thought it :)",
  "id" : 182901705174827008,
  "in_reply_to_status_id" : 182901329973350400,
  "created_at" : "2012-03-22 18:48:59 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182893045497335808",
  "geo" : { },
  "id_str" : "182899041347174401",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore ethics? :D I am dissapointed in you sir :(",
  "id" : 182899041347174401,
  "in_reply_to_status_id" : 182893045497335808,
  "created_at" : "2012-03-22 18:38:24 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 14, 28 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182874710323888129",
  "geo" : { },
  "id_str" : "182875012708044801",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 @jenporterhall Nope - just Jenni getting me back. The slug was massive and still alive. On a lovely pancake. Was well got.",
  "id" : 182875012708044801,
  "in_reply_to_status_id" : 182874710323888129,
  "created_at" : "2012-03-22 17:02:55 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182872625771581440",
  "geo" : { },
  "id_str" : "182874902242664448",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I am writing a presentation on Testing using Powerpoint.. Feel ma pain :D",
  "id" : 182874902242664448,
  "in_reply_to_status_id" : 182872625771581440,
  "created_at" : "2012-03-22 17:02:29 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 16, 32 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182829401258475521",
  "text" : "Right... Me and @michaelnsimpson need to find a pig for tomorrow.. We want fresh bacon for our new Friday morning ritual :D",
  "id" : 182829401258475521,
  "created_at" : "2012-03-22 14:01:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182823533603336192",
  "text" : "Geek paradise... pfsense firewall shiz to play with =]",
  "id" : 182823533603336192,
  "created_at" : "2012-03-22 13:38:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182793405649268736",
  "text" : "Thank fuck for @michaelnsimpson - he saved me trying to kill someone there... I am not made to talk to assholes.",
  "id" : 182793405649268736,
  "created_at" : "2012-03-22 11:38:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 4, 18 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/182784106810183681\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/w2UZIi5p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AolhLT2CEAA0oWi.jpg",
      "id_str" : "182784106818572288",
      "id" : 182784106818572288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AolhLT2CEAA0oWi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com\/w2UZIi5p"
    } ],
    "hashtags" : [ {
      "text" : "dontmesswiththebimbo",
      "indices" : [ 88, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182784106810183681",
  "text" : "So  @jenporterhall made me a pancake earlier... Can anyone see the added protein in it. #dontmesswiththebimbo http:\/\/t.co\/w2UZIi5p",
  "id" : 182784106810183681,
  "created_at" : "2012-03-22 11:01:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burnthetopofmybaldhead",
      "indices" : [ 53, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182767771669635072",
  "geo" : { },
  "id_str" : "182771627833032704",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR well done on the sun front... We wants more. #burnthetopofmybaldhead",
  "id" : 182771627833032704,
  "in_reply_to_status_id" : 182767771669635072,
  "created_at" : "2012-03-22 10:12:06 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "luvpancakes",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182767326800777216",
  "geo" : { },
  "id_str" : "182768712967917568",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson before... way way before... I have transferred to the lovely @jenportherall who is making me a pancake :D #luvpancakes",
  "id" : 182768712967917568,
  "in_reply_to_status_id" : 182767326800777216,
  "created_at" : "2012-03-22 10:00:31 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182757453023285248",
  "geo" : { },
  "id_str" : "182759279877554176",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher and its a NI company bitch :D We can produce more than bombs, ppl marching and riots :D :D :D \\m\/",
  "id" : 182759279877554176,
  "in_reply_to_status_id" : 182757453023285248,
  "created_at" : "2012-03-22 09:23:02 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182746593538211840",
  "geo" : { },
  "id_str" : "182746638325002240",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke nerd :D",
  "id" : 182746638325002240,
  "in_reply_to_status_id" : 182746593538211840,
  "created_at" : "2012-03-22 08:32:48 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 123, 139 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/zUOQo9kO",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MVNQGUkRX_U",
      "display_url" : "youtube.com\/watch?v=MVNQGU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182746577264328704",
  "text" : "Woke up with the biggest 'CANT BE FUCKED' ever... However listening to this http:\/\/t.co\/zUOQo9kO I now have the outlook of @michaelnsimpson",
  "id" : 182746577264328704,
  "created_at" : "2012-03-22 08:32:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leahwaswrongbutwontadmitit",
      "indices" : [ 99, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182589581332455424",
  "geo" : { },
  "id_str" : "182589808193970177",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 @michaelnsimpson see its stuff like that - that makes me want to create the hashtag #leahwaswrongbutwontadmitit :)",
  "id" : 182589808193970177,
  "in_reply_to_status_id" : 182589581332455424,
  "created_at" : "2012-03-21 22:09:37 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 28, 42 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodtimes",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182583395912646658",
  "text" : "Almost one whole week since @BerryBlonde84 was proved wrong that 'va va va vrrrroooom' was in fact Renault and not Mazda :D #goodtimes :)",
  "id" : 182583395912646658,
  "created_at" : "2012-03-21 21:44:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182475371843821568",
  "text" : "Worst thing about podcasts re: coding - too many assholes ending every sentence with an inflection... Really annoying.",
  "id" : 182475371843821568,
  "created_at" : "2012-03-21 14:34:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182461974507028481",
  "geo" : { },
  "id_str" : "182462955449892864",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight I am hoping it goes well - can't seeing it being bad. Scott is very particular about his stuff.",
  "id" : 182462955449892864,
  "in_reply_to_status_id" : 182461974507028481,
  "created_at" : "2012-03-21 13:45:33 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182365604076982272",
  "geo" : { },
  "id_str" : "182460047308226561",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight i am hoping for good things.",
  "id" : 182460047308226561,
  "in_reply_to_status_id" : 182365604076982272,
  "created_at" : "2012-03-21 13:33:59 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mancardownasswmccisneverendearing",
      "indices" : [ 82, 116 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182237962925383680",
  "geo" : { },
  "id_str" : "182238204404047872",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I am many things. Endearing is not one of them... MAN CARD DOWN. #mancardownasswmccisneverendearing!!",
  "id" : 182238204404047872,
  "in_reply_to_status_id" : 182237962925383680,
  "created_at" : "2012-03-20 22:52:28 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 17, 31 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/182235898119860224\/photo\/1",
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/wBpDSpQe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AodulXUCMAAAeQa.jpg",
      "id_str" : "182235898124054528",
      "id" : 182235898124054528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AodulXUCMAAAeQa.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/wBpDSpQe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182235470145662976",
  "geo" : { },
  "id_str" : "182235898119860224",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @berryblonde84 abusive????? http:\/\/t.co\/wBpDSpQe",
  "id" : 182235898119860224,
  "in_reply_to_status_id" : 182235470145662976,
  "created_at" : "2012-03-20 22:43:19 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182219360419594240",
  "geo" : { },
  "id_str" : "182221385253400576",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 I'll wake him - hang on!",
  "id" : 182221385253400576,
  "in_reply_to_status_id" : 182219360419594240,
  "created_at" : "2012-03-20 21:45:38 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheAppBuilder",
      "screen_name" : "theappbuilder",
      "indices" : [ 3, 17 ],
      "id_str" : "313394051",
      "id" : 313394051
    }, {
      "name" : "TheAppBuilder",
      "screen_name" : "theappbuilder",
      "indices" : [ 19, 33 ],
      "id_str" : "313394051",
      "id" : 313394051
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fastcompany",
      "indices" : [ 53, 65 ]
    }, {
      "text" : "apps",
      "indices" : [ 95, 100 ]
    }, {
      "text" : "iphoneapps",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/mUg9opEm",
      "expanded_url" : "http:\/\/bit.ly\/GEk6Xx",
      "display_url" : "bit.ly\/GEk6Xx"
    } ]
  },
  "geo" : { },
  "id_str" : "182212639806586881",
  "text" : "RT @theappbuilder: @theappbuilder front page news on #fastcompany Read at http:\/\/t.co\/mUg9opEm\n#apps #iphoneapps",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TheAppBuilder",
        "screen_name" : "theappbuilder",
        "indices" : [ 0, 14 ],
        "id_str" : "313394051",
        "id" : 313394051
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fastcompany",
        "indices" : [ 34, 46 ]
      }, {
        "text" : "apps",
        "indices" : [ 76, 81 ]
      }, {
        "text" : "iphoneapps",
        "indices" : [ 82, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/mUg9opEm",
        "expanded_url" : "http:\/\/bit.ly\/GEk6Xx",
        "display_url" : "bit.ly\/GEk6Xx"
      } ]
    },
    "geo" : { },
    "id_str" : "182211665822093313",
    "in_reply_to_user_id" : 313394051,
    "text" : "@theappbuilder front page news on #fastcompany Read at http:\/\/t.co\/mUg9opEm\n#apps #iphoneapps",
    "id" : 182211665822093313,
    "created_at" : "2012-03-20 21:07:01 +0000",
    "in_reply_to_screen_name" : "theappbuilder",
    "in_reply_to_user_id_str" : "313394051",
    "user" : {
      "name" : "TheAppBuilder",
      "screen_name" : "theappbuilder",
      "protected" : false,
      "id_str" : "313394051",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1669441940\/TheAppBuilder_Logo_RedBackground_normal.jpg",
      "id" : 313394051,
      "verified" : false
    }
  },
  "id" : 182212639806586881,
  "created_at" : "2012-03-20 21:10:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182212107469729792",
  "geo" : { },
  "id_str" : "182212592373207040",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq that's what you get with centos :) Give me an account on it and I'll get it going if you want.",
  "id" : 182212592373207040,
  "in_reply_to_status_id" : 182212107469729792,
  "created_at" : "2012-03-20 21:10:42 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 17, 31 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 32, 45 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dedication",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182207461141389316",
  "geo" : { },
  "id_str" : "182210375662575616",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @peter_omalley @rickyhassard I'd come in an hour earlier to make up the time if a keep hit device can be found. #dedication",
  "id" : 182210375662575616,
  "in_reply_to_status_id" : 182207461141389316,
  "created_at" : "2012-03-20 21:01:53 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182206939659386882",
  "geo" : { },
  "id_str" : "182210102923763713",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq Debian and make it easy",
  "id" : 182210102923763713,
  "in_reply_to_status_id" : 182206939659386882,
  "created_at" : "2012-03-20 21:00:48 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182207467311218688",
  "geo" : { },
  "id_str" : "182208930036985856",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley bound to be some sort of device that keeps it hot.",
  "id" : 182208930036985856,
  "in_reply_to_status_id" : 182207467311218688,
  "created_at" : "2012-03-20 20:56:08 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182207133725634560",
  "text" : "This cold is starting to take a hold... I think. Dunno. Crappy sore throat - grrrrrrrrrr",
  "id" : 182207133725634560,
  "created_at" : "2012-03-20 20:49:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182203934012735488",
  "geo" : { },
  "id_str" : "182206313017782273",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq cpanel!!! Euugggghhh :) Do it then... When you get it done give me the addy...",
  "id" : 182206313017782273,
  "in_reply_to_status_id" : 182203934012735488,
  "created_at" : "2012-03-20 20:45:44 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182194256998449152",
  "geo" : { },
  "id_str" : "182203241247936514",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq just means you don't have to worry about upgrading the software every so often. You gonna host it on wintermute?",
  "id" : 182203241247936514,
  "in_reply_to_status_id" : 182194256998449152,
  "created_at" : "2012-03-20 20:33:32 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 58, 72 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 73, 86 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 91, 107 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182194888559964160",
  "text" : "Hmmm - next Friday - build a burger for Friday lunch? \/cc @peter_omalley @RickyHassard and @michaelnsimpson",
  "id" : 182194888559964160,
  "created_at" : "2012-03-20 20:00:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182163146893557760",
  "geo" : { },
  "id_str" : "182187333683134464",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq you should. I recommend using one of the hosted solutions like Wordpress or Blogger instead of hosting your own.",
  "id" : 182187333683134464,
  "in_reply_to_status_id" : 182163146893557760,
  "created_at" : "2012-03-20 19:30:19 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182129461095964672",
  "geo" : { },
  "id_str" : "182129960306216960",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg get my name out there more... So new stuff being learnt, blog up, site up and twitter is now hopen. Dunno why - I just talk shite",
  "id" : 182129960306216960,
  "in_reply_to_status_id" : 182129461095964672,
  "created_at" : "2012-03-20 15:42:21 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182129461095964672",
  "geo" : { },
  "id_str" : "182129840932134912",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg Ack you are always \"special\" Paul - always :) Was getting sick of the spam. But a trusted source told me I need...",
  "id" : 182129840932134912,
  "in_reply_to_status_id" : 182129461095964672,
  "created_at" : "2012-03-20 15:41:52 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/fKR1b2Z6",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=nmJOO6D5RvA",
      "display_url" : "youtube.com\/watch?v=nmJOO6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182124336709246976",
  "text" : "http:\/\/t.co\/fKR1b2Z6 - Cannot. Fucking. Wait.",
  "id" : 182124336709246976,
  "created_at" : "2012-03-20 15:20:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182118651191762944",
  "geo" : { },
  "id_str" : "182122147546800129",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg yeah - hopefully the spammers are gone... Was one of the reasons I locked it. How did you know?",
  "id" : 182122147546800129,
  "in_reply_to_status_id" : 182118651191762944,
  "created_at" : "2012-03-20 15:11:18 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182117670232137729",
  "text" : "Working without coffee is pretty shit.. Haven't had one so far today at all - due to meetings and road trips... Can't wait..",
  "id" : 182117670232137729,
  "created_at" : "2012-03-20 14:53:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alvynmcq",
      "screen_name" : "alvynmcq",
      "indices" : [ 0, 9 ],
      "id_str" : "16155145",
      "id" : 16155145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181880623781261312",
  "geo" : { },
  "id_str" : "182091802583646208",
  "in_reply_to_user_id" : 16155145,
  "text" : "@alvynmcq yeah if you want to :) What you gonna talk about? I have to have one for geek fu apparently",
  "id" : 182091802583646208,
  "in_reply_to_status_id" : 181880623781261312,
  "created_at" : "2012-03-20 13:10:43 +0000",
  "in_reply_to_screen_name" : "alvynmcq",
  "in_reply_to_user_id_str" : "16155145",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 31, 43 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182091626146050048",
  "text" : "Road trip to carrick done with @niall_adams :)",
  "id" : 182091626146050048,
  "created_at" : "2012-03-20 13:10:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181877411720343552",
  "text" : "I feel like I am coming down with the cold. This does not please me.",
  "id" : 181877411720343552,
  "created_at" : "2012-03-19 22:58:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181873158868058112",
  "geo" : { },
  "id_str" : "181873351160102912",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams Yay :D Pity its to Carrick... Will be like old times :D",
  "id" : 181873351160102912,
  "in_reply_to_status_id" : 181873158868058112,
  "created_at" : "2012-03-19 22:42:40 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181815716931051520",
  "geo" : { },
  "id_str" : "181815934464430080",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley FUCK FUCK FUCK FUCK FUCK FUCK FUCK FUCK FUCK FUCK AND FUCK FORGOT ABOUT THAT....",
  "id" : 181815934464430080,
  "in_reply_to_status_id" : 181815716931051520,
  "created_at" : "2012-03-19 18:54:31 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181812408208195584",
  "text" : "Just remembered I have to go to Carrick tomorrow... For fuck sake...",
  "id" : 181812408208195584,
  "created_at" : "2012-03-19 18:40:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181703211831398400",
  "geo" : { },
  "id_str" : "181712070327275521",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard Oh cheers then :) All good - learning new stuffs at the mo. NI is always raining.. Always :)",
  "id" : 181712070327275521,
  "in_reply_to_status_id" : 181703211831398400,
  "created_at" : "2012-03-19 12:01:48 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Shore Film",
      "screen_name" : "theshorefilm",
      "indices" : [ 3, 16 ],
      "id_str" : "202819500",
      "id" : 202819500
    }, {
      "name" : "The Shore Film",
      "screen_name" : "theshorefilm",
      "indices" : [ 36, 49 ],
      "id_str" : "202819500",
      "id" : 202819500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181496537019449345",
  "text" : "RT @theshorefilm: The Oscar-winning @theshorefilm is on BBC Four tonight at 10.30pm. Please RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Shore Film",
        "screen_name" : "theshorefilm",
        "indices" : [ 18, 31 ],
        "id_str" : "202819500",
        "id" : 202819500
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181491363462914049",
    "text" : "The Oscar-winning @theshorefilm is on BBC Four tonight at 10.30pm. Please RT",
    "id" : 181491363462914049,
    "created_at" : "2012-03-18 21:24:47 +0000",
    "user" : {
      "name" : "The Shore Film",
      "screen_name" : "theshorefilm",
      "protected" : false,
      "id_str" : "202819500",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1292521520\/TheShore_Avatar_Pic_normal.png",
      "id" : 202819500,
      "verified" : false
    }
  },
  "id" : 181496537019449345,
  "created_at" : "2012-03-18 21:45:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 0, 14 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181371630642135040",
  "geo" : { },
  "id_str" : "181377052866383872",
  "in_reply_to_user_id" : 233333546,
  "text" : "@madebyrichard sarcasm my friend? :) How are ya anyway?",
  "id" : 181377052866383872,
  "in_reply_to_status_id" : 181371630642135040,
  "created_at" : "2012-03-18 13:50:33 +0000",
  "in_reply_to_screen_name" : "madebyrichard",
  "in_reply_to_user_id_str" : "233333546",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/n4AETti7",
      "expanded_url" : "http:\/\/swmcc.wordpress.com\/2012\/03\/18\/new-site\/",
      "display_url" : "swmcc.wordpress.com\/2012\/03\/18\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181370878456631296",
  "text" : "New Blog Post - http:\/\/t.co\/n4AETti7",
  "id" : 181370878456631296,
  "created_at" : "2012-03-18 13:26:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181185464743628800",
  "geo" : { },
  "id_str" : "181185703563116544",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson Yup :D Was up at 7:30 - watched Star Wars and Spartacus - went back to bed and only up at 9:45pm :D Awesomeage :)",
  "id" : 181185703563116544,
  "in_reply_to_status_id" : 181185464743628800,
  "created_at" : "2012-03-18 01:10:12 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 17, 31 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181184524892377089",
  "geo" : { },
  "id_str" : "181184859904028672",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @berryblonde84 Hi :D Did you tell her about her being wrong re: the Mazda adverts? Ha ha :) You still up then?",
  "id" : 181184859904028672,
  "in_reply_to_status_id" : 181184524892377089,
  "created_at" : "2012-03-18 01:06:51 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181183887349776384",
  "text" : "Slept most of the day and am now wide *AWAKE*!!!! =D",
  "id" : 181183887349776384,
  "created_at" : "2012-03-18 01:02:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180948295022153728",
  "geo" : { },
  "id_str" : "181013535000768512",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Well done, thanks very much :D I love your hash tags lol...",
  "id" : 181013535000768512,
  "in_reply_to_status_id" : 180948295022153728,
  "created_at" : "2012-03-17 13:46:04 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Scott",
      "screen_name" : "jamesscott",
      "indices" : [ 3, 14 ],
      "id_str" : "6643052",
      "id" : 6643052
    }, {
      "name" : "TheAppBuilder",
      "screen_name" : "theappbuilder",
      "indices" : [ 33, 47 ],
      "id_str" : "313394051",
      "id" : 313394051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/mbRCYGbE",
      "expanded_url" : "http:\/\/engt.co\/zRtvfa",
      "display_url" : "engt.co\/zRtvfa"
    } ]
  },
  "geo" : { },
  "id_str" : "180926294345785344",
  "text" : "RT @jamesscott: Incredibly proud @theappbuilder (made in belfast) featured on Engadget today http:\/\/t.co\/mbRCYGbE ...and we're just gett ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TheAppBuilder",
        "screen_name" : "theappbuilder",
        "indices" : [ 17, 31 ],
        "id_str" : "313394051",
        "id" : 313394051
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/mbRCYGbE",
        "expanded_url" : "http:\/\/engt.co\/zRtvfa",
        "display_url" : "engt.co\/zRtvfa"
      } ]
    },
    "geo" : { },
    "id_str" : "180764859112226816",
    "text" : "Incredibly proud @theappbuilder (made in belfast) featured on Engadget today http:\/\/t.co\/mbRCYGbE ...and we're just getting warmed up :)",
    "id" : 180764859112226816,
    "created_at" : "2012-03-16 21:17:55 +0000",
    "user" : {
      "name" : "James Scott",
      "screen_name" : "jamesscott",
      "protected" : false,
      "id_str" : "6643052",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1565623575\/James_-_Get_Excited_normal.jpg",
      "id" : 6643052,
      "verified" : false
    }
  },
  "id" : 180926294345785344,
  "created_at" : "2012-03-17 07:59:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180787766756524032",
  "geo" : { },
  "id_str" : "180789990438076416",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley awesome :) hot shiz there..",
  "id" : 180789990438076416,
  "in_reply_to_status_id" : 180787766756524032,
  "created_at" : "2012-03-16 22:57:47 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180733274098909184",
  "geo" : { },
  "id_str" : "180734146832908289",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson that will come back to bite me in the ass.. But I could give a flying fuck right about now! :)",
  "id" : 180734146832908289,
  "in_reply_to_status_id" : 180733274098909184,
  "created_at" : "2012-03-16 19:15:53 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 33 ],
      "url" : "http:\/\/t.co\/h0yBGAv",
      "expanded_url" : "http:\/\/webapps.stackexchange.com\/questions\/20879\/how-did-this-guy-hack-twitters-140-character-limit",
      "display_url" : "webapps.stackexchange.com\/questions\/2087\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "180733652139909121",
  "geo" : { },
  "id_str" : "180734053924880385",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit http:\/\/t.co\/h0yBGAv - this was it... Was a bad week and I just ranted :)",
  "id" : 180734053924880385,
  "in_reply_to_status_id" : 180733652139909121,
  "created_at" : "2012-03-16 19:15:30 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180733341425876992",
  "text" : "Sorry - its been a bad week :) But now to play with sublime, node.js, RoR and relax :D First - watch Warrior :D",
  "id" : 180733341425876992,
  "created_at" : "2012-03-16 19:12:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180732945538097152",
  "text" : "Its not  hacking twitter either. Fucking morons. But what do I know - I just create software instead of going SXSW &amp; wanking myself to death",
  "id" : 180732945538097152,
  "created_at" : "2012-03-16 19:11:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipsterkidsprobablydont",
      "indices" : [ 116, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180732392804327424",
  "text" : "I just unfollowed two twats that did that 140 char limit thing. You only survive if you know why it works that way. #hipsterkidsprobablydont",
  "id" : 180732392804327424,
  "created_at" : "2012-03-16 19:08:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bigdirtydump",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180731492199178240",
  "geo" : { },
  "id_str" : "180732016445227008",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR I know I suck... Will get on it! Dexter - still need to watch last season. #bigdirtydump",
  "id" : 180732016445227008,
  "in_reply_to_status_id" : 180731492199178240,
  "created_at" : "2012-03-16 19:07:25 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 64, 77 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180730959518375936",
  "geo" : { },
  "id_str" : "180731163021815808",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley You buy an Apple TV.. Fanboy.. Did you listen to @RickyHassard ... Am on the wall re: it.. Let me know how you get on.",
  "id" : 180731163021815808,
  "in_reply_to_status_id" : 180730959518375936,
  "created_at" : "2012-03-16 19:04:01 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180730340095180800",
  "geo" : { },
  "id_str" : "180730999880155136",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR cool :) I have four episodes of damages and the fan boy pics to still give you... Must get on that. Switch computie on.",
  "id" : 180730999880155136,
  "in_reply_to_status_id" : 180730340095180800,
  "created_at" : "2012-03-16 19:03:22 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bekadeliversalright",
      "indices" : [ 71, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180729169615912960",
  "geo" : { },
  "id_str" : "180729837776941057",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR I also see you shoved in a three day weekend too. Nice one. :) #bekadeliversalright",
  "id" : 180729837776941057,
  "in_reply_to_status_id" : 180729169615912960,
  "created_at" : "2012-03-16 18:58:45 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180684055203946496",
  "geo" : { },
  "id_str" : "180684266705920001",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 four out of the seven of those are wrong... close though... defffo close.",
  "id" : 180684266705920001,
  "in_reply_to_status_id" : 180684055203946496,
  "created_at" : "2012-03-16 15:57:40 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180684105682399233",
  "text" : "Non work geek type things though....",
  "id" : 180684105682399233,
  "created_at" : "2012-03-16 15:57:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180680211338231810",
  "text" : "Three day weekend... Gonna geek it up with many geek type things :D",
  "id" : 180680211338231810,
  "created_at" : "2012-03-16 15:41:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 3, 12 ],
      "id_str" : "80937118",
      "id" : 80937118
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 13, 26 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 27, 39 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180654047689310208",
  "text" : "FF @kirkcoyb @Paul_Moffett @willemkokke - sexy ass mother fuckers :D",
  "id" : 180654047689310208,
  "created_at" : "2012-03-16 13:57:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180650805735604224",
  "geo" : { },
  "id_str" : "180651681858596866",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson the beach boys are good don't get me wrong... Its just that its pishing outside and I am still a tad grumpy. Much Love! :D",
  "id" : 180651681858596866,
  "in_reply_to_status_id" : 180650805735604224,
  "created_at" : "2012-03-16 13:48:11 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180650395926925313",
  "text" : "I can't quite fathom how in the name of blue mercy fuck we are listening to the beach boys up here..",
  "id" : 180650395926925313,
  "created_at" : "2012-03-16 13:43:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 17, 31 ],
      "id_str" : "77241609",
      "id" : 77241609
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 32, 46 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 51, 65 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180595161439543296",
  "geo" : { },
  "id_str" : "180595774294458368",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @berryblonde84 @peter_omalley But @jenporterhall wont.. cos its not a car - its a fucking mouse! \"I can see its wee eyes!\"",
  "id" : 180595774294458368,
  "in_reply_to_status_id" : 180595161439543296,
  "created_at" : "2012-03-16 10:06:02 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 4, 18 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "howsyourheadthismorning",
      "indices" : [ 93, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http:\/\/t.co\/kjh96Y3",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=OJuWDsJkYLc",
      "display_url" : "youtube.com\/watch?v=OJuWDs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180594458360954880",
  "text" : "Yo! @BerryBlonde84... \/me clears throat... YOU. WERE. COMPLETELY. WRONG. http:\/\/t.co\/kjh96Y3 #howsyourheadthismorning? :D :D :D",
  "id" : 180594458360954880,
  "created_at" : "2012-03-16 10:00:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 54, 68 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180452136872706048",
  "geo" : { },
  "id_str" : "180456280194940928",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 We would have won if not for the lovely @jenporterhall. Mouse v woodpecker!!! Next time well kick your ass!!",
  "id" : 180456280194940928,
  "in_reply_to_status_id" : 180452136872706048,
  "created_at" : "2012-03-16 00:51:44 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180450772625002497",
  "geo" : { },
  "id_str" : "180455831173738498",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne you're up late in a school night.",
  "id" : 180455831173738498,
  "in_reply_to_status_id" : 180450772625002497,
  "created_at" : "2012-03-16 00:49:57 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "indices" : [ 3, 14 ],
      "id_str" : "66949689",
      "id" : 66949689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbc",
      "indices" : [ 101, 105 ]
    }, {
      "text" : "aleshadixon",
      "indices" : [ 106, 118 ]
    }, {
      "text" : "animation",
      "indices" : [ 119, 129 ]
    }, {
      "text" : "black",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180327312905076736",
  "text" : "RT @blacknorth: Watch our latest animation 'behind closed doors' on BBC1 Monday the 19th March 5pm.  #bbc #aleshadixon #animation #black ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bbc",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "aleshadixon",
        "indices" : [ 90, 102 ]
      }, {
        "text" : "animation",
        "indices" : [ 103, 113 ]
      }, {
        "text" : "blacknorth",
        "indices" : [ 114, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180326831185076225",
    "text" : "Watch our latest animation 'behind closed doors' on BBC1 Monday the 19th March 5pm.  #bbc #aleshadixon #animation #blacknorth",
    "id" : 180326831185076225,
    "created_at" : "2012-03-15 16:17:21 +0000",
    "user" : {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "protected" : false,
      "id_str" : "66949689",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/759091973\/blacklogo_normal.gif",
      "id" : 66949689,
      "verified" : false
    }
  },
  "id" : 180327312905076736,
  "created_at" : "2012-03-15 16:19:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunning",
      "screen_name" : "ryancunning",
      "indices" : [ 17, 29 ],
      "id_str" : "226910307",
      "id" : 226910307
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/180324851481972736\/photo\/1",
      "indices" : [ 30, 49 ],
      "url" : "http:\/\/t.co\/8w4DfK7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoCkfz0CEAA-6_b.jpg",
      "id_str" : "180324851486167040",
      "id" : 180324851486167040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoCkfz0CEAA-6_b.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/8w4DfK7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180324851481972736",
  "text" : "Awesomeness from @ryancunning http:\/\/t.co\/8w4DfK7",
  "id" : 180324851481972736,
  "created_at" : "2012-03-15 16:09:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 34, 41 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180321415130652672",
  "text" : "I've just been felt up in work by @srushe.... That is all.",
  "id" : 180321415130652672,
  "created_at" : "2012-03-15 15:55:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 13, 24 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 60, 73 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180311966798196736",
  "geo" : { },
  "id_str" : "180313486201589760",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @johngirvin do we have to get tshirts made for @Paul_Moffett stag do? Can I deputise you for this too if we do? ;)",
  "id" : 180313486201589760,
  "in_reply_to_status_id" : 180311966798196736,
  "created_at" : "2012-03-15 15:24:19 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 14, 30 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 92, 106 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180293012788756481",
  "text" : "Next week for @michaelnsimpson man challenge is the infamous 'Cinnamon Challenge' thanks to @jenporterhall i have to do it with him now.",
  "id" : 180293012788756481,
  "created_at" : "2012-03-15 14:02:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 16, 32 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugarrush",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180288803297169408",
  "text" : "Full respect to @michaelnsimpson for he just whacked SIX creme eggs down him there in 5mins!!! #sugarrush",
  "id" : 180288803297169408,
  "created_at" : "2012-03-15 13:46:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180284572632760321",
  "text" : "2 hour episode showing next week of Mad Men is just about enough to lift me out of this funk that I am in... But not quite....",
  "id" : 180284572632760321,
  "created_at" : "2012-03-15 13:29:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180270788765679616",
  "geo" : { },
  "id_str" : "180275871326806016",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore three years to the hoverboard.",
  "id" : 180275871326806016,
  "in_reply_to_status_id" : 180270788765679616,
  "created_at" : "2012-03-15 12:54:51 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180240608890322944",
  "geo" : { },
  "id_str" : "180240965947236352",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson I didn't though!!! You are blaming me in the wrong...",
  "id" : 180240965947236352,
  "in_reply_to_status_id" : 180240608890322944,
  "created_at" : "2012-03-15 10:36:09 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 55, 71 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pancakegate",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180237773603733504",
  "text" : "Poor wee students heard a load of abuse between me and @michaelnsimpson in the kitchen. We were unaware that they were there. #pancakegate",
  "id" : 180237773603733504,
  "created_at" : "2012-03-15 10:23:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180052275782352897",
  "geo" : { },
  "id_str" : "180052580133638145",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson Nope - wasn't you... Was just a feeling.. :)",
  "id" : 180052580133638145,
  "in_reply_to_status_id" : 180052275782352897,
  "created_at" : "2012-03-14 22:07:34 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180050479693299713",
  "text" : "Tomorrow is Thursday....... This pleases me.... Today felt like a Thursday... This did not please me.",
  "id" : 180050479693299713,
  "created_at" : "2012-03-14 21:59:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180022631154724865",
  "geo" : { },
  "id_str" : "180028367473618944",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues :) I love c&amp;c soup... Feel free to send any my way. Great fully received :)",
  "id" : 180028367473618944,
  "in_reply_to_status_id" : 180022631154724865,
  "created_at" : "2012-03-14 20:31:22 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179955596357926913",
  "geo" : { },
  "id_str" : "179955763815522307",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight what happened in your last one?",
  "id" : 179955763815522307,
  "in_reply_to_status_id" : 179955596357926913,
  "created_at" : "2012-03-14 15:42:52 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179936059617062912",
  "geo" : { },
  "id_str" : "179951147258355713",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues You are a STAR.. Shall give this a go on Saturday :) :) Thank you very very mucho :)",
  "id" : 179951147258355713,
  "in_reply_to_status_id" : 179936059617062912,
  "created_at" : "2012-03-14 15:24:31 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179924229733613568",
  "text" : "The soup I made last night - tastes like ass :(",
  "id" : 179924229733613568,
  "created_at" : "2012-03-14 13:37:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sonia Hastings",
      "screen_name" : "sonic171281",
      "indices" : [ 0, 12 ],
      "id_str" : "144556150",
      "id" : 144556150
    }, {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 13, 29 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179906634020171776",
  "geo" : { },
  "id_str" : "179908673458552832",
  "in_reply_to_user_id" : 144556150,
  "text" : "@sonic171281 @anthonyhastings @bkgstatus seriously what the fuck is going on here? Am I having a stroke?",
  "id" : 179908673458552832,
  "in_reply_to_status_id" : 179906634020171776,
  "created_at" : "2012-03-14 12:35:44 +0000",
  "in_reply_to_screen_name" : "sonic171281",
  "in_reply_to_user_id_str" : "144556150",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179852386746109954",
  "text" : "Right... Wednesday then.... This week will not fucking destroy me. Not that is a bad week though.. I just aint feeling it!",
  "id" : 179852386746109954,
  "created_at" : "2012-03-14 08:52:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179702523437916161",
  "geo" : { },
  "id_str" : "179702801964875777",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore If the next few episodes are good it might win me over.. But this season has been very weak. Will see what happens..",
  "id" : 179702801964875777,
  "in_reply_to_status_id" : 179702523437916161,
  "created_at" : "2012-03-13 22:57:41 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179699611852738560",
  "geo" : { },
  "id_str" : "179702152254603264",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore next season should be good - but it depends how much they take from the comics. I think they are doing their own thang though",
  "id" : 179702152254603264,
  "in_reply_to_status_id" : 179699611852738560,
  "created_at" : "2012-03-13 22:55:06 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179699611852738560",
  "geo" : { },
  "id_str" : "179701332486262784",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore yeah well could be an 'infection' that is now air borne to dead people that still have their brains in tact... Dunno :)",
  "id" : 179701332486262784,
  "in_reply_to_status_id" : 179699611852738560,
  "created_at" : "2012-03-13 22:51:51 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179674496054202368",
  "geo" : { },
  "id_str" : "179696879028805632",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore Hmmm.. Well at least the story has finally moved on a bit.. Not a bad episode - but a very slow season me thinks.",
  "id" : 179696879028805632,
  "in_reply_to_status_id" : 179674496054202368,
  "created_at" : "2012-03-13 22:34:09 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179693704334942208",
  "geo" : { },
  "id_str" : "179696560450453505",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight the last one there wasn't too bad (shown in the US last Friday). Finally moved the story on.",
  "id" : 179696560450453505,
  "in_reply_to_status_id" : 179693704334942208,
  "created_at" : "2012-03-13 22:32:53 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179681840121126912",
  "geo" : { },
  "id_str" : "179682252819660801",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor kinda ironic though... You considering your disability and all... :D",
  "id" : 179682252819660801,
  "in_reply_to_status_id" : 179681840121126912,
  "created_at" : "2012-03-13 21:36:02 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179674496054202368",
  "geo" : { },
  "id_str" : "179674755388014592",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore 10-4 good buddy!",
  "id" : 179674755388014592,
  "in_reply_to_status_id" : 179674496054202368,
  "created_at" : "2012-03-13 21:06:14 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179674210967363584",
  "text" : "Am now downing tools to go watch the latest episode of The Walking Dead. See if they are still fucking around this farm I am gonna go crazy!",
  "id" : 179674210967363584,
  "created_at" : "2012-03-13 21:04:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keepitup",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179671318659211264",
  "geo" : { },
  "id_str" : "179672076486066178",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard Well - as long as I can pick yer brain when it comes to doing the HTML5 portion of this wee project I am on :) #keepitup",
  "id" : 179672076486066178,
  "in_reply_to_status_id" : 179671318659211264,
  "created_at" : "2012-03-13 20:55:35 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179655182479663104",
  "geo" : { },
  "id_str" : "179670687651336192",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard doing anything interesting with HTML5? I've had a wee play and like what I see so far. Am loving node.js at the mo :)",
  "id" : 179670687651336192,
  "in_reply_to_status_id" : 179655182479663104,
  "created_at" : "2012-03-13 20:50:04 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179668540918472704",
  "geo" : { },
  "id_str" : "179670273853882368",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc well actually firms behaving better pays my bills. So should qualify. It doesn't interest me that much. :)",
  "id" : 179670273853882368,
  "in_reply_to_status_id" : 179668540918472704,
  "created_at" : "2012-03-13 20:48:26 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179637333606416384",
  "geo" : { },
  "id_str" : "179669911415697408",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley nice :) I expect to see something tomorrow :)",
  "id" : 179669911415697408,
  "in_reply_to_status_id" : 179637333606416384,
  "created_at" : "2012-03-13 20:46:59 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179668540918472704",
  "text" : "After 12 years I finally like javascript - only cos I get to do proper programming in it though. Making forms act better aint programming!",
  "id" : 179668540918472704,
  "created_at" : "2012-03-13 20:41:32 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 26, 42 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179663205818310656",
  "text" : "I hope I get to play with @michaelnsimpson tomorrow... Upstairs aint the same without his womanly ways :)",
  "id" : 179663205818310656,
  "created_at" : "2012-03-13 20:20:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179662660969840640",
  "text" : "swm@legolas: sudo su - swm is not in the sudoers file. Ha - what a knob!",
  "id" : 179662660969840640,
  "created_at" : "2012-03-13 20:18:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179662173214224385",
  "text" : "I have to say that on my old home pc - 2Gig of RAM with vista - VirtualBox running a debian instance is nice and solid.",
  "id" : 179662173214224385,
  "created_at" : "2012-03-13 20:16:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179630281647595521",
  "geo" : { },
  "id_str" : "179634021314211840",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley fucking this should just work... Man I need this 3 day break :)",
  "id" : 179634021314211840,
  "in_reply_to_status_id" : 179630281647595521,
  "created_at" : "2012-03-13 18:24:22 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 0, 9 ],
      "id_str" : "8388092",
      "id" : 8388092
    }, {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 10, 21 ],
      "id_str" : "5932682",
      "id" : 5932682
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 22, 35 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179621971435339776",
  "geo" : { },
  "id_str" : "179623608061149184",
  "in_reply_to_user_id" : 8388092,
  "text" : "@hamstarr @davidjrice @rickyhassard Noted. Seek me out at the next meet and a pint will be yours :)",
  "id" : 179623608061149184,
  "in_reply_to_status_id" : 179621971435339776,
  "created_at" : "2012-03-13 17:43:00 +0000",
  "in_reply_to_screen_name" : "hamstarr",
  "in_reply_to_user_id_str" : "8388092",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179569146063896577",
  "geo" : { },
  "id_str" : "179569938091085824",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin take another 30 seconds and tweet about it again ;)",
  "id" : 179569938091085824,
  "in_reply_to_status_id" : 179569146063896577,
  "created_at" : "2012-03-13 14:09:44 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 90, 101 ],
      "id_str" : "5932682",
      "id" : 5932682
    }, {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 102, 111 ],
      "id_str" : "8388092",
      "id" : 8388092
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 115, 128 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stepforth",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179541082453983233",
  "text" : "BTW. I need to buy someone a pint.. Who told me about Coffee JS? Was one of these three - @davidjrice @hamstarr or @RickyHassard. #stepforth",
  "id" : 179541082453983233,
  "created_at" : "2012-03-13 12:15:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179491139873812480",
  "text" : "So on my commute into work I will be listening to a node.js podcast... Yup... Today will be better than yesterday...",
  "id" : 179491139873812480,
  "created_at" : "2012-03-13 08:56:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Johnston",
      "screen_name" : "cimota",
      "indices" : [ 0, 7 ],
      "id_str" : "14060295",
      "id" : 14060295
    }, {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 8, 17 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179478074251935744",
  "geo" : { },
  "id_str" : "179490784922435584",
  "in_reply_to_user_id" : 14060295,
  "text" : "@cimota @hamstarr I deal with LPS on a weekly basis. I know how this is gonna go :( At least you tried though :(",
  "id" : 179490784922435584,
  "in_reply_to_status_id" : 179478074251935744,
  "created_at" : "2012-03-13 08:55:12 +0000",
  "in_reply_to_screen_name" : "cimota",
  "in_reply_to_user_id_str" : "14060295",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179300964367482881",
  "geo" : { },
  "id_str" : "179322395566415872",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit hipster talk?",
  "id" : 179322395566415872,
  "in_reply_to_status_id" : 179300964367482881,
  "created_at" : "2012-03-12 21:46:05 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179300681583304704",
  "geo" : { },
  "id_str" : "179301189559652353",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson Nope - but after I eat my dinner I will *munch*. Will look up your teeny bopper programme after *munching*.",
  "id" : 179301189559652353,
  "in_reply_to_status_id" : 179300681583304704,
  "created_at" : "2012-03-12 20:21:49 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179300210898509825",
  "text" : "Between making chicken & chorizo jambalaya I got a debian vm going to put all my new hackings on :) Sweet :) VPM for swm.cc is too slow.",
  "id" : 179300210898509825,
  "created_at" : "2012-03-12 20:17:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179290041976233984",
  "text" : "87.8Mb downloaded in less than 20seconds - YUM :D Bit geeky that is Virtual Box but still :D",
  "id" : 179290041976233984,
  "created_at" : "2012-03-12 19:37:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 103, 115 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179288782326071296",
  "text" : "Just home there now and shaved properly.... Do not shave without your glasses on.. Least it cheered up @niall_adams today.",
  "id" : 179288782326071296,
  "created_at" : "2012-03-12 19:32:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 16, 30 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179258753697325056",
  "text" : "30mins to go... @jenporterhall has done well... Haven't heard her once today apart from twice on the phone which couldn't be avoided.",
  "id" : 179258753697325056,
  "created_at" : "2012-03-12 17:33:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179245432118050816",
  "text" : "Whatever twat said \"Monday - so full of promise\" needs kicked in the head. Monday is full of crap. I need a holiday... FUCK FUCK FUCK :)",
  "id" : 179245432118050816,
  "created_at" : "2012-03-12 16:40:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179242560756252672",
  "geo" : { },
  "id_str" : "179244468124385280",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @jenportherall This is strike 2. You also just tweeted yourself so I dunno about the underestimation to be honest ;)",
  "id" : 179244468124385280,
  "in_reply_to_status_id" : 179242560756252672,
  "created_at" : "2012-03-12 16:36:26 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 50, 62 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 67, 83 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "heartlessbastards",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179240235094380545",
  "text" : "Right... I didn't shave properly this morning and @niall_adams and @michaelnsimpson are doing nothing but laughing at me #heartlessbastards",
  "id" : 179240235094380545,
  "created_at" : "2012-03-12 16:19:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179223588795187200",
  "geo" : { },
  "id_str" : "179223729832853504",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll Nooooo..... Don't get up....",
  "id" : 179223729832853504,
  "in_reply_to_status_id" : 179223588795187200,
  "created_at" : "2012-03-12 15:14:01 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179223646089379840",
  "text" : "At the 75% portion of the day and @jenportherall hasn't uttered a word yet.. Even with the spiked coffee I gave her earlier... Impressive.",
  "id" : 179223646089379840,
  "created_at" : "2012-03-12 15:13:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 17, 30 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179213116637319170",
  "geo" : { },
  "id_str" : "179213293762777089",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @rickyhassard cos he is a heartless bastard.. he brings in no biccies but has cake in his own house. Hmmmm... :)",
  "id" : 179213293762777089,
  "in_reply_to_status_id" : 179213116637319170,
  "created_at" : "2012-03-12 14:32:33 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179211724451364864",
  "geo" : { },
  "id_str" : "179212024256020480",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard picture or STFU :)",
  "id" : 179212024256020480,
  "in_reply_to_status_id" : 179211724451364864,
  "created_at" : "2012-03-12 14:27:30 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179210981619138561",
  "geo" : { },
  "id_str" : "179211594323079168",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard you having cake????? Right this second???",
  "id" : 179211594323079168,
  "in_reply_to_status_id" : 179210981619138561,
  "created_at" : "2012-03-12 14:25:48 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jumpingjennimexianbeanthathastostayquiet",
      "indices" : [ 94, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179211473778786306",
  "text" : "Made Jenni some coffee there - three shots of espresso and some peculated stuff to top it up. #jumpingjennimexianbeanthathastostayquiet :)",
  "id" : 179211473778786306,
  "created_at" : "2012-03-12 14:25:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179200837720096768",
  "text" : "I just unfollowed getglue.. Great service but I aint American.. So must of their updates were useless for me.",
  "id" : 179200837720096768,
  "created_at" : "2012-03-12 13:43:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179196890515120128",
  "text" : "My head is also burnt....",
  "id" : 179196890515120128,
  "created_at" : "2012-03-12 13:27:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179195945605533696",
  "geo" : { },
  "id_str" : "179196786563497985",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll The Hedgehog!!!!!!!",
  "id" : 179196786563497985,
  "in_reply_to_status_id" : 179195945605533696,
  "created_at" : "2012-03-12 13:26:57 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 14, 28 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179188138449707008",
  "text" : "Have to say - @jenporterhall is doing great at this not talking thing... Half way through the day and not one word uttered :)",
  "id" : 179188138449707008,
  "created_at" : "2012-03-12 12:52:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 78, 94 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179165625946615808",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall no communication means you cannot stick your two fingers up at @michaelnsimpson. That's 1 strike!!!",
  "id" : 179165625946615808,
  "created_at" : "2012-03-12 11:23:08 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hastings",
      "screen_name" : "AnthonyHastings",
      "indices" : [ 0, 16 ],
      "id_str" : "125947894",
      "id" : 125947894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179124604495859712",
  "geo" : { },
  "id_str" : "179155023970840576",
  "in_reply_to_user_id" : 125947894,
  "text" : "@AnthonyHastings yo ant... what's the craic?",
  "id" : 179155023970840576,
  "in_reply_to_status_id" : 179124604495859712,
  "created_at" : "2012-03-12 10:41:00 +0000",
  "in_reply_to_screen_name" : "AnthonyHastings",
  "in_reply_to_user_id_str" : "125947894",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179152790315204608",
  "geo" : { },
  "id_str" : "179154974436098048",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit pfffffft.... Leave me alone :D",
  "id" : 179154974436098048,
  "in_reply_to_status_id" : 179152790315204608,
  "created_at" : "2012-03-12 10:40:49 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179123364680572929",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR It is Monday... Not. Good. Enough. Must. Try. Harder.",
  "id" : 179123364680572929,
  "created_at" : "2012-03-12 08:35:12 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179123145557544960",
  "text" : "Cannot. Fucking. Move.",
  "id" : 179123145557544960,
  "created_at" : "2012-03-12 08:34:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178957163056742400",
  "geo" : { },
  "id_str" : "178957734136389632",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley that it does... that it really fucking does.. However 3 day weekend next week :D :D",
  "id" : 178957734136389632,
  "in_reply_to_status_id" : 178957163056742400,
  "created_at" : "2012-03-11 21:37:03 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178952519857356800",
  "geo" : { },
  "id_str" : "178954527251234816",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR consider yourself penciled. When I find my legs I'll get back to you lol. Such such pain... Am a wuss :)",
  "id" : 178954527251234816,
  "in_reply_to_status_id" : 178952519857356800,
  "created_at" : "2012-03-11 21:24:18 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mylegsaregone",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178946946621374464",
  "geo" : { },
  "id_str" : "178950380426760192",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR when i find my legs again no bother :) Might be worth us just bombing up especially for you to take pics though. #mylegsaregone",
  "id" : 178950380426760192,
  "in_reply_to_status_id" : 178946946621374464,
  "created_at" : "2012-03-11 21:07:50 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178942927060484096",
  "text" : "I don't think I have ever been this sore......",
  "id" : 178942927060484096,
  "created_at" : "2012-03-11 20:38:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 44, 58 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178928942059757568",
  "geo" : { },
  "id_str" : "178929177548963840",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson no worries. I'll play with @jenporterhall instead... Oh nooo I cannot. For she is not allowed to engage in convo with us :)",
  "id" : 178929177548963840,
  "in_reply_to_status_id" : 178928942059757568,
  "created_at" : "2012-03-11 19:43:34 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178927594710892544",
  "geo" : { },
  "id_str" : "178927960806531072",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson maybe it is at work?",
  "id" : 178927960806531072,
  "in_reply_to_status_id" : 178927594710892544,
  "created_at" : "2012-03-11 19:38:44 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178927594710892544",
  "geo" : { },
  "id_str" : "178927861405724672",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson also - you in the office this week and able to play - we need the old Mike back :)",
  "id" : 178927861405724672,
  "in_reply_to_status_id" : 178927594710892544,
  "created_at" : "2012-03-11 19:38:21 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178922718056550401",
  "geo" : { },
  "id_str" : "178925907292073984",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson ffs mike!!!",
  "id" : 178925907292073984,
  "in_reply_to_status_id" : 178922718056550401,
  "created_at" : "2012-03-11 19:30:35 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 23, 38 ],
      "id_str" : "15344533",
      "id" : 15344533
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 43, 56 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2peaks1day",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178907875605889025",
  "text" : "Back from playing with @Georgina_Milne and @stevebiscuit... If anyone sees a pair of legs up in the mournes they are mine. #2peaks1day.",
  "id" : 178907875605889025,
  "created_at" : "2012-03-11 18:18:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 25, 38 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 43, 58 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178741253465321472",
  "text" : "Up early to go play with @stevebiscuit and @Georgina_Milne...",
  "id" : 178741253465321472,
  "created_at" : "2012-03-11 07:16:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178620928857608192",
  "geo" : { },
  "id_str" : "178621400683249664",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight you take me for a mad man sir.",
  "id" : 178621400683249664,
  "in_reply_to_status_id" : 178620928857608192,
  "created_at" : "2012-03-10 23:20:35 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178616549261840384",
  "geo" : { },
  "id_str" : "178616727331024897",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight sent into her. Three lots.",
  "id" : 178616727331024897,
  "in_reply_to_status_id" : 178616549261840384,
  "created_at" : "2012-03-10 23:02:00 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178608670144339970",
  "geo" : { },
  "id_str" : "178615453420228611",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues really? I haven't watched it in ages. Should give it a go... Is Marg still in it?",
  "id" : 178615453420228611,
  "in_reply_to_status_id" : 178608670144339970,
  "created_at" : "2012-03-10 22:56:57 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Crowe",
      "screen_name" : "russellcrowe",
      "indices" : [ 1, 14 ],
      "id_str" : "133093395",
      "id" : 133093395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178604575111135233",
  "text" : "\u201C@russellcrowe: I'm going to get a massage , wish you all could feel how I'll feel in about an hour from now\u201D Guessing - still like a prick!",
  "id" : 178604575111135233,
  "created_at" : "2012-03-10 22:13:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178604311843061760",
  "text" : "So 95% of the hipsters are at SXSW... Not jealous - not jealous at all...",
  "id" : 178604311843061760,
  "created_at" : "2012-03-10 22:12:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "methinkstheladyhasntthoughtthisthrough",
      "indices" : [ 89, 128 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178599805914857474",
  "geo" : { },
  "id_str" : "178600332056723456",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall for you not to speak for a whole day and not go near your phone.... Dunno #methinkstheladyhasntthoughtthisthrough",
  "id" : 178600332056723456,
  "in_reply_to_status_id" : 178599805914857474,
  "created_at" : "2012-03-10 21:56:52 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bliss",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178471323583004673",
  "geo" : { },
  "id_str" : "178593245079674880",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall FFS, I pronounce it the correct way - its all you other tards that are wrong. Remember no talking on Monday.. #bliss",
  "id" : 178593245079674880,
  "in_reply_to_status_id" : 178471323583004673,
  "created_at" : "2012-03-10 21:28:42 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178542520022740992",
  "geo" : { },
  "id_str" : "178590018032513024",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight firing up the machine now...",
  "id" : 178590018032513024,
  "in_reply_to_status_id" : 178542520022740992,
  "created_at" : "2012-03-10 21:15:53 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/178589914802290689\/photo\/1",
      "indices" : [ 31, 50 ],
      "url" : "http:\/\/t.co\/a2CHrEG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Anp6lNCCAAEYGVF.jpg",
      "id_str" : "178589914806484993",
      "id" : 178589914806484993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Anp6lNCCAAEYGVF.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/a2CHrEG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178589914802290689",
  "text" : "Who needs friends like this... http:\/\/t.co\/a2CHrEG",
  "id" : 178589914802290689,
  "created_at" : "2012-03-10 21:15:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178567007808139264",
  "geo" : { },
  "id_str" : "178567596319326208",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley just showed my Dad that there and he said \"Hungry whore\". Says it all really... Changing ur name on the from Fat Bastard.",
  "id" : 178567596319326208,
  "in_reply_to_status_id" : 178567007808139264,
  "created_at" : "2012-03-10 19:46:47 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178452753893441537",
  "geo" : { },
  "id_str" : "178456377889521664",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson it was. Not a bad episode. :)",
  "id" : 178456377889521664,
  "in_reply_to_status_id" : 178452753893441537,
  "created_at" : "2012-03-10 12:24:50 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/178450566559711232\/photo\/1",
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/KDQYu1F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ann72EYCQAAt1Av.jpg",
      "id_str" : "178450566563905536",
      "id" : 178450566563905536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ann72EYCQAAt1Av.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/KDQYu1F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178450566559711232",
  "text" : "Red Star Wars logo... Nice touch for this episode :) http:\/\/t.co\/KDQYu1F",
  "id" : 178450566559711232,
  "created_at" : "2012-03-10 12:01:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178426613791326208",
  "geo" : { },
  "id_str" : "178446572076539905",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall where did you go - sounds that it is almost illegal to do such stuff... Mellow Birds.... Yuck",
  "id" : 178446572076539905,
  "in_reply_to_status_id" : 178426613791326208,
  "created_at" : "2012-03-10 11:45:52 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 97, 110 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178427221407580160",
  "geo" : { },
  "id_str" : "178438732863651840",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson he is a terrible actor... just terrible. Wonder if you'll like the end - me and @RickyHassard disagree on this part.",
  "id" : 178438732863651840,
  "in_reply_to_status_id" : 178427221407580160,
  "created_at" : "2012-03-10 11:14:43 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178438595420495872",
  "text" : "Ha.... Free house... Star Wars: Clone Wars and Spartacus I think....",
  "id" : 178438595420495872,
  "created_at" : "2012-03-10 11:14:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178405628178468864",
  "geo" : { },
  "id_str" : "178421660435755008",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson good good. What you think so far?",
  "id" : 178421660435755008,
  "in_reply_to_status_id" : 178405628178468864,
  "created_at" : "2012-03-10 10:06:53 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ipreferedmy20sbutyouarefurtherintoyour30sthanmesoyouwouldknowbetter",
      "indices" : [ 48, 116 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178210981502124032",
  "geo" : { },
  "id_str" : "178211426064797696",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I said \/hope\/ she is tweeting... #Ipreferedmy20sbutyouarefurtherintoyour30sthanmesoyouwouldknowbetter",
  "id" : 178211426064797696,
  "in_reply_to_status_id" : 178210981502124032,
  "created_at" : "2012-03-09 20:11:29 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "costhatshowyouroll",
      "indices" : [ 72, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178208359869202432",
  "geo" : { },
  "id_str" : "178211246431145984",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Shut it :) You'll be under a table in an hour or two anyways :) #costhatshowyouroll",
  "id" : 178211246431145984,
  "in_reply_to_status_id" : 178208359869202432,
  "created_at" : "2012-03-09 20:10:46 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178206654582624257",
  "geo" : { },
  "id_str" : "178207648435552257",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR told you to get an iPhone :) Staying out tonight so pics will be with you tomorrow at some stage. Get an iPhone :)",
  "id" : 178207648435552257,
  "in_reply_to_status_id" : 178206654582624257,
  "created_at" : "2012-03-09 19:56:28 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178203742666113024",
  "geo" : { },
  "id_str" : "178207410844991488",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore my MTA used to be qmail, then used postfix - postfix is really nice. Sounds like a shitter of a server problem though :(",
  "id" : 178207410844991488,
  "in_reply_to_status_id" : 178203742666113024,
  "created_at" : "2012-03-09 19:55:32 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "continuegentlemanday",
      "indices" : [ 118, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178180602586083329",
  "geo" : { },
  "id_str" : "178204728587599872",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I hope the eldery woman that I helped lift her shopping into her car is tweeting nice things about me. #continuegentlemanday",
  "id" : 178204728587599872,
  "in_reply_to_status_id" : 178180602586083329,
  "created_at" : "2012-03-09 19:44:52 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178164503349968898",
  "geo" : { },
  "id_str" : "178204197374803969",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne There is a happy medium :) Last time I couldn't even see the summit! :)",
  "id" : 178204197374803969,
  "in_reply_to_status_id" : 178164503349968898,
  "created_at" : "2012-03-09 19:42:46 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178194017710907392",
  "geo" : { },
  "id_str" : "178194300880961536",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll let me at them! No one fucks with the baking goddess!!",
  "id" : 178194300880961536,
  "in_reply_to_status_id" : 178194017710907392,
  "created_at" : "2012-03-09 19:03:26 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178193129411842049",
  "geo" : { },
  "id_str" : "178194037218619392",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore anything I can do to help just shout.",
  "id" : 178194037218619392,
  "in_reply_to_status_id" : 178193129411842049,
  "created_at" : "2012-03-09 19:02:23 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178192904513273857",
  "geo" : { },
  "id_str" : "178193875620474881",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll oh and they haven't given it to you? Bastards.",
  "id" : 178193875620474881,
  "in_reply_to_status_id" : 178192904513273857,
  "created_at" : "2012-03-09 19:01:45 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178177744163700736",
  "geo" : { },
  "id_str" : "178192762418626562",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll you sure it's the neighbours?",
  "id" : 178192762418626562,
  "in_reply_to_status_id" : 178177744163700736,
  "created_at" : "2012-03-09 18:57:19 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 10, 17 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178155320403701760",
  "text" : "Excuse me @BekaBR but it is raining outside.. Was nice this morning but now it rains when the weekend starts... FS lady... Sort it now pls!",
  "id" : 178155320403701760,
  "created_at" : "2012-03-09 16:28:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178154475427610624",
  "geo" : { },
  "id_str" : "178154888038064130",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight I'm working.... \tWill be home at around eight...ish...",
  "id" : 178154888038064130,
  "in_reply_to_status_id" : 178154475427610624,
  "created_at" : "2012-03-09 16:26:49 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178126858884366337",
  "geo" : { },
  "id_str" : "178127037100335104",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe stupid fucking autocorrect.....",
  "id" : 178127037100335104,
  "in_reply_to_status_id" : 178126858884366337,
  "created_at" : "2012-03-09 14:36:09 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178126403299065856",
  "text" : "I haven't a fucking clue why i am following Keith Chegwin... But I just remedied the situation.. WTF...",
  "id" : 178126403299065856,
  "created_at" : "2012-03-09 14:33:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "upstarisintascomimuchbetterthanstinkydownstairsppl",
      "indices" : [ 83, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178126144481140736",
  "text" : "New guy in office likes proper coffee.... The gourmet shit as well.... Tis nice... #upstarisintascomimuchbetterthanstinkydownstairsppl",
  "id" : 178126144481140736,
  "created_at" : "2012-03-09 14:32:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The ginja ninja",
      "screen_name" : "andycochrane",
      "indices" : [ 0, 13 ],
      "id_str" : "59068510",
      "id" : 59068510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178112003624280065",
  "geo" : { },
  "id_str" : "178112485172318208",
  "in_reply_to_user_id" : 59068510,
  "text" : "@andycochrane shit one :(",
  "id" : 178112485172318208,
  "in_reply_to_status_id" : 178112003624280065,
  "created_at" : "2012-03-09 13:38:20 +0000",
  "in_reply_to_screen_name" : "andycochrane",
  "in_reply_to_user_id_str" : "59068510",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178075680792260608",
  "geo" : { },
  "id_str" : "178099174036881408",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne depends on the level they go in at. I dealt with them a few jobs back. Partners = \u00A3\u00A3\u00A3. I'd say a bit like Deloitte (sp).",
  "id" : 178099174036881408,
  "in_reply_to_status_id" : 178075680792260608,
  "created_at" : "2012-03-09 12:45:26 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 7, 23 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 26, 40 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "upstairspeepsthatarenthereonafriday",
      "indices" : [ 42, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178058957955411968",
  "text" : "I miss @michaelnsimpson & @jenporterhall. #upstairspeepsthatarenthereonafriday",
  "id" : 178058957955411968,
  "created_at" : "2012-03-09 10:05:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 26, 39 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178041978129367040",
  "text" : "It is Friday... Lets hope @RickyHassard gets tripped up by a wall again. Best. Friday. Ever.",
  "id" : 178041978129367040,
  "created_at" : "2012-03-09 08:58:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177897722186178560",
  "geo" : { },
  "id_str" : "177898095932219392",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I never really got into it. Tried it in rehab to manage co-location teams - just never really took me.",
  "id" : 177898095932219392,
  "in_reply_to_status_id" : 177897722186178560,
  "created_at" : "2012-03-08 23:26:25 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shewontseethisandifshedoesyoulivewithhersoshewillkillyoufirst",
      "indices" : [ 28, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177894496544112641",
  "geo" : { },
  "id_str" : "177895409870569474",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight will do :D #shewontseethisandifshedoesyoulivewithhersoshewillkillyoufirst :)",
  "id" : 177895409870569474,
  "in_reply_to_status_id" : 177894496544112641,
  "created_at" : "2012-03-08 23:15:45 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177867317936521217",
  "geo" : { },
  "id_str" : "177884947137302528",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR sorry was out there. Youll get them tomorrow :)",
  "id" : 177884947137302528,
  "in_reply_to_status_id" : 177867317936521217,
  "created_at" : "2012-03-08 22:34:10 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177841311569813504",
  "text" : "Deployed my first heroku app there... Getting there with all this new fangled hipster stuff....",
  "id" : 177841311569813504,
  "created_at" : "2012-03-08 19:40:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177786312147992576",
  "geo" : { },
  "id_str" : "177787518572429313",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore what do you use? I tried BC a while back - never really got it..",
  "id" : 177787518572429313,
  "in_reply_to_status_id" : 177786312147992576,
  "created_at" : "2012-03-08 16:07:02 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 32, 48 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177785854935310336",
  "text" : "Got completely bitch slapped by @michaelnsimpson there... Awesome bitch slap...",
  "id" : 177785854935310336,
  "created_at" : "2012-03-08 16:00:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177767682484088835",
  "text" : ".....FUCKING DONE.....",
  "id" : 177767682484088835,
  "created_at" : "2012-03-08 14:48:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177764218370658304",
  "text" : "He's too busy typing to pay attention to these tweets - even thogh this is up on a big screen... YOU ARE A WANKER MIKE",
  "id" : 177764218370658304,
  "created_at" : "2012-03-08 14:34:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177763466210312193",
  "text" : "Got the wrong Mike.... Ahh well :D",
  "id" : 177763466210312193,
  "created_at" : "2012-03-08 14:31:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Simpson",
      "screen_name" : "michaelsimpson",
      "indices" : [ 18, 33 ],
      "id_str" : "18265908",
      "id" : 18265908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177763398862389248",
  "text" : "In a meeting with @michaelsimpson - am so bored its unreal :)",
  "id" : 177763398862389248,
  "created_at" : "2012-03-08 14:31:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177723070981734400",
  "text" : "I am the worst programmer alive. Fact. Wondering why something wasn't returning what I wanted.. Cos I didn't actually return it :(",
  "id" : 177723070981734400,
  "created_at" : "2012-03-08 11:50:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 1, 15 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theymattertoo",
      "indices" : [ 50, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177695933897773056",
  "text" : "\u201C@jenporterhall: When is International Men's Day? #theymattertoo\u201D",
  "id" : 177695933897773056,
  "created_at" : "2012-03-08 10:03:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 12, 21 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177692635413229568",
  "geo" : { },
  "id_str" : "177692838602092544",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin @hamstarr Hope it all works out alright...",
  "id" : 177692838602092544,
  "in_reply_to_status_id" : 177692635413229568,
  "created_at" : "2012-03-08 09:50:48 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/mnvum4X",
      "expanded_url" : "http:\/\/alturl.com\/4d2qe",
      "display_url" : "alturl.com\/4d2qe"
    } ]
  },
  "geo" : { },
  "id_str" : "177685844184928256",
  "text" : "New Blog Post - http:\/\/t.co\/mnvum4X",
  "id" : 177685844184928256,
  "created_at" : "2012-03-08 09:23:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 17, 31 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177685784076369920",
  "text" : "Still no sign of @jenporterhall guess I will have to make this tea myself :(",
  "id" : 177685784076369920,
  "created_at" : "2012-03-08 09:22:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "asalways",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "sadfanboytweet",
      "indices" : [ 72, 87 ]
    }, {
      "text" : "regainedsomedignityback",
      "indices" : [ 98, 122 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177682601815973888",
  "geo" : { },
  "id_str" : "177684888043012096",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Nah you look great. #asalways Will email them when I gets home. #sadfanboytweet You smell #regainedsomedignityback",
  "id" : 177684888043012096,
  "in_reply_to_status_id" : 177682601815973888,
  "created_at" : "2012-03-08 09:19:13 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177675844070809600",
  "text" : "8150 images got so far... Only another 72000 to go! Sneaky scripts are good. Sleeing 2 seconds in between gets :)",
  "id" : 177675844070809600,
  "created_at" : "2012-03-08 08:43:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177671949202362368",
  "geo" : { },
  "id_str" : "177672320062730241",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Seems I have old work type pictures :D Even the odd one me having hair!!! :)",
  "id" : 177672320062730241,
  "in_reply_to_status_id" : 177671949202362368,
  "created_at" : "2012-03-08 08:29:16 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keepsdigging",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177671216419708928",
  "text" : "And not infer that all hoes aren't lovely as well.. In fact some of my favourite women are hoes :) #keepsdigging I just want a cup of tea!",
  "id" : 177671216419708928,
  "created_at" : "2012-03-08 08:24:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 52, 66 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177670924420657153",
  "text" : "Re-read my last tweet. I did not mean to infer that @jenporterhall is a hoe. She is lovely. I shouldn't take the piss this early in the am:(",
  "id" : 177670924420657153,
  "created_at" : "2012-03-08 08:23:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 100, 114 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177669066474004480",
  "text" : "Its International Womens Day - so does that mean that every hoe has to make me a cup of tea???? \/cc @jenporterhall",
  "id" : 177669066474004480,
  "created_at" : "2012-03-08 08:16:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177667691086229504",
  "geo" : { },
  "id_str" : "177668722952118272",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne shinny pearly whites?",
  "id" : 177668722952118272,
  "in_reply_to_status_id" : 177667691086229504,
  "created_at" : "2012-03-08 08:14:59 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Archibald",
      "screen_name" : "BerryBlonde84",
      "indices" : [ 0, 14 ],
      "id_str" : "77241609",
      "id" : 77241609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontpanic",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177657505042800640",
  "geo" : { },
  "id_str" : "177668609026424832",
  "in_reply_to_user_id" : 77241609,
  "text" : "@BerryBlonde84 you try a hard reboot of it. Happened me once - just needed a kick. #dontpanic",
  "id" : 177668609026424832,
  "in_reply_to_status_id" : 177657505042800640,
  "created_at" : "2012-03-08 08:14:31 +0000",
  "in_reply_to_screen_name" : "BerryBlonde84",
  "in_reply_to_user_id_str" : "77241609",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayB",
      "screen_name" : "eight_one_eight",
      "indices" : [ 0, 16 ],
      "id_str" : "302776981",
      "id" : 302776981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iaintthatstupid",
      "indices" : [ 51, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177532765904961536",
  "geo" : { },
  "id_str" : "177656820544978944",
  "in_reply_to_user_id" : 302776981,
  "text" : "@eight_one_eight only if given permission it is :) #iaintthatstupid",
  "id" : 177656820544978944,
  "in_reply_to_status_id" : 177532765904961536,
  "created_at" : "2012-03-08 07:27:41 +0000",
  "in_reply_to_screen_name" : "eight_one_eight",
  "in_reply_to_user_id_str" : "302776981",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 50, 59 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amtemptedbutwillrefrain",
      "indices" : [ 110, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177512255573856256",
  "text" : "Opening up this server... Got some really cool of @kirkcoyb  circa 2003... Ohhh just a *click* of a button :) #amtemptedbutwillrefrain",
  "id" : 177512255573856256,
  "created_at" : "2012-03-07 21:53:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 55, 62 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amtemptedbutwillrefrain",
      "indices" : [ 112, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177512203237326848",
  "text" : "Opening up this server... Got some really cool pics of @BekaBR circa 2003... Ohhh just a *click* of a button :) #amtemptedbutwillrefrain",
  "id" : 177512203237326848,
  "created_at" : "2012-03-07 21:53:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 50, 57 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amtemptedbutwillrefrain",
      "indices" : [ 107, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177512101793906689",
  "text" : "Opening up this server... Got some really cool of @BekaBR circa 2003... Ohhh just a *click* of a button :) #amtemptedbutwillrefrain",
  "id" : 177512101793906689,
  "created_at" : "2012-03-07 21:52:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177504181261836289",
  "geo" : { },
  "id_str" : "177504288728285184",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams awesome.... Much to discuss tomorrow then :D",
  "id" : 177504288728285184,
  "in_reply_to_status_id" : 177504181261836289,
  "created_at" : "2012-03-07 21:21:34 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 15, 29 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177499902308397056",
  "geo" : { },
  "id_str" : "177503924465577985",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall @peter_omalley you saying its not a happy haven usually?? Just cos of me... Huh? You can't be.. can you?",
  "id" : 177503924465577985,
  "in_reply_to_status_id" : 177499902308397056,
  "created_at" : "2012-03-07 21:20:08 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177500775113687040",
  "geo" : { },
  "id_str" : "177503804990824450",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams where are you... where are you?",
  "id" : 177503804990824450,
  "in_reply_to_status_id" : 177500775113687040,
  "created_at" : "2012-03-07 21:19:39 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/Im076xk",
      "expanded_url" : "http:\/\/pastie.org\/3543871",
      "display_url" : "pastie.org\/3543871"
    } ]
  },
  "geo" : { },
  "id_str" : "177497428386250752",
  "text" : "Booted up my old linux server... And got this - http:\/\/t.co\/Im076xk OLD OLD OLD",
  "id" : 177497428386250752,
  "created_at" : "2012-03-07 20:54:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177494421342928896",
  "geo" : { },
  "id_str" : "177497394714394624",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 that's about the same as three taxi trips from hillsborough to the airport funnily enough ;)",
  "id" : 177497394714394624,
  "in_reply_to_status_id" : 177494421342928896,
  "created_at" : "2012-03-07 20:54:11 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177481837285867520",
  "geo" : { },
  "id_str" : "177492075808423936",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp how very dare you :)",
  "id" : 177492075808423936,
  "in_reply_to_status_id" : 177481837285867520,
  "created_at" : "2012-03-07 20:33:03 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 33, 46 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177491988835352576",
  "text" : "Am hoping that the sky+ box that @marcus_r1975 is bombing my way will stop me having to give sky 65quid... Lets hope :)",
  "id" : 177491988835352576,
  "created_at" : "2012-03-07 20:32:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177483727843237888",
  "geo" : { },
  "id_str" : "177488873369243649",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR I think it is on channel 4 on Fridays - but I just get it the naughty way. Its a good show :)",
  "id" : 177488873369243649,
  "in_reply_to_status_id" : 177483727843237888,
  "created_at" : "2012-03-07 20:20:19 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177469208928600064",
  "text" : "Making spag bolg with korn and downloading latest ep of New Girl. Am sure I didn't have a vagina this mornin, starting to have doubts though",
  "id" : 177469208928600064,
  "created_at" : "2012-03-07 19:02:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177395524306079746",
  "text" : "I really love sublime",
  "id" : 177395524306079746,
  "created_at" : "2012-03-07 14:09:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177391019971715072",
  "geo" : { },
  "id_str" : "177391290466566144",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR yes - that's why I like it. i never use them :)",
  "id" : 177391290466566144,
  "in_reply_to_status_id" : 177391019971715072,
  "created_at" : "2012-03-07 13:52:34 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177390766602199040",
  "geo" : { },
  "id_str" : "177390842963693568",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR love your hash tags :)",
  "id" : 177390842963693568,
  "in_reply_to_status_id" : 177390766602199040,
  "created_at" : "2012-03-07 13:50:47 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177390033723076608",
  "geo" : { },
  "id_str" : "177390439668789248",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR well don't be doing it again... Way too cold for that sort of business... Has to be a nice Spring and you promised.",
  "id" : 177390439668789248,
  "in_reply_to_status_id" : 177390033723076608,
  "created_at" : "2012-03-07 13:49:11 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 52, 59 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177372154256556032",
  "text" : "Hailstones in March. Not Cool!!! Sort it out Bex... @BekaBR",
  "id" : 177372154256556032,
  "created_at" : "2012-03-07 12:36:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177366869903278081",
  "geo" : { },
  "id_str" : "177372019317424132",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe nicely added benefit is all :)",
  "id" : 177372019317424132,
  "in_reply_to_status_id" : 177366869903278081,
  "created_at" : "2012-03-07 12:35:59 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177347885816496129",
  "text" : "A fly flew into my tea this morning... I did not curse... Gentleman day is going well so far :D",
  "id" : 177347885816496129,
  "created_at" : "2012-03-07 11:00:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "c4em",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/JMHNmkZ",
      "expanded_url" : "http:\/\/www.c4em.org.uk\/",
      "display_url" : "c4em.org.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "177338819669016576",
  "text" : "I support the right of two people in love to get married, regardless of gender. It's only fair. #c4em http:\/\/t.co\/JMHNmkZ",
  "id" : 177338819669016576,
  "created_at" : "2012-03-07 10:24:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177338000609525762",
  "geo" : { },
  "id_str" : "177338440797528064",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues isn't it ridiculous that we actually have to sign this though? I dunno.. Love is love IMVHO. Grrrr @ stupid ppl!! Signed it btw",
  "id" : 177338440797528064,
  "in_reply_to_status_id" : 177338000609525762,
  "created_at" : "2012-03-07 10:22:33 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177337105712820224",
  "text" : "Today is a headphone day - lots to get done :D",
  "id" : 177337105712820224,
  "created_at" : "2012-03-07 10:17:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177160258194640898",
  "text" : "Very rare that a tv show has any more than 2\/3 good seasons in them. Damages S4 is pretty crap so far. Only 3 episodes in though 2b fair.",
  "id" : 177160258194640898,
  "created_at" : "2012-03-06 22:34:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177144233436782592",
  "geo" : { },
  "id_str" : "177144419340922880",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus do you remember me with hair???? Do ya... Do ya???",
  "id" : 177144419340922880,
  "in_reply_to_status_id" : 177144233436782592,
  "created_at" : "2012-03-06 21:31:35 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177142825245351936",
  "geo" : { },
  "id_str" : "177143895287795713",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson Will give them another go in a sec..... Am dead on for a lift. Car is fine - I was just being pa. pa. pa. paranoid!",
  "id" : 177143895287795713,
  "in_reply_to_status_id" : 177142825245351936,
  "created_at" : "2012-03-06 21:29:30 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177143340804997122",
  "geo" : { },
  "id_str" : "177143754694729728",
  "in_reply_to_user_id" : 95932190,
  "text" : "@bkgStatus that is awesome! :D Oh and before I forget... Fuck you!",
  "id" : 177143754694729728,
  "in_reply_to_status_id" : 177143340804997122,
  "created_at" : "2012-03-06 21:28:56 +0000",
  "in_reply_to_screen_name" : "brrygrdn",
  "in_reply_to_user_id_str" : "95932190",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "indices" : [ 3, 13 ],
      "id_str" : "7311162",
      "id" : 7311162
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 15, 21 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177142713295183872",
  "text" : "RT @mharrigan: @swmcc God damn fad boy hipster coder. I bet Rails is so last year and Scala is the shit, all piped into MongoDB. You sic ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "177140986366009344",
    "geo" : { },
    "id_str" : "177142024108118016",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc God damn fad boy hipster coder. I bet Rails is so last year and Scala is the shit, all piped into MongoDB. You sicken me.",
    "id" : 177142024108118016,
    "in_reply_to_status_id" : 177140986366009344,
    "created_at" : "2012-03-06 21:22:04 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "Mark Harrigan",
      "screen_name" : "mharrigan",
      "protected" : false,
      "id_str" : "7311162",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1244027252\/49305_703667370_6415415_q_normal.jpg",
      "id" : 7311162,
      "verified" : false
    }
  },
  "id" : 177142713295183872,
  "created_at" : "2012-03-06 21:24:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177142537541259265",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson or maybe not. Lots of them are at \"waiting\".......",
  "id" : 177142537541259265,
  "created_at" : "2012-03-06 21:24:06 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177142470554034176",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson guess what I have for you tomorrow :D 'Retried' them all and *BAM* :D",
  "id" : 177142470554034176,
  "created_at" : "2012-03-06 21:23:50 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177140986366009344",
  "text" : "Just minded that instead of sitting here playing with node.js (fuck up - I aint a hipster) I could be watching the new ep of The Living Dead",
  "id" : 177140986366009344,
  "created_at" : "2012-03-06 21:17:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177129586377756672",
  "geo" : { },
  "id_str" : "177135447313620992",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Sssssssh... She will hear you!!!! :D Car is grand apparently :)",
  "id" : 177135447313620992,
  "in_reply_to_status_id" : 177129586377756672,
  "created_at" : "2012-03-06 20:55:56 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177135282167099394",
  "text" : "Car is grand apparently. I am just being a \"Wee Pussy Bitch\" which I think means that my Dad at 64 thinks he can take me in a fight! :)",
  "id" : 177135282167099394,
  "created_at" : "2012-03-06 20:55:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177123550895935488",
  "geo" : { },
  "id_str" : "177125882278846465",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley no not yet - just a feeling I get.... Don't like it much to be honest.",
  "id" : 177125882278846465,
  "in_reply_to_status_id" : 177123550895935488,
  "created_at" : "2012-03-06 20:17:55 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177113907905826816",
  "text" : "I have a horrible feeling my clutch is on the way out :(",
  "id" : 177113907905826816,
  "created_at" : "2012-03-06 19:30:20 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177099712246185984",
  "text" : "Phew..... Like what the fuck would I say if I couldn't curse??",
  "id" : 177099712246185984,
  "created_at" : "2012-03-06 18:33:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177099599155175424",
  "text" : "Fucking... I got an error when putting that in my previous tweet. I can curse here right - I must be able to!",
  "id" : 177099599155175424,
  "created_at" : "2012-03-06 18:33:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/pLlLivy",
      "expanded_url" : "http:\/\/wordress.com",
      "display_url" : "wordress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "177099485497917440",
  "text" : "Seems the mod_rewrite rule I put in on Friday was fine. I just couldn't spell wordpress right (http:\/\/t.co\/pLlLivy)... Idiot that I am!",
  "id" : 177099485497917440,
  "created_at" : "2012-03-06 18:33:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177096786081611776",
  "geo" : { },
  "id_str" : "177096990734286849",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson bullwank... Thought I got away with it :)",
  "id" : 177096990734286849,
  "in_reply_to_status_id" : 177096786081611776,
  "created_at" : "2012-03-06 18:23:07 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177047104265523200",
  "geo" : { },
  "id_str" : "177054145914748928",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb am up for that :D",
  "id" : 177054145914748928,
  "in_reply_to_status_id" : 177047104265523200,
  "created_at" : "2012-03-06 15:32:52 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177046236799578112",
  "geo" : { },
  "id_str" : "177046420686241792",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb Oh just for a nosey - see how Poppy is getting on - stalk a few other peeps ;) If you deactivate it it still saves photos :D",
  "id" : 177046420686241792,
  "in_reply_to_status_id" : 177046236799578112,
  "created_at" : "2012-03-06 15:02:10 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 91, 105 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 62 ],
      "url" : "http:\/\/t.co\/mXFVmcq",
      "expanded_url" : "http:\/\/www.howtoguides365.com\/how-to\/be-gentleman\/",
      "display_url" : "howtoguides365.com\/how-to\/be-gent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177045786436182016",
  "text" : "This is what I have to be tomorrow in work http:\/\/t.co\/mXFVmcq for 24 hours.. If i do this @jenporterhall has to shut up all of Monday :)",
  "id" : 177045786436182016,
  "created_at" : "2012-03-06 14:59:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177045131973758977",
  "geo" : { },
  "id_str" : "177045444394893313",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb nope deleted it too. I might bomb back on it again at a later stage.",
  "id" : 177045444394893313,
  "in_reply_to_status_id" : 177045131973758977,
  "created_at" : "2012-03-06 14:58:17 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177043242087493632",
  "geo" : { },
  "id_str" : "177043641490087936",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb You still got your bebo? Coming up on 4 weeks.... Eugggghh.... Feels like yesterday I was taking the piss out of u & your 30th.",
  "id" : 177043641490087936,
  "in_reply_to_status_id" : 177043242087493632,
  "created_at" : "2012-03-06 14:51:08 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177042210733297665",
  "geo" : { },
  "id_str" : "177042415868329984",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb you pure bred wanker you :D Well played asslick :) I just don't honestly use it anymore. Not really.",
  "id" : 177042415868329984,
  "in_reply_to_status_id" : 177042210733297665,
  "created_at" : "2012-03-06 14:46:15 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177040042248777728",
  "geo" : { },
  "id_str" : "177041852216774657",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 I like twitter and use it. FB I never used. Not really.",
  "id" : 177041852216774657,
  "in_reply_to_status_id" : 177040042248777728,
  "created_at" : "2012-03-06 14:44:01 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ahhthememories",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177041094410899456",
  "geo" : { },
  "id_str" : "177041780439658497",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR I remember that this is what happened bebo too... Guess I'll just have to stalk u the old fashioned way. #ahhthememories",
  "id" : 177041780439658497,
  "in_reply_to_status_id" : 177041094410899456,
  "created_at" : "2012-03-06 14:43:44 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177039125650739200",
  "text" : "I got rid of my facebook and google+ accounts - feel much better for it :)",
  "id" : 177039125650739200,
  "created_at" : "2012-03-06 14:33:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177004502833041408",
  "text" : "OH: \"You gave up and you just went for a 'next', 'next', 'next' installer.. Admit it\" - I fail :) - but funny quote..",
  "id" : 177004502833041408,
  "created_at" : "2012-03-06 12:15:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176769232233705473",
  "geo" : { },
  "id_str" : "176778163735633921",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 The fact that the ad had them dancing with them for longer than the two previous clips bombined says it all :(",
  "id" : 176778163735633921,
  "in_reply_to_status_id" : 176769232233705473,
  "created_at" : "2012-03-05 21:16:13 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/m43jibi",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1gldall2838",
      "display_url" : "youtube.com\/watch?v=1gldal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "176703466167730176",
  "text" : "Star Wars has just died for me.. First two segments are good enough - the third... Will - just look - http:\/\/t.co\/m43jibi",
  "id" : 176703466167730176,
  "created_at" : "2012-03-05 16:19:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176680246387556352",
  "text" : "adduser or useradd.... 50\/50 chance of getting this right...",
  "id" : 176680246387556352,
  "created_at" : "2012-03-05 14:47:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176592898245136384",
  "geo" : { },
  "id_str" : "176626477981368322",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley bastard.... We had a tossing competition this morning - and not the good kind... I lost :(",
  "id" : 176626477981368322,
  "in_reply_to_status_id" : 176592898245136384,
  "created_at" : "2012-03-05 11:13:28 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 23, 30 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176570518596620289",
  "text" : "So... Monday again.... @BekaBR What is happening on this four day weekend plan? Any progress - get a move on son! :)",
  "id" : 176570518596620289,
  "created_at" : "2012-03-05 07:31:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176432974093496320",
  "geo" : { },
  "id_str" : "176433229568552960",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall pffffffft.",
  "id" : 176433229568552960,
  "in_reply_to_status_id" : 176432974093496320,
  "created_at" : "2012-03-04 22:25:34 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 0, 14 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176430572971888640",
  "geo" : { },
  "id_str" : "176432683709243392",
  "in_reply_to_user_id" : 227493010,
  "text" : "@jenporterhall I'll whack you round the gob with it!",
  "id" : 176432683709243392,
  "in_reply_to_status_id" : 176430572971888640,
  "created_at" : "2012-03-04 22:23:24 +0000",
  "in_reply_to_screen_name" : "jenporterhall",
  "in_reply_to_user_id_str" : "227493010",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/ILjfNiC",
      "expanded_url" : "http:\/\/wordpress.com",
      "display_url" : "wordpress.com"
    }, {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/7LC7gsO",
      "expanded_url" : "http:\/\/swmcc.wordpress.com",
      "display_url" : "swmcc.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "176381467012767745",
  "text" : "... URL. Seems I got the rewrite rule wrong.. So now it points to http:\/\/t.co\/ILjfNiC and not http:\/\/t.co\/7LC7gsO :) Ha. Will fix later.",
  "id" : 176381467012767745,
  "created_at" : "2012-03-04 18:59:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176381282207543296",
  "text" : "Eugggh - I moved ma blog on Friday evening (sick of having to upgrade all the time) - so shoved in a mod_rewrite rule to point to the new..",
  "id" : 176381282207543296,
  "created_at" : "2012-03-04 18:59:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 8, 22 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176310818571423746",
  "geo" : { },
  "id_str" : "176370979059142659",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR @No_Underscore Never hold back Bex.. Never :D",
  "id" : 176370979059142659,
  "in_reply_to_status_id" : 176310818571423746,
  "created_at" : "2012-03-04 18:18:12 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 12, 26 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176303094739632128",
  "text" : "Also me and @No_Underscore put the world to rights about assholes that wank each other off on twitter re: their jobs.. You know who you are.",
  "id" : 176303094739632128,
  "created_at" : "2012-03-04 13:48:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 104, 117 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176302591297327105",
  "text" : "Apart from the new person that came up to me and rubbed my belly - she was annoying.. Even more so than @RickyHassard rubbing my head...",
  "id" : 176302591297327105,
  "created_at" : "2012-03-04 13:46:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 54, 66 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 81, 95 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176301750674923522",
  "text" : "Meeting new people wasn't bad at all... Plus the sexy @willemkokke was there and @No_Underscore popped in.. Good to see them :)",
  "id" : 176301750674923522,
  "created_at" : "2012-03-04 13:43:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 15, 27 ],
      "id_str" : "453312717",
      "id" : 453312717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175913446217498624",
  "geo" : { },
  "id_str" : "175955856314216452",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @kirstylvssp that is pure awesome.",
  "id" : 175955856314216452,
  "in_reply_to_status_id" : 175913446217498624,
  "created_at" : "2012-03-03 14:48:39 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175940112109146112",
  "text" : "I am meeting new people tonight. I hate meeting new people..",
  "id" : 175940112109146112,
  "created_at" : "2012-03-03 13:46:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175709331411566592",
  "geo" : { },
  "id_str" : "175709482314240000",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Why do you hate her so much? :)",
  "id" : 175709482314240000,
  "in_reply_to_status_id" : 175709331411566592,
  "created_at" : "2012-03-02 22:29:39 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175708038672547841",
  "geo" : { },
  "id_str" : "175708312644493312",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Hmmmmmm... Depends - how sadistic are you prepared to go?",
  "id" : 175708312644493312,
  "in_reply_to_status_id" : 175708038672547841,
  "created_at" : "2012-03-02 22:25:00 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175707110745718784",
  "geo" : { },
  "id_str" : "175707685637988352",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Go on do it.... :)",
  "id" : 175707685637988352,
  "in_reply_to_status_id" : 175707110745718784,
  "created_at" : "2012-03-02 22:22:31 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175703292633030657",
  "geo" : { },
  "id_str" : "175703737405423616",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore and it has Poriort has  the bad guy.",
  "id" : 175703737405423616,
  "in_reply_to_status_id" : 175703292633030657,
  "created_at" : "2012-03-02 22:06:50 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175700543518412801",
  "geo" : { },
  "id_str" : "175703403236827136",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore executive decision?",
  "id" : 175703403236827136,
  "in_reply_to_status_id" : 175700543518412801,
  "created_at" : "2012-03-02 22:05:30 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175680487354933248",
  "geo" : { },
  "id_str" : "175682716015144960",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop Giving it one last go on the mac though.. If that doesn't work I am calling it a night. Thanks :)",
  "id" : 175682716015144960,
  "in_reply_to_status_id" : 175680487354933248,
  "created_at" : "2012-03-02 20:43:18 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175680487354933248",
  "geo" : { },
  "id_str" : "175682614223585281",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop I tried that - but brew yaps about xcode. Weird thing is - got it all running in Ubuntu in 10mins :)",
  "id" : 175682614223585281,
  "in_reply_to_status_id" : 175680487354933248,
  "created_at" : "2012-03-02 20:42:53 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175674394557956096",
  "geo" : { },
  "id_str" : "175675531218526208",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I really do. I am going home now to have a wank.... Will be thinking about your mother :)",
  "id" : 175675531218526208,
  "in_reply_to_status_id" : 175674394557956096,
  "created_at" : "2012-03-02 20:14:45 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175673091484172288",
  "geo" : { },
  "id_str" : "175674341604851712",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist will end up getting the source and doing it properly. But for my own notes I wanna know how fast it will take on Ubuntu",
  "id" : 175674341604851712,
  "in_reply_to_status_id" : 175673091484172288,
  "created_at" : "2012-03-02 20:10:01 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175672970642075650",
  "geo" : { },
  "id_str" : "175674169734856704",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist just postgres. That's all I need :)",
  "id" : 175674169734856704,
  "in_reply_to_status_id" : 175672970642075650,
  "created_at" : "2012-03-02 20:09:20 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uracunt",
      "indices" : [ 134, 142 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175673091484172288",
  "geo" : { },
  "id_str" : "175674074461249536",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist true - this is very hipster of us thinking about it. Conversing in &lt; 140 characters.. Only need Sseven is all I need. #uracunt",
  "id" : 175674074461249536,
  "in_reply_to_status_id" : 175673091484172288,
  "created_at" : "2012-03-02 20:08:57 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175672568571891712",
  "geo" : { },
  "id_str" : "175672764932440064",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist never tried it. Am in full huff mode. I want to develop - not spend an evening wanking about with inferior tools. Grrrr :D",
  "id" : 175672764932440064,
  "in_reply_to_status_id" : 175672568571891712,
  "created_at" : "2012-03-02 20:03:45 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175672164878520321",
  "geo" : { },
  "id_str" : "175672455694782464",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist Does my nut in.. The only thing missing from the mac is a \/good\/ package manager for this dev type stuffs.",
  "id" : 175672455694782464,
  "in_reply_to_status_id" : 175672164878520321,
  "created_at" : "2012-03-02 20:02:31 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175671696559316993",
  "geo" : { },
  "id_str" : "175671960615927808",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I know that I'll be able to get set up in about 10mins with Ubuntu\/Debian though.. Why do they make it so hard?",
  "id" : 175671960615927808,
  "in_reply_to_status_id" : 175671696559316993,
  "created_at" : "2012-03-02 20:00:33 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175664494503137280",
  "geo" : { },
  "id_str" : "175671580561637376",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist tried that - brew wont install.. I've given up.",
  "id" : 175671580561637376,
  "in_reply_to_status_id" : 175664494503137280,
  "created_at" : "2012-03-02 19:59:03 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175663935058477056",
  "geo" : { },
  "id_str" : "175671325619269632",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I can't stand this though. Development on a mac shouldn't be this hard.It just isn't on. Installing Ubuntu on vmware.",
  "id" : 175671325619269632,
  "in_reply_to_status_id" : 175663935058477056,
  "created_at" : "2012-03-02 19:58:02 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175664610794422273",
  "geo" : { },
  "id_str" : "175669582915309568",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR awesome :)",
  "id" : 175669582915309568,
  "in_reply_to_status_id" : 175664610794422273,
  "created_at" : "2012-03-02 19:51:07 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175660938924527618",
  "text" : "Maybe there is a nicer way to install GCC on my mac... This is fucking ridiculous.",
  "id" : 175660938924527618,
  "created_at" : "2012-03-02 19:16:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175660704500686848",
  "text" : "Maybe its because I spent so long out of hipsterville - but see these new ways of doing things - they really aren't faster.",
  "id" : 175660704500686848,
  "created_at" : "2012-03-02 19:15:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175660577446838272",
  "text" : "Why developing on a debian machine is always the handiest option - \"Warning: Xcode is not installed!\" - am on SL - and I aint paying.",
  "id" : 175660577446838272,
  "created_at" : "2012-03-02 19:15:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175650238806241280",
  "geo" : { },
  "id_str" : "175660479056850947",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf ha ha ha ha :)",
  "id" : 175660479056850947,
  "in_reply_to_status_id" : 175650238806241280,
  "created_at" : "2012-03-02 19:14:56 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175638288433020928",
  "text" : "You cannot update because WordPress 3.3.1 requires PHP version 5.2.4 or higher. You are running version 5.1.6. - I HATE CENTOS",
  "id" : 175638288433020928,
  "created_at" : "2012-03-02 17:46:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175621746488119297",
  "geo" : { },
  "id_str" : "175621960141766656",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Ohhh forgot you were into that :D Ha ha ha...",
  "id" : 175621960141766656,
  "in_reply_to_status_id" : 175621746488119297,
  "created_at" : "2012-03-02 16:41:52 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175613192544862209",
  "geo" : { },
  "id_str" : "175620035916738560",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR ok.. See you there about 2076 :D",
  "id" : 175620035916738560,
  "in_reply_to_status_id" : 175613192544862209,
  "created_at" : "2012-03-02 16:34:14 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beka B",
      "screen_name" : "BekaBR",
      "indices" : [ 0, 7 ],
      "id_str" : "506126514",
      "id" : 506126514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175605380200665088",
  "geo" : { },
  "id_str" : "175612057968836608",
  "in_reply_to_user_id" : 506126514,
  "text" : "@BekaBR Nah - you'll just wreck the place.. \"No Beka's allowed\" - you gotta find somewhere just as bad to spend enternity - Larne or Lurgan.",
  "id" : 175612057968836608,
  "in_reply_to_status_id" : 175605380200665088,
  "created_at" : "2012-03-02 16:02:31 +0000",
  "in_reply_to_screen_name" : "BekaBR",
  "in_reply_to_user_id_str" : "506126514",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175601312950517761",
  "geo" : { },
  "id_str" : "175602087873359873",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb pretty much..... But sure - I'll keep a seat for ya ;)",
  "id" : 175602087873359873,
  "in_reply_to_status_id" : 175601312950517761,
  "created_at" : "2012-03-02 15:22:54 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Plunkett",
      "screen_name" : "kirkcoyb",
      "indices" : [ 0, 9 ],
      "id_str" : "80937118",
      "id" : 80937118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175601312950517761",
  "geo" : { },
  "id_str" : "175601821245648896",
  "in_reply_to_user_id" : 80937118,
  "text" : "@kirkcoyb pretty much...",
  "id" : 175601821245648896,
  "in_reply_to_status_id" : 175601312950517761,
  "created_at" : "2012-03-02 15:21:51 +0000",
  "in_reply_to_screen_name" : "kirkcoyb",
  "in_reply_to_user_id_str" : "80937118",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175601117093298176",
  "text" : "I am going straight to hell.. Straight to hell....",
  "id" : 175601117093298176,
  "created_at" : "2012-03-02 15:19:03 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175583048534990848",
  "geo" : { },
  "id_str" : "175594402356535297",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne good luck - hope the release went well :)",
  "id" : 175594402356535297,
  "in_reply_to_status_id" : 175583048534990848,
  "created_at" : "2012-03-02 14:52:22 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175561784432930816",
  "geo" : { },
  "id_str" : "175574729141391361",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore you are the boss though... so home time = when ever you say :)",
  "id" : 175574729141391361,
  "in_reply_to_status_id" : 175561784432930816,
  "created_at" : "2012-03-02 13:34:12 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175496268838219777",
  "text" : "I have about an hour or two's worth of work on this project then its signed off..... Good way to start a Friday putting a proj to bed.",
  "id" : 175496268838219777,
  "created_at" : "2012-03-02 08:22:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 0, 12 ],
      "id_str" : "14049418",
      "id" : 14049418
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175347088090083328",
  "geo" : { },
  "id_str" : "175350863836086272",
  "in_reply_to_user_id" : 14049418,
  "text" : "@stimpled0rf @peter_omalley always",
  "id" : 175350863836086272,
  "in_reply_to_status_id" : 175347088090083328,
  "created_at" : "2012-03-01 22:44:38 +0000",
  "in_reply_to_screen_name" : "stimpled0rf",
  "in_reply_to_user_id_str" : "14049418",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175335279580811267",
  "geo" : { },
  "id_str" : "175335699879440385",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley I think I pissed them off... But I was looking forward to it and I am a presbie.. 6.20 - too right i got ma moneys worth!",
  "id" : 175335699879440385,
  "in_reply_to_status_id" : 175335279580811267,
  "created_at" : "2012-03-01 21:44:23 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McMaster",
      "screen_name" : "s_mc_master",
      "indices" : [ 0, 12 ],
      "id_str" : "501270359",
      "id" : 501270359
    }, {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 57, 72 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175335190183419904",
  "geo" : { },
  "id_str" : "175335469737979904",
  "in_reply_to_user_id" : 501270359,
  "text" : "@s_mc_master It is - am in training though so don't tell @Georgina_Milne as I have a shit load of weight to lose for August :)",
  "id" : 175335469737979904,
  "in_reply_to_status_id" : 175335190183419904,
  "created_at" : "2012-03-01 21:43:28 +0000",
  "in_reply_to_screen_name" : "s_mc_master",
  "in_reply_to_user_id_str" : "501270359",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 7, 21 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175334753845772290",
  "geo" : { },
  "id_str" : "175335156503166976",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @peter_omalley ohhh and coleslaw....",
  "id" : 175335156503166976,
  "in_reply_to_status_id" : 175334753845772290,
  "created_at" : "2012-03-01 21:42:13 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Henderson",
      "screen_name" : "Kirstylvssp",
      "indices" : [ 0, 12 ],
      "id_str" : "453312717",
      "id" : 453312717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 100, 113 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Michael",
      "screen_name" : "stimpled0rf",
      "indices" : [ 114, 126 ],
      "id_str" : "14049418",
      "id" : 14049418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175334219164286976",
  "geo" : { },
  "id_str" : "175335000911265792",
  "in_reply_to_user_id" : 453312717,
  "text" : "@Kirstylvssp @peter_omalley I am up for that... 1st Friday in April collective man challenge... \/cc @RickyHassard @stimpled0rf ???",
  "id" : 175335000911265792,
  "in_reply_to_status_id" : 175334219164286976,
  "created_at" : "2012-03-01 21:41:36 +0000",
  "in_reply_to_screen_name" : "Kirstylvssp",
  "in_reply_to_user_id_str" : "453312717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 7, 21 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175334382507278337",
  "geo" : { },
  "id_str" : "175334753845772290",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @peter_omalley burger, sun dried tomatoes, swedish cheese, jalapenos, onion ring with thousand island dressing and garlic sauce!",
  "id" : 175334753845772290,
  "in_reply_to_status_id" : 175334382507278337,
  "created_at" : "2012-03-01 21:40:37 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175333165324443648",
  "geo" : { },
  "id_str" : "175334382507278337",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley white bap, red sauce base, ice berg lettuce, tabacco onions,  tomatoes, peppers, cucumber, onion rings, boiled egg, beef",
  "id" : 175334382507278337,
  "in_reply_to_status_id" : 175333165324443648,
  "created_at" : "2012-03-01 21:39:09 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/175330152052568064\/photo\/1",
      "indices" : [ 50, 69 ],
      "url" : "http:\/\/t.co\/drvNRAl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Am7l2CfCMAEm6M2.jpg",
      "id_str" : "175330152056762369",
      "id" : 175330152056762369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am7l2CfCMAEm6M2.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/drvNRAl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175330152052568064",
  "text" : "Epic Burger...... Forgot the fried egg though.... http:\/\/t.co\/drvNRAl",
  "id" : 175330152052568064,
  "created_at" : "2012-03-01 21:22:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Andrew Hagan",
      "screen_name" : "hagy83",
      "indices" : [ 14, 21 ],
      "id_str" : "128812149",
      "id" : 128812149
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 22, 34 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175323864073641984",
  "geo" : { },
  "id_str" : "175324208086261760",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @hagy83 @niall_adams Bodger and Badger, Bodger and Bader. Na-na-na na na, Na-na-na na na! Bodger and Badger &lt;rinse and repeat&gt;",
  "id" : 175324208086261760,
  "in_reply_to_status_id" : 175323864073641984,
  "created_at" : "2012-03-01 20:58:43 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175305751034740736",
  "geo" : { },
  "id_str" : "175322172217241601",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard Dude that does not look good.... In fact that looks terrible.... How did it turn out?",
  "id" : 175322172217241601,
  "in_reply_to_status_id" : 175305751034740736,
  "created_at" : "2012-03-01 20:50:37 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ransom_Stoddard",
      "screen_name" : "Ransom_Stoddard",
      "indices" : [ 3, 19 ],
      "id_str" : "310915180",
      "id" : 310915180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175195294919700480",
  "text" : "RT @Ransom_Stoddard: Lisburn is becoming less of a City and more of a Ghost Town due to a lack of action by the Council and the Executiv ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/zH5YfAwb",
        "expanded_url" : "http:\/\/www.lisburntoday.co.uk\/news\/letters\/saddened_to_see_yet_more_stores_close_1_3560357",
        "display_url" : "lisburntoday.co.uk\/news\/letters\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "175192367916261376",
    "text" : "Lisburn is becoming less of a City and more of a Ghost Town due to a lack of action by the Council and the Executive http:\/\/t.co\/zH5YfAwb",
    "id" : 175192367916261376,
    "created_at" : "2012-03-01 12:14:50 +0000",
    "user" : {
      "name" : "Ransom_Stoddard",
      "screen_name" : "Ransom_Stoddard",
      "protected" : false,
      "id_str" : "310915180",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1381568893\/34242_normal.jpg",
      "id" : 310915180,
      "verified" : false
    }
  },
  "id" : 175195294919700480,
  "created_at" : "2012-03-01 12:26:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sophieraworth",
      "screen_name" : "sophieraworth",
      "indices" : [ 3, 17 ],
      "id_str" : "99560384",
      "id" : 99560384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175194207403769856",
  "text" : "RT @sophieraworth: A suspected thief arrested in Belfast - with his arm stuck in a letterbox. Fire crew couldn't free him so took letter ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "175192932134039552",
    "text" : "A suspected thief arrested in Belfast - with his arm stuck in a letterbox. Fire crew couldn't free him so took letterbox off instead...",
    "id" : 175192932134039552,
    "created_at" : "2012-03-01 12:17:04 +0000",
    "user" : {
      "name" : "sophieraworth",
      "screen_name" : "sophieraworth",
      "protected" : false,
      "id_str" : "99560384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000491976584\/21708cb50aba903ce02106feebde3c23_normal.jpeg",
      "id" : 99560384,
      "verified" : false
    }
  },
  "id" : 175194207403769856,
  "created_at" : "2012-03-01 12:22:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shitlikethatreallydoesworkiamnotcrazy",
      "indices" : [ 95, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175188290855645184",
  "text" : "Meeting wasn't too bad. Was pretty good in fact. But that's cos we sat in the correct order!!! #shitlikethatreallydoesworkiamnotcrazy",
  "id" : 175188290855645184,
  "created_at" : "2012-03-01 11:58:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175125331760517120",
  "geo" : { },
  "id_str" : "175133906981502976",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke working with me is great craic..... :D",
  "id" : 175133906981502976,
  "in_reply_to_status_id" : 175125331760517120,
  "created_at" : "2012-03-01 08:22:31 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/175058530586460161\/photo\/1",
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/by0YpWR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Am3uzlsCAAA-dYb.jpg",
      "id_str" : "175058530594848768",
      "id" : 175058530594848768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am3uzlsCAAA-dYb.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/by0YpWR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175058530586460161",
  "text" : "Awesome... Got him at 3:22am. We are both in that meeting tomorrow. This isn't going to be fun :) http:\/\/t.co\/by0YpWR",
  "id" : 175058530586460161,
  "created_at" : "2012-03-01 03:23:01 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175056838683926528",
  "text" : "Writing the software and systems is interesting.. Meetings are not... Have already had my quota of meeting this week already :)",
  "id" : 175056838683926528,
  "created_at" : "2012-03-01 03:16:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175056563390787584",
  "text" : "This is not good shit... I cannot sleep and I have a 3 hour meeting tomorrow to discuss Dog System Stat Returns...",
  "id" : 175056563390787584,
  "created_at" : "2012-03-01 03:15:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]