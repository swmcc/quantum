Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coldasmytits",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274629465894686720",
  "text" : "Really need to set the timer on my heating... Just home - met by 2 pengiuns and an Eskimo this time... #coldasmytits",
  "id" : 274629465894686720,
  "created_at" : "2012-11-30 21:42:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 60, 73 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274574225363324928",
  "geo" : { },
  "id_str" : "274574832656596994",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams Shit I tweeted myself didn't I? Meant to tweet @Paul_Moffett - right - time to down tools and go home! You miss me don't ya ;)",
  "id" : 274574832656596994,
  "in_reply_to_status_id" : 274574225363324928,
  "created_at" : "2012-11-30 18:05:16 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274571191375769600",
  "geo" : { },
  "id_str" : "274572264924672002",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 Brilliant! :D",
  "id" : 274572264924672002,
  "in_reply_to_status_id" : 274571191375769600,
  "created_at" : "2012-11-30 17:55:03 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Debenhams",
      "screen_name" : "Debenhams",
      "indices" : [ 7, 17 ],
      "id_str" : "296196029",
      "id" : 296196029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/Bhubvedd",
      "expanded_url" : "http:\/\/yfrog.com\/khq3mnp",
      "display_url" : "yfrog.com\/khq3mnp"
    } ]
  },
  "geo" : { },
  "id_str" : "274572075891556353",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @debenhams - errrr\u2026 apologies\u2026  http:\/\/t.co\/Bhubvedd",
  "id" : 274572075891556353,
  "created_at" : "2012-11-30 17:54:18 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Debenhams",
      "screen_name" : "Debenhams",
      "indices" : [ 63, 73 ],
      "id_str" : "296196029",
      "id" : 296196029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274570511458107392",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett your stupid wedding list is making me register a @Debenhams account.. FUCK YOU BOTH IN THE ASSES!!!!",
  "id" : 274570511458107392,
  "created_at" : "2012-11-30 17:48:05 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274565150864977920",
  "geo" : { },
  "id_str" : "274567472470970368",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 proper Knightrider now\u2026. None of that diluted re-make shite. :)",
  "id" : 274567472470970368,
  "in_reply_to_status_id" : 274565150864977920,
  "created_at" : "2012-11-30 17:36:01 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274541870468694016",
  "text" : "Secret Santa at Repknight sorted\u2026",
  "id" : 274541870468694016,
  "created_at" : "2012-11-30 15:54:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 3, 13 ],
      "id_str" : "212603717",
      "id" : 212603717
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 110, 116 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274534430385766401",
  "text" : "RT @carisenda: The cabal playlist is KLF, Cream, QotSA, The Police and Shania Twain. Mental note: don't allow @swmcc near the playlist.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 95, 101 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274532946566868992",
    "text" : "The cabal playlist is KLF, Cream, QotSA, The Police and Shania Twain. Mental note: don't allow @swmcc near the playlist.",
    "id" : 274532946566868992,
    "created_at" : "2012-11-30 15:18:49 +0000",
    "user" : {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "protected" : false,
      "id_str" : "212603717",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1513037620\/avatar_normal.png",
      "id" : 212603717,
      "verified" : false
    }
  },
  "id" : 274534430385766401,
  "created_at" : "2012-11-30 15:24:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274479410252496897",
  "text" : "I've just been called \"The White\" Barry White\u2026. #awesome",
  "id" : 274479410252496897,
  "created_at" : "2012-11-30 11:46:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274254065024765952",
  "geo" : { },
  "id_str" : "274268042987462656",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl i never liked him. I was always more a fan of goose anyways",
  "id" : 274268042987462656,
  "in_reply_to_status_id" : 274254065024765952,
  "created_at" : "2012-11-29 21:46:11 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/38LHIHF3",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=PKEu2f1J_9o",
      "display_url" : "youtube.com\/watch?v=PKEu2f\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "274248508071108608",
  "geo" : { },
  "id_str" : "274249959489015809",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl http:\/\/t.co\/38LHIHF3",
  "id" : 274249959489015809,
  "in_reply_to_status_id" : 274248508071108608,
  "created_at" : "2012-11-29 20:34:20 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274240571537776641",
  "geo" : { },
  "id_str" : "274246700951015424",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl you fucking legend... Best. Film. Ever. *playing with the boys*",
  "id" : 274246700951015424,
  "in_reply_to_status_id" : 274240571537776641,
  "created_at" : "2012-11-29 20:21:23 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274153797754953728",
  "text" : "When I moved jobs my main reason was to learn new things.. It is happening on every level as today I learnt a new phrase \"A P1 Pish\" :D :D",
  "id" : 274153797754953728,
  "created_at" : "2012-11-29 14:12:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sahra",
      "screen_name" : "sahra_t",
      "indices" : [ 0, 8 ],
      "id_str" : "22045186",
      "id" : 22045186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/rp4kmL3z",
      "expanded_url" : "http:\/\/nzbs.org",
      "display_url" : "nzbs.org"
    } ]
  },
  "in_reply_to_status_id_str" : "274067374125228033",
  "geo" : { },
  "id_str" : "274094228387274752",
  "in_reply_to_user_id" : 22045186,
  "text" : "@sahra_t sick beard, http:\/\/t.co\/rp4kmL3z and nzb.su - will give them a go tonight and see how it goes.",
  "id" : 274094228387274752,
  "in_reply_to_status_id" : 274067374125228033,
  "created_at" : "2012-11-29 10:15:31 +0000",
  "in_reply_to_screen_name" : "sahra_t",
  "in_reply_to_user_id_str" : "22045186",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273935447120572417",
  "geo" : { },
  "id_str" : "273935712880046080",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe that's cos I is pretty though ;) :D",
  "id" : 273935712880046080,
  "in_reply_to_status_id" : 273935447120572417,
  "created_at" : "2012-11-28 23:45:38 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273934108281937920",
  "geo" : { },
  "id_str" : "273935025244880896",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin hmmm they shove up code without testing and you let them live? Better man than I ;)",
  "id" : 273935025244880896,
  "in_reply_to_status_id" : 273934108281937920,
  "created_at" : "2012-11-28 23:42:54 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273933900697456641",
  "text" : "I was out for most of tonight so didn't put the heating on (cos I am miserable).. I swear two pengiuns just passed me on the hall there!",
  "id" : 273933900697456641,
  "created_at" : "2012-11-28 23:38:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sahra",
      "screen_name" : "sahra_t",
      "indices" : [ 0, 8 ],
      "id_str" : "22045186",
      "id" : 22045186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273925170253660160",
  "in_reply_to_user_id" : 22045186,
  "text" : "@sahra_t cheers for the RT",
  "id" : 273925170253660160,
  "created_at" : "2012-11-28 23:03:44 +0000",
  "in_reply_to_screen_name" : "sahra_t",
  "in_reply_to_user_id_str" : "22045186",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Pullen",
      "screen_name" : "bobpullen",
      "indices" : [ 0, 10 ],
      "id_str" : "14771454",
      "id" : 14771454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273906168823443458",
  "geo" : { },
  "id_str" : "273924925348249600",
  "in_reply_to_user_id" : 14771454,
  "text" : "@bobpullen cheers :)",
  "id" : 273924925348249600,
  "in_reply_to_status_id" : 273906168823443458,
  "created_at" : "2012-11-28 23:02:46 +0000",
  "in_reply_to_screen_name" : "bobpullen",
  "in_reply_to_user_id_str" : "14771454",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padzor",
      "screen_name" : "padzor",
      "indices" : [ 0, 7 ],
      "id_str" : "60141834",
      "id" : 60141834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273898751486222336",
  "geo" : { },
  "id_str" : "273901146274406400",
  "in_reply_to_user_id" : 60141834,
  "text" : "@padzor i will give that a go thanks.",
  "id" : 273901146274406400,
  "in_reply_to_status_id" : 273898751486222336,
  "created_at" : "2012-11-28 21:28:16 +0000",
  "in_reply_to_screen_name" : "padzor",
  "in_reply_to_user_id_str" : "60141834",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273896807145279489",
  "text" : "So twitter - now that newzbin has retired what you recommend as a replacement?",
  "id" : 273896807145279489,
  "created_at" : "2012-11-28 21:11:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273873504674381824",
  "text" : "Just home - newzbin has closed.... Shite :(",
  "id" : 273873504674381824,
  "created_at" : "2012-11-28 19:38:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 9, 21 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amserious",
      "indices" : [ 105, 115 ]
    }, {
      "text" : "roadhouse",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273865779810799616",
  "geo" : { },
  "id_str" : "273868921541644288",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @debbiecreid You'll be burnt for real if you aren't able to talk to me about tonight's episode. #amserious #roadhouse",
  "id" : 273868921541644288,
  "in_reply_to_status_id" : 273865779810799616,
  "created_at" : "2012-11-28 19:20:13 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovethis",
      "indices" : [ 45, 54 ]
    }, {
      "text" : "nerd",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273831863020298240",
  "text" : "I'm gonna be building indexes in my sleep :) #lovethis #nerd",
  "id" : 273831863020298240,
  "created_at" : "2012-11-28 16:52:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hylands",
      "screen_name" : "shylands",
      "indices" : [ 0, 9 ],
      "id_str" : "9488072",
      "id" : 9488072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273821596601438208",
  "geo" : { },
  "id_str" : "273822722918862848",
  "in_reply_to_user_id" : 9488072,
  "text" : "@shylands when is it going live so I can be nosey :)",
  "id" : 273822722918862848,
  "in_reply_to_status_id" : 273821596601438208,
  "created_at" : "2012-11-28 16:16:39 +0000",
  "in_reply_to_screen_name" : "shylands",
  "in_reply_to_user_id_str" : "9488072",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 7, 15 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273793459708633089",
  "text" : "I miss @jbrevel :( You better be watching Sons for tomorrow.. Much to discuss.",
  "id" : 273793459708633089,
  "created_at" : "2012-11-28 14:20:22 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 14, 24 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273763641982062592",
  "text" : "About to give @smccalden my talk on how version control should be used for dev communication etc. God help him for those that got it prev :)",
  "id" : 273763641982062592,
  "created_at" : "2012-11-28 12:21:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273702690599604224",
  "geo" : { },
  "id_str" : "273703697119313920",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit had a strong coffee last night at around 8pm. Add that to my coffee consumption throughout the day and it was wide awake time",
  "id" : 273703697119313920,
  "in_reply_to_status_id" : 273702690599604224,
  "created_at" : "2012-11-28 08:23:41 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/0nFfhwge",
      "expanded_url" : "http:\/\/yfrog.com\/g0oheep",
      "display_url" : "yfrog.com\/g0oheep"
    } ]
  },
  "geo" : { },
  "id_str" : "273703523592568832",
  "text" : "I am so happy right now :) http:\/\/t.co\/0nFfhwge",
  "id" : 273703523592568832,
  "created_at" : "2012-11-28 08:22:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273595990831951872",
  "text" : "I left my phone in my car so they can't wake me back... At least I think I left my phone in the car... Fuck knows.",
  "id" : 273595990831951872,
  "created_at" : "2012-11-28 01:15:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 13, 23 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 24, 37 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 38, 52 ],
      "id_str" : "227493010",
      "id" : 227493010
    }, {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 53, 63 ],
      "id_str" : "609442047",
      "id" : 609442047
    }, {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 64, 76 ],
      "id_str" : "760043",
      "id" : 760043
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 77, 90 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wakeupfucknuts",
      "indices" : [ 91, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273595127094714369",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @smccalden @Paul_Moffett @jenporterhall @Xtinamccu @StrayTaoist @stevebiscuit #wakeupfucknuts",
  "id" : 273595127094714369,
  "created_at" : "2012-11-28 01:12:16 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273594326293020672",
  "text" : "Donkey Cock... Shouldn't have had that coffee at Moffett's after 8! Lets see who I can wake to share my misery!!!! Next tweet!",
  "id" : 273594326293020672,
  "created_at" : "2012-11-28 01:09:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/aOTm9Wv0",
      "expanded_url" : "http:\/\/vimium.github.com\/",
      "display_url" : "vimium.github.com"
    }, {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/UpcmEaUU",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=WlT1gM04uHw",
      "display_url" : "youtube.com\/watch?v=WlT1gM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273564611763118080",
  "text" : "http:\/\/t.co\/aOTm9Wv0 makes me go http:\/\/t.co\/UpcmEaUU",
  "id" : 273564611763118080,
  "created_at" : "2012-11-27 23:11:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273557908791373824",
  "geo" : { },
  "id_str" : "273561374343458816",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl War Games, The Karate Kid and especially Top Gun aren't crappy 80's movies.. Lets just nip that in the bud now :)",
  "id" : 273561374343458816,
  "in_reply_to_status_id" : 273557908791373824,
  "created_at" : "2012-11-27 22:58:08 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273543030680731649",
  "geo" : { },
  "id_str" : "273552620382203904",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl retro 80 films :) Tomorrow should be the karate kid or Top Gun! :)",
  "id" : 273552620382203904,
  "in_reply_to_status_id" : 273543030680731649,
  "created_at" : "2012-11-27 22:23:21 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 1, 12 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scenicroute",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273552393222909952",
  "text" : "\u201C@Alana_Doll: Awk sure I near drove to larne! #scenicroute\u201D Seven words you should never have to say!",
  "id" : 273552393222909952,
  "created_at" : "2012-11-27 22:22:27 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "couldntgiveaflyingfuckasivebeenfedsofuckhimandhisgayplacemats",
      "indices" : [ 56, 118 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273497293553037314",
  "geo" : { },
  "id_str" : "273501549194522624",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco just finished the dinner. So do as you see fit. #couldntgiveaflyingfuckasivebeenfedsofuckhimandhisgayplacemats",
  "id" : 273501549194522624,
  "in_reply_to_status_id" : 273497293553037314,
  "created_at" : "2012-11-27 19:00:25 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273497293553037314",
  "geo" : { },
  "id_str" : "273497605957365760",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco why did you cc him? Now he'll throw me out without feeding me. Ill be round at yours in 20 ;)",
  "id" : 273497605957365760,
  "in_reply_to_status_id" : 273497293553037314,
  "created_at" : "2012-11-27 18:44:45 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/273495950713049088\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/kMJ2adEk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8unHj4CUAA6Owd.jpg",
      "id_str" : "273495950717243392",
      "id" : 273495950717243392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8unHj4CUAA6Owd.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/kMJ2adEk"
    } ],
    "hashtags" : [ {
      "text" : "hewontnotice",
      "indices" : [ 92, 105 ]
    }, {
      "text" : "gayplacemats",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273495950713049088",
  "text" : "Getting fed for free but fuck me these place mats have to go. Shoving them down my kaks now #hewontnotice #gayplacemats http:\/\/t.co\/kMJ2adEk",
  "id" : 273495950713049088,
  "created_at" : "2012-11-27 18:38:10 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    }, {
      "name" : "Christina McCullough",
      "screen_name" : "Xtinamccu",
      "indices" : [ 15, 25 ],
      "id_str" : "609442047",
      "id" : 609442047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "enjoy",
      "indices" : [ 78, 84 ]
    }, {
      "text" : "schoolboyerror",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273468606648561664",
  "geo" : { },
  "id_str" : "273472224013451265",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher @Xtinamccu Phillip was peeving at other girls in magazines\u2026 :D #enjoy #schoolboyerror",
  "id" : 273472224013451265,
  "in_reply_to_status_id" : 273468606648561664,
  "created_at" : "2012-11-27 17:03:53 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273391862931419136",
  "geo" : { },
  "id_str" : "273393392174641152",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore oh dear :( You thinking of upping sticks and moving then?",
  "id" : 273393392174641152,
  "in_reply_to_status_id" : 273391862931419136,
  "created_at" : "2012-11-27 11:50:38 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273389028768882688",
  "geo" : { },
  "id_str" : "273389769071943680",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore my cousin manages your building. Drop my name and he'll seal that up for you.. No he won't.. but still you never know :)",
  "id" : 273389769071943680,
  "in_reply_to_status_id" : 273389028768882688,
  "created_at" : "2012-11-27 11:36:14 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 38, 48 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/q2eVH0tu",
      "expanded_url" : "http:\/\/yfrog.com\/nxb8dyp",
      "display_url" : "yfrog.com\/nxb8dyp"
    } ]
  },
  "geo" : { },
  "id_str" : "273388547514433536",
  "text" : "Dirty. Rotten. Bastards. Top marks to @carisenda for lowering it even more with a phpMyAdmin endorsement. http:\/\/t.co\/q2eVH0tu",
  "id" : 273388547514433536,
  "created_at" : "2012-11-27 11:31:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 11, 24 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bestfuckyouever",
      "indices" : [ 76, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273387202032046080",
  "geo" : { },
  "id_str" : "273387610104279040",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda @stevebiscuit he endorsed me for phpMyAdmin though - the fucker! #bestfuckyouever",
  "id" : 273387610104279040,
  "in_reply_to_status_id" : 273387202032046080,
  "created_at" : "2012-11-27 11:27:40 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 3, 16 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/stevebiscuit\/status\/273379662749655040\/photo\/1",
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/hZd20AmA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8s9WteCYAAA7q7.jpg",
      "id_str" : "273379662758043648",
      "id" : 273379662758043648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8s9WteCYAAA7q7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hZd20AmA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273379925996732416",
  "text" : "RT @stevebiscuit: And who says MySQL doesn't have a place in Big Data? http:\/\/t.co\/hZd20AmA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/stevebiscuit\/status\/273379662749655040\/photo\/1",
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/hZd20AmA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A8s9WteCYAAA7q7.jpg",
        "id_str" : "273379662758043648",
        "id" : 273379662758043648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8s9WteCYAAA7q7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hZd20AmA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273379662749655040",
    "text" : "And who says MySQL doesn't have a place in Big Data? http:\/\/t.co\/hZd20AmA",
    "id" : 273379662749655040,
    "created_at" : "2012-11-27 10:56:05 +0000",
    "user" : {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "protected" : false,
      "id_str" : "14068466",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1929736578\/steve_normal.png",
      "id" : 14068466,
      "verified" : false
    }
  },
  "id" : 273379925996732416,
  "created_at" : "2012-11-27 10:57:08 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Parmenter",
      "screen_name" : "sazzy",
      "indices" : [ 0, 6 ],
      "id_str" : "13811562",
      "id" : 13811562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273362520293662720",
  "geo" : { },
  "id_str" : "273367518717018112",
  "in_reply_to_user_id" : 13811562,
  "text" : "@sazzy writing a really good README at the start and updating it at the end of the day. Using the Pomodoro using to break work in chunks.",
  "id" : 273367518717018112,
  "in_reply_to_status_id" : 273362520293662720,
  "created_at" : "2012-11-27 10:07:50 +0000",
  "in_reply_to_screen_name" : "sazzy",
  "in_reply_to_user_id_str" : "13811562",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273159025032560642",
  "geo" : { },
  "id_str" : "273162911558553600",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett You really need to get rid of those placemats.. Next time I am round I'll shove them down me trousers or summit...",
  "id" : 273162911558553600,
  "in_reply_to_status_id" : 273159025032560642,
  "created_at" : "2012-11-26 20:34:47 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Calman",
      "screen_name" : "SusanCalman",
      "indices" : [ 3, 15 ],
      "id_str" : "20427223",
      "id" : 20427223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273084123868966912",
  "text" : "RT @SusanCalman: Got cold called.  Was asked for my National Insurance Number. I told them it was CPE 1704 TKS. That's the launch code i ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273030045365313536",
    "text" : "Got cold called.  Was asked for my National Insurance Number. I told them it was CPE 1704 TKS. That's the launch code in War Games. I win.",
    "id" : 273030045365313536,
    "created_at" : "2012-11-26 11:46:50 +0000",
    "user" : {
      "name" : "Susan Calman",
      "screen_name" : "SusanCalman",
      "protected" : false,
      "id_str" : "20427223",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2137094589\/pootle_normal.jpg",
      "id" : 20427223,
      "verified" : false
    }
  },
  "id" : 273084123868966912,
  "created_at" : "2012-11-26 15:21:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273059543997620224",
  "geo" : { },
  "id_str" : "273061361880285184",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore does it get busy at lunchtime too? Fuck that then. I just thought it got busy during the evening.",
  "id" : 273061361880285184,
  "in_reply_to_status_id" : 273059543997620224,
  "created_at" : "2012-11-26 13:51:16 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273046876771733504",
  "geo" : { },
  "id_str" : "273055618313629697",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore what? ever? Its right outside your front door man! I dunno\u2026. You just don't deserve such a good thing to be so close :)",
  "id" : 273055618313629697,
  "in_reply_to_status_id" : 273046876771733504,
  "created_at" : "2012-11-26 13:28:27 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273044593673646080",
  "geo" : { },
  "id_str" : "273046290991046656",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore wild boar!!! go for the wild boar!",
  "id" : 273046290991046656,
  "in_reply_to_status_id" : 273044593673646080,
  "created_at" : "2012-11-26 12:51:23 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "indices" : [ 3, 17 ],
      "id_str" : "233333546",
      "id" : 233333546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273040986043731968",
  "text" : "RT @madebyrichard: Juggling work and fending off a horny dog is tricky",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273040669671555072",
    "text" : "Juggling work and fending off a horny dog is tricky",
    "id" : 273040669671555072,
    "created_at" : "2012-11-26 12:29:03 +0000",
    "user" : {
      "name" : "Richard FS",
      "screen_name" : "madebyrichard",
      "protected" : false,
      "id_str" : "233333546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3224464013\/9d96f183f148b6675952fe73fabe9fb5_normal.jpeg",
      "id" : 233333546,
      "verified" : false
    }
  },
  "id" : 273040986043731968,
  "created_at" : "2012-11-26 12:30:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273030426803699712",
  "text" : "I have no idea how people can survive without coffee in an office environment..",
  "id" : 273030426803699712,
  "created_at" : "2012-11-26 11:48:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Girvin",
      "screen_name" : "johngirvin",
      "indices" : [ 0, 11 ],
      "id_str" : "14604982",
      "id" : 14604982
    }, {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 12, 25 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Simon McCartney",
      "screen_name" : "simonmcc",
      "indices" : [ 26, 35 ],
      "id_str" : "6776922",
      "id" : 6776922
    }, {
      "name" : "Simon Hamilton",
      "screen_name" : "hamstarr",
      "indices" : [ 36, 45 ],
      "id_str" : "8388092",
      "id" : 8388092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273016026998923264",
  "geo" : { },
  "id_str" : "273017574046965760",
  "in_reply_to_user_id" : 14604982,
  "text" : "@johngirvin @stevebiscuit @simonmcc @hamstarr But most 'kids' now use IDE's for knowledge replacement though - which is sad :(",
  "id" : 273017574046965760,
  "in_reply_to_status_id" : 273016026998923264,
  "created_at" : "2012-11-26 10:57:16 +0000",
  "in_reply_to_screen_name" : "johngirvin",
  "in_reply_to_user_id_str" : "14604982",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 6, 14 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manupandcomeintofuck",
      "indices" : [ 108, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273000734302281728",
  "text" : "Seems @jbrevel has been emitted with the disease too\u2026 All his big balls eddie talk about not getting colds\u2026 #manupandcomeintofuck :)",
  "id" : 273000734302281728,
  "created_at" : "2012-11-26 09:50:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetGlue",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/vK7bubIz",
      "expanded_url" : "http:\/\/is.gd\/ekwaNj",
      "display_url" : "is.gd\/ekwaNj"
    } ]
  },
  "geo" : { },
  "id_str" : "272847747600756736",
  "text" : "I unlocked the Bootcamp sticker on #GetGlue! http:\/\/t.co\/vK7bubIz",
  "id" : 272847747600756736,
  "created_at" : "2012-11-25 23:42:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getglue.com\" rel=\"nofollow\"\u003EGetGlue.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetGlue",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "TheLastSeven",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/75yX7O36",
      "expanded_url" : "http:\/\/is.gd\/dPDvO5",
      "display_url" : "is.gd\/dPDvO5"
    } ]
  },
  "geo" : { },
  "id_str" : "272847735089160192",
  "text" : "I'm watching The Last Seven http:\/\/t.co\/75yX7O36 #GetGlue #TheLastSeven",
  "id" : 272847735089160192,
  "created_at" : "2012-11-25 23:42:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272783454209449984",
  "text" : "As I near my 8000 tweet I am wondering just what utter bollocks it will be about.",
  "id" : 272783454209449984,
  "created_at" : "2012-11-25 19:26:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272769910587932672",
  "geo" : { },
  "id_str" : "272777206755889153",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden I meant half not have... When you are as pretty as me you don't have to spell things correctly ;)",
  "id" : 272777206755889153,
  "in_reply_to_status_id" : 272769910587932672,
  "created_at" : "2012-11-25 19:02:08 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272769910587932672",
  "geo" : { },
  "id_str" : "272777081098760192",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden Aye... Luckily have the kitchen is tiled. So just have to repaint the ceiling and the wall.. Could have been worse :)",
  "id" : 272777081098760192,
  "in_reply_to_status_id" : 272769910587932672,
  "created_at" : "2012-11-25 19:01:38 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272767495805480960",
  "text" : "Typical.. This disease is lifting now at 6pm on a Sunday. I'm gonna do something cool next weekend as this one sucked big donkey dick.",
  "id" : 272767495805480960,
  "created_at" : "2012-11-25 18:23:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 12, 20 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/bzVeVXaT",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=to1l78Y6IkA",
      "display_url" : "youtube.com\/watch?v=to1l78\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272641538117484545",
  "text" : "Reminder to @jbrevel to watch The WaLking Dead.. If you are hungover listen to this to get you up and out! http:\/\/t.co\/bzVeVXaT",
  "id" : 272641538117484545,
  "created_at" : "2012-11-25 10:03:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272626584035414016",
  "text" : "A few episodes of Fraiser to make me feel edumucated on a Sun morn. Starting to get over this fucking cold too! Diseases ridden designers.",
  "id" : 272626584035414016,
  "created_at" : "2012-11-25 09:03:37 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/WOqJqwow",
      "expanded_url" : "http:\/\/www.examiner.com\/article\/kelsey-grammer-s-boss-cancelled-by-starz-after-two-seasons",
      "display_url" : "examiner.com\/article\/kelsey\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272411894428614657",
  "text" : "Fuck. Right. Off. http:\/\/t.co\/WOqJqwow",
  "id" : 272411894428614657,
  "created_at" : "2012-11-24 18:50:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Armstrong Villas",
      "screen_name" : "spain_resales",
      "indices" : [ 14, 28 ],
      "id_str" : "89479760",
      "id" : 89479760
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 54, 65 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/L5JX68q6",
      "expanded_url" : "http:\/\/4sq.com\/9JtRX3",
      "display_url" : "4sq.com\/9JtRX3"
    } ]
  },
  "geo" : { },
  "id_str" : "272349205278912512",
  "text" : "I just ousted @spain_resales as the mayor of Tesco on @foursquare! http:\/\/t.co\/L5JX68q6",
  "id" : 272349205278912512,
  "created_at" : "2012-11-24 14:41:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/WsjPCJYK",
      "expanded_url" : "http:\/\/techcrunch.com\/2012\/11\/23\/instagram-thanksgiving\/",
      "display_url" : "techcrunch.com\/2012\/11\/23\/ins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272291029766508544",
  "text" : "Geek Porn - http:\/\/t.co\/WsjPCJYK",
  "id" : 272291029766508544,
  "created_at" : "2012-11-24 10:50:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272281290823327744",
  "geo" : { },
  "id_str" : "272289071764733952",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda neither would I. But the execs still get to say to their overlords \"this ad was seen by x\".",
  "id" : 272289071764733952,
  "in_reply_to_status_id" : 272281290823327744,
  "created_at" : "2012-11-24 10:42:28 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen",
      "screen_name" : "carisenda",
      "indices" : [ 0, 10 ],
      "id_str" : "212603717",
      "id" : 212603717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272278669790158848",
  "geo" : { },
  "id_str" : "272279393643155456",
  "in_reply_to_user_id" : 212603717,
  "text" : "@carisenda I'd say the amount for the skippable ads like that and the ones you can't skip is telling.",
  "id" : 272279393643155456,
  "in_reply_to_status_id" : 272278669790158848,
  "created_at" : "2012-11-24 10:04:00 +0000",
  "in_reply_to_screen_name" : "carisenda",
  "in_reply_to_user_id_str" : "212603717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272090146973814784",
  "text" : "OH: \"Sarah Milligan is about as funny as a sore cock\u2026 My sore cock\" - Gotta love my Dad :)",
  "id" : 272090146973814784,
  "created_at" : "2012-11-23 21:32:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271971788647440384",
  "geo" : { },
  "id_str" : "271973725186953216",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams too right. never happened. your loss ;)",
  "id" : 271973725186953216,
  "in_reply_to_status_id" : 271971788647440384,
  "created_at" : "2012-11-23 13:49:23 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 10, 17 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271963694882254848",
  "geo" : { },
  "id_str" : "271967753336938496",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues @srushe So proud :D I hope you gave the universal sign that you were calling him a wanker too for extra swmcc points :D",
  "id" : 271967753336938496,
  "in_reply_to_status_id" : 271963694882254848,
  "created_at" : "2012-11-23 13:25:39 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    }, {
      "name" : "katherine",
      "screen_name" : "wee_kitty_kat",
      "indices" : [ 12, 26 ],
      "id_str" : "878452075",
      "id" : 878452075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271958744043233280",
  "geo" : { },
  "id_str" : "271966666911514624",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll @wee_kitty_kat I think that reads different if you aren't from Lisburn. Just saying\u2026",
  "id" : 271966666911514624,
  "in_reply_to_status_id" : 271958744043233280,
  "created_at" : "2012-11-23 13:21:20 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 1, 10 ],
      "id_str" : "17864413",
      "id" : 17864413
    }, {
      "name" : "CollegeHumor",
      "screen_name" : "CollegeHumor",
      "indices" : [ 126, 139 ],
      "id_str" : "16825289",
      "id" : 16825289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/9iLNIliR",
      "expanded_url" : "http:\/\/su.pr\/25DlsP",
      "display_url" : "su.pr\/25DlsP"
    } ]
  },
  "geo" : { },
  "id_str" : "271950913206366208",
  "text" : "\u201C@ManyHues:This vid argues for marriage equality with humour :D \nGay Men Will Marry Your Girlfriends http:\/\/t.co\/9iLNIliR via @CollegeHumor\u201D",
  "id" : 271950913206366208,
  "created_at" : "2012-11-23 12:18:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271949281374633984",
  "geo" : { },
  "id_str" : "271949514875731968",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe When songs like Rawhide and Surfing Bird come through the speakers its a good distraction :)",
  "id" : 271949514875731968,
  "in_reply_to_status_id" : 271949281374633984,
  "created_at" : "2012-11-23 12:13:11 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271948654485577729",
  "geo" : { },
  "id_str" : "271948820420640768",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe If its done in the right way its good craic though. In here it is done in the right way as I would have agreed with you before.",
  "id" : 271948820420640768,
  "in_reply_to_status_id" : 271948654485577729,
  "created_at" : "2012-11-23 12:10:26 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271946534084571136",
  "geo" : { },
  "id_str" : "271947771576217600",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe its good craic in here though. Helps when you can turn it up loud as the phones rarely go off in here (touch wood).",
  "id" : 271947771576217600,
  "in_reply_to_status_id" : 271946534084571136,
  "created_at" : "2012-11-23 12:06:15 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271945393787506689",
  "text" : "Nothing like Surfing Bird coming on in through the office speakers\u2026",
  "id" : 271945393787506689,
  "created_at" : "2012-11-23 11:56:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckmccalden",
      "indices" : [ 31, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/ZVlO80x4",
      "expanded_url" : "http:\/\/www.stephenmccalden.com\/blog\/2012\/11\/23\/fmc-best-live-song\/",
      "display_url" : "stephenmccalden.com\/blog\/2012\/11\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271936261151944704",
  "text" : "I win - http:\/\/t.co\/ZVlO80x4 - #fuckmccalden",
  "id" : 271936261151944704,
  "created_at" : "2012-11-23 11:20:31 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 37, 48 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/u33U8yos",
      "expanded_url" : "http:\/\/4sq.com\/TT1k0P",
      "display_url" : "4sq.com\/TT1k0P"
    } ]
  },
  "geo" : { },
  "id_str" : "271934967725035520",
  "text" : "I just unlocked the \"Local\" badge on @foursquare for checking in three times at the same place in one week! http:\/\/t.co\/u33U8yos",
  "id" : 271934967725035520,
  "created_at" : "2012-11-23 11:15:23 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271928705973104641",
  "geo" : { },
  "id_str" : "271929777257074688",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid well do thanks :)",
  "id" : 271929777257074688,
  "in_reply_to_status_id" : 271928705973104641,
  "created_at" : "2012-11-23 10:54:45 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271927799076499456",
  "text" : "OH: \"And the main joke is she's a lesbian\".",
  "id" : 271927799076499456,
  "created_at" : "2012-11-23 10:46:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271925377750949889",
  "geo" : { },
  "id_str" : "271927233701101570",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid I'm not that bad really - just man flu :) Mark diseased me\u2026",
  "id" : 271927233701101570,
  "in_reply_to_status_id" : 271925377750949889,
  "created_at" : "2012-11-23 10:44:39 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271924611673907200",
  "text" : "I feel sick and unwell :(",
  "id" : 271924611673907200,
  "created_at" : "2012-11-23 10:34:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kevtraynor",
      "screen_name" : "kevtraynor",
      "indices" : [ 0, 11 ],
      "id_str" : "17738145",
      "id" : 17738145
    }, {
      "name" : "BBC Northern Ireland",
      "screen_name" : "BBCnireland",
      "indices" : [ 12, 24 ],
      "id_str" : "1451312228",
      "id" : 1451312228
    }, {
      "name" : "BBC Question Time",
      "screen_name" : "bbcqt",
      "indices" : [ 25, 31 ],
      "id_str" : "41579192",
      "id" : 41579192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271757349235077120",
  "geo" : { },
  "id_str" : "271758030213885952",
  "in_reply_to_user_id" : 39041248,
  "text" : "@kevtraynor @bbcnireland @bbcqt @PlanzaiRich if you have sky go to sky channel 960",
  "id" : 271758030213885952,
  "in_reply_to_status_id" : 271757349235077120,
  "created_at" : "2012-11-22 23:32:18 +0000",
  "in_reply_to_screen_name" : "dalerocks",
  "in_reply_to_user_id_str" : "39041248",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271748204524105728",
  "geo" : { },
  "id_str" : "271751869594992641",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams bring it bitch",
  "id" : 271751869594992641,
  "in_reply_to_status_id" : 271748204524105728,
  "created_at" : "2012-11-22 23:07:49 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271747501390966784",
  "geo" : { },
  "id_str" : "271747788449144832",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams design. flaw. :)",
  "id" : 271747788449144832,
  "in_reply_to_status_id" : 271747501390966784,
  "created_at" : "2012-11-22 22:51:36 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271747145785286658",
  "geo" : { },
  "id_str" : "271747651970678785",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams it is Friday - I expect nothing else :D :D :D",
  "id" : 271747651970678785,
  "in_reply_to_status_id" : 271747145785286658,
  "created_at" : "2012-11-22 22:51:03 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/dW6t4EoM",
      "expanded_url" : "http:\/\/tom.preston-werner.com\/2010\/08\/23\/readme-driven-development.html",
      "display_url" : "tom.preston-werner.com\/2010\/08\/23\/rea\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "271745158133989376",
  "geo" : { },
  "id_str" : "271747173002129408",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop Tom Preston Werner wrote about it - http:\/\/t.co\/dW6t4EoM - seems good enough for me for personal stuff - giving it a go anywho",
  "id" : 271747173002129408,
  "in_reply_to_status_id" : 271745158133989376,
  "created_at" : "2012-11-22 22:49:09 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 17, 23 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271746833330626560",
  "text" : "RT: @nail_adams: @swmcc as you once said to me \"You uncultured fuck!\"",
  "id" : 271746833330626560,
  "created_at" : "2012-11-22 22:47:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "indices" : [ 15, 26 ],
      "id_str" : "66949689",
      "id" : 66949689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271741609899618304",
  "geo" : { },
  "id_str" : "271742606264893440",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @blacknorth about the current state of digital animation firms in NI. Very good segment too.",
  "id" : 271742606264893440,
  "in_reply_to_status_id" : 271741609899618304,
  "created_at" : "2012-11-22 22:31:00 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "indices" : [ 110, 121 ],
      "id_str" : "66949689",
      "id" : 66949689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maybenot",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271740763082194944",
  "text" : "So Kris was just on the tee-vee there - could swear he dropped an octave though from his natural voice ;) \/cc @blacknorth #maybenot",
  "id" : 271740763082194944,
  "created_at" : "2012-11-22 22:23:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blacknorth",
      "screen_name" : "blacknorth",
      "indices" : [ 39, 50 ],
      "id_str" : "66949689",
      "id" : 66949689
    }, {
      "name" : "The Arts Show",
      "screen_name" : "bbcartsshow",
      "indices" : [ 62, 74 ],
      "id_str" : "843228829",
      "id" : 843228829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271737504120573953",
  "text" : "I just saw a quick teaser of something @blacknorth did on the @bbcartsshow. Yeah I watch art shows.. I am full of culture - fuckers!",
  "id" : 271737504120573953,
  "created_at" : "2012-11-22 22:10:44 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271736257372098560",
  "text" : "Just trying some RDD on my code...",
  "id" : 271736257372098560,
  "created_at" : "2012-11-22 22:05:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271654040981618688",
  "text" : "\"My IDE won't work with git\" - *swmcc blank face* \"My IDE won't work with git\" *swmcc rinse and repeat*.",
  "id" : 271654040981618688,
  "created_at" : "2012-11-22 16:39:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Mone OBE",
      "screen_name" : "MichelleMone",
      "indices" : [ 0, 13 ],
      "id_str" : "58432995",
      "id" : 58432995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271647977909649408",
  "geo" : { },
  "id_str" : "271649001638608896",
  "in_reply_to_user_id" : 58432995,
  "text" : "@MichelleMone welcome to Norn Iron :)",
  "id" : 271649001638608896,
  "in_reply_to_status_id" : 271647977909649408,
  "created_at" : "2012-11-22 16:19:03 +0000",
  "in_reply_to_screen_name" : "MichelleMone",
  "in_reply_to_user_id_str" : "58432995",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271642744764628995",
  "geo" : { },
  "id_str" : "271642965993197570",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull not my tools pretty lady!! I am happy with my setup :) He has left me defeated :) But IDE's are shite!",
  "id" : 271642965993197570,
  "in_reply_to_status_id" : 271642744764628995,
  "created_at" : "2012-11-22 15:55:04 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IDESAREREALLYSHIT",
      "indices" : [ 87, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271641332248870912",
  "text" : "git push origin master (or gp if you alias it) v 1h25mins docking about with netbeans\u2026 #IDESAREREALLYSHIT",
  "id" : 271641332248870912,
  "created_at" : "2012-11-22 15:48:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271633473381470208",
  "text" : "IDE's are shite\u2026 learn the command line FFS!",
  "id" : 271633473381470208,
  "created_at" : "2012-11-22 15:17:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271624633189556224",
  "text" : "OH: \"It refreshes every time I am back filling myself\"",
  "id" : 271624633189556224,
  "created_at" : "2012-11-22 14:42:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271620929581355008",
  "text" : "Some dirty son of a bitch (Mark) has given me the cold\u2026. Disease ridden designers\u2026 Filth...",
  "id" : 271620929581355008,
  "created_at" : "2012-11-22 14:27:30 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271610645827436544",
  "geo" : { },
  "id_str" : "271615864632143872",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams cheers - I've used them for a few things so far - seems very good :) Pricey though :)",
  "id" : 271615864632143872,
  "in_reply_to_status_id" : 271610645827436544,
  "created_at" : "2012-11-22 14:07:23 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Rushe",
      "screen_name" : "srushe",
      "indices" : [ 0, 7 ],
      "id_str" : "761761",
      "id" : 761761
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 8, 20 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271608500776468482",
  "geo" : { },
  "id_str" : "271615786563551232",
  "in_reply_to_user_id" : 761761,
  "text" : "@srushe @niall_adams cheers steve",
  "id" : 271615786563551232,
  "in_reply_to_status_id" : 271608500776468482,
  "created_at" : "2012-11-22 14:07:04 +0000",
  "in_reply_to_screen_name" : "srushe",
  "in_reply_to_user_id_str" : "761761",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 1, 13 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/ivjBH8kK",
      "expanded_url" : "http:\/\/arstechnica.com\/information-technology\/2012\/11\/how-team-obamas-tech-efficiency-left-romney-it-in-dust\/",
      "display_url" : "arstechnica.com\/information-te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271607884847136769",
  "text" : "\u201C@niall_adams: Interesting article on the IT spend of Obama's campaign. http:\/\/t.co\/ivjBH8kK\u201D",
  "id" : 271607884847136769,
  "created_at" : "2012-11-22 13:35:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271349285503774721",
  "geo" : { },
  "id_str" : "271350341142974464",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg Thoust does but I am not that eager at the minute. It can wait - its almost done now. :)",
  "id" : 271350341142974464,
  "in_reply_to_status_id" : 271349285503774721,
  "created_at" : "2012-11-21 20:32:17 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271346708892512256",
  "geo" : { },
  "id_str" : "271347716104261633",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg I also have to add its only a certain \"thing\" that is being throttled...",
  "id" : 271347716104261633,
  "in_reply_to_status_id" : 271346708892512256,
  "created_at" : "2012-11-21 20:21:51 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271346708892512256",
  "geo" : { },
  "id_str" : "271347599456497664",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg I'm doing \"something\" I wouldn't normally do. But my usual shop is out of the product so getting it elsewhere :)",
  "id" : 271347599456497664,
  "in_reply_to_status_id" : 271346708892512256,
  "created_at" : "2012-11-21 20:21:23 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271343688515477504",
  "geo" : { },
  "id_str" : "271344078665445376",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams it makes you CTO in that company I would think ;)",
  "id" : 271344078665445376,
  "in_reply_to_status_id" : 271343688515477504,
  "created_at" : "2012-11-21 20:07:24 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 0, 9 ],
      "id_str" : "20543444",
      "id" : 20543444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271343623222734848",
  "geo" : { },
  "id_str" : "271344018598789120",
  "in_reply_to_user_id" : 20543444,
  "text" : "@HerrWulf I will DM you it :)",
  "id" : 271344018598789120,
  "in_reply_to_status_id" : 271343623222734848,
  "created_at" : "2012-11-21 20:07:10 +0000",
  "in_reply_to_screen_name" : "HerrWulf",
  "in_reply_to_user_id_str" : "20543444",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "idiots",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271343671302053888",
  "text" : "Actually the previous blog post was on Facebook advertising so I guess you can't be too hard on those type of people. #idiots",
  "id" : 271343671302053888,
  "created_at" : "2012-11-21 20:05:47 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271343368771088384",
  "text" : "I just read a companies blog and it was an entry on how to set up MAMP for dev. Part 1 of X. I hope they get a fucking clue in part 2!",
  "id" : 271343368771088384,
  "created_at" : "2012-11-21 20:04:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271342463346671616",
  "text" : "I lie... 27.6kB\/s now...",
  "id" : 271342463346671616,
  "created_at" : "2012-11-21 20:00:59 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271341816534691840",
  "text" : "BT are throttling me down to 82kB a second.... This is annoying...",
  "id" : 271341816534691840,
  "created_at" : "2012-11-21 19:58:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/271255178043330560\/photo\/1",
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/bS80Jstn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8OxJbMCEAA9HD4.jpg",
      "id_str" : "271255178047524864",
      "id" : 271255178047524864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8OxJbMCEAA9HD4.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/bS80Jstn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271255178043330560",
  "text" : "Situation Room. We just need the clocks with different time zones. http:\/\/t.co\/bS80Jstn",
  "id" : 271255178043330560,
  "created_at" : "2012-11-21 14:14:09 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270987901226057728",
  "text" : "Dear writers of Homeland. Please make use of the excellent actress that plays the daughter and stop making her Kym Bauer.",
  "id" : 270987901226057728,
  "created_at" : "2012-11-20 20:32:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 37, 50 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "schoolboyerror",
      "indices" : [ 109, 124 ]
    }, {
      "text" : "donttouchit",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270641065051185152",
  "geo" : { },
  "id_str" : "270642341239459840",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel Spending too much time with @Paul_Moffett - keep it inside for at least 20seconds after its loaded. #schoolboyerror #donttouchit",
  "id" : 270642341239459840,
  "in_reply_to_status_id" : 270641065051185152,
  "created_at" : "2012-11-19 21:38:57 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 0, 11 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270641785175433216",
  "geo" : { },
  "id_str" : "270641880771985408",
  "in_reply_to_user_id" : 5932682,
  "text" : "@davidjrice picture or STFU",
  "id" : 270641880771985408,
  "in_reply_to_status_id" : 270641785175433216,
  "created_at" : "2012-11-19 21:37:07 +0000",
  "in_reply_to_screen_name" : "davidjrice",
  "in_reply_to_user_id_str" : "5932682",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270636871758004224",
  "geo" : { },
  "id_str" : "270639667156750336",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel &lt;disclaimer&gt;I gave you no files... In fact.. who the fuck are you anyway?&lt;\/disclaimer&gt;",
  "id" : 270639667156750336,
  "in_reply_to_status_id" : 270636871758004224,
  "created_at" : "2012-11-19 21:28:19 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270636871758004224",
  "geo" : { },
  "id_str" : "270637065035710464",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel what? They are playing for me right now.... Yeah - I'll shove them now and then DM you sure. Give me a second.",
  "id" : 270637065035710464,
  "in_reply_to_status_id" : 270636871758004224,
  "created_at" : "2012-11-19 21:17:59 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 40, 47 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 56, 63 ],
      "id_str" : "11322372",
      "id" : 11322372
    }, {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 89, 98 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/jIOLiyna",
      "expanded_url" : "http:\/\/vimeo.com\/50679241",
      "display_url" : "vimeo.com\/50679241"
    }, {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/LcEUZShs",
      "expanded_url" : "http:\/\/tomayko.com\/writings\/adopt-an-open-source-process-constraints",
      "display_url" : "tomayko.com\/writings\/adopt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270636415891668992",
  "text" : "Two awesome talks became available from @github peeps - @holman http:\/\/t.co\/jIOLiyna and @rtomayko http:\/\/t.co\/LcEUZShs",
  "id" : 270636415891668992,
  "created_at" : "2012-11-19 21:15:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/2WHVjhr2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=tWh6fH85fao",
      "display_url" : "youtube.com\/watch?v=tWh6fH\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "270631425538154498",
  "geo" : { },
  "id_str" : "270633144972091392",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel awesome.. For this will happen to you if you don't. http:\/\/t.co\/2WHVjhr2",
  "id" : 270633144972091392,
  "in_reply_to_status_id" : 270631425538154498,
  "created_at" : "2012-11-19 21:02:24 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 2, 10 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270631006132916224",
  "text" : ". @jbrevel you better be watching The Walking Dead right now or I wont talk to you tomorrow at all. ROADHOUSE!",
  "id" : 270631006132916224,
  "created_at" : "2012-11-19 20:53:54 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270566407295610880",
  "geo" : { },
  "id_str" : "270567262170255360",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid Oh no - just a few people from my old work have got into my account. I deserve it - I did it to them a while back.",
  "id" : 270567262170255360,
  "in_reply_to_status_id" : 270566407295610880,
  "created_at" : "2012-11-19 16:40:36 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 68, 80 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270543118238101504",
  "text" : "OK. I have work to do - so ppl that follow me. Some dick - probably @niall_adams has hijacked my account... Knock yourself out - you cock!",
  "id" : 270543118238101504,
  "created_at" : "2012-11-19 15:04:40 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270541747413737472",
  "text" : "Ok, so it's obvious there are some issues with Twitter app security!",
  "id" : 270541747413737472,
  "created_at" : "2012-11-19 14:59:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphy201",
      "indices" : [ 0, 15 ],
      "id_str" : "508798903",
      "id" : 508798903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270538324400295936",
  "geo" : { },
  "id_str" : "270538494189895680",
  "in_reply_to_user_id" : 508798903,
  "text" : "@ChrisMurphy201 I did... So not sure what is going on. I changed my password.",
  "id" : 270538494189895680,
  "in_reply_to_status_id" : 270538324400295936,
  "created_at" : "2012-11-19 14:46:18 +0000",
  "in_reply_to_screen_name" : "ChrisMurphy201",
  "in_reply_to_user_id_str" : "508798903",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 45, 57 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 61, 77 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270537653785600000",
  "geo" : { },
  "id_str" : "270537965745348608",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc Right.. Who the fuck is this? Is this @niall_adams or @michaelnsimpson... I know I left my account open on the iPad in Tascomi...",
  "id" : 270537965745348608,
  "in_reply_to_status_id" : 270537653785600000,
  "created_at" : "2012-11-19 14:44:12 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270535353121783808",
  "geo" : { },
  "id_str" : "270537653785600000",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc that's really odd.",
  "id" : 270537653785600000,
  "in_reply_to_status_id" : 270535353121783808,
  "created_at" : "2012-11-19 14:42:57 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 0, 13 ],
      "id_str" : "5684272",
      "id" : 5684272
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 14, 28 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270536117873434624",
  "geo" : { },
  "id_str" : "270537144941023235",
  "in_reply_to_user_id" : 5684272,
  "text" : "@RickyHassard @peter_omalley Was probably me. Free kick in the stones to each of you sure :)",
  "id" : 270537144941023235,
  "in_reply_to_status_id" : 270536117873434624,
  "created_at" : "2012-11-19 14:40:56 +0000",
  "in_reply_to_screen_name" : "RickyHassard",
  "in_reply_to_user_id_str" : "5684272",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270535353121783808",
  "text" : "Hmmm seems my twitter account is still linked up to an iPad\u2026 I keep revoking access but it gets switched back\u2026 FFS...",
  "id" : 270535353121783808,
  "created_at" : "2012-11-19 14:33:49 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270534763499094016",
  "text" : "I mean, he is just ignoring me :(",
  "id" : 270534763499094016,
  "created_at" : "2012-11-19 14:31:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270515244567252992",
  "geo" : { },
  "id_str" : "270515389237178368",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll that sounds great :)",
  "id" : 270515389237178368,
  "in_reply_to_status_id" : 270515244567252992,
  "created_at" : "2012-11-19 13:14:29 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 34, 44 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270491426117255168",
  "text" : "OH: \"He even skies in a kilt\" \/cc @smccalden",
  "id" : 270491426117255168,
  "created_at" : "2012-11-19 11:39:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 73, 83 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270491361923448833",
  "text" : "OH: \"The last time I saw my father wear trousers was four years ago\" \/cc @smccalden",
  "id" : 270491361923448833,
  "created_at" : "2012-11-19 11:39:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 0, 13 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270477257770930176",
  "geo" : { },
  "id_str" : "270479987969245184",
  "in_reply_to_user_id" : 14068466,
  "text" : "@stevebiscuit that's natural selection :)",
  "id" : 270479987969245184,
  "in_reply_to_status_id" : 270477257770930176,
  "created_at" : "2012-11-19 10:53:49 +0000",
  "in_reply_to_screen_name" : "stevebiscuit",
  "in_reply_to_user_id_str" : "14068466",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270479864165986304",
  "text" : "ROADHOUSE",
  "id" : 270479864165986304,
  "created_at" : "2012-11-19 10:53:19 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 52, 62 ],
      "id_str" : "240194412",
      "id" : 240194412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "enjoy",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "dontuseittoomuchhasthatstuffisexpensive",
      "indices" : [ 94, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270476159635030016",
  "text" : "Just bought a drip coffee machine for the office in @repknight. The gourmet stuff too\u2026 #enjoy #dontuseittoomuchhasthatstuffisexpensive",
  "id" : 270476159635030016,
  "created_at" : "2012-11-19 10:38:36 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270331186646237184",
  "geo" : { },
  "id_str" : "270470154855534592",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne ah right, I thought you meant moved to Belfast. I met Steve yup yup :)",
  "id" : 270470154855534592,
  "in_reply_to_status_id" : 270331186646237184,
  "created_at" : "2012-11-19 10:14:44 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270279160235163648",
  "geo" : { },
  "id_str" : "270303712021463040",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne what you mean Cone up to Belfast?",
  "id" : 270303712021463040,
  "in_reply_to_status_id" : 270279160235163648,
  "created_at" : "2012-11-18 23:13:21 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270271690607575040",
  "geo" : { },
  "id_str" : "270278262071107584",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne  \"I am also currently ranked third in Ireland for ladies competitive bog snorkelling.\" I &lt;3 You :) :)",
  "id" : 270278262071107584,
  "in_reply_to_status_id" : 270271690607575040,
  "created_at" : "2012-11-18 21:32:13 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270271690607575040",
  "geo" : { },
  "id_str" : "270278049977753600",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne love the pic :)",
  "id" : 270278049977753600,
  "in_reply_to_status_id" : 270271690607575040,
  "created_at" : "2012-11-18 21:31:23 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270218590639255552",
  "text" : "RT @szlwzl: I got to the hot deli counter just as they were closing, 14 bbq chicken wings for 1.49. This might be the best thing ever.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270210640151470081",
    "text" : "I got to the hot deli counter just as they were closing, 14 bbq chicken wings for 1.49. This might be the best thing ever.",
    "id" : 270210640151470081,
    "created_at" : "2012-11-18 17:03:31 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 270218590639255552,
  "created_at" : "2012-11-18 17:35:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270168833812221952",
  "text" : "Hmmmm I am only up :) Lazy ass bastard that's what I am :)",
  "id" : 270168833812221952,
  "created_at" : "2012-11-18 14:17:24 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "indices" : [ 3, 16 ],
      "id_str" : "19125494",
      "id" : 19125494
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 18, 27 ],
      "id_str" : "50985598",
      "id" : 50985598
    }, {
      "name" : "RepKnight",
      "screen_name" : "RepKnight",
      "indices" : [ 41, 51 ],
      "id_str" : "240194412",
      "id" : 240194412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269876366391005184",
  "text" : "RT @nicholabates: @davehedo just saw the @repknight video - you\u2019re a bloody rockstar!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Henderson",
        "screen_name" : "davehedo",
        "indices" : [ 0, 9 ],
        "id_str" : "50985598",
        "id" : 50985598
      }, {
        "name" : "RepKnight",
        "screen_name" : "RepKnight",
        "indices" : [ 23, 33 ],
        "id_str" : "240194412",
        "id" : 240194412
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 25.2485185352, 55.3458782642 ]
    },
    "id_str" : "269872709138259969",
    "in_reply_to_user_id" : 50985598,
    "text" : "@davehedo just saw the @repknight video - you\u2019re a bloody rockstar!",
    "id" : 269872709138259969,
    "created_at" : "2012-11-17 18:40:42 +0000",
    "in_reply_to_screen_name" : "davehedo",
    "in_reply_to_user_id_str" : "50985598",
    "user" : {
      "name" : "Nichola Bates",
      "screen_name" : "nicholabates",
      "protected" : false,
      "id_str" : "19125494",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2947508512\/c9075236946505819826a2f275f50186_normal.jpeg",
      "id" : 19125494,
      "verified" : false
    }
  },
  "id" : 269876366391005184,
  "created_at" : "2012-11-17 18:55:14 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 42, 53 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/6MzN1wCy",
      "expanded_url" : "http:\/\/4sq.com\/Q1jYaT",
      "display_url" : "4sq.com\/Q1jYaT"
    } ]
  },
  "geo" : { },
  "id_str" : "269850072815132672",
  "text" : "I just unlocked the \"Adventurer\" badge on @foursquare for checking in to ten different places! http:\/\/t.co\/6MzN1wCy",
  "id" : 269850072815132672,
  "created_at" : "2012-11-17 17:10:45 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 1, 14 ],
      "id_str" : "14068466",
      "id" : 14068466
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 16, 22 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "onlyseeingthisnowffs",
      "indices" : [ 96, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269849456940302336",
  "text" : "\u201C@stevebiscuit: @swmcc don't worry, I've the lingerie on underneath the jeans &amp; t-shirt ;)\u201D #onlyseeingthisnowffs ;)",
  "id" : 269849456940302336,
  "created_at" : "2012-11-17 17:08:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269789976034676736",
  "geo" : { },
  "id_str" : "269796561872117761",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ I never said I wasn't shit ;)",
  "id" : 269796561872117761,
  "in_reply_to_status_id" : 269789976034676736,
  "created_at" : "2012-11-17 13:38:07 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crumlinisfullofshit",
      "indices" : [ 118, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269789680122347520",
  "text" : "Am at Crumlin dump. It's getting harder and harder to work out where the dump starts and the village ends to be fair. #crumlinisfullofshit",
  "id" : 269789680122347520,
  "created_at" : "2012-11-17 13:10:46 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wilkin",
      "screen_name" : "stevebiscuit",
      "indices" : [ 6, 19 ],
      "id_str" : "14068466",
      "id" : 14068466
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/269778783622557696\/photo\/1",
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/1RxNldNO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A75yX9YCcAIONJL.jpg",
      "id_str" : "269778783626752002",
      "id" : 269778783626752002,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A75yX9YCcAIONJL.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/1RxNldNO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269778783622557696",
  "text" : "Seems @stevebiscuit thinks I was joking. http:\/\/t.co\/1RxNldNO",
  "id" : 269778783622557696,
  "created_at" : "2012-11-17 12:27:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269764788417077248",
  "geo" : { },
  "id_str" : "269778317622775808",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden Going there now :)",
  "id" : 269778317622775808,
  "in_reply_to_status_id" : 269764788417077248,
  "created_at" : "2012-11-17 12:25:37 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 3, 15 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 17, 25 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 26, 32 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 33, 43 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imsohappynow",
      "indices" : [ 109, 122 ]
    }, {
      "text" : "buuurrrrrrn",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269778214837178368",
  "text" : "RT @DebbieCReid: @jbrevel @swmcc @smccalden I'd agree with those ratings but then I'm a girl! ;-) Awesome :) #imsohappynow #buuurrrrrrn",
  "id" : 269778214837178368,
  "created_at" : "2012-11-17 12:25:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 14, 24 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "needtohaveaserioustalkonmondayfella",
      "indices" : [ 95, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269754303751794688",
  "text" : "Just stalking @smccalden blog\u2026 I see his movie reviews has Rocky as 1\/5 and Love Actually 4\/5\u2026 #needtohaveaserioustalkonmondayfella",
  "id" : 269754303751794688,
  "created_at" : "2012-11-17 10:50:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269730721281765376",
  "geo" : { },
  "id_str" : "269731010579673088",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg you are well on your way to doing it. I find her character annoying in homeland anyway - comparing her to Bercow could tip me over.",
  "id" : 269731010579673088,
  "in_reply_to_status_id" : 269730721281765376,
  "created_at" : "2012-11-17 09:17:38 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269728797958475779",
  "geo" : { },
  "id_str" : "269729024195039232",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg I disagree in the strongest possible terms.. No way they are similar. Not even a little.",
  "id" : 269729024195039232,
  "in_reply_to_status_id" : 269728797958475779,
  "created_at" : "2012-11-17 09:09:45 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Dunlop",
      "screen_name" : "rickydunlop",
      "indices" : [ 0, 12 ],
      "id_str" : "14208622",
      "id" : 14208622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269641454203326465",
  "geo" : { },
  "id_str" : "269654817734017024",
  "in_reply_to_user_id" : 14208622,
  "text" : "@rickydunlop congrats :)",
  "id" : 269654817734017024,
  "in_reply_to_status_id" : 269641454203326465,
  "created_at" : "2012-11-17 04:14:53 +0000",
  "in_reply_to_screen_name" : "rickydunlop",
  "in_reply_to_user_id_str" : "14208622",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269585781360824320",
  "geo" : { },
  "id_str" : "269640419569184769",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg no no she does not!",
  "id" : 269640419569184769,
  "in_reply_to_status_id" : 269585781360824320,
  "created_at" : "2012-11-17 03:17:40 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 118, 132 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269599444813627393",
  "text" : "Also you can do nothing without someone finding out. On my way home heard a beep from a car beside me. Was the lovely @jenporterhall...",
  "id" : 269599444813627393,
  "created_at" : "2012-11-17 00:34:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stillonthewall",
      "indices" : [ 84, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269574083019157504",
  "geo" : { },
  "id_str" : "269599209244733441",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke I've been thinking I need to do that.. At 13.99 though is it worth it? #stillonthewall",
  "id" : 269599209244733441,
  "in_reply_to_status_id" : 269574083019157504,
  "created_at" : "2012-11-17 00:33:55 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 3, 10 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269599011126784001",
  "text" : "RT @szlwzl: Just used the phrase \"fuck off you fucking fuck\" while that idiot from the script was on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269570198665846784",
    "text" : "Just used the phrase \"fuck off you fucking fuck\" while that idiot from the script was on.",
    "id" : 269570198665846784,
    "created_at" : "2012-11-16 22:38:38 +0000",
    "user" : {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "protected" : false,
      "id_str" : "3604141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148628301\/2edd89ea-a08b-428b-ade0-27e60fadef32_normal.jpg",
      "id" : 3604141,
      "verified" : false
    }
  },
  "id" : 269599011126784001,
  "created_at" : "2012-11-17 00:33:07 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269578867407204352",
  "geo" : { },
  "id_str" : "269598832512335873",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ arse balls. will have to sort that tomorrow.",
  "id" : 269598832512335873,
  "in_reply_to_status_id" : 269578867407204352,
  "created_at" : "2012-11-17 00:32:25 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette",
      "screen_name" : "annette_mccull",
      "indices" : [ 0, 15 ],
      "id_str" : "161635397",
      "id" : 161635397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269564748960522240",
  "geo" : { },
  "id_str" : "269570851014340608",
  "in_reply_to_user_id" : 161635397,
  "text" : "@annette_mccull I used the wifi (and twitter) when I was at $* waiting for someone... Must have happened there..",
  "id" : 269570851014340608,
  "in_reply_to_status_id" : 269564748960522240,
  "created_at" : "2012-11-16 22:41:13 +0000",
  "in_reply_to_screen_name" : "annette_mccull",
  "in_reply_to_user_id_str" : "161635397",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269564914224463872",
  "text" : "Fuck sake now it looks like I retweeted ParisHilton..",
  "id" : 269564914224463872,
  "created_at" : "2012-11-16 22:17:38 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269564047400267776",
  "text" : "Fuck my twitter account has been hacked :D",
  "id" : 269564047400267776,
  "created_at" : "2012-11-16 22:14:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paris Hilton",
      "screen_name" : "ParisHilton",
      "indices" : [ 3, 15 ],
      "id_str" : "24929621",
      "id" : 24929621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269554659574824960",
  "text" : "RT @ParisHilton: There comes a point in your life when you realize who REALLY matters, who NEVER did, and who ALWAYS will...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268993617014714369",
    "text" : "There comes a point in your life when you realize who REALLY matters, who NEVER did, and who ALWAYS will...",
    "id" : 268993617014714369,
    "created_at" : "2012-11-15 08:27:30 +0000",
    "user" : {
      "name" : "Paris Hilton",
      "screen_name" : "ParisHilton",
      "protected" : false,
      "id_str" : "24929621",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/378800000610140459\/a559d3a1c2088554ce8598c6780c3455_normal.png",
      "id" : 24929621,
      "verified" : true
    }
  },
  "id" : 269554659574824960,
  "created_at" : "2012-11-16 21:36:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    }, {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 54, 61 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269499929653817344",
  "geo" : { },
  "id_str" : "269513819955548160",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg oh right :) Thought we were in the midst if a @pgregg rant\/bitch fest. Ahh well I'm sure it's in the pipeline ;)",
  "id" : 269513819955548160,
  "in_reply_to_status_id" : 269499929653817344,
  "created_at" : "2012-11-16 18:54:36 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269507914887213056",
  "geo" : { },
  "id_str" : "269513321177313280",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden well there's no real need to do a remake as the book and British show were superb. But I am excited regardless.",
  "id" : 269513321177313280,
  "in_reply_to_status_id" : 269507914887213056,
  "created_at" : "2012-11-16 18:52:37 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gregg",
      "screen_name" : "PGregg",
      "indices" : [ 0, 7 ],
      "id_str" : "26985337",
      "id" : 26985337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269498975877488640",
  "geo" : { },
  "id_str" : "269499167389388800",
  "in_reply_to_user_id" : 26985337,
  "text" : "@pgregg not a fan of tablets then?",
  "id" : 269499167389388800,
  "in_reply_to_status_id" : 269498975877488640,
  "created_at" : "2012-11-16 17:56:23 +0000",
  "in_reply_to_screen_name" : "PGregg",
  "in_reply_to_user_id_str" : "26985337",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/NIB6DM7E",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=ULwUzF1q5w4",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269461086711996417",
  "text" : "The original was brilliant - if this is even 50% as awesome it will be amazing\u2026 http:\/\/t.co\/NIB6DM7E",
  "id" : 269461086711996417,
  "created_at" : "2012-11-16 15:25:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 1, 11 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckmccalden",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/X7RoqBTF",
      "expanded_url" : "http:\/\/www.stephenmccalden.com\/blog\/2012\/11\/16\/fmc-80s-films\/",
      "display_url" : "stephenmccalden.com\/blog\/2012\/11\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269432687251558400",
  "text" : "\u201C@smccalden: FMC : 80s Films &gt;&gt; Won by ME!!! Free lunch ole!!! http:\/\/t.co\/X7RoqBTF\u201D #fuckmccalden Congrats :) Good choice...",
  "id" : 269432687251558400,
  "created_at" : "2012-11-16 13:32:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 13, 23 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 24, 32 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269415072625999872",
  "geo" : { },
  "id_str" : "269419248772866049",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid @smccalden @jbrevel let's hope he chokes :)",
  "id" : 269419248772866049,
  "in_reply_to_status_id" : 269415072625999872,
  "created_at" : "2012-11-16 12:38:49 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckmccalden",
      "indices" : [ 21, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/dzbkkEvC",
      "expanded_url" : "http:\/\/yfrog.com\/mga7sbp",
      "display_url" : "yfrog.com\/mga7sbp"
    } ]
  },
  "geo" : { },
  "id_str" : "269394644230623234",
  "text" : "Judging has started\u2026 #fuckmccalden  http:\/\/t.co\/dzbkkEvC",
  "id" : 269394644230623234,
  "created_at" : "2012-11-16 11:01:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 9, 21 ],
      "id_str" : "53155256",
      "id" : 53155256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269083067015131136",
  "geo" : { },
  "id_str" : "269083173797912576",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @debbiecreid you are on a 10pound limit Cocko!!! :D",
  "id" : 269083173797912576,
  "in_reply_to_status_id" : 269083067015131136,
  "created_at" : "2012-11-15 14:23:22 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 71, 81 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 93, 103 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269077682053066755",
  "text" : "I heart the internal Repknight yammer stream.. Full of conversation of @smccalden talking to @smccalden :D Quality :)",
  "id" : 269077682053066755,
  "created_at" : "2012-11-15 14:01:33 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 13, 21 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269071903069728769",
  "geo" : { },
  "id_str" : "269076926109470720",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid @jbrevel its a done deal :)",
  "id" : 269076926109470720,
  "in_reply_to_status_id" : 269071903069728769,
  "created_at" : "2012-11-15 13:58:33 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Ricky Hassard",
      "screen_name" : "RickyHassard",
      "indices" : [ 13, 26 ],
      "id_str" : "5684272",
      "id" : 5684272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269021131095293952",
  "geo" : { },
  "id_str" : "269022433149849600",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @rickyhassard I like this..",
  "id" : 269022433149849600,
  "in_reply_to_status_id" : 269021131095293952,
  "created_at" : "2012-11-15 10:22:00 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "late",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "lockogetsafreelunch",
      "indices" : [ 105, 125 ]
    }, {
      "text" : "hophechokes",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269005081838489600",
  "text" : "I would have made it if it wasn't for the temporary traffic lights on the lisburn rd! Ball cock :( #late #lockogetsafreelunch #hophechokes",
  "id" : 269005081838489600,
  "created_at" : "2012-11-15 09:13:04 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 1, 9 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 31, 37 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "late",
      "indices" : [ 61, 66 ]
    }, {
      "text" : "chaching",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269004632691453952",
  "text" : "\u201C@jbrevel: Thank you very much @swmcc I do love a free lunch #late #chaching\u201D FUCK FUCK FUCK FUCK FUCK FUCK FUCK FUCK FUCK FUCK FUCK FUCK FK",
  "id" : 269004632691453952,
  "created_at" : "2012-11-15 09:11:16 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Knowles",
      "screen_name" : "ChrisKnowles_",
      "indices" : [ 0, 14 ],
      "id_str" : "241959103",
      "id" : 241959103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268833311676313600",
  "geo" : { },
  "id_str" : "268977840291188737",
  "in_reply_to_user_id" : 241959103,
  "text" : "@ChrisKnowles_ He will make use of those thirty minutes.. With three episodes to go I would say one of the main stories will come to an end.",
  "id" : 268977840291188737,
  "in_reply_to_status_id" : 268833311676313600,
  "created_at" : "2012-11-15 07:24:49 +0000",
  "in_reply_to_screen_name" : "ChrisKnowles_",
  "in_reply_to_user_id_str" : "241959103",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268829516179333120",
  "text" : "90 mins of Sons of Anarchy to watch next week. I haven't a clue what is gonna happen...",
  "id" : 268829516179333120,
  "created_at" : "2012-11-14 21:35:25 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268714332110602240",
  "text" : "RT @jbrevel: @swmcc has just seen my ohhhhh face!! Cheese infused burgers in a cheesy bap with layers of ketchup and fiery chilli nachos ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "epiclunch",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "268710212431671298",
    "geo" : { },
    "id_str" : "268714215785766913",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc has just seen my ohhhhh face!! Cheese infused burgers in a cheesy bap with layers of ketchup and fiery chilli nachos #epiclunch",
    "id" : 268714215785766913,
    "in_reply_to_status_id" : 268710212431671298,
    "created_at" : "2012-11-14 13:57:16 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 268714332110602240,
  "created_at" : "2012-11-14 13:57:43 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 1, 9 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "peakedtooearlyintheweeklunches",
      "indices" : [ 105, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268710212431671298",
  "text" : ".@jbrevel is making sex noises as he eats his lunch. Granted its a pretty epic fucking lunch\u2026 But still\u2026 #peakedtooearlyintheweeklunches",
  "id" : 268710212431671298,
  "created_at" : "2012-11-14 13:41:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 9, 19 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckingprogrammers",
      "indices" : [ 67, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268677944308813824",
  "geo" : { },
  "id_str" : "268678140514164738",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @smccalden Not OCD - you two are just fucked in the head! #fuckingprogrammers",
  "id" : 268678140514164738,
  "in_reply_to_status_id" : 268677944308813824,
  "created_at" : "2012-11-14 11:33:55 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268644233643171841",
  "text" : "OH: \"You posh whorebag\"...",
  "id" : 268644233643171841,
  "created_at" : "2012-11-14 09:19:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    }, {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 15, 31 ],
      "id_str" : "311597138",
      "id" : 311597138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268631286162284544",
  "geo" : { },
  "id_str" : "268641733364027392",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley @michaelnsimpson I concur.",
  "id" : 268641733364027392,
  "in_reply_to_status_id" : 268631286162284544,
  "created_at" : "2012-11-14 09:09:15 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268463091572936704",
  "geo" : { },
  "id_str" : "268463315708166145",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley :) :) Happy memories",
  "id" : 268463315708166145,
  "in_reply_to_status_id" : 268463091572936704,
  "created_at" : "2012-11-13 21:20:16 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 64, 72 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268454803376590848",
  "geo" : { },
  "id_str" : "268462352855334912",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden that looks amazing. Bring one in tomorrow and me and @jbrevel will fight for it :)",
  "id" : 268462352855334912,
  "in_reply_to_status_id" : 268454803376590848,
  "created_at" : "2012-11-13 21:16:27 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Caswell",
      "screen_name" : "creationix",
      "indices" : [ 3, 14 ],
      "id_str" : "70596949",
      "id" : 70596949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EpicPullRequest",
      "indices" : [ 105, 121 ]
    }, {
      "text" : "BestDocumente",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 104 ],
      "url" : "https:\/\/t.co\/XuCNCOo6",
      "expanded_url" : "https:\/\/github.com\/ajaxorg\/cloud9\/pull\/2369",
      "display_url" : "github.com\/ajaxorg\/cloud9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268462040144809985",
  "text" : "RT @creationix: This is what happens when your tech writer submits a pull request! https:\/\/t.co\/XuCNCOo6 #EpicPullRequest #BestDocumente ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EpicPullRequest",
        "indices" : [ 89, 105 ]
      }, {
        "text" : "BestDocumentedPullRequest",
        "indices" : [ 106, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 88 ],
        "url" : "https:\/\/t.co\/XuCNCOo6",
        "expanded_url" : "https:\/\/github.com\/ajaxorg\/cloud9\/pull\/2369",
        "display_url" : "github.com\/ajaxorg\/cloud9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "268450313411887104",
    "text" : "This is what happens when your tech writer submits a pull request! https:\/\/t.co\/XuCNCOo6 #EpicPullRequest #BestDocumentedPullRequest",
    "id" : 268450313411887104,
    "created_at" : "2012-11-13 20:28:36 +0000",
    "user" : {
      "name" : "Tim Caswell",
      "screen_name" : "creationix",
      "protected" : false,
      "id_str" : "70596949",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/2636020456\/d447953a1f656bc20420859e667da59f_normal.jpeg",
      "id" : 70596949,
      "verified" : false
    }
  },
  "id" : 268462040144809985,
  "created_at" : "2012-11-13 21:15:12 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 0, 14 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268446481747423232",
  "geo" : { },
  "id_str" : "268461909886517249",
  "in_reply_to_user_id" : 437697624,
  "text" : "@peter_omalley that's just amazing",
  "id" : 268461909886517249,
  "in_reply_to_status_id" : 268446481747423232,
  "created_at" : "2012-11-13 21:14:41 +0000",
  "in_reply_to_screen_name" : "peter_omalley",
  "in_reply_to_user_id_str" : "437697624",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268391448091717632",
  "text" : "I just looked at our patch panel and now I want to cry :D I am not looking again :)",
  "id" : 268391448091717632,
  "created_at" : "2012-11-13 16:34:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268386942532595715",
  "geo" : { },
  "id_str" : "268388701732745216",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams Your mother is below my desk right now - sucking me off\u2026. I'll tell her to call round to see you when she's done!",
  "id" : 268388701732745216,
  "in_reply_to_status_id" : 268386942532595715,
  "created_at" : "2012-11-13 16:23:47 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 13, 27 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268388058368446464",
  "geo" : { },
  "id_str" : "268388612004016128",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams @peter_omalley I signed off it a while back :)",
  "id" : 268388612004016128,
  "in_reply_to_status_id" : 268388058368446464,
  "created_at" : "2012-11-13 16:23:26 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatthoughtwilllinger",
      "indices" : [ 37, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268384602740117505",
  "geo" : { },
  "id_str" : "268385714868207616",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams I know where you live\u2026. #thatthoughtwilllinger",
  "id" : 268385714868207616,
  "in_reply_to_status_id" : 268384602740117505,
  "created_at" : "2012-11-13 16:11:55 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268378942237450241",
  "geo" : { },
  "id_str" : "268381896956862467",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams FUCK. SAKE.",
  "id" : 268381896956862467,
  "in_reply_to_status_id" : 268378942237450241,
  "created_at" : "2012-11-13 15:56:45 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rumble Labs",
      "screen_name" : "rumblelabs",
      "indices" : [ 0, 11 ],
      "id_str" : "20454184",
      "id" : 20454184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268371280749817857",
  "geo" : { },
  "id_str" : "268373082446655488",
  "in_reply_to_user_id" : 20454184,
  "text" : "@rumblelabs maybe some non alcoholic ones for the drivers? But that's me chancing my arm ;) :D",
  "id" : 268373082446655488,
  "in_reply_to_status_id" : 268371280749817857,
  "created_at" : "2012-11-13 15:21:43 +0000",
  "in_reply_to_screen_name" : "rumblelabs",
  "in_reply_to_user_id_str" : "20454184",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fresh Made Media",
      "screen_name" : "studiofmm",
      "indices" : [ 23, 33 ],
      "id_str" : "137625620",
      "id" : 137625620
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 38, 52 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268342962843418627",
  "text" : "Liking the new look of @studiofmm \/cc @No_Underscore no point cc'ing Ryan he never uses this damn twitter thing :)",
  "id" : 268342962843418627,
  "created_at" : "2012-11-13 13:22:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Reid",
      "screen_name" : "DebbieCReid",
      "indices" : [ 0, 12 ],
      "id_str" : "53155256",
      "id" : 53155256
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 61, 71 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268335681632358400",
  "geo" : { },
  "id_str" : "268342452333719552",
  "in_reply_to_user_id" : 53155256,
  "text" : "@DebbieCReid they've taken it down so am now in full view of @smccalden and his happy face :(",
  "id" : 268342452333719552,
  "in_reply_to_status_id" : 268335681632358400,
  "created_at" : "2012-11-13 13:20:00 +0000",
  "in_reply_to_screen_name" : "DebbieCReid",
  "in_reply_to_user_id_str" : "53155256",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 1, 8 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 36, 45 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rejoco\/status\/268330990626299905\/photo\/1",
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/TiOnH3VL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7lNnUMCYAACwUu.jpg",
      "id_str" : "268330990634688512",
      "id" : 268330990634688512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7lNnUMCYAACwUu.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TiOnH3VL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268331717721485312",
  "text" : "\u201C@rejoco: . Starter for 10 of stand @davehedo modelling http:\/\/t.co\/TiOnH3VL\u201D The front view of my previous tweet :)",
  "id" : 268331717721485312,
  "created_at" : "2012-11-13 12:37:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/268330874066591745\/photo\/1",
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/ntiRsr0a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7lNgh9CYAIjvXk.jpg",
      "id_str" : "268330874070786050",
      "id" : 268330874070786050,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7lNgh9CYAIjvXk.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/ntiRsr0a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268330874066591745",
  "text" : "The view to my left - wish this could stay up forever. http:\/\/t.co\/ntiRsr0a",
  "id" : 268330874066591745,
  "created_at" : "2012-11-13 12:34:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/268277968076406784\/photo\/1",
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/z8X3QlJP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7kdY_yCAAAgpKj.jpg",
      "id_str" : "268277968080601088",
      "id" : 268277968080601088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7kdY_yCAAAgpKj.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/z8X3QlJP"
    } ],
    "hashtags" : [ {
      "text" : "inyourfacelocko",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268277968076406784",
  "text" : "#inyourfacelocko 1min to spare http:\/\/t.co\/z8X3QlJP",
  "id" : 268277968076406784,
  "created_at" : "2012-11-13 09:03:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Braziel",
      "screen_name" : "Braziel",
      "indices" : [ 0, 8 ],
      "id_str" : "776654",
      "id" : 776654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268260895933730817",
  "geo" : { },
  "id_str" : "268267074214834176",
  "in_reply_to_user_id" : 776654,
  "text" : "@Braziel Good luck..",
  "id" : 268267074214834176,
  "in_reply_to_status_id" : 268260895933730817,
  "created_at" : "2012-11-13 08:20:29 +0000",
  "in_reply_to_screen_name" : "Braziel",
  "in_reply_to_user_id_str" : "776654",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/L13ahubj",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/business-20303218",
      "display_url" : "bbc.co.uk\/news\/business-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268092892059402240",
  "text" : "http:\/\/t.co\/L13ahubj That's who they should have sent. They employ 100's of ppl and keep them in jobs.. Tax avoidance isn't illegal!",
  "id" : 268092892059402240,
  "created_at" : "2012-11-12 20:48:21 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/3vAuqDYa",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/business-20301381",
      "display_url" : "bbc.co.uk\/news\/business-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268091719755640833",
  "text" : "Amazon should have sent a stronger individual than this.  http:\/\/t.co\/3vAuqDYa",
  "id" : 268091719755640833,
  "created_at" : "2012-11-12 20:43:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268085401368031232",
  "geo" : { },
  "id_str" : "268086812352868354",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel no need Cocko - ill check in via foursquare ;)",
  "id" : 268086812352868354,
  "in_reply_to_status_id" : 268085401368031232,
  "created_at" : "2012-11-12 20:24:11 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 79, 87 ],
      "id_str" : "50685221",
      "id" : 50685221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268084509654806528",
  "text" : "Making one sided bet challenges with men from Ballycastle is just no good. \/cc @jbrevel I shall be checking in on my phone if I can find it!",
  "id" : 268084509654806528,
  "created_at" : "2012-11-12 20:15:02 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ihatefeet",
      "indices" : [ 95, 105 ]
    }, {
      "text" : "yuck",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268052932811976704",
  "geo" : { },
  "id_str" : "268084267261759489",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne I didn't mean it that way. I mean any talk of anything foot related is rank :( #ihatefeet #yuck",
  "id" : 268084267261759489,
  "in_reply_to_status_id" : 268052932811976704,
  "created_at" : "2012-11-12 20:14:04 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 15, 27 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268075436205035521",
  "geo" : { },
  "id_str" : "268083449875808256",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @willemkokke there is nothing moderately priced around your area. Fucking madness round there :)",
  "id" : 268083449875808256,
  "in_reply_to_status_id" : 268075436205035521,
  "created_at" : "2012-11-12 20:10:49 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenni Porter",
      "screen_name" : "jenporterhall",
      "indices" : [ 28, 42 ],
      "id_str" : "227493010",
      "id" : 227493010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268083213774237697",
  "text" : "Nice coffee with the lovely @jenporterhall at M&amp;S... Scenery wasn't bad as well :)",
  "id" : 268083213774237697,
  "created_at" : "2012-11-12 20:09:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgina_Milne",
      "screen_name" : "Georgina_Milne",
      "indices" : [ 0, 15 ],
      "id_str" : "15344533",
      "id" : 15344533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268041602549817344",
  "geo" : { },
  "id_str" : "268043078420549632",
  "in_reply_to_user_id" : 15344533,
  "text" : "@Georgina_Milne disgusting talk.",
  "id" : 268043078420549632,
  "in_reply_to_status_id" : 268041602549817344,
  "created_at" : "2012-11-12 17:30:24 +0000",
  "in_reply_to_screen_name" : "Georgina_Milne",
  "in_reply_to_user_id_str" : "15344533",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grrrcentos",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268007452375654400",
  "text" : "I really feel dirty having CentOS on this lovely lovely mac\u2026 #grrrcentos",
  "id" : 268007452375654400,
  "created_at" : "2012-11-12 15:08:50 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 0, 13 ],
      "id_str" : "36913698",
      "id" : 36913698
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 14, 26 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feeldirty",
      "indices" : [ 69, 79 ]
    }, {
      "text" : "grrrrcentos",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267932195837054977",
  "geo" : { },
  "id_str" : "267933746181844992",
  "in_reply_to_user_id" : 36913698,
  "text" : "@Paul_Moffett @willemkokke I am downloading a cents image right now. #feeldirty #grrrrcentos",
  "id" : 267933746181844992,
  "in_reply_to_status_id" : 267932195837054977,
  "created_at" : "2012-11-12 10:15:57 +0000",
  "in_reply_to_screen_name" : "Paul_Moffett",
  "in_reply_to_user_id_str" : "36913698",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 57 ],
      "url" : "https:\/\/t.co\/h1k3qYX3",
      "expanded_url" : "https:\/\/github.com\/cloudera\/impala",
      "display_url" : "github.com\/cloudera\/impala"
    } ]
  },
  "geo" : { },
  "id_str" : "267928117849497601",
  "text" : "Today I will be mostly playing with https:\/\/t.co\/h1k3qYX3 - lets see what happens :)",
  "id" : 267928117849497601,
  "created_at" : "2012-11-12 09:53:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267744504470179840",
  "text" : "David Haye, Muhammad Ali, George Foreman, joe Frazier, Larry Holmes. One of the above is not the same. One of the above is....",
  "id" : 267744504470179840,
  "created_at" : "2012-11-11 21:43:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "Rick Monro",
      "screen_name" : "monro",
      "indices" : [ 15, 21 ],
      "id_str" : "16466617",
      "id" : 16466617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267708794841219073",
  "geo" : { },
  "id_str" : "267710060929630208",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @monro Hmmmm still on the wall....",
  "id" : 267710060929630208,
  "in_reply_to_status_id" : 267708794841219073,
  "created_at" : "2012-11-11 19:27:06 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Adams",
      "screen_name" : "PRAEst76",
      "indices" : [ 0, 9 ],
      "id_str" : "12081742",
      "id" : 12081742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267343924874588162",
  "geo" : { },
  "id_str" : "267350353694056448",
  "in_reply_to_user_id" : 12081742,
  "text" : "@PRAEst76 my wallpaper is class! I picked that last summer! It's awesome!",
  "id" : 267350353694056448,
  "in_reply_to_status_id" : 267343924874588162,
  "created_at" : "2012-11-10 19:37:46 +0000",
  "in_reply_to_screen_name" : "PRAEst76",
  "in_reply_to_user_id_str" : "12081742",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267286709870415872",
  "geo" : { },
  "id_str" : "267288600629084160",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke :)",
  "id" : 267288600629084160,
  "in_reply_to_status_id" : 267286709870415872,
  "created_at" : "2012-11-10 15:32:23 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267285723080695810",
  "geo" : { },
  "id_str" : "267286440046653440",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke luckily spit isn't part of he http protocol ;)",
  "id" : 267286440046653440,
  "in_reply_to_status_id" : 267285723080695810,
  "created_at" : "2012-11-10 15:23:47 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrayTaoist",
      "screen_name" : "StrayTaoist",
      "indices" : [ 0, 12 ],
      "id_str" : "760043",
      "id" : 760043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267284479758966784",
  "geo" : { },
  "id_str" : "267284663406575616",
  "in_reply_to_user_id" : 760043,
  "text" : "@StrayTaoist I am retro!!!",
  "id" : 267284663406575616,
  "in_reply_to_status_id" : 267284479758966784,
  "created_at" : "2012-11-10 15:16:44 +0000",
  "in_reply_to_screen_name" : "StrayTaoist",
  "in_reply_to_user_id_str" : "760043",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/Jrq2cejj",
      "expanded_url" : "http:\/\/instagr.am\/p\/R2nRMfhXwZ\/",
      "display_url" : "instagr.am\/p\/R2nRMfhXwZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "267282450349166592",
  "text" : "Fuck you Mr. Lucas. Fuck you... http:\/\/t.co\/Jrq2cejj",
  "id" : 267282450349166592,
  "created_at" : "2012-11-10 15:07:56 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267017034603327488",
  "geo" : { },
  "id_str" : "267017299855306752",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll put the twitters down, take a bath and go to sleep. Tomorrow is a new day.",
  "id" : 267017299855306752,
  "in_reply_to_status_id" : 267017034603327488,
  "created_at" : "2012-11-09 21:34:19 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana",
      "screen_name" : "Alana_Doll",
      "indices" : [ 0, 11 ],
      "id_str" : "67130324",
      "id" : 67130324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267016622223548416",
  "geo" : { },
  "id_str" : "267016723318857728",
  "in_reply_to_user_id" : 67130324,
  "text" : "@Alana_Doll why so?",
  "id" : 267016723318857728,
  "in_reply_to_status_id" : 267016622223548416,
  "created_at" : "2012-11-09 21:32:02 +0000",
  "in_reply_to_screen_name" : "Alana_Doll",
  "in_reply_to_user_id_str" : "67130324",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266921315955531776",
  "geo" : { },
  "id_str" : "266926303813451776",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher Nah programming is programming\u2026",
  "id" : 266926303813451776,
  "in_reply_to_status_id" : 266921315955531776,
  "created_at" : "2012-11-09 15:32:44 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Belcher",
      "screen_name" : "philipbelcher",
      "indices" : [ 0, 14 ],
      "id_str" : "47601296",
      "id" : 47601296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266898253428191232",
  "geo" : { },
  "id_str" : "266909968815505408",
  "in_reply_to_user_id" : 47601296,
  "text" : "@philipbelcher what you using this weather code wise?",
  "id" : 266909968815505408,
  "in_reply_to_status_id" : 266898253428191232,
  "created_at" : "2012-11-09 14:27:50 +0000",
  "in_reply_to_screen_name" : "philipbelcher",
  "in_reply_to_user_id_str" : "47601296",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ComputingSecurityAwards",
      "indices" : [ 67, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266880342676353025",
  "text" : "RT @maildistiller: We cannot believe we won Editor's Choice at the #ComputingSecurityAwards last night! Great week for us, absolutely ov ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ComputingSecurityAwards",
        "indices" : [ 48, 72 ]
      }, {
        "text" : "GoTeam",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266879639736176641",
    "text" : "We cannot believe we won Editor's Choice at the #ComputingSecurityAwards last night! Great week for us, absolutely overwhelmed #GoTeam",
    "id" : 266879639736176641,
    "created_at" : "2012-11-09 12:27:19 +0000",
    "user" : {
      "name" : "ProofpointEssentials",
      "screen_name" : "Proofpoint_SMB",
      "protected" : false,
      "id_str" : "152962481",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/3754782848\/438736811a4e19f957757c58e218bd63_normal.png",
      "id" : 152962481,
      "verified" : false
    }
  },
  "id" : 266880342676353025,
  "created_at" : "2012-11-09 12:30:06 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 1, 11 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckmccalden",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/55UNkRrF",
      "expanded_url" : "http:\/\/www.stephenmccalden.com\/blog\/2012\/11\/09\/fmc-summer-holiday\/",
      "display_url" : "stephenmccalden.com\/blog\/2012\/11\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "266872559268663296",
  "text" : "\u201C@smccalden: FMC : Week one of the new office Friday Music Club and we\u2019ve got a topic of Summer Holiday http:\/\/t.co\/55UNkRrF\u201D #fuckmccalden",
  "id" : 266872559268663296,
  "created_at" : "2012-11-09 11:59:11 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 0, 8 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Navicat",
      "screen_name" : "_Navicat",
      "indices" : [ 9, 18 ],
      "id_str" : "83992904",
      "id" : 83992904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266860359162417152",
  "geo" : { },
  "id_str" : "266865993282887680",
  "in_reply_to_user_id" : 50685221,
  "text" : "@jbrevel @_navicat noooo use the shell :) navicat\u2026 I dunno - hippies :D",
  "id" : 266865993282887680,
  "in_reply_to_status_id" : 266860359162417152,
  "created_at" : "2012-11-09 11:33:05 +0000",
  "in_reply_to_screen_name" : "jbrevel",
  "in_reply_to_user_id_str" : "50685221",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266858595969298432",
  "text" : "Am quite happy with gitlab so far after three weeks use\u2026 Its no github but its not bad...",
  "id" : 266858595969298432,
  "created_at" : "2012-11-09 11:03:41 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckmccalden",
      "indices" : [ 14, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/Ea8qqrl3",
      "expanded_url" : "http:\/\/yfrog.com\/gyl5nsp",
      "display_url" : "yfrog.com\/gyl5nsp"
    } ]
  },
  "geo" : { },
  "id_str" : "266849691516432384",
  "text" : "First week of #fuckmccalden and I pick the wrong version of All Summer Long and lose\u2026  http:\/\/t.co\/Ea8qqrl3",
  "id" : 266849691516432384,
  "created_at" : "2012-11-09 10:28:18 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 9, 19 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/3jnTzhpT",
      "expanded_url" : "http:\/\/instagram.com\/swmcc\/",
      "display_url" : "instagram.com\/swmcc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "266640914909372416",
  "text" : "I got an @instagram profile now.. Follow me bitches - http:\/\/t.co\/3jnTzhpT",
  "id" : 266640914909372416,
  "created_at" : "2012-11-08 20:38:42 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 24, 37 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "waitfortheboom",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266591935484030976",
  "text" : "In about twenty seconds @Paul_Moffett is going to explode.... Within in the next minute anyway... lets see... #waitfortheboom",
  "id" : 266591935484030976,
  "created_at" : "2012-11-08 17:24:05 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Richardson",
      "screen_name" : "marcus_r1975",
      "indices" : [ 0, 13 ],
      "id_str" : "445071004",
      "id" : 445071004
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 14, 26 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266547745215631360",
  "geo" : { },
  "id_str" : "266549578231341060",
  "in_reply_to_user_id" : 445071004,
  "text" : "@marcus_r1975 @niall_adams pair of bitches bitching.... show some class motherfuckers! :)",
  "id" : 266549578231341060,
  "in_reply_to_status_id" : 266547745215631360,
  "created_at" : "2012-11-08 14:35:46 +0000",
  "in_reply_to_screen_name" : "marcus_r1975",
  "in_reply_to_user_id_str" : "445071004",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266529899370655744",
  "geo" : { },
  "id_str" : "266530565002498048",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore feeling okay dude? :)",
  "id" : 266530565002498048,
  "in_reply_to_status_id" : 266529899370655744,
  "created_at" : "2012-11-08 13:20:13 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266310063893934080",
  "geo" : { },
  "id_str" : "266310615772053504",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl was quality hearing him wake up in the middle of the night\u2026 Awesome trick. :)",
  "id" : 266310615772053504,
  "in_reply_to_status_id" : 266310063893934080,
  "created_at" : "2012-11-07 22:46:13 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266310063893934080",
  "geo" : { },
  "id_str" : "266310541386084352",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl When that first came out I was living with my bro.. So one night I put water on his floor and turned on the tv when he was asleep!",
  "id" : 266310541386084352,
  "in_reply_to_status_id" : 266310063893934080,
  "created_at" : "2012-11-07 22:45:55 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "szlwzl",
      "screen_name" : "szlwzl",
      "indices" : [ 0, 7 ],
      "id_str" : "3604141",
      "id" : 3604141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266306945957367810",
  "geo" : { },
  "id_str" : "266309491786645504",
  "in_reply_to_user_id" : 3604141,
  "text" : "@szlwzl that film scared the crap out of me for years!!!!",
  "id" : 266309491786645504,
  "in_reply_to_status_id" : 266306945957367810,
  "created_at" : "2012-11-07 22:41:45 +0000",
  "in_reply_to_screen_name" : "szlwzl",
  "in_reply_to_user_id_str" : "3604141",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 30, 44 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266209475592073216",
  "geo" : { },
  "id_str" : "266209918527348736",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams @peter_omalley I shouldn't have to say this.. However.. DO. NOT. BUY. A. FUCKING. ONSEY!!!!",
  "id" : 266209918527348736,
  "in_reply_to_status_id" : 266209475592073216,
  "created_at" : "2012-11-07 16:06:05 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike ",
      "screen_name" : "michaelnsimpson",
      "indices" : [ 0, 16 ],
      "id_str" : "311597138",
      "id" : 311597138
    }, {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 17, 29 ],
      "id_str" : "28624459",
      "id" : 28624459
    }, {
      "name" : "Peter O'Malley",
      "screen_name" : "peter_omalley",
      "indices" : [ 30, 44 ],
      "id_str" : "437697624",
      "id" : 437697624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266203924896301057",
  "geo" : { },
  "id_str" : "266207066622947328",
  "in_reply_to_user_id" : 311597138,
  "text" : "@michaelnsimpson @niall_adams @peter_omalley I leave you for two and a half weeks and now look!",
  "id" : 266207066622947328,
  "in_reply_to_status_id" : 266203924896301057,
  "created_at" : "2012-11-07 15:54:45 +0000",
  "in_reply_to_screen_name" : "michaelnsimpson",
  "in_reply_to_user_id_str" : "311597138",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 13, 26 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266160773464743936",
  "geo" : { },
  "id_str" : "266160998929539072",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @paul_moffett I think he's turned the notification off though.. Lets see\u2026.. :)",
  "id" : 266160998929539072,
  "in_reply_to_status_id" : 266160773464743936,
  "created_at" : "2012-11-07 12:51:41 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 13, 26 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266160773464743936",
  "geo" : { },
  "id_str" : "266160880859889664",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @paul_moffett Nope. I quite like it\u2026 *BEEEP*",
  "id" : 266160880859889664,
  "in_reply_to_status_id" : 266160773464743936,
  "created_at" : "2012-11-07 12:51:13 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 0, 6 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 7, 19 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 20, 33 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266158793489014785",
  "geo" : { },
  "id_str" : "266158900586348544",
  "in_reply_to_user_id" : 804717,
  "text" : "@swmcc @willemkokke @paul_moffett LOUD AUDBILE BEEP WHEN I TWEET PAUL\u2026 *BEEEEEEEEEP*",
  "id" : 266158900586348544,
  "in_reply_to_status_id" : 266158793489014785,
  "created_at" : "2012-11-07 12:43:21 +0000",
  "in_reply_to_screen_name" : "swmcc",
  "in_reply_to_user_id_str" : "804717",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem Kokke",
      "screen_name" : "willemkokke",
      "indices" : [ 0, 12 ],
      "id_str" : "78104215",
      "id" : 78104215
    }, {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 13, 26 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266158562877784066",
  "geo" : { },
  "id_str" : "266158793489014785",
  "in_reply_to_user_id" : 78104215,
  "text" : "@willemkokke @paul_moffett I meant inflection\u2026 :)",
  "id" : 266158793489014785,
  "in_reply_to_status_id" : 266158562877784066,
  "created_at" : "2012-11-07 12:42:56 +0000",
  "in_reply_to_screen_name" : "willemkokke",
  "in_reply_to_user_id_str" : "78104215",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 15, 24 ],
      "id_str" : "20543444",
      "id" : 20543444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266137596315443200",
  "geo" : { },
  "id_str" : "266139859347963904",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @herrwulf 15quid!!! FUCK THAT!",
  "id" : 266139859347963904,
  "in_reply_to_status_id" : 266137596315443200,
  "created_at" : "2012-11-07 11:27:41 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 15, 24 ],
      "id_str" : "20543444",
      "id" : 20543444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266122371365208064",
  "geo" : { },
  "id_str" : "266137214352781312",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @herrwulf how much for though. That place is really expensive.",
  "id" : 266137214352781312,
  "in_reply_to_status_id" : 266122371365208064,
  "created_at" : "2012-11-07 11:17:11 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Moffett",
      "screen_name" : "Paul_Moffett",
      "indices" : [ 16, 29 ],
      "id_str" : "36913698",
      "id" : 36913698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266137079740788736",
  "text" : "Word of warning @paul_moffett just ended two sentences with an infliction.. One more and he'll be killed\u2026",
  "id" : 266137079740788736,
  "created_at" : "2012-11-07 11:16:39 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susanna Reid",
      "screen_name" : "susannareid100",
      "indices" : [ 3, 18 ],
      "id_str" : "19477583",
      "id" : 19477583
    }, {
      "name" : "Bill Turnbull",
      "screen_name" : "billtu",
      "indices" : [ 58, 65 ],
      "id_str" : "17716950",
      "id" : 17716950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266118006772482048",
  "text" : "RT @susannareid100: Thanks for your company this morning. @billtu doing a brilliant job in Washington. 2 billion dollars later, America  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Turnbull",
        "screen_name" : "billtu",
        "indices" : [ 38, 45 ],
        "id_str" : "17716950",
        "id" : 17716950
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266108066611724288",
    "text" : "Thanks for your company this morning. @billtu doing a brilliant job in Washington. 2 billion dollars later, America has the same President.",
    "id" : 266108066611724288,
    "created_at" : "2012-11-07 09:21:21 +0000",
    "user" : {
      "name" : "Susanna Reid",
      "screen_name" : "susannareid100",
      "protected" : false,
      "id_str" : "19477583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040936357\/4eb8d0eed29d4603c790d7ab89614aec_normal.jpeg",
      "id" : 19477583,
      "verified" : true
    }
  },
  "id" : 266118006772482048,
  "created_at" : "2012-11-07 10:00:51 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266101048450621440",
  "text" : "320,000 tweets a minute!!!!",
  "id" : 266101048450621440,
  "created_at" : "2012-11-07 08:53:28 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265933471057326080",
  "text" : "\/usr\/local\/Cellar\/postgresql\/9.2.1: 2813 files, 37M, built in 4.7 minutes",
  "id" : 265933471057326080,
  "created_at" : "2012-11-06 21:47:34 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bootstrap",
      "screen_name" : "twbootstrap",
      "indices" : [ 34, 46 ],
      "id_str" : "372475592",
      "id" : 372475592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imaprogrammernotadesigner",
      "indices" : [ 101, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265930203279273984",
  "text" : "I am telling ya. If it wasn't for @twbootstrap I would be well screwed - any app I do ends up using. #imaprogrammernotadesigner",
  "id" : 265930203279273984,
  "created_at" : "2012-11-06 21:34:35 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "welldone",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 21 ],
      "url" : "https:\/\/t.co\/t4IzhzJz",
      "expanded_url" : "https:\/\/npmjs.org\/package\/bower",
      "display_url" : "npmjs.org\/package\/bower"
    } ]
  },
  "geo" : { },
  "id_str" : "265805474698514432",
  "text" : "https:\/\/t.co\/t4IzhzJz - this will save me shit loads of time. #welldone",
  "id" : 265805474698514432,
  "created_at" : "2012-11-06 13:18:58 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keavy",
      "screen_name" : "keavy",
      "indices" : [ 0, 6 ],
      "id_str" : "8605362",
      "id" : 8605362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265487815708659712",
  "geo" : { },
  "id_str" : "265488466517823488",
  "in_reply_to_user_id" : 8605362,
  "text" : "@keavy thank you for posting the slides.",
  "id" : 265488466517823488,
  "in_reply_to_status_id" : 265487815708659712,
  "created_at" : "2012-11-05 16:19:17 +0000",
  "in_reply_to_screen_name" : "keavy",
  "in_reply_to_user_id_str" : "8605362",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/9YZcVimB",
      "expanded_url" : "http:\/\/yfrog.com\/oembwcp",
      "display_url" : "yfrog.com\/oembwcp"
    } ]
  },
  "geo" : { },
  "id_str" : "265482858062299137",
  "text" : "I feel a bit dirty having this installed on my lovely new mac\u2026 However only way to see interesting webinars :( http:\/\/t.co\/9YZcVimB",
  "id" : 265482858062299137,
  "created_at" : "2012-11-05 15:57:00 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "davidjrice",
      "indices" : [ 0, 11 ],
      "id_str" : "5932682",
      "id" : 5932682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265469490408603648",
  "geo" : { },
  "id_str" : "265470047642845184",
  "in_reply_to_user_id" : 5932682,
  "text" : "@davidjrice Starting to show your age there - about fucking time. This pleases me :D",
  "id" : 265470047642845184,
  "in_reply_to_status_id" : 265469490408603648,
  "created_at" : "2012-11-05 15:06:06 +0000",
  "in_reply_to_screen_name" : "davidjrice",
  "in_reply_to_user_id_str" : "5932682",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265360111604731904",
  "text" : "Fucking Frost ::(",
  "id" : 265360111604731904,
  "created_at" : "2012-11-05 07:49:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 0, 10 ],
      "id_str" : "169048119",
      "id" : 169048119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265224247876653056",
  "geo" : { },
  "id_str" : "265225040096800768",
  "in_reply_to_user_id" : 169048119,
  "text" : "@smccalden even your tweet sounds Chinese :)",
  "id" : 265225040096800768,
  "in_reply_to_status_id" : 265224247876653056,
  "created_at" : "2012-11-04 22:52:31 +0000",
  "in_reply_to_screen_name" : "smccalden",
  "in_reply_to_user_id_str" : "169048119",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265197188223746049",
  "geo" : { },
  "id_str" : "265216283296014336",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues oh there will be :)",
  "id" : 265216283296014336,
  "in_reply_to_status_id" : 265197188223746049,
  "created_at" : "2012-11-04 22:17:44 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265216207614001152",
  "text" : "Yoda doing a crossword..... I give up ....",
  "id" : 265216207614001152,
  "created_at" : "2012-11-04 22:17:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265174433868677120",
  "text" : "Last episode of Downtown tonight... This does not please me...",
  "id" : 265174433868677120,
  "created_at" : "2012-11-04 19:31:26 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Monro",
      "screen_name" : "monro",
      "indices" : [ 0, 6 ],
      "id_str" : "16466617",
      "id" : 16466617
    }, {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 7, 21 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 22, 31 ],
      "id_str" : "20543444",
      "id" : 20543444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265101264688410624",
  "geo" : { },
  "id_str" : "265101525775425536",
  "in_reply_to_user_id" : 16466617,
  "text" : "@monro @No_Underscore @HerrWulf it just depends. I think we are all weary due to the prequels... It is 50\/50 at the minute.",
  "id" : 265101525775425536,
  "in_reply_to_status_id" : 265101264688410624,
  "created_at" : "2012-11-04 14:41:43 +0000",
  "in_reply_to_screen_name" : "monro",
  "in_reply_to_user_id_str" : "16466617",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 15, 24 ],
      "id_str" : "20543444",
      "id" : 20543444
    }, {
      "name" : "Rick Monro",
      "screen_name" : "monro",
      "indices" : [ 25, 31 ],
      "id_str" : "16466617",
      "id" : 16466617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265100261314400256",
  "geo" : { },
  "id_str" : "265100541145788417",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @HerrWulf @monro Well Disney might go for the 8-14 year demographic to enhance the lifeline of the franchise. So we will see.",
  "id" : 265100541145788417,
  "in_reply_to_status_id" : 265100261314400256,
  "created_at" : "2012-11-04 14:37:48 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    }, {
      "name" : "David Turner",
      "screen_name" : "HerrWulf",
      "indices" : [ 15, 24 ],
      "id_str" : "20543444",
      "id" : 20543444
    }, {
      "name" : "Rick Monro",
      "screen_name" : "monro",
      "indices" : [ 25, 31 ],
      "id_str" : "16466617",
      "id" : 16466617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265098263991042048",
  "geo" : { },
  "id_str" : "265099636488949760",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore @HerrWulf @monro I agree. But I think they would be best served to focus on the expanded universe - make it their own etc.",
  "id" : 265099636488949760,
  "in_reply_to_status_id" : 265098263991042048,
  "created_at" : "2012-11-04 14:34:13 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Murray",
      "screen_name" : "No_Underscore",
      "indices" : [ 0, 14 ],
      "id_str" : "33658328",
      "id" : 33658328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265084500759953408",
  "geo" : { },
  "id_str" : "265085794258124801",
  "in_reply_to_user_id" : 33658328,
  "text" : "@No_Underscore I doubt that :( Hamill possibly. Fisher - probably not. Ford - no way\u2026 But still you never know :)",
  "id" : 265085794258124801,
  "in_reply_to_status_id" : 265084500759953408,
  "created_at" : "2012-11-04 13:39:13 +0000",
  "in_reply_to_screen_name" : "No_Underscore",
  "in_reply_to_user_id_str" : "33658328",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigella Lawson",
      "screen_name" : "Nigella_Lawson",
      "indices" : [ 3, 18 ],
      "id_str" : "173195708",
      "id" : 173195708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264818046609285121",
  "text" : "RT @Nigella_Lawson: Didn't manage an Ulster Fry, but leaving Belfast with a Boojums burrito under my belt, so all good!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264383886228873216",
    "text" : "Didn't manage an Ulster Fry, but leaving Belfast with a Boojums burrito under my belt, so all good!",
    "id" : 264383886228873216,
    "created_at" : "2012-11-02 15:10:05 +0000",
    "user" : {
      "name" : "Nigella Lawson",
      "screen_name" : "Nigella_Lawson",
      "protected" : false,
      "id_str" : "173195708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397689056\/bd21781d721a04c5329c40630522b3b8_normal.jpeg",
      "id" : 173195708,
      "verified" : true
    }
  },
  "id" : 264818046609285121,
  "created_at" : "2012-11-03 19:55:17 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 3, 11 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "Stephen McCullough",
      "screen_name" : "swmcc",
      "indices" : [ 13, 19 ],
      "id_str" : "804717",
      "id" : 804717
    }, {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 20, 27 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 28, 38 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 39, 48 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264700517647794176",
  "text" : "RT @jbrevel: @swmcc @rejoco @smccalden @davehedo ha, I supposedly was at doy and was chatting to Zach Braff before getting chucked out # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen McCullough",
        "screen_name" : "swmcc",
        "indices" : [ 0, 6 ],
        "id_str" : "804717",
        "id" : 804717
      }, {
        "name" : "John Reid",
        "screen_name" : "rejoco",
        "indices" : [ 7, 14 ],
        "id_str" : "53053999",
        "id" : 53053999
      }, {
        "name" : "Stephen McCalden",
        "screen_name" : "smccalden",
        "indices" : [ 15, 25 ],
        "id_str" : "169048119",
        "id" : 169048119
      }, {
        "name" : "David Henderson",
        "screen_name" : "davehedo",
        "indices" : [ 26, 35 ],
        "id_str" : "50985598",
        "id" : 50985598
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "awesome",
        "indices" : [ 122, 130 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "264699064732504066",
    "geo" : { },
    "id_str" : "264699970395979777",
    "in_reply_to_user_id" : 804717,
    "text" : "@swmcc @rejoco @smccalden @davehedo ha, I supposedly was at doy and was chatting to Zach Braff before getting chucked out #awesome",
    "id" : 264699970395979777,
    "in_reply_to_status_id" : 264699064732504066,
    "created_at" : "2012-11-03 12:06:05 +0000",
    "in_reply_to_screen_name" : "swmcc",
    "in_reply_to_user_id_str" : "804717",
    "user" : {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "protected" : false,
      "id_str" : "50685221",
      "profile_image_url_https" : "https:\/\/si0.twimg.com\/profile_images\/1237514871\/41667_623870939_4871_n_normal.jpg",
      "id" : 50685221,
      "verified" : false
    }
  },
  "id" : 264700517647794176,
  "created_at" : "2012-11-03 12:08:15 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 31, 40 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatshitwontbetoleratedatxmasbitch",
      "indices" : [ 88, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264699499778277376",
  "text" : "One thing I learnt last night. @davehedo can hold two pints better than any man I know. #thatshitwontbetoleratedatxmasbitch",
  "id" : 264699499778277376,
  "created_at" : "2012-11-03 12:04:13 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Reid",
      "screen_name" : "rejoco",
      "indices" : [ 0, 7 ],
      "id_str" : "53053999",
      "id" : 53053999
    }, {
      "name" : "Stephen McCalden",
      "screen_name" : "smccalden",
      "indices" : [ 8, 18 ],
      "id_str" : "169048119",
      "id" : 169048119
    }, {
      "name" : "John Loughrey",
      "screen_name" : "jbrevel",
      "indices" : [ 19, 27 ],
      "id_str" : "50685221",
      "id" : 50685221
    }, {
      "name" : "David Henderson",
      "screen_name" : "davehedo",
      "indices" : [ 28, 37 ],
      "id_str" : "50985598",
      "id" : 50985598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264663817601028096",
  "geo" : { },
  "id_str" : "264699064732504066",
  "in_reply_to_user_id" : 53053999,
  "text" : "@rejoco @smccalden @jbrevel @davehedo I left my house keys in the office so spent the night on my parents living room floor! #fail",
  "id" : 264699064732504066,
  "in_reply_to_status_id" : 264663817601028096,
  "created_at" : "2012-11-03 12:02:29 +0000",
  "in_reply_to_screen_name" : "rejoco",
  "in_reply_to_user_id_str" : "53053999",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Adams",
      "screen_name" : "niall_adams",
      "indices" : [ 0, 12 ],
      "id_str" : "28624459",
      "id" : 28624459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264407043971108864",
  "geo" : { },
  "id_str" : "264448998314762240",
  "in_reply_to_user_id" : 28624459,
  "text" : "@niall_adams barely dude.... Barely",
  "id" : 264448998314762240,
  "in_reply_to_status_id" : 264407043971108864,
  "created_at" : "2012-11-02 19:28:49 +0000",
  "in_reply_to_screen_name" : "niall_adams",
  "in_reply_to_user_id_str" : "28624459",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swmcc\/status\/264448993122197505\/photo\/1",
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/w0MrsRl8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6uC9UjCIAAhRkD.jpg",
      "id_str" : "264448993130586112",
      "id" : 264448993130586112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6uC9UjCIAAhRkD.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/w0MrsRl8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264448993122197505",
  "text" : "Can you spot the differences between the two authors ??? http:\/\/t.co\/w0MrsRl8",
  "id" : 264448993122197505,
  "created_at" : "2012-11-02 19:28:48 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatstheworsthatcanhappen",
      "indices" : [ 112, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264335417959145472",
  "text" : "Repknight day out to the Down Royal... If anyone is looking me I'll be under a table by 5 I think.. Maybe not.. #whatstheworsthatcanhappen",
  "id" : 264335417959145472,
  "created_at" : "2012-11-02 11:57:29 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fucksake",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264293239593500672",
  "text" : "Laptop forgot again. #fucksake",
  "id" : 264293239593500672,
  "created_at" : "2012-11-02 09:09:53 +0000",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManyHues",
      "screen_name" : "ManyHues",
      "indices" : [ 0, 9 ],
      "id_str" : "17864413",
      "id" : 17864413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263780903904493568",
  "geo" : { },
  "id_str" : "263794867208073216",
  "in_reply_to_user_id" : 17864413,
  "text" : "@ManyHues you can only count the last two years... prior to that you lived in apartment... Unfair stat that I think :)",
  "id" : 263794867208073216,
  "in_reply_to_status_id" : 263780903904493568,
  "created_at" : "2012-11-01 00:09:32 +0000",
  "in_reply_to_screen_name" : "ManyHues",
  "in_reply_to_user_id_str" : "17864413",
  "user" : {
    "name" : "Stephen McCullough",
    "screen_name" : "swmcc",
    "protected" : false,
    "id_str" : "804717",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2470646242\/wsnfbha57fhe3ab9e9tr_normal.jpeg",
    "id" : 804717,
    "verified" : false
  }
} ]